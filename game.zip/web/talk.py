"""The browser version, stage 3: talking to people and what it leads to, on panels (web/panel.py): a
conversation (game/dialogue.py, as ui/chat_dialog.py shows it), quests offered and handed in, trainers,
menders, passage, a temple raising the dead; trading (ui/trade_dialog.py); a shift of work and the bank
(ui/money_dialog.py); the watch; a temple's cures; crimes.
"""
from __future__ import annotations

from game import places
from game.state import money_text
from web.panel import Panel
from web.scene import png64

WORK_KINDS = [(None, "Any work going?", "Let them pick"), ("Fetch", "Something to fetch", "Bring them an item"),
              ("Defeat", "Something to fight", "Deal with a threat"), ("Visit", "Somewhere to go", "Go to a place for them")]
THANKS = ["Good work. Here, you've earned this.", "That's everything. Thank you, truly.",
          "I knew I could count on you.", "Just what I needed. Take this, with my thanks."]


def _face(world, state, npc) -> str:
    try:
        from game.art.portrait import MOOD, portrait_of
        mood = MOOD.get(state.disposition(npc), "neutral") if npc.type == "npc" else ""
        art = portrait_of(world, npc, mood)
        if art is None:
            art = world.sprites.render_entity(npc, world.entities)
        return png64(art) if art is not None else ""
    except Exception:  # noqa: BLE001 - a face is never worth an error
        return ""


class Talking:
    """Mixed into web.bridge.Session."""

    # ==================================================================
    # A conversation
    # ==================================================================
    def _talk(self, npc_id: str, tree: dict | None = None, title: str = "") -> None:
        from game.dialogue import Conversation
        from game.quests import first_name
        npc = self.world.entities.get(npc_id)
        if npc is None or npc.type != "npc":
            return
        bits = [npc.fields.get("occupation") or ""]
        home = self.world.entities.get(places.building_of(self.world, npc))
        if home:
            bits.append(home.name)
        try:
            from game import factions
            f = factions.primary(self.world, npc)
            if f is not None:
                bits.append(f"{f.name}: {factions.level(self.world, self.state, f.id)}")
        except Exception:  # noqa: BLE001
            pass
        cv = Conversation(self.world, self.state, npc, self.book, self.members, self.rng, self.bus, tree=tree)
        t = {"cv": cv, "npc": npc, "screen": "main", "arg": None, "offer": None, "wants": None,
             "first": first_name(npc.name)}
        p = self._panel(Panel(title or f"Talking with {npc.name}", lambda p: self._talk_build(p, t), npc.name,
                              "  ·  ".join(b for b in bits if b), _face(self.world, self.state, npc), close="Goodbye",
                              on_close=lambda p: self._talk_after(t)))
        t["p"] = p
        self.bus.emit("npc.talked", npc=npc.id)
        first = cv.line()
        if first:
            self._said(t, first)
        hostile = cv.node != cv.hub and "hostile" in cv.node
        if self.book is not None and not hostile:          # the first person the party talks to: a story
            try:
                from game import chains
                offer = chains.starter_offer(self.world, self.state, npc, self.book.levels())
            except Exception:  # noqa: BLE001
                offer = None
            if offer is not None:
                self._said(t, offer["pitch"])
                t.update(screen="offer", offer=offer)

    def _said(self, t: dict, text: str, mine: bool = False) -> None:
        """A line said: in the conversation, and in the log."""
        t["p"].say(text, "You" if mine else t["first"], "you" if mine else "them")
        if mine:
            self.bus.emit("log", kind="player", text=text)
        else:
            self.say("dialogue", f"{t['npc'].name}: {text}")

    def _note(self, t: dict, text: str, kind: str = "quest") -> None:
        t["p"].say(text, "", "note" if kind == "quest" else "gold")

    def _talk_build(self, p: Panel, t: dict) -> None:
        s = t["screen"]
        getattr(self, "_talk_" + s)(p, t)

    def _talk_main(self, p: Panel, t: dict) -> None:
        for ch in t["cv"].options():
            p.option("►  " + ch.text, (lambda p, c=ch: self._talk_pick(t, c)), ch.check_text if ch.enabled else ch.why,
                     enabled=ch.enabled)

    def _talk_pick(self, t: dict, choice) -> None:
        self._said(t, choice.text, True)
        r = t["cv"].choose(choice)
        if r.check is not None:
            ok = bool(r.check.get("success"))
            total = r.check.get("total")
            self._note(t, f"{choice.check_text}: {total if total is not None else '-'}, {'success' if ok else 'failure'}.",
                       "quest" if ok else "loot")
        for n in r.notes:
            self._note(t, n, "loot")
        if r.line:
            self._said(t, r.line)
        t["screen"] = "main"
        if r.fight:
            t["wants"] = ("fight",)
            t["p"].closed = True
            return
        if r.quest is not None:
            t.update(screen="offer", offer=r.quest)
            return
        if r.open and self._talk_open(t, r.open, r.open_arg or {}):
            return
        if r.end:
            t["p"].closed = True

    def _talk_open(self, t: dict, what: str, arg: dict) -> bool:
        q = self.book.get(arg.get("quest_id") or "") if arg.get("quest_id") and self.book is not None else None
        if what in ("trade", "fence"):
            t["wants"] = ("trade",)
            t["p"].closed = True
            return True
        if what == "work":
            if self.book.handmade_available(t["npc"]) or self.book.from_npc_active(t["npc"]) or \
                    self.book.days_until_next(t["npc"]):
                self._talk_ask(t, None, quiet=True)
            else:
                t["screen"] = "work"
            return True
        if what == "hand_in" and q is not None:
            lines = self.book.hand_in(q["id"])
            if not lines and self.book.get(q["id"]).get("status") != "completed":
                self._said(t, "That's not everything I asked for. Come back when it is.")
            else:
                self._said(t, self.rng.choice(THANKS))
                if lines:
                    self._note(t, "You receive: " + ", ".join(lines), "loot")
            return True
        if what == "about" and q is not None:
            left = [o for o in q["objectives"] if not o.get("done")]
            if left:
                o = left[0]
                extra = f" That's {o.get('progress', 0)} of {o['count']} so far." if o["count"] > 1 else ""
                self._said(t, f"Still waiting on that. {o['text']}.{extra}")
            else:
                self._said(t, "Well? Have you done it?")
            return False
        if what in ("passage", "revive", "train", "restore"):
            t["screen"] = what
            return True
        if what == "choose" and q is not None:
            t.update(screen="choice", arg=(q["id"], int(arg.get("objective") or 0)))
            o = q["objectives"][t["arg"][1]]
            self._said(t, f"So. {o['text']}?" if not o["text"].endswith("?") else o["text"])
            return True
        if what == "drink":
            self._buy_round(t)
            return False
        if what in ("library", "college", "jobs", "bank", "bounty", "games", "arena", "land", "claim_due", "hire",
                    "automatons", "settle", "cure", "guild", "brothel"):
            t["wants"] = (what,)
            t["p"].closed = True
            return True
        return False

    def _buy_round(self, t: dict) -> None:
        from game import rumors
        if self.state.copper < rumors.DRINK_PRICE:
            self._said(t, "Coin first, friend.")
            return
        self.state.add_copper(-rumors.DRINK_PRICE, "a round")
        town = t["cv"].town()
        r = rumors.hear(self.world, self.state, town, self.rng, source=t["npc"].name, bus=None) if town else None
        if r is None:
            self._said(t, "Thanks. Can't say I've heard anything new, mind.")
        else:
            self._said(t, r["text"])
            self._note(t, f"Rumor heard ({money_text(rumors.DRINK_PRICE)}). It's in the journal.")

    # ---- work: asking for a quest
    def _talk_work(self, p: Panel, t: dict) -> None:
        for kind, text, sub in WORK_KINDS:
            p.option("►  " + text, (lambda p, k=kind: self._talk_ask(t, k)), sub)
        p.option("Never mind", lambda p: t.update(screen="main"), style="ghost")

    def _talk_ask(self, t: dict, kind, quiet: bool = False) -> None:
        line = {None: "Got any work for me?", "Fetch": "Need anything fetched?",
                "Defeat": "Anything need fighting?", "Visit": "Need anyone to go somewhere?"}[kind]
        if not quiet:
            self._said(t, line, True)
        quest, reply = self.book.offer(t["npc"], kind)
        self._said(t, reply)
        t.update(screen="offer", offer=quest) if quest is not None else t.update(screen="main")

    def _talk_offer(self, p: Panel, t: dict) -> None:
        q = t["offer"]
        p.head(q["title"])
        p.text(f"{q.get('kind', '')}  ·  from {q.get('giver_name', '')}", "small")
        for o in q["objectives"]:
            p.text(f"□  {o['text']}")
            if o.get("hint"):
                p.text(o["hint"], "small")
        reward = self.book.reward_text(q)
        if reward:
            p.text(f"Reward:  {reward}", "gold")

        def accept(p):
            self._said(t, "I'll do it.", True)
            got = self.book.accept(q, t["npc"])
            self._said(t, self.rng.choice(["Good. Don't keep me waiting.", "Thank you. Come back when it's done.",
                                           "I'll hold you to that."]))
            self._note(t, f"Quest accepted: {got['title']}")
            t["screen"] = "main"

        def decline(p):
            self._said(t, "Not right now.", True)
            self._said(t, "Suit yourself. The offer stands for a while." if q.get("source") == "generated"
                       else "Think it over.")
            t["screen"] = "main"
        p.buttons(("Not now", decline, "ghost"), ("Accept", accept, "primary"))

    # ---- a quest's decision (game/chains.py)
    def _talk_choice(self, p: Panel, t: dict) -> None:
        qid, index = t["arg"]
        q = self.book.get(qid)
        for k, c in enumerate(q["objectives"][index].get("choices") or []):
            def go(p, k=k, c=c):
                self._said(t, c["text"] + ".", True)
                ok, text = self.book.choose(qid, index, k, self.members, self.rng)
                if ok:
                    self._said(t, self.rng.choice(["So be it.", "Then that's how it is.", "I'll remember that."]))
                    self._note(t, f"{text[:1].upper()}{text[1:]}.")
                else:
                    self._said(t, text)
                t["screen"] = "main"
            p.option("►  " + c["text"], go, f"{c['check'][0]} check" if c.get("check") else "")
        p.option("I need to think about it", lambda p: t.update(screen="main"), style="ghost")

    # ---- trainers and menders (game/tools.py, game/quality.py)
    def _talk_train(self, p: Panel, t: dict) -> None:
        from game import tools
        npc = t["npc"]
        keys = tools.trains(self.world, npc)
        if not t.get("trained_said"):
            t["trained_said"] = True
            names = ", ".join(tools.label(self.world, k) for k in keys)
            self._said(t, f"I can teach {names}. It isn't cheap, and the rest is practice." if keys
                       else "I've nothing to teach.")
        for key in keys:
            cost = tools.price(self.world, self.state, key, npc)
            for m in [m for m in self.members if not m.get("dead")]:
                can, why = tools.can_train(self.world, m, key)
                ok = can and self.state.copper >= cost

                def go(p, m=m, key=key):
                    good, text = tools.train(self.world, self.state, m, key, npc, self.bus)
                    if good:
                        self._said(t, "Watch closely. ...Again. Again. There: you have it.")
                        self._note(t, text, "loot")
                    else:
                        p.message = text
                    t["screen"] = "main"
                    t.pop("trained_said", None)
                p.option(f"Train {m.get('name')} in {tools.label(self.world, key)}", go if ok else None,
                         money_text(cost) if ok else (why or f"{money_text(cost)} (you have {money_text(self.state.copper)})"),
                         enabled=ok)
        p.option("Back", lambda p: (t.update(screen="main"), t.pop("trained_said", None)), style="ghost")

    def _talk_restore(self, p: Panel, t: dict) -> None:
        from game import quality
        occ = t["npc"].fields.get("occupation") or ""
        held = [(w, i, n) for w, i, n in quality.damaged_held(self.world, self.state, self.members)
                if quality.mender_takes(occ, self.world.entities.get(i))]
        p.text("Let's see what you've got." if held else "Nothing here I can mend.", "small")
        for where, item_id, _n in held:
            item = self.world.entities.get(item_id)
            who = "the pack" if where == "pack" else next((m.get("name") for m in self.members if m.get("id") == where), "")
            cost = quality.restore_cost(self.world, item_id)
            ok = self.state.copper >= cost

            def go(p, w=where, i=item_id):
                good, text, _whole = quality.restore(self.world, self.state, self.members, w, i, 1)
                p.message = text
            p.option(f"Mend {item.name if item else item_id} ({who})", go if ok else None,
                     money_text(cost) + ("" if ok else " (you can't afford it)"), enabled=ok)
        p.option("Back", lambda p: t.update(screen="main"), style="ghost")

    # ---- ships, airships and caravans
    def _talk_passage(self, p: Panel, t: dict) -> None:
        from game import geography as G
        from game import passage
        trips = passage.offers(self.world, t["npc"])
        words = {"Boat": "by ship", "Airship": "by airship", "Caravan": "with the caravan"}
        p.text("Where are you headed?" if trips else "I've no trips to offer.", "small")
        for o in trips:
            cont = G.continent_of_town(self.world, o["to"])
            where = o["to"].name + (f", {cont.name}" if cont is not None else "")
            ok = self.state.copper >= o["price"] * 100

            def go(p, o=o):
                self._said(t, f"We'll go to {o['to'].name}.", True)
                self._said(t, "Then get aboard. We leave now.")
                t["wants"] = ("passage", o)
                p.closed = True
            p.option(f"To {where} {words.get(o['method'], '')}", go if ok else None,
                     f"{o['price']} gp, {o['days']} day{'s' if o['days'] != 1 else ''}" +
                     ("" if ok else " (you can't afford it)") + (f"  ·  {o['note']}" if o["note"] else ""), enabled=ok)
        p.option("Back", lambda p: t.update(screen="main"), style="ghost")

    # ---- temples raise the dead
    def _talk_revive(self, p: Panel, t: dict) -> None:
        from game import party as P
        cost = int(self.world.rules.get("revive_cost", 500) or 0)
        p.text("Who have you lost?", "small")
        for m in [m for m in self.members if m.get("dead")]:
            ok = self.state.copper >= cost * 100

            def go(p, m=m):
                if self.state.copper < cost * 100:
                    return
                self.state.add_copper(-cost * 100, f"raising {m.get('name')}")
                m["dead"] = False
                rec = self.state.party.setdefault(m["id"], {})
                rec["hp"] = 1
                rec["conditions"] = {}
                self.state.save()
                P.save(self.world, self.members)
                self._said(t, f"The rite is done. {m.get('name')} breathes again, weak but alive.")
                self._note(t, f"{m.get('name')} is alive again (1 HP).", "loot")
                self.bus.emit("party.revived", member=m["id"])
                t["screen"] = "main"
            p.option(f"Raise {m.get('name')}", go if ok else None, f"{cost} gp" if ok else
                     f"{cost} gp (you have {money_text(self.state.copper)})", enabled=ok)
        p.option("Back", lambda p: t.update(screen="main"), style="ghost")

    # ---- after the talk
    def _talk_after(self, t: dict) -> None:
        w = t.get("wants")
        if not w:
            return
        npc = t["npc"]
        what = w[0]
        if what == "fight":
            self.say("narration", f"{npc.name} draws on you!")
            self._fight_npc(npc.id)
        elif what == "trade":
            self._open_trade(npc.id)
        elif what == "passage":
            self._start_voyage(w[1])
        elif what == "jobs":
            self._open_jobs(npc)
        elif what == "guild":
            self._open_guild(npc)
        elif what == "brothel":
            self._open_brothel(npc)
        elif what == "bank":
            self._open_bank(npc)
        elif what == "bounty":
            self._face_the_law(npc)
        elif what == "cure":
            self._open_cure(npc)
        elif what == "claim_due":
            self._register_claims(npc)                     # (web/estate.py)
        else:
            self._more_after_talk(what, npc)

    def _more_after_talk(self, what: str, npc) -> None:
        """Library, college, games, the arena, land and hired hands, settlers: web/places2.py where it's there."""
        fn = getattr(self, "_talk_leads_to", None)
        if fn is None or not fn(what, npc):
            from web.bridge import STAGE_LATER
            self.say("system", STAGE_LATER)

    # ==================================================================
    # Trading (ui/trade_dialog.py)
    # ==================================================================
    def _open_trade(self, npc_id: str) -> None:
        from game import trade
        npc = self.world.entities.get(npc_id)
        if npc is None:
            return
        if not trade.will_trade(npc, self.state):
            self.say("dialogue", f"{npc.name}: I'm not selling anything to you.")
            return
        if not trade.is_merchant(self.world, npc):
            self.say("dialogue", f"{npc.name}: I've nothing to sell, sorry.")
            return
        spot = places.current(self.world, self.state)
        if spot.kind == "building" and not places.is_open(spot.building, self.state.minute_of_day):
            self.say("dialogue", f"{npc.name}: We're closed. Come back at {places.opens_at(spot.building)}.")
            return
        tr = {"npc": npc, "mode": "buy", "sel": ""}
        self._panel(Panel(f"Trade with {npc.name}", lambda p: self._trade_build(p, tr), npc.name, "",
                          _face(self.world, self.state, npc)))

    def _describe_item(self, item) -> str:
        f = item.fields
        bits = [f.get("category") or ""]
        if f.get("category") == "Weapon":
            bits.append(f"{f.get('damage', '')} {f.get('damage_type', '')}".strip())
        if f.get("category") in ("Armor", "Shield"):
            bits.append(f"AC {f.get('armor_class', '')}")
        if f.get("use_effect"):
            bits.append(f"{f.get('use_effect')} {f.get('use_dice', '')}".strip())
        if f.get("weight"):
            bits.append(f"{f.get('weight')} lb")
        text = "  ·  ".join(b for b in bits if b)
        return (text + ("\n" + item.description if item.description else "")).strip()

    def _trade_build(self, p: Panel, tr: dict) -> None:
        from game import trade
        w, s, npc = self.world, self.state, tr["npc"]
        p.sub = f"Your purse: {money_text(s.copper)}   ·   {npc.name} has {money_text(trade.purse(s, npc))} to spend"
        stock = trade.stock(w, s, npc, self.rng)
        special = set(trade.special_ids(s, npc))
        needed = {o["target"] for q in self.book.active() for o in q["objectives"] if o["kind"] == "Fetch"} \
            if self.book is not None else set()
        sel = tr["sel"]
        if sel:                                      # what's picked: about it, how many, the price
            item = w.entities.get(sel)
            have = stock.get(sel, 0) if tr["mode"] == "buy" else s.count(sel)
            if item is None or have <= 0:
                tr["sel"] = ""
            else:
                p.head(item.name)
                p.text(self._describe_item(item), "small")
                p.number("qty", "How many", 1, 1, max(1, have))
                n = int(p.values.get("qty") or 1)
                if tr["mode"] == "buy":
                    each = trade.buy_price(w, s, npc, item)
                    ok = each * n <= s.copper
                    label = f"Buy for {money_text(each * n)}"
                    fn = trade.buy
                else:
                    each = trade.sell_price(w, s, npc, item)
                    ok = each > 0 and each * n <= trade.purse(s, npc)
                    label = f"Sell for {money_text(each * n)}" if each else "Worthless here"
                    fn = trade.sell

                def deal(p, fn=fn):
                    good, msg = fn(w, s, npc, tr["sel"], int(p.values.get("qty") or 1), self.bus)
                    p.message = msg
                    self.say("loot" if good else "system", msg)
                    p.values["qty"] = 1
                    if good and tr["mode"] == "sell" and s.count(tr["sel"]) <= 0:
                        tr["sel"] = ""
                p.buttons(("Back", lambda p: tr.update(sel=""), "ghost"), (label, deal if ok else None, "primary"))
                return
        p.head(f"{npc.name} sells")
        if not stock:
            p.text("Nothing for sale right now.", "small")
        for item_id, n in sorted(stock.items(), key=lambda kv: w.entities.get(kv[0]).name):
            item = w.entities.get(item_id)
            price = trade.buy_price(w, s, npc, item)
            p.option(f"{item.name}  ×{n}", (lambda p, i=item_id: (tr.update(mode="buy", sel=i), p.values.update(qty=1))),
                     (money_text(price) if price else "—") + ("  (kept for friends)" if item_id in special else ""))
        p.head("Your pack")
        rows = [(i, n) for i, n in s.inventory.items() if w.entities.get(i) is not None and n]
        if not rows:
            p.text("Your pack is empty.", "small")
        for item_id, n in sorted(rows, key=lambda kv: w.entities.get(kv[0]).name):
            item = w.entities.get(item_id)
            price = trade.sell_price(w, s, npc, item)
            p.option(f"{item.name}  ×{n}", (lambda p, i=item_id: (tr.update(mode="sell", sel=i), p.values.update(qty=1))),
                     (money_text(price) if price else "worthless here") + ("  (quest item)" if item_id in needed else ""))
        p.option("Haggle", (lambda p: self._haggle(p, npc)) if trade.can_haggle(s, npc) else None,
                 "Persuasion, once a day: 10% better prices if it works", style="ghost")

    def _haggle(self, p: Panel, npc) -> None:
        from game import checks, condition, trade
        opts = checks.options(self.world)
        persuade = next((o for o in opts if o["label"].lower() == "persuasion"), None) or \
            next((o for o in opts if o["stat"] == "cha"), None)
        live = [m for m in self.members if not m.get("dead")]
        if persuade is None or not live:
            return
        best = None
        for m in live:
            c = condition.combatant(self.world, m)
            b, _p = checks.bonus(self.world, m, c, persuade)
            if best is None or b > best[0]:
                best = (b, m, c)
        _b, m, c = best
        r = checks.roll(self.world, m, c, persuade, 15, rng=self.rng, bus=self.bus, target=npc.name)
        trade.haggled(self.state, npc, bool(r["success"]))
        p.message = (f"{c.name} haggles: {r['total']} vs DC 15. " +
                     ("Prices are 10% better today." if r["success"] else f"{npc.name} won't budge."))

    # ==================================================================
    # Money: a shift of work, the bank, the watch (ui/money_dialog.py), a temple's cures
    # ==================================================================
    def _open_jobs(self, npc) -> None:
        from game import jobs
        offers = jobs.offers(self.world, self.state, npc, self.members)

        def build(p: Panel) -> None:
            p.text("Everyone in the party works, and each is paid by how good they are at it.", "small")
            if not offers:
                p.text("There's no work going.", "gold")
            for o in offers:
                tip = f"Pay rises with {o['skill']}. " + ", ".join(f"{n}: {money_text(r)} an hour" for _i, n, r in o["members"])

                def take(p, o=o):
                    self._fx(o.get("sound") or "timeskip", 0.8)
                    r = jobs.work(self.world, self.state, self.members, o, bool(p.values.get("goods")), self.bus)
                    self.say("loot", r["text"])
                    p.closed = True
                p.option(o["text"], take, "", desc=tip)
            if offers:
                p.check("goods", "Take goods instead of coin, where they're offered")
        self._panel(Panel(f"Work for {npc.name}", build, npc.name, "", _face(self.world, self.state, npc), close="Not now"))

    def _open_brothel(self, npc) -> None:
        """Hire a courtesan (game/brothel.py): who goes upstairs. Then the screen cuts to black."""
        from game import brothel
        from game.state import money_text

        def build(p: Panel) -> None:
            cost = brothel.price(npc) * 100
            p.text(f"{npc.name}'s company is {money_text(cost)}. Who goes upstairs?", "small")
            for m in self.members:
                if m.get("dead"):
                    continue

                def go(p, m=m):
                    out = brothel.visit(self.world, self.state, self.members, m["id"], npc, self.rng, self.bus)
                    if out.get("ok"):
                        self._fx(out["blackout"]["sound"])
                        self._blackout = out["blackout"]
                    for line in out["lines"]:
                        self.say("narration", line)
                    p.closed = True
                    if out.get("ok"):
                        self.api_save()
                p.option(m.get("name") or "?", go if self.state.copper >= cost else None,
                         f"Performance {brothel.bonus(self.world, m):+d}", enabled=self.state.copper >= cost)
        self._panel(Panel("Upstairs", build, npc.name, "", _face(self.world, self.state, npc), close="Not now"))

    def _open_guild(self, npc) -> None:
        """Work for the thieves' guild (game/thieves.py)."""
        from game import thieves

        def build(p: Panel) -> None:
            town = thieves._npc_town(self.world, npc)
            g = thieves.guild_of(self.world, town)
            r, _s = thieves.rank(self.world, self.state, town)
            p.text(f"{g.name if g else 'The guild'} takes {int(thieves.GUILD_CUT * 100)}% of the take. "
                   + (f"You're a {r} of the guild." if r else "You're nobody to the guild yet.") +
                   (" Its cutpurses and muggers leave you be." if thieves.protected(self.world, self.state, town)
                    else ""), "small")
            for j in thieves.jobs_for(self.world, self.state, npc, self.members):
                def go(p, j=j):
                    self._fx("timeskip", 0.8)
                    out = thieves.do_job(self.world, self.state, self.members, npc, j["id"], self.rng, self.bus)
                    self.say("loot" if out.get("paid") else "narration", out["text"])
                    p.closed = True
                lo, hi = j["gp"]
                sub = (f"{j['hours']} h · {j['skill']} DC {j['dc']} · {j['who']} {j['bonus']:+d} · {lo}-{hi} gp"
                       if j["open"] else f"Needs: {j['need']}")
                p.option(j["name"], go if j["open"] else None, sub, enabled=j["open"])
        self._panel(Panel("Work for the guild", build, npc.name, "", _face(self.world, self.state, npc),
                          close="Not now"))

    def _open_bank(self, who) -> None:
        from game import bank, law
        b = who if who is not None and who.type == "building" else bank.bank_of(self.world, who)
        if b is None:
            return
        key = bank.realm_of(self.world, b)

        def build(p: Panel) -> None:
            s = self.state
            most, rate, lvl = bank.terms(self.world, s, key)
            ln = bank.loan(s, key)
            p.text(f"Banks of {law.realm_name(self.world, key)}. Your purse: {money_text(s.copper)}.")
            p.text(f"In the account: {money_text(bank.balance(s, key))} (the same at every bank in the realm; safe if "
                   f"you fall).")
            if ln:
                p.text(f"You owe {money_text(ln['owed'])}: {money_text(ln['weekly'])} a week, next on day {ln['due_day']}" +
                       (f". Missed payments: {ln['missed']}" if ln.get("missed") else "") + ".")
            elif most:
                p.text(f"Being {lvl.lower()} here, you could borrow up to {most:,} gp at {int(rate * 100)}% over "
                       f"{bank.WEEKS} weeks, repaid weekly.")
            else:
                p.text(f"They won't lend to someone {lvl.lower()} in these parts.")
            p.number("gp", "Gold pieces", 10, 1, 1_000_000, " gp")

            def said(p, r):
                p.message = r[1]
            gp = lambda p: int(p.values.get("gp") or 1)  # noqa: E731
            p.buttons(("Deposit", lambda p: said(p, bank.deposit(self.world, self.state, key, gp(p) * 100)), ""),
                      ("Withdraw", lambda p: said(p, bank.withdraw(self.world, self.state, key, gp(p) * 100)), ""))
            p.buttons(("Borrow", lambda p: said(p, bank.borrow(self.world, self.state, key, gp(p))), ""),
                      ("Repay", lambda p: said(p, bank.repay(self.world, self.state, key, gp(p) * 100)), ""))
        self._panel(Panel(b.name, build))

    def _face_the_law(self, npc=None, key: str = "") -> None:
        from game import law
        if not key:
            key, gp = law.wanted_here(self.world, self.state)
        else:
            gp = law.bounty(self.world, self.state, key)
        if gp <= 0:
            self.say("system", "You're not wanted here.")
            return
        law.confronted(self.state)

        def build(p: Panel) -> None:
            p.text(f"\"Hold there. You're wanted in {law.realm_name(self.world, key)}: {gp} gp, or the cells.\"")
            for text, act, ok in law.guard_prompt_options(self.world, self.state, key, gp):
                p.option(text, (lambda p, a=act[1]: (setattr(p, "then", lambda: self._law_choice(a, key)),
                                                     setattr(p, "closed", True))) if ok else None,
                         style="danger" if act[1] == "resist" else "primary" if act[1] == "pay" else "")
        self._panel(Panel(npc.name if npc is not None else "The watch", build, close="Walk away"))

    def _law_choice(self, what: str, key: str) -> None:
        from game import law
        town = places.current(self.world, self.state).town
        if what == "pay":
            _ok, text = law.pay_fine(self.world, self.state, key, self.bus)
            self.say("system", text)
        elif what == "jail":
            from game import jail
            got = jail.imprison(self.world, self.state, self.members, key, self.ex, self.bus)   # (a real jail)
            if got.get("ok"):
                self._fx("door_close", 0.9)
                self.say("narration", got["text"])
                self.api_save()
                return
            self._fx("timeskip", 0.8)
            _ok, text = law.go_to_jail(self.world, self.state, key, self.bus)
            self.say("narration", text)
            self.ex.sync()
        elif what == "resist":
            law.resisted(self.world, self.state, key, town, self.bus)
            rows = law.guards_for(self.world, town, 2)
            if rows:
                self._encounter({"rows": rows, "text": "You resist arrest. The watch draws steel!",
                                 "environment": "urban"})

    def _open_cure(self, npc) -> None:
        from game import survival as SV

        def build(p: Panel) -> None:
            p.text("The priest looks you over. \"Diseases I can lift for a modest offering; curses cost more, and some "
                   "cost a great deal.\"", "small")
            rows = SV.priest_offer(self.state, self.members)
            if not rows:
                p.text("Nobody here needs the temple's help.")
            for m, a, gp in rows:
                def go(p, m=m, a=a):
                    _ok, msg = SV.priest_cure(self.world, self.state, m, a["name"], self.bus)
                    p.message = msg
                p.option(f"{m.get('name')}: {a['name']} ({a['kind']})", go, f"{gp} gp")
        self._panel(Panel(f"{npc.name}'s healing", build, npc.name, "", _face(self.world, self.state, npc)))

    def _do_crime(self, kind: str, target: str = "") -> None:
        """Steal, pick a pocket, or rob a bank (game/law.py). A robbery that's seen brings the guards."""
        from game import bank, law
        if kind == "rob":
            spot = places.current(self.world, self.state)
            b = self.world.entities.get(target) if target else (spot.building if spot.kind == "building" else None)
            if b is None or not bank.is_bank(b):
                return
            r = bank.rob(self.world, self.state, self.members, b, self.rng, self.ex, self.bus)
            self.say("loot" if r.get("ok") else "damage", r["text"])
            if r.get("alarm"):
                rows = [{"id": x, "count": 1} for x in b.fields.get("npcs") or []
                        if not self.state.npc_dead(x) and
                        (self.world.entities.get(x).fields.get("occupation") or "") == "Guard"] or \
                    law.guards_for(self.world, spot.town, 2)
                if rows:
                    self._encounter({"rows": rows, "text": "Guards! The vault guard comes for you.",
                                     "environment": "interior"})
            return
        npc = self.world.entities.get(target)
        if npc is None:
            return
        fn = law.pickpocket if kind == "pickpocket" else law.steal
        r = fn(self.world, self.state, self.members, npc, self.rng, self.ex, self.bus)
        self.say("loot" if r.get("ok") else "damage", r["text"])


__all__ = ["Talking"]
