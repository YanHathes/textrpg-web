"""The browser version, stage 2: what the other tabs show and do (Bag, Party, Quests, Map, Settings), as plain
JSON calls. web/bridge.py's Session takes these in (Tabs is one of its bases), so they share its world, party,
log and walking map.

    Bag       bag(member) -> money, each hero's things, the party pack;  bag_do(member, what, item, to)
    Party     party(member) -> the heroes, and one hero's sheet (game/sheet.py), skills and standing
    Quests    journal(); quest(id) -> one quest's page;  quest_do(id, what, arg);  pin_rumor(id);  notes(text)
    Map       place() -> where the party is, who's here, the ways out and what to do (game/places.describe);
              place_go(target) / place_do(target);  bigmap() -> what the world map shows, and
              bigmap_pic(name) -> one of its pictures (game/bigmap.py, kept in the world)
    Settings  saves() / save_as(name, slot) / load(slot) / delete_save(slot)

Every call that changes something gives back "view" too (the status line and what's new in the log), so the
page shows what happened at once.
"""
from __future__ import annotations

from web.scene import png64


def _rgb_png(w: int, h: int, rgb: bytes, level: int = 6) -> str:
    """Raw RGB bytes as a PNG (base64)."""
    import base64
    import struct
    import zlib
    row = w * 3
    raw = b"".join(b"\x00" + rgb[y * row:(y + 1) * row] for y in range(h))

    def chunk(tag: bytes, body: bytes) -> bytes:
        return struct.pack(">I", len(body)) + tag + body + struct.pack(">I", zlib.crc32(tag + body) & 0xFFFFFFFF)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, level)) + chunk(b"IEND", b""))
    return base64.b64encode(png).decode("ascii")


def _plain(x):
    """Anything game-shaped down to what JSON can carry (tuples to lists, entities to their ids)."""
    if isinstance(x, dict):
        return {str(k): _plain(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_plain(v) for v in x]
    if x is None or isinstance(x, (str, int, float, bool)):
        return x
    return getattr(x, "id", None) or str(x)


class Tabs:
    """Mixed into web.bridge.Session (it has world, state, members, ex, book, bus, rng, say, api_view...)."""

    # ==================================================================
    # Helpers
    # ==================================================================
    def _member(self, member_id: str = "") -> dict | None:
        live = [m for m in self.members if m.get("id") == member_id]
        return live[0] if live else (self.members[0] if self.members else None)

    def _changed(self, out: dict | None = None) -> dict:
        """After a change: the party saved, the figure redrawn if its gear changed, the view sent along."""
        from game import party as P
        P.save(self.world, self.members)
        self.state.save()
        try:
            self._party_sprite()
        except Exception:  # noqa: BLE001 - the old figure will do
            pass
        out = dict(out or {})
        out["view"] = self.api_view()
        return out

    def _name(self, item_id: str) -> str:
        e = self.world.entities.get(item_id)
        return e.name if e is not None else item_id

    # ==================================================================
    # Bag
    # ==================================================================
    def api_bag(self, member: str = "") -> dict:
        from game import character as CH
        from game import condition
        from game import inventory as INV
        m = self._member(member)
        if m is None:
            return {"money": self.state.money_text(), "members": [], "who": "", "carried": [], "pack": []}
        c = condition.combatant(self.world, m)
        eq = m.get("equipment") or {}
        attuned = m.get("attuned") or []
        carried = []
        for item_id, n in sorted((m.get("inventory") or {}).items(), key=lambda kv: self._name(kv[0])):
            item = self.world.entities.get(item_id)
            if item is None or not n:
                continue
            worn = [s for s, i in eq.items() if i == item_id]
            needs = bool(item.fields.get("requires_attunement"))
            carried.append({"id": item_id, "name": item.name, "n": n, "worn": worn,
                            "attune": ("attuned" if item_id in attuned else "needs attunement") if needs else "",
                            "can_wear": bool(INV.slots_for(item)), "desc": item.description or "",
                            "kind": item.fields.get("kind") or item.fields.get("category") or ""})
        pack = []
        for item_id, n in sorted(self.state.inventory.items(), key=lambda kv: self._name(kv[0])):
            item = self.world.entities.get(item_id)
            if item is not None and n:
                pack.append({"id": item_id, "name": item.name, "n": n, "desc": item.description or ""})
        worn = [f"{s}: {self._name(i)}" for s, i in eq.items() if self.world.entities.get(i)]
        notes = [f"Carrying {INV.weight(self.world, m):g} lb"]
        if getattr(c, "encumbrance", ""):
            notes.append(c.encumbrance)
        if getattr(c, "armor_untrained", False):
            notes.append("not trained in this armor: disadvantage on attacks, no spells")
        lvl = CH.total_level(self.world, m)
        return {"money": self.state.money_text(), "who": m.get("id"), "name": m.get("name") or "Hero",
                "level": lvl, "members": [{"id": x.get("id"), "name": x.get("name") or "Hero",
                                           "dead": bool(x.get("dead"))} for x in self.members],
                "carried": carried, "pack": pack, "wearing": worn,
                "attuned": f"{len([i for i in attuned if self.world.entities.get(i)])} of {getattr(c, 'attune_max', 3)}",
                "notes": "  ·  ".join(notes), "mount": self._mount_row()}

    def _mount_row(self) -> dict | None:
        ex = self.ex
        if ex is None or ex.area is None:
            return None
        if ex.mounted():
            ok = ex.travelling() != "voyage"
            return {"what": "unmount", "label": "Unmount", "enabled": ok,
                    "tip": "Get down: what you ride waits on this square." if ok else
                    "You can't get off until you reach land."}
        if ex.can_remount():
            pk = ex.parked_here() or {}
            what = {"cart": "the cart", "wagon": "the wagon", "horse": "your horses"}.get(pk.get("kind"), "your mount")
            return {"what": "mount", "label": "Mount", "enabled": True, "tip": f"Climb back onto {what}"}
        return None

    def api_bag_do(self, member: str = "", what: str = "", item: str = "", to: str = "") -> dict:
        """equip, unequip, attune, use, to_pack, take, take_all, use_pack, give (to: another hero),
        unmount, mount."""
        from game import inventory as INV
        m = self._member(member)
        if m is None:
            return self._changed({"message": "", "bag": self.api_bag()})
        name = m.get("name") or "Hero"
        text = ""
        if what == "equip":
            obj = self.world.entities.get(item)
            slots = INV.slots_for(obj) if obj is not None else []
            if not slots:
                text = "That isn't something to wear or wield."
            else:
                eq = m.get("equipment") or {}
                slot = next((s for s in slots if s not in eq), slots[0])
                _ok, text = INV.equip(self.world, m, item, slot)
        elif what == "unequip":
            for s, i in list((m.get("equipment") or {}).items()):
                if i == item:
                    INV.unequip(m, s)
            text = "Taken off."
        elif what == "attune":
            _ok, text = INV.attune(self.world, m, item, item not in (m.get("attuned") or []))
        elif what == "use":
            text = INV.use_outside_combat(self.world, self.state, m, item, self.rng, self.bus) or "Nothing happens."
        elif what == "to_pack":
            text = "Put in the pack." if INV.to_pack(self.state, m, item, 1) else "Take it off first."
        elif what in ("take", "take_all"):
            n = INV.from_pack(self.state, m, item, self.state.count(item) if what == "take_all" else 1)
            text = (f"{name} takes {self._name(item)}" + (f" x{n}" if n > 1 else "") + " from the pack.") if n \
                else "There's none of that left in the pack."
        elif what == "use_pack":
            if not INV.from_pack(self.state, m, item, 1):
                text = "There's none of that left in the pack."
            else:
                before = INV.count(m, item)
                text = INV.use_outside_combat(self.world, self.state, m, item, self.rng, self.bus) or "Nothing happens."
                if INV.count(m, item) >= before:                  # not used up: back in the pack
                    INV.to_pack(self.state, m, item, 1)
        elif what == "give":
            other = next((o for o in self.members if o.get("id") == to and o is not m), None)
            if other is None:
                text = "Give it to whom?"
            else:
                text = f"Given to {other.get('name')}." if INV.give(m, other, item, 1) else "Take it off first."
        elif what in ("unmount", "mount") and self.ex is not None:
            ok, text = self.ex.dismount() if what == "unmount" else self.ex.remount()
            if ok:
                self.say("narration", text)
        else:
            text = "?"
        return self._changed({"message": text, "bag": self.api_bag(m.get("id"))})

    # ==================================================================
    # Party
    # ==================================================================
    def _face(self, m: dict) -> str:
        """The key of a hero's figure for the sprites call (drawn as they look now)."""
        from game.art.doll import Gear
        from game.art.library import render_look
        race = self.world.entities.get(m.get("race") or "")
        look = dict((race.fields.get("appearance") or {}) if race else {})
        look.update({k: v for k, v in (m.get("look") or {}).items() if v})
        look.setdefault("base", "human")
        gear = Gear()
        for slot, item_id in (m.get("equipment") or {}).items():
            item = self.world.entities.get(item_id)
            if item:
                self.world.sprites.apply_item(gear, item, slot)
        sig = abs(hash((m.get("id"), tuple(sorted(look.items(), key=str)),
                        tuple(sorted((m.get("equipment") or {}).items())))))
        key = f"hero:{m.get('id')}:{sig}"
        if key not in self.scene.sources:
            self.scene.set_source(key, render_look(look, gear, 1))
        return key

    def api_party(self, member: str = "") -> dict:
        from game import character as CH
        from game import checks, condition
        from game.sheet import sheet_for
        m = self._member(member)
        rows = []
        for x in self.members:
            try:
                face = self._face(x)
            except Exception:  # noqa: BLE001 - a plain token instead
                face = ""
            classes = " / ".join(f"{k.name} {lv}" for k, lv, _s in CH.classes_of(self.world, x))
            rows.append({"id": x.get("id"), "name": x.get("name") or "Hero", "face": face, "dead": bool(x.get("dead")),
                         "line": "  ·  ".join(b for b in (f"Level {CH.total_level(self.world, x)}", classes) if b),
                         "level_up": bool(CH.can_level_up(self.world, x)) and not x.get("dead")})
        if m is None:
            return {"members": rows, "who": "", "sheet": None, "can_add": True}
        c = condition.combatant(self.world, m)
        condition.apply(self.state, m, c)
        sheet = sheet_for(self.world, c, m, self.state)
        sheet["sections"] = [s for s in sheet["sections"] if s["title"] != "Party pack"]   # (that's the Bag)
        skills = []
        for o in checks.options(self.world):
            if o.get("kind") == "Ability":
                continue
            try:
                b, prof = checks.bonus(self.world, m, c, o)
            except Exception:  # noqa: BLE001 - a skill that can't be worked out is left off
                continue
            if o.get("kind") == "Tool" and not prof:
                continue                                  # (only the tools they know)
            skills.append({"label": o["label"], "bonus": f"{b:+d}", "short": o.get("short") or "", "prof": bool(prof)})
        lvl = CH.total_level(self.world, m)
        xp = (f"XP {m.get('xp', 0)}" + (f"  (next level at {CH.XP_TABLE[lvl]})" if lvl < 20 else "")
              if (self.world.rules.get("levelling") or "XP") == "XP" else "Milestone levelling")
        from game.party import MAX_MEMBERS
        casts = any(k.fields.get("spellcasting") for k, _lv, _s in CH.classes_of(self.world, m)) or bool(c.spells)
        return {"members": rows, "who": m.get("id"), "sheet": _plain(sheet), "skills": skills, "xp": xp,
                "standing": self._standing(), "level_up": bool(CH.can_level_up(self.world, m)) and not m.get("dead"),
                "dead": bool(m.get("dead")), "has_choices": bool(CH.choices_for(self.world, m)),
                "pending_choices": len(CH.pending_choices(self.world, m)), "casts": casts,
                "can_add": len(self.members) < MAX_MEMBERS}

    def _standing(self) -> list[dict]:
        from game import factions as F
        out = []
        try:
            met = F.met(self.world, self.state)
        except Exception:  # noqa: BLE001 - no factions: nothing to show
            return out
        for f in met:
            score = F.standing(self.world, self.state, f.id)
            out.append({"name": f.name, "kind": f.fields.get("kind") or "Other", "score": score,
                        "words": F.level_name(score)})
        return out

    # ==================================================================
    # Quests
    # ==================================================================
    def api_journal(self) -> dict:
        try:
            j = self.book.journal()
        except Exception:  # noqa: BLE001 - the plain list, if the journal can't be put together
            j = {"chains": [], "active": [self.book.display(q) for q in self.book.active()],
                 "finished": [self.book.display(q) for q in self.book.finished()], "lore": [], "rumors": [],
                 "notes": ""}
        return _plain(j)

    def api_quest(self, id: str = "", pin: bool = True) -> dict:
        """One quest's page (opening a live one pins it, as in the app)."""
        from game import places
        q = self.book.get(id)
        if q is None:
            return {"quest": None}
        live = q["status"] in ("active", "ready")
        if pin and live and (self.book.pinned() or {}).get("id") != id:
            self.book.track(id)
        here = places.current(self.world, self.state).id
        objs = []
        for i, o in enumerate(q["objectives"]):
            done = bool(o.get("done"))
            dest, acts = self._objective_dest(o), []
            if live and not done:
                hunt = o.get("hunt")
                if dest and places.parse(self.world, dest).id != here:
                    if places.route(self.world, here, dest):
                        acts.append({"label": "Go there", "what": "route", "arg": dest})
                elif dest and hunt:
                    acts.append({"label": "Explore", "what": "explore", "arg": ""})
                if o.get("kind") == "Custom":
                    acts.append({"label": "Mark done", "what": "mark", "arg": i})
            way = ""
            if live and not done and dest:
                if places.parse(self.world, dest).id == here:
                    way = "you're there" + (" (explore to find them)" if o.get("hunt") else "")
                else:
                    way = places.route_text(self.world, here, dest) or "no known way there"
            objs.append({"text": o["text"] + (f"  ({o.get('progress', 0)}/{o['count']})" if o["count"] > 1 else ""),
                         "done": done, "hint": o.get("hint") or "" if not done else "", "way": way, "actions": acts})
        hand_in = None
        if q["status"] == "ready":
            giver = self.world.entities.get(q.get("giver"))
            where = places.parse(self.world, places.where_is(self.world, giver)) if giver else None
            where = where if where is not None and where.kind != "nowhere" else None
            hand_in = {"text": f"Return to {q.get('giver_name')}" + (f" at {where.name}" if where else "")
                       + " and talk to them to hand it in.",
                       "go": where.id if where is not None and where.id != here else ""}
        status = {"active": "In progress", "ready": "Ready to hand in", "completed": "Completed",
                  "abandoned": "Abandoned"}.get(q["status"], q["status"])
        meta = "   ·   ".join(x for x in (q.get("kind"), q.get("giver_name") and f"from {q['giver_name']}", status,
                                          q.get("accepted_day") and f"taken on day {q['accepted_day']}") if x)
        pinned = self.book.pinned()
        return {"quest": _plain({"id": q["id"], "title": q["title"], "meta": meta, "pitch": q.get("pitch") or "",
                                 "objectives": objs, "hand_in": hand_in, "reward": self.book.reward_text(q),
                                 "journal": list(q.get("journal") or [])[-6:], "live": live,
                                 "tracked": bool(pinned is not None and pinned.get("id") == q["id"])}),
                "journal": self.api_journal()}

    def _objective_dest(self, o: dict) -> str:
        from game import places
        hunt = o.get("hunt")
        if hunt and hunt.get("town") and hunt.get("direction"):
            return places.wild_id(hunt["town"], hunt["direction"])
        if o.get("kind") in ("Visit", "Talk"):
            return places.location_of(self.world, o.get("target") or "")
        return ""

    def api_quest_do(self, id: str = "", what: str = "", arg=None) -> dict:
        """track, abandon, route (arg: where), explore, mark (arg: the objective)."""
        if what == "track":
            self.book.track(id)
        elif what == "abandon":
            self.book.abandon(id)
        elif what == "route":
            self.follow_route(str(arg or ""))
        elif what == "explore":
            self._activity("explore")
        elif what == "mark":
            self.book.mark_done(id, int(arg or 0))
        out = self.api_quest(id, pin=False) if what != "abandon" else {"quest": None, "journal": self.api_journal()}
        return self._changed(out)

    def api_pin_rumor(self, id: str = "") -> dict:
        pinned = (self.state.pin or {}).get("rumor") == id
        self.book.pin_rumor("" if pinned else id)
        self.state.save()
        return {"journal": self.api_journal()}

    def api_notes(self, text: str = "") -> dict:
        from game import books
        books.lore(self.state)["notes"] = str(text)[:20000]
        self.state.save()
        self._keep_play()
        return {"saved": True}

    # ==================================================================
    # Map: where the party is
    # ==================================================================
    def api_route(self, goal: str = "") -> dict:
        """Head for a place (a quest's objective, a town picked on the world map), the quickest way."""
        self.follow_route(goal)
        return self._changed(self.api_place())

    def api_place(self) -> dict:
        from game import places
        d = places.describe(self.world, self.state)
        d.pop("scene", None)
        return {"place": _plain(d), "pin": self._pin_text()}

    def _pin_text(self) -> dict | None:
        try:
            p = self.book.pin_target()
        except Exception:  # noqa: BLE001 - no pin to show
            return None
        if not p:
            return None
        return {"title": p.get("title") or "", "text": p.get("text") or "", "quest": p.get("quest") or "",
                "pos": list(p["pos"]) if p.get("pos") else None}

    def api_place_go(self, target: str = "") -> dict:
        """Take one of the ways out (a door, a street, the wilds)."""
        if target:
            self._map_action(("go", target))
        out = self.api_place()
        out["view"] = self.api_view()
        return out

    def api_place_do(self, target: str = "") -> dict:
        """One of the things to do here (rest, explore, search...)."""
        if target:
            self._activity(target)
            self.ex.sync()
        out = self._changed(self.api_place())
        return out

    # ==================================================================
    # Map: the world map (game/bigmap.py)
    # ==================================================================
    def api_bigmap(self) -> dict:
        """What the world map shows over its pictures: where everything is (in miles), what the party knows,
        the fog, the party and the pin."""
        from game import bigmap
        from game import geography as G
        from game import mapimage as MI
        world, state = self.world, self.state
        bm = bigmap.open_map(world)
        try:
            bm.refresh()                              # new settlements since last time: just their patch
        except Exception:  # noqa: BLE001 - the pictures as they are
            pass
        grid = G.terrain(world)
        pics = {name: {"bounds": list(b), "w": w, "h": h, "stride": stride, "continent": cont,
                       "done": bm.pic(name).done if name == "world" else None}
                for name, (b, w, h, stride, cont) in bm.infos().items()}
        visited = set(state.visited)
        towns = []
        for tid, (x, y) in G.town_positions(world).items():
            t = world.entities.get(tid)
            if t is None or not G.town_known(world, state, t):
                continue
            towns.append({"id": tid, "name": t.name, "kind": G.settlement_kind(t), "x": x, "y": y,
                          "visited": tid in visited, "people": t.fields.get("population") or ""})
        marks = []
        for lm in world.entities.all("landmark"):
            p = G.landmark_position(world, lm)
            if p is None:
                continue
            if lm.id in state.discovered or (not lm.fields.get("hidden", True) and G.seen(world, state, *p)):
                marks.append({"id": lm.id, "name": lm.name, "kind": "landmark", "x": p[0], "y": p[1],
                              "what": (lm.fields.get("kind") or "landmark")})
        for d in world.entities.all("dungeon"):
            if world.entities.by_field("landmark", "dungeon", d.id):
                continue
            p = G.dungeon_position(world, d)
            if p is not None and (d.id in state.discovered or not d.fields.get("hidden", True)):
                marks.append({"id": d.id, "name": d.name, "kind": "dungeon", "x": p[0], "y": p[1],
                              "what": d.fields.get("kind") or "dungeon"})
        conts = [{"name": c.name, "x": ctr[0], "y": ctr[1]} for c in world.entities.all("continent")
                 for ctr in [G._pt(c.fields.get("center"))] if ctr is not None]
        regions = []
        for r in world.entities.all("region"):
            ctr = G._pt(r.fields.get("center"))
            if ctr is None:
                continue
            b = G.region_bounds(world, r)
            known = b is not None and (G.seen(world, state, (b[0] + b[2]) / 2, (b[1] + b[3]) / 2) or any(
                G.region_of_town(world, world.entities.get(t)) is r for t in visited if world.entities.get(t)))
            if known:
                regions.append({"name": r.name, "x": ctr[0], "y": ctr[1]})
        fog = None
        cells = G.seen_cells(world, state)
        if cells is not None:
            key = (id(grid), state.fog)
            cached = getattr(world, "_web_fog", None)
            if cached is None or cached[0] != key:
                from web.scene import png_rgba
                cached = (key, png_rgba(grid.cols, grid.rows, MI.fog_rgba(world, cells), level=6))
                world._web_fog = cached
            fog = {"png": cached[1], "w": grid.cols * grid.cell, "h": grid.rows * grid.cell}
        here = G.party_position(world, state)
        try:
            from game import hexes as HX
            hex_miles = HX.hex_miles(world)
        except Exception:  # noqa: BLE001 - no hexes in this world
            hex_miles = 0
        return _plain({"width": grid.width, "height": grid.height, "pics": pics, "towns": towns, "marks": marks,
                       "continents": conts, "regions": regions, "fog": fog, "party": list(here) if here else None,
                       "pin": self._pin_text(), "hex_miles": hex_miles})

    def api_bigmap_pic(self, name: str = "world", work: float = 1.5) -> dict:
        """One of the big map's pictures as a PNG; one never drawn yet is drawn for a while first (the page
        asks again while "done" is false)."""
        from game import bigmap
        bm = bigmap.open_map(self.world)
        pic = bm.pic(name)
        if pic is None:
            return {"name": name, "png": "", "done": True}
        if not pic.done and work > 0:
            bm.work(float(work), [name])
            bm.save()
        cache = getattr(self.world, "_web_pics", None)
        if cache is None:
            cache = self.world._web_pics = {}
        sig = (len(pic.jobs), sum(j[4] for j in pic.jobs))
        got = cache.get(name)
        if got is None or got[0] != sig or not pic.done:
            got = (sig, _rgb_png(pic.w, pic.h, bytes(pic.rgb), level=6))
            cache[name] = got
        return {"name": name, "png": got[1], "w": pic.w, "h": pic.h, "bounds": list(pic.bounds),
                "done": pic.done, "fraction": round(pic.fraction(), 3)}

    def api_bigmap_at(self, x: float = 0.0, y: float = 0.0) -> dict:
        """What's at a point of the world map (miles): for the line under it when it's tapped."""
        from game import geography as G
        if not G.seen(self.world, self.state, x, y):
            c = G.continent_at(self.world, x, y)
            return {"text": f"Uncharted ({c.name})" if c is not None else "Unexplored"}
        reg = G.region_at(self.world, x, y)
        land = G.continent_at(self.world, x, y) is not None and G.biome_at(self.world, x, y) not in ("Ocean", "Lake")
        return {"text": f"{G.biome_at(self.world, x, y)}" + (f", {reg.name}" if reg is not None else ""), "trek": bool(land)}

    def api_bigmap_town(self, id: str = "") -> dict:
        """A town tapped on the world map: what it is, and the way there."""
        from game import geography as G
        from game import places
        t = self.world.entities.get(id)
        if t is None:
            return {"text": ""}
        lines = [t.name, f"{G.settlement_kind(t)}  ·  population {t.fields.get('population') or '?'}"]
        here = places.current(self.world, self.state)
        go = ""
        if here.town is not None and here.town.id == t.id:
            lines.append("You're here.")
        else:
            try:
                goal = places.town_gate(self.world, t)
                way = places.route_text(self.world, here.id, goal)
                if way:
                    lines.append("Way: " + way)
                    go = goal
            except Exception:  # noqa: BLE001 - no known way
                pass
        return {"text": "\n".join(lines), "go": go}

    # ==================================================================
    # Settings: saves
    # ==================================================================
    def api_saves(self) -> dict:
        from game import saves
        hard = saves.hardcore(self.world)
        rows = [] if hard else [{"slot": s["slot"], "name": s.get("name") or s["slot"], "saved": s.get("saved", ""),
                                 "where": s.get("where", ""), "clock": s.get("clock", ""), "party": s.get("party", ""),
                                 "auto": s["slot"] == getattr(saves, "AUTOSAVE", "autosave")}
                                for s in saves.list_saves(self.world)]
        from game import places
        return {"hardcore": hard, "saves": rows,
                "suggest": f"Day {self.state.day} - {places.current(self.world, self.state).name}"}

    def api_save_as(self, name: str = "", slot: str = "") -> dict:
        from game import party as P
        from game import saves
        if saves.hardcore(self.world):
            return {"saved": False, "message": "This world plays Hardcore: there are no manual saves."}
        name = (name or "").strip()[:60] or self.api_saves()["suggest"]
        P.save(self.world, self.members)
        self.ex.save()
        saves.save(self.world, self.state, self.members, name, slot or None)
        self.say("system", f"Game saved: {name}.")
        self._keep_play()
        out = self.api_saves()
        out.update({"saved": True, "view": self.api_view()})
        return out

    def api_load(self, slot: str = "") -> dict:
        from game import saves
        if saves.hardcore(self.world):
            return {"loaded": False, "message": "This world plays Hardcore: there are no saves to load."}
        if not slot or not saves.load(self.world, slot):
            return {"loaded": False, "message": "That save couldn't be loaded."}
        self._keep_play()                         # the loaded files become what the browser keeps
        self.menu, self.menu_kind, self.prompt = None, "", None
        self.api_start("continue")
        self.say("system", "Game loaded.")
        v = self.api_view()
        v["loaded"] = True
        return v

    def api_delete_save(self, slot: str = "") -> dict:
        from game import saves
        if slot and slot != getattr(saves, "AUTOSAVE", "autosave"):
            saves.delete(self.world, slot)
            self._keep_play()
        return self.api_saves()


__all__ = ["Tabs", "png64"]
