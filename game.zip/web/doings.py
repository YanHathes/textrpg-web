"""The browser version, stage 3: more of the app's windows, on panels (web/panel.py): crafting at a station
(ui/craft_dialog.py), books (reading one, a library's shelves, a college's courses: ui/books_dialog.py),
animals and vehicles (ui/animals_dialog.py), land and homes (ui/estate_dialog.py), and gathering.
"""
from __future__ import annotations

from game.state import money_text
from web.panel import Panel


class Doings:
    """Mixed into web.bridge.Session."""

    # ==================================================================
    # Crafting
    # ==================================================================
    def _open_craft(self, station: str, where: str = "", bid: str = "") -> None:
        from game import crafting
        if not station:
            return
        b = self.world.entities.get(bid) if bid else None
        owned = b is not None and bool(b.fields.get("owner"))
        where = where or self.state.location
        info = crafting.station_info(self.world, station)
        cs = {"station": station, "where": where, "owned": owned, "tab": "jobs" if crafting.ready_jobs(self.state, where)
              else "make", "sel": ""}
        self._panel(Panel(info["label"], lambda p: self._craft_build(p, cs)))

    def _craft_build(self, p: Panel, cs: dict) -> None:
        tabs = [("make", "Make"), ("jobs", "Jobs"), ("mend", "Mend and salvage")]
        p.buttons(*[(lab + (" ✓" if cs["tab"] == k else ""), (lambda p, k=k: cs.update(tab=k, sel="")),
                     "primary" if cs["tab"] == k else "ghost") for k, lab in tabs])
        getattr(self, "_craft_" + cs["tab"])(p, cs)

    def _craft_make(self, p: Panel, cs: dict) -> None:
        from game import crafting
        from game import tools as T
        w, s = self.world, self.state
        pool = crafting.pool_of(w, s, self.members)
        rs = crafting.recipes(w)
        known = crafting.known(w, s, cs["station"])
        if cs["sel"]:
            r = crafting.recipe_for(w, cs["sel"])
            e = w.entities.get(cs["sel"])
            live = [m for m in self.members if not m.get("dead")]
            p.select("who", "Who", [(m["id"], m.get("name") or "?") for m in live])
            p.number("batches", "Batches", 1, 1, 99)
            p.number("skilled", "Hire skilled", 0, 0, 10)
            p.number("untrained", "Hire untrained", 0, 0, 10)
            n = int(p.values.get("batches") or 1)
            makes = int(r.get("makes") or 1) * n
            p.head((e.name if e else cs["sel"]) + (f" x{makes}" if makes > 1 else ""))
            for ref, k in r["materials"]:
                have = sum(v for kk, v in pool.items() if crafting._matches(w, ref, kk))
                need = int(k) * n
                p.text(f"{'✓' if have >= need else '✗'} {crafting.ref_name(w, ref)}: {have}/{need}")
            helpers = {"skilled": int(p.values.get("skilled") or 0), "untrained": int(p.values.get("untrained") or 0)}
            days = crafting.days_for(w, r, n, helpers)
            tool = (r.get("tools") or [""])[0]
            m = next((x for x in live if x["id"] == p.values.get("who")), None)
            lvl = T.level(w, m, crafting._tool_key(w, {"tools": r.get("tools") or []}))[0] if m is not None else ""
            p.text(f"About {crafting._days_text(days)} of work" + (f" with {tool} ({lvl.lower() or 'untrained'})" if tool else "")
                   + f". Check DC {r.get('dc')} at the end sets the quality."
                   + (" Skilled helpers give the final check advantage." if helpers["skilled"] else ""), "small")
            per_day = crafting.rent(w, cs["station"], cs["owned"]) + crafting.wages(w, helpers)
            whole = max(1, int(-(-days // 1)))
            cost = int(round(per_day * whole * 100)) if days >= 1 else int(round(per_day * 100))
            p.text(f"Station and helpers: {money_text(int(per_day * 100))} a day; {money_text(cost)} paid now. You have "
                   f"{money_text(s.copper)}." if per_day else "Nothing to pay.", "gold")
            ok = crafting.can_make(w, r, dict(pool), n, 0) and cost <= s.copper

            def start(p):
                good, text, job = crafting.start(w, s, self.members, cs["sel"], cs["station"], cs["where"],
                                                 p.values.get("who") or "", int(p.values.get("batches") or 1),
                                                 {"skilled": int(p.values.get("skilled") or 0),
                                                  "untrained": int(p.values.get("untrained") or 0)},
                                                 owned=cs["owned"], bus=self.bus)
                p.message = text
                if good:
                    self.say("narration", text)
                    if job is not None and crafting.time_left(w, job, s.minutes) <= 8 * 60:
                        self._craft_wait(p, job)          # a short piece of work: done while you watch
                    cs.update(tab="jobs", sel="")
            p.buttons(("Back", lambda p: cs.update(sel=""), "ghost"), ("Start work", start if ok else None, "primary"))
            return
        here = [i for i, r in rs.items() if cs["station"] in r["stations"]]
        hidden = len(here) - len(known)
        p.text(f"{len(known)} recipe{'s' if len(known) != 1 else ''} known here" +
               (f"; {hidden} more to discover (you learn one when you have everything it needs)." if hidden > 0 else "."),
               "small")
        rows = []
        for iid in known:
            ok = crafting.can_make(w, rs[iid], dict(pool), 1, 0, rs)
            e = w.entities.get(iid)
            rows.append((not ok, e.name if e else iid, iid, ok))
        for _bad, name, iid, ok in sorted(rows):
            p.option(name, lambda p, i=iid: (cs.update(sel=i), p.values.clear()), "" if ok else "missing things",
                     style="" if ok else "ghost")

    def _craft_wait(self, p: Panel, job: dict) -> None:
        from game import crafting
        minutes = crafting.time_left(self.world, job, self.state.minutes)
        if job.get("paid_until") is not None:
            minutes = min(minutes, max(0, int(job["paid_until"]) - self.state.minutes))
        self._fx("timeskip", 0.8)
        self.state.advance(max(1, minutes), "crafting")
        if job.get("status") == "ready":
            _ok, text, _made = crafting.collect(self.world, self.state, self.members, job, self.rng, self.bus)
            p.message = text

    def _craft_jobs(self, p: Panel, cs: dict) -> None:
        from game import crafting
        jobs = crafting.jobs_at(self.state, cs["where"])
        if not jobs:
            p.text("No work going on here.", "small")
        now = self.state.minutes
        for job in jobs:
            count = int(job.get("batches") or 1) * int(job.get("makes") or 1)
            p.head(job["name"] + (f" x{count}" if count > 1 else "") +
                   f"  ·  {int(crafting.progress(self.world, job, now) * 100)}%")
            if job.get("status") == "ready":
                p.text("Finished: collect it to see how it turned out.", "gold")

                def collect(p, j=job):
                    _ok, text, _m = crafting.collect(self.world, self.state, self.members, j, self.rng, self.bus)
                    p.message = text
                p.buttons(("Collect", collect, "primary"))
                continue
            left = crafting.time_left(self.world, job, now)
            paid = job.get("paid_until")
            note = f"About {crafting._days_text(left / 1440)} of work left."
            if paid is not None:
                note += (" Paid for until day " + str(int(paid) // 1440 + 1) + ".") if paid > now else \
                    " Stopped: the station isn't paid for."
            p.text(note, "small")
            pairs = [("Wait for it", lambda p, j=job: self._craft_wait(p, j), "primary")]
            if paid is not None:
                pairs.append(("Pay 7 more days", lambda p, j=job: setattr(p, "message", crafting.pay_more(
                    self.world, self.state, j, 7)[1]), ""))
            pairs.append(("Stop", lambda p, j=job: setattr(p, "message", crafting.cancel(self.world, self.state, j)), "ghost"))
            p.buttons(*pairs)

    def _craft_mend(self, p: Panel, cs: dict) -> None:
        from game import crafting
        from game import quality as Q
        w = self.world
        rs = crafting.recipes(w)
        mend, salvage = [], []
        for iid, n in sorted(self.state.inventory.items()):
            if n <= 0:
                continue
            base, _q, damaged = Q.parse(iid)
            r = rs.get(base)
            if r is None or cs["station"] not in r["stations"]:
                continue
            e = w.entities.get(iid)
            name = e.name if e else iid
            if damaged:
                rr = crafting.restore_recipe(w, iid)
                mend.append((iid, name, ", ".join(f"{crafting.ref_name(w, ref)} x{k}" for ref, k in (rr or {}).get("materials", []))))
            got = crafting.salvage_yield(w, iid)
            if got:
                salvage.append((iid, f"{name} (x{n})", ", ".join(f"{crafting.ref_name(w, ref)} x{k}" for ref, k in got)))
        p.head("Damaged gear to mend")
        if not mend:
            p.text("Nothing to mend here.", "small")
        for iid, name, need in mend:
            p.option(f"Mend {name}", lambda p, i=iid: setattr(p, "message", crafting.restore(
                self.world, self.state, self.members, i, self.bus)[1]), need)
        p.head("Break down for materials")
        if not salvage:
            p.text("Nothing to break down here.", "small")
        for iid, name, got in salvage:
            p.option(f"Break down {name}", lambda p, i=iid: setattr(p, "message", crafting.salvage(
                self.world, self.state, i, 1, self.bus)[1]), "→ " + got)

    # ==================================================================
    # Books
    # ==================================================================
    def _read_book(self, book_id: str, back=None) -> None:
        from game import books
        item = self.world.entities.get(book_id)
        rd = {"at": 0, "pages": books.pages(item) if item else ["(Nothing.)"], "said": ""}

        def build(p: Panel) -> None:
            done = books.has_read(self.state, book_id)
            p.text((books.kind_of(item) if item else "") + ("  ·  read" if done else ""), "small")
            p.text(rd["pages"][rd["at"]] if rd["pages"] else "")
            p.buttons(("‹ Back", (lambda p: rd.update(at=rd["at"] - 1)) if rd["at"] > 0 else None, "ghost"),
                      (f"{rd['at'] + 1} / {len(rd['pages'])}", None, "ghost"),
                      ("Next ›", (lambda p: rd.update(at=rd["at"] + 1)) if rd["at"] < len(rd["pages"]) - 1 else None, "ghost"))
            mins = books.read_minutes(item) if item else 0

            def read(p):
                _m, lines = books.read(self.world, self.state, book_id, self.bus)
                p.message = (" ".join(lines[1:]) or lines[0]) if lines else ""
            length = f"{mins} min" if mins < 90 else f"{mins / 60:.0f} hours"
            p.option(("Read it again" if done else "Read it through") + f" ({length})", read, style="primary")
        self._panel(Panel(item.name if item else "A book", build, close="Close",
                          on_close=(lambda p: back()) if back is not None else None))

    def _open_bookshelf(self, building, one=None) -> None:
        from game import books
        if building is None:
            return
        kind = books.library_kind(self.world, building)

        def build(p: Panel) -> None:
            if one is not None:
                what, _held = books.on_shelf(self.world, building, one[0], one[1])
                p.text(f"A bookshelf: {what}", "gold")
            p.text("Read anything here for nothing, or borrow it for a deposit you get back when you return it.", "small")
            held = books.on_shelf(self.world, building, *one)[1] if one is not None else books.shelf(self.world, building)
            for b in held:
                p.head(("✓ " if books.has_read(self.state, b.id) else "") + b.name)
                p.text(books.kind_of(b), "small")
                p.buttons(("Read here", lambda p, i=b.id: self._read_book(i, lambda: self._open_bookshelf(building, one)),
                           "primary"),
                          ("Borrow", lambda p, i=b.id: setattr(p, "message", books.borrow(self.world, self.state, i)[1]), ""))

            def give_back(p):
                said = []
                for bid in list(books.lore(self.state)["loans"]):
                    ok, text = books.give_back(self.world, self.state, bid)
                    if ok:
                        said.append(text)
                p.message = " ".join(said) or "You haven't borrowed anything."
            p.option("Give back what we borrowed", give_back, style="ghost")
        self._panel(Panel(building.name + (" (archives)" if kind == "archives" else ""), build))

    def _open_college(self, npc) -> None:
        from game import books

        def build(p: Panel) -> None:
            live = [m for m in self.members if not m.get("dead")]
            p.select("who", "Who studies", [(m["id"], m.get("name") or "?") for m in live])
            m = next((x for x in live if x["id"] == p.values.get("who")), None) or (live[0] if live else None)
            for c in books.courses(self.world, self.state, m, npc) if m is not None else []:
                length = f"{c['days']} days" if c.get("days") else f"{c.get('hours', 0)} hours"

                def take(p, c=c, m=m):
                    _ok, text = books.take_course(self.world, self.state, m, c, self.bus)
                    p.message = text
                p.option(c["label"], take if c["open"] else None, f"{c['gp']} gp, {length}" +
                         ("" if c["open"] else "  (advanced: not yet)"), enabled=c["open"])
        self._panel(Panel("Courses", build))

    # ==================================================================
    # Animals, carts and boats (ui/animals_dialog.py)
    # ==================================================================
    def _open_animals(self, building=None) -> None:
        from game import animals
        an = {"tab": "yours", "sel": "", "building": building, "offers": animals.shop(self.world, building)}
        self._panel(Panel(building.name if building is not None else "Animals and vehicles",
                          lambda p: self._animals_build(p, an)))

    def _animals_build(self, p: Panel, an: dict) -> None:
        from game import animals
        b = an["building"]
        p.sub = f"Purse: {money_text(self.state.copper)}"
        tabs = [("yours", "Yours"), ("storage", "Storage")]
        if an["offers"]:
            tabs.append(("buy", "Buy"))
        if b is not None and animals.is_dock(self.world, b):
            tabs.append(("sail", "Sail"))
        if any(v["kind"] in ("vehicle", "boat") for v in animals.owned(self.state)):
            tabs.append(("routes", "Routes"))
        p.buttons(*[(lab, (lambda p, k=k: an.update(tab=k, sel="")), "primary" if an["tab"] == k else "ghost")
                    for k, lab in tabs])
        getattr(self, "_animals_" + an["tab"])(p, an)

    def _animals_yours(self, p: Panel, an: dict) -> None:
        from game import animals
        from game.animalwords import animal_line
        owned = animals.owned(self.state)
        v = animals.get(self.state, an["sel"]) if an["sel"] else None
        if v is None:
            if not owned:
                p.text("You have no animals or vehicles yet.", "small")
            for x in owned:
                p.option(x["name"], lambda p, i=x["id"]: (an.update(sel=i), p.values.clear()),
                         animal_line(self.world, self.state, self.members, x))
            p.text("Everyone on a mount, or a cart or wagon with an animal hitched to pull it, makes road journeys and "
                   "treks faster. Stabling costs 5 sp a day an animal while you're in town.", "small")
            return
        p.head(v["name"])
        p.text(animal_line(self.world, self.state, self.members, v), "small")
        p.field("name", "Name", v["name"])
        p.buttons(("Rename", lambda p: setattr(p, "message", self._animal_rename(v, p.values.get("name") or "")), ""))
        if v["kind"] == "animal":
            e = self.world.entities.get(v.get("enemy") or "")
            roles = animals.roles_for(self.world, e) if e is not None else ["pet"]
            if animals.mount_stats(v["type"]):
                roles = list(dict.fromkeys(roles + ["mount", "pack"]))
            p.select("role", "Role", [(r, animals.ROLE_WORDS[r].capitalize()) for r in roles], v.get("role"))
            p.select("rider", "Rider", [("", "Nobody rides it")] + [(m["id"], m.get("name") or "?") for m in self.members
                                                                    if not m.get("dead")], v.get("rider") or "")
            p.select("hitch", "Pulls", [("", "Nothing")] + [(x["id"], x["name"]) for x in animals.owned(self.state)
                                                            if x["kind"] == "vehicle"], v.get("pulls") or "")
            p.buttons(("Set role", lambda p: setattr(p, "message", animals.set_role(self.world, self.state, v["id"],
                                                                                   p.values.get("role"))[1]), ""),
                      ("Rider", lambda p: setattr(p, "message", animals.assign_rider(self.world, self.state, v["id"],
                                                                                    p.values.get("rider") or "")[1]), ""),
                      ("Hitch", lambda p: setattr(p, "message", animals.hitch(self.world, self.state, v["id"],
                                                                             p.values.get("hitch") or "")[1]), ""))
        b = an["building"]
        can_sell = bool(an["offers"]) or (b is not None and animals.is_stable(b))
        p.buttons(("Back", lambda p: an.update(sel=""), "ghost"),
                  ("Sell", (lambda p: (setattr(p, "message", animals.sell(self.world, self.state, v["id"])[1]),
                                       an.update(sel=""))) if can_sell else None, ""),
                  ("Let it go", lambda p: (setattr(p, "message", animals.release(self.world, self.state, v["id"])),
                                           an.update(sel="")), "ghost"))

    def _animal_rename(self, v: dict, name: str) -> str:
        from game import animals
        if not name.strip():
            return "Give it a name first."
        animals.rename(self.world, self.state, v["id"], name)
        return f"It's {name.strip()} now."

    def _animals_storage(self, p: Panel, an: dict) -> None:
        from game import animals
        stores = animals.open_stores(self.world, self.state)
        if not stores:
            p.text("Nothing that carries things is here with you.", "small")
            return
        p.select("store", "Storage", [(v["id"], f"{v['name']} ({v['type']})") for v in stores])
        v = animals.get(self.state, p.values.get("store") or "")
        if v is None:
            return
        p.text(f"{animals.load(self.world, v):g} of {animals.capacity(self.world, v)} lb", "small")
        p.number("n", "How many", 1, 1, 9999)
        p.head("Carried")
        for iid, n in sorted((v.get("storage") or {}).items()):
            p.option(f"{self._name(iid)}  ×{n}", lambda p, i=iid: setattr(p, "message", animals.take(
                self.world, self.state, v["id"], i, int(p.values.get("n") or 1))[1]), "take to the pack")
        p.head("Party pack")
        for iid, n in sorted(self.state.inventory.items(), key=lambda kv: self._name(kv[0])):
            p.option(f"{self._name(iid)}  ×{n}", lambda p, i=iid: setattr(p, "message", animals.put(
                self.world, self.state, v["id"], i, int(p.values.get("n") or 1))[1]), "stow")

    def _animals_buy(self, p: Panel, an: dict) -> None:
        from game import animals
        b = an["building"]
        p.field("newname", "Name it (optional)", "")
        for o in an["offers"]:
            if o["kind"] == "animal":
                st = animals.mount_stats(o["type"])
                extra = f"speed {st[1]} ft, carries {st[2]} lb" if st else ""
            elif o["kind"] == "vehicle":
                extra = f"carries {animals.VEHICLES[o['type']][1]} lb; needs an animal to pull it"
            else:
                bt = animals.BOATS[o["type"]]
                extra = f"{bt[1]:g} mph, carries {bt[3]:,} lb" + (f", needs a crew of {bt[2]}" if bt[2] else "")

            def buy(p, o=o):
                town = b.fields.get("town") if b is not None else ""
                _ok, text, _v = animals.buy(self.world, self.state, o, (p.values.get("newname") or "").strip(), town)
                p.values["newname"] = ""
                p.message = text
            p.option(f"{o['type']}  ·  {o['price']:,} gp", buy, extra)

    def _animals_sail(self, p: Panel, an: dict) -> None:
        from game import animals
        town = an["building"].fields.get("town") or ""
        boats = [x for x in animals.boats(self.state) if (x.get("home") or "") == town]
        if not boats:
            p.text("None of your boats is moored here.", "small")
            return
        p.select("boat", "Boat", [(x["id"], f"{x['name']} ({x['type']})") for x in boats])
        bt = animals.get(self.state, p.values.get("boat") or "")
        for r in animals.routes(self.world, self.state, bt) if bt is not None else []:
            wage = f"  ·  crew {money_text(r['wages'])}" if r["wages"] else ""

            def go(p, r=r):
                ok, text = animals.sail(self.world, self.state, bt, r, self.bus)
                if not ok:
                    p.message = text
                    return
                p.closed = True
                p.then = self._voyage
            p.option(f"To {r['to'].name}", go, f"{r['days']} day{'s' if r['days'] != 1 else ''}{wage}")
        p.text("Your own boat goes where you like along the coast, with no passage to buy; the bigger ones need a hired "
               "crew, paid for the trip.", "small")

    def _animals_routes(self, p: Panel, an: dict) -> None:
        from game import animals, trade
        p.head("Running")
        for r in trade.routes(self.state):
            a, b = self.world.entities.get(r["from"]), self.world.entities.get(r["to"])
            v = animals.get(self.state, r["vehicle"])
            p.option(f"{v['name'] if v else '?'}: {r['good']}, {a.name if a else '?'} to {b.name if b else '?'}",
                     lambda p, i=r["id"]: setattr(p, "message", trade.stop_route(self.world, self.state, i)[1]),
                     f"{r['trips']} trips, {money_text(r['earned'])} earned  ·  tap to wind it up")
        p.head("A new route")
        vehicles = [(v["id"], f"{v['name']} ({v['type']})") for v in animals.owned(self.state)
                    if v["kind"] in ("vehicle", "boat") and not v.get("route")]
        if not vehicles:
            p.text("No free cart, wagon or boat.", "small")
            return
        towns = self._route_towns()
        p.select("veh", "With", vehicles)
        p.select("from", "From", [(t.id, t.name) for t in towns])
        p.select("to", "To", [(t.id, t.name) for t in towns], towns[1].id if len(towns) > 1 else None)
        p.number("stake", "Stake", 200, 10, 1_000_000, " gp")

        def plan(p):
            v = animals.get(self.state, p.values.get("veh") or "")
            a, b = self.world.entities.get(p.values.get("from") or ""), self.world.entities.get(p.values.get("to") or "")
            if v is None or a is None or b is None:
                p.message = "Pick a cart or boat, and two towns."
                return
            pl = trade.route_plan(self.world, self.state, v, a, b, int(p.values.get("stake") or 200))
            p.message = pl["why"] or (f"{pl['good'].capitalize()}: a round trip every {pl['days']} days, "
                                      f"{int(pl['margin'] * 100)}% on the stake, {money_text(pl['wages'])} in wages: "
                                      f"about {money_text(pl['profit'])} a trip.")
        p.buttons(("Plan it", plan, ""), ("Send it off", lambda p: setattr(p, "message", trade.start_route(
            self.world, self.state, p.values.get("veh") or "", p.values.get("from") or "", p.values.get("to") or "",
            int(p.values.get("stake") or 200))[1]), "primary"))

    def _route_towns(self) -> list:
        import math

        from game import animals
        from game import geography as G
        here = []
        for v in animals.owned(self.state):
            t = self.world.entities.get(v.get("home") or "")
            if t is not None and t not in here:
                here.append(t)
        out = list(here)
        for t0 in here:
            p0 = G.town_position(self.world, t0)
            near = sorted(self.world.entities.all("town"), key=lambda t: math.hypot(
                *(a - b for a, b in zip(G.town_position(self.world, t) or (0, 0), p0 or (0, 0)))))
            for t in near[:25]:
                if t not in out:
                    out.append(t)
        return out

    def _name(self, iid: str) -> str:
        it = self.world.entities.get(iid)
        return it.name if it else iid

    def _look_for_animals(self) -> None:
        """A wild beast, wary but not hostile: calm it, a try at a time (ui/animals_dialog.py TameDialog)."""
        from game import animals
        self._fx("timeskip", 0.8)
        e = animals.find_wild(self.world, self.state, self.members, self.rng, self.bus)
        if e is None:
            self.say("narration", "Birdsong, tracks, droppings: nothing you can get near.")
            return
        key = f"wild:{self.state.location}:{e.id}:{self.state.day}"
        tm = {"said": "", "over": False}

        def build(p: Panel) -> None:
            p.text(f"A {e.name.lower()}, wary of you but not hostile. Five patient tries that go well will tame it; a bad "
                   f"one scares it off" + (" or sets it on you." if animals.predator(e) else ".") +
                   " Food it likes, from your pack, helps.")
            p.text(f"Calmed {int(self.state.taming.get(key, 0))} of {animals.TAME_SUCCESSES} times  ·  DC "
                   f"{animals.tame_dc(e)}", "gold")
            p.text(tm["said"])

            def go(p):
                r = animals.tame_try(self.world, self.state, self.members, e, key, self.rng, self.bus)
                tm["said"] = r.get("text") or ""
                if r["result"] in ("tamed", "fled", "angry"):
                    tm["over"] = True
                    if r["result"] == "tamed":
                        v = animals.adopt(self.world, self.state, e)
                        p.closed = True
                        p.then = lambda: self._name_animal(v)
                    elif r["result"] == "angry":
                        p.closed = True
                        p.then = lambda: self._encounter({"rows": [{"id": e.id, "count": 1}],
                                                          "text": f"The {e.name.lower()} turns on you!",
                                                          "environment": "forest"})
            p.option("Try to calm it (10 min)", go if not tm["over"] else None, style="primary")
        self._panel(Panel(f"A {e.name.lower()}", build, close="Leave it be"))

    def _name_animal(self, v) -> None:
        """A beast just tamed: what to call it, and what it's for."""
        from game import animals
        if not v:
            return
        e = self.world.entities.get(v.get("enemy") or "")

        def build(p: Panel) -> None:
            p.text(f"The {v['type'].lower()} trusts you now. What will you call it, and what is it for?")
            p.field("name", "Name", v["name"])
            p.select("role", "For", [(r, animals.ROLE_WORDS[r].capitalize()) for r in animals.roles_for(self.world, e)],
                     v.get("role"))
            p.text("A pet follows you and fights beside you. A mount can be ridden (faster travel) and carries things; "
                   "a pack animal only carries things. Livestock belongs on a farm.", "small")

            def keep(p):
                animals.rename(self.world, self.state, v["id"], p.values.get("name") or v["name"])
                animals.set_role(self.world, self.state, v["id"], p.values.get("role") or v.get("role"))
                self.say("loot", f"{animals.get(self.state, v['id'])['name']} joins you. (See to your animals from the "
                                 f"Map tab.)")
                p.closed = True
            p.option("Keep it", keep, style="primary")
        self._panel(Panel("Tamed!", build, close="Keep it"))

    # ==================================================================
    # What a talk leads to (web/talk.py asks)
    # ==================================================================
    def _talk_leads_to(self, what: str, npc) -> bool:
        from game import places
        if what == "library":
            self._open_bookshelf(self.world.entities.get(places.building_of(self.world, npc) or ""))
        elif what == "college":
            self._open_college(npc)
        elif what in ("games", "arena") and hasattr(self, "_open_games"):
            if what == "games":
                self._open_games(self.world.entities.get(places.building_of(self.world, npc) or ""))
            else:
                from game import arena
                self._open_arena_house(arena.arena_of(self.world, npc))
        elif what in ("land", "hire", "automatons", "settle") and hasattr(self, "_estate_talk"):
            self._estate_talk(what, npc)
        else:
            return False
        return True


__all__ = ["Doings"]
