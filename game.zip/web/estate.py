"""The browser version, stage 3: land, homes and settlements (game/estate.py, game/homes.py, game/colony.py), as
the app's ui/estate_dialog.py shows them, on panels (web/panel.py): a town's land seller, a claim in the wilds,
hiring a hand, an automaton, "Your land", furnishing, a settler asking to stay; and marking out a building on
the walking map (the D-pad moves it, Action turns it, Interact puts it down, Back stops).
"""
from __future__ import annotations

from game import estate as ES
from game.state import money_text
from web.panel import Panel


def _name(world, iid: str) -> str:
    e = world.entities.get(iid)
    return e.name if e is not None else iid


class Estates:
    """Mixed into web.bridge.Session."""

    placing: dict | None = None

    # ==================================================================
    # Where it starts
    # ==================================================================
    def _estate_activity(self, what: str) -> None:
        if what == "estate":
            self._open_estate()
        elif what.startswith("estate:build:"):
            self._blueprints(what.split(":", 2)[2])
        elif what.startswith("estate:collect:"):
            ES.collect(self.world, self.state, what.split(":", 2)[2], self.bus)
        elif what == "estate:stake":
            pos = (self.state.explore or {}).get("pos") or {}
            if pos.get("area") != "world":
                self.say("system", "Walk out onto the land you want, then stake it.")
                return
            X, Y = int(pos.get("x", 0)), int(pos.get("y", 0))
            ok, why = False, ""
            for kind in ("property", "settlement"):
                ok, why, _r = ES.can_claim(self.world, self.state, kind, X, Y)
                if ok:
                    break
            if not ok:
                self.say("system", why)
                return
            town, _d = ES.registrar(self.world, X, Y)
            self._claim_kind(True, town.name if town else "", lambda kind, name: self._staked(kind, name, X, Y))
        elif what.startswith("estate:"):
            self._open_estate(what.split(":", 1)[1])

    def _staked(self, kind: str, name: str, X: int, Y: int) -> None:
        ok, msg, _c = ES.make_claim(self.world, self.state, kind, X, Y, name, False, self.bus)
        if not ok:
            self.say("system", msg)
        self.ex.sync()

    def _estate_talk(self, what: str, npc) -> None:
        from game import neighborhood as NB
        town = self.world.entities.get(NB.npc_town(self.world, npc) or "")
        if what == "land" and town is not None:
            self._land_seller(npc, town)
        elif what == "hire":
            self._hire(npc)
        elif what == "automatons":
            self._automatons(npc)
        elif what == "settle":
            self._settler(npc)

    # ==================================================================
    # Buying land
    # ==================================================================
    def _claim_kind(self, staking: bool, near: str, then) -> None:
        """A property (one chunk, for good) or a starter settlement (3 x 3 chunks, named, growing from a Camp)."""
        pr, st = ES.CLAIMS["property"], ES.CLAIMS["settlement"]

        def build(p: Panel) -> None:
            p.text((f"You mark out the land here. To build on it, register it at the town hall in {near} and pay "
                    "the price." if staking else f"Land near {near}.") if near else "Land in the wilds.", "small")
            p.select("kind", "What", [("property", f"{pr['label']} ({pr['price']} gp)"),
                                      ("settlement", f"{st['label']} ({st['price']} gp)")])
            p.text(f"{pr['label']}: about 160 by 160 feet. A homestead, a farm, a mine. It never grows, but it can become "
                   f"a settlement later (and not back)." if p.values.get("kind") == "property" else
                   f"{st['label']}: about 480 by 480 feet. You name it, and it starts as a Camp that settlers can grow.",
                   "small")
            p.field("name", "Its name", "")

            def ok(p):
                p.closed = True
                kind, name = p.values.get("kind") or "property", (p.values.get("name") or "").strip()
                p.then = lambda: then(kind, name)
            p.option("Stake it" if staking else "Buy it", ok, style="primary")
        self._panel(Panel("Stake a claim" if staking else "Buy a claim", build, close="Never mind"))

    def _land_seller(self, npc, town) -> None:
        def build(p: Panel) -> None:
            p.text(f"Lots in {town.name} are {ES.lot_price(self.world, town)} gp each. Land in the wilds you claim "
                   "yourself: go out to it and stake it (dry land at least "
                   f"{ES.MIN_TOWN_MILES:g} mile from any town), then register it at the nearest town hall: "
                   f"{ES.CLAIMS['property']['price']} gp for a property, {ES.CLAIMS['settlement']['price']} gp for a "
                   "starter settlement.", "small")
            w, h = ES.lot_size()
            free = ES.lots_free(self.world, self.state, town)
            if not free:
                p.text("No lots left for sale here.")
            for i in free:
                p.option(f"Lot {i + 1}", lambda p, i=i: setattr(p, "message", ES.buy_lot(
                    self.world, self.state, town, int(i), self.bus)[1]), f"{w * 5} by {h * 5} feet  ·  "
                    f"{ES.lot_price(self.world, town)} gp")

        self._panel(Panel(f"Land from {npc.name}", build))

    def _register_claims(self, npc) -> None:
        """At a town hall: register the claims staked round about (game/estate.py register)."""
        def build(p: Panel) -> None:
            here = ES.registering(self.world, self.state, npc)
            if not here:
                p.text("There's nothing of yours waiting to be registered here.")
                return
            p.text("Register a claim to own it: the right to build on the land and develop it.", "small")
            for c in here:
                kind = ES.CLAIMS.get(c["kind"], {}).get("label", "Claim")
                p.option(f"Register {c['name']}", lambda p, i=c["id"]: setattr(p, "message", ES.register(
                    self.world, self.state, i, self.bus)[1]), f"{kind}  ·  {c['price']} gp",
                    enabled=self.state.copper >= int(c["price"]) * 100)
        self._panel(Panel(f"The register, with {npc.name}", build))

    # ==================================================================
    # Hands and automatons
    # ==================================================================
    def _buildings_choice(self) -> list:
        out = [("", "Not yet (idle)")]
        for b in ES.buildings(self.world):
            bp = ES.bp_of(self.world, b)
            cap = ES.worker_cap(bp) if bp is not None else 0
            there = sum(1 for w in ES.workers(self.state) if w.get("building") == b.id)
            out.append((b.id, f"{b.name}  ({there}/{cap})  ·  {b.fields.get('status')}"))
        return out

    def _hire(self, npc) -> None:
        wage = ES.wage_for(self.world, npc)
        skilled = ES.skilled(self.world, npc)

        def build(p: Panel) -> None:
            p.text(f"{npc.name} will work for {money_text(int(round(wage * 100)))} a day" +
                   (", a skilled hand: now and then they'll turn up something rare." if skilled else ", an untrained hand.")
                   + " Wages come out of your purse every day.")
            p.select("where", "Put them to work at", self._buildings_choice())

            def hire(p):
                ok, msg, _w = ES.hire(self.world, self.state, npc, p.values.get("where") or "", self.bus)
                if ok:
                    self.say("loot", msg)
                    p.closed = True
                else:
                    p.message = msg
            p.option("Hire them", hire, style="primary")
        self._panel(Panel(f"Hire {npc.name}", build, close="Not now"))

    def _automatons(self, npc) -> None:
        def build(p: Panel) -> None:
            p.text("An automaton is bought once and never paid. In a farm, a mine or a lumber camp it makes twice what a "
                   "hired hand does (the base resource only, never anything rare), and a better one works faster.", "small")
            p.select("where", "Put it to work at", self._buildings_choice())
            for grade, (price, spd) in ES.AUTOMATON.items():
                def buy(p, grade=grade):
                    ok, msg, w = ES.buy_automaton(self.world, self.state, grade, npc, bus=self.bus)
                    if ok and p.values.get("where"):
                        ok2, why = ES.assign(self.world, self.state, w["id"], p.values["where"])
                        if not ok2:
                            msg += " " + why
                    p.message = msg
                p.option(grade, buy, f"{price} gp  ·  works at {spd:g}x")
        self._panel(Panel(f"Automatons from {npc.name}", build))

    def _settler(self, npc) -> None:
        from game import colony
        pt = colony.pitch(self.world, npc)
        st = colony.settlement_of_npc(self.state, npc)

        def build(p: Panel) -> None:
            who = "on their own" if pt["household"] == 1 else f"with a household of {pt['household']}"
            race = (("an " if pt["race"][:1] in "AEIOU" else "a ") + pt["race"].lower()) if pt["race"] else ""
            p.text(f"{pt['name']}, {race} {pt['profession']}, {who}.")
            p.text(f"They'd pay {pt['tax']:g} gp a week in taxes (at a fair rate).")
            p.text("They'd need " + " and ".join(pt["needs"]) + ".")
            if st is not None:
                free = colony.free_houses(self.world, st)
                p.text("There's a free house for them." if free > 0 else
                       "There's no free house: they'd camp on the green until one is built (three weeks at most).")
            p.text("Turned away, they go elsewhere and never come back.", "small")
            p.buttons(("Turn them away", lambda p: (colony.turn_away(self.world, self.state, npc, self.bus),
                                                    setattr(p, "closed", True)), "ghost"),
                      ("Welcome them", lambda p: (colony.accept(self.world, self.state, npc, self.bus),
                                                  setattr(p, "closed", True)), "primary"))
        self._panel(Panel(f"{npc.name} would like to settle", build, close="Later"))

    # ==================================================================
    # Your land
    # ==================================================================
    def _open_estate(self, here_claim: str = "") -> None:
        es = {"tab": "land", "claim": here_claim, "bid": "", "wid": ""}
        self._panel(Panel("Your land", lambda p: self._estate_build(p, es)))

    def _estate_build(self, p: Panel, es: dict) -> None:
        d = ES.data(self.state)
        p.sub = (f"Every day: upkeep {ES.upkeep(self.world, self.state):g} gp, wages {ES.wage_bill(self.state):g} gp."
                 + (f"  Owed: {d['owed']:.2f} gp." if d.get("owed") else ""))
        p.buttons(*[(lab, (lambda p, k=k: es.update(tab=k, bid="", wid="")), "primary" if es["tab"] == k else "ghost")
                    for k, lab in (("land", "Land"), ("workers", "Workers"), ("settlements", "Settlements"))])
        getattr(self, "_estate_" + es["tab"])(p, es)

    def _estate_land(self, p: Panel, es: dict) -> None:
        claims = ES.claims(self.state)
        if not claims:
            p.text("You own no land yet. Buy a lot from a town's land seller, or stake a claim out in the wilds.", "small")
            return
        c = ES.claim(self.state, es["claim"]) if es["claim"] else None
        if c is None:
            for x in claims:
                kind = ES.CLAIMS.get(x["kind"], {}).get("label", "Town lot") if x["kind"] != "lot" else "Town lot"
                n = len(ES.buildings(self.world, x["id"]))
                p.option(x["name"], lambda p, i=x["id"]: es.update(claim=i, bid=""),
                         f"{kind}  ·  {n} building{'s' if n != 1 else ''}" + ("" if x.get("paid") else "  ·  not registered"))
            return
        p.head(c["name"])
        if not c.get("paid") and c.get("kind") != "lot":
            p.text(ES.unregistered_text(self.world, c), "small")
        b = self.world.entities.get(es["bid"]) if es["bid"] else None
        if b is None:
            for bb in ES.buildings(self.world, c["id"]):
                st = bb.fields.get("status")
                if st == "building":
                    left = ES.days_left(self.world, self.state, bb.id)
                    extra = f"{int((ES.progress(self.world, self.state, bb.id) or 0) * 100)}% · about {left:.0f} days left"
                elif st == "planned":
                    extra = "marked out: start the work when you have the materials"
                else:
                    out = ES.output(self.state, bb.id)
                    extra = ", ".join(f"{n} {_name(self.world, i)}" for i, n in out.items() if n) or "built"
                crew = [w["name"] for w in ES.workers(self.state) if w.get("building") == bb.id]
                p.option(bb.name, lambda p, i=bb.id: es.update(bid=i), extra + (f"  ·  {', '.join(crew)}" if crew else ""))
            pairs = [("Back", lambda p: es.update(claim="", bid=""), "ghost"),
                     ("Build...", lambda p: (setattr(p, "closed", True),
                                             setattr(p, "then", lambda: self._blueprints(c["id"]))), "primary")]
            if c.get("kind") == "property":
                cost = ES.CLAIMS["settlement"]["price"] - ES.CLAIMS["property"]["price"]

                def grow(p):
                    if not es.get("sure"):
                        es["sure"] = True
                        p.message = (f"Make {c['name']} a starter settlement for {cost} gp more? Its land grows to 3 by 3 "
                                     "chunks round it, and it can never go back to being a property. Press again to found it.")
                        return
                    es.pop("sure", None)
                    p.message = ES.to_settlement(self.world, self.state, c["id"], "", self.bus)[1]
                pairs.append(("Make it a settlement", grow, ""))
            p.buttons(*pairs)
            return
        bp = ES.bp_of(self.world, b)
        st = b.fields.get("status")
        p.text(b.name, "gold")
        if bp is not None:
            p.text(ES.summary(self.world, bp), "small")
        if st == "planned" and bp is not None:
            lack = ES.missing(self.world, self.state, bp)
            if lack:
                p.text("Still needed: " + ", ".join(f"{n} {_name(self.world, i)}" for i, n in lack))
        if st == "done":
            r = ES.rates(self.world, self.state, b)
            if r:
                p.text("Making " + ", ".join(f"{v:.1f} {_name(self.world, i)}" for i, v in r.items()) + " a day.")
            inc = ES.income_rate(self.world, self.state, b)
            if inc:
                p.text(f"Bringing in {inc:.1f} gp a day.")

        def collect(p):
            got = ES.collect(self.world, self.state, b.id, self.bus)
            p.message = ("Collected: " + ", ".join(f"{n} {_name(self.world, i)}" for i, n in got.items())) if got \
                else "Nothing to collect."
        p.buttons(("Back", lambda p: es.update(bid=""), "ghost"),
                  ("Start the work", (lambda p: setattr(p, "message", ES.start(self.world, self.state, b.id, self.bus)[1]))
                   if st == "planned" else None, "primary"),
                  ("Collect", collect if st == "done" and any(ES.output(self.state, b.id).values()) else None, ""),
                  ("Call it off", (lambda p: (setattr(p, "message", ES.remove(self.world, self.state, b.id, self.bus)[1]),
                                              es.update(bid=""))) if st != "done" else None, "ghost"))

    def _estate_workers(self, p: Panel, es: dict) -> None:
        ws = ES.workers(self.state)
        if not ws:
            p.text("Nobody works for you yet. Ask townsfolk if they'd work for you, or buy an automaton at an "
                   "automaton workshop.", "small")
            return
        p.select("where", "Put to work at", [("", "Idle")] + [(b.id, b.name) for b in ES.buildings(self.world)])
        for w in ws:
            b = self.world.entities.get(w.get("building") or "")
            what = f"{w.get('grade', '').lower()} automaton" if w.get("kind") == "automaton" else \
                ("skilled hand" if w.get("skilled") else "hand") + f", {money_text(int(round(w.get('wage', 0) * 100)))} a day"
            p.head(w["name"])
            p.text(f"{what}  ·  {b.name if b else 'idle'}", "small")
            p.buttons(("Put to work there", lambda p, i=w["id"]: setattr(p, "message", ES.assign(
                self.world, self.state, i, p.values.get("where") or "")[1] or "Done."), ""),
                ("Let go", lambda p, i=w["id"]: setattr(p, "message", ES.dismiss(self.world, self.state, i, self.bus)[1]),
                 "ghost"))

    def _estate_settlements(self, p: Panel, es: dict) -> None:
        from game import colony
        sts = colony.settlements(self.state)
        if not sts:
            p.text("You have no settlement yet. Stake a starter settlement out in the wilds (or make a property one), "
                   "and settlers will come.", "small")
            return
        p.select("st", "Settlement", [(x["id"], x["name"]) for x in sts])
        st = colony.get(self.state, p.values.get("st") or "")
        if st is None:
            return
        s = colony.status(self.world, self.state, st)
        road = st.get("road") or {}
        job = colony.road_job(self.state, st)
        plan = colony.road_plan(self.world, self.state, st)
        p.text(f"{s['tier']}  ·  {s['population']} people in {s['households']} households  ·  standing {s['standing']}")
        p.text(f"Food for {s['food']}, water for {s['water']}  ·  defence {s['defense']} against {s['threat']} "
               f"({'safe' if s['safe'] else 'not safe'})  ·  free houses: {max(0, s['free_houses'])}")
        p.text(f"Taxes {s['tax_week']:g} gp a week  ·  next: {s['next_tier'] or 'the top'}  ·  a newcomer about every "
               f"{max(1, round(1 / max(0.01, s['chance'])))} days", "small")
        store = st.get("store") or {}
        if store:
            p.text("Storehouse: " + ", ".join(f"{n} {_name(self.world, i)}" for i, n in store.items() if n))
        if road.get("done"):
            p.text(f"A road leads to {_name(self.world, road['to'])}.")
        elif job is not None:
            p.text(f"The road is {int(100 * job['done'] / max(1, job['work']))}% built.")
        elif plan is not None:
            p.text(f"A road to {plan['name']} ({plan['miles']} miles) would take {plan['labor']} gp of work and "
                   + ", ".join(f"{n} {_name(self.world, i)}" for i, n in plan["materials"]) + ".")
        w = colony.pending(self.world, st)
        if w is not None:
            p.text(f"Waiting on the green: {w.name} (talk to them)", "gold")
        for n in colony.settlers_of(self.world, st):
            s2 = n.fields.get("settler") or {}
            home = self.world.entities.get(n.fields.get("home") or "")
            work = self.world.entities.get(n.fields.get("building") or "")
            p.text(f"{n.name}  ·  {s2.get('profession')}, household of {s2.get('household')}  ·  "
                   f"{home.name if home else 'camping'}  ·  {work.name if work else 'no work yet'}", "small")
        p.select("tax", "Taxes", [(k, k) for k in colony.TAX_RATES], st.get("tax_rate") or "Fair")

        def take(p):
            got = {k: v for k, v in (st.get("store") or {}).items() if v}
            for i, n in got.items():
                self.state.add_item(i, int(n), "the storehouse")
            st["store"] = {}
            p.message = ("Taken: " + ", ".join(f"{n} {_name(self.world, i)}" for i, n in got.items())) if got \
                else "The storehouse is empty."
        p.buttons(("Set taxes", lambda p: colony.set_tax(self.state, st["id"], p.values.get("tax") or "Fair"), ""),
                  ("Take from the store", take, ""),
                  ("Build the road", (lambda p: setattr(p, "message", colony.start_road(self.world, self.state, st["id"],
                                                                                      self.bus)[1]))
                   if not road.get("done") and job is None and plan is not None else None, "primary"))

    # ==================================================================
    # Building: what, then where (on the walking map)
    # ==================================================================
    def _blueprints(self, cid: str) -> None:
        c = ES.claim(self.state, cid)
        if c is None:
            return

        def build(p: Panel) -> None:
            cw, ch = ES.claim_size_of(c)
            p.text(f"{c['name']}: {cw * 5} by {ch * 5} feet. You'll mark out where it goes on the map (the D-pad moves "
                   f"it, Action turns it, Interact puts it down, Back stops).", "small")
            for bp in ES.blueprints(self.world):
                w, h = ES.footprint(bp)
                fits = (w <= cw and h <= ch) or (h <= cw and w <= ch)
                lack = ES.missing(self.world, self.state, bp)
                p.option(bp.name + ("" if fits else "  (too big for this land)"),
                         (lambda p, b=bp: (setattr(p, "closed", True),
                                           setattr(p, "then", lambda: self._begin_placement(c, b)))) if fits else None,
                         ES.summary(self.world, bp) + ("" if not lack else "  ·  still needed: " + ", ".join(
                             f"{n} {_name(self.world, i)}" for i, n in lack)), enabled=fits, desc=bp.description or "")
        self._panel(Panel("What to build", build, close="Never mind"))

    def _begin_placement(self, claim: dict, bp) -> None:
        ex = self.ex
        if ex is None or ex.area is None:
            self.say("system", "Go to the land first: buildings are marked out on the walking map.")
            return
        bounds = ES.claim_bounds(self.world, claim, ex.area)
        if bounds is None:
            self.say("system", f"Go to {claim['name']} first: buildings are marked out on the walking map.")
            return
        bx, by, bw, bh = bounds
        w, h = ES.footprint(bp)
        x = min(max(0, ex.x - bx - w // 2), max(0, bw - w))
        y = min(max(0, ex.y - by - h - 1), max(0, bh - h))
        self.placing = {"claim": claim, "bp": bp, "rot": 0, "x": x, "y": y, "bounds": bounds}
        self.say("system", f"Mark out where the {bp.name.lower()} goes: the D-pad moves it, Action turns it, Interact "
                           f"puts it down, Back stops.")

    def _ghost(self) -> dict | None:
        pl = self.placing
        if pl is None:
            return None
        bx, by, bw, bh = pl["bounds"]
        w, h = ES.footprint(pl["bp"], pl["rot"])
        ok, why = ES.can_place(self.world, self.state, pl["claim"], pl["bp"], pl["x"], pl["y"], pl["rot"], self.ex.area)
        door = None
        if not ES.is_open(pl["bp"]):
            side = {0: "S", 1: "W", 2: "N", 3: "E"}[pl["rot"] % 4]
            gx, gy = bx + pl["x"], by + pl["y"]
            door = {"S": (gx + w // 2, gy + h), "N": (gx + w // 2, gy - 1), "W": (gx - 1, gy + h // 2),
                    "E": (gx + w, gy + h // 2)}[side]
        return {"claim": list(pl["bounds"]), "rect": [bx + pl["x"], by + pl["y"], w, h], "ok": bool(ok), "why": why or "",
                "door": list(door) if door else None, "name": pl["bp"].name}

    def _place_key(self, name: str) -> None:
        pl = self.placing
        if pl is None:
            return
        if name in ("N", "S", "E", "W"):
            dx, dy = {"N": (0, -1), "S": (0, 1), "E": (1, 0), "W": (-1, 0)}[name]
            w, h = ES.footprint(pl["bp"], pl["rot"])
            bw, bh = pl["bounds"][2], pl["bounds"][3]
            pl["x"] = min(max(0, pl["x"] + dx), max(0, bw - w))
            pl["y"] = min(max(0, pl["y"] + dy), max(0, bh - h))
        elif name == "rotate":
            pl["rot"] = (pl["rot"] + 1) % 4
            w, h = ES.footprint(pl["bp"], pl["rot"])
            pl["x"] = min(pl["x"], max(0, pl["bounds"][2] - w))
            pl["y"] = min(pl["y"], max(0, pl["bounds"][3] - h))
        elif name == "put":
            ok, msg, b = ES.place(self.world, self.state, pl["claim"]["id"], pl["bp"], pl["x"], pl["y"], pl["rot"],
                                  self.ex.area, bus=self.bus)
            if not ok:
                self.say("system", msg)
                return
            self.placing = None
            self.ex.sync()
            self._estate_placed(b.id)
        elif name == "stop":
            self.placing = None
            self.say("system", "You stop marking it out.")

    def _estate_placed(self, bid: str) -> None:
        b = self.world.entities.get(bid)
        bp = ES.bp_of(self.world, b) if b is not None else None
        if bp is None:
            return
        lack = ES.missing(self.world, self.state, bp)
        if lack:
            self.say("system", "To start the work you'll need " + ", ".join(f"{n} {_name(self.world, i)}" for i, n in lack)
                     + ". (Your land, on the Map tab, starts it.)")
            return

        def build(p: Panel) -> None:
            p.text(f"You have the materials for {b.name}. Start the work now? They're used up as it begins.")
            p.option("Start", lambda p: (ES.start(self.world, self.state, bid, self.bus), setattr(p, "closed", True)),
                     style="primary")
        self._panel(Panel("Start building", build, close="Later"))

    # ==================================================================
    # Furnishing (game/homes.py)
    # ==================================================================
    def _furnish(self, b) -> None:
        from game import homes
        from game import rooms as R
        if b is None:
            return
        fb = {"b": b}

        def build(p: Panel) -> None:
            bb = self.world.entities.get(fb["b"].id) or fb["b"]
            p.text("Furniture goes into a room (beds make it somewhere to sleep, a shrine heals); a workbench is a "
                   "crafting station of your own, free to use." + ("" if homes.can_extend(bb) else " A building in "
                   "town can't grow past its walls: this is how it changes."), "small")
            p.select("room", "Room", [(r["name"], f"{r['name']}  (room for {max(0, homes.room_room(r))} more)")
                                      for r in R.ensure(self.world, bb)])
            keys = [(k, lab) for k, (lab, _gp, _m) in homes.FURNISHINGS.items()]
            keys += [(f"bench:{fac}", f"Workbench: {fac.lower()}") for fac in homes.WORKBENCHES
                     if fac not in (bb.fields.get("facilities") or [])]
            for key, lab in keys:
                gp, mats = homes.furnish_cost(self.world, key)

                def go(p, key=key):
                    ok, msg = homes.furnish(self.world, self.state, bb, p.values.get("room") or "", key, self.bus)
                    p.message = msg
                p.option(lab, go, f"{gp} gp" + (" + " + ", ".join(f"{n} {_name(self.world, i)}" for i, n in mats)
                                                if mats else ""))
        self._panel(Panel(f"Furnish {b.name}", build))


    # ==================================================================
    # Building onto a home (ui/room_editor.py's build mode, as lists instead of a plan)
    # ==================================================================
    def _build_onto(self, b) -> None:
        from game import homes
        from game import rooms as R
        if b is None:
            return
        bo = {"b": b, "lay": homes.layout(self.world, b), "tiles": homes.buildable(self.world), "at": None}
        sides = {"N": "north", "S": "south", "E": "east", "W": "west"}

        def build(p: Panel) -> None:
            lay = bo["lay"]
            if bo["at"] is None:
                n = len(lay.rooms)
                p.text(f"{n} room{'s' if n != 1 else ''}; {len(lay.open_doors())} open doorways. You have "
                       f"{self.state.copper // 100} gp.", "small")
                have = homes.perks(self.world, bo["b"])
                if have:
                    p.text("Your home gives: " + ", ".join(k.lower() for k in sorted(have)) + ".")
                p.head("Build a room off")
                for i, k in lay.open_doors():
                    r = lay.rooms[i]
                    side, _off = r["doors"][k]
                    p.option(f"{r['name']}: the {sides.get(side, side)} doorway", lambda p, i=i, k=k: bo.update(at=("door", i, k)),
                             R.floor_name(r["floor"]))
                for i, fl in lay.open_stairs():
                    r = lay.rooms[i]
                    p.option(f"{r['name']}: the stairs to the {R.floor_name(fl).lower()}",
                             lambda p, i=i, fl=fl: bo.update(at=("stair", i, fl)), "the other end")
                return
            kind, i, k = bo["at"]
            cands = lay.candidates(bo["tiles"], i, k) if kind == "door" else lay.stair_candidates(bo["tiles"], i, k)
            floor = lay.rooms[i]["floor"] if kind == "door" else k
            p.text("These fit here:" if cands else "Nothing fits here (no room, or the limits are reached).", "small")
            for t, (x, y) in sorted(cands, key=lambda c: (c[0]["role"], c[0]["name"])):
                mats = ", ".join(f"{n} {_name(self.world, it)}" for it, n in ES.room_materials(self.world, t))

                def go(p, t=t, x=x, y=y):
                    ok, text = homes.build_room(self.world, self.state, bo["b"], lay, t, x, y, floor, i,
                                                k if kind == "door" else None, self.bus)
                    p.message = text
                    if ok:
                        bo["b"] = self.world.entities.get(bo["b"].id)
                        bo["at"] = None
                p.option(f"{t['name']}  ({t['role']}, {t['w']} x {t['h']})", go,
                         f"{int(float(t.get('cost') or 0))} gp" + (f" + {mats}" if mats else "") +
                         f", {int(t.get('days') or 0)} days" + (f"  ·  {t['perk'].lower()}" if t.get("perk") else ""),
                         desc=t.get("description") or "")
            p.option("Back", lambda p: bo.update(at=None), style="ghost")
        self._panel(Panel(f"Build onto {b.name}", build))


__all__ = ["Estates"]
