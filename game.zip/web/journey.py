"""The browser version, stage 3: being carried along (the app's main window: _journey, _voyage, _trek and their
legs). A road journey, a trek across open country and a voyage (ship, airship, caravan) go a stretch at a time:
the page calls journey() about five times a second while the view says it's travelling, as the app's journey
timer does, and stops while anything else is going on (a fight, a menu, something coming down the road).
Without a walking map, the whole way is done at once. Following a route goes on along the roads too.
"""
from __future__ import annotations

from game import places, travel

ROAD_LINES = ["The road winds on.", "You keep a steady pace.", "Hours pass on the road.",
              "Fields give way to rougher country, then back again.", "You stop briefly to rest your feet.",
              "A cart passes the other way; the driver nods.", "The milestones tick by."]


class Journeys:
    """Mixed into web.bridge.Session."""

    route_goal = ""
    voyage_sub = 0

    # ==================================================================
    # Setting off
    # ==================================================================
    def _go_far(self, target: str) -> bool:
        """road:<town>:<dir>, journey:continue / journey:back, voyage:continue. True when handled."""
        if target.startswith("road:"):
            _r, town_id, direction = target.split(":", 2)
            if travel.start_journey(self.world, self.state, town_id, direction, self.bus) is None:
                return True
            self._journey()
            return True
        if target == "journey:continue":
            self._journey()
            return True
        if target == "voyage:continue":
            self._voyage()
            return True
        if target == "journey:back":
            travel.turn_back(self.world, self.state, self.bus)
            self._journey()
            return True
        return False

    def _walkable_now(self, kind: str) -> bool:
        """On the walking map, carried along it (the page paces it); else done all at once."""
        ex = self.ex
        if ex is None:
            return False
        ex.sync()
        return ex.area is not None and ex.travelling() == kind

    def _journey(self, _outcome: str = "") -> None:
        if (self.state.journey or {}).get("kind") == "voyage":
            self._voyage()
            return
        if self._walkable_now("road"):
            return                                       # the page carries it along, leg by leg
        for _ in range(50):
            if self.state.journey is None or self.fight is not None:
                break
            step = travel.step(self.world, self.state, self.rng, self._levels(), self.bus, members=self.members)
            if step["kind"] == "encounter":
                self._encounter(step, then=self._journey)
                return
            if step["kind"] in ("arrived", "stopped"):
                break
        self._route_on()

    def _voyage(self, _outcome: str = "") -> None:
        from game import passage
        if (self.state.journey or {}).get("kind") == "voyage" and self._walkable_now("voyage"):
            self.voyage_sub = 0
            return
        for _ in range(60):
            j = self.state.journey
            if not j or j.get("kind") != "voyage" or self.fight is not None:
                break
            step = passage.step(self.world, self.state, self.rng, self._levels(), self.members, self.bus)
            if step["kind"] == "encounter":
                self._encounter(step, then=self._voyage)
                return
            if step["kind"] == "arrived":
                break
        self._check_continent()
        self.ex.sync()

    def _start_voyage(self, offer: dict) -> None:
        from game import passage
        ok, text = passage.start(self.world, self.state, offer, self.bus)
        if not ok:
            self.say("system", text)
            return
        self._voyage()

    def _trek(self, _outcome: str = "") -> None:
        from game import hexes as H
        if self.state.trek and self._walkable_now("trek"):
            if self.ex.area is not None and self.ex.area.kind == "world":
                self.state.trek.setdefault("start", [self.ex.x, self.ex.y])
            return
        for _ in range(2000):
            if self.state.trek is None or self.fight is not None:
                break
            step = H.trek_step(self.world, self.state, self.rng, self._levels(), self.bus, self.members)
            if step["kind"] == "encounter":
                self._encounter(step, then=lambda outcome: self._trek() if outcome == "victory" else H.stop_trek(self.state))
                return
            if step["kind"] in ("arrived", "stopped"):
                break
        here = places.current(self.world, self.state)
        if here.kind == "hex":
            places.enter(self.world, self.state, here.id, self.bus)

    def _check_continent(self) -> bool:
        """Landed on another continent: its walking map is laid out (the app shows a loading screen)."""
        from game import worldmap
        if not worldmap.walkable(self.world):
            return False
        c = worldmap.continent_due(self.world, self.state)
        if c is None:
            return False
        self.say("system", f"Landing on {c.name}…")
        worldmap.load_continent(self.world, c.id)
        if self.ex is not None:
            self.ex.sync()
        return True

    # ==================================================================
    # A stretch at a time (the page asks)
    # ==================================================================
    def api_journey(self) -> dict:
        ex = self.ex
        busy = self.fight is not None or self.menu is not None or self.pnl is not None or self.placing is not None
        if ex is None or busy or not ex.travelling() or ex.encounters:
            out = self.api_view()
            out["paused"] = True
            return out
        kind = ex.travelling()
        if kind == "road":
            self._journey_leg()
        elif kind == "trek":
            self._trek_leg()
        elif kind == "voyage":
            self._voyage_leg()
        return self.api_view()

    def _journey_leg(self) -> None:
        j = self.state.journey
        if not j:
            return
        leg = max(0.1, min(3.0, float(j.get("hours", 1)) / 16.0))
        before = float(j.get("done", 0))
        step = travel.step(self.world, self.state, self.rng, self._levels(), self.bus, leg=leg, quiet=True,
                           members=self.members)
        if step["kind"] == "stopped":
            self.ex.sync()
            return
        if step["kind"] == "arrived":
            self.ex.sync()
            self._route_on()
            return
        if int(before) != int(float(j.get("done", 0))):          # every hour or so, a word about the road
            dest = self.world.entities.get(j.get("to") or "")
            self.say("narration", f"{self.rng.choice(ROAD_LINES)} ({j['done']:g} of {j['hours']:g} hours to "
                                  f"{dest.name if dest else 'town'})")
        self.ex.place_on_route()
        if step["kind"] == "encounter":
            self.ex.spawn_group(step, distance=(7, 11))
            self.say("damage", step.get("text") or "Something is coming down the road!")

    def _trek_leg(self) -> None:
        import math
        from game import hexes as H
        t = self.state.trek
        if not t:
            return
        for _ in range(max(1, math.ceil(len(t.get("path") or []) / 16))):
            step = H.trek_step(self.world, self.state, self.rng, self._levels(), self.bus, self.members)
            if step["kind"] == "stopped":
                self.ex.sync()
                return
            if step["kind"] == "arrived":
                here = places.current(self.world, self.state)
                if here.kind == "hex":
                    places.enter(self.world, self.state, here.id, self.bus)
                self.ex.sync()
                return
            if step["kind"] == "encounter":
                self.ex.place_on_route()
                self.ex.spawn_group(step, distance=(7, 11))
                self.say("damage", step.get("text") or "Something is coming!")
                break
        self.ex.place_on_route()

    def _voyage_leg(self) -> None:
        from game import passage
        j = self.state.journey
        if not j or j.get("kind") != "voyage":
            return
        per = max(1, round(16 / max(1, int(j.get("days", 1)))))
        self.voyage_sub += 1
        if self.voyage_sub < per:
            self.ex.sub_progress = self.voyage_sub / per
        else:
            self.voyage_sub = 0
            self.ex.sub_progress = 0.0
            step = passage.step(self.world, self.state, self.rng, self._levels(), self.members, self.bus)
            if step["kind"] == "arrived":
                self._check_continent()
                self.ex.sync()
                return
            if step["kind"] == "encounter":
                self._encounter(step, then=lambda _o: None)      # on deck, or round the wagons; then sail on
                return
        self.ex.place_on_route()

    def api_trek(self, x: float = 0.0, y: float = 0.0) -> dict:
        """Across open country to a point picked on the world map (miles), hex by hex."""
        from game import hexes as H
        self.trek_to(H.at(self.world, float(x), float(y)))
        return self.api_view()

    def trek_to(self, goal, then: str = "") -> bool:
        from game import geography as G
        from game import hexes as H
        self.route_goal = ""
        if self.state.journey:
            self.say("system", "Finish the road journey first.")
            return False
        here = places.current(self.world, self.state)
        if here.kind in ("building", "street", "dungeon") and H.party_hex(self.world, self.state) != tuple(goal):
            p = G.party_position(self.world, self.state)          # out of the town or dungeon first
            if p is not None:
                places.travel(self.world, self.state, H.hex_of_point(self.world, p), self.bus)
        if H.start_trek(self.world, self.state, tuple(goal), then, self.bus) is None:
            self.say("system", "There's no way across open country to there from here.")
            return False
        self._trek()
        return True

    # ==================================================================
    # Following a route, roads and all
    # ==================================================================
    def follow_route(self, goal: str) -> None:
        if not goal:
            return
        here = places.current(self.world, self.state)
        if not places.route(self.world, here.id, goal):
            self.say("system", "You don't know a way there from here.")
            return
        self.route_goal = goal
        self.say("narration", "You set off. " + places.route_text(self.world, here.id, goal))
        self._route_on()

    def _route_on(self) -> None:
        for _ in range(60):
            goal = self.route_goal
            if not goal or self.fight is not None:
                return
            here = places.current(self.world, self.state)
            steps = places.route(self.world, here.id, goal)
            if not steps:
                self.route_goal = ""
                if here.id == places.parse(self.world, goal).id:
                    self.say("system", f"You've arrived: {here.name}.")
                self.ex.sync()
                return
            loc, _mins, how = steps[0]
            if how.startswith("road:"):
                self._go_far(f"road:{here.town.id}:{how.split(':', 1)[1]}")
                return                  # the journey picks the route up again when it arrives
            before = self.state.location
            self._map_action(("go", loc))
            if self.state.location == before:
                self.route_goal = ""
                return


__all__ = ["Journeys"]
