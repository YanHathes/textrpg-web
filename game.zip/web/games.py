"""The browser version, stage 3: games. A minigame (game/minigames.py: a check played as a game, a festival's
contest) and a gambling table (game/tablegames/: blackjack, Hold'em, craps, roulette, the tavern games) both
draw themselves as a list of shapes; the page draws them on a canvas and sends what's pressed, ticking the game
along about thirty times a second (as ui/minigames/window.py and table.py do in the app). Also the panels
around them: picking a table (ui/games_dialog.py), a festival (ui/festival_dialog.py), an arena's
tournaments and bouts, and the checks setting (dice, or minigames).

    play(do, ...)    do: "state", "tick" (dt, press, release), "tap" (x, y on the 640 x 360 board), "button"
                     (action), "giveup", "end"
    play_sprites(keys)
"""
from __future__ import annotations

from game.state import money_text
from web.panel import Panel
from web.scene import png64

RESULT_S = 1.4
TABLE_SOUNDS = {"deal": "shuffle", "hit": "card", "double": "chips", "split": "card", "spin": "wheel", "roll": "dice",
                "roll_now": "dice", "throw": "dice", "start": "chips", "bet": "chips", "call": "chips"}   # (the app's)


class Games:
    """Mixed into web.bridge.Session."""

    play: dict | None = None
    tournament: str = ""

    # ==================================================================
    # Playing one
    # ==================================================================
    def _play_minigame(self, spec, then) -> None:
        """then(perf or None) runs when it's over (None: rolled the dice instead)."""
        from game import minigames as M
        self.close_menus()
        self.play = {"kind": "game", "obj": M.make(spec), "spec": spec, "then": then, "ended": None, "t": 0.0}
        self._fx("click", 0.8)

    def _sit_down(self, table, then) -> None:
        self.close_menus()
        self.play = {"kind": "table", "obj": table, "then": then, "flash": ""}
        self._fx("shuffle" if getattr(table, "uses", "") == "cards" else "chips", 0.7)

    def api_play(self, do: str = "state", dt: float = 0.0, press: list | None = None, release: list | None = None,
                 x: float = 0.0, y: float = 0.0, action: str = "") -> dict:
        pl = self.play
        if pl is None:
            return {"play": None, "view": self.api_view()}
        g = pl["obj"]
        if pl["kind"] == "game":
            for a in press or []:
                if not g.done:
                    g.press(a)
            for a in release or []:
                g.release(a)
            if do == "tap" and not g.done:
                g.press(f"point:{x:.1f},{y:.1f}")
                hit = next((a for bx, by, bw, bh, a in g.boxes() if bx <= x <= bx + bw and by <= y <= by + bh), None)
                g.press(hit or "hit")
                if not hit:
                    g.release("hit")
            if do in ("tick", "tap") and not g.done:
                g.update(min(0.1, max(0.0, float(dt))))
            pl["t"] += float(dt or 0)
            if g.done and pl["ended"] is None:
                from game import minigames as M
                pl["ended"] = pl["t"]
                self._fx("quest" if M.natural_for(g.perf, pl["spec"].need) >= pl["spec"].need else "miss", 0.9)
            if do == "giveup":
                return self._play_over(None)
            if g.done and (do == "end" or pl["t"] - pl["ended"] >= RESULT_S):
                return self._play_over(g.perf)
            return {"play": self._game_json(), "view": self.api_view()}
        # a gambling table
        if do == "button":
            if action == "leave":
                return self._play_over(g)
            self._table_do(action)
        elif do == "tap":
            hit = next((a for bx, by, bw, bh, a in g.boxes() if bx <= x <= bx + bw and by <= y <= by + bh), None)
            if hit:
                self._table_do(hit)
            elif g.realtime:
                self._table_do("hit")
        elif do == "tick":
            if g.realtime or getattr(g, "rolling", 0) > 0 or getattr(g, "phase", "") == "spin":
                g.update(min(0.1, max(0.0, float(dt))))
        if getattr(g, "thrown_out", False):
            return self._play_over(g)
        return {"play": self._table_json(), "view": self.api_view()}

    def _play_over(self, result) -> dict:
        pl = self.play
        self.play = None
        then = pl.get("then")
        if then is not None:
            then(result)
        from game import party as P
        P.save(self.world, self.members)
        self.state.save()
        return {"play": None, "view": self.api_view()}

    def _game_json(self) -> dict:
        from game import minigames as M
        from game import wording
        pl = self.play
        g, spec = pl["obj"], pl["spec"]
        bits = [g.title, wording.game_help(g.help)]
        if spec.slow:
            bits.append("slow mode")
        out = {"kind": "game", "title": spec.title or g.title, "help": "  ·  ".join(b for b in bits if b),
               "bar": round(g.time_left, 3), "draw": g.draw(), "pads": [list(p) for p in M.pads(g)],
               "quit": "Roll the dice instead", "done": bool(g.done)}
        if g.done:
            nat = M.natural_for(g.perf, spec.need)
            ok = nat >= spec.need
            out["result"] = {"word": "Natural 20!" if nat == 20 else "A complete miss" if nat == 1 else
                             ("Success" if ok else "Failure"), "ok": ok,
                             "line": (g.message + "  " if g.message else "") + f"Counts as a roll of {nat}."}
        return out

    def _table_json(self) -> dict:
        from game import wording
        from game.tablegames import base as TB
        pl = self.play
        t = pl["obj"]
        buttons = [("Stake -", "stake-", t.betting()), ("Stake +", "stake+", t.betting())] + list(t.buttons())
        if t.cheat_label:
            buttons.append((f"Cheat: {t.cheat_label}", "cheat", t.can_cheat() and not t.over))
        buttons.append(("Leave the table", "leave", True))
        return {"kind": "table", "title": t.title, "help": wording.game_help(t.help),
                "purse": f"{t.ctx.player}: {TB.money(t.chips)} in chips  ·  stake {TB.money(t.stake)} "
                         f"({TB.money(t.ctx.stake_min)} to {TB.money(t.ctx.stake_max)})  ·  the house: {TB.money(t.house)}",
                "draw": t.draw(), "buttons": [[lab, act, bool(ok)] for lab, act, ok in buttons], "flash": pl.get("flash") or "",
                "wheel": self._wheel(),
                "live": bool(t.realtime or getattr(t, "rolling", 0) > 0 or getattr(t, "phase", "") == "spin")}

    @staticmethod
    def _wheel() -> dict:
        from game.tablegames.roulette import REDS, WHEEL
        return {"nums": list(WHEEL), "reds": sorted(REDS)}

    def _table_do(self, action: str) -> None:
        from game import tablegames as TG
        pl = self.play
        t = pl["obj"]
        if action == "tells":
            pl["flash"] = self._read_tells(t) or ""
            return
        if action == "cheat":
            ok, text = TG.try_cheat(self.world, self.state, self.members, t, self.rng, self.bus)
            pl["flash"] = text
            self._fx("coins" if ok else "miss", 0.8)
            if getattr(t, "caught", False):
                t.thrown_out = True
            return
        before = t.chips
        t.press(action)
        self._fx(TABLE_SOUNDS.get(action, "click"), 0.6)
        if t.chips > before:
            self._fx("coins", 0.6)
        if t.over:
            pl["flash"] = "The game's over: " + (t.lines[-1] if t.lines else "")

    def _read_tells(self, table) -> str:
        from game import checks, condition
        m = next((x for x in self.members if x.get("id") == getattr(table, "player_id", "")), None) or \
            next((x for x in self.members if not x.get("dead")), None)
        opt = next((o for o in checks.options(self.world) if o["label"] == "Insight"), None)
        if m is None or opt is None:
            return ""
        extra = int(table.ctx.bonus.get("cards", 0)) if table.id == "holdem" else 0
        r = checks.roll(self.world, m, condition.combatant(self.world, m), opt, 0, rng=self.rng, bus=self.bus,
                        target="reading the table", extra=extra)
        total = int(r.get("total") or 0)
        if hasattr(table, "read_tells"):
            return " ".join(table.read_tells(total))
        if hasattr(table, "read"):
            return table.read(total)
        return ""

    def api_play_sprites(self, keys: list) -> dict:
        """Pictures for the games' sprite slots (a person to read, watchers, an animal) and the players at a table."""
        out = {}
        for key in keys:
            c = None
            try:
                if key in ("speaker", "watcher"):
                    from game.art import doll, folk
                    from game.art.humanoid import Look
                    c = folk.sprite(Look("human", clothes="#6a4a3a" if key == "watcher" else "#3f5a7a"),
                                    doll.Gear(armor="tunic"), tiles=2)
                elif key == "animal":
                    e = next((x for x in self.world.entities.all("enemy") if x.name in ("Draft Horse", "Riding Horse",
                                                                                         "Mule", "Mastiff")), None)
                    c = self.world.sprites.render_entity(e, self.world.entities) if e is not None else None
                else:
                    e = self.world.entities.get(key)
                    c = self.world.sprites.render_entity(e, self.world.entities) if e is not None else None
            except Exception:  # noqa: BLE001 - a plain box will do
                c = None
            out[key] = png64(c) if c is not None else ""
        return out

    # ==================================================================
    # Checks as games (Settings: Checks)
    # ==================================================================
    def _check_as_game(self, who, c, option, then) -> bool:
        """When the settings say so, a check the player makes is played as its minigame first; then(natural) or
        then(None) for the dice. False when it's dice anyway."""
        from game import minigames as M
        st = self._settings()
        game, category = M.game_for(option, "")
        if not M.wanted(st, category):
            return False
        from game import checks
        b = checks.bonus(self.world, who, c, option)[0]
        need = M.need_for(0, b)
        spec = M.Spec(game, need, slow=bool(st.get("minigame_slow", False)), seed=self.rng.randrange(1 << 30),
                      title=f"{who.get('name')}: {option.get('label')}", kind=str(option.get("label") or "").lower())
        self._play_minigame(spec, lambda perf: then(None if perf is None else M.natural_for(perf, need)))
        return True

    def api_setting(self, key: str = "", value=None) -> dict:
        """The browser version's own settings (kept in the browser): checks_mode, minigame_slow, react, and the
        sound's (web/sound.py VOLUMES)."""
        from web.sound import VOLUMES
        if key in ("checks_mode", "minigame_slow", "react", "minigame_kinds") or key in dict(VOLUMES):
            self._set(key, value)
            self._kept = True
        return {"settings": {k: self._settings().get(k, d) for k, d in (("checks_mode", "Dice"),
                                                                         ("minigame_slow", False), ("react", True))},
                "volumes": self._volumes()}

    # ==================================================================
    # A tavern's or casino's games
    # ==================================================================
    def _open_games(self, building) -> None:
        from game import tablegames as TG
        if building is None or not TG.games_at(self.world, building):
            return
        kind = TG.house_kind(self.world, building)
        lo, hi = TG.LIMITS.get(kind, (10, 500))

        def build(p: Panel) -> None:
            barred = TG.barred(self.state, building)
            p.text(f"Stakes {money_text(lo)} to {money_text(hi)} a hand. The house has "
                   f"{money_text(TG.bankroll(self.world, self.state, building))}.", "small")
            if barred:
                p.text(f"They won't let you play: {barred} more day{'s' if barred != 1 else ''}.", "gold")
            top = max(1, self.state.copper // 100)
            p.number("chips", "Buy chips (gp)", max(1, min(top, hi // 100 * 10, max(lo // 100 * 20, 1))),
                     max(1, lo // 100), top)
            for g in TG.games_at(self.world, building):
                def sit(p, g=g):
                    table = TG.sit(self.world, self.state, self.members, building, g, int(p.values.get("chips") or 1) * 100)
                    if table is None:
                        p.message = "You can't sit down to that."
                        return
                    p.closed = True
                    p.then = lambda: self._sit_down(table, lambda t: self._left_table(t))
                p.option(TG.GAMES[g].title, sit if not barred and self.state.copper >= lo else None,
                         TG.BLURB.get(g, ""), enabled=not barred and self.state.copper >= lo)
        self._panel(Panel(building.name, build, close="Not now"))

    def _left_table(self, table) -> None:
        from game import tablegames as TG
        TG.leave(self.world, self.state, self.members, table, self.bus)

    # ==================================================================
    # Festivals (game/townevents.py, game/contests.py)
    # ==================================================================
    def _open_festival(self, message: str = "") -> None:
        from game import contests as C
        from game import places
        from game import settlements as ST
        from game import townevents as TE
        f = TE.festival_here(self.world, self.state)
        town = places.current(self.world, self.state).town
        if f is None or town is None:
            return

        def build(p: Panel) -> None:
            p.text(f.highlights[:1].upper() + f.highlights[1:] + ".", "small")
            done = set(TE.entered(self.state, f))
            for cid in f.contests:
                info = C.CONTESTS[cid]
                got = C.entrant(self.world, self.state, self.members, cid)
                who = f"{got[0].get('name')} ({got[1]:+d})" if got else "nobody"
                mount = C.needs_mount(cid) and not C.has_mount(self.world, self.state, self.members)

                def enter(p, cid=cid):
                    p.closed = True
                    p.then = lambda: self._contest(f, town, cid)
                p.option(("✓ " if cid in done else "") + info["name"],
                         enter if cid not in done and not mount and got else None,
                         who + (" · needs a mount" if mount else "") + (" · done" if cid in done else ""))
            purse = C.PURSE.get(ST.tier_of(town), 25) * 100
            p.text(f"First place takes {money_text(purse)} (and sometimes a prize), second a third of that. Taking part "
                   f"pleases the town.", "small")
            pairs = [("Visit the stalls", lambda p: (setattr(p, "closed", True),
                                                      setattr(p, "then", lambda: self._festival_stalls(town))), "")]
            if f.god:
                pairs.append(("The temple's blessing", lambda p: (setattr(p, "closed", True),
                                                                   setattr(p, "then", lambda: self._festival_bless(f, town))),
                              ""))
            p.buttons(*pairs)
        pnl = Panel(f"{f.name} in {town.name}", build)
        pnl.message = message
        self._panel(pnl)

    def _contest(self, f, town, cid: str) -> None:
        from game import contests as C
        from game import minigames as M
        from game import townevents as TE
        TE.enter_contest(self.world, self.state, f, cid)
        who, b = C.entrant(self.world, self.state, self.members, cid)
        need = C.need_for(town, f.key, cid, b)

        def after(perf):
            self.state.advance(30, "the contest")
            C.roll(self.world, self.state, self.members, town, f.key, cid, perf, self.rng, self.bus)
            self._open_festival()
        st = self._settings()
        if M.wanted(st, C.category(cid)):
            spec = M.Spec(C.CONTESTS[cid]["game"], need, slow=bool(st.get("minigame_slow", False)),
                          seed=self.rng.randrange(1 << 30), title=f"{who.get('name')}: {C.CONTESTS[cid]['name']}")
            self._play_minigame(spec, after)
        else:
            after(None)

    def _festival_stalls(self, town) -> None:
        from game import places
        from game import trade as TR
        from game import townevents as TE
        npc = next((n for b in places.buildings_in(self.world, town) for n in
                    (self.world.entities.get(x) for x in b.fields.get("npcs") or [])
                    if n is not None and TR.is_merchant(self.world, n) and TE.festival_stock(self.world, self.state, n)),
                   None)
        if npc is not None:
            self._open_trade(npc.id)

    def _festival_bless(self, f, town) -> None:
        from game import places
        from game import townevents as TE
        temple = next((b for b in places.buildings_in(self.world, town) if (b.fields.get("kind") or "") == "Temple"), None)
        if temple is not None:
            places.enter(self.world, self.state, temple.id, self.bus)
        TE.bless(self.world, self.state, self.members, f, self.bus)

    # ==================================================================
    # An arena: tournaments and bouts (game/arena.py)
    # ==================================================================
    def _open_arena_house(self, arena_b) -> None:
        from game import arena as AR
        if arena_b is None:
            return

        def build(p: Panel) -> None:
            s, a = self.state, arena_b
            e = AR.entry(s, a)
            ok, why = AR.can_sign(self.world, s, a)
            if e:
                p.text(f"You're in the tournament: {e['won']} of {len(e['fights'])} fights won.")
            elif AR.is_tournament_day(a, s.day):
                p.text(f"Tournament today! Entry {money_text(AR.entry_fee(self.members))}. " + ("" if ok else why) +
                       " Every fight is Hard or Deadly, built for your party; nobody dies, and you're healed afterwards.")
            else:
                p.text(f"The next tournament is on day {AR.next_day(a, s.day)} (today is day {s.day}).")
            titles = AR.titles(s)
            if titles:
                p.text("Your titles: " + ", ".join(titles) + ".", "gold")
            bracket = AR.preview(self.world, s, a, self.members) if (e or AR.is_tournament_day(a, s.day)) else []
            for i, f in enumerate(bracket):
                done = e and i < e["won"]
                n = sum(int(r.get("count") or 1) for r in f["rows"])
                what = self.world.entities.get(f["rows"][0]["id"])
                p.option(("✓ " if done else "") + f"Fight {i + 1}: {f['name']}", None,
                         f"{n} x {what.name if what else '?'}  ·  {f['difficulty']}",
                         desc=AR.statblock(self.world, what) if what is not None else "")
            pairs = []
            if not e and ok and AR.is_tournament_day(a, s.day):
                pairs.append(("Sign up", lambda p: setattr(p, "message", AR.sign_up(self.world, self.state, a,
                                                                                      self.members, self.bus)[1]), "primary"))
            if e:
                pairs.append(("Fight the next bout", lambda p: (setattr(p, "closed", True),
                                                                 setattr(p, "then", lambda: self._tournament_fight(a))),
                              "primary"))
            if pairs:
                p.buttons(*pairs)
            c = AR.card(self.world, s, a)
            ea, eb = self.world.entities.get(c["a"]), self.world.entities.get(c["b"])
            p.head("On the sand now")
            p.text(f"{ea.name} (pays {c['odds_a']:.2f} to 1) against {eb.name} (pays {c['odds_b']:.2f} to 1).")
            p.number("stake", "Stake", 10, 1, 2000, " gp")

            def bet(p, side):
                r = AR.bet(self.world, self.state, a, side, int(p.values.get("stake") or 10), bus=self.bus)
                p.message = r["lines"][-1] if r["lines"] else ""
            p.buttons((f"Bet on {ea.name}", lambda p: bet(p, "a"), ""), (f"Bet on {eb.name}", lambda p: bet(p, "b"), ""))
        self._panel(Panel(arena_b.name, build, close="Leave"))

    def _tournament_fight(self, a) -> None:
        from game import arena as AR
        f = AR.next_fight(self.state, a)
        if f is None:
            return
        self.tournament = a.id
        self._fx("cheer", 0.8)
        self.say("place", f"The arena: {f['name']}")
        self._start_fight(f["rows"], "arena", "", then=lambda outcome: self._tournament_bout(a, outcome == "victory"),
                          style="Stone", foe_cells=False)

    def _tournament_bout(self, a, won: bool) -> None:
        from game import arena as AR
        self.tournament = ""
        r = AR.bout_done(self.world, self.state, a, self.members, won, self.rng, self.bus)
        self.say("loot" if r["status"] == "won" else "narration", r["text"])
        if r["status"] in ("won", "next"):
            self._fx("cheer", 0.8)
        if r["status"] == "next":
            self._open_arena_house(a)


__all__ = ["Games"]
