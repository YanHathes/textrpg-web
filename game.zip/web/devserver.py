"""Try the browser version on a computer, without Pyodide: this serves the page and answers its calls from
normal Python (the same web/bridge.py the browser runs). For working on the page, and for the tests.

    python web/devserver.py [--port 8000] [--data FOLDER]       then open http://localhost:8000

FOLDER holds the worlds and saves (data/web by default); the first world is made (or copied from
bundled/worlds) the first time.
"""
from __future__ import annotations

import json
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def make_server(port: int, data: Path, site: Path | None = None):
    from tools.build_web import assets, sound_index
    from web.bridge import Session
    site = Path(site or tempfile.mkdtemp(prefix="textrpg-web-"))
    assets(site)
    (site / "rpc-mode.json").write_text(json.dumps({"mode": "server"}))
    (site / "site.json").write_text(json.dumps({"url": "", "qr": False}))
    sounds = ROOT / "game" / "sounds"                # the sounds as they are (.wav), straight from the game
    (site / "sounds").mkdir(exist_ok=True)
    (site / "sounds" / "index.json").write_text(json.dumps(sound_index(sounds, "wav")))
    one = ThreadPoolExecutor(max_workers=1)        # every call on the same one thread, as in the browser's
    session = one.submit(Session, data, True).result()   # worker (the game's databases stay on their thread)

    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *a, **k):
            super().__init__(*a, directory=str(site), **k)

        def log_message(self, *a):                  # quiet
            pass

        def translate_path(self, path):
            if path.startswith("/sounds/") and not path.startswith("/sounds/index.json"):
                rel = path.split("?", 1)[0][len("/sounds/"):]
                f = (sounds / rel).resolve()
                if sounds.resolve() in f.parents:
                    return str(f)
            return super().translate_path(path)

        def end_headers(self):
            self.send_header("Cache-Control", "no-store")
            super().end_headers()

        def do_POST(self):  # noqa: N802 - http.server's name
            if self.path != "/rpc":
                self.send_error(404)
                return
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
            out = one.submit(session.call, body.get("name", ""), body.get("args") or {}).result()
            data = json.dumps(out).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.run = lambda fn: one.submit(fn).result()     # (for tests: something done on the game's thread)
    return server, session


def main(argv: list[str]) -> int:
    port = int(argv[argv.index("--port") + 1]) if "--port" in argv else 8000
    data = Path(argv[argv.index("--data") + 1]) if "--data" in argv else ROOT / "data" / "web"
    server, _session = make_server(port, data)
    print(f"The browser version: http://localhost:{port}   (Ctrl+C to stop)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
