"""The browser version, stage 3: fights. The battle itself is the game's (game/combat/engine.py), set up and
settled as in the app (game/fightflow.py), with the same buttons (game/battlepages.py, shown as the phone
app's four tabs: Action, Move, Bonus, End turn). The page draws the field and paces the enemies' turns:

    fight()                    everything the battle screen shows (see _fight_json)
    fight_pics()               the field's pictures (the ground, the tree tops, the ground in grey), once a fight
    fight_sprites(keys)        [[combatant id, facing], ...] -> their pictures
    fight_tab(key)             Action, Move, Bonus or End turn
    fight_pick(index)          a button on the open page;  fight_back()
    fight_end(sure)            end the turn (asks first, as the app does)
    fight_cell(x, y)           a square tapped: move there, aim there, or attack who's there
    fight_ai()                 one step of whoever the computer plays (the page calls it until it's the
                               party's turn again, showing each step)
    fight_done(skin)           after the end: what it changed kept, the rewards, then back to the map

Reactions (an opportunity attack, a Shield spell) can't wait for a tap in the middle of an enemy's move, so
they're taken by themselves when the "react" setting is on (the app asks), and let go when it's off.
"""
from __future__ import annotations


from web.scene import png64

FLOAT_COLOURS = {"damage": "#e05a48", "heal": "#7ccf6a", "miss": "#c8c0b0", "crit": "#f0c040"}


class Fights:
    """Mixed into web.bridge.Session."""

    fight = None                      # game.fightflow.Fight under way
    fstate: dict = {}

    # ==================================================================
    # Starting one
    # ==================================================================
    def _start_fight(self, rows: list, environment: str = "plains", text: str = "", then=None, size=None,
                     style: str = "", time: str | None = None, bmap=None, allies=None, foe_cells=None,
                     seen=None) -> bool:
        from game import weather
        from game.combat import lighting
        from game.battlesetup import map_size_for
        from game.fightflow import Fight
        if self.fight is not None:
            return False
        self.close_menus()
        if bmap is None and foe_cells is not False:
            bmap = self._site_map(foe_cells)
        if bmap is not None:
            environment = bmap.environment
        underground = environment in ("dungeon", "cave", "dungeon_room")
        if time is None:
            time = "Night" if underground else lighting.light_time(self.state.minutes,
                                                                    weather.here(self.world, self.state))
        sw, sh = self._screen_px()
        size = tuple(size) if isinstance(size, (tuple, list)) else map_size_for(sw, sh, size or "fit")
        f = Fight.prepare(self.world, self.state, self.members, rows, environment, size, style=style, time=time,
                          bmap=bmap, allies=allies, rng=self.rng, bus=self.bus)
        if isinstance(f, str):
            self.say("system", f"The fight can't start: {f}")
            return False
        f.seen = list(seen or [])
        self.fight = f
        self.fstate = {"page": "main", "mode": "idle", "pending": None, "confirming": False, "ai": None,
                       "then": then, "moves": {}, "floats": [], "lines": [], "said": [], "aim": None,
                       "ended": False, "pics": None, "n": 0, "keys": {}, "info": ""}
        b = f.battle
        b.on_event = self._fight_event
        b.ask_reaction = None if self._settings().get("react", True) else (lambda *a: None)
        if text:
            self.say("damage", text)
        self.say("place", "Battle")
        names = ", ".join(c.name for c in b.combatants if c.team == "enemy")
        self.say("damage", f"A fight breaks out against {names}!")
        if self.book is not None:
            self.book.counting = True
        b.start()
        return True

    def _screen_px(self) -> tuple[int, int]:
        s = getattr(self, "screen", None) or {}
        return int(s.get("w") or 412), int(s.get("h") or 420)

    def api_screen(self, w: int = 412, h: int = 420) -> dict:
        """How big the page's map half is (the battle map is fitted to it, as in the app)."""
        self.screen = {"w": int(w), "h": int(h)}
        return {"ok": True}

    def _site_map(self, foe_cells=None):
        """On the walking map, the fight happens right where the party stands."""
        ex = self.ex
        if ex is None or ex.area is None or ex.travelling() == "voyage":
            return None
        from game import battlesite
        try:
            return battlesite.battle_map_here(ex, foe_cells)
        except Exception as exc:  # noqa: BLE001 - a made-up map will do
            self.say("system", f"(Couldn't use the map here for the fight: {exc})")
            return None

    def close_menus(self) -> None:
        self.menu, self.menu_kind, self.prompt = None, "", None

    def _encounter(self, found: dict, then=None) -> bool:
        """A fight out in the world (found: rows, text, environment, foe_cells, map_size, style, allies)."""
        return self._start_fight(found.get("rows") or [], found.get("environment") or "plains",
                                 found.get("text") or "You're attacked!", then, size=found.get("map_size"),
                                 style=found.get("style") or "", bmap=found.get("bmap"), allies=found.get("allies"),
                                 foe_cells=found.get("foe_cells"))

    def _fight_npc(self, npc_id: str) -> bool:
        """Drawing steel on someone (Interact on them, or Fight in a talk)."""
        from game import law, places
        npc = self.world.entities.get(npc_id)
        if npc is None:
            return False
        cells = [(t.x, t.y) for t in self.ex.tokens if t.entity == npc.id] if self.ex is not None else None
        try:
            seen = law.onlookers(self.world, self.state, self.ex, self.rng, exclude=(npc.id,))
        except Exception:  # noqa: BLE001 - nobody saw
            seen = []
        self.say("damage", f"You draw your weapon on {npc.name}.")
        spot = places.current(self.world, self.state)
        row = places.room_here(spot)
        size, style = None, ""
        if row is not None:
            from game import rooms as R
            size = R.battle_size(row)
            style = (spot.building.fields.get("interior") or "Stone") if spot.building is not None else "Stone"
        bmap = self._site_map(cells or None)
        return self._start_fight([{"id": npc.id, "count": 1}], bmap.environment if bmap is not None else "interior",
                                 "", size=size, style=style, bmap=bmap, seen=seen, foe_cells=False)

    # ==================================================================
    # What the battle says
    # ==================================================================
    def _fight_event(self, name: str, **data) -> None:
        fs = self.fstate
        if name == "combat.log":
            self.say(data["kind"], data["text"])
            fs["said"] = (fs["said"] + [data["text"]])[-2:]
        elif name == "combat.damage":
            amount = data.get("amount", 0)
            fs["floats"].append({"id": data["target"].id, "text": f"-{amount}" if amount else "0",
                                 "colour": FLOAT_COLOURS["damage"]})
        elif name == "combat.heal":
            fs["floats"].append({"id": data["target"].id, "text": f"+{data['amount']}", "colour": FLOAT_COLOURS["heal"]})
        elif name == "combat.attack" and not data.get("hit"):
            fs["floats"].append({"id": data["target"].id, "text": "miss", "colour": FLOAT_COLOURS["miss"]})
        elif name == "combat.attack" and data.get("crit"):
            fs["floats"].append({"id": data["target"].id, "text": "CRIT!", "colour": FLOAT_COLOURS["crit"]})
        elif name == "combat.moved":
            c = data["combatant"]
            fs["moves"].setdefault(c.id, []).append([c.x, c.y])
        elif name == "combat.summoned":
            s = data["combatant"]
            if data.get("sprite") is not None and self.fight is not None:
                self.fight.sprites[s.id] = data["sprite"]
        self.bus.emit(name, **{k: v for k, v in data.items() if k != "battle"})   # the mechanics hear it too

    # ==================================================================
    # The screen
    # ==================================================================
    def _mine(self):
        f = self.fight
        if f is None or self.fstate.get("ended"):
            return None
        b = f.battle
        c = b.current
        from game.combat.engine import PLAYER
        return c if c is not None and c.team == PLAYER and c.active and not b.outcome else None

    def api_fight(self) -> dict:
        return self._fight_json()

    def _fight_json(self) -> dict:
        from game import handheld as H
        from game.battlepages import budget_text, build_pages, condition_word
        from game.combat import conditions as CND
        from game.combat.engine import PLAYER
        f, fs = self.fight, self.fstate
        if f is None:
            return {"fight": None, "view": self.api_view()}
        b = f.battle
        cur = b.current
        mine = self._mine()
        units = []
        sight = self._sight()
        dark = sight is not None
        for c in b.combatants:
            if c.fled:
                continue
            hidden = c.team == "enemy" and dark and all(sight.get(cell, (2, False))[0] == 0 for cell in c.cells())
            if c.team == "enemy":
                tip = f"{c.name}\n{condition_word(c)}"
            else:
                tip = f"{c.name}\nHP {c.hp}/{c.max_hp}   AC {c.ac}   Speed {c.speed * 5} ft" + \
                      (f"\n{CND.summary(c)}" if c.conditions else "")
            units.append({"id": c.id, "name": c.name, "team": c.team, "x": c.x, "y": c.y, "size": c.size,
                          "hp": c.hp, "max": c.max_hp, "alive": bool(c.alive), "facing": c.facing,
                          "current": c is cur, "hidden": hidden, "tip": tip,
                          "sprite": bool(f.sprites.get(c.id) is not None)})
        from game.combat import wreck
        out = {"round": b.round, "w": b.map.w, "h": b.map.h, "units": units, "current": cur.id if cur else "",
               "field": wreck.version(b.map),
               "mine": mine is not None, "outcome": b.outcome or "", "order": [
                   {"id": c.id, "name": c.name, "team": c.team, "alive": bool(c.alive)} for c in b.order if not c.fled],
               "reach": [], "targets": [], "area": None, "status": "", "hint": "", "tabs": [], "menu": None,
               "info": None, "said": list(fs["said"]), "floats": fs["floats"], "moves": fs["moves"],
               "dark": self._dark_json(sight)}
        fs["floats"], fs["moves"] = [], {}
        if b.outcome or fs.get("ended"):
            out["end"] = self._end_json()
            return {"fight": out, "view": self.api_view()}
        if mine is None:
            if cur is not None and cur.team == PLAYER and (cur.dying or cur.hp <= 0):
                state = "stable" if cur.stable else f"dying ({cur.death_saves[0]} saves, {cur.death_saves[1]} fails)"
                out["info"] = {"title": cur.name, "text": f"Unconscious, {state}.", "back": "", "go": ""}
            else:
                out["info"] = {"title": cur.name if cur else "", "text": "Their turn…", "back": "", "go": ""}
            out["ai"] = True
            out["status"] = f"Round {b.round}"
            return {"fight": out, "view": self.api_view()}
        c = mine
        mode, pending = fs["mode"], fs["pending"]
        if mode == "move" and c.movement_left() > 0:
            cells = set()
            for (px, py) in b.reachable(c):
                cells.update(c.cells(px, py))
            out["reach"] = sorted(cells)
        elif mode == "attack" and pending is not None:
            from game.combat import wreck
            out["targets"] = [o.id for o in b.targets_for(c, pending)]
            out["things"] = wreck.targets(b, c, pending)            # walls, trees and the like to break
        elif mode == "spell" and pending is not None and not pending[0].targets_cell:
            out["targets"] = [o.id for o in b.spell_targets(c, pending[0])]
        elif mode == "feature" and pending is not None:
            out["targets"] = [o.id for o in b.feature_targets(c, pending[0])]
        if fs.get("aim") is not None:
            spell = self._area_spell(c)
            if spell is not None:
                x, y = fs["aim"]
                cells = set(c.cells(x, y)) if spell.effect == "Teleport" else b.area_cells(c, spell, x, y)
                ok = b._aim_ok(c, spell, None, (x, y)) if spell.effect == "Teleport" else \
                    b.distance_to_cell(c, x, y) <= b.area_reach(c, spell)
                out["area"] = {"cells": sorted(cells), "ok": bool(ok), "at": [x, y]}
        pages = build_pages(b, c, mode, pending)
        fs["pages"] = pages
        tabs = H.combat_tabs(pages, fs["page"], True)
        on = "end" if fs["confirming"] else H.tab_of(pages, fs["page"])
        out["tabs"] = [{"id": t["id"], "label": t["label"], "sub": t["sub"], "enabled": t["enabled"],
                        "on": t["id"] == on} for t in tabs]
        out["status"] = f"{c.name}  ·  {c.hp_text()} HP"
        out["budget"] = budget_text(c)
        if fs["confirming"]:
            left = [t["label"] + " " + t["sub"] for t in tabs if t["id"] in ("move", "bonus") and t["enabled"]]
            out["info"] = {"title": "End the turn?", "text": ("You still have: " + ", ".join(left) + ".") if left
                           else "Nothing left to do this turn.", "back": "Keep going", "go": "End turn"}
        elif fs["page"] == "move":
            out["info"] = {"title": "Move", "text": f"Tap a lit square on the map to move there "
                           f"({c.movement_left() * 5} ft left).", "back": "Done", "go": ""}
        elif fs["page"] == "target":
            title = (pages.get("target") or {}).get("title") or "Choose a target"
            text = ("Tap where to aim it; tap the same square again to cast." if self._area_spell(c)
                    else "Tap who to target on the map (or a wall, tree or thing to break)." if mode == "attack"
                    else "Tap who to target on the map.")
            out["info"] = {"title": title, "text": text, "back": "Cancel", "go": ""}
        else:
            page = "actions" if fs["page"] == "main" else fs["page"]
            m = H.combat_menu(pages, page, True)
            out["menu"] = {"title": m.title, "back": page not in ("actions", "main", "bonus"),
                           "choices": [{"label": ch.label, "note": ch.note, "desc": ch.desc, "enabled": ch.enabled}
                                       for ch in m.choices]}
            fs["menu_page"] = page
        if c.conditions and not CND.can_act(c):
            out["hint"] = f"{c.name} can't act this turn ({CND.summary(c)}). End the turn to continue."
        elif b.turn_spent(c) and not fs["confirming"]:
            out["hint"] = "Nothing left but moving. End your turn when you're ready."
        return {"fight": out, "view": self.api_view()}

    def _sight(self):
        """What the party can see of each square, (light level, grey), or None in full light."""
        b = self.fight.battle
        light = b.light
        light.update_carried(b.combatants)
        if light.ambient == 2:
            return None
        viewers = [c for c in b.combatants if c.team == "player" and c.alive and not c.fled]
        out = {(x, y): light.party_view(viewers, x, y) for y in range(b.map.h) for x in range(b.map.w)}
        if not any(lvl < 2 or grey for lvl, grey in out.values()):
            return None
        return out

    def _dark_json(self, sight):
        """The dark, square by square: a letter each (0 dark, 1 dim, 2 lit; G/g for grey sight), and the lights."""
        if sight is None:
            return None
        b = self.fight.battle
        rows = []
        for y in range(b.map.h):
            rows.append("".join(("g" if lvl == 1 else "G") if grey and lvl else str(lvl)
                                for lvl, grey in (sight[(x, y)] for x in range(b.map.w))))
        lights = []
        for src in b.light.all_sources():
            lights.append({"x": src.x, "y": src.y, "bright": src.bright, "colour": src.color, "owner": src.owner or ""})
        return {"rows": rows, "lights": lights}

    def api_fight_pics(self) -> dict:
        """The field: the ground, the tree tops over everyone, and the ground in grey (seen by darkvision)."""
        b = self.fight.battle
        art = b.map.render(include_tall=False)
        grey = art.copy()
        for i, px in enumerate(grey.px):
            if px is not None:
                g = int((px[0] * 0.3 + px[1] * 0.59 + px[2] * 0.11) * 0.7)
                grey.px[i] = (g, g, g, 255)
        return {"bg": png64(art), "tall": png64(b.map.render_tall()), "grey": png64(grey), "w": b.map.w, "h": b.map.h}

    def api_fight_sprites(self, keys: list) -> dict:
        """[[combatant id, facing], ...] -> {"id@facing": png}"""
        out = {}
        sprites = self.fight.sprites if self.fight is not None else {}
        for cid, facing in keys:
            canvas = sprites.get(cid)
            if canvas is None:
                out[f"{cid}@{facing}"] = ""
                continue
            if getattr(canvas, "views", None):
                from game.art.folk import facing as face
                c = face(canvas, int(facing) % 4, 0)
            else:
                c = canvas.rotated(int(facing)) if facing else canvas
            out[f"{cid}@{facing}"] = png64(c)
        return out

    # ==================================================================
    # The party's turn
    # ==================================================================
    def api_fight_tab(self, key: str = "") -> dict:
        from game import handheld as H
        c, fs = self._mine(), self.fstate
        if c is None:
            return self._fight_json()
        pages = fs.get("pages") or {}
        if fs["page"] in ("move", "target") and key != H.tab_of(pages, fs["page"]):
            self._fight_action("cancel", None)
        t = {x["id"]: x for x in H.combat_tabs(fs.get("pages") or {}, fs["page"], True)}.get(key) or {}
        if not t.get("enabled"):
            return self._fight_json()
        fs["confirming"] = False
        if key == "action":
            self._go("actions")
        elif key == "bonus":
            self._go("bonus")
        elif key == "move":
            name, payload = (t["entry"].get("action") or ("move", None))
            self._fight_action(name, payload)
        elif key == "end":
            fs["confirming"] = True
        return self._fight_json()

    def _go(self, page: str) -> None:
        fs = self.fstate
        fs["page"] = page if page in (fs.get("pages") or {}) or page in ("move", "target", "main") else "main"
        fs["confirming"] = False

    def api_fight_pick(self, index: int = 0) -> dict:
        from game import handheld as H
        fs = self.fstate
        if self._mine() is None:
            return self._fight_json()
        m = H.combat_menu(fs.get("pages") or {}, fs.get("menu_page") or "actions", True)
        if not (0 <= index < len(m.choices)) or not m.choices[index].enabled:
            return self._fight_json()
        entry = m.choices[index].action or {}
        if entry.get("page"):
            self._go(entry["page"])
        elif entry.get("action"):
            name, payload = entry["action"]
            self._fight_action(name, payload)
        return self._fight_json()

    def api_fight_back(self) -> dict:
        fs = self.fstate
        if self._mine() is None:
            return self._fight_json()
        if fs["confirming"]:
            fs["confirming"] = False
        elif fs["page"] in ("move", "target"):
            self._fight_action("cancel", None)
        else:
            parent = ((fs.get("pages") or {}).get(fs["page"]) or {}).get("parent")
            self._go(parent if parent and parent != "main" else "main")
        return self._fight_json()

    def api_fight_end(self, sure: bool = True) -> dict:
        c = self._mine()
        if c is not None and sure:
            self.fstate.update(mode="idle", pending=None, confirming=False, page="main", aim=None)
            self._end_turn()
        return self._fight_json()

    def _end_turn(self) -> None:
        b = self.fight.battle
        self.fstate["ai"] = None
        if not b.outcome:
            b.end_turn()

    def _fight_action(self, name: str, payload) -> None:
        """As the app's battle controller does with a button (ui/battle/controller.py)."""
        c = self._mine()
        if c is None:
            return
        b, fs = self.fight.battle, self.fstate
        fs["aim"] = None
        if name == "move":
            fs.update(mode="move", pending=None, page="move")
        elif name == "attack":
            fs.update(mode="attack", pending=payload, page="target")
        elif name == "cast":
            spell, slot = payload
            if spell.self_only:
                self._do(lambda: b.cast(c, spell, target=c, slot=slot))
                return
            fs.update(mode="spell", pending=(spell, slot), page="target")
        elif name == "feature":
            feature, option = payload
            if b.feature_needs_aim(c, feature):
                fs.update(mode="feature", pending=(feature, option), page="target")
            else:
                self._do(lambda: b.use_feature(c, feature, option))
        elif name == "item":
            self._do(lambda: b.use_item(c, payload))
        elif name == "stabilize":
            self._do(lambda: b.stabilize(c, payload))
        elif name in ("grapple", "shove", "push", "help"):
            fn = {"grapple": lambda: b.grapple(c, payload), "shove": lambda: b.shove(c, payload),
                  "push": lambda: b.shove(c, payload, push=True), "help": lambda: b.help(c, payload)}[name]
            self._do(fn)
        elif name in ("hide", "escape", "dash", "dodge", "disengage", "flee"):
            self._do(lambda: getattr(b, name)(c))
        elif name == "end":
            fs.update(mode="idle", pending=None, page="main", confirming=False)
            self._end_turn()
        elif name == "cancel":
            fs.update(mode="idle", pending=None, page="main")

    def _do(self, fn) -> None:
        """An action done: stay on for more of the same (more attacks, more squares to walk), else back."""
        b, fs = self.fight.battle, self.fstate
        c = b.current
        fn()
        stay = ((fs["mode"] == "attack" and fs["pending"] is not None and not fs["pending"].offhand
                 and c.attacks_left > 0) or (fs["mode"] == "move" and c.movement_left() > 0))
        if not stay:
            fs.update(mode="idle", pending=None, page="main")
        fs["aim"] = None

    def _area_spell(self, c):
        fs, b = self.fstate, self.fight.battle
        if fs["mode"] == "spell" and fs["pending"] is not None and fs["pending"][0].targets_cell:
            return fs["pending"][0]
        if fs["mode"] == "feature" and fs["pending"] is not None:
            spell = b.feature_spell(c, fs["pending"][0])
            if spell is not None and spell.targets_cell:
                return spell
        return None

    def api_fight_cell(self, x: int = 0, y: int = 0) -> dict:
        c = self._mine()
        if c is None:
            return self._fight_json()
        b, fs = self.fight.battle, self.fstate
        other = b.at(x, y)
        mode, pending = fs["mode"], fs["pending"]
        if mode == "attack" and pending is not None:
            from game.combat import wreck
            if other is not None and other in b.targets_for(c, pending):
                self._do(lambda: b.attack(c, pending, other))
            elif other is None and (x, y) in wreck.targets(b, c, pending):     # a wall, a tree, a table
                self._do(lambda: wreck.attack(b, c, pending, (x, y)))
        elif mode in ("spell", "feature") and pending is not None:
            spell = self._area_spell(c)
            if spell is not None:                                 # tap to aim, tap the same square to let it go
                if fs.get("aim") == (x, y) and b._aim_ok(c, spell, None, (x, y)):
                    if mode == "spell":
                        self._do(lambda: b.cast(c, spell, cell=(x, y), slot=pending[1]))
                    else:
                        self._do(lambda: b.use_feature(c, pending[0], pending[1], cell=(x, y)))
                else:
                    fs["aim"] = (x, y)
            elif mode == "spell" and other is not None and other in b.spell_targets(c, pending[0]):
                self._do(lambda: b.cast(c, pending[0], target=other, slot=pending[1]))
            elif mode == "feature" and other is not None and other in b.feature_targets(c, pending[0]):
                self._do(lambda: b.use_feature(c, pending[0], pending[1], target=other))
        elif mode == "move":
            pos = (x, y) if c.size == 1 else (x - c.size // 2, y - c.size // 2)
            if pos in b.reachable(c) and pos != (c.x, c.y):
                self._do(lambda: b.move(c, pos))
        elif other is not None:                                   # (nothing picked): who's that?
            out = self._fight_json()
            u = next((u for u in out["fight"]["units"] if u["id"] == other.id), None)
            if u is not None and not u["hidden"]:
                out["fight"]["tip"] = u["tip"]
            return out
        return self._fight_json()

    # ==================================================================
    # The computer's turns
    # ==================================================================
    def api_fight_ai(self) -> dict:
        from game.combat.engine import PLAYER
        f, fs = self.fight, self.fstate
        if f is None:
            return self._fight_json()
        b = f.battle
        if b.outcome or self._mine() is not None:
            return self._fight_json()
        c = b.current
        if c is None:
            return self._fight_json()
        if c.team == PLAYER and (c.dying or c.hp <= 0):            # down: the death save was rolled; on we go
            self._end_turn()
            return self._fight_json()
        if fs.get("ai") is None or fs.get("ai_for") != (c.id, b.round):
            fs["ai"], fs["ai_for"] = b.ai_turn(c), (c.id, b.round)
        try:
            step = next(fs["ai"])
        except StopIteration:
            fs["ai"] = None
            self._end_turn()
            step = "end"
        out = self._fight_json()
        out["fight"]["step"] = step
        return out

    # ==================================================================
    # The end
    # ==================================================================
    def _end_json(self) -> dict:
        f, fs = self.fight, self.fstate
        if not fs.get("ended"):
            fs["ended"] = True
            f.outcome_rewards(f.battle.outcome or "fled")
            fs["skin"] = f.skinnable() if f.battle.outcome == "victory" else 0
        outcome = f.battle.outcome or "fled"
        title = {"victory": "Victory!", "defeat": "Defeat", "fled": "Escaped"}.get(outcome, "Battle over")
        lines = []
        if outcome == "victory":
            lines.append("The battle is won.")
        elif outcome == "defeat":
            lines.append("Your party has fallen.")
            if (self.world.rules.get("party_falls") or "Wake up in town") == "Wake up in town":
                lines.append("Darkness takes you...")
        else:
            lines.append("You got away.")
        fallen = f.fallen()
        if fallen and getattr(self, "tournament", ""):
            fallen_text = "Out of the fight: " + ", ".join(fallen) + ". (Nobody dies in the arena.)"
        else:
            fallen_text = ("Killed: " + ", ".join(fallen) + ". A temple may be able to raise them.") if fallen else ""
        return {"title": title, "outcome": outcome, "lines": lines, "gains": f.reward_lines(),
                "fallen": fallen_text,
                "skin": fs.get("skin", 0)}

    def api_fight_done(self, skin: bool = False) -> dict:
        from game import party as P
        f, fs = self.fight, self.fstate
        if f is None:
            return self.api_view()
        if not fs.get("ended"):
            self._end_json()
        outcome = f.battle.outcome or "fled"
        f.settle(outcome, self.book, self.bus, self.rng)
        from game.combat import wreck                    # what the fight broke, kept on the walking map
        for line in wreck.write_back(self.ex, f.battle.map):
            self.say("damage", line)
        if skin and fs.get("skin"):
            if (f.skin(self.members, self.rng, self.bus) or {}).get("minutes"):
                self._fx("rustle", 0.6)
        if outcome == "victory":
            f.give_rewards(self.bus)
        P.save(self.world, self.members)
        self.state.save()
        then = fs.get("then")
        self.fight, self.fstate = None, {}
        self.ex.sync()
        self._party_sprite()
        out: dict = {}
        if outcome == "defeat" and not getattr(self, "tournament", ""):   # (nobody dies in the arena)
            out = self._party_fell()
        elif then is not None:
            then(outcome)
        if outcome == "victory":
            self.api_save()
        v = self.api_view()
        v.update(out)
        return v

    def _party_fell(self) -> dict:
        """The whole party is down: what happens is the world's 'party falls' rule."""
        from game import condition, saves
        from game import jail
        if jail.jailed(self.state):                     # beaten getting out of jail: back in the cell
            self.say("narration", jail.recaptured(self.world, self.state, self.members, self.ex, self.bus))
            self.api_save()
            return {}
        from game import thieves
        if thieves.mugging(self.state):                 # beaten by muggers: robbed, and you come to where you fell
            for line in thieves.beaten(self.world, self.state, self.members, self.rng):
                self.say("damage", line)
            self.api_save()
            return {}
        falls = self.world.rules.get("party_falls") or "Wake up in town"
        if falls == "Wake up in town":
            condition.knocked_out(self.world, self.state, self.members, self.bus)
            from game import bank
            bank.fell(self.world, self.state, self.bus)
            self.ex.sync()
            self.api_save()
            return {}
        hardcore = falls == "Hardcore"
        if hardcore:
            saves.wipe_run(self.world)
        self._keep_play()
        return {"game_over": {"hardcore": hardcore, "can_load": not hardcore and bool(saves.list_saves(self.world)),
                              "text": "Your party has fallen. This world plays Hardcore: the run is over." if hardcore
                              else "Your party has fallen."}}

    def api_game_over(self, choice: str = "new", slot: str = "") -> dict:
        """After the party falls for good: "load" a save, or "new" (a new party: the main menu's New game)."""
        from game import saves
        if choice == "load" and slot:
            return self.api_load(slot)
        if not saves.hardcore(self.world):
            saves.new_run(self.world)
        self._keep_play()
        return {"menu": True}


__all__ = ["Fights"]
