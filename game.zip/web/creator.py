"""The browser version, stage 3: making characters, and what comes after (the app's ui/character_creator.py,
ui/levelup_dialog.py, ui/choices_dialog.py, the look editor ui/appearance.py, the welcome to a new game, and
the Spells tab of a hero's window). The rules are the game's (game/character.py); this holds what's been
picked so far, page by page, as plain JSON for the page.

    creator(do, ...)     do: "start", "set" (what, value), "go" (step: 1 or -1), "cancel"
    party_new(how)       "quick": the ready-made heroes; "begin": the adventure starts
    look(do, ...)        a hero's look: "open" (member), "set" (key, value), "random", "save", "cancel"
    levelup(do, ...)     "open" (member), "set" (what, value), "roll", "apply", "cancel"
    choices(do, ...)     "open" (member), "toggle" (feature, option), "save"
    spells(member, do)   preparing spells; casting one outside a fight
"""
from __future__ import annotations

import random

from game import character as CH
from web.scene import png64

PAGES = ["Race", "Class", "Ability scores", "Background & skills", "Equipment", "Spells", "Name & look", "Summary"]
EYE_COLORS = ["#1e1a20", "#3a6ad0", "#3a8a4a", "#7a4a2a", "#f0c040", "#d03a3a", "#a070e0", "#e8e8e8"]
CLOTHES_COLORS = ["#5b6b4e", "#4d5f7a", "#7a4b33", "#6a2a3a", "#3b2f4a", "#8a7a5a", "#2e2e34", "#a8a090"]
KIND_WORDS = {"Features": "options", "Skill proficiency": "skills to become proficient in",
              "Skill expertise": "skills for expertise (double proficiency)", "Spells": "spells to learn"}


# ======================================================================
# A look (ui/appearance.py, without Qt)
# ======================================================================
def look_base(world, race_id: str, value: dict) -> str:
    if value.get("base"):
        return value["base"]
    race = world.entities.get(race_id or "")
    return ((race.fields.get("appearance") or {}).get("base") if race else None) or "human"


def look_fields(world, race_id: str, value: dict) -> list[dict]:
    """What can be changed about a body, as the app's look editor offers it."""
    from game.art import creatures as CR
    from game.art.humanoid import BEARD_STYLES, BODY_BASES, HAIR_STYLES
    base = look_base(world, race_id, value)
    v = value
    out = []
    if base in CR.CREATURE_BASES:
        cb = CR.CREATURE_BASES[base]
        out.append({"key": "skin", "label": "Main color", "type": "color", "options": list(cb.options), "value": v.get("skin", "")})
        out.append({"key": "accent", "label": "Markings", "type": "color",
                    "options": [cb.secondary, "#e8e0d0", "#2a2a2e", "#c04030", "#e8b860"], "value": v.get("accent", "")})
        out.append({"key": "eyes", "label": "Eyes", "type": "color", "options": EYE_COLORS[3:] + [cb.eyes],
                    "value": v.get("eyes", "")})
        if cb.variants:
            out.append({"key": "variant", "label": "Variant", "type": "choice",
                        "options": [["", "Default"]] + [[x, x.title()] for x in cb.variants], "value": v.get("variant", "")})
        return out
    b = BODY_BASES.get(base, BODY_BASES["human"])
    out.append({"key": "skin", "label": "Skin", "type": "color", "options": list(b.skin_options), "value": v.get("skin", "")})
    out.append({"key": "hair", "label": "Hair", "type": "choice",
                "options": [["", f"Default ({b.hair})"]] + [[h, h.title()] for h in HAIR_STYLES], "value": v.get("hair", "")})
    out.append({"key": "hair_color", "label": "Hair color", "type": "color",
                "options": list(b.hair_options) or ["#2b2220", "#4a3426", "#b08a4e", "#cfcac0"],
                "value": v.get("hair_color", "")})
    out.append({"key": "beard", "label": "Beard", "type": "choice",
                "options": [["", f"Default ({b.beard_default})"]] + [[s, s.title()] for s in BEARD_STYLES],
                "value": v.get("beard", "")})
    out.append({"key": "eyes", "label": "Eyes", "type": "color", "options": EYE_COLORS, "value": v.get("eyes", "")})
    out.append({"key": "clothes", "label": "Clothes", "type": "color", "options": CLOTHES_COLORS, "value": v.get("clothes", "")})
    if b.accent:
        out.append({"key": "accent", "label": "Horns / scales", "type": "color",
                    "options": [b.accent, "#e0c27a", "#3a2a2e", "#e8e8e0", "#8a2a2a"], "value": v.get("accent", "")})
    return out


def look_random(world, race_id: str, value: dict, rng=None) -> dict:
    from game.art import creatures as CR
    from game.art.humanoid import BEARD_STYLES, BODY_BASES, HAIR_STYLES
    rng = rng or random.Random()
    base = look_base(world, race_id, value)
    v = {k: x for k, x in value.items() if k == "base"}
    if base in CR.CREATURE_BASES:
        cb = CR.CREATURE_BASES[base]
        v["skin"] = rng.choice(cb.options)
        if cb.variants:
            v["variant"] = rng.choice(cb.variants)
        return v
    b = BODY_BASES.get(base, BODY_BASES["human"])
    v["skin"] = rng.choice(b.skin_options)
    if b.hair_options:
        v["hair"] = rng.choice([h for h in HAIR_STYLES if h not in ("mane", "ragged")])
        v["hair_color"] = rng.choice(b.hair_options)
    v["clothes"] = rng.choice(CLOTHES_COLORS)
    v["eyes"] = rng.choice(EYE_COLORS[:5])
    if "beard" in b.features or rng.random() < 0.25:
        v["beard"] = rng.choice(BEARD_STYLES)
    return v


def look_json(world, race_id: str, value: dict, equipment: dict | None = None) -> dict:
    from game.art.library import body_bases
    from game.battlesetup import character_sprite
    try:
        pic = png64(character_sprite(world, race_id or "", value, equipment or {}))
    except Exception:  # noqa: BLE001 - no picture rather than no editor
        pic = ""
    return {"base": value.get("base", ""), "bases": [{"id": "", "label": "Same as their race", "group": ""}] +
            [{"id": i, "label": lab, "group": cat} for i, lab, cat in body_bases()],
            "fields": look_fields(world, race_id, value), "picture": pic}


def look_set(value: dict, key: str, x) -> dict:
    v = dict(value)
    if key == "base":                              # colours from a different body rarely make sense
        v = {"base": x} if x else {}
    elif x in ("", None):
        v.pop(key, None)
    else:
        v[key] = x
    return v


class Creating:
    """Mixed into web.bridge.Session."""

    cr: dict | None = None
    lk: dict | None = None
    lu: dict | None = None
    ch: dict | None = None

    # ==================================================================
    # A new game's party
    # ==================================================================
    def api_party_new(self, how: str = "quick") -> dict:
        from game import party as P
        if how == "quick" and not self.members:
            self.members[:] = [P.default_member(self.world, i) for i in range(2)]
            P.save(self.world, self.members)
            self.say("system", " and ".join(m.get("name", "?") for m in self.members) + " are ready for adventure.")
            how = "begin"
        if how == "begin":
            self._party_sprite()
            self.say("place", "The adventure begins.")
            self._announce()
            self.api_save()
        return self.api_view()

    # ==================================================================
    # The character creator
    # ==================================================================
    def api_creator(self, do: str = "start", what: str = "", value=None, step: int = 1) -> dict:
        from game.party import MAX_MEMBERS, new_id
        if do == "start":
            if len(self.members) >= MAX_MEMBERS:
                return {"creator": None, "message": f"A party can have at most {MAX_MEMBERS} characters."}
            self.cr = {"page": 0, "problem": "", "method": "Standard array", "pool": list(CH.STANDARD_ARRAY),
                       "rolled": None, "gear": {}, "gold": False, "flex": False, "traits": [],
                       "m": {"id": new_id(), "name": "", "race": "", "subrace": "", "background": "", "classes": [],
                             "scores": {}, "bonus_choices": {}, "skills": [], "spells": [], "feats": [], "asi": [],
                             "hp_rolls": [], "xp": 0, "inventory": {}, "equipment": {}, "attuned": [], "look": {},
                             "made": True, "potions": 0}}
            self._cr_scores(self.cr["method"])
        elif self.cr is None:
            return {"creator": None}
        elif do == "cancel":
            self.cr = None
            return {"creator": None, "view": self.api_view()}
        elif do == "set":
            self._cr_set(what, value)
        elif do == "go":
            done = self._cr_go(int(step))
            if done is not None:
                return done
        return {"creator": self._cr_json()}

    def _keys(self) -> list:
        return [s.fields["key"] for s in self._stats()]

    def _stats(self) -> list:
        return [s for s in self.world.entities.stats() if s.fields.get("key")
                and (s.fields.get("group") or "Abilities") == "Abilities"]

    def _abbr(self, sid) -> str:
        s = self.world.entities.get(sid)
        return (s.fields.get("abbreviation") or s.name[:3].upper()) if s else "?"

    def _klass(self, m=None):
        rows = (m or self.cr["m"]).get("classes") or []
        return self.world.entities.get(rows[0]["class"]) if rows else None

    def _casts(self) -> bool:
        k = self._klass()
        return bool(k and k.fields.get("spellcasting"))

    def _skip(self, i: int) -> bool:
        return PAGES[i] == "Spells" and not self._casts()

    def _granted(self) -> set:
        m, out = self.cr["m"], set()
        for r in CH.races_of(self.world, m):
            out |= set((r.fields.get("skills") if r else None) or [])
        bg = self.world.entities.get(m.get("background") or "")
        if bg:
            out |= set(bg.fields.get("skills") or [])
        return out

    def _cr_scores(self, method: str, reroll: bool = False) -> None:
        cr, m = self.cr, self.cr["m"]
        cr["method"] = "Roll" if method.startswith("Roll") else method
        if cr["method"] == "Standard array":
            cr["pool"] = list(CH.STANDARD_ARRAY)
        elif cr["method"] == "Roll":
            if reroll or not cr.get("rolled"):
                cr["rolled"] = CH.roll_scores(self.rng)
            cr["pool"] = list(cr["rolled"])
        keys = self._keys()
        k = self._klass()
        ps = self.world.entities.get(k.fields.get("primary_stat")) if k else None
        primary = ps.fields.get("key") if ps else ""
        order = [x for x in [primary, "con", "dex"] if x in keys] + [x for x in keys if x not in (primary, "con", "dex")]
        if cr["method"] == "Point buy":
            m["scores"] = {x: 8 for x in keys}
        else:
            vals = sorted(cr["pool"], reverse=True) + [10] * max(0, len(order) - len(cr["pool"]))
            m["scores"] = {x: vals[i] for i, x in enumerate(order)}

    def _cr_set(self, what: str, value) -> None:
        cr, m = self.cr, self.cr["m"]
        cr["problem"] = ""
        if what == "race":
            m.update(race=value or "", subrace="", bonus_choices={})
        elif what == "subrace":
            m["subrace"] = value or ""
        elif what == "class":
            m["classes"] = [{"class": value, "level": 1, "subclass": ""}] if value else []
            m["skills"], m["spells"], m["equipment"], m["inventory"] = [], [], {}, {}
            cr["gear"] = {}
            self._cr_scores(cr["method"])
        elif what == "method":
            self._cr_scores(str(value))
        elif what == "reroll":
            self._cr_scores("Roll", reroll=True)
        elif what == "score":
            key, v = value
            m["scores"][key] = int(v)
        elif what == "flexible":
            bonus = CH.racial_bonuses(self.world, {**m, "bonus_choices": {}})
            m["bonus_choices"] = dict(bonus) if value else {}
        elif what == "bonus":                          # [index of the bonus, the ability it goes on]
            i, key = value
            bonus = CH.racial_bonuses(self.world, {**m, "bonus_choices": {}})
            chunks = sorted((v for v in bonus.values() if v > 0), reverse=True)
            current = [k for k, v in sorted(m["bonus_choices"].items(), key=lambda kv: -kv[1]) if v]
            keys = self._keys()
            picks = [current[j] if j < len(current) else keys[j % len(keys)] for j in range(len(chunks))]
            picks[int(i)] = key
            choice: dict = {}
            for amount, k in zip(chunks, picks):
                choice[k] = choice.get(k, 0) + amount
            m["bonus_choices"] = choice
        elif what == "background":
            m["background"] = value or ""
            granted = self._granted()
            m["skills"] = [s for s in m["skills"] if s not in granted]
        elif what == "skill":
            skills = [s for s in m["skills"] if s != value]
            if value not in m["skills"]:
                skills.append(value)
            m["skills"] = skills
        elif what == "gear":                           # [group, option index]
            g, idx = value
            cr["gear"][int(g)] = int(idx)
        elif what == "gold":
            cr["gold"] = bool(value)
        elif what == "spell":
            spells = [s for s in m["spells"] if s != value]
            if value not in m["spells"]:
                spells.append(value)
            m["spells"] = spells
        elif what == "name":
            m["name"] = str(value or "").strip()[:40]
        elif what == "look":
            key, v = value
            m["look"] = look_set(m.get("look") or {}, key, v)
        elif what == "look_random":
            m["look"] = look_random(self.world, m.get("subrace") or m.get("race"), m.get("look") or {}, self.rng)

    def _cr_check(self) -> str:
        cr, m = self.cr, self.cr["m"]
        name = PAGES[cr["page"]]
        if name == "Race" and not m.get("race"):
            return "Pick a race."
        if name == "Class" and not m.get("classes"):
            return "Pick a class."
        if name == "Ability scores":
            if cr["method"] == "Point buy":
                spent = CH.point_buy_cost(m["scores"])
                if spent > CH.POINT_BUY_TOTAL:
                    return f"That's {spent} points; you have {CH.POINT_BUY_TOTAL}."
            elif sorted(m["scores"].values(), reverse=True) != sorted(cr["pool"], reverse=True):
                return "Use each score once."
            if m.get("bonus_choices"):
                bonus = CH.racial_bonuses(self.world, {**m, "bonus_choices": {}})
                chunks = [v for v in bonus.values() if v > 0]
                if len({k for k, v in m["bonus_choices"].items() if v}) != len(chunks):
                    return "Put each racial bonus on a different ability."
        if name == "Background & skills":
            k = self._klass()
            need = int((k.fields.get("skill_count") if k else 0) or 0)
            ids = list((k.fields.get("skill_choices") if k else None) or [])
            have = len([s for s in m["skills"] if s in ids])
            free = len([s for s in ids if s not in self._granted()])
            if have != min(need, free):
                return f"Choose {need} skills from your class list ({have} chosen)."
        if name == "Spells":
            c_need, s_need, cantrips, spells = self._spell_pool()
            c_have = len([s for s in m["spells"] if s in cantrips])
            s_have = len([s for s in m["spells"] if s in spells])
            if (c_need is not None and c_have != c_need) or (s_need is not None and s_have != s_need):
                return f"Choose {c_need or 0} cantrips and {s_need or 0} spells ({c_have} and {s_have} chosen)."
        if name == "Name & look" and not (m.get("name") or "").strip():
            return "Give your character a name."
        return ""

    def _cr_go(self, step: int):
        cr = self.cr
        if step > 0:
            problem = self._cr_check()
            if problem:
                cr["problem"] = problem
                return None
            if cr["page"] == len(PAGES) - 1:
                return self._cr_create()
            if PAGES[cr["page"]] == "Equipment":
                self._apply_gear()
        cr["problem"] = ""
        nxt = cr["page"] + step
        while 0 <= nxt < len(PAGES) and self._skip(nxt):
            nxt += step
        cr["page"] = max(0, min(len(PAGES) - 1, nxt))
        if PAGES[cr["page"]] == "Name & look":
            self._apply_gear()
            bg = self.world.entities.get(cr["m"].get("background") or "")
            cr["traits"] = []
            if bg:
                for key, title in (("traits", "A trait"), ("ideals", "An ideal"), ("bonds", "A bond"), ("flaws", "A flaw")):
                    lines = bg.fields.get(key) or []
                    if lines:
                        cr["traits"].append(f"{title} (from {bg.name}): {self.rng.choice(lines)}")
        return None

    def _apply_gear(self) -> None:
        from game import dice
        cr, m = self.cr, self.cr["m"]
        k = self._klass()
        bg = self.world.entities.get(m.get("background") or "")
        if cr["gold"] and k and k.fields.get("starting_gold"):
            items, extra = CH.starting_gear(self.world, None, None, bg)
            roll = dice.roll(k.fields["starting_gold"], self.rng).total * int(k.fields.get("starting_gold_multiplier") or 1)
            m["start_gold"] = roll + extra
        else:
            items, extra = CH.starting_gear(self.world, k, cr["gear"], bg)
            m["start_gold"] = extra
        m["inventory"] = items
        m["equipment"] = CH.auto_equip(self.world, items)

    def _cr_create(self) -> dict:
        from game import party as P
        member = CH.normalize(self.world, self.cr["m"])
        self.cr = None
        gold = int(member.pop("start_gold", 0) or 0)
        self.members.append(member)
        P.save(self.world, self.members)
        if gold and self.state is not None:
            self.state.add_copper(gold * 100, f"{member.get('name')}'s starting gold")
        self.say("system", f"{member.get('name')} joins the party.")
        self._party_sprite()
        self._keep_play()
        out = {"creator": None, "made": member["id"], "count": len(self.members), "max": P.MAX_MEMBERS,
               "view": self.api_view()}
        if CH.pending_choices(self.world, member):
            out["choices"] = self._ch_open(member["id"])
        return out

    def _spell_pool(self):
        m = self.cr["m"]
        k = self._klass()
        c_need, s_need = CH.known_counts(k, 1) if k else (None, None)
        top = max(CH.spell_slots(self.world, m) or {1: 0})
        pool = [s for s in (self.world.entities.get(i) for i in k.fields.get("spells") or []) if s] if k else []
        cantrips = [s.id for s in pool if int(s.fields.get("level") or 0) == 0]
        spells = [s.id for s in pool if 0 < int(s.fields.get("level") or 0) <= top]
        c_need = None if c_need is None else min(c_need, len(cantrips))
        s_need = None if s_need is None else min(s_need, len(spells))
        return c_need, s_need, cantrips, spells

    def _cr_json(self) -> dict:
        from game.combat import builders as B
        cr, m, w = self.cr, self.cr["m"], self.world
        page = PAGES[cr["page"]]
        shown = [p for i, p in enumerate(PAGES) if not self._skip(i)]
        out = {"page": page, "step": shown.index(page) + 1, "steps": len(shown), "problem": cr["problem"],
               "last": cr["page"] == len(PAGES) - 1, "first": cr["page"] == 0}
        # who they are so far
        bits = []
        race, sub = CH.races_of(w, m)
        if race:
            bits.append(race.name + (f" ({sub.name})" if sub else ""))
        k = self._klass()
        if k:
            bits.append(k.name)
        bg = w.entities.get(m.get("background") or "")
        if bg:
            bits.append(bg.name)
        if m.get("scores"):
            fs = CH.final_scores(w, m)
            bits.append("  ".join(f"{x.upper()} {fs.get(x, 10)}" for x in self._keys()))
        out["side"] = bits
        try:
            from game.battlesetup import character_sprite
            out["picture"] = png64(character_sprite(w, m.get("subrace") or m.get("race") or "", m.get("look"),
                                                    m.get("equipment") or {}))
        except Exception:  # noqa: BLE001
            out["picture"] = ""
        if page == "Race":
            rows = []
            for r in [r for r in w.entities.all("race") if r.fields.get("playable", True) and not r.fields.get("subrace_of")]:
                f = r.fields
                bonus = ", ".join(f"{self._abbr(x.get('stat'))} +{x.get('amount')}" for x in f.get("stat_modifiers") or [])
                feats = ", ".join(e.name for e in (w.entities.get(i) for i in f.get("features") or []) if e)
                info = "  ·  ".join(b for b in (bonus, f"speed {f.get('speed', 30)} ft",
                                                 f"darkvision {f.get('darkvision')} ft" if f.get("darkvision") else "",
                                                 f.get("size") if f.get("size") not in (None, "", "Medium") else "",
                                                 feats) if b)
                rows.append({"id": r.id, "name": r.name, "info": info, "desc": r.description or "", "on": m.get("race") == r.id})
            subs = [r for r in w.entities.all("race") if r.fields.get("subrace_of") == m.get("race")]
            out["options"] = rows
            out["subraces"] = [{"id": s.id, "name": s.name, "on": m.get("subrace") == s.id} for s in subs]
        elif page == "Class":
            mana_on = (w.rules.get("magic_system") or "Mana") == "Mana"
            rows = []
            for kk in [x for x in w.entities.all("class") if not x.fields.get("subclass_of")]:
                f = kk.fields
                first = [e.name for e in (w.entities.get(i) for i in B.class_features(kk, 1)) if e]
                casting = self._abbr(f.get("casting_stat")) if f.get("spellcasting") else ""
                pool = (f"Mana from {casting}" if casting else "Stamina from CON") if mana_on else ""
                info = "  ·  ".join(b for b in (f"Hit die {f.get('hit_die', 'd8')}",
                                                 f"primary {self._abbr(f.get('primary_stat'))}",
                                                 "saves " + ", ".join(self._abbr(x) for x in f.get("saving_throws") or []),
                                                 pool, ("level 1: " + ", ".join(first)) if first else "") if b)
                rows.append({"id": kk.id, "name": kk.name, "info": info, "desc": kk.description or "",
                             "on": bool(k) and k.id == kk.id})
            out["options"] = rows
        elif page == "Ability scores":
            bonus = CH.racial_bonuses(w, {**m, "bonus_choices": {}})
            final = CH.final_scores(w, m)
            rows = []
            for s in self._stats():
                key = s.fields["key"]
                extra = bonus.get(key, 0)
                rows.append({"key": key, "name": s.name, "value": int(m["scores"].get(key, 8)),
                             "bonus": f"race +{extra}" if extra and not m.get("bonus_choices") else "",
                             "total": final.get(key, 10), "mod": w.modifier(key, final.get(key, 10))})
            out["method"] = cr["method"]
            out["methods"] = ["Standard array", "Point buy", "Roll"]
            out["choices"] = sorted(set(cr["pool"]), reverse=True)
            out["rows"] = rows
            out["points"] = f"Points: {CH.point_buy_cost(m['scores'])} of {CH.POINT_BUY_TOTAL}" \
                if cr["method"] == "Point buy" else ""
            if w.rules.get("flexible_racial_bonuses", True) and bonus:
                chunks = sorted((v for v in bonus.values() if v > 0), reverse=True)
                current = [x for x, v in sorted(m["bonus_choices"].items(), key=lambda kv: -kv[1]) if v]
                keys = self._keys()
                out["flexible"] = {"on": bool(m.get("bonus_choices")), "keys": keys,
                                   "chunks": [{"amount": a, "value": current[i] if i < len(current) else keys[i % len(keys)]}
                                              for i, a in enumerate(chunks)]}
        elif page == "Background & skills":
            need = int((k.fields.get("skill_count") if k else 0) or 0)
            ids = list((k.fields.get("skill_choices") if k else None) or [])
            granted = self._granted()
            info = ""
            if bg:
                f = bg.fields
                skills = ", ".join(e.name for e in (w.entities.get(i) for i in f.get("skills") or []) if e)
                feat = w.entities.get(f.get("feature") or "")
                info = "  ·  ".join(b for b in (f"skills: {skills}" if skills else "", f"feature: {feat.name}" if feat else "",
                                                 f"{f.get('gold', 0)} gp" if f.get("gold") else "") if b)
                if bg.description:
                    info += "\n" + bg.description
            out["backgrounds"] = [{"id": "", "name": "(no background)", "on": not m.get("background")}] + \
                [{"id": b.id, "name": b.name, "on": m.get("background") == b.id} for b in w.entities.all("background")]
            out["info"] = info
            out["need"] = need
            out["skills"] = [{"id": sid, "name": w.entities.get(sid).name, "on": sid in m["skills"],
                              "granted": sid in granted} for sid in ids if w.entities.get(sid)]
        elif page == "Equipment":
            always = [w.entities.get(i) for i in (k.fields.get("starting_equipment") or [])] if k else []
            groups: dict[int, list] = {}
            for idx, r in enumerate((k.fields.get("equipment_choices") or []) if k else []):
                groups.setdefault(int(r.get("group") or 1), []).append((idx, r))
            out["always"] = ", ".join(i.name for i in always if i)
            out["groups"] = []
            for g, opts in sorted(groups.items()):
                rows = []
                for idx, r in opts:
                    names = ", ".join(e.name for e in (w.entities.get(i) for i in r.get("items") or []) if e)
                    n = int(r.get("count") or 1)
                    rows.append({"index": idx, "label": names + (f"  (x{n})" if n > 1 else ""),
                                 "on": cr["gear"].get(g, opts[0][0]) == idx})
                out["groups"].append({"group": g, "options": rows})
            out["from_background"] = ", ".join(e.name for e in (w.entities.get(i) for i in (bg.fields.get("equipment") or []))
                                               if e) if bg else ""
            gold = k.fields.get("starting_gold") if k else ""
            out["gold"] = {"can": bool(gold), "on": cr["gold"],
                           "label": f"Take gold instead ({gold or '0'} x {int(k.fields.get('starting_gold_multiplier') or 1) if k else 1} gp)"}
        elif page == "Spells":
            c_need, s_need, cantrips, spells = self._spell_pool()
            style = CH.casting_style(k) if k else "Known"
            note = ""
            if style.startswith("Prepared"):
                note = f"{k.name}s prepare spells from their whole list each day. Choose which in the Party tab once the character is made."
            elif style == "Spellbook":
                note = "Choose the spells written in your spellbook. You prepare some of them each day."
            elif c_need is None and s_need is None:
                note = f"{k.name}s know every spell on their list."
            secs = []
            for title, ids, need in (("Cantrips", cantrips, c_need), ("Level 1 spells", spells, s_need)):
                if not ids or (title != "Cantrips" and style.startswith("Prepared")):
                    continue
                secs.append({"title": title, "need": need, "spells": [
                    {"id": sid, "name": w.entities.get(sid).name, "desc": w.entities.get(sid).description or "",
                     "on": sid in m["spells"] or need is None, "locked": need is None} for sid in ids]})
            out["note"], out["sections"] = note, secs
        elif page == "Name & look":
            out["name"] = m.get("name") or ""
            out["look"] = look_json(w, m.get("subrace") or m.get("race"), m.get("look") or {}, m.get("equipment"))
            out["traits"] = cr.get("traits") or []
        else:
            from game.sheet import sheet_for
            mm = CH.normalize(w, m)
            c = CH.build(w, mm)
            from web.tabs import _plain
            out["sheet"] = _plain(sheet_for(w, c, mm))
            out["gold"] = m.get("start_gold") or 0
        return out

    # ==================================================================
    # A hero's look
    # ==================================================================
    def api_look(self, do: str = "open", member: str = "", key: str = "", value=None) -> dict:
        from game import party as P
        if do == "open":
            m = self._member(member)
            if m is None:
                return {"look": None}
            self.lk = {"id": m["id"], "value": dict(m.get("look") or {}), "race": m.get("subrace") or m.get("race"),
                       "eq": m.get("equipment") or {}, "name": m.get("name") or "Hero"}
        elif self.lk is None:
            return {"look": None}
        elif do == "set":
            self.lk["value"] = look_set(self.lk["value"], key, value)
        elif do == "random":
            self.lk["value"] = look_random(self.world, self.lk["race"], self.lk["value"], self.rng)
        elif do == "save":
            m = self._member(self.lk["id"])
            if m is not None:
                m["look"] = dict(self.lk["value"])
                P.save(self.world, self.members)
                self._party_sprite()
                self._keep_play()
            self.lk = None
            return {"look": None, "view": self.api_view()}
        elif do == "cancel":
            self.lk = None
            return {"look": None}
        lk = self.lk
        return {"look": {"name": lk["name"], **look_json(self.world, lk["race"], lk["value"], lk["eq"])}}

    # ==================================================================
    # Levelling up
    # ==================================================================
    def api_levelup(self, do: str = "open", member: str = "", what: str = "", value=None) -> dict:
        from game import condition
        from game import party as P
        if do == "open":
            m = self._member(member)
            if m is None or not CH.can_level_up(self.world, m):
                return {"levelup": None}
            m = CH.normalize(self.world, m)
            ks = CH.class_choices(self.world, m)
            self.lu = {"id": m["id"], "m": m, "klass": ks[0].id if ks else "", "hp": None, "sub": "",
                       "asi_mode": "+2 to one score", "asi": [], "feat": "", "spells": [], "problem": ""}
        elif self.lu is None:
            return {"levelup": None}
        elif do == "cancel":
            self.lu = None
            return {"levelup": None}
        elif do == "set":
            lu = self.lu
            lu["problem"] = ""
            if what == "class":
                lu.update(klass=value, hp=None, sub="", spells=[], asi=[], feat="")
            elif what == "hp":
                lu["hp"] = int(value)
            elif what == "sub":
                lu["sub"] = value or ""
            elif what == "asi_mode":
                lu.update(asi_mode=value, asi=[], feat="")
            elif what == "asi":                       # [index, ability]
                i, k = value
                while len(lu["asi"]) <= int(i):
                    lu["asi"].append("")
                lu["asi"][int(i)] = k
            elif what == "feat":
                lu["feat"] = value or ""
            elif what == "spell":
                lu["spells"] = [s for s in lu["spells"] if s != value] + ([] if value in lu["spells"] else [value])
        elif do == "roll":
            k = self.world.entities.get(self.lu["klass"])
            if k is not None:
                self.lu["hp"] = CH.roll_hp(k, self.rng)
        elif do == "apply":
            res = self._lu_apply()
            if isinstance(res, str):
                self.lu["problem"] = res
            else:
                mid = self.lu["id"]
                self.lu = None
                self.members[:] = [res if x["id"] == mid else x for x in self.members]
                P.save(self.world, self.members)
                if self.state is not None:            # the new level's hit points come with it
                    rec = condition.record(self.state, res)
                    if "hp" in rec:
                        gained = CH.build(self.world, res).max_hp - int(rec.get("max", rec["hp"]))
                        rec["hp"] = int(rec["hp"]) + max(0, gained)
                    rec["hit_dice"] = int(rec.get("hit_dice", 0)) + 1
                    self.state.save()
                self.say("loot", f"{res.get('name')} reaches level {CH.total_level(self.world, res)}!")
                self.bus.emit("party.levelled", member=mid)
                self._keep_play()
                out = {"levelup": None, "view": self.api_view()}
                if CH.pending_choices(self.world, res):
                    out["choices"] = self._ch_open(mid)
                elif CH.can_level_up(self.world, res):         # enough experience for more than one level
                    out["again"] = mid
                return out
        return {"levelup": self._lu_json()}

    def _lu_json(self) -> dict:
        w, lu = self.world, self.lu
        m = lu["m"]
        k = w.entities.get(lu["klass"])
        out = {"name": m.get("name"), "level": CH.total_level(w, m) + 1, "problem": lu["problem"],
               "classes": [{"id": x.id, "name": x.name, "on": x.id == lu["klass"]} for x in CH.class_choices(w, m)]}
        if k is None:
            return out
        n = CH.level_up_needs(w, m, k)
        out["multi"] = not any(r["class"] == k.id for r in m["classes"])
        out["line"] = f"{k.name} level {n['class_level']}" + (": " + ", ".join(f.name for f in n["new_features"])
                                                               if n["new_features"] else ": no new features")
        rule = w.rules.get("hp_on_level") or "Choose"
        avg = CH.average_hp(k)
        if rule == "Average":
            lu["hp"] = avg
        elif rule == "Roll" and lu["hp"] is None:
            lu["hp"] = CH.roll_hp(k, self.rng)
        out["hp"] = {"rule": rule, "average": avg, "value": lu["hp"], "die": n["hit_die"]}
        if n["subclass"]:
            subs = CH.subclasses_of(w, k)
            if not lu["sub"] and subs:
                lu["sub"] = subs[0].id
            out["subclass"] = {"title": k.fields.get("subclass_title") or "subclass",
                               "options": [{"id": s.id, "name": s.name, "desc": s.description or "", "on": s.id == lu["sub"]}
                                           for s in subs]}
        if n["asi"]:
            keys = [s.fields["key"] for s in self._stats()]
            scores = CH.final_scores(w, m)
            modes = ["+2 to one score", "+1 to two scores"]
            feats = [f for f in w.entities.all("feature") if f.fields.get("kind") == "Feat" and f.id not in (m.get("feats") or [])]
            if w.rules.get("feats", True) and feats:
                modes.append("A feat")
            want = 1 if lu["asi_mode"].startswith("+2") else 2
            while len(lu["asi"]) < want:
                lu["asi"].append(keys[len(lu["asi"]) % len(keys)])
            out["asi"] = {"modes": modes, "mode": lu["asi_mode"], "picks": lu["asi"][:want],
                          "keys": [{"key": x, "label": f"{x.upper()} ({scores.get(x, 10)})"} for x in keys],
                          "feats": [{"id": f.id, "name": f.name, "desc": f.description or "", "on": f.id == lu["feat"]}
                                    for f in feats] if lu["asi_mode"] == "A feat" else []}
        if n["spells"] or n["cantrips"]:
            trial = CH.apply_level_up(w, m, k, 1)
            top = max(CH.spell_slots(w, trial) or {1: 0})
            pool = [s for s in (w.entities.get(i) for i in k.fields.get("spells") or []) if s]
            known = set(m.get("spells") or [])
            secs = []
            for title, cond, need in (("New cantrips", lambda s: int(s.fields.get("level") or 0) == 0, n["cantrips"]),
                                      (f"New spells (up to level {top})",
                                       lambda s: 0 < int(s.fields.get("level") or 0) <= top, n["spells"])):
                choices = [s for s in pool if cond(s) and s.id not in known]
                need = min(need, len(choices))
                if need:
                    secs.append({"title": title, "need": need, "spells": [
                        {"id": s.id, "name": s.name, "desc": s.description or "", "on": s.id in lu["spells"]} for s in choices]})
            out["spells"] = secs
        return out

    def _lu_apply(self):
        w, lu = self.world, self.lu
        m = lu["m"]
        k = w.entities.get(lu["klass"])
        if k is None:
            return "Pick a class for the new level."
        if lu["hp"] is None:
            return "Choose how many hit points to gain: take the average or roll."
        n = CH.level_up_needs(w, m, k)
        asi, feat = None, ""
        if n["asi"]:
            if lu["asi_mode"] == "A feat":
                feat = lu["feat"]
                if not feat:
                    return "Pick a feat."
            elif lu["asi_mode"].startswith("+2"):
                asi = {lu["asi"][0]: 2}
            else:
                a, b = lu["asi"][0], lu["asi"][1]
                if a == b:
                    return "Pick two different scores."
                asi = {a: 1, b: 1}
            scores = CH.final_scores(w, m)
            if asi and any(scores.get(x, 10) + v > 20 for x, v in asi.items()):
                return "A score can't go above 20 this way."
        secs = self._lu_json().get("spells") or []
        for sec in secs:
            ids = {s["id"] for s in sec["spells"]}
            if len([s for s in lu["spells"] if s in ids]) != sec["need"]:
                return f"{sec['title']}: choose {sec['need']}."
        return CH.apply_level_up(w, m, k, int(lu["hp"]), lu["sub"] if n["subclass"] else "", asi, feat, list(lu["spells"]))

    # ==================================================================
    # Choices (fighting styles, maneuvers, expertise...)
    # ==================================================================
    def _ch_open(self, member_id: str) -> dict | None:
        m = self._member(member_id)
        if m is None:
            return None
        m = CH.normalize(self.world, m)
        picks = {}
        for row in CH.choices_for(self.world, m):
            picks[row["feature"].id] = list(row["have"])
        self.ch = {"id": member_id, "m": m, "picks": picks, "problem": ""}
        return self._ch_json()

    def _ch_json(self) -> dict:
        w, ch = self.world, self.ch
        rows = []
        for row in CH.choices_for(w, ch["m"]):
            f = row["feature"]
            have = set(row["have"])
            opts = list(row["options"]) + [w.entities.get(i) for i in have if i not in {o.id for o in row["options"]}
                                           and w.entities.get(i)]
            need = min(row["need"], len(opts))
            picked = ch["picks"].get(f.id, [])
            rows.append({"id": f.id, "title": f"{f.name}: choose {need} {KIND_WORDS.get(row['kind'], 'options')}",
                         "desc": f.description or "", "need": need,
                         "options": [{"id": o.id, "name": o.name, "desc": o.description or "", "on": o.id in picked}
                                     for o in opts]})
        return {"name": ch["m"].get("name"), "rows": rows, "problem": ch["problem"]}

    def api_choices(self, do: str = "open", member: str = "", feature: str = "", option: str = "") -> dict:
        from game import party as P
        if do == "open":
            return {"choices": self._ch_open(member)}
        if self.ch is None:
            return {"choices": None}
        if do == "toggle":
            row = next((r for r in self._ch_json()["rows"] if r["id"] == feature), None)
            picks = list(self.ch["picks"].get(feature, []))
            if option in picks:
                picks.remove(option)
            elif row is not None and len(picks) < row["need"]:
                picks.append(option)
            self.ch["picks"][feature] = picks
            return {"choices": self._ch_json()}
        if do == "save":
            ch = self.ch
            m = ch["m"]
            choices = dict(m.get("choices") or {})
            choices.update(ch["picks"])
            m["choices"] = choices
            mid = ch["id"]
            self.members[:] = [m if x["id"] == mid else x for x in self.members]
            P.save(self.world, self.members)
            self._keep_play()
            self.ch = None
            if CH.pending_choices(self.world, m):            # a pick that unlocks more picks
                return {"choices": self._ch_open(mid), "view": self.api_view()}
            return {"choices": None, "view": self.api_view()}
        self.ch = None
        return {"choices": None}

    # ==================================================================
    # Spells: preparing them, and casting outside a fight
    # ==================================================================
    def api_spells(self, member: str = "", do: str = "", spell: str = "", target: str = "") -> dict:
        from game import condition as COND
        from game import party as P
        m = self._member(member)
        if m is None:
            return {"spells": None}
        message = ""
        if do == "prepare":
            prep = self._prep_groups(m)
            mine = [sid for g in prep for sid in g["picked"]]
            if spell in mine:
                mine.remove(spell)
            else:
                g = next((g for g in prep if spell in [s["id"] for s in g["spells"]]), None)
                if g is not None and len(g["picked"]) < g["limit"]:
                    mine.append(spell)
            m["prepared"] = mine or ["-"]                     # "-": nothing prepared on purpose
            P.save(self.world, self.members)
            message = "Prepared spells changed."
        elif do == "cast":
            t = self._member(target)
            if t is not None:
                message = COND.cast_outside(self.world, self.state, m, spell, t, self.rng, self.bus) or \
                    "You can't cast that right now."
                P.save(self.world, self.members)
                self.state.save()
        c = COND.combatant(self.world, m)
        COND.apply(self.state, m, c)
        lines = []
        if c.mana_max:
            lines.append(f"{c.mana_name} {c.mana}/{c.mana_max}  ·  spells cost 10 per level  ·  can cast up to level "
                         f"{c.max_cast_level}")
        for name, pool in sorted((getattr(c, "resources", {}) or {}).items()):
            lines.append(f"{name}: {pool['max']} (back on a {str(pool.get('recharge') or '').lower()})")
        outside = []
        if not m.get("dead"):
            for sp, lvl in COND.outside_spells(self.world, self.state, m):
                cost = (f"{lvl * int(self.world.rules.get('mana_per_spell_level', 10) or 10)} {c.mana_name}"
                        if c.mana_max and lvl else ("free" if not lvl else f"level {lvl} slot"))
                outside.append({"id": sp.id, "name": sp.name, "cost": cost, "desc": sp.describe()})
        out = {"spells": {"lines": lines, "prepare": self._prep_groups(m), "outside": outside,
                          "targets": [{"id": o["id"], "name": o.get("name") + ("  (dead)" if o.get("dead") else "")}
                                      for o in self.members],
                          "ready": [s.describe() for s in sorted(c.spells, key=lambda s: (s.level, s.name))]},
               "message": message}
        if do:
            out["view"] = self.api_view()
        return out

    def _prep_groups(self, m: dict) -> list[dict]:
        out = []
        top = max(CH.spell_slots(self.world, m) or {0: 0})
        for k, lv, sub in CH.classes_of(self.world, m):
            style = CH.casting_style(k)
            if not k.fields.get("spellcasting") or style == "Known":
                continue
            limit = CH.prepare_limit(self.world, m, k, lv)
            _c, levelled = CH.class_spell_pool(self.world, k, sub, top)
            if style == "Spellbook":
                book = set(m.get("spells") or [])
                levelled = [s for s in levelled if s.id in book]
            current = set(CH.prepared_for(self.world, m, k, sub, lv))
            always = set(CH.always_prepared(self.world, sub, top))
            spells = [{"id": s.id, "name": f"{s.name}  (level {s.fields.get('level')})", "desc": s.description or "",
                       "on": s.id in current} for s in sorted(levelled, key=lambda s: (int(s.fields.get("level") or 0), s.name))
                      if s.id not in always]
            out.append({"klass": k.name, "limit": limit, "from": "your spellbook" if style == "Spellbook" else "the class list",
                        "spells": spells, "picked": [s["id"] for s in spells if s["on"]],
                        "always": [self.world.entities.get(i).name for i in sorted(always)
                                   if self.world.entities.get(i) and int(self.world.entities.get(i).fields.get("level") or 0) > 0]})
        return out


__all__ = ["Creating", "PAGES", "look_fields", "look_json", "look_random"]
