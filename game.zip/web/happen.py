"""The browser version, stage 3: what the game does by itself when things happen, as the app's main window does
(ui/main_window.py, _wire_events): experience shared out, milestones, recipes learned from what's picked up, a
story's foe waiting where the party arrives, traps and monsters at landmarks and in dungeons, festivals and
raids in town, a guard stopping a wanted party, what the trade routes did while time passed.
"""
from __future__ import annotations


class Happenings:
    """Mixed into web.bridge.Session."""

    def _wire(self) -> None:
        bus = self.bus
        bus.on("xp.gained", self._xp_gained)
        bus.on("quest.completed", self._quest_completed)
        bus.on("inventory.changed", lambda e: self._learn_recipes(e.get("item")) if (e.get("change") or 0) > 0
               else None)
        bus.on("quest.accepted", lambda e: self._chain_fight_here() if (e.get("quest") or {}).get("chain") else None)
        bus.on("location.entered", self._entered)
        bus.on("time.passed", lambda e: self._route_reports())
        self._events_town = ""
        self._sound_wire()
        self._sound_reset()

    def _levels(self) -> list[int]:
        from game import character as CH
        out = []
        for m in self.members:
            if m.get("dead"):
                continue
            try:
                out.append(max(1, CH.total_level(self.world, m)))
            except Exception:  # noqa: BLE001 - a member pointing at deleted content
                out.append(max(1, int(m.get("level") or 1)))
        return out or [1]

    def _xp_gained(self, event) -> None:
        """Experience is shared equally among the living party members."""
        from game import party as P
        amount = int(event.get("amount") or 0)
        if amount <= 0 or not self.members:
            return
        for name in P.award_xp(self.world, self.members, amount):
            self.say("loot", f"{name} can level up! (Party tab: Level up)")

    def _quest_completed(self, _event) -> None:
        from game import party as P
        if (self.world.rules.get("levelling") or "XP") == "Milestone" and self.members:
            P.give_milestone(self.world, self.members)
            self.say("loot", "Milestone reached: everyone can gain a level!")

    def _learn_recipes(self, item_id) -> None:
        if self.state is None or self.fight is not None or not item_id:
            return
        from game import crafting
        try:
            crafting.learn(self.world, self.state, self.members, [item_id], self.bus)
        except Exception:  # noqa: BLE001 - nothing learned
            pass

    def _chain_fight_here(self) -> None:
        """A story step that starts while the party is already where its foe waits: the fight is on."""
        if self.state is None or self.fight is not None:
            return
        from game import chains
        found = chains.fight_at(self.world, self.state, self.state.location)
        if found is not None:
            self._encounter(found)

    def _route_reports(self) -> None:
        if self.state is None or not self.state.holdings.get("reports"):
            return
        from game import trade
        for line in trade.take_reports(self.state):
            self.say("loot", line)

    # ---- arriving somewhere
    def _entered(self, event) -> None:
        if self.state is None or self.fight is not None:
            return
        if event.get("kind") in ("landmark", "dungeon"):
            self._arrive_outside(event.get("spot") or "")
            if self.fight is not None:
                return
        from game import chains
        found = chains.fight_at(self.world, self.state, event.get("location") or event.get("spot") or "")
        if found is not None:
            self._encounter(found)
            return
        self._town_events()

    def _arrive_outside(self, loc: str) -> None:
        """Traps and monsters waiting at a landmark or in a dungeon room."""
        from game import dungeons as D
        walking = self.ex is not None and self.ex.area is not None and self.ex.area.kind == "dungeon"
        what = D.arrival(self.world, self.state, loc, self.rng, traps=not walking)   # (traps: game/traps.py)
        if what["trap"]:
            for line in D.trap_text(self.world, self.members, what["trap"], self.rng, self.state):
                self.say("damage", line)
        if what["fight"]:
            key = what["key"]
            found = {"rows": what["fight"], "environment": what["environment"], "text": what["text"],
                     "map_size": what.get("map_size"), "style": what.get("style") or ""}
            if self.ex is not None and self.ex.area is not None:
                cells = [(t.x, t.y) for t in self.ex.tokens if t.kind == "enemy" and t.room == loc]
                found["foe_cells"] = cells or None
            self._encounter(found, then=lambda outcome, k=key: D.mark_cleared(self.state, k)
                            if outcome == "victory" else None)

    def _town_events(self) -> None:
        """Arriving in a town (or a new day there): a festival to announce, or a raid."""
        from game import places
        from game import townevents as TE
        spot = places.current(self.world, self.state)
        town = spot.town if spot.kind in ("street", "building") else None
        if town is None:
            self._events_town = ""
            return
        if self._events_town == town.id:
            return
        self._events_town = town.id
        TE.check(self.world, self.state, town, self.rng, self.bus, self._levels())
        if self.ex is not None:
            self.ex.raid_sync()

    def _raid_fight(self, rows: list, cells=None) -> None:
        """Into the fight with the town's guard beside you."""
        from game import law
        from game import townevents as TE
        raid = TE.raid_here(self.world, self.state)
        if raid is None or not rows:
            return
        town = self.world.entities.get(raid["town"])
        allies = law.guards_for(self.world, town, 2)

        def after(outcome):
            if outcome == "victory":
                TE.wave_won(self.world, self.state, self.members, self.bus)
                if self.ex is not None:
                    self.ex.raid_sync()
        self._encounter({"rows": rows, "text": "You charge in with the guard!", "environment": "street",
                         "allies": allies, "foe_cells": cells}, then=after)

    def _new_animal(self, v) -> None:
        if v:
            self.say("loot", f"{v['name']} joins you. (See to your animals from the Map tab.)")


__all__ = ["Happenings"]
