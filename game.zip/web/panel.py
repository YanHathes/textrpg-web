"""The browser version, stage 3: one kind of screen for the app's many smaller windows (talking to someone,
trading, a shift of work, the bank, the watch, a temple, crafting, books, animals, land, games...).

A Panel has a title, perhaps a face, what's been said so far (a conversation's lines, kept while the panel is
open), and blocks: words, buttons, boxes to type a number or a name in, choices from a list. Every button is a
Python function kept here; the page only says which one was pressed (and what's typed in the boxes), so each
of the app's windows becomes a short function that fills a panel (web/talk.py, web/places2.py).

    panel(do="pick", index, values)     a button pressed (values: the boxes as they are)
    panel(do="close")                   closed (its close function runs: what comes after)
"""
from __future__ import annotations


class Panel:
    def __init__(self, title: str, build, name: str = "", sub: str = "", picture: str = "", close: str = "Done",
                 on_close=None) -> None:
        self.title, self.build, self.name, self.sub, self.picture = title, build, name, sub, picture
        self.close_label, self.on_close = close, on_close
        self.lines: list[dict] = []           # the conversation so far: {"who", "text", "kind"}
        self.values: dict = {}                # what's in the boxes
        self.blocks: list[dict] = []
        self.fns: list = []
        self.message = ""
        self.closed = False
        self.then = None                      # what to do once it's shut (a fight, a trade...)
        self.picking = False                  # the page shows the world map to pick a spot (on_point gets it)
        self.on_point = None

    # ---- filling it (the build function calls these)
    def text(self, text: str, style: str = "") -> None:
        if text:
            self.blocks.append({"t": "text", "text": str(text), "style": style})

    def head(self, text: str) -> None:
        self.blocks.append({"t": "head", "text": str(text)})

    def option(self, label: str, fn=None, sub: str = "", enabled: bool = True, style: str = "", on: bool = False,
               desc: str = "") -> None:
        self.fns.append(fn)
        self.blocks.append({"t": "opt", "i": len(self.fns) - 1, "label": str(label), "sub": str(sub or ""),
                            "enabled": bool(enabled and fn is not None), "style": style, "on": bool(on), "desc": desc})

    def buttons(self, *pairs) -> None:
        """Buttons side by side: (label, fn, style) ..."""
        row = []
        for label, fn, style in pairs:
            self.fns.append(fn)
            row.append({"i": len(self.fns) - 1, "label": label, "style": style, "enabled": fn is not None})
        self.blocks.append({"t": "row", "items": row})

    def number(self, key: str, label: str, value: int = 1, lo: int = 1, hi: int = 1_000_000, suffix: str = "") -> None:
        self.values.setdefault(key, value)
        self.values[key] = max(lo, min(hi, int(self.values.get(key) or value)))
        self.blocks.append({"t": "number", "id": key, "label": label, "value": self.values[key], "min": lo, "max": hi,
                            "suffix": suffix})

    def field(self, key: str, label: str, value: str = "") -> None:
        self.values.setdefault(key, value)
        self.blocks.append({"t": "field", "id": key, "label": label, "value": self.values[key]})

    def select(self, key: str, label: str, options: list, value=None) -> None:
        """options: [(value, label)]"""
        if key not in self.values or self.values[key] not in [o[0] for o in options]:
            self.values[key] = value if value is not None else (options[0][0] if options else "")
        self.blocks.append({"t": "select", "id": key, "label": label, "value": self.values[key],
                            "options": [[str(v), str(lab)] for v, lab in options]})

    def check(self, key: str, label: str, value: bool = False) -> None:
        self.values.setdefault(key, value)
        self.blocks.append({"t": "check", "id": key, "label": label, "value": bool(self.values[key])})

    def say(self, text: str, who: str = "", kind: str = "them") -> None:
        if text:
            self.lines.append({"who": who, "text": str(text), "kind": kind})

    # ---- for the page
    def render(self) -> dict:
        self.blocks, self.fns = [], []
        self.build(self)
        pick, self.picking = self.picking, False          # (once: the page opens the map)
        return {"title": self.title, "name": self.name, "sub": self.sub, "picture": self.picture,
                "lines": self.lines[-40:], "blocks": self.blocks, "message": self.message, "close": self.close_label,
                "pick": pick}


class Panels:
    """Mixed into web.bridge.Session."""

    pnl: Panel | None = None

    def _panel(self, p: Panel) -> Panel:
        self.close_menus()
        self.pnl = p
        return p

    def _panel_json(self) -> dict:
        out = {"panel": self.pnl.render() if self.pnl is not None else None}
        out["view"] = self.api_view()
        return out

    def api_panel(self, do: str = "", index: int = -1, values: dict | None = None) -> dict:
        p = self.pnl
        if p is None:
            return {"panel": None, "view": self.api_view()}
        if values and do != "point":
            for k, v in values.items():
                if k in p.values:
                    p.values[k] = v
        if do == "pick" and 0 <= index < len(p.fns) and p.fns[index] is not None:
            p.message = ""
            p.fns[index](p)
        elif do == "close":
            p.closed = True
        elif do == "set":                        # a box changed and the panel shows something from it
            pass
        elif do == "point":                      # a spot picked on the world map (values: x, y in miles)
            p.picking = False
            if p.on_point is not None and values:
                p.on_point(p, float(values.get("x") or 0), float(values.get("y") or 0))
        if p.closed:
            self.pnl = None
            if p.on_close is not None:
                p.on_close(p)
            if p.then is not None:
                p.then()
            from game import party as P
            P.save(self.world, self.members)
            self.state.save()
            self.ex.sync()
            self._party_sprite()
        return self._panel_json()


__all__ = ["Panel", "Panels"]
