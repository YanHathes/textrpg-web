"""The game, driven by a web page (the browser version, stage 1).

A page can't call Python objects, so everything it needs goes through one entry point, call(name, args), which
takes and gives plain JSON. In the browser the page (web/site/app.js) reaches it through Pyodide, inside a
Web Worker; on a computer, web/devserver.py serves the page and answers the same calls from normal Python, so
the page can be tried and tested without Pyodide.

Stage 1 covers the walking map: opening the world, a new game with ready-made heroes or going on with one,
walking, what the party sees, people and doors (Interact), the prompts they bring up, the six commands' menus
(Check, Action, Rest), waiting, the log, and saving. Stage 2 (web/tabs.py) the other tabs: the Bag, the Party's
sheets, the Quests journal, the Map (the place panel and the world map) and the Settings' saves. What isn't in
the browser version yet (fights, the character creator, trading, crafting...) says so in the log instead of
doing nothing.
"""
from __future__ import annotations

import json
import random
import time
from pathlib import Path

from game import handheld as H
from game import wording
from web.creator import Creating
from web.doings import Doings
from web.estate import Estates
from web.fight import Fights
from web.games import Games
from web.happen import Happenings
from web.journey import Journeys
from web.panel import Panels
from web.sound import Sounds
from web.talk import Talking
from web.tabs import Tabs

STAGE_LATER = "That isn't in the browser version yet: it comes in a later stage."


# What in a world's folder is the playthrough (kept in the browser's storage between visits), as against the
# world itself (unpacked from world.zip into memory every visit, so its big databases are never written back)
WORLD_ONLY = {"entities", "cache", "sprites", "templates", "bigmap.db", "world.json"}


class Session(Journeys, Tabs, Fights, Happenings, Creating, Panels, Talking, Doings, Estates, Games, Sounds):
    def __init__(self, data_dir: str | Path, touch: bool = True, keep_dir: str | Path | None = None) -> None:
        """data_dir holds the worlds; keep_dir (the browser's lasting storage) the playthroughs and settings.
        Without keep_dir (on a computer) everything stays in data_dir."""
        self.data = Path(data_dir)
        self.data.mkdir(parents=True, exist_ok=True)
        self.keep = Path(keep_dir) if keep_dir else None
        if self.keep is not None:
            self.keep.mkdir(parents=True, exist_ok=True)
        wording.set_how("touch" if touch else "mouse")
        from game.world import WorldManager
        self.worlds = WorldManager(self.data / "worlds")
        self.world = None
        self.state = None
        self.ex = None
        self.scene = None
        self.members: list[dict] = []
        self.log: list[dict] = []          # what's been said, oldest first (the page asks for what's new)
        self.rng = random.Random()
        self.menu: H.Menu | None = None
        self.menu_kind = ""
        self.prompt = None
        self._roller = None
        self._target = None
        self._last_save = 0.0
        self._kept = False
        self._sound_init()

    # ==================================================================
    # The one entry point
    # ==================================================================
    def call(self, name: str, args: dict | None = None) -> dict:
        fn = getattr(self, "api_" + name, None)
        if fn is None:
            return {"error": f"no such call: {name}"}
        try:
            out = fn(**(args or {}))
        except Exception as exc:  # noqa: BLE001 - the page shows it, rather than hanging
            import traceback
            return {"error": f"{type(exc).__name__}: {exc}", "trace": traceback.format_exc()}
        out = out if isinstance(out, dict) else {"value": out}
        if self.state is not None and (self.state.law or {}).get("jail"):
            self._jail_due(out)                     # the hour of a hanging (game/jail.py)
        try:
            self._sound_out(out)                    # the music when it should change, and effects (web/sound.py)
        except Exception:  # noqa: BLE001 - never let the sound stop the game
            pass
        if getattr(self, "_stale", None):              # the land changed: those blocks are drawn again
            out["stale"] = sorted(self._stale)
            self._stale = set()
        if getattr(self, "_blackout", None):          # the screen cuts to black (game/brothel.py)
            out["blackout"], self._blackout = self._blackout, None
        if self._kept:                              # the page's worker writes the browser's storage now
            self._kept = False
            out["kept"] = True
        return out

    # ==================================================================
    # Starting
    # ==================================================================
    def _settings_path(self) -> Path:
        return (self.keep or self.data) / "web-settings.json"

    def _settings(self) -> dict:
        p = self._settings_path()
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def _set(self, key: str, value) -> None:
        s = self._settings()
        s[key] = value
        self._settings_path().write_text(json.dumps(s), encoding="utf-8")

    def api_boot(self) -> dict:
        """What the main menu needs: the world the game will open, and whether there's a party to go on with
        (no world is opened for this)."""
        self._sound_quiet = True                    # (no music over the menu: web/sound.py)
        slug = self._settings().get("world") or ""
        if not slug or not (self.data / "worlds" / slug / "world.json").exists():
            slug = self.worlds.ensure_default() or ""
            self._set("world", slug)
        name, ready = slug, False
        try:
            meta = json.loads((self.data / "worlds" / slug / "world.json").read_text(encoding="utf-8"))
            name = meta.get("name") or slug
            home = self.keep / "play" / slug if self.keep is not None else self.data / "worlds" / slug
            party = json.loads((home / "party.json").read_text(encoding="utf-8"))
            ready = bool(party.get("members"))
        except (OSError, ValueError):
            pass
        return {"world": name, "slug": slug, "can_continue": ready, "title": "YanCo Branded RPG"}

    def api_start(self, how: str = "continue") -> dict:
        """Open the world and the game: "continue" (the party as it was) or "new" (a new run, with ready-made
        heroes until the character creator comes to the browser)."""
        from game import party as P
        from game import places, saves
        from game.events import EventBus
        from game.explore import Explorer
        from game.state import GameState
        from web.scene import Scene
        slug = self.api_boot()["slug"]
        if self.world is not None:
            self.world.close()
        self._restore(slug)                         # the playthrough, back into the world's folder
        self.world = self.worlds.open(slug)
        if how == "new":
            saves.new_run(self.world)
        self.bus = EventBus()
        self.bus.on("log", self._heard)
        self._stale = set()                         # map blocks to draw again (game/landchanges.py)
        self.bus.on("land.changed", lambda e: self._stale.add((e.get("cx"), e.get("cy"))))
        self._wire()
        self.members = P.load(self.world, defaults=False)      # (empty: the page asks who's going)
        self.state = GameState(self.world, self.bus)
        try:
            from game import worldfill
            worldfill.ensure(self.world)
        except Exception:  # noqa: BLE001
            pass
        from game import worldmap
        if worldmap.walkable(self.world):
            worldmap.load_continent(self.world, worldmap.party_continent_id(self.world, self.state))
        from game.quests import QuestBook
        self.book = QuestBook(self.world, self.state, self.bus, levels=lambda: [max(1, int(m.get("level") or 1))
                                                                               for m in self.members] or [1])
        from game.mechanics import MechanicsEngine
        self.fight, self.fstate = None, {}
        self.mechanics = MechanicsEngine(self.world, self.state, self.bus,
                                         battle=lambda: self.fight.battle if self.fight is not None else None,
                                         members=lambda: self.members, book=self.book)
        places.current(self.world, self.state)
        self.ex = Explorer(self.world, self.state, self.bus, members=lambda: self.members, rng=self.rng)
        self.ex.sync()
        self.scene = Scene(self.ex, self.world)
        self._party_sprite()
        self.book.check_all()
        if how == "new":
            self.say("narration", f"Your party sets out in {self.world.name}.")
        self._announce()
        out = self.api_view()
        if not self.members:                   # a new game: make the heroes (or take ready-made ones)
            out["welcome"] = {"world": self.world.name, "first": how == "new"}
        return out

    def _party_sprite(self) -> None:
        from game.art.doll import Gear
        from game.art.library import render_look
        from game.constants import SIZES
        from game.explore import face_of
        face = face_of(self.world, self.members)
        m = next((x for x in self.members if face and x.get("id") == face.get("id")), None) or \
            (self.members[0] if self.members else None)
        if m is None:
            return
        race = self.world.entities.get(m.get("race") or "")
        look = dict((race.fields.get("appearance") or {}) if race else {})
        look.update({k: v for k, v in (m.get("look") or {}).items() if v})
        look.setdefault("base", "human")
        gear = Gear()
        for slot, item_id in (m.get("equipment") or {}).items():
            item = self.world.entities.get(item_id)
            if item:
                self.world.sprites.apply_item(gear, item, slot)
        tiles = SIZES.get((race.fields.get("size") if race else "Medium") or "Medium", 1)
        self.scene.set_party(render_look(look, gear, tiles))

    # ==================================================================
    # The log
    # ==================================================================
    def _heard(self, e: dict) -> None:
        text = e.get("text") or ""
        if text:
            self.log.append({"n": len(self.log), "kind": e.get("kind") or "narration", "text": wording.say(text)})
            del self.log[:-400]

    def say(self, kind: str, text: str) -> None:
        self.bus.emit("log", kind=kind, text=text)

    def _announce(self) -> None:
        from game import places
        spot = places.current(self.world, self.state)
        desc = getattr(spot, "description", "") or ""
        if spot.name:
            self.say("place", spot.name)
        if desc:
            self.say("narration", places.short_description(desc))

    # ==================================================================
    # What the page shows
    # ==================================================================
    def api_view(self, since: int = -1) -> dict:
        """Everything the page needs after anything happens: the status line, the hint, the menu or prompt
        that's open, and what's new in the log."""
        from game.walkhud import hint_words, status_bits
        short, full = status_bits(self.ex)
        hint = hint_words(self.ex)
        if hint.startswith("E   "):
            hint = {"touch": "Interact · ", "pad": "A   "}.get(wording.how(), "E   ") + hint[4:]
        first = 0 if since < 0 else since + 1
        return {"hud": short, "hud_full": full, "hint": hint, "menu": self._menu_json(),
                "fighting": self.fight is not None, "panel": self.pnl is not None, "placing": self._ghost(),
                "playing": self.play is not None,
                "log": [x for x in self.log if x["n"] >= first][-60:],
                "area": id(self.ex.area) if self.ex.area is not None else 0, "level": self.ex.level,
                "x": self.ex.x, "y": self.ex.y, "w": self.ex.area.w if self.ex.area else 0,
                "h": self.ex.area.h if self.ex.area else 0, "travelling": self.ex.travelling()}

    def _menu_json(self) -> dict | None:
        m = self.menu
        if m is None:
            return None
        return {"kind": self.menu_kind, "title": m.title, "context": getattr(m, "context", ""),
                "groups": list(m.groups or []),
                "choices": [{"label": c.label, "note": c.note, "desc": c.desc, "enabled": c.enabled,
                             "group": c.group or "", "go": c.label} for c in m.choices],
                "go": getattr(m, "go", "") or ""}

    # the map's pictures (web/scene.py)
    def api_chunk(self, level: str, cx: int, cy: int) -> dict:
        return self.scene.chunk(level, cx, cy)

    def api_tiles(self, keys: list) -> dict:
        out = {}
        for k in keys:
            try:
                out[k] = self.scene.tile(k)
            except Exception:  # noqa: BLE001 - a tile that can't be made shows as nothing
                out[k] = ""
        return out

    def api_frame(self, x0: int, y0: int, x1: int, y1: int) -> dict:
        return self.scene.frame(x0, y0, x1, y1)

    def api_sprites(self, keys: list) -> dict:
        """[[key, turn, step], ...] -> {"key@turn~step": png}"""
        out = {}
        for key, turn, step in keys:
            out[f"{key}@{turn}~{step}"] = self.scene.sprite(key, int(turn), int(step)) or ""
        return out

    def api_roof(self, bid: str) -> dict:
        return self.scene.roof(bid) or {}

    # ==================================================================
    # Walking and the six commands
    # ==================================================================
    def api_step(self, dir: str) -> dict:  # noqa: A002 - the page's word
        if self.menu is not None or self.fight is not None:
            return self.api_view()
        if self.placing is not None:                       # marking out a building: the D-pad moves it
            for d in dir:
                self._place_key(d)
            return self.api_view()
        res = self.ex.step(dir)
        if not res.moved and len(dir) == 2:                 # sliding along a wall
            for one in (dir[0], dir[1]):
                r2 = self.ex.step(one)
                if r2.moved or r2.prompt or r2.action:
                    res = r2
                    break
        out = self._handle(res)
        out["moved"] = bool(res.moved)
        return out

    def api_tick(self) -> dict:
        """Every second or so: people wander, encounters close in, the world goes on."""
        if self.menu is not None or self.ex is None or self.fight is not None:
            return {"changed": False}
        before = (len(self.ex.tokens), tuple((t.x, t.y) for t in self.ex.tokens[:40]))
        self.ex.refresh_people()
        moved = self.ex.wander()
        res = self.ex.tick()
        out = self._handle(res) if (res.message or res.action or res.prompt) else {}
        out["changed"] = bool(moved) or before != (len(self.ex.tokens), tuple((t.x, t.y) for t in self.ex.tokens[:40]))
        self._autosave()
        return out

    def api_command(self, key: str) -> dict:
        if self.placing is not None:                       # Interact puts it down, Action turns it, Back stops
            self._place_key({"interact": "put", "action": "rotate", "back": "stop"}.get(key, ""))
            return self.api_view()
        if key == "interact":
            return self._handle(self.ex.interact())
        if key == "back":
            return self.api_close()
        if key == "map":
            self.say("system", STAGE_LATER.replace("That", "The big map"))
            return self.api_view()
        if key == "check":
            self._open(self._check_menu(), "check")
        elif key == "action":
            from game import places
            spot = places.current(self.world, self.state)
            dungeon = bool(self.ex.area is not None and self.ex.area.kind == "dungeon")
            self._open(H.action_menu(spot.name or "Here", spot.kind in ("wild", "road"), dungeon), "action")
        elif key == "rest":
            from game import places
            act, why = H.long_rest_here(places.current(self.world, self.state))
            self._open(H.rest_menu(self.state.minute_of_day, act, why, self.state.clock_text()), "rest")
        return self.api_view()

    def _open(self, menu: H.Menu, kind: str) -> None:
        self.menu, self.menu_kind = menu, kind

    def api_close(self) -> dict:
        kind = self.menu_kind
        self.menu, self.menu_kind = None, ""
        if kind == "prompt":
            self.prompt = None
            return self._handle(self.ex.choose(("none",)))
        return self.api_view()

    def api_pick(self, index: int) -> dict:
        """A choice in the open menu (index into its whole list)."""
        m = self.menu
        if m is None or not (0 <= index < len(m.choices)):
            return self.api_view()
        ch = m.choices[index]
        if not ch.enabled:
            return self.api_view()
        kind = self.menu_kind
        self.menu, self.menu_kind = None, ""
        a = ch.action
        if kind == "prompt":
            self.prompt = None
            return self._handle(self.ex.choose(tuple(a)))
        if not a:
            return self.api_view()
        if a[0] == "check":
            self._roll(a[1])
        elif a[0] == "look":
            self._announce()
        elif a[0] == "wait":
            self._map_action(("wait", a[1]))
        elif a[0] == "activity":
            self._activity(a[1])
        return self.api_view()

    def _check_menu(self) -> H.Menu:
        from game import checks, condition
        members = [x for x in self.members if not x.get("dead")]
        who = members[0] if members else None
        opts = checks.options(self.world)
        bonuses = {}
        if who is not None:
            c = condition.combatant(self.world, who)
            for o in opts:
                try:
                    bonuses[o["id"]] = checks.bonus(self.world, who, c, o)[0]
                except Exception:  # noqa: BLE001
                    bonuses[o["id"]] = 0
        self._roller = who
        facing = ""
        self._target = None
        t = self.ex.token_at(*self.ex.facing_cell()) if self.ex.area is not None else None
        if t is not None and self.ex.shown(t):
            e = self.world.entities.get(getattr(t, "entity", "") or "")
            if e is not None and e.type == "npc":
                self._target, facing = {"npc": e.id, "id": e.id, "name": e.name}, "npc"
        if not facing:
            from game import places
            if places.current(self.world, self.state).kind in ("wild", "road"):
                facing = "wild"
        return H.check_menu(opts, bonuses, facing, (who or {}).get("name", ""))

    def _roll(self, option_id: str) -> None:
        from game import checks, condition
        who = self._roller
        o = next((x for x in checks.options(self.world) if x["id"] == option_id), None)
        if who is None or o is None:
            return
        c = condition.combatant(self.world, who)
        target = self._target or {}
        social = o["label"].lower() in ("persuasion", "deception", "intimidation", "insight", "performance")
        if not getattr(self, "_natural", None) and self._check_as_game(who, c, o, lambda nat: self._roll_with(option_id, nat)):
            return                                     # played as its minigame first (web/games.py)
        r = checks.roll(self.world, who, c, o, 0, "normal", self.rng, self.bus,
                        target=target.get("name", "") if social else "")
        if r.get("total") is not None:
            sign = "+" if r["bonus"] >= 0 else "-"
            self.say("system", f"{c.name}: {o['label']} {r['roll']} {sign} {abs(r['bonus'])} = {r['total']}")
        elif r.get("text"):
            self.say("system", r["text"])

    def _roll_with(self, option_id: str, natural) -> None:
        """The check again, its die the minigame's result (None: the dice after all)."""
        from game import checks
        self._natural = True
        keep = checks.minigame
        if natural is not None:
            checks.minigame = lambda *a, **k: natural
        try:
            self._roll(option_id)
        finally:
            checks.minigame = keep
            self._natural = False

    # ==================================================================
    # What the walking map asks for
    # ==================================================================
    def _handle(self, res) -> dict:
        if res is None:
            return self.api_view()
        if res.message:
            self.say("narration", res.message)
        if res.entered:
            self._announce()
        if res.prompt is not None:
            self.prompt = res.prompt
            self._open(H.prompt_menu(res.prompt), "prompt")
        if res.action is not None:
            self._map_action(res.action)
        return self.api_view()

    def _map_action(self, action) -> None:
        from game import places
        what = action[0]
        if what == "wait":
            how = action[1] if len(action) > 1 else 60
            if how in ("morning", "evening"):
                want = 7 * 60 if how == "morning" else 18 * 60
                how = (want - self.state.minute_of_day) % 1440 or 1440
            self._fx("timeskip", 0.8)
            self.state.advance(int(how), "waiting")
            self.say("narration", f"Time passes. It is now {self.state.clock_text()}.")
        elif what == "activity":
            self._activity(action[1])
        elif what == "jail":                               # locked up (game/jail.py)
            self._jail_act(tuple(action))
        elif what == "trap":                               # a dungeon trap (game/traps.py)
            self._trap_act(tuple(action))
        elif what in ("thief", "mug"):                     # a cutpurse, muggers (game/thieves.py)
            self._thief_act(tuple(action))
        elif what == "homeless":                           # one of the town's homeless (game/homeless.py)
            from game import homeless
            for line in homeless.act(self.world, self.state, self.ex, tuple(action), self.bus)["lines"]:
                if "works for you" not in line:            # (that one's in the log already)
                    self.say("narration", line)
            self.api_save()
        elif what == "wilds":
            self._map_action(("go", action[1]))
        elif what == "map":
            pass                                           # (the page's Map button opens the world map)
        elif what == "enter":
            if action[1] and action[1] != self.state.location:
                places.enter(self.world, self.state, action[1], self.bus, walking=True)
        elif what == "go":
            target = action[1]
            if self._go_far(target):                      # a road, the next leg of a journey, a voyage
                pass
            else:
                dest = places.parse(self.world, target)
                if dest.kind == "building" and not places.is_open(dest.building, self.state.minute_of_day):
                    self.say("system", f"{dest.name} is closed. It opens at {places.opens_at(dest.building)}.")
                else:
                    if dest.kind == "wild":
                        self.say("narration", f"You leave the town behind, heading {dest.direction.lower()}.")
                    if places.travel(self.world, self.state, target, self.bus):
                        self.ex.sync()
                        self._announce()
        elif what == "battle":
            info = self.ex.group_info(action[1]) if len(action) > 1 else None
            if info is not None:
                cells = [(t.x, t.y) for t in info["tokens"]]
                self.ex.remove_group(action[1])
                if info.get("raid"):
                    self._raid_fight(info["rows"], cells)
                else:
                    self._encounter({"rows": info["rows"], "text": info.get("text") or "", "foe_cells": cells,
                                     "environment": info.get("environment") or "plains"})
        elif what == "fight" and len(action) > 1:
            self._fight_npc(action[1])
        elif what == "chat" and len(action) > 1:
            self._talk(action[1])
        elif what == "trade" and len(action) > 1:
            self._open_trade(action[1])
        elif what == "check":
            self._open(self._check_menu(), "check")
            return
        elif what == "craft":
            self._open_craft(action[1], action[2] if len(action) > 2 else "", action[3] if len(action) > 3 else "")
        elif what == "gather":
            from web.sound import WORK_SOUND
            got = self.ex.gather_target(int(action[1]), int(action[2]))
            self._fx(WORK_SOUND.get(got[4] if got is not None else "", "click"), 0.7)
            out = self.ex.gather(int(action[1]), int(action[2]), int(action[3]) if len(action) > 3 else 1)
            for line, ok in zip(out["lines"], out["oks"] + [False] * len(out["lines"])):
                self.say("loot" if ok else "narration", line)
            if out["items"]:
                self._fx("coins", 0.4)
            if out["found"]:
                self.say("narration", out["found"])
        elif what == "shelf":
            self._open_bookshelf(self.world.entities.get(action[1]), (int(action[2]), int(action[3])))
        elif what == "estate_placed":
            self._estate_placed(action[1])
        elif what == "games":
            self._open_games(self.world.entities.get(action[1]))
        elif what in ("pickpocket", "steal", "rob"):
            self._do_crime(what, action[1] if len(action) > 1 else "")
        elif what == "law":
            self._law_choice(action[1], action[2] if len(action) > 2 else "")
        elif what == "tame":
            r = self.ex.tame(action[1], self.rng) or {}
            if r.get("text"):
                self.say("loot" if r.get("result") == "tamed" else "narration", r["text"])
            if r.get("result") == "tamed":
                self._new_animal(r.get("animal"))
            elif r.get("result") == "angry":
                self._map_action(("battle", r.get("group")))
                return
        else:
            self.say("system", STAGE_LATER)
        self.ex.sync()

    def _activity(self, what: str) -> None:
        from game import condition, places
        if what.startswith(("rest:", "search", "investigate:")):
            self._fx("timeskip", 0.8)                  # (the app's time-skip scene)
        if what == "rest:short":
            condition.short_rest(self.world, self.state, self.members, self.rng, self.bus)
        elif what == "rest:home":
            from game import homes
            spot = places.current(self.world, self.state)
            if spot.building is not None and spot.building.fields.get("owner"):
                homes.rest(self.world, self.state, spot.building, self.members, self.bus)
        elif what == "rest:inn":
            spot = places.current(self.world, self.state)
            price = int(float((spot.building.fields.get("inn_price") if spot.building else 0) or 0) * 100)
            if condition.can_long_rest(self.state):
                condition.long_rest(self.world, self.state, self.members, self.bus)
            elif price > self.state.copper:
                self.say("system", "You can't afford the rooms.")
            else:
                self.state.add_copper(-price, "rooms for the night")
                bed = places.guest_room(self.world, spot)
                if bed:
                    self.ex.give_key(bed)
                if bed and bed != spot.id:
                    places.enter(self.world, self.state, bed, self.bus, announce=False)
                    self.say("narration", f"You're shown up to the {places.parse(self.world, bed).name.lower()}.")
                condition.long_rest(self.world, self.state, self.members, self.bus)
        elif what == "rest:camp":
            if condition.can_long_rest(self.state):
                condition.long_rest(self.world, self.state, self.members, self.bus)
                return
            from game import travel
            spot = places.current(self.world, self.state)
            chance = (self.state.journey or {}).get("danger") if spot.kind == "road" else None
            chance = int(chance if chance is not None else self.world.rules.get("camp_encounter_chance", 25))
            if self.rng.random() < chance / 100.0:
                terrain = (spot.extra.get("biome") or "Plains") if spot.kind == "hex" else travel.terrain_of(spot.town)
                found = travel.encounter(self.world, terrain, self._levels(), self.rng, night=True)
                if found:
                    self.state.advance(3 * 60, "camping")
                    found["text"] = "In the dead of night, something finds your camp. " + found["text"]
                    self._encounter(found, then=lambda outcome: condition.long_rest(
                        self.world, self.state, self.members, self.bus, minutes=5 * 60)
                        if outcome == "victory" else None)
                    return
            condition.long_rest(self.world, self.state, self.members, self.bus)
        elif what == "search":
            from game import dungeons as D
            _ok, text = D.search_secrets(self.world, self.state, places.current(self.world, self.state).id,
                                         self.members, self.rng)
            self.say("narration", text)
            from game import traps
            n, lines = traps.search(self.world, self.state, self.ex, self.members, self.rng)
            for line in lines:
                self.say("system", line)
            if not n and self.ex is not None and self.ex.area is not None and self.ex.area.kind == "dungeon":
                self.say("narration", "No traps that you can find.")
        elif what == "search:land":
            ok, text = self.ex.search_land()
            self.say("loot" if ok else "narration", text)
        elif what == "loot":
            from game import dungeons as D
            text = D.take_loot(self.world, self.state, places.current(self.world, self.state).id, self.rng)
            if text:
                self.say("loot", text)
        elif what == "special":
            from game import dungeons as D
            text = D.use_special(self.world, self.state, places.current(self.world, self.state).id, self.members,
                                 self.rng, self.bus)
            if text:
                self.say("loot", text)
        elif what.startswith("investigate:"):
            _w, qid, idx = what.split(":")
            ok, text = self.book.investigate(qid, int(idx), self.members, self.rng)
            self.say("quest" if ok else "narration", text)
        elif what == "notice":
            from game import rumors
            spot = places.current(self.world, self.state)
            mem = self.state.npc(f"board:{spot.building.id if spot.building else spot.id}")
            if mem.get("day") == self.state.day:
                self.say("narration", "Nothing new on the board since this morning.")
            else:
                mem["day"] = self.state.day
                r = rumors.hear(self.world, self.state, spot.town, self.rng, source="the notice board",
                                kinds=("quest", "lair", "relic", "festival"), bus=self.bus) \
                    if spot.town is not None else None
                if r is None:
                    self.say("narration", "Lost dogs, a lute for sale, a wedding. Nothing for you.")
        elif what.startswith("survival:"):
            from game import survival
            if what == "survival:meal":
                survival.hot_meal(self.world, self.state, self.members, self.bus)
            else:
                text = survival.refill(self.world, self.state, self.members, what != "survival:refill-wild", self.bus)
                if text.startswith("You've nothing"):
                    self.say("system", text)
        elif what.startswith("flyer:"):
            from game import lots
            text = lots.take_flyer(self.world, self.state, self.book, what.split(":", 1)[1])
            if text:
                self.say("narration", text)
        elif what.startswith("craft:"):
            self._open_craft(what.split(":", 1)[1], f"camp|{self.state.location}")
        elif what.startswith("read:"):
            self._read_book(what.split(":", 1)[1])
        elif what == "animals":
            spot = places.current(self.world, self.state)
            self._open_animals(spot.building if spot.kind == "building" else None)
        elif what == "tame:look":
            self._look_for_animals()
        elif what == "estate" or what.startswith("estate:"):
            self._estate_activity(what)
        elif what == "home:buy":
            from game import homes
            spot = places.current(self.world, self.state)
            ok, price, why = homes.can_buy(self.world, self.state, spot)
            if not ok:
                self.say("system", why)
            else:
                from web.panel import Panel

                def buy(p):
                    leader = next((m.get("name") for m in self.members if not m.get("dead")), "")
                    b = homes.buy(self.world, self.state, spot, leader, self.bus)
                    places.enter(self.world, self.state, b.id, self.bus)
                    self._announce()
                    p.closed = True
                self._panel(Panel("Buy a house", lambda p: (
                    p.text(f"Buy a small house on {spot.street} in {spot.town.name} for {price} gp? It comes with a front "
                           f"room, a bedroom and a kitchen, and you can build onto it."),
                    p.option("Buy it", buy, style="primary")), close="Not now"))
        elif what == "home:furnish":
            spot = places.current(self.world, self.state)
            if spot.building is not None and spot.building.fields.get("owner"):
                self._furnish(spot.building)
        elif what == "home:build":
            from game import homes
            spot = places.current(self.world, self.state)
            if spot.building is not None and not homes.can_extend(spot.building):
                self.say("system", "A building in town can't grow past its walls: furnish it from within instead.")
            elif spot.building is not None and spot.building.fields.get("owner"):
                self._build_onto(spot.building)
        elif what == "raid:fight":
            from game import townevents as TE
            raid = TE.raid_here(self.world, self.state)
            if raid is not None:
                self._raid_fight(TE.wave_rows(raid))
        elif what == "games":
            spot = places.current(self.world, self.state)
            self._open_games(spot.building)
        elif what == "arena":
            spot = places.current(self.world, self.state)
            self._open_arena_house(spot.building)
        elif what == "festival":
            self._open_festival()
        elif what.startswith("crime:"):
            parts = what.split(":")
            self._do_crime(parts[1], parts[2] if len(parts) > 2 else "")
        elif what == "law:face":
            self._face_the_law()
        elif what == "explore":
            from game import travel
            r = travel.explore(self.world, self.state, self.rng, self._levels(), self.book,
                               int(self.world.rules.get("wild_encounter_chance", 35)))
            if r.get("kind") == "encounter":
                self._encounter(r)
            else:
                self.say("narration", r.get("text") or "")
        else:
            self.say("system", STAGE_LATER)

    # ==================================================================
    # Saving
    # ==================================================================
    def _autosave(self) -> None:
        if time.monotonic() - self._last_save > 60:
            self.api_save()

    def api_save(self) -> dict:
        from game import saves
        from game import party as P
        if self.world is None:
            return {"saved": False}
        self._last_save = time.monotonic()
        self.ex.save()
        P.save(self.world, self.members)
        try:
            saves.autosave(self.world, self.state, self.members)
        except OSError as exc:
            self.say("system", f"Couldn't save: {exc}")
            return {"saved": False}
        self._keep_play()
        return {"saved": True}

    # ---- the playthrough, in the browser's lasting storage
    def _play_files(self, folder: Path):
        for f in folder.rglob("*"):
            rel = f.relative_to(folder)
            if f.is_file() and rel.parts[0] not in WORLD_ONLY:
                yield f, rel

    def _restore(self, slug: str) -> None:
        if self.keep is None:
            return
        import shutil
        src, dst = self.keep / "play" / slug, self.data / "worlds" / slug
        if not src.is_dir():
            return
        for _f, rel in list(self._play_files(dst)):        # what the zip brought: the bundled start
            (dst / rel).unlink()
        for f, rel in self._play_files(src):
            (dst / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dst / rel)

    # ==================================================================
    # Jail (game/jail.py)
    # ==================================================================
    def _jail_act(self, action: tuple) -> None:
        from game import jail
        out = jail.act(self.world, self.state, self.members, self.ex, action, self.rng, self.bus)
        if out.get("skip"):
            self._fx("timeskip", 0.8)
        if out.get("released"):
            self._fx("door_open", 0.8)
        if out.get("text"):
            self.say(out.get("kind") or "system", out["text"])
        if out.get("fight"):
            self._encounter({"rows": out["fight"], "text": "The guards draw their cudgels!", "environment": "urban"})
            return
        self.ex.refresh_people(force=True)
        self.api_save()

    def _trap_act(self, action: tuple) -> None:
        from game import dungeons as D
        from game import traps
        if action[1] == "alarm":                     # an alarm went off: the nearest room's monsters come
            d = self.world.entities.get(action[2])
            r = D.room(d, action[3]) if d is not None else None
            foes = D.room_foes(self.world, d, r, self.rng) if r is not None else []
            if foes:
                key = (d.id, action[3])
                self._encounter({"rows": [{"id": e.id, "count": n} for e, n in foes], "text": "To arms!",
                                 "environment": D.ENVIRONMENT.get(d.fields.get("kind") or "Other", "dungeon")},
                                then=lambda outcome, k=key: D.mark_cleared(self.state, k)
                                if outcome == "victory" else None)
            return
        out = traps.act(self.world, self.state, self.members, self.ex, action, self.rng, self.bus)
        for line in out.get("lines") or []:
            self.say("damage" if "damage" in line else "system", line)
        if out.get("fight"):
            self._trap_act(("trap", "alarm", out["key"][0], out["key"][1]))
            return
        self.api_save()

    def _thief_act(self, action: tuple) -> None:
        from game import thieves
        out = thieves.act(self.world, self.state, self.members, self.ex, action, self.rng, self.bus)
        for line in out.get("lines") or []:
            self.say("loot" if "gp" in line and "take" not in line else "narration", line)
        if out.get("fight"):
            self._encounter({"rows": out["fight"], "text": "The muggers come at you!", "environment": "urban"},
                            then=lambda outcome: thieves.fought(self.state, outcome))
            return
        self.api_save()

    def _jail_due(self, out: dict) -> None:
        """Dawn on the day of a hanging, with the party still in its cell: the end (whatever the world's
        'party falls' rule; a save can still be loaded unless it's Hardcore)."""
        from game import jail, saves
        due = jail.due(self.state)
        if due == "free":                           # the sentence ran out while waiting some other way
            self.say("narration", jail.release(self.world, self.state, self.members, self.ex, self.bus, "served"))
            self.api_save()
            return
        if due != "hang":
            return
        text = jail.execute(self.world, self.state, self.members, self.bus)
        self.say("narration", text)
        hardcore = saves.hardcore(self.world)
        if hardcore:
            saves.wipe_run(self.world)
        self._keep_play()
        out["executed"] = {"hardcore": hardcore, "can_load": not hardcore and bool(saves.list_saves(self.world)),
                           "text": text + (" This world plays Hardcore: the run is over." if hardcore else "")}

    def _keep_play(self) -> None:
        if self.keep is None or self.world is None:
            return
        import shutil
        src, dst = Path(self.world.path), self.keep / "play" / self.world.slug
        self._kept = True
        shutil.rmtree(dst, ignore_errors=True)
        for f, rel in self._play_files(src):
            (dst / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dst / rel)


_SESSION: Session | None = None


def call(name: str, args_json: str = "{}", data_dir: str = "/game", keep_dir: str = "/data") -> str:
    """For the page (through Pyodide): JSON in, JSON out. data_dir is in memory (the worlds, unpacked each
    visit); keep_dir is the browser's lasting storage (the playthroughs)."""
    global _SESSION
    if _SESSION is None:
        _SESSION = Session(data_dir, keep_dir=keep_dir)
    return json.dumps(_SESSION.call(name, json.loads(args_json or "{}")))


__all__ = ["Session", "call"]
