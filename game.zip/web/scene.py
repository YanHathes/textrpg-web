"""What the walking map shows, for a web page to draw (the browser version, stage 1).

The desktop and Android game draw the walking map with Qt (ui/explore_view.py). A browser can't run Qt, so
here the same decisions are made without it, and handed to the page as plain data: the page (web/site/map.js)
does the drawing on a canvas. Nothing here draws a whole picture pixel by pixel in Python, which would be
slow inside a browser: the page draws everything from small pictures (tiles and sprites) that Python makes
once each, as PNGs, by key.

    Scene(explorer, world)
    .chunk(level, cx, cy)      a CH x CH block of squares: [[tile key, x, y], ...] and the shadows on it
    .tile(key)                 a tile's PNG (floors, walls, water, roofs, props, doors...)
    .frame(x0, y0, x1, y1)     what changes as the party walks: what's in sight, doors, people, roofs, the
                               party itself, the never-seen squares and the dark of the hour
    .sprite(key, turn, step)   a figure's PNG, turned (0 south, 1 west, 2 north, 3 east) and mid-stride
    .roof(bid)                 a building's whole roof as one PNG
"""
from __future__ import annotations

import base64

from game import area as A
from game import explore as X
from game import maplight as ML
from game.art import tiles as TL
from game.art.canvas import Canvas

T = TL.T                      # art pixels to a square
CH = 16                       # squares to a side of a block (as ui/explore_view.py)
PROP_RISE = TL.PROP_RISE


def _v(x: int, y: int) -> int:
    return (((x * 92837111) ^ (y * 689287499)) >> 4) & 3


def _gv(x: int, y: int) -> int:
    return ((x * 73856093) ^ (y * 19349663)) % 16


def _mask(test, x: int, y: int) -> int:
    m = 0
    for bit, (dx, dy) in ((TL.N, (0, -1)), (TL.E, (1, 0)), (TL.S, (0, 1)), (TL.W, (-1, 0))):
        if test(x + dx, y + dy):
            m |= bit
    return m


def _fringe(lv, x: int, y: int, f: str):
    mine = TL.SPILL[f]
    best, mask = None, 0
    for bit, (dx, dy) in ((TL.N, (0, -1)), (TL.E, (1, 0)), (TL.S, (0, 1)), (TL.W, (-1, 0))):
        if not lv.inside(x + dx, y + dy) or (x + dx, y + dy) in lv.water:
            continue
        o = lv.floor_at(x + dx, y + dy)
        if TL.SPILL.get(o, 0) <= mine:
            continue
        if best is None or TL.SPILL[o] > TL.SPILL[best]:
            best, mask = o, bit
        elif o == best:
            mask |= bit
    return None if best is None else (best, mask)


def png64(c: Canvas) -> str:
    return base64.b64encode(c.to_png()).decode("ascii")


def png_rgba(w: int, h: int, data: bytes, level: int = 6) -> str:
    """Raw RGBA bytes as a PNG (base64), without going through a Canvas pixel by pixel."""
    import struct
    import zlib
    row = w * 4
    raw = b"".join(b"\x00" + data[y * row:(y + 1) * row] for y in range(h))

    def chunk(tag: bytes, body: bytes) -> bytes:
        return struct.pack(">I", len(body)) + tag + body + struct.pack(">I", zlib.crc32(tag + body) & 0xFFFFFFFF)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, level)) + chunk(b"IEND", b""))
    return base64.b64encode(png).decode("ascii")


# ----------------------------------------------------------------------
# Tiles, by key: "kind|arg|arg..." (made by game/art/tiles.py)
# ----------------------------------------------------------------------
def _b(s: str) -> bool:
    return s == "1"


TILE_MAKERS = {
    "earth": lambda a: TL.earth_tile(int(a[0])),
    "floor": lambda a: TL.floor_tile(a[0], int(a[1])),
    "roof": lambda a: TL.roof_tile_in(a[0] or "Wooden", int(a[1]), int(a[2]), _b(a[3]) if len(a) > 3 else False),
    "fringe": lambda a: TL.fringe_tile(a[0], int(a[1]), int(a[2])),
    "water": lambda a: TL.water_tile(int(a[0]), int(a[1]), a[2]),
    "season": lambda a: TL.season_tile(a[0], a[1], int(a[2])),
    "ground": lambda a: TL.ground_tile(a[0], a[1], int(a[2])),
    "win": lambda a: TL.window_tile(a[0], int(a[1]), _b(a[2])),
    "wall": lambda a: TL.wall_tile(a[0], int(a[1])),
    "prop": lambda a: (TL.prop_sprite_in(a[0], int(a[1]), a[2], _b(a[3])) if (a[2] or _b(a[3]))
                       else TL.prop_sprite(a[0], int(a[1]))),
    "door": lambda a: TL.door_sprite(a[0], _b(a[1]), _b(a[2])),
    "trap": lambda a: TL.trap_sprite(a[0], a[1]),
    "flame": lambda a: TL.flame_sprite(int(a[0]), int(a[1])),
    "crack": lambda a: TL.crack_sprite(int(a[0])),
}


def tile_canvas(key: str) -> Canvas:
    kind, *args = key.split("|")
    return TILE_MAKERS[kind](args)


class Scene:
    def __init__(self, explorer, world) -> None:
        self.ex = explorer
        self.world = world
        self.look = ("", "")                 # (season, ground) the blocks were drawn for
        self.party_key = "party"             # the party's figure (set_party)
        self._party_n = 1
        self.sources: dict = {}              # sprite key -> Canvas (facing south)
        self._props: dict = {}               # prop key -> (w, h) of its art (for its offset)

    # ---- the season and the ground (the blocks are drawn for them)
    def conditions(self):
        ex = self.ex
        if ex.area is None or ex.area.kind == "dungeon":
            return None, ("", "")
        try:
            w = ex.weather()
        except Exception:  # noqa: BLE001 - no weather is better than no map
            w = None
        return w, ((w.season, w.ground) if w is not None else ("", ""))

    # ---- blocks of the map
    def _prop_key(self, pr, season: str, snow: bool) -> str:
        if (season or snow) and not self.ex.area.cell_building.get((pr.x, pr.y)):
            return f"prop|{pr.id}|{pr.variant}|{season}|{int(snow)}"
        return f"prop|{pr.id}|{pr.variant}||0"

    def _prop_size(self, key: str) -> tuple[int, int]:
        got = self._props.get(key)
        if got is None:
            c = tile_canvas(key)
            got = self._props[key] = (c.w, c.h)
        return got

    def chunk(self, level: str, cx: int, cy: int) -> dict:
        """One block: the tiles to draw, in order, at art-pixel offsets in the block (CH * T across), and the
        dark bands of the walls' shadows. Mirrors ExploreView._paint_chunk."""
        a = self.ex.area
        _w, look = self.conditions()
        self.look = look
        season, ground = look
        snow = ground == "snow"
        lvk = self._chunk_level(level, cx, cy)
        ops, shade = [], []
        x0, y0 = cx * CH, cy * CH
        props = {}
        for y in range(y0 - 1, y0 + CH + PROP_RISE):
            for x in range(x0 - 1, x0 + CH + 1):
                if not (0 <= x < a.w and 0 <= y < a.h):
                    continue
                lv = a.layer(lvk, x, y)
                pr = lv.prop_cells.get((x, y))
                if pr is not None:
                    props[id(pr)] = pr
                if not (x0 <= x < x0 + CH and y0 <= y < y0 + CH):
                    continue
                px, py = (x - x0) * T, (y - y0) * T
                f = lv.floor_at(x, y)
                v = _v(x, y)
                if f == A.ROOF:
                    m = _mask(lambda xx, yy: lv.floor_at(xx, yy) == A.ROOF, x, y)
                    ops.append([f"roof|{lv.roof or 'Wooden'}|{m}|{v % 3}|0", px, py])
                    shade.append([px, py, T, T, 60])
                    continue
                if f in (A.EARTH, A.VOID):
                    ops.append([f"earth|{v % 3}", px, py])
                else:
                    ops.append([f"floor|{f}|{v}", px, py])
                if f in TL.SPILL and (x, y) not in lv.water:
                    edge = _fringe(lv, x, y, f)
                    if edge is not None:
                        ops.append([f"fringe|{edge[0]}|{edge[1]}|{v}", px, py])
                if (x, y) in lv.water:
                    m = _mask(lambda xx, yy: (xx, yy) in lv.water, x, y)
                    ops.append([f"water|{m}|{v}|{lv.water[(x, y)]}", px, py])
                elif (season or ground) and f in TL.OUTDOOR_FLOORS and not lv.overlay and \
                        (x, y) not in a.cell_building:
                    gv = _gv(x, y)
                    if season and ground != "snow":
                        ops.append([f"season|{season}|{f}|{gv}", px, py])
                    if ground:
                        ops.append([f"ground|{ground}|{f}|{gv}", px, py])
        for y in range(y0, y0 + CH):                       # wall shadows on the floor below them
            for x in range(x0, x0 + CH):
                if not (0 <= x < a.w and 0 <= y < a.h):
                    continue
                lv = a.layer(lvk, x, y)
                if (x, y) in lv.walls and (x, y + 1) not in lv.walls and lv.floor_at(x, y + 1) not in A.SOLID:
                    px, py = (x - x0) * T, (y + 1 - y0) * T
                    for d in range(6):
                        shade.append([px, py + d, T, 1, int(120 * (1 - d / 6))])
        walls = []
        for y in range(y0, y0 + CH):
            for x in range(x0, x0 + CH):
                if not (0 <= x < a.w and 0 <= y < a.h):
                    continue
                lv = a.layer(lvk, x, y)
                kind = lv.walls.get((x, y))
                if kind is None:
                    d = lv.doors.get((x, y))
                    if d is None or not self.ex.secret_hidden(lv, (x, y)):
                        continue
                    kind = d.get("wall") or "stone_wall"
                m = _mask(lambda xx, yy: (xx, yy) in lv.walls or (xx, yy) in lv.doors, x, y)
                px, py = (x - x0) * T, (y - y0) * T
                if (x, y) in lv.windows:
                    walls.append([f"win|{kind}|{m}|{int(bool(m & (TL.E | TL.W)))}", px, py])
                else:
                    walls.append([f"wall|{kind}|{m}", px, py])
        for pr in sorted(props.values(), key=lambda q: (q.y + q.defn.h, q.x)):
            key = self._prop_key(pr, season, snow)
            w, h = self._prop_size(key)
            dx, dy = TL.prop_offset(pr.id, w, h)
            walls.append([key, (pr.x - x0) * T + dx, (pr.y - y0) * T + dy])
        return {"level": lvk, "cx": cx, "cy": cy, "size": CH * T, "ops": ops, "shade": shade, "over": walls,
                "look": "|".join(look)}

    def _chunk_level(self, level: str, cx: int, cy: int) -> str:
        a = self.ex.area
        lv = a.levels.get(level) or a.base
        if not lv.overlay or lv.underground:
            return lv.key
        x0, y0 = cx * CH, cy * CH
        if x0 < lv.ox + lv.w and lv.ox < x0 + CH and y0 < lv.oy + lv.h and lv.oy < y0 + CH:
            return lv.key
        return a.base_key

    def tile(self, key: str) -> str:
        return png64(tile_canvas(key))

    # ---- roofs
    def roof(self, bid: str) -> dict | None:
        from game import destruction
        if destruction.is_ruin(bid, self.ex.state):
            return None
        r = self.ex.area.roofs.get(bid)
        if not r or not r["cells"]:
            return None
        cells = r["cells"]
        xs = [c[0] for c in cells]
        ys = [c[1] for c in cells]
        x0, y0, x1, y1 = min(xs), min(ys), max(xs) + 1, max(ys) + 1
        w, h = x1 - x0, y1 - y0
        out = Canvas(w * T, h * T)
        style = r["style"]
        horizontal = w >= h
        snow = self.look[1] == "snow"
        for (x, y) in cells:
            m = _mask(lambda xx, yy: (xx, yy) in cells, x, y)
            t = TL.roof_tile_in(style, m, (x * 3 + y) % 3, snow)
            far = (horizontal and y >= y0 + h / 2) or (not horizontal and x >= x0 + w / 2)
            if far:                                          # a gable: the far slope in shade
                t = t.copy()
                for i, px in enumerate(t.px):
                    if px is not None:
                        t.px[i] = (int(px[0] * 0.78), int(px[1] * 0.78), int(px[2] * 0.78), px[3])
            out.blit(t, (x - x0) * T, (y - y0) * T)
        return {"bid": bid, "x": x0, "y": y0, "w": w, "h": h, "ridge": "h" if horizontal else "v",
                "png": png64(out)}

    # ---- figures
    def sprite(self, key: str, turn: int = 0, step: int = 0) -> str | None:
        src = self._source(key)
        if src is None:
            return None
        if getattr(src, "views", None):
            from game.art.folk import facing
            c = facing(src, turn % 4, step)
        else:
            c = src.rotated(turn) if turn else src
        return png64(c)

    def _source(self, key: str):
        got = self.sources.get(key)
        if got is not None or key in self.sources:
            return got
        c = None
        try:
            if key.startswith("vessel:"):
                from game.art import vehicles as VH
                c = VH.draw(key.split(":", 1)[1])
            elif key.startswith("crowd:") or key in self.ex.crowd_info:
                from game import crowds
                d = self.ex.crowd_info.get(key.split(":", 1)[-1]) or self.ex.crowd_info.get(key) or \
                    next((v for v in self.ex.crowd_info.values() if crowds.sprite_key(v) == key), None)
                c = crowds.sprite(d) if d is not None else None
            else:
                e = self.world.entities.get(key)
                if e is not None:
                    c = self.world.sprites.render_entity(e, self.world.entities)
        except Exception:  # noqa: BLE001 - a missing sprite shows as a plain token
            c = None
        self.sources[key] = c
        return c

    def set_source(self, key: str, canvas) -> None:
        self.sources[key] = canvas

    def set_party(self, canvas) -> None:
        """The party's figure, under a new key each time it changes (new gear), so the page asks again."""
        self.sources.pop(self.party_key, None)
        self.party_key = f"party#{self._party_n}"
        self._party_n += 1
        self.sources[self.party_key] = canvas

    # ---- what changes as the party walks
    def frame(self, x_lo: int, y_lo: int, x_hi: int, y_hi: int) -> dict:
        ex = self.ex
        a = ex.area
        x_lo, y_lo = max(0, x_lo), max(0, y_lo)
        x_hi, y_hi = min(a.w, x_hi), min(a.h, y_hi)
        level = ex.level
        inside = ex.inside_building()
        lv_here = ex.lv()

        def in_building(x, y) -> bool:
            if lv_here.overlay:
                return lv_here.inside(x, y) and lv_here.floor_at(x, y) != A.PASS
            return bool(inside) and a.cell_building.get((x, y)) == inside

        from game import destruction, fire
        ruins = set((getattr(ex.state, "destruction", None) or {}).get("ruins") or {})

        def under_roof(x, y) -> bool:
            if lv_here.overlay:
                return lv_here.inside(x, y) and lv_here.floor_at(x, y) != A.PASS
            b = a.cell_building.get((x, y))
            return bool(b) and b not in ruins

        vis = ex.visible
        runs = []
        for y in range(y_lo, y_hi):
            run = None
            for x in range(x_lo, x_hi + 1):
                lit = x < x_hi and (x, y) in vis and (not inside or in_building(x, y))
                if lit and run is None:
                    run = x
                elif not lit and run is not None:
                    runs.append([run, y, x - run])
                    run = None
        doors = []
        for y in range(y_lo, y_hi):
            for x in range(x_lo, x_hi):
                lv = a.layer(level, x, y)
                d = lv.doors.get((x, y))
                if d is None or ex.secret_hidden(lv, (x, y)) or not ex.seen(lv, x, y):
                    continue
                st = ex.door_state(lv.key, (x, y))
                lit = (x, y) in vis and (not inside or in_building(x, y))
                doors.append({"x": x, "y": y, "key": f"door|{d.get('wall', 'wood_wall')}|"
                                                      f"{int(st in ('open', 'broken'))}|{int(bool(d.get('horizontal')))}",
                              "lit": lit, "locked": st == "locked"})
        traps = []                                     # the traps the party knows of (game/traps.py)
        if a.kind == "dungeon":
            from game import traps as TR
            for x, y, k, st in TR.shown(ex, a.levels.get(level) or a.base):
                if x_lo <= x < x_hi and y_lo <= y < y_hi:
                    traps.append({"x": x, "y": y, "key": f"trap|{k}|{st}", "lit": (x, y) in vis})
        fires = [[x, y, f"flame|{(x + y + ex.state.minutes) % 2}|{n}", (x, y) in vis]       # (game/fire.py)
                 for x, y, n in fire.burning(ex) if x_lo <= x < x_hi and y_lo <= y < y_hi]
        cracks = [[x, y, f"crack|{st}", (x, y) in vis]                                       # (destruction.py)
                  for x, y, st in destruction.damaged(ex, ex.layer(ex.x, ex.y) if not lv_here.overlay else lv_here,
                                                      x_lo, y_lo, x_hi, y_hi)]
        people = []
        for t in sorted((t for t in ex.tokens if ex.shown(t) and x_lo <= t.x < x_hi and y_lo <= t.y < y_hi
                         and (not inside or in_building(t.x, t.y))), key=lambda t: (t.y, t.x)):
            work = ex.work_bar(t) if t.at_work else None
            people.append({"key": t.entity, "x": t.x, "y": t.y, "turn": X.turns(t.facing),
                           "enemy": t.kind == "enemy", "indoors": bool(under_roof(t.x, t.y)), "work": work})
        roofs = []
        for bid, r in a.roofs.items():
            if (lv_here.overlay and bid == lv_here.bid) or bid in ruins:
                continue
            cells = r["cells"]
            if not cells:
                continue
            seen = any(ex.seen(a.layer(level, x, y), x, y) for (x, y) in list(cells)[:40])
            if not seen:
                continue
            xs = [c[0] for c in cells]
            ys = [c[1] for c in cells]
            if min(xs) > x_hi or min(ys) > y_hi or max(xs) < x_lo or max(ys) < y_lo:
                continue
            lit = (not inside) and any((x, y) in vis for (x, y) in cells)
            roofs.append({"bid": bid, "lit": lit, "here": bid == inside})
        followers = [{"key": eid, "x": fx, "y": fy, "turn": X.turns(ff)}
                     for eid, fx, fy, ff in (ex.followers() if hasattr(ex, "followers") else []) if (fx, fy) in vis]
        vessel = ex.vessel
        ride = "" if vessel else (ex.ride() if hasattr(ex, "ride") else "")
        crowns = []
        if not inside:                                     # tree crowns over anyone standing behind them
            under = [(ex.x, ex.y)] + [(q["x"], q["y"]) for q in people if not q["indoors"]]
            crowns = self._crowns(under, level, vis)
        fog = self._fog(x_lo, y_lo, x_hi, y_hi, level, inside)
        dark = None if inside else self._dark(x_lo, y_lo, x_hi, y_hi, level)
        return {"area": id(a), "w": a.w, "h": a.h, "level": level, "inside": inside or "",
                "box": [x_lo, y_lo, x_hi, y_hi], "runs": runs, "doors": doors, "traps": traps, "people": people,
                "fires": fires, "cracks": cracks,
                "roofs": roofs,
                "followers": followers, "party": {"x": ex.x, "y": ex.y, "turn": X.turns(ex.facing),
                                                  "vessel": vessel or ride or "", "key": self.party_key},
                "fog": fog, "dark": dark, "look": "|".join(self.look), "crowns": crowns,
                "sight": ex.sight_radius()}

    def _crowns(self, squares, level: str, vis) -> list:
        """The crowns of tall trees (and the like) in front of these squares, to be laid half seen-through over
        whoever stands behind them, as ExploreView._canopies does: [tile key, left, top, width, rise] in art
        pixels (T to a square); the page draws the top `rise` rows of that tile."""
        a = self.ex.area
        season, ground = self.look
        snow = ground == "snow"
        out, done = [], set()
        for (tx, ty) in squares:
            for dy in range(1, PROP_RISE + 1):
                for dx in (-1, 0, 1):
                    x, y = tx + dx, ty + dy
                    if not (0 <= x < a.w and 0 <= y < a.h) or (x, y) not in vis:
                        continue
                    pr = a.layer(level, x, y).prop_cells.get((x, y))
                    if pr is None or id(pr) in done or not pr.defn.tall:
                        continue
                    key = self._prop_key(pr, season, snow)
                    w, h = self._prop_size(key)
                    ax, ay = TL.prop_offset(pr.id, w, h)
                    rise = -ay                                    # how far it stands above its squares
                    left, top = pr.x * T + ax, pr.y * T + ay
                    if rise <= 0 or not (left < (tx + 1) * T and tx * T < left + w and top < (ty + 1) * T):
                        continue
                    done.add(id(pr))
                    out.append([key, left, top, w, rise])
        return out

    def _fog(self, x_lo, y_lo, x_hi, y_hi, level, inside) -> dict:
        """The never-seen squares, as a small black-where-unseen picture (one pixel to a square)."""
        ex = self.ex
        a = ex.area
        w, h = max(1, x_hi - x_lo), max(1, y_hi - y_lo)
        buf = bytearray(w * h * 4)
        roofed = set()
        if not inside:
            for bid, r in a.roofs.items():
                if any(ex.seen(a.layer(level, x, y), x, y) for (x, y) in list(r["cells"])[:40]):
                    roofed |= r["cells"]
        for y in range(y_lo, y_hi):
            for x in range(x_lo, x_hi):
                if not ex.seen(a.layer(level, x, y), x, y) and (x, y) not in roofed:
                    buf[((y - y_lo) * w + (x - x_lo)) * 4 + 3] = 255
        return {"x": x_lo, "y": y_lo, "w": w, "h": h, "png": png_rgba(w, h, bytes(buf))}

    def _dark(self, x_lo, y_lo, x_hi, y_hi, level) -> dict | None:
        """The hour's darkness with holes where the lights are (game/maplight.py), and their glow."""
        ex = self.ex
        a = ex.area
        weather, _look = self.conditions()
        tint = ML.tint_for(ex.state.minutes, weather, a.kind)
        if tint[3] <= 0:
            return None
        b, d, col, _dv = ex.party_lights()
        lights = ML.lights_in(a, level, x_lo, y_lo, x_hi, y_hi, ex.state.minutes)
        if b + d:
            lights.append((ex.x + 0.5, ex.y + 0.5, b, d, col))
        dark, glow, w, h = ML.overlay(x_lo, y_lo, x_hi - x_lo, y_hi - y_lo, tint, lights)
        return {"x": x_lo, "y": y_lo, "w": x_hi - x_lo, "h": y_hi - y_lo, "png": png_rgba(w, h, dark),
                "glow": png_rgba(w, h, glow)}


__all__ = ["Scene", "CH", "T", "tile_canvas", "png64"]
