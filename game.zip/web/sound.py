"""Sound and music in the browser (stage 4): what the app's ui/audio.py plays, decided the same way.

The game decides (game/soundscape.py: the mood for where the party is, the hour, the weather and any fight, and
the ambience loops under it); the page plays it (web/site/sound.js: Web Audio, cross-fading as the app does).
So every answer the page gets can carry two things:

    "music"   {"mood": "town_day", "salt": "12", "loops": {"rain": 0.8}}   when what should be playing changed
    "sfx"     [["hit", 0.8], ["coins", 0.7]]                               effects since the last answer

The effects are the app's, from the same events (a blow landing or missing, a foe falling, a quest done, a
level, coins at a trade, doors, a spell, a shift's work, the time skip...). The volumes are Settings' (kept with
the browser version's other settings).

Working out the scene costs about a millisecond, so it's done only when something that changes it happened (the
party moved on, a fight began or ended, the hour turned) and at most once a second otherwise.
"""
from __future__ import annotations

import time

VOLUMES = (("sound_on", True), ("volume_master", 80), ("volume_music", 70), ("volume_effects", 70),
           ("volume_ambience", 70))
RECHECK_SECONDS = 1.0

# gathering (game/gathering.py), as the app's ui/main_window.py WORK_SOUND
WORK_SOUND = {"woodcutting": "chop", "mining": "pick", "foraging": "rustle", "harvesting": "rustle",
              "fishing": "splash", "skinning": "rustle"}


class Sounds:
    """Mixed into web/bridge.py's Session."""

    def _sound_init(self) -> None:
        self._sfx: list = []
        self._music_sent = None
        self._music_dirty = True
        self._music_checked = 0.0
        self._sound_quiet = False

    # ------------------------------------------------------------------ effects
    def _fx(self, name: str, volume: float = 1.0) -> None:
        """A one-off effect (game/sounds/effects/<name>), played by the page with its next answer."""
        if name and len(getattr(self, "_sfx", [])) < 12:
            self._sfx.append([name, round(float(volume), 2)])

    def _sound_wire(self) -> None:
        """The app's own sounds, from the same events (ui/main_window.py)."""
        bus = self.bus
        bus.on("combat.attack", lambda e: self._fx("hit" if e.get("hit") else "miss", 0.8))
        bus.on("combat.defeated", lambda e: self._fx("defeat", 0.7))
        bus.on("quest.completed", lambda e: self._fx("quest"))
        bus.on("party.levelled", lambda e: self._fx("levelup"))
        bus.on("trade.bought", lambda e: self._fx("coins", 0.7))
        bus.on("trade.sold", lambda e: self._fx("coins", 0.7))
        bus.on("door.opened", lambda e: self._fx("door_open", 0.6))
        bus.on("door.closed", lambda e: self._fx("door_close", 0.6))
        bus.on("spell.cast_outside", lambda e: self._fx("spell", 0.7))
        bus.on("tool.milestone", lambda e: self._fx("levelup", 0.7))
        bus.on("craft.ready", lambda e: self._fx("quest", 0.6))
        for name in ("location.entered", "raid.*", "festival.started", "time.changed"):
            bus.on(name, lambda e: self._music_changed())

    def _music_changed(self) -> None:
        self._music_dirty = True

    # ------------------------------------------------------------------ the music and the loops
    def _music_now(self) -> dict | None:
        from game import soundscape as SS
        if self.world is None or self.state is None or self._sound_quiet:
            return None
        try:
            scene = SS.scene_from_game(self.world, self.state, self.ex, combat=self.fight is not None)
        except Exception:  # noqa: BLE001 - never let the sound stop the game
            return None
        return {"mood": SS.mood_for(scene), "salt": str(self.state.day),
                "loops": {k: round(v, 2) for k, v in sorted(SS.ambience_for(scene).items())}}

    def _sound_out(self, out: dict) -> None:
        """Put what changed in the sound onto an answer (web/bridge.py call)."""
        if self._sfx:
            out["sfx"], self._sfx = self._sfx, []
        now = time.monotonic()
        fighting = self.fight is not None
        if fighting != getattr(self, "_music_fighting", False):
            self._music_fighting = fighting
            self._music_dirty = True
        if not self._music_dirty and now - self._music_checked < RECHECK_SECONDS:
            return
        self._music_dirty = False
        self._music_checked = now
        music = self._music_now()
        if music is None:
            music = {"mood": "", "salt": "", "loops": {}}
        if music != self._music_sent:
            self._music_sent = music
            out["music"] = music

    def _sound_reset(self) -> None:
        """A new game or another save: the page hears what fits all over again."""
        self._sound_quiet = False
        self._music_sent = None
        self._music_dirty = True

    def api_sound(self) -> dict:
        """The volumes (Settings); what should be playing comes with the answer."""
        self._music_sent = None
        self._music_dirty = True
        return {"volumes": self._volumes()}

    def _volumes(self) -> dict:
        s = self._settings()
        return {k: s.get(k, d) for k, d in VOLUMES}


__all__ = ["Sounds", "VOLUMES", "WORK_SOUND"]
