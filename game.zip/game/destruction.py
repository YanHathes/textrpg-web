"""Destruction (Hotfix 23): trees, rocks, furniture and the walls of buildings can be smashed, felled, burned
(game/fire.py) and brought down, on the walking map and in fights.

Toughness, from the 5e rules for objects
    Each thing is of a material (MATERIAL: its Armour Class) and has hit points and a damage threshold (a hit
    that does less does nothing: a dagger won't chip a stone wall). Stone shrugs off half of piercing and
    slashing; poison and psychic do nothing to anything. TOUGH (props) and WALLS (wall kinds) list them.
What can be broken
    Trees, bushes, rocks and boulders, stumps and logs, furniture and street things (barrels, crates, tables,
    carts, fences, lamps, signposts, statues...), and wall squares that stand between two open places: a
    building's walls, the walls between a dungeon's rooms. Not the ground, water, stairs, a map's edge, nor
    the solid rock round a dungeon (a wall with earth behind it): nobody tunnels out of a dungeon.
How
    Face it and choose Smash it: the party lays into it, round after round, each with their best blow at it
    (smash). It takes game time, it's loud (in the wilds it draws monsters; in town, the watch), and the
    damage stays (state.destruction["dmg"]) until it breaks or is mended.
What's left
    A tree falls away from whoever brought it down (fall): three squares of trunk and its crown (four for a
    big one), crushing what's in the way (a Dexterity save against 4d6 bludgeoning, half on a save; things
    in the way are smashed, a wall in the way is hit). A stump stays and grows back, like a cut tree; the
    trunk can be cut for wood. A rock goes to rubble. Furniture goes to debris (a broken chest spills
    nothing: chests aren't breakable). A wall square becomes a hole with rubble in it.
Crime
    Breaking what isn't yours in a town (its buildings, its trees and lamps) is vandalism, if seen (law.py).
Buildings coming down
    A building that has lost a third of its walls collapses (collapse): its walls fall in, its roof comes
    down, everyone inside makes a Dexterity save against 6d6 bludgeoning (half on a save) and may be pinned
    (a Strength (Athletics) check to get free, or half an hour digging out). It's a ruin: its shop is shut,
    its stairs lead nowhere, and those who lived or worked there sleep rough (game/schedules.py) and rebuild
    it by day, as fast as the party's own hands would build the nearest blueprint of its kind
    (game/estate.py: its labour, the world's craft pace, a hand for each of them). A wall square knocked
    through, short of a collapse, is mended by them in a day or two.

Kept in the save, state.destruction:
    "dmg":    {"<level key>|x,y": damage taken}
    "broken": {building id: ["<level key>|x,y", ...]}   wall squares knocked through
    "ruins":  {building id: {"town", "name", "since", "work", "done", "cells": [[level key, x, y], ...],
               "doors": [[level key, x, y], ...], "people": [npc ids]}}
    "fires":  (game/fire.py)
"""
from __future__ import annotations

import math
import random
import weakref

from game import landchanges

MATERIAL = {"wood": 15, "stone": 17, "iron": 19, "plant": 10, "cloth": 11, "glass": 13}
# prop id -> (material, hp, threshold, flammable, what it leaves, value in gp)
TOUGH = {
    "tree": ("wood", 30, 0, True, "fall", 5), "big_tree": ("wood", 60, 3, True, "fall", 10),
    "pine": ("wood", 30, 0, True, "fall", 5), "bush": ("plant", 6, 0, True, "", 0),
    "berry_bush": ("plant", 6, 0, True, "", 0), "haybale": ("plant", 6, 0, True, "", 1),
    "crops": ("plant", 3, 0, True, "", 1), "rug": ("cloth", 4, 0, True, "", 2),
    "rock": ("stone", 30, 5, False, "rubble", 0), "boulder": ("stone", 60, 8, False, "rubble", 0),
    "stump": ("wood", 15, 0, True, "", 0), "log": ("wood", 20, 0, True, "", 0),
    "fallen_trunk": ("wood", 12, 0, True, "", 0), "branches": ("plant", 4, 0, True, "", 0),
    "burnt_tree": ("wood", 12, 0, False, "", 0), "sapling": ("plant", 5, 0, True, "", 0),
    "barrel": ("wood", 10, 0, True, "debris", 2), "crate": ("wood", 10, 0, True, "debris", 1),
    "table": ("wood", 12, 0, True, "debris", 5), "chair": ("wood", 5, 0, True, "debris", 1),
    "bed": ("wood", 12, 0, True, "debris", 10), "bookshelf": ("wood", 15, 0, True, "debris", 10),
    "counter": ("wood", 15, 0, True, "debris", 8), "workbench": ("wood", 15, 0, True, "debris", 15),
    "loom": ("wood", 12, 0, True, "debris", 15), "tanning_rack": ("wood", 10, 0, True, "debris", 8),
    "alchemy_table": ("wood", 12, 0, True, "debris", 25), "jeweler_bench": ("wood", 12, 0, True, "debris", 20),
    "writing_desk": ("wood", 12, 0, True, "debris", 10), "pew": ("wood", 12, 0, True, "debris", 5),
    "rack": ("wood", 10, 0, True, "debris", 5), "tub": ("wood", 12, 0, True, "debris", 5),
    "throne": ("wood", 20, 0, True, "debris", 50), "cart": ("wood", 20, 0, True, "debris", 15),
    "fence": ("wood", 8, 0, True, "", 1), "signpost": ("wood", 5, 0, True, "", 1),
    "sale_sign": ("wood", 5, 0, True, "", 1), "lamp": ("iron", 10, 0, False, "", 5),
    "brazier": ("iron", 10, 0, False, "", 5), "stove": ("iron", 25, 3, False, "rubble", 15),
    "anvil": ("iron", 40, 10, False, "", 20), "statue": ("stone", 40, 5, False, "rubble", 50),
    "pillar": ("stone", 50, 8, False, "rubble", 20), "altar": ("stone", 40, 5, False, "rubble", 50),
    "grave": ("stone", 20, 3, False, "rubble", 2), "well": ("stone", 40, 5, False, "rubble", 30),
    "fountain": ("stone", 50, 5, False, "rubble", 50), "forge": ("stone", 40, 5, False, "rubble", 30),
}
# wall kind -> (material, hp, threshold, flammable)
WALLS = {"wood_wall": ("wood", 25, 3, True), "stone_wall": ("stone", 45, 10, False),
         "brick_wall": ("stone", 40, 8, False), "rock_wall": ("stone", 60, 12, False)}
WALL_DEFAULT = ("stone", 45, 10, False)
WALL_GP = 25
STONE_RESISTS = ("piercing", "slashing")
NOTHING = ("poison", "psychic")
ROUNDS_A_MINUTE = 10
KEEP_AT_IT = 10                   # minutes, "keep at it"
TRUNK = {"tree": 3, "pine": 3, "big_tree": 4}
FALL_DICE, FALL_DC = "4d6", 13
COLLAPSE_SHARE = 1 / 3
COLLAPSE_DICE, COLLAPSE_DC, PINNED_DC = "6d6", 13, 12
TRUNK_DAYS = 30                   # a felled trunk lies this long (rotting, carted off) unless cut up
MEND_DAYS = 1.5                   # a hole in a wall: a hand's days to mend it
NOISE = 120                       # squares on the walking-encounter meter a minute of smashing is worth
COMMONER_HP = 4

_bound = None                     # the game state ruins are read from (places.is_open has no world to hand)


def bind(state) -> None:
    global _bound
    _bound = weakref.ref(state) if state is not None else None


def _state():
    return _bound() if _bound is not None else None


def data(state) -> dict:
    d = state.destruction
    for k in ("dmg", "broken", "ruins"):
        d.setdefault(k, {})
    return d


def is_ruin(bid: str, state=None) -> bool:
    st = state if state is not None else _state()
    return bool(st is not None and bid and bid in (getattr(st, "destruction", None) or {}).get("ruins", {}))


# ----------------------------------------------------------------------------------------------------
# What's there
# ----------------------------------------------------------------------------------------------------
def lv_key(lv) -> str:
    if getattr(lv, "chunked", False):
        return "land"
    return getattr(lv, "change_key", "") or f"lv:{lv.key}"


def sq_key(lv, x: int, y: int) -> str:
    return f"{lv_key(lv)}|{int(x)},{int(y)}"


def wall_breakable(lv, x: int, y: int) -> bool:
    """A wall square with open floor on two opposite sides: between two rooms, or a building and the street.
    Not one with earth (or the edge of the map) behind it."""
    from game import area as A

    def open_(xx, yy):
        return lv.inside(xx, yy) and lv.floor_at(xx, yy) not in A.SOLID and (xx, yy) not in lv.walls
    return (open_(x - 1, y) and open_(x + 1, y)) or (open_(x, y - 1) and open_(x, y + 1))


def thing_at(ex, x: int, y: int) -> dict | None:
    """What could be broken on this square: {"kind" ("prop" or "wall"), "lv", "x", "y" (its corner),
    "id", "label", "material", "ac", "hp", "threshold", "flammable", "leaves", "value"}."""
    if ex.area is None:
        return None
    lv = ex.layer(x, y)
    c = (x, y)
    if c in lv.walls:
        if c in lv.doors or not wall_breakable(lv, x, y):
            return None
        kind = lv.walls[c]
        mat, hp, thr, fl = WALLS.get(kind, WALL_DEFAULT)
        label = {"wood_wall": "Timber wall", "stone_wall": "Stone wall", "brick_wall": "Brick wall",
                 "rock_wall": "Rock wall"}.get(kind, "Wall")
        return {"kind": "wall", "lv": lv, "x": x, "y": y, "id": kind, "label": label, "material": mat,
                "ac": MATERIAL[mat], "hp": hp, "threshold": thr, "flammable": fl, "leaves": "rubble",
                "value": WALL_GP}
    p = lv.prop_cells.get(c)
    if p is None or p.id not in TOUGH:
        return None
    mat, hp, thr, fl, leaves, gp = TOUGH[p.id]
    return {"kind": "prop", "lv": lv, "x": p.x, "y": p.y, "id": p.id, "label": p.defn.label, "material": mat,
            "ac": MATERIAL[mat], "hp": hp, "threshold": thr, "flammable": fl, "leaves": leaves, "value": gp,
            "prop": p}


def hp_left(state, t: dict) -> int:
    return max(0, int(t["hp"]) - int(data(state)["dmg"].get(sq_key(t["lv"], t["x"], t["y"]), 0)))


def stage(state, t: dict) -> int:
    """How battered it looks: 0 whole, 1 knocked about, 2 nearly through."""
    left = hp_left(state, t)
    return 0 if left >= t["hp"] else 1 if left > t["hp"] / 3 else 2


def damaged(ex, lv, x0, y0, x1, y1) -> list[tuple[int, int, int]]:
    """[(x, y, stage)] of the battered things in a box (for the map's cracks)."""
    d = (getattr(ex.state, "destruction", None) or {}).get("dmg") or {}
    if not d:
        return []
    out = []
    pre = lv_key(lv) + "|"
    for k, n in d.items():
        if not k.startswith(pre) or not n:
            continue
        x, y = (int(v) for v in k[len(pre):].split(","))
        if x0 <= x < x1 and y0 <= y < y1:
            t = thing_at(ex, x, y)
            if t is not None:
                out.append((x, y, stage(ex.state, t) or 1))
    return out


def _value(t: dict) -> float:
    return float(t.get("value") or 0)


# ----------------------------------------------------------------------------------------------------
# Blows
# ----------------------------------------------------------------------------------------------------
def _multiplier(t: dict, dtype: str) -> float:
    dtype = (dtype or "").lower()
    if dtype in NOTHING:
        return 0.0
    if t["material"] == "stone" and dtype in STONE_RESISTS:
        return 0.5
    if t["material"] == "iron" and dtype == "piercing":
        return 0.5
    return 1.0


def _avg(expr: str) -> float:
    from game import dice
    try:
        e = dice.parse(str(expr or "1"))
    except Exception:  # noqa: BLE001 - a plain number
        try:
            return float(expr)
        except Exception:  # noqa: BLE001
            return 1.0
    tot = 0.0
    for term in getattr(e, "terms", []) or []:
        n, sides = getattr(term, "count", 0), getattr(term, "sides", 0)
        if sides:
            tot += getattr(term, "sign", 1) * n * (sides + 1) / 2
        else:
            tot += getattr(term, "sign", 1) * float(getattr(term, "value", 0) or getattr(term, "count", 0) or 0)
    return tot or 1.0


def best_blow(world, state, m: dict, t: dict):
    """The member's best way of hurting this thing: (Attack, expected damage a swing), or None. Weapons and
    fists only (fire is for burning: game/fire.py)."""
    from game import condition
    c = condition.combatant(world, m)
    condition.apply(state, m, c)
    best = None
    for a in c.attacks:
        if a.ranged and a.damage_type == "piercing" and t["material"] in ("stone", "iron"):
            continue                                     # arrows at a wall: no
        mult = _multiplier(t, a.damage_type)
        dmg = max(0.0, _avg(a.damage) * mult - t["threshold"])
        hit = min(0.95, max(0.05, (21 - (t["ac"] - a.to_hit)) / 20))
        val = hit * dmg
        if best is None or val > best[1]:
            best = (a, val)
    return best


def _swing(t: dict, a, rng) -> tuple[bool, int, int]:
    """One blow: (hit, damage done, the d20)."""
    from game import dice
    d20 = rng.randint(1, 20)
    if d20 != 20 and (d20 == 1 or d20 + a.to_hit < t["ac"]):
        return False, 0, d20
    dmg = dice.roll(a.damage, rng).total
    if d20 == 20:
        dmg += dice.roll(a.damage, rng).total - _flat(a.damage)
    dmg = int(dmg * _multiplier(t, a.damage_type))
    return True, (dmg if dmg >= t["threshold"] else 0), d20


def _flat(expr: str) -> int:
    try:
        return int(str(expr).split("+")[-1]) if "+" in str(expr) and "d" not in str(expr).split("+")[-1] else 0
    except ValueError:
        return 0


def prompt(ex, x: int, y: int):
    """Facing something that can be broken: how much is left of it, smash it, set it alight, leave it."""
    from game import fire
    from game.explore import Prompt
    t = thing_at(ex, x, y)
    if t is None:
        return None
    left = hp_left(ex.state, t)
    how = {0: "It's whole.", 1: "It's been knocked about.", 2: "It's nearly through."}[stage(ex.state, t)]
    ms = [m for m in ex.members() if not m.get("dead")]
    blows = [(m, best_blow(ex.world, ex.state, m, t)) for m in ms]
    blows = [(m, b) for m, b in blows if b is not None and b[1] > 0]
    tough = f"{t['material'].title()}, AC {t['ac']}, {left}/{t['hp']} hit points" + \
        (f", ignores any blow under {t['threshold']}" if t["threshold"] else "")
    text = f"{how} ({tough}.)"
    if blows:
        best = max(blows, key=lambda mb: mb[1][1])
        text += f" Best at it: {best[0].get('name')} with {best[1][0].name.lower()}."
    else:
        text += " Nothing you have will make a mark on it."
    if t["id"] in TRUNK:
        text += " Brought down, it will fall away from you."
    if _crime_here(ex, t):
        text += " It isn't yours: breaking it is a crime, if you're seen."
    opts = [("Smash it (a minute)", ("smash", x, y, 1), bool(blows)),
            (f"Keep at it (up to {KEEP_AT_IT} minutes)", ("smash", x, y, KEEP_AT_IT), bool(blows))]
    src = fire.source(ex.world, ex.state, ex.members())
    if t["flammable"]:
        opts.append((f"Set it alight ({src[1]})" if src else "Set it alight (nothing to light it with)",
                     ("burn", x, y), src is not None))
    opts.append(("Leave it", ("none",), True))
    return Prompt(t["label"], text, opts)


def smash(ex, x: int, y: int, minutes: int = 1, rng=None) -> dict:
    """The party lays into the thing at (x, y) for up to `minutes` (or until it breaks). Returns {"lines",
    "broke", "minutes", "prompt" (to carry on)}."""
    rng = rng or ex.rng
    st = ex.state
    t = thing_at(ex, x, y)
    if t is None:
        return {"lines": ["There's nothing there to break."], "broke": False, "minutes": 0}
    ms = [m for m in ex.members() if not m.get("dead")]
    blows = [(m, best_blow(ex.world, st, m, t)) for m in ms]
    blows = [(m, b[0]) for m, b in blows if b is not None and b[1] > 0]
    if not blows:
        return {"lines": [f"Nothing you have will make a mark on the {t['label'].lower()}."], "broke": False,
                "minutes": 0}
    from game import condition
    per = {m["id"]: max(1, int(getattr(condition.combatant(ex.world, m), "attacks_per_action", 1) or 1))
           for m, _a in blows}
    done = rounds = 0
    left = hp_left(st, t)
    for _r in range(max(1, int(minutes)) * ROUNDS_A_MINUTE):
        rounds += 1
        for m, a in blows:
            for _k in range(per[m["id"]]):
                hit, dmg, _d = _swing(t, a, rng)
                done += dmg
                if done >= left:
                    break
            if done >= left:
                break
        if done >= left:
            break
    spent = max(1, math.ceil(rounds / ROUNDS_A_MINUTE))
    st.advance(spent, "smashing")
    lines = []
    _noise(ex, t, spent)
    if done >= left:
        lines.append(f"{_who(blows)} {_verb(t)} the {t['label'].lower()} in {_time(rounds)}.")
        lines += destroy(ex, t, frm=(ex.x, ex.y), rng=rng)
        out = {"lines": lines, "broke": True, "minutes": spent}
    else:
        data(st)["dmg"][sq_key(t["lv"], t["x"], t["y"])] = int(data(st)["dmg"].get(
            sq_key(t["lv"], t["x"], t["y"]), 0)) + done
        left2 = left - done
        lines.append(f"{_who(blows)} lay{'s' if len(blows) == 1 else ''} into the {t['label'].lower()} for "
                     f"{_time(rounds)}: {done} damage ({left2}/{t['hp']} left)." if done else
                     f"{_who(blows)} can't make a mark on the {t['label'].lower()}.")
        out = {"lines": lines, "broke": False, "minutes": spent, "prompt": prompt(ex, x, y) if done else None}
    st.save()
    _redraw(ex)
    return out


def _who(blows) -> str:
    names = [m.get("name") or "?" for m, _a in blows]
    return names[0] if len(names) == 1 else "The party"


def _verb(t: dict) -> str:
    return {"wood": "brings down" if t["id"] in TRUNK else "smashes", "stone": "breaks", "iron": "batters apart",
            "plant": "flattens", "cloth": "tears up"}.get(t["material"], "breaks")


def _time(rounds: int) -> str:
    secs = rounds * 6
    return f"{secs} seconds" if secs < 60 else f"{math.ceil(secs / 60)} minute{'s' if secs > 60 else ''}"


def _crime_here(ex, t: dict) -> bool:
    from game import places
    spot = places.current(ex.world, ex.state)
    if spot.town is None or ex.area is None or ex.area.kind == "dungeon":
        return False
    bid = ex.area.cell_building.get((t["x"], t["y"])) if hasattr(ex.area, "cell_building") else ""
    if bid:
        b = ex.world.entities.get(bid)
        if b is not None and b.fields.get("owner"):
            return False
    return True


def _noise(ex, t: dict, minutes: int) -> None:
    """Loud: in the wilds it draws monsters; in town, it's vandalism if anyone sees."""
    if ex.area is not None and ex.area.kind == "world" and ex.zone_loc().startswith("hex|"):
        ex._enc_meter = getattr(ex, "_enc_meter", 0) + NOISE * minutes
    if _crime_here(ex, t):
        from game import law, places
        done = data(ex.state).setdefault("seen_for", {})
        k = sq_key(t["lv"], t["x"], t["y"])
        if done.get(k) == ex.state.day:
            return                                         # (once a day for the same thing)
        done[k] = ex.state.day
        seen = law.witnesses(ex.world, ex.state, ex.members(), ex, ex.rng, bus=ex.bus)
        law.commit(ex.world, ex.state, "vandalism", places.current(ex.world, ex.state).town, seen, _value(t), "",
                   ex.bus)


def _record(ex, lv, x: int, y: int, chg: dict, merge: bool = True, save: bool = True) -> None:
    st = ex.state
    if getattr(lv, "chunked", False):
        old = landchanges.change_at(st, x, y) if merge else None
        new = dict(old or {}, **chg)
        new.pop("then", None) if "then" not in chg else None
        if "until" not in chg:
            new.pop("until", None)
        landchanges.record(ex.world, st, x, y, new, ex.bus, save=save)
    else:
        old = landchanges.level_change_at(st, lv, x, y) if merge else None
        new = dict(old or {}, **chg)
        if "then" not in chg:
            new.pop("then", None)
        if "until" not in chg:
            new.pop("until", None)
        landchanges.record_level(ex.world, st, lv, x, y, new, ex.bus, save=save)


def _redraw(ex) -> None:
    ex.door_version = getattr(ex, "door_version", 0) + 1
    try:
        ex.look()
    except Exception:  # noqa: BLE001 - the map will catch up
        pass


# ----------------------------------------------------------------------------------------------------
# Broken
# ----------------------------------------------------------------------------------------------------
def destroy(ex, t: dict, frm=None, rng=None, quiet: bool = False) -> list[str]:
    """The thing breaks: what's left is laid down (a tree falls), and a wall's building may come down."""
    rng = rng or ex.rng
    st = ex.state
    lv, x, y = t["lv"], t["x"], t["y"]
    data(st)["dmg"].pop(sq_key(lv, x, y), None)
    lines = []
    if t["kind"] == "wall":
        _record(ex, lv, x, y, {"wall": "", "prop": "rubble", "variant": (x * 7 + y) % 3})
        lines += _wall_down(ex, lv, x, y, rng)
    elif t["leaves"] == "fall":
        lines += fall(ex, t, frm or (ex.x, ex.y), rng)
    else:
        leaves = t["leaves"]
        _record(ex, lv, x, y, {"prop": leaves, "variant": (x * 3 + y) % 3} if leaves else {"prop": ""})
    _redraw(ex)
    return lines


def _dir_from(frm, x: int, y: int) -> tuple[int, int]:
    dx, dy = x - frm[0], y - frm[1]
    if dx == 0 and dy == 0:
        return (0, 1)
    ang = math.atan2(dy, dx)
    k = int(round(ang / (math.pi / 4))) % 8
    return [(1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1), (0, -1), (1, -1)][k]


def fall(ex, t: dict, frm, rng=None, stump: bool = True) -> list[str]:
    """A tree comes down, away from `frm` (where it was cut from): a stump where it stood, its trunk and
    crown along the ground, and whatever was in the way crushed."""
    from game import gathering as GA
    rng = rng or ex.rng
    st = ex.state
    lv, x, y, pid = t["lv"], t["x"], t["y"], t["id"]
    dx, dy = _dir_from(frm, x, y)
    days = (GA.SOURCES.get(pid) or (0, 0, 0, 0, 12))[4]
    if stump:
        _record(ex, lv, x, y, {"prop": "stump", "variant": 0, "until": st.minutes + int(days * 1440),
                               "was": {"prop": pid, "variant": 0}})
    lines = [f"The {t['label'].lower()} creaks, leans, and comes down with a crash, falling "
             f"{_dir_word(dx, dy)}."]
    length = TRUNK.get(pid, 3)
    piece = 0 if dy == 0 else 1 if dx == 0 else 2 if dx == dy else 3
    for i in range(1, length + 1):
        cx, cy = x + dx * i, y + dy * i
        l2 = ex.layer(cx, cy)
        if not l2.inside(cx, cy) or (cx, cy) in l2.water:
            break
        if (cx, cy) in l2.walls:                          # into a wall: it takes the blow, the tree stops
            w = thing_at(ex, cx, cy)
            if w is not None:
                lines += hit(ex, w, _roll(FALL_DICE, rng), "bludgeoning", rng, frm=(x, y))
            break
        lines += _crush(ex, cx, cy, rng, "the falling tree")
        other = l2.prop_cells.get((cx, cy))
        if other is not None and other.id in ("rock", "boulder", "well", "fountain", "statue", "pillar"):
            break                                         # it comes to rest on the rock
        if other is not None:
            o = thing_at(ex, cx, cy)
            if o is not None:
                lines.append(f"It smashes the {o['label'].lower()}.")
                _record(ex, l2, o["x"], o["y"], {"prop": o["leaves"] if o["leaves"] not in ("fall",) else ""})
            elif other.defn.blocks:
                break
        crown = i == length
        _record(ex, l2, cx, cy, {"prop": "branches" if crown else "fallen_trunk",
                                 "variant": (rng.randrange(3) if crown else piece),
                                 "until": st.minutes + TRUNK_DAYS * 1440})
    return lines


def _dir_word(dx, dy) -> str:
    return {(0, -1): "north", (0, 1): "south", (1, 0): "east", (-1, 0): "west", (1, -1): "north-east",
            (-1, -1): "north-west", (1, 1): "south-east", (-1, 1): "south-west"}[(dx, dy)]


def _roll(expr: str, rng) -> int:
    from game import dice
    return dice.roll(expr, rng).total


def hit(ex, t: dict, amount: int, dtype: str, rng=None, frm=None) -> list[str]:
    """Damage done to a thing by something other than the party's blows (a falling tree, a fire, a spell).
    Breaks it if that's enough."""
    st = ex.state
    amount = int(amount * _multiplier(t, dtype))
    if amount < t["threshold"] or amount <= 0:
        return []
    left = hp_left(st, t)
    if amount >= left:
        return [f"The {t['label'].lower()} gives way."] + destroy(ex, t, frm=frm, rng=rng)
    data(st)["dmg"][sq_key(t["lv"], t["x"], t["y"])] = int(data(st)["dmg"].get(sq_key(t["lv"], t["x"], t["y"]), 0)) \
        + amount
    return []


def _crush(ex, x: int, y: int, rng, what: str, dice_: str = FALL_DICE, dc: int = FALL_DC) -> list[str]:
    """Whoever stands on (x, y) is caught by `what`: a Dexterity save against `dice_` bludgeoning, half on a
    save. Townsfolk can die of it (and that's on the party, if anyone saw); monsters too."""
    lines = []
    for tok in list(ex.tokens):
        if (tok.x, tok.y) != (x, y) or tok.level not in (ex.level, ex.layer(x, y).key):
            continue
        dmg = _roll(dice_, rng)
        hp, dex = _token_stats(ex, tok)
        saved = rng.randint(1, 20) + dex >= dc
        if saved:
            dmg //= 2
        name = tok.name if tok.kind == "npc" else f"a {tok.name.split(' ', 1)[-1]}" if tok.kind == "crowd" else \
            f"the {tok.name.lower()}"
        if dmg >= hp:
            lines.append(f"{name[:1].upper()}{name[1:]} is caught under {what} and doesn't get up.")
            _kill_token(ex, tok)
        else:
            lines.append(f"{name[:1].upper()}{name[1:]} is struck by {what} ({dmg} damage)"
                         + (", diving half clear." if saved else "."))
            _hurt_token(ex, tok, dmg)
    return lines


def _token_stats(ex, tok) -> tuple[int, int]:
    e = ex.world.entities.get(tok.entity) if tok.entity else None
    if tok.kind == "npc" and e is not None:
        try:
            from game.combat import builders as CB
            c = CB.from_npc(ex.world, e, random.Random(1))
            return max(1, int(c.hp)), c.mod("dex")
        except Exception:  # noqa: BLE001 - an ordinary body
            return COMMONER_HP, 0
    if tok.kind == "enemy" and e is not None:
        try:
            hp = int(e.fields.get("hp") or 0) or int(str(e.fields.get("hit_points") or "0").split()[0] or 0)
        except (TypeError, ValueError):
            hp = 0
        dex = (int((e.fields.get("stats") or {}).get("dex", 10)) - 10) // 2 if isinstance(e.fields.get("stats"),
                                                                                       dict) else 0
        return max(1, hp or 10), dex
    return COMMONER_HP, 0


def _hurt_token(ex, tok, dmg: int) -> None:
    if tok.kind == "npc":
        from game import law, schedules
        npc = ex.world.entities.get(tok.entity)
        if npc is not None:
            ex.state.npc(npc.id)["disposition"] = "Wary"
            seen = law.witnesses(ex.world, ex.state, ex.members(), ex, ex.rng)
            schedules.react_to_harm(ex.world, ex.state, npc, False, ex.bus)
            law.harmed(ex.world, ex.state, npc, False, seen + [npc.id], ex.bus)


def _kill_token(ex, tok) -> None:
    from game import law, schedules
    if tok in ex.tokens:
        ex.tokens.remove(tok)
    if tok.kind == "npc":
        npc = ex.world.entities.get(tok.entity)
        if npc is not None:
            ex.state.npc(npc.id)["dead"] = True
            if ex.bus is not None:
                ex.bus.emit("npc.died", npc=npc.id)
            seen = law.witnesses(ex.world, ex.state, ex.members(), ex, ex.rng)
            schedules.react_to_harm(ex.world, ex.state, npc, True, ex.bus)
            law.harmed(ex.world, ex.state, npc, True, seen, ex.bus)
    elif tok.kind == "crowd":
        from game import places
        town = places.current(ex.world, ex.state).town
        if town is not None:
            seen = law.witnesses(ex.world, ex.state, ex.members(), ex, ex.rng)
            law.commit(ex.world, ex.state, "murder", town, seen, 0, "", ex.bus)
    elif tok.kind == "enemy" and tok.group:
        if not any(t.group == tok.group for t in ex.tokens):
            ex.remove_group(tok.group)
        if tok.entity:
            ex.state.record_kill(tok.entity)


# ----------------------------------------------------------------------------------------------------
# Walls, and buildings coming down
# ----------------------------------------------------------------------------------------------------
def building_at(ex, x: int, y: int) -> str:
    a = ex.area
    bid = (getattr(a, "cell_building", None) or {}).get((x, y)) if a is not None else ""
    if bid:
        return bid
    for nx, ny in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
        bid = (getattr(a, "cell_building", None) or {}).get((nx, ny))
        if bid:
            return bid
    return ""


def wall_cells(ex, bid: str):
    """(level, [wall squares]) of a building's ground floor."""
    a = ex.area
    r = (a.roofs.get(bid) or {}) if a is not None else {}
    cells = list(r.get("cells") or [k for k, v in (a.cell_building or {}).items() if v == bid])
    if not cells:
        return None, []
    lv = _ground_level(ex, cells[0])
    walls = sorted({c for c in cells if c in lv.walls} | _orig_walls(lv, cells))
    return lv, walls


def _ground_level(ex, c):
    """The level a building's ground floor is on (the town's ground, not an upper floor laid over it)."""
    a = ex.area
    site = a.site_at(*c) if hasattr(a, "site_at") else None
    if site is not None:
        return site.base
    return a.levels.get(a.base_key) or a.base


def _orig_walls(lv, cells) -> set:
    under = lv.__dict__.get("_orig_ground") or {}
    return {c for c in cells if c in under and under[c][0]}


def _wall_down(ex, lv, x: int, y: int, rng) -> list[str]:
    """A wall square knocked through: its building's people will mend it, unless it was one too many."""
    bid = building_at(ex, x, y)
    if not bid or is_ruin(bid, ex.state):
        return []
    d = data(ex.state)
    b = ex.world.entities.get(bid)
    broken = d["broken"].setdefault(bid, [])
    k = sq_key(lv, x, y)
    if k not in broken:
        broken.append(k)
    _glv, walls = wall_cells(ex, bid)
    gone = len([k2 for k2 in broken if _still_broken(ex, k2)])
    if walls and gone >= max(2, math.ceil(len(walls) * COLLAPSE_SHARE)):
        return collapse(ex, bid, rng)
    people = residents(ex.world, ex.state, bid)
    days = MEND_DAYS / max(1, len(people))
    _record(ex, lv, x, y, {"wall": "", "prop": "rubble", "variant": (x * 7 + y) % 3,
                           "until": ex.state.minutes + int(days * 1440)})
    name = b.name if b is not None else "the building"
    return [f"There's a hole through the wall of {name}."]


def _still_broken(ex, k: str) -> bool:
    lvk, xy = k.rsplit("|", 1)
    x, y = (int(v) for v in xy.split(","))
    lv = ex.layer(x, y)
    if lv_key(lv) != lvk:
        lv = _ground_level(ex, (x, y))
    chg = landchanges.change_on(ex.state, lv, x, y)
    return chg is not None and chg.get("wall") == ""


def residents(world, state, bid: str) -> list:
    """Those who live or work in a building (and so rebuild it), alive."""
    from game import estate
    out = [n for n in world.entities.by_field("npc", "building", bid) if not state.npc_dead(n.id)]
    seen = {n.id for n in out}
    out += [n for n in world.entities.by_field("npc", "home", bid) if n.id not in seen and not state.npc_dead(n.id)]
    seen = {n.id for n in out}
    for w in estate.workers(state):
        if w.get("building") == bid and w.get("npc") not in seen:
            n = world.entities.get(w.get("npc") or "")
            if n is not None:
                out.append(n)
    return out


def labor(world, b) -> float:
    """Work (gp of a hand's days) to raise this building again: the nearest blueprint of its kind, scaled to
    its size (game/estate.py)."""
    from game import estate
    kind = (b.fields.get("kind") or "") if b is not None else ""
    bps = [bp["fields"] for bp in estate.BUILTIN if bp["fields"].get("style", "building") == "building"]
    same = [f for f in bps if f.get("kind") == kind] or bps
    w, h = _footprint(b)
    best = min(same, key=lambda f: abs(int(f["w"]) * int(f["h"]) - w * h))
    return float(best.get("labor") or 100) * max(0.5, (w * h) / max(1, int(best["w"]) * int(best["h"])))


def _footprint(b) -> tuple[int, int]:
    from game import rooms
    try:
        return rooms.footprint_for(b.fields.get("kind") or "House", "building")
    except Exception:  # noqa: BLE001 - a house-sized place
        return 8, 7


def collapse(ex, bid: str, rng=None, quiet: bool = False) -> list[str]:
    """The building comes down: walls in, roof down, everyone inside hurt, and it's a ruin until its people
    rebuild it."""
    from game import places
    rng = rng or ex.rng
    st = ex.state
    a = ex.area
    b = ex.world.entities.get(bid)
    name = b.name if b is not None else "the building"
    lv, walls = wall_cells(ex, bid)
    if lv is None:
        return []
    cells = list((a.roofs.get(bid) or {}).get("cells") or [k for k, v in a.cell_building.items() if v == bid])
    rec = {"town": (b.fields.get("town") if b is not None else "") or "", "name": name, "since": st.minutes,
           "work": round(labor(ex.world, b), 1), "done": 0.0, "cells": [], "doors": [],
           "people": [n.id for n in residents(ex.world, st, bid)]}
    data(st)["ruins"][bid] = rec
    lines = [f"With a long groan, {name} comes down: walls, roof and all."]
    inside = [c for c in cells]
    for c in walls:
        keep = rng.random() < 0.2                          # a stub of wall here and there
        if keep:
            continue
        _record(ex, lv, c[0], c[1], {"wall": "", "prop": "rubble", "variant": rng.randrange(3)}, merge=False)
        rec["cells"].append([lv_key(lv), c[0], c[1]])
    for c in inside:
        if c in walls:
            continue
        p = lv.prop_cells.get(c)
        if p is not None and (p.x, p.y) == c and p.id not in ("stairs_up", "stairs_down", "chest"):
            _record(ex, lv, c[0], c[1], {"prop": "debris" if TOUGH.get(p.id, ("",))[0] == "wood" else "rubble",
                                         "variant": rng.randrange(3)}, merge=False)
            rec["cells"].append([lv_key(lv), c[0], c[1]])
        elif p is None and rng.random() < 0.25:
            _record(ex, lv, c[0], c[1], {"prop": "rubble", "variant": rng.randrange(3)}, merge=False)
            rec["cells"].append([lv_key(lv), c[0], c[1]])
        if c in lv.doors:
            ex.set_door(lv.key, c, "broken")
            rec["doors"].append([lv.key, c[0], c[1]])
    for c in walls:
        if c in lv.doors:
            ex.set_door(lv.key, c, "broken")
            rec["doors"].append([lv.key, c[0], c[1]])
    data(st)["broken"].pop(bid, None)
    # the party, if it's in there (an upper floor comes down with it)
    here = ex.layer(ex.x, ex.y)
    if (ex.x, ex.y) in set(cells) and (here.bid == bid or here is lv):
        if here is not lv:
            ex.level = lv.key
            lines.append("The floor gives way under you and you come down with it.")
        lines += _party_crushed(ex, rng)
    for c in cells:
        if c != (ex.x, ex.y):
            lines += _crush(ex, c[0], c[1], rng, "falling stone and timber", COLLAPSE_DICE, COLLAPSE_DC)
    if rec["people"]:
        lines.append("Its people have nowhere to sleep now. They'll set about rebuilding it.")
    if b is not None and places.open_span(b) is not None:
        lines.append("Its doors won't open again until it's rebuilt.")
    _crime_building(ex, b)
    st.save()
    _redraw(ex)
    if ex.bus is not None:
        ex.bus.emit("building.ruined", building=bid)
    return lines


def _crime_building(ex, b) -> None:
    if b is None or b.fields.get("owner"):
        return
    from game import law, places
    town = places.current(ex.world, ex.state).town
    if town is None:
        return
    seen = law.witnesses(ex.world, ex.state, ex.members(), ex, ex.rng, bus=ex.bus)
    law.commit(ex.world, ex.state, "vandalism", town, seen, 300, b.id, ex.bus)


def _party_crushed(ex, rng) -> list[str]:
    from game import condition, checks
    lines = []
    for m in ex.members():
        if m.get("dead"):
            continue
        c = condition.combatant(ex.world, m)
        condition.apply(ex.state, m, c)
        dmg = _roll(COLLAPSE_DICE, rng)
        bonus = c.mod("dex") + (c.prof if "dex" in (c.saves or set()) else 0)
        saved = rng.randint(1, 20) + bonus >= COLLAPSE_DC
        if saved:
            dmg //= 2
        c.hp = max(1, c.hp - dmg)                          # (knocked senseless, not killed)
        condition.store(ex.state, m, c, save=False)
        lines.append(f"{c.name} takes {dmg} damage" + (" (diving half clear)." if saved else "."))
        if not saved:
            opt = next((o for o in checks.options(ex.world) if o["label"] == "Athletics"), None)
            got = checks.roll(ex.world, m, c, opt, PINNED_DC, rng=rng) if opt else {"success": rng.random() < .5}
            if not got.get("success"):
                ex.state.advance(30, "digging out")
                lines.append(f"{c.name} is pinned under the rubble and it takes half an hour to dig them out.")
    ex.state.save()
    return lines


def stairs_blocked(ex, lk: str) -> bool:
    """Stairs into a fallen building lead nowhere."""
    lv = ex.area.levels.get(lk) if ex.area is not None else None
    return bool(lv is not None and lv.bid and is_ruin(lv.bid, ex.state))


def roof_gone(state, bid: str) -> bool:
    return is_ruin(bid, state)


# ----------------------------------------------------------------------------------------------------
# Rebuilding
# ----------------------------------------------------------------------------------------------------
def rate(world, state, bid: str) -> float:
    """Work done on a ruin a day: a hand's day for each of its people (the world's craft pace)."""
    from game import estate
    rec = data(state)["ruins"].get(bid) or {}
    people = [p for p in rec.get("people") or [] if not state.npc_dead(p)]
    return estate.pace(world) * max(1, len(people))


def days_left(world, state, bid: str) -> float | None:
    rec = data(state)["ruins"].get(bid)
    if rec is None:
        return None
    return max(0.0, (float(rec["work"]) - float(rec["done"])) / max(0.01, rate(world, state, bid)))


def rebuilt(world, state, bid: str, bus=None) -> None:
    """The ruin's risen again: every square of it put back as it was."""
    rec = data(state)["ruins"].pop(bid, None)
    if rec is None:
        return
    for key, x, y in rec.get("cells") or []:
        if key == "land":
            landchanges.undo(world, state, x, y, bus)
        else:
            landchanges.undo_level(world, state, key, x, y, bus)
    doors = state.explore.get("doors") or {}
    for lk, x, y in rec.get("doors") or []:
        for _area, ds in doors.items():
            ds.pop(f"{lk}:{x},{y}", None)
    state.save()
    if bus is not None:
        bus.emit("log", kind="narration", text=f"{rec.get('name') or 'A building'} has been rebuilt.")
        bus.emit("building.rebuilt", building=bid)


def _tick(world, state, since: int, now: int) -> None:
    d = (getattr(state, "destruction", None) or {}).get("ruins") or {}
    if not d:
        return
    days = (now - since) / 1440
    if days <= 0:
        return
    for bid in list(d):
        rec = d[bid]
        rec["done"] = float(rec["done"]) + rate(world, state, bid) * days
        if rec["done"] >= float(rec["work"]):
            rebuilt(world, state, bid, getattr(state, "bus", None))


def displaced(world, npc, minute: int) -> str:
    """Where one of a ruin's people is (game/schedules.py): at the ruin by day, rebuilding; sleeping rough
    in its street by night. "" if their place is standing."""
    st = _state()
    ruins = ((getattr(st, "destruction", None) or {}).get("ruins") or {}) if st is not None else {}
    if not ruins:
        return ""
    bid = next((b for b in (npc.fields.get("building"), npc.fields.get("home")) if b and b in ruins), "")
    if not bid:
        return ""
    from game import places
    b = world.entities.get(bid)
    if b is None:
        return ""
    if 8 * 60 <= minute < 19 * 60:
        return bid
    town = world.entities.get(b.fields.get("town") or "")
    if town is None:
        return bid
    names = [s["name"] for s in places.streets_of(town)]
    street = b.fields.get("street") if b.fields.get("street") in names else (names[0] if names else "")
    return places.street_id(town.id, street) if street else bid


def sleeping_rough(world, npc, minute: int) -> bool:
    return bool(displaced(world, npc, minute)) and not (8 * 60 <= minute < 19 * 60)


from game import ticker  # noqa: E402

ticker.register("ruins", _tick)

__all__ = ["thing_at", "prompt", "smash", "destroy", "fall", "hit", "collapse", "is_ruin", "rebuilt", "bind",
           "displaced", "residents", "labor", "days_left", "damaged", "stage", "TOUGH", "WALLS"]
