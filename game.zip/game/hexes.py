"""Hexes: the overland map is a grid of hexes, and crossing open country goes hex by hex.

Hexes are pointy-topped, in axial coordinates (q, r). A hex is `hex_miles` across (world rule,
6 by default), so the centers of two neighbouring hexes are that many miles apart. A location
"hex|<q>|<r>" is the party out in the open in that hex (see game/places.py).

What a hex is like comes from the map (game/geography.py): its biome, region and continent are
read at its center. Water (ocean, lakes) can't be crossed on foot, and neither can the sea between
continents: crossing to another continent takes a passage (game/passage.py).

Time to enter a hex = hex_miles / travel_mph x the biome's difficulty. Each hex entered has a
chance of trouble (world rule hex_encounter_chance, plus the region's danger).

Roads between towns are still the quick, safer way (game/travel.py journeys); hexes are for going
where roads don't.
"""
from __future__ import annotations

import heapq
import math
import random

SQ3 = math.sqrt(3.0)
# neighbour offsets, and which way each one lies
STEPS = [((1, 0), "East"), ((1, -1), "North-east"), ((0, -1), "North-west"),
         ((-1, 0), "West"), ((-1, 1), "South-west"), ((0, 1), "South-east")]
WATER = {"Ocean", "Lake"}
DIFFICULTY = {"Plains": 1.0, "Coast": 1.0, "Forest": 1.5, "Hills": 1.5, "Desert": 1.5, "Badlands": 1.5,
              "Swamp": 2.0, "Jungle": 2.0, "Arctic": 2.0, "Mountains": 2.5, "Taiga": 1.5, "Tundra": 1.5,
              "Savanna": 1.0}
NOUN = {"Plains": "plains", "Coast": "coast", "Forest": "forest", "Hills": "hills", "Desert": "desert",
        "Badlands": "badlands", "Swamp": "marsh", "Jungle": "jungle", "Arctic": "snowfields",
        "Mountains": "mountains", "Lake": "lakeshore", "Ocean": "sea", "Taiga": "pine forest", "Tundra": "tundra",
        "Savanna": "grasslands"}
MAX_SEARCH = 60000          # hexes looked at when finding a way (a very long trek just fails)


# ======================================================================
# Geometry
# ======================================================================
def hex_miles(world) -> float:
    return max(1.0, float(world.rules.get("hex_miles", 6) or 6))


def _size(world) -> float:
    return hex_miles(world) / SQ3            # center to corner


def center(world, q: int, r: int) -> tuple[float, float]:
    s = _size(world)
    return s * SQ3 * (q + r / 2.0), s * 1.5 * r


def corners(world, q: int, r: int) -> list[tuple[float, float]]:
    cx, cy = center(world, q, r)
    s = _size(world)
    return [(cx + s * math.cos(math.radians(60 * i - 30)), cy + s * math.sin(math.radians(60 * i - 30)))
            for i in range(6)]


def at(world, x: float, y: float) -> tuple[int, int]:
    """The hex a point (in miles) is in."""
    s = _size(world)
    fq = (SQ3 / 3 * x - y / 3) / s
    fr = (2.0 / 3 * y) / s
    return _round(fq, fr)


def _round(fq: float, fr: float) -> tuple[int, int]:
    fs = -fq - fr
    q, r, s = round(fq), round(fr), round(fs)
    dq, dr, ds = abs(q - fq), abs(r - fr), abs(s - fs)
    if dq > dr and dq > ds:
        q = -r - s
    elif dr > ds:
        r = -q - s
    return int(q), int(r)


def distance(a: tuple[int, int], b: tuple[int, int]) -> int:
    dq, dr = a[0] - b[0], a[1] - b[1]
    return int((abs(dq) + abs(dr) + abs(dq + dr)) // 2)


def neighbours(q: int, r: int) -> list[tuple[int, int, str]]:
    return [(q + dq, r + dr, d) for (dq, dr), d in STEPS]


def hex_id(q: int, r: int) -> str:
    return f"hex|{q}|{r}"


def parse_id(loc: str) -> tuple[int, int] | None:
    if not str(loc or "").startswith("hex|"):
        return None
    try:
        _h, q, r = loc.split("|")
        return int(q), int(r)
    except ValueError:
        return None


def hex_of_point(world, p) -> str:
    return hex_id(*at(world, *p)) if p is not None else ""


# ======================================================================
# What a hex is like
# ======================================================================
def biome(world, q: int, r: int) -> str:
    from game import geography as G
    return G.biome_at(world, *center(world, q, r))


def region(world, q: int, r: int):
    from game import geography as G
    return G.region_at(world, *center(world, q, r))


def continent(world, q: int, r: int):
    from game import geography as G
    return G.continent_at(world, *center(world, q, r))


def on_map(world, q: int, r: int) -> bool:
    from game import geography as G
    x, y = center(world, q, r)
    g = G.terrain(world)
    return 0 <= x < g.width and 0 <= y < g.height


def _continent_id(world, q: int, r: int) -> str:
    from game import geography as G
    g = G.terrain(world)
    i = g.index(*center(world, q, r))
    return (g.continent[i] if (i is not None and g.continent) else "") or ""


def passable(world, q: int, r: int, on_continent: str | None = None) -> bool:
    """Can the party walk into this hex? Not water, not off the map, and (when the world has
    continents) on the continent they're on."""
    if not on_map(world, q, r) or biome(world, q, r) in WATER:
        return False
    if on_continent is not None and world.entities.all("continent"):
        return _continent_id(world, q, r) == on_continent
    return True


def hours_into(world, q: int, r: int) -> float:
    from game import geography as G
    return round(hex_miles(world) / G.mph(world) * DIFFICULTY.get(biome(world, q, r), 1.5), 2)


def name(world, q: int, r: int) -> str:
    b = biome(world, q, r)
    reg = region(world, q, r)
    return f"Open {NOUN.get(b, 'country')}" + (f" in {reg.name}" if reg is not None else "")


def encounter_chance(world, q: int, r: int) -> int:
    reg = region(world, q, r)
    base = int(world.rules.get("hex_encounter_chance", 6) or 0)
    return max(0, min(95, base + int((reg.fields.get("danger") if reg is not None else 0) or 0) // 4))


# ======================================================================
# What's in a hex
# ======================================================================
def _index(world) -> dict[tuple[int, int], dict]:
    """hex -> {"towns": [...], "landmarks": [...], "dungeons": [...]} (cached until those change)."""
    from game import geography as G
    key = (hex_miles(world), world.entities.count("town"), world.entities.count("landmark"),
           world.entities.count("dungeon"), id(G.town_positions(world)))
    cached = getattr(world, "_hex_index", None)
    if cached is not None and cached[0] == key:
        return cached[1]
    idx: dict[tuple[int, int], dict] = {}

    def put(kind, e, p):
        if p is not None:
            idx.setdefault(at(world, *p), {"towns": [], "landmarks": [], "dungeons": []})[kind].append(e)
    for t in world.entities.all("town"):
        put("towns", t, G.town_position(world, t))
    for lm in world.entities.all("landmark"):
        put("landmarks", lm, G.landmark_position(world, lm))
    for d in world.entities.all("dungeon"):
        if not world.entities.by_field("landmark", "dungeon", d.id):
            put("dungeons", d, G.dungeon_position(world, d))
    world._hex_index = (key, idx)
    return idx


def things_in(world, q: int, r: int) -> dict:
    return _index(world).get((q, r), {"towns": [], "landmarks": [], "dungeons": []})


def town_hex(world, town) -> tuple[int, int] | None:
    from game import geography as G
    p = G.town_position(world, town)
    return at(world, *p) if p is not None else None


def party_hex(world, state) -> tuple[int, int] | None:
    from game import geography as G
    here = parse_id(state.location)
    if here is not None:
        return here
    p = G.party_position(world, state)
    return at(world, *p) if p is not None else None


# ======================================================================
# Finding a way
# ======================================================================
def path(world, start: tuple[int, int], goal: tuple[int, int], on_continent: str | None = None) -> list:
    """Quickest walk from one hex to another: [(q, r), ...] not including the start ([] = no way).
    The goal itself may be a town or landmark hex on land; water is never crossed."""
    if start == goal:
        return []
    if not passable(world, *goal, on_continent):
        return []
    best = {start: 0.0}
    came: dict = {}
    fastest = hex_miles(world) / max(0.5, float(world.rules.get("travel_mph", 3) or 3))
    heap = [(0.0, 0.0, start)]
    seen = 0
    while heap:
        _f, cost, cur = heapq.heappop(heap)
        if cur == goal:
            break
        if cost > best.get(cur, 1e18):
            continue
        seen += 1
        if seen > MAX_SEARCH:
            return []
        for q, r, _d in neighbours(*cur):
            if not passable(world, q, r, on_continent):
                continue
            c = cost + hours_into(world, q, r)
            if c < best.get((q, r), 1e18):
                best[(q, r)] = c
                came[(q, r)] = cur
                heapq.heappush(heap, (c + distance((q, r), goal) * fastest, c, (q, r)))
    if goal not in came:
        return []
    out = []
    node = goal
    while node != start:
        out.append(node)
        node = came[node]
    return list(reversed(out))


def quick_path(world, start: tuple[int, int], goal: tuple[int, int], water: bool, limit: int = 150000) -> list:
    """A rough way between two hexes for a ship (water=True: open water, coast at a little more, other
    land only at a high price, to get out of port) or a caravan (water=False: land, never water).
    [(q, r), ...] not including the start; [] when none is found."""
    if start == goal:
        return []
    best = {start: 0.0}
    came: dict = {}
    heap = [(0.0, 0.0, start)]
    seen = 0
    while heap:
        _f, cost, cur = heapq.heappop(heap)
        if cur == goal:
            break
        if cost > best.get(cur, 1e18):
            continue
        seen += 1
        if seen > limit:
            return []
        for q, r, _d in neighbours(*cur):
            nxt = (q, r)
            if not on_map(world, q, r):
                continue
            b = biome(world, q, r)
            if water:
                step = 1.0 if b in WATER else 2.5 if b == "Coast" else 25.0
            else:
                if b in WATER and nxt != goal:
                    continue
                step = 1.0
            c = cost + step
            if c < best.get(nxt, 1e18):
                best[nxt] = c
                came[nxt] = cur
                heapq.heappush(heap, (c + distance(nxt, goal) * 1.05, c, nxt))
    if goal not in came:
        return []
    out = []
    node = goal
    while node != start:
        out.append(node)
        node = came[node]
    return list(reversed(out))


def path_hours(world, steps: list) -> float:
    return round(sum(hours_into(world, q, r) for q, r in steps), 1)


# ======================================================================
# Treks: crossing open country hex by hex
# ======================================================================
def start_trek(world, state, goal: tuple[int, int], then: str = "", bus=None) -> dict | None:
    """Plan a trek from where the party is to a hex. `then` is a location to go into on arrival
    (a town, a landmark). Returns the trek, or None if there's no way."""
    here = party_hex(world, state)
    if here is None:
        return None
    on = _continent_id(world, *here) if world.entities.all("continent") else None
    steps = path(world, here, goal, on)
    if not steps and here != goal:
        return None
    state.trek = {"path": [list(s) for s in steps], "i": 0, "then": then,
                  "hours": path_hours(world, steps), "goal": list(goal)}
    state.save()
    if bus is not None and steps:
        bus.emit("log", kind="narration", text=f"You strike out across open country: {len(steps)} hexes, about "
                                               f"{state.trek['hours']:g} hours.")
    return state.trek


def trek_step(world, state, rng: random.Random, levels: list[int], bus=None, members: list | None = None) -> dict:
    """Walk into the next hex. Returns {"kind": "progress" | "encounter" | "arrived", ...}. Riding (everyone
    on a mount, or a cart with an animal to pull it) crosses it faster (game/animals.py)."""
    from game import places, travel
    t = state.trek
    if not t:
        return {"kind": "arrived"}
    if t["i"] >= len(t["path"]):
        state.trek = None
        then = t.get("then") or ""
        if then:
            places.enter(world, state, then, bus)
        state.save()
        return {"kind": "arrived", "target": then}
    q, r = t["path"][t["i"]]
    hours = hours_into(world, q, r)
    try:                                          # bad weather slows the going
        from game import weather as W
        hours /= max(0.25, W.at(world, state.minutes, biome(world, q, r), *center(world, q, r)).travel)
    except Exception:          # noqa: BLE001
        pass
    if members:
        from game import animals
        hours /= animals.travel_factor(world, state, members)
    state.advance(int(round(hours * 60)), "crossing open country")
    t["i"] += 1
    places.enter(world, state, hex_id(q, r), bus, announce=False)
    if members is not None and world.rules.get("survival"):       # out of food or water: stop (game/survival.py)
        from game import survival
        warn = survival.out_of_supplies(world, state, members)
        if warn:
            stop_trek(state)
            if bus is not None:
                bus.emit("log", kind="system", text=warn)
            return {"kind": "stopped", "text": warn}
    from game import settlements as ST
    if rng.random() < encounter_chance(world, q, r) * ST.danger_factor(world, *center(world, q, r)) / 100.0:
        reg = region(world, q, r)
        found = travel.encounter(world, biome(world, q, r), levels, rng, region=reg,
                                 night=state.time_of_day in ("Night", "Dusk"))
        if found:
            found["kind"] = "encounter"
            return found
    if t["i"] >= len(t["path"]):
        return trek_step(world, state, rng, levels, bus, members)
    if bus is not None and t["i"] % 3 == 0:
        bus.emit("log", kind="narration", text=f"{name(world, q, r)}. ({t['i']} of {len(t['path'])} hexes)")
    return {"kind": "progress"}


def stop_trek(state) -> None:
    state.trek = None
    state.save()


def _terrain(b: str) -> str:
    """Biome -> the terrain names encounters and battle maps use."""
    return {"Jungle": "Forest", "Badlands": "Desert", "Lake": "Coast", "Ocean": "Coast", "Taiga": "Forest",
            "Tundra": "Arctic", "Savanna": "Plains"}.get(b, b)


__all__ = ["center", "corners", "at", "distance", "neighbours", "hex_id", "parse_id", "biome", "region",
           "continent", "passable", "hours_into", "name", "things_in", "path", "quick_path", "start_trek", "trek_step"]
