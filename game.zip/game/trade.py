"""Buying and selling with NPCs.

What an NPC sells: everything in their "Always stocks" list, plus items tagged
with their "Sells items tagged" words (or, if those are blank, their
occupation's usual goods). Stock and the NPC's purse refill every week (world
rule shop_restock_days). Rare and better items only appear if they're in
"Always stocks".

Prices, in copper pieces: buying costs the item's value times the NPC's markup;
attitude changes it (Friendly 10% less, Wary 20% more, Hostile won't trade);
a successful haggle (once a day per NPC) takes 10% off. Selling pays half the
item's value (world rule sell_price_percent), as long as the NPC can afford it; a trade that uses some raw
material (ore at the smithy, hides at the hunter's, herbs at the alchemist's: BUYS) pays a quarter more.

What a trader's people make at work (game/crafting.py: the smith's blades, the tailor's cloaks) goes on the
shelf as each piece is finished, and some of it is in every restock.

Where (step 11): prices follow the town. Its own produce (game/settlements.py) is cheap there (x0.75), what
it needs is dear (x1.35), and every one of a good sold there lately takes 4% off its price (down to half),
easing day by day. Trade goods (ore, timber, grain, furs, spices...) sell for 65% of their worth there
(world rule sell_goods_percent), so buying where a good is made and selling where it's needed pays. Standing
with the town moves prices too (Revered 12% off; Hated half again). Stolen goods (game/law.py) are refused
except by a fence or a shopkeeper in another neighborhood.

Trade routes: a cart or wagon (with an animal hitched) or a boat, a hired crew and a stake from the purse
carry a good from where it's made to where it's needed, a round trip at a time, through the catch-up step;
each trip's profit (or loss) goes to the purse and into the reports.

Gathering tools (game/gathering.py) turn up in the shops of the trades that use them (TOOL_STOCK): picks
and axes at the smithy, knives, tackle and snares at the hunter's, sickles and scythes at the farm.
"""
from __future__ import annotations

import math
import random

from game.constants import OCCUPATIONS

ATTITUDE = {"Friendly": 0.9, "Neutral": 1.0, "Wary": 1.2, "Hostile": None}
GOOD_RARITIES = ("", "Common", "Uncommon")
STACKY = ("Consumable", "Ammunition", "Material", "Gear", "Treasure")
# raw materials each trade pays more for (item tags), and the gathering tools it keeps (game/tools.py work)
BUYS = {"Blacksmith": {"ore", "metal", "stone"}, "Armorer": {"hide", "metal"}, "Weaponsmith": {"metal", "wood"},
        "Merchant": {"wood", "stone", "grain"}, "Alchemist": {"herb", "mushroom", "alchemical", "monster"},
        "Innkeeper": {"fish", "berry", "mushroom", "grain"}, "Hunter": {"hide", "monster"},
        "Farmer": {"grain"}, "Tailor": {"hide", "cloth"}, "Fletcher": {"wood", "feather"},
        "Jeweler": {"gem", "treasure"}}
BUY_BONUS = 1.25
TOOL_STOCK = {"Blacksmith": {"mining", "woodcutting"}, "Merchant": {"mining", "woodcutting", "fishing", "foraging"},
              "Hunter": {"skinning", "fishing", "trapping"}, "Farmer": {"harvesting", "foraging"},
              "Alchemist": {"foraging"}}


def tags_for(npc) -> set[str]:
    own = {t.strip().lower() for t in npc.fields.get("sells_tags") or [] if t.strip()}
    return own or set(OCCUPATIONS.get(npc.fields.get("occupation") or "", []))


def item_tags(item) -> set[str]:
    f = item.fields
    return {t.lower() for t in item.tags} | {str(f.get("category") or "").lower()}


def _attitude(world, state, npc) -> str:
    """How the trader feels about the party: their own mood moved by its standing with their factions."""
    from game import factions
    return factions.attitude(world, state, npc)


def will_trade(npc, state=None) -> bool:
    mood = _attitude(state.world, state, npc) if state is not None else (npc.fields.get("disposition") or "Neutral")
    return ATTITUDE.get(mood, 1.0) is not None


def is_merchant(world, npc) -> bool:
    if npc.fields.get("shop_items"):
        return True
    tags = tags_for(npc)
    return bool(tags) and any(item_tags(i) & tags for i in world.entities.all("item"))


def restock_days(world) -> int:
    return int(world.rules.get("shop_restock_days", 7) or 7)


def _restock(world, state, npc, rng: random.Random) -> None:
    mem = state.npc(npc.id)
    tags = tags_for(npc)
    always = [i for i in (world.entities.get(x) for x in npc.fields.get("shop_items") or []) if i is not None]
    magic_shop = "magic" in tags
    pool = [i for i in world.entities.all("item")
            if item_tags(i) & tags and (i.fields.get("rarity") or "") in GOOD_RARITIES and i not in always
            and (magic_shop or "magic" not in i.tags or (i.fields.get("rarity") or "Common") == "Common")]
    rng.shuffle(pool)
    stock = {}
    from game import quality
    for item in always + pool[:max(0, 12 - len(always))]:
        stacky = bool(item.fields.get("stackable")) or item.fields.get("category") in STACKY
        stock[item.id] = rng.randint(3, 12) if stacky else rng.randint(1, 2)
        if quality.can_vary(item) and not stacky:            # now and then a better or a cheaper one
            r = rng.random()
            if r < 0.12:
                stock[quality.variant(item.id, "Fine")] = 1
            elif r < 0.2:
                stock[quality.variant(item.id, "Poor")] = 1
            elif r < 0.215:
                stock[quality.variant(item.id, "Masterwork")] = 1
    try:                                              # what the trader's own people make (game/crafting.py)
        from game import crafting
        made = crafting.trade_products(world, npc.fields.get("occupation") or "")
    except Exception:  # noqa: BLE001
        made = []
    if made:
        for iid in rng.sample(made, min(4, len(made))):
            it = world.entities.get(iid)
            if it is not None and iid not in stock:
                stock[iid] = rng.randint(1, 3)
    if not npc.fields.get("sells_tags"):              # the tools of the trade
        from game import tools
        works = TOOL_STOCK.get(npc.fields.get("occupation") or "", set())
        if works:
            for item in world.entities.all("item"):
                if item.id not in stock and tools.work_of(item) in works and \
                        (item.fields.get("rarity") or "") in GOOD_RARITIES and "magic" not in item.tags:
                    if rng.random() < 0.7:
                        stock[item.id] = rng.randint(1, 2)
    mem["stock"] = stock
    mem["stocked_day"] = state.day
    mem["purse"] = int(float(npc.fields.get("gold", 100) or 0) * 100)
    state.save()


HONORED = 21           # standing at which a trader brings out what they keep for friends (game/factions.py)
SPECIAL_RARITIES = ("Uncommon", "Rare")


def honored(world, state, npc) -> bool:
    """Is the party Honored (or better) with this trader's factions?"""
    from game import factions
    return factions.npc_standing(world, state, npc) >= HONORED


def _special(world, state, npc) -> None:
    """The few better pieces a trader keeps back for those their people honour (chosen once per restock)."""
    mem = state.npc(npc.id)
    tags = tags_for(npc)
    have = set(mem.get("stock") or {})
    pool = [i for i in world.entities.all("item")
            if item_tags(i) & tags and (i.fields.get("rarity") or "") in SPECIAL_RARITIES and i.id not in have]
    rng = random.Random(f"{npc.id}|{mem.get('stocked_day', 0)}")
    rng.shuffle(pool)
    picks = [i.id for i in pool[:3]]
    for iid in picks:
        mem["stock"][iid] = 1
    mem["special"] = picks
    mem["special_day"] = mem.get("stocked_day", 0)


def special_ids(state, npc) -> list[str]:
    return list(state.npc(npc.id).get("special") or [])


def stock(world, state, npc, rng: random.Random | None = None) -> dict[str, int]:
    """item id -> how many the NPC has, refilling it when a week has passed. Traders whose people honour
    the party bring out a few uncommon or rare pieces too."""
    mem = state.npc(npc.id)
    if "stock" not in mem or state.day >= int(mem.get("stocked_day", 0)) + restock_days(world):
        _restock(world, state, npc, rng or random.Random())
    try:                                              # and what they've finished since (goes on the shelf)
        from game import crafting
        crafting.npc_work(world, state, npc)
    except Exception:  # noqa: BLE001
        pass
    try:                                              # a festival's goods (game/townevents.py), once a festival
        from game import townevents as TE
        extra = TE.festival_stock(world, state, npc)
        if extra and mem.get("festival_day") != state.day // 3:
            mem["festival_day"] = state.day // 3
            for k, v in extra.items():
                mem["stock"][k] = mem["stock"].get(k, 0) + v
    except Exception:  # noqa: BLE001
        pass
        mem.pop("special", None)
    is_honored = honored(world, state, npc)
    if is_honored and mem.get("special_day") != mem.get("stocked_day", 0):
        _special(world, state, npc)
    mem["stock"] = {k: v for k, v in mem["stock"].items() if v > 0 and world.entities.get(k) is not None}
    if not is_honored and mem.get("special"):
        hidden = set(mem["special"])
        return {k: v for k, v in mem["stock"].items() if k not in hidden}
    return mem["stock"]


def purse(state, npc) -> int:
    return int(state.npc(npc.id).get("purse", int(float(npc.fields.get("gold", 100) or 0) * 100)))


def _haggle_factor(state, npc) -> float:
    mem = state.npc(npc.id)
    return 0.9 if mem.get("haggle_day") == state.day and mem.get("haggled") else 1.0


# ----------------------------------------------------------------------------------------------------
# What things are worth here (step 11): what the town makes and needs, how much of it has been sold here
# lately, and the party's name in town
# ----------------------------------------------------------------------------------------------------
# item tags -> the trade goods of game/settlements.py
GOOD_OF_TAG = {"ore": "ore", "metal": "ore", "ingot": "ore", "stone": "stone", "gem": "gems", "gems": "gems",
               "wood": "timber", "timber": "timber", "fish": "fish", "salt": "salt", "grain": "grain",
               "farm": "livestock", "meat": "livestock", "livestock": "livestock", "wool": "wool", "fibre": "wool",
               "hide": "furs", "fur": "furs", "furs": "furs", "herb": "herbs", "mushroom": "herbs", "spice": "spices",
               "spices": "spices", "dye": "dyes", "dyes": "dyes", "wine": "wine", "drink": "wine", "cloth": "cloth",
               "clothing": "cloth", "tool": "tools", "tools": "tools"}
MADE_HERE = 0.75             # a town's own produce is cheap there
NEEDED_HERE = 1.35           # what it needs costs (and fetches) more
GLUT_STEP = 0.04             # each one sold here lately takes 4% off its price here...
GLUT_FLOOR = 0.5             # ...down to half
GLUT_DECAY = 0.85            # and the glut eases by 15% a day
TOWN_REP = {"Hated": 1.5, "Hostile": 1.25, "Unfriendly": 1.1, "Neutral": 1.0, "Friendly": 0.97, "Honored": 0.93,
            "Revered": 0.88}


def good_of(item) -> str:
    """The trade good an item counts as ("" for most made things)."""
    if item is None:
        return ""
    for t in item.tags or []:
        g = GOOD_OF_TAG.get(str(t).lower())
        if g:
            return g
    return ""


def _town_of(world, npc):
    from game import neighborhood as NB
    return world.entities.get(NB.npc_town(world, npc)) if npc is not None else None


def _market(state, town) -> dict:
    return state.npc(f"market:{town.id}")


def glut(state, town, good: str) -> float:
    """How much of a good has been sold in this town lately (eased day by day)."""
    if town is None or not good:
        return 0.0
    m = _market(state, town)
    g = m.get("glut", {}).get(good)
    if not g:
        return 0.0
    amount, day = g
    return float(amount) * GLUT_DECAY ** max(0, state.day - int(day))


def _add_glut(state, town, good: str, n: int) -> None:
    if town is None or not good or n <= 0:
        return
    m = _market(state, town)
    m.setdefault("glut", {})[good] = [round(glut(state, town, good) + n, 3), state.day]


def town_factor(world, state, town, item) -> float:
    """What a good is worth here against its usual price: produce cheap, needs dear, a glut cheaper."""
    if town is None:
        return 1.0
    from game import settlements as ST
    g = good_of(item)
    if not g:
        return 1.0
    f = MADE_HERE if g in ST.produces(town) else NEEDED_HERE if g in ST.needs(town) else 1.0
    return f * max(GLUT_FLOOR, 1.0 - GLUT_STEP * glut(state, town, g))


def rep_factor(world, state, town) -> float:
    """Standing with the town itself: friends pay less, the disliked more (and get less for what they sell)."""
    from game import factions
    tf = factions.town_faction(world, town) if town is not None else None
    if tf is None or state is None:
        return 1.0
    return TOWN_REP.get(factions.level(world, state, tf.id), 1.0)


def buy_price(world, state, npc, item) -> int:
    """Copper for one, from this NPC (0 if they won't sell)."""
    att = ATTITUDE.get(_attitude(world, state, npc), 1.0)
    if att is None:
        return 0
    markup = float(npc.fields.get("price_markup", 100) or 100) / 100.0
    value = float(item.fields.get("value") or 0) * 100
    town = _town_of(world, npc)
    here = town_factor(world, state, town, item) * rep_factor(world, state, town)
    return max(1, int(round(value * markup * att * here * _haggle_factor(state, npc))))


def sell_price(world, state, npc, item) -> int:
    """Copper the NPC pays for one (a fence pays a fraction for stolen goods; game/law.py)."""
    att = ATTITUDE.get(_attitude(world, state, npc), 1.0)
    if att is None:
        return 0
    pct = float(world.rules.get("sell_price_percent", 50) or 50) / 100.0
    if good_of(item):                                # trade goods keep more of their worth
        pct = max(pct, float(world.rules.get("sell_goods_percent", 65) or 65) / 100.0)
    value = float(item.fields.get("value") or 0) * 100
    if value <= 0:
        return 0
    if item.fields.get("stolen"):
        from game import law
        ok, fence = law.will_buy_stolen(world, state, npc, item.id)
        if not ok:
            return 0
        if fence:
            return max(1, int(value * law.STOLEN_SELL))
    bonus = 1.1 if _haggle_factor(state, npc) < 1 else 1.0
    if wants(npc, item):
        bonus *= BUY_BONUS
    town = _town_of(world, npc)
    here = town_factor(world, state, town, item) / rep_factor(world, state, town)
    return max(1, int(value * pct / (att if att > 1 else 1.0) * bonus * here))


def wants(npc, item) -> bool:
    """Does this trader use this raw material (and so pay more for it)?"""
    return bool(BUYS.get(npc.fields.get("occupation") or "", set()) & {t.lower() for t in item.tags or []})


def buy(world, state, npc, item_id: str, n: int = 1, bus=None) -> tuple[bool, str]:
    item = world.entities.get(item_id)
    have = stock(world, state, npc).get(item_id, 0)
    if item is None or have <= 0:
        return False, "They don't have that."
    n = max(1, min(n, have))
    cost = buy_price(world, state, npc, item) * n
    if cost > state.copper:
        return False, "You can't afford that."
    state.add_copper(-cost, f"bought {item.name}")
    mem = state.npc(npc.id)
    mem["stock"][item_id] = have - n
    mem["purse"] = purse(state, npc) + cost
    state.add_item(item_id, n, source="trade")
    if bus is not None:
        bus.emit("trade.bought", npc=npc.id, item=item_id, count=n, copper=cost)
    from game.state import money_text
    return True, f"Bought {item.name}{' x' + str(n) if n > 1 else ''} for {money_text(cost)}."


def sell(world, state, npc, item_id: str, n: int = 1, bus=None) -> tuple[bool, str]:
    item = world.entities.get(item_id)
    have = state.count(item_id)
    if item is None or have <= 0:
        return False, "You don't have that."
    if locked(world, state, item_id):
        return False, f"You need the {item.name.lower()} for a quest. It isn't for sale while the story goes on."
    n = max(1, min(n, have))
    if item.fields.get("stolen"):
        from game import law
        if not law.will_buy_stolen(world, state, npc, item_id)[0]:
            return False, f"{npc.name} looks at the {item.name.lower().replace(' (stolen)', '')} and then at you. " \
                          "\"I don't buy that sort of thing. Not from round here.\""
    each = sell_price(world, state, npc, item)
    if each <= 0:
        return False, f"{npc.name} won't pay anything for that."
    pay = each * n
    if pay > purse(state, npc):
        return False, f"{npc.name} can't afford that right now."
    state.remove_item(item_id, n, reason="sold")
    state.add_copper(pay, f"sold {item.name}")
    mem = state.npc(npc.id)
    mem["purse"] = purse(state, npc) - pay
    stock(world, state, npc)
    from game import quality
    shelf_id = quality.unmarked(item_id)                 # on their shelf it's just stock
    mem["stock"][shelf_id] = mem["stock"].get(shelf_id, 0) + n
    _add_glut(state, _town_of(world, npc), good_of(item), n)
    state.save()
    if bus is not None:
        bus.emit("trade.sold", npc=npc.id, item=item_id, count=n, copper=pay)
    from game.state import money_text
    return True, f"Sold {item.name}{' x' + str(n) if n > 1 else ''} for {money_text(pay)}."


# ----------------------------------------------------------------------------------------------------
# Trade routes (step 11): a cart or a boat of the party's, a hired crew, and a stake to trade with. It
# buys a good where it's made and sells it where it's needed, again and again, through the catch-up step.
# ----------------------------------------------------------------------------------------------------
ROUTE_SELL = 0.65            # what a cargo fetches at market there, of its worth there
DROVER_WAGE = 0.5            # gp a day for a carter (boats pay their own crews: game/animals.py)
LOSS_CHANCE = 0.05           # a trip that meets bandits or a storm...
LOSS_SHARE = 0.2             # ...loses this much of the stake
TRIP_GLUT = 2.0              # what each cargo adds to the glut where it's sold


def _route_days(world, vehicle, a, b) -> int:
    """Days for one way."""
    from game import animals
    from game import geography as G
    pa, pb = G.town_position(world, a), G.town_position(world, b)
    miles = math.hypot(pb[0] - pa[0], pb[1] - pa[1]) * 1.2 if (pa and pb) else 50
    if vehicle["kind"] == "boat":
        _p, mph, _c, _cargo, hours = animals.BOATS.get(vehicle["type"], animals.BOATS["Rowboat"])
    else:
        mph, hours = 3.0 * 40 / 30, 8
    return max(1, int(math.ceil(miles / (mph * hours))))


def _route_wage(world, vehicle) -> float:
    from game import animals
    if vehicle["kind"] == "boat":
        return max(1, animals.BOATS.get(vehicle["type"], animals.BOATS["Rowboat"])[2]) * animals.CREW_WAGE
    return DROVER_WAGE


def route_goods(world, a, b) -> list[str]:
    """Goods made in a and needed in b (the ones worth carrying)."""
    from game import settlements as ST
    return [g for g in ST.produces(a) if g in ST.needs(b)]


def route_margin(world, state, a, b, good: str) -> float:
    """What a cargo of this good gains, bought in a and sold in b (before wages): 0.17 is 17%."""
    from game import settlements as ST
    f_a = MADE_HERE if good in ST.produces(a) else NEEDED_HERE if good in ST.needs(a) else 1.0
    f_b = NEEDED_HERE if good in ST.needs(b) else MADE_HERE if good in ST.produces(b) else 1.0
    f_b *= max(GLUT_FLOOR, 1.0 - GLUT_STEP * glut(state, b, good))
    return ROUTE_SELL * f_b / f_a - 1.0


def route_plan(world, state, vehicle, a, b, stake_gp: int) -> dict:
    """What a route would do: {"good", "days" (a round trip), "margin", "wages", "profit" (a trip), "why"}."""
    from game import animals
    goods = route_goods(world, a, b)
    if vehicle["kind"] == "vehicle" and not any(x.get("pulls") == vehicle["id"] for x in animals.owned(state)):
        return {"why": f"{vehicle['name']} needs an animal hitched to pull it."}
    if vehicle["kind"] == "animal":
        return {"why": "Only a cart, a wagon or a boat can carry a cargo on a route."}
    if vehicle["kind"] == "boat" and not (animals.coastal(world, a) and animals.coastal(world, b)):
        return {"why": "A boat can only trade between towns on the water."}
    if not goods:
        return {"why": f"Nothing made in {a.name} is wanted in {b.name}."}
    good = max(goods, key=lambda g: route_margin(world, state, a, b, g))
    days = 2 * _route_days(world, vehicle, a, b)
    wages = int(round(_route_wage(world, vehicle) * days * 100))
    margin = route_margin(world, state, a, b, good)
    return {"good": good, "days": days, "margin": margin, "wages": wages,
            "profit": int(stake_gp * 100 * margin) - wages, "why": ""}


def routes(state) -> list[dict]:
    return state.holdings.setdefault("routes", [])


def start_route(world, state, vehicle_id: str, from_id: str, to_id: str, stake_gp: int) -> tuple[bool, str]:
    """Send a cart or boat off to trade between two towns, with a stake from the purse."""
    from game import animals
    v = animals.get(state, vehicle_id)
    a, b = world.entities.get(from_id), world.entities.get(to_id)
    if v is None or a is None or b is None or a.id == b.id:
        return False, "Pick a vehicle and two towns."
    if v.get("route"):
        return False, f"{v['name']} is already out on a route."
    plan = route_plan(world, state, v, a, b, stake_gp)
    if plan.get("why"):
        return False, plan["why"]
    if stake_gp <= 0 or stake_gp * 100 > state.copper:
        return False, "You haven't the money for that stake."
    state.add_copper(-stake_gp * 100, "a trading stake")
    r = {"id": state.next_id("r"), "vehicle": v["id"], "from": a.id, "to": b.id, "good": plan["good"],
         "stake": stake_gp * 100, "days": plan["days"], "next": state.minutes + plan["days"] * 1440,
         "trips": 0, "earned": 0, "lost": 0, "started": state.day}
    routes(state).append(r)
    v["route"] = r["id"]
    for x in animals.owned(state):
        if x.get("pulls") == v["id"]:
            x["route"] = r["id"]
    state.ticks.setdefault("trade_routes", state.minutes)
    animals._save(world, state)
    return True, (f"{v['name']} sets off to carry {plan['good']} from {a.name} to {b.name}: a round trip every "
                  f"{plan['days']} days, about {_money(plan['profit'])} a trip after wages.")


def stop_route(world, state, route_id: str) -> tuple[bool, str]:
    """Call it home: the stake comes back to the purse, and the vehicle to where it set out."""
    from game import animals
    r = next((x for x in routes(state) if x["id"] == route_id), None)
    if r is None:
        return False, "No such route."
    state.holdings["routes"] = [x for x in routes(state) if x["id"] != route_id]
    for x in animals.owned(state, True):
        if x.get("route") == route_id:
            x.pop("route", None)
            x["home"] = r["from"]
    state.add_copper(int(r["stake"]), "the trading stake back")
    animals._save(world, state)
    return True, f"The route is wound up: {_money(r['stake'])} of stake back, {_money(r['earned'])} earned in all."


def _money(c: int) -> str:
    from game.state import money_text
    return money_text(int(c))


def _routes_catch_up(world, state, since: int, now: int) -> None:
    """Every round trip that finished: the profit to the purse (or the loss to the stake), and a report."""
    import random as _r
    from game import animals
    reports = state.holdings.setdefault("reports", [])
    for r in list(routes(state)):
        v = animals.get(state, r["vehicle"])
        a, b = world.entities.get(r["from"]), world.entities.get(r["to"])
        if v is None or a is None or b is None:
            continue
        rng = _r.Random(f"{r['id']}:{r['trips']}")
        guard = 0
        while int(r["next"]) <= now and guard < 400 and r["stake"] > 0:
            guard += 1
            r["next"] = int(r["next"]) + r["days"] * 1440
            r["trips"] += 1
            wages = int(round(_route_wage(world, v) * r["days"] * 100))
            if rng.random() < LOSS_CHANCE:
                lost = int(r["stake"] * LOSS_SHARE)
                r["stake"] -= lost
                r["lost"] += lost
                state.copper = max(0, state.copper - wages)
                reports.append(f"Trade route {a.name} - {b.name}: the cargo was lost on the way "
                               f"({_money(lost)} of the stake), and the crew still wants paying ({_money(wages)}).")
                continue
            gain = int(r["stake"] * route_margin(world, state, a, b, r["good"])) - wages
            _add_glut(state, b, r["good"], TRIP_GLUT)
            state.copper = max(0, state.copper + gain)
            r["earned"] += gain
            reports.append(f"Trade route {a.name} - {b.name}: a cargo of {r['good']} sold, "
                           + (f"{_money(gain)} profit" if gain >= 0 else f"{_money(-gain)} lost") + " after wages.")
    del reports[:-50]


def take_reports(state) -> list[str]:
    out = list(state.holdings.get("reports") or [])
    state.holdings["reports"] = []
    return out


def _register() -> None:
    from game import ticker
    ticker.register("trade_routes", _routes_catch_up)


_register()


def locked(world, state, item_id: str) -> bool:
    """A quest item an active chain needs (game/chains.py): not to be sold or broken down."""
    from game import chains
    from game import quality
    try:
        return quality.base_of(item_id) in chains.locked_items(world, state)
    except Exception:  # noqa: BLE001
        return False


def can_haggle(state, npc) -> bool:
    return state.npc(npc.id).get("haggle_day") != state.day


def haggled(state, npc, success: bool) -> None:
    mem = state.npc(npc.id)
    mem["haggle_day"] = state.day
    mem["haggled"] = bool(success)
    state.save()
