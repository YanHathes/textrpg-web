"""Rumors: what barkeeps (sometimes for the price of a drink), notice boards and townsfolk pass on. Each
points to something real nearby (the neighborhood: game/neighborhood.py):

    quest     someone in the neighborhood with troubles of their own (a chain to be had)
    deposit   a hidden deposit (game/gathering.py): a rich vein or rare herbs, shown on the map once heard
    lair      the lair of something dangerous
    relic     a lost relic and the dungeon it lies in

Heard rumors are kept in the save (state.rumors) and listed in the journal, where one can be pinned (the
map pin then points to it). The same rumor is never heard twice.

    {"id", "kind", "text", "target" (entity id), "loc" (a place id), "cell": [x, y] (a deposit's square),
     "day", "from"}
"""
from __future__ import annotations

import random

from game import neighborhood as NB

DRINK_PRICE = 20            # copper: a round for the barkeep, and they talk
FREE_CHANCE = 0.4           # asking for nothing: sometimes they've heard something real
CROWD_CHANCE = 0.08         # townsfolk in the street, now and then
DIR_WORDS = {"N": "north", "S": "south", "E": "east", "W": "west", "NE": "north-east", "NW": "north-west",
             "SE": "south-east", "SW": "south-west"}


def heard(state) -> list[dict]:
    return [r for r in (state.rumors or []) if isinstance(r, dict)]


def _known_targets(state) -> set:
    return {r.get("target") or r.get("key") for r in heard(state)}


def _direction(dx: float, dy: float) -> str:
    import math
    if abs(dx) < 1e-6 and abs(dy) < 1e-6:
        return ""
    a = math.degrees(math.atan2(-dy, dx)) % 360
    names = ["east", "north-east", "north", "north-west", "west", "south-west", "south", "south-east"]
    return names[int((a + 22.5) // 45) % 8]


def candidates(world, state, town) -> list[dict]:
    """Every rumor that could be told in this town that hasn't been heard yet."""
    from game import chains
    from game import dungeons as DG
    hood = NB.neighborhood(world, town)
    known = _known_targets(state)
    out = []
    took = {c.get("giver") for c in chains.all_chains(state)}
    for n in hood.npcs(world, state):
        occ = n.fields.get("occupation") or ""
        if occ not in chains.OCC_STORY or n.id in took or n.id in known:
            continue
        t = world.entities.get(NB.npc_town(world, n))
        title = chains.STORIES[chains.OCC_STORY[occ]]["title"].replace("{village}", t.name if t else "a village")
        out.append({"kind": "quest", "target": n.id, "loc": chains._loc_of(world, n.id),
                    "text": f"{n.name}, the {occ.lower()} in {t.name if t else 'town'}, has had troubles. "
                            f"Something about '{title.lower()}'. They could use help."})
    for d in hood.dungeons:
        if d.id in known:
            continue
        relic = next((i for i in world.entities.all("item") if i.fields.get("found_in") == d.id), None)
        if relic is not None:
            out.append({"kind": "relic", "target": d.id, "loc": chains._loc_of(world, d.id),
                        "text": f"They say {relic.name} lies somewhere in {d.name}. Plenty have gone looking."})
        elif (d.fields.get("kind") or "") in ("Lair", "Cave"):
            out.append({"kind": "lair", "target": d.id, "loc": chains._loc_of(world, d.id),
                        "text": f"Something big has made its lair at {d.name}. Stock goes missing whenever it's hungry."})
    for lm in hood.landmarks:
        if lm.id in known or (lm.fields.get("kind") or "") not in ("Lair", "Cave", "Ruins"):
            continue
        out.append({"kind": "lair", "target": lm.id, "loc": DG.landmark_id(lm.id),
                    "text": f"Keep clear of {lm.name}. Whatever lives there doesn't like visitors."})
    out += _deposits(world, state, town, known)
    try:                                       # festivals coming up nearby (game/townevents.py)
        from game import places
        from game import townevents as TE
        for t in hood.towns:
            got = TE.upcoming(world, t, state.minutes, 12)
            if got is None:
                continue
            f, days = got
            key = f"festival:{t.id}:{f.key}"
            if key in known:
                continue
            out.append({"kind": "festival", "target": key, "loc": places.street_id(t.id, places.first_street(t)),
                        "text": f"{f.name} comes to {t.name} in {days} day{'s' if days != 1 else ''}: "
                                f"{f.highlights}. Folk come from all round."})
    except Exception:  # noqa: BLE001
        pass
    return out


def _deposits(world, state, town, known) -> list[dict]:
    """Hidden deposits within a few miles of the town (worlds you can walk)."""
    from game import geography as G
    from game import gathering as GA
    from game import landchanges as LC
    try:
        from game import worldmap as WM
        if not WM.walkable(world):
            return []
    except Exception:  # noqa: BLE001
        return []
    p = G.town_position(world, town)
    if p is None:
        return []
    X, Y = int(p[0] * WM.SQ), int(p[1] * WM.SQ)
    out = []
    reach = 6
    cx0, cy0 = X // LC.CH, Y // LC.CH
    for cy in range(cy0 - reach, cy0 + reach + 1):
        for cx in range(cx0 - reach, cx0 + reach + 1):
            spot = GA.hidden_in_chunk(world, cx, cy, LC.CH)
            if spot is None:
                continue
            key = f"deposit:{spot[0]},{spot[1]}"
            if key in known or LC.change_at(state, *spot) is not None:
                continue
            land = G.biome_at(world, spot[0] / WM.SQ, spot[1] / WM.SQ)
            kind = GA.hidden_kind(land)
            d = _direction(spot[0] - X, spot[1] - Y)
            miles = ((spot[0] - X) ** 2 + (spot[1] - Y) ** 2) ** 0.5 / WM.SQ
            what = "a rich seam of ore" if kind == "rich_vein" else "a patch of rare herbs"
            out.append({"kind": "deposit", "target": "", "key": key, "cell": [spot[0], spot[1]], "deposit": kind,
                        "loc": "", "text": f"Old prospectors talk of {what} about {max(1, round(miles))} "
                                          f"mile{'s' if round(miles) > 1 else ''} {d} of {town.name}."})
    return out


def hear(world, state, town, rng: random.Random | None = None, source: str = "", kinds: tuple | None = None,
         bus=None, about: str = "") -> dict | None:
    """Hear a new rumor in this town (None if there's nothing new). It goes in the journal; a deposit
    rumor also shows the deposit on the map."""
    if town is None:
        return None
    rng = rng or random.Random()
    cands = [c for c in candidates(world, state, town) if kinds is None or c["kind"] in kinds]
    if about:                                          # a lead to one place in particular (a letter's)
        cands = [c for c in cands if c.get("target") == about] or cands
    if not cands:
        return None
    by_kind: dict = {}
    for c in cands:
        by_kind.setdefault(c["kind"], []).append(c)
    kind = rng.choice(sorted(by_kind))
    r = dict(rng.choice(by_kind[kind]))
    r.update(id=state.next_id("r"), day=state.day, **{"from": source})
    state.rumors = heard(state) + [r]
    if r["kind"] == "deposit":
        reveal_deposit(world, state, r, bus)
    state.save()
    if bus is not None:
        bus.emit("rumor.heard", rumor=r)
        bus.emit("log", kind="quest", text=f"Rumor: {r['text']}")
    return r


def reveal_deposit(world, state, r: dict, bus=None) -> None:
    from game import landchanges as LC
    x, y = r["cell"]
    if LC.change_at(state, x, y) is None:
        LC.record(world, state, x, y, {"prop": r.get("deposit") or "rich_vein", "variant": 0, "found": True}, bus)


def position(world, state, r: dict):
    """Where a rumor points, in map miles (for the pin)."""
    from game import geography as G
    from game import places
    if r.get("cell"):
        from game import worldmap as WM
        return r["cell"][0] / WM.SQ, r["cell"][1] / WM.SQ
    if r.get("loc"):
        try:
            return G.party_position_of(world, places.parse(world, r["loc"]), state)
        except Exception:  # noqa: BLE001
            return None
    return None


__all__ = ["hear", "heard", "candidates", "position", "reveal_deposit", "DRINK_PRICE", "FREE_CHANCE", "CROWD_CHANCE"]
