"""Factions and the party's standing with them.

A faction is a group the party can stand well or badly with: a realm, a town (its people and its watch),
a guild, a god's faithful, a gang. Each world gets them made for it (ensure()): one for every realm named
by its regions, every town, every guild that keeps halls, every god with temples, the bandits and smugglers
of each realm, and a thieves' guild in each city.

Standing runs from -100 to +100 and is shown as a level (Hated ... Revered). It's kept in the save
(state.reputation: faction id -> standing; a faction is "met" once it has an entry).

One way in, one way out:
    change(world, state, faction_id, amount, reason)    the only way standing moves. Part of it spreads:
                                                        to the faction it's part of (a town's realm), to
                                                        its allies, and the other way to its rivals.
    standing(), level(), attitude()                     the only ways it's read.

Who belongs where needs no data on the people themselves: an NPC belongs to where they work (a temple's
god, a guild's hall), their town and its realm. A "Belongs to" link on an NPC, building or town overrides.
"""
from __future__ import annotations

VERSION = 1
LEVELS = [(-61, "Hated"), (-21, "Hostile"), (-6, "Unfriendly"), (5, "Neutral"), (20, "Friendly"),
          (60, "Honored"), (100, "Revered")]       # (highest standing in the band, name)
LEVEL_NAMES = [n for _s, n in LEVELS]
MIN, MAX = -100, 100

# how much an NPC's own feelings count, added to their factions' standing
PERSONAL = {"Friendly": 20, "Neutral": 0, "Wary": -15, "Hostile": -100}
WEIGHTS = {"own": 1.0, "work": 1.0, "town": 0.6, "realm": 0.3}

# what the party's deeds are worth (later steps add their own)
QUEST_DONE = 5
HURT = -10
KILLED = -25


def level_name(score: int) -> str:
    for top, name in LEVELS:
        if score <= top:
            return name
    return LEVELS[-1][1]


def _cap(text: str) -> str:
    return text[:1].upper() + text[1:]


# ======================================================================
# Making them
# ======================================================================
def realm_names(world) -> list[str]:
    names = {(r.fields.get("realm") or "").strip() for r in world.entities.all("region")}
    return sorted(n for n in names if n)


GUILDS = {
    "Merchants": ("The Merchants' Guild", "Traders and merchant companies, with halls in the great cities."),
    "Adventurers": ("The Adventurers' Guild", "Sellswords, monster-hunters and the companies that hire them out."),
    "Arcanists": ("The Arcanists' Guild", "Mages, their colleges and their towers."),
}
ROLE_OF_OCCUPATION = {"Merchant": "Merchants", "Caravan master": "Merchants", "Mercenary": "Adventurers",
                      "Arcanist": "Arcanists", "Scholar": "Arcanists"}


def guild_role(world, building) -> str:
    """Which guild a guild hall belongs to: by who works there, else by its name."""
    for nid in building.fields.get("npcs") or []:
        npc = world.entities.get(nid)
        role = ROLE_OF_OCCUPATION.get((npc.fields.get("occupation") or "") if npc is not None else "")
        if role:
            return role
    name = building.name.lower()
    if any(w in name for w in ("merchant", "trader", "trade")):
        return "Merchants"
    if any(w in name for w in ("college", "tower", "arcan", "mage", "wizard")):
        return "Arcanists"
    return "Adventurers"


def temple_god(building) -> str:
    """The god a temple or shrine is sacred to, from its name ("Chapel of the Dawnfather")."""
    name = building.name
    if " of " in name:
        return name.split(" of ", 1)[1].strip()
    return name.strip()


def _signature(world) -> list:
    s = world.entities
    return [VERSION, s.count("town"), s.count("region"), s.count("building"), s.count("faction")]


def ensure(world) -> int:
    """Make the factions this world is missing. Quick when nothing has changed. Returns how many were made."""
    sig = _signature(world)
    if world.meta.get("factions_sig") == sig:
        return 0
    from game import progress
    store = world.entities
    made = 0
    taken = {f.name.lower() for f in store.all("faction")}

    def new(name: str, fields: dict, description: str) -> object:
        nonlocal made
        base, k = name, 2
        while name.lower() in taken:
            name = f"{base} ({k})"
            k += 1
        taken.add(name.lower())
        made += 1
        return store.create("faction", name, fields, description, ["Faction"], save=False)

    idx = index(world)
    realms = {}
    for rn in realm_names(world):
        f = idx["realm"].get(rn.lower())
        if f is None:
            f = new(rn, {"kind": "Realm", "realm": rn}, f"The realm of {rn}: its lords, laws and soldiers.")
        realms[rn.lower()] = f
    towns = store.all("town")
    for i, t in enumerate(towns):
        if i % 100 == 0:
            progress.report(i / max(1, len(towns)), "Founding factions")
        if idx["town"].get(t.id) is not None or t.fields.get("settlement"):
            continue
        rn = _realm_name_of_town(world, t)
        parent = realms.get(rn.lower()) if rn else None
        new(t.name, {"kind": "Town", "town": t.id, "realm": rn or "", "parent": parent.id if parent else None},
            f"The people of {t.name}, and its watch.")
    roles, gods = set(), {}
    for b in store.all("building"):
        kind = b.fields.get("kind") or ""
        if kind == "Guild hall":
            if idx["hall"].get(b.name.lower()) is None:
                roles.add(guild_role(world, b))
        elif kind == "Temple":
            g = temple_god(b)
            if g:
                gods.setdefault(g.lower(), g)
    for role in sorted(roles):
        if idx["guild"].get(role) is None:
            name, blurb = GUILDS[role]
            new(name, {"kind": "Guild", "guild_of": role}, blurb)
    for g in sorted(gods.values()):
        if idx["god"].get(g.lower()) is None:
            new(f"The Faithful of {g}", {"kind": "Temple", "god": g},
                f"Those who keep the temples and shrines of {g}.")
    # criminals: bandits and smugglers in every realm, a thieves' guild in every city
    for rn in realm_names(world) + [""]:
        where = (rn if rn.lower().startswith("the ") else f"the {rn}") if rn else "the Wilds"
        realm = realms.get(rn.lower()) if rn else None
        for what, blurb in (("Bandits", "Robbers who prey on the roads"), ("Smugglers", "Smugglers who move "
                                                                       "what the law forbids")):
            key = f"{what} of {where}".lower()
            if idx["criminal"].get(key) is None:
                new(f"{what} of {where}", {"kind": "Criminal", "realm": rn,
                                            "rivals": [realm.id] if realm else []},
                    f"{blurb} in {where}.")
    for t in towns:
        if (t.fields.get("kind") or "") not in ("City", "Capital") or t.fields.get("settlement"):
            continue
        if idx["thieves"].get(t.id) is not None:
            continue
        own = index(world)["town"].get(t.id)
        new(f"The {t.name} Thieves' Guild", {"kind": "Criminal", "town": t.id,
                                             "realm": _realm_name_of_town(world, t) or "",
                                             "rivals": [own.id] if own else []},
            f"The thieves, fences and cutpurses of {t.name}.")
    if made:
        store.save("faction")
    world.meta["factions_sig"] = _signature(world)
    world.save_meta()
    return made


def _realm_name_of_town(world, town) -> str:
    rid = town.fields.get("region_ref")
    r = world.entities.get(rid) if rid else None
    if r is not None and (r.fields.get("realm") or "").strip():
        return r.fields["realm"].strip()
    text = (town.fields.get("region") or "").strip()
    if text and text.lower() in {n.lower() for n in realm_names(world)}:
        return text
    return ""


# ======================================================================
# Finding them
# ======================================================================
def index(world) -> dict:
    """Lookups by what a faction is about (cached until factions change)."""
    def build(factions):
        out = {"realm": {}, "town": {}, "hall": {}, "god": {}, "guild": {}, "criminal": {}, "thieves": {},
               "rivals": {}, "allies": {}}
        for f in factions:
            fl = f.fields
            kind = fl.get("kind") or "Other"
            if kind == "Realm" and fl.get("realm"):
                out["realm"].setdefault(fl["realm"].lower(), f)
            elif kind == "Town" and fl.get("town"):
                out["town"].setdefault(fl["town"], f)
            elif kind == "Guild" and fl.get("guild_of"):
                out["guild"].setdefault(fl["guild_of"], f)
            elif kind == "Temple" and fl.get("god"):
                out["god"].setdefault(fl["god"].lower(), f)
            elif kind == "Criminal":
                if fl.get("town"):
                    out["thieves"].setdefault(fl["town"], f)
                out["criminal"].setdefault(f.name.lower(), f)
            for hall in fl.get("building_names") or []:
                out["hall"].setdefault(str(hall).lower(), f)
            for other in fl.get("rivals") or []:          # rivalry and alliance work both ways
                out["rivals"].setdefault(f.id, set()).add(other)
                out["rivals"].setdefault(other, set()).add(f.id)
            for other in fl.get("allies") or []:
                out["allies"].setdefault(f.id, set()).add(other)
                out["allies"].setdefault(other, set()).add(f.id)
        return out
    return world.entities.custom_index("faction", "factions", build)


def get(world, faction_id: str):
    f = world.entities.get(faction_id) if faction_id else None
    return f if f is not None and f.type == "faction" else None


def realm_of_town(world, town):
    if town is None:
        return None
    rn = _realm_name_of_town(world, town)
    return index(world)["realm"].get(rn.lower()) if rn else None


def town_faction(world, town):
    if town is None:
        return None
    own = get(world, town.fields.get("faction"))
    return own or index(world)["town"].get(town.id)


def building_factions(world, building) -> list:
    """The factions a building belongs to besides its town (a temple's faithful, a guild)."""
    if building is None:
        return []
    own = get(world, building.fields.get("faction"))
    if own is not None:
        return [own]
    idx = index(world)
    out = []
    hall = idx["hall"].get(building.name.lower())
    if hall is not None:
        out.append(hall)
    elif (building.fields.get("kind") or "") == "Guild hall":
        g = idx["guild"].get(guild_role(world, building))
        if g is not None:
            out.append(g)
    if (building.fields.get("kind") or "") == "Temple":
        g = idx["god"].get(temple_god(building).lower())
        if g is not None:
            out.append(g)
    return out


def npc_factions(world, npc) -> list[tuple[object, float]]:
    """[(faction, weight)]: where they work first, then their town and its realm."""
    if npc is None:
        return []
    store = world.entities
    out: list[tuple[object, float]] = []
    seen = set()

    def add(f, w):
        if f is not None and f.id not in seen:
            seen.add(f.id)
            out.append((f, w))
    add(get(world, npc.fields.get("faction")), WEIGHTS["own"])
    b = store.get(npc.fields.get("building") or "")
    for f in building_factions(world, b):
        add(f, WEIGHTS["work"])
    town = store.get(npc.fields.get("town") or "") or (store.get(b.fields.get("town") or "") if b else None)
    add(town_faction(world, town), WEIGHTS["town"])
    add(realm_of_town(world, town), WEIGHTS["realm"])
    return out


def primary(world, npc):
    """The faction an NPC acts for first (their own, then where they work, then their town)."""
    got = npc_factions(world, npc)
    return got[0][0] if got else None


# ======================================================================
# Reading standing
# ======================================================================
def start_of(world, faction_id: str) -> int:
    f = get(world, faction_id)
    return int((f.fields.get("start") if f is not None else 0) or 0)


def standing(world, state, faction_id: str) -> int:
    v = state.reputation.get(faction_id)
    return int(v) if v is not None else start_of(world, faction_id)


def level(world, state, faction_id: str) -> str:
    return level_name(standing(world, state, faction_id))


def met(world, state) -> list:
    """The factions the party has dealings with, by standing (best first)."""
    out = [f for f in (get(world, fid) for fid in state.reputation) if f is not None]
    return sorted(out, key=lambda f: (-standing(world, state, f.id), f.name.lower()))


def npc_standing(world, state, npc) -> int:
    """The party's standing with an NPC's factions, weighted (where they work counts most)."""
    got = npc_factions(world, npc)
    if not got:
        return 0
    total = sum(w for _f, w in got)
    return int(round(sum(standing(world, state, f.id) * w for f, w in got) / total))


def attitude(world, state, npc) -> str:
    """How an NPC treats the party: their own feelings (Friendly, Neutral, Wary, Hostile) moved by the
    party's standing with their factions. Someone the party attacked stays Hostile."""
    if state is None:
        return npc.fields.get("disposition") or "Neutral"
    personal = state.disposition(npc)
    if personal == "Hostile":
        return "Hostile"
    score = PERSONAL.get(personal, 0) + npc_standing(world, state, npc)
    if score <= -40:
        return "Hostile"
    if score <= -10:
        return "Wary"
    if score >= 15:
        return "Friendly"
    return "Neutral"


# ======================================================================
# Changing standing
# ======================================================================
def meet(world, state, faction_id: str) -> bool:
    """Note a faction as known (at its starting standing). True if it's new."""
    if not faction_id or faction_id in state.reputation or get(world, faction_id) is None:
        return False
    state.reputation[faction_id] = start_of(world, faction_id)
    return True


def meet_town(world, state, town) -> None:
    """Arriving in a town: its people and its realm become known."""
    new = False
    for f in (town_faction(world, town), realm_of_town(world, town)):
        if f is not None:
            new = meet(world, state, f.id) or new
    if new:
        state.save()


def change(world, state, faction_id: str, amount: int, reason: str = "", bus=None) -> list[dict]:
    """The one way standing moves. Part of the change spreads: up to the faction it's part of, half to
    its allies, and half the other way to its rivals. Returns what changed."""
    f = get(world, faction_id)
    amount = int(amount)
    if f is None or amount == 0:
        return []
    idx = index(world)
    moves: dict[str, int] = {f.id: amount}

    def add(fid, n):
        if fid and n and get(world, fid) is not None:
            moves[fid] = moves.get(fid, 0) + n
    parent = f.fields.get("parent")
    if parent:
        add(parent, _part(amount, float(f.fields.get("share_up", 25) or 0) / 100.0))
    for fid in idx["allies"].get(f.id, ()):
        add(fid, _part(amount, 0.5))
    for fid in idx["rivals"].get(f.id, ()):
        add(fid, -_part(amount, 0.5))
    out = []
    for fid, n in moves.items():
        if n == 0:
            continue
        before = standing(world, state, fid)
        after = max(MIN, min(MAX, before + n))
        state.reputation[fid] = after
        if after != before:
            g = get(world, fid)
            out.append({"faction": fid, "name": g.name, "change": after - before, "standing": after,
                        "level": level_name(after), "was": level_name(before),
                        "main": fid == f.id})
    state.save()
    if out and bus is not None:
        bus.emit("reputation.changed", changes=out, reason=reason)
        main = next((c for c in out if c["main"]), out[0])
        text = f"Standing with {main['name']}: {main['change']:+d} ({main['level']})"
        if reason:
            text += f", {reason}"
        others = [c for c in out if not c["main"]]
        if others:
            text += ". Also " + ", ".join(f"{c['name']} {c['change']:+d}" for c in others[:4])
        bus.emit("log", kind="system", text=text + ".")
        for c in out:
            if c["level"] != c["was"]:
                bus.emit("log", kind="quest", text=f"Your standing with {c['name']} is now {c['level']}.")
    return out


def _part(amount: int, share: float) -> int:
    """A share of a change, rounded away from zero so small deeds still spread a little."""
    if share <= 0:
        return 0
    v = amount * share
    n = int(abs(v) + 0.5)
    if n == 0 and abs(v) >= 0.25:
        n = 1
    return n if v > 0 else -n


# ======================================================================
# Deeds that count already
# ======================================================================
def quest_done(world, state, quest: dict, bus=None) -> list[dict]:
    """A finished quest: the giver's faction thinks better of the party."""
    npc = world.entities.get(quest.get("giver") or "")
    f = primary(world, npc) if npc is not None else None
    if f is None:
        return []
    return change(world, state, f.id, QUEST_DONE, f"for {quest.get('title') or 'a job done'}", bus)


def harmed(world, state, victim, killed: bool, bus=None) -> list[dict]:
    """The party hurt or killed someone: their faction remembers."""
    f = primary(world, victim) if victim is not None and victim.type == "npc" else None
    if f is None:
        return []
    return change(world, state, f.id, KILLED if killed else HURT,
                  f"for {'killing' if killed else 'attacking'} {victim.name}", bus)


__all__ = ["ensure", "change", "standing", "level", "level_name", "attitude", "npc_factions", "primary",
           "meet", "meet_town", "met", "town_faction", "realm_of_town", "building_factions", "npc_standing",
           "quest_done", "harmed", "LEVELS", "LEVEL_NAMES"]
