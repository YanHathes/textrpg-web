"""What the party owns in one playthrough, kept in the save (<world>/holdings.json), never in the world.

The world holds what every playthrough shares: the land, the towns, their buildings and people. What the
player makes or buys belongs to one playthrough, so two saves in the same world can each own a different
house, and neither sees the other's.

    buildings     the party's own buildings (bought or built), with their room layouts. They're put into
                  the entity store as save-owned entities, so towns, the walking map and the places menu
                  see them like any other building, but the store never writes them to the world's files.
    claims        land the party has bought or staked                         (filled in later steps)
    settlements   the party's own settlements and their settlers
    jobs          construction and crafting under way
    workers       hired workers and automatons, and where they work
    vehicles      mounts, carts and boats, and what's stored in each
    bank          accounts, loans, and the vaults the party has emptied
    routes        trade routes run by hired crews (game/trade.py)
    reports       what came of them since the party last looked
    estate        what the party's buildings have made and earned, and what's owed (game/estate.py)

Saves made before this file existed had their bought houses in the world itself. The first time such a
game is opened, those houses move into the running game's holdings (and into any save slot that has no
holdings yet, since every one of them could see the house before).
"""
from __future__ import annotations

import json
from pathlib import Path

from game.entities import Entity

FILE = "holdings.json"
FORMAT = 1
SECTIONS = {"claims": list, "settlements": list, "jobs": list, "workers": list, "vehicles": list, "bank": dict,
            "routes": list, "reports": list, "estate": dict,
            "parked": dict}             # where the party got down and left its mount (game/animals.py park)


def empty() -> dict:
    return {k: f() for k, f in SECTIONS.items()}


def path(world) -> Path:
    return Path(world.path) / FILE


def load(world, state) -> None:
    """Read the running game's holdings and put its buildings into the entity store."""
    store = world.entities
    store.overlay_hook = None
    store.clear_overlay()
    state.holdings = empty()
    p = path(world)
    data = None
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            data = None
    if data is not None:
        for k, f in SECTIONS.items():
            v = data.get(k)
            state.holdings[k] = v if isinstance(v, f) else f()
        for raw in data.get("buildings") or []:
            try:
                store.add_overlay(Entity.from_dict(raw))
            except (KeyError, TypeError):
                continue
    store.overlay_hook = lambda: save(world, state)
    if data is None:
        _migrate(world, state)
    from game import landchanges
    landchanges.forget_all(world, state)   # chunks built for another save may show its changes
    wa = getattr(world, "_world_area", None)
    if wa is not None:                     # another save's claims and lots leave the walking map
        try:
            wa.drop_claims()
            wa.refresh_towns()
        except Exception:  # noqa: BLE001
            pass
    from game import area as A
    A.forget()
    if state.holdings.get("settlements"):          # the party's own settlements (game/colony.py)
        try:
            from game import colony
            colony.sync(world, state)
        except Exception:  # noqa: BLE001
            import traceback
            traceback.print_exc()
    else:
        from game import places
        places.EXTRA_ROADS.clear()


def save(world, state) -> None:
    payload = {"format": FORMAT,
               "buildings": [e.to_dict() for e in world.entities.overlay_entities()],
               **(getattr(state, "holdings", None) or empty())}
    p = path(world)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)


def buildings(world) -> list:
    return [e for e in world.entities.overlay_entities() if e.type == "building"]


def owns(world, entity_id: str) -> bool:
    return world.entities.is_overlay(entity_id)


def _migrate(world, state) -> None:
    """Houses bought before holdings existed live in the world: hand them to this playthrough."""
    store = world.entities
    owned = [b for b in store.having("building", "owner") if b.fields.get("owner") and not store.is_overlay(b.id)]
    if not owned:
        return
    for b in owned:
        store._overlay.add(b.id)
    store.save("building")                 # writes the world without them, and (via the hook) holdings.json
    if not path(world).exists():
        save(world, state)
    from game import saves
    root = saves.folder(world)
    if root.exists():
        for d in root.iterdir():
            if d.is_dir() and (d / "meta.json").exists() and not (d / FILE).exists():
                (d / FILE).write_text(path(world).read_text(encoding="utf-8"), encoding="utf-8")


__all__ = ["load", "save", "buildings", "owns", "empty", "FILE", "SECTIONS"]
