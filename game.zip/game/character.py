"""Player characters: what a party member is made of, turning one into fighting numbers,
and levelling up.

A party member (saved in party.json) looks like this:
    {"id", "name", "race", "subrace", "background",
     "classes": [{"class": id, "level": n, "subclass": id}],     # first one is the starting class
     "scores": {"str": 15, ...},          # base scores, before race and improvements
     "bonus_choices": {"str": 2, ...},    # racial bonuses placed by hand (when the world allows it)
     "skills": [skill ids], "spells": [spell ids], "feats": [feature ids],
     "asi": [{"level": 4, "class": id, "stats": {"str": 2}} or {"level": 4, "class": id, "feat": id}],
     "hp_rolls": [hit points gained at each level after the first, before CON],
     "xp": 0, "inventory": {item id: count}, "equipment": {slot: item id}, "attuned": [item ids],
     "look": {...}, "dead": False, "made": True,
     "choices": {feature id: [chosen feature / skill / spell ids]},   # Fighting Style, Expertise...
     "prepared": [spell ids],             # prepared casters and wizards
     "charges": {item id: charges left}}
Older members ("class" and "level" only) still work.

Features know which class level they came from (Ki = monk level, Sneak Attack by rogue level),
so formulas and Scaling tables use the class level, not the character level.

Mana and Stamina (world rule magic_system = "Mana"): a character whose class casts spells has
Mana = 10 x their spellcasting ability score; everyone else has Stamina = 10 x Constitution.
A spell costs 10 Mana per level it's cast at (cantrips are free) and can only be cast at levels
the character has spell slots for. Features can cost Mana/Stamina too.
"""
from __future__ import annotations

import random
import re

from game import dice, formula
from game.combat import builders as B
from game.combat import features as F
from game.combat.engine import PLAYER, Combatant
from game.constants import SIZES

XP_TABLE = [0, 300, 900, 2700, 6500, 14000, 23000, 34000, 48000, 64000, 85000, 100000, 120000, 140000, 165000,
            195000, 225000, 265000, 305000, 355000]

# Spell slots by caster level (SRD multiclass spellcaster table)
FULL_SLOTS = {
    1: [2], 2: [3], 3: [4, 2], 4: [4, 3], 5: [4, 3, 2], 6: [4, 3, 3], 7: [4, 3, 3, 1], 8: [4, 3, 3, 2],
    9: [4, 3, 3, 3, 1], 10: [4, 3, 3, 3, 2], 11: [4, 3, 3, 3, 2, 1], 12: [4, 3, 3, 3, 2, 1],
    13: [4, 3, 3, 3, 2, 1, 1], 14: [4, 3, 3, 3, 2, 1, 1], 15: [4, 3, 3, 3, 2, 1, 1, 1], 16: [4, 3, 3, 3, 2, 1, 1, 1],
    17: [4, 3, 3, 3, 2, 1, 1, 1, 1], 18: [4, 3, 3, 3, 3, 1, 1, 1, 1], 19: [4, 3, 3, 3, 3, 2, 1, 1, 1],
    20: [4, 3, 3, 3, 3, 2, 2, 1, 1]}
PACT_SLOTS = {1: (1, 1), 2: (2, 1), 3: (2, 2), 4: (2, 2), 5: (2, 3), 6: (2, 3), 7: (2, 4), 8: (2, 4), 9: (2, 5),
              10: (2, 5), 11: (3, 5), 12: (3, 5), 13: (3, 5), 14: (3, 5), 15: (3, 5), 16: (3, 5), 17: (4, 5),
              18: (4, 5), 19: (4, 5), 20: (4, 5)}
POINT_BUY_COST = {8: 0, 9: 1, 10: 2, 11: 3, 12: 4, 13: 5, 14: 7, 15: 9}
POINT_BUY_TOTAL = 27
STANDARD_ARRAY = [15, 14, 13, 12, 10, 8]


# ======================================================================
# Reading a member
# ======================================================================
def classes_of(world, m: dict) -> list[tuple]:
    """[(class entity, level, subclass entity or None)] in the order they were taken."""
    rows = m.get("classes")
    if not rows and m.get("class"):
        rows = [{"class": m["class"], "level": int(m.get("level") or 1)}]
    out = []
    for r in rows or []:
        k = world.entities.get(r.get("class"))
        if k is not None:
            out.append((k, max(1, int(r.get("level") or 1)), world.entities.get(r.get("subclass") or "")))
    return out


def total_level(world, m: dict) -> int:
    rows = classes_of(world, m)
    return max(1, sum(lv for _k, lv, _s in rows)) if rows else max(1, int(m.get("level") or 1))


def normalize(world, m: dict) -> dict:
    """Fill in the newer fields for an older member (keeps everything already there)."""
    m = dict(m)
    if not m.get("classes") and m.get("class"):
        m["classes"] = [{"class": m["class"], "level": int(m.get("level") or 1), "subclass": ""}]
    m.setdefault("classes", [])
    m["level"] = total_level(world, m) if m["classes"] else int(m.get("level") or 1)
    if m["classes"]:
        m["class"] = m["classes"][0]["class"]
    for key, empty in (("skills", []), ("feats", []), ("asi", []), ("hp_rolls", []), ("inventory", {}),
                       ("equipment", {}), ("attuned", []), ("bonus_choices", {}), ("choices", {}),
                       ("prepared", []), ("charges", {})):
        m.setdefault(key, empty if not isinstance(empty, (list, dict)) else type(empty)())
    m.setdefault("xp", XP_TABLE[min(19, m["level"] - 1)])
    inv = dict(m["inventory"])
    for item_id in (m.get("equipment") or {}).values():      # whatever is worn is carried
        if item_id and inv.get(item_id, 0) < sum(1 for i in m["equipment"].values() if i == item_id):
            inv[item_id] = sum(1 for i in m["equipment"].values() if i == item_id)
    m["inventory"] = inv
    return m


def races_of(world, m: dict) -> tuple:
    race = world.entities.get(m.get("race"))
    sub = world.entities.get(m.get("subrace") or "")
    if race is not None and race.fields.get("subrace_of"):        # a subrace picked as the race
        sub, race = race, world.entities.get(race.fields["subrace_of"]) or race
    return race, sub


def _stat_key(world, sid) -> str:
    s = world.entities.get(sid)
    return s.fields.get("key", "") if s else ""


def racial_bonuses(world, m: dict) -> dict[str, int]:
    if m.get("bonus_choices") and world.rules.get("flexible_racial_bonuses", True):
        return {k: int(v) for k, v in m["bonus_choices"].items() if v}
    out: dict[str, int] = {}
    for r in races_of(world, m):
        for row in ((r.fields.get("stat_modifiers") if r else None) or []):
            key = _stat_key(world, row.get("stat"))
            if key:
                out[key] = out.get(key, 0) + int(row.get("amount") or 0)
    return out


def base_scores(world, m: dict) -> dict[str, int]:
    keys = [s.fields.get("key") for s in world.entities.stats() if s.fields.get("key")]
    given = m.get("scores") or {}
    if given:
        return {k: int(given.get(k, 10)) for k in keys}
    # older members: the standard array, best scores where the class wants them
    rows = classes_of(world, m)
    primary = _stat_key(world, rows[0][0].fields.get("primary_stat")) if rows else ""
    order = [k for k in [primary, world.rules.get("hp_stat", "con"), world.rules.get("ranged_stat", "dex")] if k in keys]
    order += [k for k in keys if k not in order]
    return {k: STANDARD_ARRAY[i] if i < len(STANDARD_ARRAY) else 10 for i, k in enumerate(order)}


def attuned_ok(world, m: dict, item) -> bool:
    return not item.fields.get("requires_attunement") or item.id in (m.get("attuned") or [])


def final_scores(world, m: dict) -> dict[str, int]:
    scores = base_scores(world, m)
    for k, v in racial_bonuses(world, m).items():
        scores[k] = scores.get(k, 10) + v
    for a in m.get("asi") or []:
        for k, v in (a.get("stats") or {}).items():
            scores[k] = min(20, scores.get(k, 10) + int(v))
    for item_id in (m.get("equipment") or {}).values():
        item = world.entities.get(item_id)
        if item is None or not attuned_ok(world, m, item):
            continue
        for row in item.fields.get("stat_bonuses") or []:
            key = _stat_key(world, row.get("stat"))
            if key:
                scores[key] = min(30, scores.get(key, 10) + int(row.get("amount") or 0))
    # items that set a score (Gauntlets of Ogre Power: Strength 19) work after everything else
    for item_id in (m.get("equipment") or {}).values():
        item = world.entities.get(item_id)
        if item is None or not attuned_ok(world, m, item):
            continue
        for row in item.fields.get("stat_sets") or []:
            key = _stat_key(world, row.get("stat"))
            if key:
                scores[key] = max(scores.get(key, 10), int(row.get("value") or 0))
    return scores


def caster_stat(world, m: dict) -> str:
    """The spellcasting ability of the character's biggest spellcasting class ('' = none)."""
    best = None
    for k, lv, _s in classes_of(world, m):
        if k.fields.get("spellcasting") and (best is None or lv > best[1]):
            best = (k, lv)
    return _stat_key(world, best[0].fields.get("casting_stat")) if best else ""


def _slots_from_table(klass, level: int) -> dict[int, int]:
    rows = sorted((r for r in klass.fields.get("slots") or [] if int(r.get("level") or 0) <= level),
                  key=lambda r: int(r.get("level") or 0))
    out = {}
    if rows:
        for i, part in enumerate(str(rows[-1].get("slots") or "").split(","), start=1):
            try:
                if int(part.strip()) > 0:
                    out[i] = int(part.strip())
            except ValueError:
                pass
    return out


def spell_slots(world, m: dict) -> dict[int, int]:
    """Spell slots by level. One class: its own Slots table. Several: the SRD multiclass rules."""
    casters = [(k, lv) for k, lv, _s in classes_of(world, m) if k.fields.get("spellcasting")]
    if not casters:
        return {}
    if len(casters) == 1:
        own = _slots_from_table(*casters[0])
        if own:
            return own
    caster_level = 0
    pact = 0
    for k, lv in casters:
        kind = k.fields.get("caster_type") or "Full"
        if kind == "Full":
            caster_level += lv
        elif kind == "Half":
            caster_level += lv // 2
        elif kind == "Third":
            caster_level += lv // 3
        elif kind == "Pact":
            pact += lv
    slots = {i + 1: n for i, n in enumerate(FULL_SLOTS.get(min(20, caster_level), []))} if caster_level else {}
    if pact:
        n, lvl = PACT_SLOTS[min(20, pact)]
        slots[lvl] = slots.get(lvl, 0) + n
    return slots


def proficiencies(world, m: dict) -> tuple[set, set]:
    armor, weapons = set(), set()
    for k, _lv, _s in classes_of(world, m):
        armor |= set(k.fields.get("armor_proficiency") or [])
        weapons |= set(k.fields.get("weapon_proficiency") or [])
    return armor, weapons


def skill_ids(world, m: dict) -> set[str]:
    out = set(m.get("skills") or [])
    for r in races_of(world, m):
        out |= set((r.fields.get("skills") if r else None) or [])
    bg = world.entities.get(m.get("background") or "")
    if bg is not None:
        out |= set(bg.fields.get("skills") or [])
    out |= set(chosen(world, m, "Skill proficiency"))
    return out


def expertise_ids(world, m: dict) -> set[str]:
    return set(chosen(world, m, "Skill expertise"))


def chosen(world, m: dict, kind: str) -> list[str]:
    """Everything picked for features of one choice kind (only features the member still has)."""
    have = set(feature_sources(world, m)[0])
    out = []
    for fid, picks in (m.get("choices") or {}).items():
        f = world.entities.get(fid)
        if f is not None and fid in have and (f.fields.get("choice_kind") or "") == kind:
            out += [p for p in picks or [] if world.entities.get(p)]
    return list(dict.fromkeys(out))


def feature_sources(world, m: dict) -> tuple[list[str], dict, dict]:
    """(feature ids, {id: class level}, {id: item id}) for everything the member has: class and
    subclass features (by class level), chosen features, race, background, feats, and features
    granted by equipped (and attuned) items."""
    ids: list[str] = []
    levels: dict[str, int] = {}
    items: dict[str, str] = {}

    def add(fid, lv=0, item=""):
        if fid and fid not in levels and world.entities.get(fid) is not None:
            ids.append(fid)
            levels[fid] = lv
            if item:
                items[fid] = item

    for k, lv, sub in classes_of(world, m):
        for fid in B.class_features(k, lv):
            add(fid, lv)
        if sub is not None:
            for fid in B.class_features(sub, lv):
                add(fid, lv)
    for r in races_of(world, m):
        for fid in B.race_features(r):
            add(fid)
    bg = world.entities.get(m.get("background") or "")
    if bg is not None and bg.fields.get("feature"):
        add(bg.fields["feature"])
    for fid in list(m.get("feats") or []) + [a["feat"] for a in m.get("asi") or [] if a.get("feat")]:
        add(fid)
    for item_id in dict.fromkeys((m.get("equipment") or {}).values()):
        item = world.entities.get(item_id)
        if item is not None and attuned_ok(world, m, item):
            for fid in item.fields.get("features") or []:
                add(fid, 0, item.id)
    # chosen features (a Fighting Style...), which may offer choices of their own
    picks = m.get("choices") or {}
    for _round in range(3):
        grew = False
        for fid in list(ids):
            f = world.entities.get(fid)
            if f is None or (f.fields.get("choice_kind") or "") != "Features":
                continue
            for p in picks.get(fid) or []:
                if p not in levels and world.entities.get(p) is not None:
                    add(p, levels.get(fid, 0))
                    grew = True
        if not grew:
            break
    return ids, levels, items


def feature_ids(world, m: dict) -> list[str]:
    return feature_sources(world, m)[0]


# ======================================================================
# Choices (Fighting Style, Maneuvers, Expertise, Magical Secrets...)
# ======================================================================
def choice_need(feature, class_level: int) -> int:
    rows = sorted(feature.fields.get("choice_counts") or [], key=lambda r: int(r.get("level") or 1))
    if not rows:
        return 1
    need = 0
    for r in rows:
        if int(r.get("level") or 1) <= max(1, class_level):
            need = int(r.get("count") or 0)
    return need


def choice_options(world, m: dict, feature) -> list:
    kind = feature.fields.get("choice_kind") or ""
    opts = [e for e in (world.entities.get(i) for i in feature.fields.get("choice_options") or []) if e]
    if kind in ("Skill proficiency", "Skill expertise"):
        if not opts:
            opts = [s for s in world.entities.all("skill") if (s.fields.get("kind") or "Skill") in ("Skill", "Tool")]
        if kind == "Skill expertise":
            mine = skill_ids(world, m)
            opts = [s for s in opts if s.id in mine]
        else:
            mine = skill_ids(world, m) - set((m.get("choices") or {}).get(feature.id) or [])
            opts = [s for s in opts if s.id not in mine]
    return opts


def choices_for(world, m: dict) -> list[dict]:
    """Every choice the member's features offer: {"feature", "kind", "options", "need", "have"}."""
    ids, levels, _items = feature_sources(world, m)
    out = []
    for fid in ids:
        f = world.entities.get(fid)
        kind = (f.fields.get("choice_kind") or "") if f is not None else ""
        if not kind:
            continue
        lv = levels.get(fid) or total_level(world, m)
        have = [p for p in (m.get("choices") or {}).get(fid) or [] if world.entities.get(p)]
        out.append({"feature": f, "kind": kind, "options": choice_options(world, m, f), "need": choice_need(f, lv),
                    "have": have})
    return out


def pending_choices(world, m: dict) -> list[dict]:
    """Choices with picks still to make (never more than there are options)."""
    out = []
    for c in choices_for(world, m):
        available = len({o.id for o in c["options"]} | set(c["have"]))
        if len(c["have"]) < min(c["need"], available):
            out.append(c)
    return out


# ======================================================================
# Spellcasting styles
# ======================================================================
def casting_style(klass) -> str:
    return (klass.fields.get("casting_style") or "Known") if klass is not None else "Known"


def prepare_limit(world, m: dict, klass, class_level: int) -> int:
    scores = final_scores(world, m)
    mods = B.modifiers(world, scores)
    values = {"level": class_level, "class_level": class_level, "character_level": total_level(world, m),
              "casting_mod": mods.get(_stat_key(world, klass.fields.get("casting_stat")), 0)}
    for k, v in mods.items():
        values[f"{k}_mod"] = v
    values.update(scores)
    try:
        return max(1, int(formula.evaluate(klass.fields.get("prepare_count") or "max(1, casting_mod + level)", values)))
    except Exception:          # noqa: BLE001
        return 1


def class_spell_pool(world, klass, sub, top_level: int) -> tuple[list, list]:
    """(cantrips, levelled spells up to top_level) a class (and subclass) can draw on."""
    pool = [world.entities.get(i) for i in list(klass.fields.get("spells") or [])]
    pool = [s for s in pool if s is not None and s.type == "spell"]
    cantrips = [s for s in pool if int(s.fields.get("level") or 0) == 0]
    levelled = [s for s in pool if 0 < int(s.fields.get("level") or 0) <= top_level]
    return cantrips, levelled


def always_prepared(world, sub, top_level: int) -> list[str]:
    if sub is None:
        return []
    return [s.id for s in (world.entities.get(i) for i in sub.fields.get("spells") or [])
            if s is not None and int(s.fields.get("level") or 0) <= max(0, top_level)]


def prepared_for(world, m: dict, klass, sub, class_level: int) -> list[str]:
    """The prepared spells of one Prepared / Spellbook class (picked, or a sensible default)."""
    top = max(spell_slots(world, m) or {0: 0})
    _cantrips, levelled = class_spell_pool(world, klass, sub, top)
    if casting_style(klass) == "Spellbook":
        book = set(m.get("spells") or [])
        levelled = [s for s in levelled if s.id in book]
    allowed = {s.id for s in levelled}
    limit = prepare_limit(world, m, klass, class_level)
    picked = [i for i in m.get("prepared") or [] if i in allowed][:limit]
    if not picked and not m.get("prepared"):
        best = sorted(levelled, key=lambda s: (-int(s.fields.get("level") or 0), s.name))
        picked = [s.id for s in best[:limit]]
    return picked


def castable_spell_ids(world, m: dict) -> list[str]:
    """Every spell the member can cast now: per class, by its casting style, plus spells from choices."""
    known = list(m.get("spells") or [])
    top = max(spell_slots(world, m) or {0: 0})
    out: list[str] = []
    for k, lv, sub in classes_of(world, m):
        if not k.fields.get("spellcasting"):
            continue
        style = casting_style(k)
        cantrips, levelled = class_spell_pool(world, k, sub, top)
        if style == "Known":
            pool = [s.id for s in cantrips + levelled] + [i for i in (sub.fields.get("spells") if sub else None) or []]
            out += [s for s in pool if (not known or s in known)]
        else:
            mine = [s.id for s in cantrips if s.id in known] or ([] if known else [s.id for s in cantrips])
            out += mine + prepared_for(world, m, k, sub, lv) + always_prepared(world, sub, top)
    out += [s for s in known if world.entities.get(s) is not None and not _from_prepared_class(world, m, s)]
    out += chosen(world, m, "Spells")
    return list(dict.fromkeys(out))


def _from_prepared_class(world, m: dict, spell_id: str) -> bool:
    """A known spell id that's really a spellbook entry (not castable unless prepared)."""
    s = world.entities.get(spell_id)
    if s is None or int(s.fields.get("level") or 0) == 0:
        return False
    for k, _lv, _sub in classes_of(world, m):
        if k.fields.get("spellcasting") and casting_style(k) != "Known" and spell_id in (k.fields.get("spells") or []):
            return True
    return False


def max_hp(world, m: dict, con_mod: int) -> int:
    rows = classes_of(world, m)
    if not rows:
        return max(1, 8 + con_mod + (total_level(world, m) - 1) * (5 + con_mod))
    dice_by_level = []
    for k, lv, _s in rows:
        die = int(str(k.fields.get("hit_die") or "d8").lstrip("d") or 8)
        dice_by_level += [die] * lv
    first = dice_by_level[0]
    rolls = list(m.get("hp_rolls") or [])
    total = first
    for i, die in enumerate(dice_by_level[1:]):
        total += int(rolls[i]) if i < len(rolls) else die // 2 + 1
    return max(1, total + con_mod * len(dice_by_level))


def resources_for(world, m: dict, c) -> dict:
    """Class resource pools (Ki, Sorcery Points...) at full: name -> {"cur", "max", "recharge"}."""
    out: dict[str, dict] = {}
    for k, lv, sub in classes_of(world, m):
        for row in list(k.fields.get("resources") or []) + list((sub.fields.get("resources") if sub else None) or []):
            name = str(row.get("name") or "").strip()
            if not name or lv < int(row.get("from_level") or 1):
                continue
            probe = F.RFeature(id="", name=name, class_level=lv)
            top = max(0, F.fixed(c, probe, row.get("max") or "level"))
            have = out.get(name)
            if have is None or top > have["max"]:
                out[name] = {"cur": top, "max": top, "recharge": row.get("recharge") or "Long rest"}
    return out


def attunement_limit(world, m: dict) -> int:
    return int(getattr(build(world, m), "attune_max", 3) or 3)


def mana_for(world, m: dict, scores: dict) -> tuple[str, int]:
    """('Mana' or 'Stamina', maximum)."""
    if (world.rules.get("magic_system") or "Mana") != "Mana":
        return "", 0
    per = int(world.rules.get("mana_per_point", 10) or 10)
    stat = caster_stat(world, m)
    if stat:
        return "Mana", per * int(scores.get(stat, 10))
    return "Stamina", per * int(scores.get(world.rules.get("hp_stat", "con"), 10))


# ======================================================================
# Building the fighting numbers
# ======================================================================
def build(world, m: dict, team: str = PLAYER, potions: int = 0) -> Combatant:
    m = normalize(world, m)
    race, sub = races_of(world, m)
    rows = classes_of(world, m)
    level = total_level(world, m)
    prof = 2 + (level - 1) // 4
    scores = final_scores(world, m)
    mods = B.modifiers(world, scores)
    equipment = {k: v for k, v in (m.get("equipment") or {}).items() if world.entities.get(v)}
    unattuned = {i for i in equipment.values() if not attuned_ok(world, m, world.entities.get(i))}

    attacks, bonus_attacks = B._weapon_attacks(world, equipment, mods, prof, unattuned)
    armor_profs, weapon_profs = proficiencies(world, m)
    for a in attacks + bonus_attacks:
        item = world.entities.get(a.item_id)
        if item is not None and rows and (item.fields.get("weapon_kind") or "") not in weapon_profs:
            a.to_hit -= prof                                     # not trained with this weapon
    attacks.append(B.unarmed_strike(world, mods, prof))
    per_action = 1
    for k, lv, _s in rows:
        extra_at = int(k.fields.get("extra_attacks") or 0)
        if extra_at and lv >= extra_at:
            per_action = 2

    cast_key = caster_stat(world, m)
    spells = B._spells(world, castable_spell_ids(world, m))
    slots = spell_slots(world, m)
    cast_mod = mods.get(cast_key, 0)

    speed = int((sub.fields.get("speed") if sub and int(sub.fields.get("speed") or 30) != 30 else
                 (race.fields.get("speed") if race else 30)) or 30)
    size = (sub.fields.get("size") if sub and sub.fields.get("size") not in (None, "", "Medium") else
            (race.fields.get("size") if race else "Medium")) or "Medium"
    worn, shield, shield_ac = B.armor_worn(world, equipment)
    untrained = False
    stealth = False
    for item_id in equipment.values():
        item = world.entities.get(item_id)
        f = item.fields
        if f.get("category") == "Armor":
            if rows and (f.get("armor_type") or "Light") not in armor_profs:
                untrained = True
            if int(f.get("strength_req") or 0) > scores.get(world.rules.get("melee_stat", "str"), 10):
                speed -= 10
            stealth = stealth or bool(f.get("stealth_disadvantage"))
        if f.get("category") == "Shield" and rows and "Shields" not in armor_profs:
            untrained = True

    from game import inventory as INV
    load, slow = INV.encumbrance(world, m, scores.get(world.rules.get("melee_stat", "str"), 10))
    if slow:
        speed = 5 if slow <= -999 else speed + slow
    items = B._consumables(world, [i for i, n in (m.get("inventory") or {}).items() for _ in range(int(n))])
    if potions:
        potion = next((e for e in world.entities.all("item") if e.fields.get("category") == "Consumable"
                       and (e.fields.get("use_effect") or "Heal") == "Heal"), None)
        if potion:
            existing = next((x for x in items if x.item_id == potion.id), None)
            if existing:
                existing.count += potions
            else:
                from game.combat.engine import Consumable
                items.append(Consumable(potion.id, potion.name, "Heal", potion.fields.get("use_dice") or "2d4+2",
                                        potions, timing=B._timing(potion)))
    ammo = {}
    for item_id, n in (m.get("inventory") or {}).items():
        item = world.entities.get(item_id)
        if item is not None and item.fields.get("category") == "Ammunition":
            t = item.fields.get("ammo_type") or "Arrow"
            ammo[t] = ammo.get(t, 0) + int(n)

    con = mods.get(world.rules.get("hp_stat", "con"), 0)
    hp = max_hp(world, m, con)
    lb, ld = B._carried_light(world, equipment)
    mana_name, mana_max = mana_for(world, m, scores)
    skills = {s.name.lower() for s in (world.entities.get(i) for i in skill_ids(world, m)) if s}
    first = rows[0][0] if rows else None
    darkvision = max(int((r.fields.get("darkvision") if r else 0) or 0) for r in (race, sub))
    resist = set()
    for r in (race, sub):
        resist |= set((r.fields.get("resistances") if r else None) or [])
    c = Combatant(
        id=B._id(), name=m.get("name") or "Hero", team=team, hp=hp, max_hp=hp,
        ac=B.armor_class(world, equipment, mods, unattuned), speed=max(1, B._squares(max(5, speed))),
        size=SIZES.get(size, 1), stats=scores, mods=mods, prof=prof,
        saves={_stat_key(world, s) for s in ((first.fields.get("saving_throws") if first else None) or [])},
        attacks=attacks, attacks_per_action=per_action, bonus_attacks=bonus_attacks, spells=spells,
        spell_attack=prof + cast_mod, spell_dc=8 + prof + cast_mod, casting_stat=cast_key,
        slots=dict(slots), slots_max=dict(slots), items=items, resist=resist,
        init_bonus=mods.get(world.rules.get("initiative_stat", "dex"), 0), level=level,
        armor_worn=worn, has_shield=shield, shield_ac=shield_ac, darkvision=B._squares(darkvision),
        light_bright=lb, light_dim=ld, race_id=race.id if race else "", class_id=first.id if first else "",
        equipment=list(equipment.values()), mana=mana_max, mana_max=mana_max, mana_name=mana_name or "Mana",
        max_cast_level=max(slots) if slots else 0, ammo=ammo, armor_untrained=untrained, stealth_dis=stealth,
        skill_profs=skills,
    )
    c.encumbrance = load
    c.entity_id = f"party:{m.get('id', '')}"
    c.expertise = {s.name.lower() for s in (world.entities.get(i) for i in expertise_ids(world, m)) if s}
    ids, levels, sources = feature_sources(world, m)
    c.features = F.build_all(world, ids, c, levels, sources)
    c.resources = resources_for(world, m, c)
    F.apply_static(world, c)
    for item_id in dict.fromkeys(equipment.values()):
        item = world.entities.get(item_id)
        top = int(item.fields.get("charges") or 0) if item is not None else 0
        if top:
            c.charges[item_id] = max(0, min(top, int((m.get("charges") or {}).get(item_id, top))))
    extra_hp = sum(F.fixed(c, f, e.amount) for f in c.features if f.passive for e in f.effects
                   if e.kind == "Bonus hit points")
    if extra_hp:
        c.max_hp = c.base_max_hp = c.hp = c.max_hp + extra_hp
    return c


# ======================================================================
# Levelling
# ======================================================================
def level_for_xp(xp: int) -> int:
    lvl = 1
    for i, need in enumerate(XP_TABLE):
        if xp >= need:
            lvl = i + 1
    return min(20, lvl)


def xp_to_next(m: dict, world) -> int:
    lvl = total_level(world, m)
    return 0 if lvl >= 20 else XP_TABLE[lvl] - int(m.get("xp", 0))


def can_level_up(world, m: dict) -> bool:
    lvl = total_level(world, m)
    if m.get("dead") or lvl >= 20:
        return False
    if (world.rules.get("levelling") or "XP") == "Milestone":
        return int(m.get("pending_levels", 0)) > 0
    return int(m.get("xp", 0)) >= XP_TABLE[lvl]


def meets(world, m: dict, klass) -> bool:
    """Multiclass prerequisite (an empty one always passes)."""
    rule = (klass.fields.get("multiclass_requirement") or "").strip()
    if not rule:
        return True
    try:
        return bool(formula.evaluate(rule, final_scores(world, m)))
    except Exception:          # noqa: BLE001
        return True


def class_choices(world, m: dict) -> list:
    """Classes this member can take their next level in: their own, or (multiclassing) any
    other whose requirement they meet, if their first class's requirement is met too."""
    rows = classes_of(world, m)
    have = [k for k, _lv, _s in rows]
    out = list(have)
    if world.rules.get("multiclassing", True) and (not have or all(meets(world, m, k) for k in have)):
        out += [k for k in world.entities.all("class") if not k.fields.get("subclass_of") and k not in have
                and meets(world, m, k)]
    return out


def asi_levels(klass) -> set[int]:
    text = str(klass.fields.get("asi_levels") or "4, 8, 12, 16, 19")
    return {int(x) for x in re.findall(r"\d+", text)}


def subclasses_of(world, klass) -> list:
    return [k for k in world.entities.all("class") if k.fields.get("subclass_of") == klass.id]


def known_counts(klass, level: int) -> tuple[int | None, int | None]:
    """(cantrips, spells) known at this class level (None = no limit / no table).
    Spellbook classes: spells in the book. Prepared classes: no levelled spells to learn."""
    style = casting_style(klass)
    if style == "Spellbook":
        c, _s = _known_rows(klass, level)
        start = int(klass.fields.get("spellbook_start") or 6)
        per = int(klass.fields.get("spellbook_per_level") or 2)
        return c, start + per * max(0, level - 1)
    if style.startswith("Prepared"):
        c, _s = _known_rows(klass, level)
        return c, None
    return _known_rows(klass, level)


def _known_rows(klass, level: int) -> tuple[int | None, int | None]:
    def at(rows):
        best = None
        for r in sorted(rows or [], key=lambda r: int(r.get("level") or 1)):
            if int(r.get("level") or 1) <= level:
                best = int(r.get("count") or 0)
        return best
    return at(klass.fields.get("cantrips_known")), at(klass.fields.get("spells_known"))


def level_up_needs(world, m: dict, klass) -> dict:
    """What a level in `klass` asks the player to choose."""
    rows = classes_of(world, m)
    cur = next((lv for k, lv, _s in rows if k.id == klass.id), 0)
    new = cur + 1
    sub = next((s for k, _lv, s in rows if k.id == klass.id), None)
    needs = {"class": klass, "class_level": new, "total_level": total_level(world, m) + 1,
             "subclass": sub is None and int(klass.fields.get("subclass_level") or 3) <= new
             and bool(subclasses_of(world, klass)),
             "asi": new in asi_levels(klass), "new_features": [], "spells": 0, "cantrips": 0,
             "hit_die": int(str(klass.fields.get("hit_die") or "d8").lstrip("d") or 8)}
    before = set(B.class_features(klass, cur)) if cur else set()
    needs["new_features"] = [world.entities.get(i) for i in B.class_features(klass, new) if i not in before]
    needs["new_features"] = [f for f in needs["new_features"] if f is not None]
    if klass.fields.get("spellcasting"):
        c0, s0 = known_counts(klass, cur) if cur else (0, 0)
        c1, s1 = known_counts(klass, new)
        needs["cantrips"] = max(0, (c1 or 0) - (c0 or 0))
        needs["spells"] = max(0, (s1 or 0) - (s0 or 0))
    return needs


def apply_level_up(world, m: dict, klass, hp_gain: int, subclass_id: str = "", asi: dict | None = None,
                   feat_id: str = "", spells: list | None = None) -> dict:
    """Return the member after one level in `klass`. hp_gain is before CON."""
    m = normalize(world, m)
    rows = [dict(r) for r in m["classes"]]
    row = next((r for r in rows if r["class"] == klass.id), None)
    first_level = not rows
    if row is None:
        row = {"class": klass.id, "level": 0, "subclass": ""}
        rows.append(row)
    row["level"] += 1
    if subclass_id:
        row["subclass"] = subclass_id
    m["classes"] = rows
    if not first_level:
        m["hp_rolls"] = list(m.get("hp_rolls") or []) + [int(hp_gain)]
    if asi or feat_id:
        entry = {"level": row["level"], "class": klass.id}
        if feat_id:
            entry["feat"] = feat_id
        else:
            entry["stats"] = {k: int(v) for k, v in (asi or {}).items() if v}
        m["asi"] = list(m.get("asi") or []) + [entry]
    if spells:
        m["spells"] = list(dict.fromkeys(list(m.get("spells") or []) + list(spells)))
    if (world.rules.get("levelling") or "XP") == "Milestone":
        m["pending_levels"] = max(0, int(m.get("pending_levels", 0)) - 1)
    m["level"] = total_level(world, m)
    m["class"] = rows[0]["class"]
    return m


def roll_hp(klass, rng: random.Random | None = None) -> int:
    die = int(str(klass.fields.get("hit_die") or "d8").lstrip("d") or 8)
    return dice.roll(f"1d{die}", rng or random.Random()).total


def average_hp(klass) -> int:
    die = int(str(klass.fields.get("hit_die") or "d8").lstrip("d") or 8)
    return die // 2 + 1


# ======================================================================
# Creation helpers
# ======================================================================
def point_buy_cost(scores: dict) -> int:
    return sum(POINT_BUY_COST.get(int(v), 99) for v in scores.values())


def roll_scores(rng: random.Random | None = None) -> list[int]:
    """Six scores, each 4d6 dropping the lowest die."""
    rng = rng or random.Random()
    out = []
    for _ in range(6):
        d = sorted(rng.randint(1, 6) for _ in range(4))
        out.append(sum(d[1:]))
    return sorted(out, reverse=True)


def starting_gear(world, klass, choices: dict | None = None, background=None) -> tuple[dict, int]:
    """Items (id -> count) and gold from a class's starting equipment (with the picked choices)
    and a background."""
    items: dict[str, int] = {}
    for i in (klass.fields.get("starting_equipment") or []) if klass else []:
        item = world.entities.get(i)
        items[i] = items.get(i, 0) + (20 if item is not None and item.fields.get("category") == "Ammunition" else 1)
    groups: dict[int, list] = {}
    for idx, r in enumerate((klass.fields.get("equipment_choices") or []) if klass else []):
        groups.setdefault(int(r.get("group") or 1), []).append((idx, r))
    for g, opts in groups.items():
        pick = (choices or {}).get(g, opts[0][0])
        row = next((r for i, r in opts if i == pick), opts[0][1])
        for i in row.get("items") or []:
            n = int(row.get("count") or 1)
            item = world.entities.get(i)
            if item is not None and item.fields.get("category") == "Ammunition" and n == 1:
                n = 20                         # ammunition comes in bundles of 20
            items[i] = items.get(i, 0) + n
    gold = 0
    if background is not None:
        for i in background.fields.get("equipment") or []:
            items[i] = items.get(i, 0) + 1
        gold += int(background.fields.get("gold") or 0)
    return items, gold


def auto_equip(world, inventory: dict) -> dict:
    """Put the best of what's carried into the obvious slots."""
    eq = {}
    weapons, armor, shields = [], [], []
    for item_id in inventory:
        item = world.entities.get(item_id)
        if item is None:
            continue
        cat = item.fields.get("category")
        if cat == "Weapon":
            weapons.append(item)
        elif cat in ("Armor", "Clothing") and (item.fields.get("slot") or "Body") == "Body":
            armor.append(item)
        elif cat == "Shield":
            shields.append(item)
    if armor:
        eq["Body"] = max(armor, key=lambda i: int(i.fields.get("armor_class") or 0)).id
    melee = [w for w in weapons if "ranged" not in (w.fields.get("weapon_kind") or "").lower()]
    if melee or weapons:
        main = max(melee or weapons, key=lambda w: dice.average(w.fields.get("damage") or "1"))
        eq["Main hand"] = main.id
        if "two-handed" not in (main.fields.get("properties") or []):
            if shields:
                eq["Off hand"] = shields[0].id
            else:
                light = [w for w in melee if w is not main and "light" in (w.fields.get("properties") or [])]
                if light and "light" in (main.fields.get("properties") or []):
                    eq["Off hand"] = light[0].id
    return eq
