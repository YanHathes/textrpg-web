"""What the walking map says about where the party is (step 21): its status line and the hint under the
party. Shared by the Qt screens (ui/explore_screen.py) and the browser version (web/bridge.py), so both
always say the same."""
from __future__ import annotations

from game import explore as X


def status_bits(ex) -> tuple[list[str], list[str]]:
    """The walking map's status line: (where and when, then the date and weather too). The phone shows only
    the first, the desktop all of it."""
    from game import places
    st = ex.state
    spot = places.current(ex.world, st)
    bits = [spot.name or ""]
    if spot.kind == "building" and spot.building is not None and spot.name != spot.building.name:
        bits = [spot.building.name, spot.name]
    elif spot.kind == "street" and spot.town is not None:
        bits = [spot.town.name, spot.street]
    if ex.area is not None and ex.lv().floor_no:
        from game import rooms as R
        bits.append(R.floor_name(ex.lv().floor_no))
    bits.append(st.clock_text())
    short = [b for b in bits if b]
    from game import calendar as CAL
    bits.append(CAL.date_text(ex.world, st.minutes))
    if ex.area is None or ex.area.kind != "dungeon":
        try:
            bits.append(ex.weather().describe().capitalize())
        except Exception:  # noqa: BLE001 - no weather shown is better than no status line
            pass
    return short, [b for b in bits if b]


def hint_words(ex) -> str:
    """The hint under the party ("E   Talk to Mara"): what Interact would do here. E stands for whichever
    key or button it is (ui/explore_screen.py and the browser version put in the right one)."""
    if ex is None or ex.area is None:
        return ""
    mode = ex.travelling()
    if mode == "road":
        j = ex.state.journey or {}
        dest = ex.world.entities.get(j.get("to") or "")
        left = max(0.0, float(j.get("hours", 0)) - float(j.get("done", 0)))
        if ex.encounters:
            return "Something's coming!   Stand and fight, or walk off the road"
        return (f"On the road to {dest.name if dest else 'the next town'}  ·  {left:.1f} hours to go   "
                f"·   walk to leave the road")
    if mode == "trek":
        t = ex.state.trek or {}
        left = max(0, len(t.get("path") or []) - int(t.get("i") or 0))
        if ex.encounters:
            return "Something's coming!   Stand and fight, or walk away"
        return f"Crossing country  ·  {left} hex{'es' if left != 1 else ''} to go   ·   walk to stop"
    if mode == "voyage":
        j = ex.state.journey or {}
        dest = ex.world.entities.get(j.get("to") or "")
        left = max(0, int(j.get("days", 0)) - int(j.get("done", 0)))
        what = {"ship": "Sailing", "airship": "Flying", "wagon": "With the caravan"}.get(ex.vessel, "Travelling")
        return f"{what} to {dest.name if dest else 'port'}  ·  {left} day{'s' if left != 1 else ''} to go"
    c = ex.facing_cell()
    cells = [c] + [(ex.x + dx, ex.y + dy) for dx, dy in X.DIRS.values()]
    for cc in cells:
        t = ex.token_at(*cc)
        if t is not None and ex.shown(t):
            return f"E   {'Attack' if t.kind == 'enemy' else 'Talk to'} {t.name}"
    lv = ex.layer(*c)
    if c in lv.doors and not ex.secret_hidden(lv, c):
        d = lv.doors[c]
        if d.get("kind") == "exit":
            return "E   Leave"
        if d.get("barred"):
            return "Someone's house"
        return "E   Close the door" if ex.door_open(lv, c) else "E   Open the door"
    for cc in cells:
        l2 = ex.layer(*cc)
        st = l2.stations.get(cc)
        if st:
            if st["kind"] in ("sale_sign", "signpost", "claim_sign"):
                return "E   Read the sign"
            if st["kind"] == "shelf":
                return "E   Browse the bookshelf"
            return f"E   Use the {st['kind']}"
    here = ex.layer(ex.x, ex.y)
    if (ex.x, ex.y) in here.stairs:
        return "E   Take the stairs"
    return ""


__all__ = ["status_bits", "hint_words"]
