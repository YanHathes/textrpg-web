"""Checks as minigames: the rules of every game, with no Qt (ui/minigames/ draws them and passes the keys on).

How hard: the check's DC less the character's bonus is the natural roll they'd need (Spec.need, 2-20).
Each game reads that as d (0 easy .. 1 hard) and sets its speed, its targets and its time from it, so a
strong fighter finds the climbing game easier than a frail wizard does.

What comes out works like a roll: a game ends with a performance, perf (0..1). 0.5 is "just made it": the
natural roll is the one needed; every 0.05 over or under is one more or less. A perfect run is a natural 20,
a complete miss a natural 1. So "beat the DC by 5 or more" outcomes still work.

Every game draws itself as a short list of shapes on a 640 x 360 board (rect, frame, circle, line, text,
sprite) and takes simple inputs: "hit" (press and release), "left"/"right"/"up"/"down", "pick:<n>",
"lane:<n>", "point:<x>,<y>" and "stop". bot() plays it the way a person with some skill (0..1) might, so a
test can show that a better character succeeds more often at the same game.

Slow mode (Settings, for anyone who'd rather not race the clock) halves every speed and gives more time.
"""
from __future__ import annotations

import math
import random
import zlib
from dataclasses import dataclass, field

W, H = 640, 360
DT = 1 / 60
GOOD, BAD, ACCENT, DIM, INK, BG2 = "#7ec27a", "#d0604e", "#e8c060", "#59606a", "#e8e2d0", "#2a3038"


@dataclass
class Spec:
    game: str
    need: int = 11                 # the natural roll needed (DC - bonus), 2..20
    slow: bool = False
    seed: int = 0
    title: str = ""
    kind: str = ""                 # e.g. persuasion / deception / intimidation for the argument game
    extra: dict = field(default_factory=dict)

    @property
    def d(self) -> float:
        return max(0.0, min(1.0, (self.need - 2) / 18.0))


def natural_for(perf: float, need: int) -> int:
    """The d20 a performance stands for (see the module notes)."""
    if perf >= 0.995:
        return 20
    if perf <= 0.005:
        return 1
    return max(2, min(19, int(round(need + (perf - 0.5) * 20))))


def need_for(dc: int, bonus: int, mode: str = "normal") -> int:
    """The natural roll a check needs; advantage makes the game a few steps easier, disadvantage harder."""
    n = (dc - bonus) if dc else 11
    n += {"advantage": -3, "disadvantage": 3}.get(mode, 0)
    return max(2, min(20, n))


def _clamp(v, lo=0.0, hi=1.0):
    return lo if v < lo else hi if v > hi else v


class Game:
    id = ""
    title = ""
    help = ""
    limit = 20.0                   # seconds before it ends on its own
    holds = False                  # takes press and release (hold) rather than taps
    pad = ""                       # the buttons it needs on a touch screen (PADS): "lr", "ud", "arrows", "lanes"
    pad_hit = False                # and a Go button too (it steers and acts at once)

    def __init__(self, spec: Spec) -> None:
        self.spec = spec
        self.d = spec.d
        self.rng = random.Random(spec.seed * 7919 + zlib.crc32(self.id.encode()) % 1000)
        self.t = 0.0
        self.done = False
        self.perf = 0.0
        self.message = ""
        self.held: set = set()
        self._bot_at = None
        self.setup()
        if spec.slow:
            self.limit *= 1.6

    # ---- helpers
    def sp(self, v: float) -> float:
        """A speed, halved in slow mode."""
        return v * (0.5 if self.spec.slow else 1.0)

    def finish(self, perf: float, message: str = "") -> None:
        if not self.done:
            self.done = True
            self.perf = _clamp(perf)
            self.message = message

    @property
    def time_left(self) -> float:
        return max(0.0, 1.0 - self.t / self.limit)

    # ---- the loop
    def setup(self) -> None:
        pass

    def update(self, dt: float) -> None:
        if self.done:
            return
        self.t += dt
        self.step(dt)
        if not self.done and self.t >= self.limit:
            self.timeout()

    def step(self, dt: float) -> None:
        pass

    def timeout(self) -> None:
        self.finish(0.0, "Out of time.")

    def press(self, action: str) -> None:
        if action in ("hit", "left", "right", "up", "down"):
            self.held.add(action)
        if not self.done:
            self.on(action)

    def release(self, action: str) -> None:
        self.held.discard(action)

    def on(self, action: str) -> None:
        pass

    def draw(self) -> list:
        return []

    def boxes(self) -> list:
        """Where a click picks something: [(x, y, w, h, action)] on the board."""
        return []

    def bot(self, rng: random.Random, skill: float) -> list:
        """What a player of some skill does this frame: [("press"|"release", action)]."""
        return []

    # ---- shared bits of drawing
    @staticmethod
    def bar(x, y, w, h, frac, color=GOOD):
        return [("rect", x, y, w, h, BG2), ("rect", x, y, w * _clamp(frac), h, color), ("frame", x, y, w, h, DIM)]


# ======================================================================================================
# Timing: stop a moving marker in a zone
# ======================================================================================================
class _Sweep(Game):
    """A marker sweeping back and forth across 0..1; hit when it's in the zone. Several rounds possible."""
    rounds = 1
    limit = 10.0

    def setup(self) -> None:
        self.pos, self.dir = 0.0, 1
        self.speed = 0.55 + 1.5 * self.d
        self.half = 0.17 - 0.12 * self.d
        self.scores: list[float] = []
        self.new_zone()

    def new_zone(self) -> None:
        self.center = self.rng.uniform(0.25 + self.half, 0.92 - self.half)

    def step(self, dt):
        self.pos += self.dir * self.sp(self.speed) * dt
        if self.pos > 1:
            self.pos, self.dir = 2 - self.pos, -1
        elif self.pos < 0:
            self.pos, self.dir = -self.pos, 1

    def score_hit(self) -> float:
        dist = abs(self.pos - self.center)
        return _clamp(1 - dist / (2 * self.half))

    def on(self, action):
        if action != "hit":
            return
        self.scores.append(self.score_hit())
        if len(self.scores) >= self.rounds:
            self.finish(self.final())
        else:
            self.new_zone()
            self.speed *= 1.08

    def final(self) -> float:
        return sum(self.scores) / len(self.scores)

    def timeout(self):
        done = sum(self.scores)
        self.finish(done / self.rounds * 0.45, "Too slow.")

    def bot(self, rng, skill):
        out = []
        if self._bot_at is None:
            v = self.sp(self.speed) * self.dir
            ttc = (self.center - self.pos) / v if v else 99
            if 0 <= ttc < 0.6:
                err = rng.gauss(0, 0.02 + 0.13 * (1 - skill))
                self._bot_at = self.t + ttc + err
        elif self.t >= self._bot_at:
            self._bot_at = None
            out.append(("press", "hit"))
            out.append(("release", "hit"))
        return out

    def draw(self):
        x, y, w, h = 80, 200, 480, 34
        out = [("rect", x, y, w, h, BG2),
               ("rect", x + w * (self.center - self.half), y, w * 2 * self.half, h, "#3f6a3a"),
               ("rect", x + w * (self.center - self.half / 2), y, w * self.half, h, GOOD),
               ("frame", x, y, w, h, DIM),
               ("rect", x + w * self.pos - 3, y - 10, 6, h + 20, ACCENT)]
        if self.rounds > 1:
            out.append(("text", 320, 260, f"{len(self.scores) + 1} of {self.rounds}", 14, INK, "center"))
        return out


class Power(_Sweep):
    id, title = "power", "Strength"
    help = "Press when the power bar is in the green."


class Swing(_Sweep):
    id, title = "swing", "Swing"
    help = "Swing when the marker crosses the green: three good swings."
    rounds = 3
    limit = 16.0


class Hammer(_Sweep):
    id, title = "hammer", "At the bench"
    help = "Strike on the mark, again and again."
    limit = 20.0

    def setup(self):
        super().setup()
        self.rounds = 4 + int(3 * self.d)


class Cook(Game):
    id, title = "cook", "Cooking"
    help = "Take each dish off the heat when it's done (keys 1-3)."
    limit = 25.0

    def setup(self):
        n = 2 + (1 if self.d > 0.45 else 0)
        self.heat = [0.0] * n
        self.rate = [self.rng.uniform(0.1, 0.16) * (1 + 1.2 * self.d) for _ in range(n)]
        self.start = [i * (2.5 - 1.5 * self.d) for i in range(n)]
        self.zone = 0.09 - 0.055 * self.d
        self.result: list = [None] * n

    def step(self, dt):
        for i in range(len(self.heat)):
            if self.result[i] is None and self.t >= self.start[i]:
                self.heat[i] += self.sp(self.rate[i]) * dt
                if self.heat[i] >= 1.0:
                    self.result[i] = 0.0                       # burnt
        if all(r is not None for r in self.result):
            self.finish(sum(self.result) / len(self.result))

    def on(self, action):
        if action.startswith("pick:"):
            i = int(action[5:])
            if 0 <= i < len(self.heat) and self.result[i] is None and self.t >= self.start[i]:
                self.result[i] = _clamp(1 - abs(self.heat[i] - 0.8) / (2 * self.zone))
                if all(r is not None for r in self.result):
                    self.finish(sum(self.result) / len(self.result))

    def timeout(self):
        self.finish(sum(r or 0 for r in self.result) / len(self.result) * 0.6)

    def bot(self, rng, skill):
        out = []
        for i, h in enumerate(self.heat):
            if self.result[i] is None and self.t >= self.start[i]:
                if f"_t{i}" not in self.__dict__:
                    self.__dict__[f"_t{i}"] = 0.8 + self.rate[i] * rng.gauss(0, 0.06 + 0.3 * (1 - skill))
                if h >= self.__dict__[f"_t{i}"]:
                    out.append(("press", f"pick:{i}"))
        return out

    def boxes(self):
        return [(120 + i * 150, 90, 60, 200, f"pick:{i}") for i in range(len(self.heat))]

    def draw(self):
        out = []
        for i, h in enumerate(self.heat):
            x = 120 + i * 150
            out += [("rect", x, 90, 60, 200, BG2), ("rect", x, 90 + 200 * (1 - 0.8 - self.zone), 60, 400 * self.zone, "#3f6a3a"),
                    ("rect", x, 290 - 200 * min(1, h), 60, 200 * min(1, h), "#d08040" if h < 0.95 else BAD),
                    ("frame", x, 90, 60, 200, DIM), ("text", x + 30, 300, str(i + 1), 16, INK, "center")]
            r = self.result[i]
            if r is not None:
                out.append(("text", x + 30, 70, "burnt" if r == 0 else "done", 12, GOOD if r > 0.4 else BAD, "center"))
        return out


# ======================================================================================================
# Keeping something steady
# ======================================================================================================
class Balance(Game):
    id, title = "balance", "Balance"
    help = "Keep your balance: lean left and right to stay upright."
    pad = "lr"
    limit = 8.0

    def setup(self):
        self.a, self.v = 0.0, 0.0
        self.k = 1.4 + 3.2 * self.d
        self.gust = 0.6 + 1.8 * self.d
        self.centred = 0.0
        self._g = 0.0

    def step(self, dt):
        if self.rng.random() < dt * 0.8:
            self._g = self.rng.uniform(-1, 1) * self.gust
        push = (-3.2 if "left" in self.held else 0) + (3.2 if "right" in self.held else 0)
        acc = self.sp(self.k) * self.a + self.sp(self._g) + push
        self.v = (self.v + acc * dt) * (1 - 1.2 * dt)
        self.a += self.v * dt
        if abs(self.a) < 0.3:
            self.centred += dt
        if abs(self.a) >= 1:
            self.finish(self.t / self.limit * 0.45, "You fall.")

    def timeout(self):
        cf = self.centred / self.limit
        self.finish(0.5 + 0.5 * (cf - 0.6) / 0.4 if cf >= 0.6 else 0.5 * cf / 0.6)

    def bot(self, rng, skill):
        noise = rng.gauss(0, 0.1 + 0.5 * (1 - skill))
        lean = self.a + 0.45 * self.v + noise
        out = [("release", "left"), ("release", "right")]
        if lean > 0.08:
            out.append(("press", "left"))
        elif lean < -0.08:
            out.append(("press", "right"))
        return out

    def draw(self):
        cx, cy = 320, 270
        ang = self.a * 0.9
        x2, y2 = cx + math.sin(ang) * 150, cy - math.cos(ang) * 150
        return [("rect", 120, 272, 400, 6, DIM), ("line", cx, cy, x2, y2, ACCENT, 6),
                ("circle", x2, y2, 14, INK),
                ("text", 320, 320, "← / → to lean", 12, DIM, "center")]


class Endure(Game):
    id, title = "endure", "Hold on"
    help = "Keep the marker inside the window as it closes in (left / right)."
    pad = "lr"
    limit = 8.0

    def setup(self):
        self.v, self.vel = 0.5, 0.0
        self.end_half = 0.11 - 0.05 * self.d
        self.close = 0.0

    def half(self):
        return 0.32 - (0.32 - self.end_half) * min(1, self.t / self.limit)

    def step(self, dt):
        self.vel += self.rng.gauss(0, self.sp(2.5 + 3.0 * self.d)) * dt
        self.vel += (-1.6 if "left" in self.held else 0) * dt + (1.6 if "right" in self.held else 0) * dt
        self.vel *= (1 - 1.5 * dt)
        self.v += self.vel * dt
        off = abs(self.v - 0.5)
        self.close += (1 - off / max(0.01, self.half())) * dt
        if off > self.half():
            self.finish(self.t / self.limit * 0.45, "You let go.")

    def timeout(self):
        self.finish(0.5 + 0.5 * _clamp(self.close / self.limit))

    def bot(self, rng, skill):
        guess = self.v + 0.4 * self.vel + rng.gauss(0, 0.01 + 0.08 * (1 - skill))
        out = [("release", "left"), ("release", "right")]
        if guess > 0.52:
            out.append(("press", "left"))
        elif guess < 0.48:
            out.append(("press", "right"))
        return out

    def draw(self):
        x, w = 80, 480
        h = self.half()
        return [("rect", x, 190, w, 30, BG2), ("rect", x + w * (0.5 - h), 190, w * 2 * h, 30, "#3f6a3a"),
                ("frame", x, 190, w, 30, DIM), ("rect", x + w * self.v - 3, 180, 6, 50, ACCENT)]


class Steady(Game):
    id, title = "steady", "A steady hand"
    help = "Follow the path with a steady hand (up / down)."
    pad = "ud"
    limit = 8.0

    def setup(self):
        self.y, self.vy = 0.5, 0.0
        self.half = 0.12 - 0.065 * self.d
        self.ph = [self.rng.uniform(0, 6) for _ in range(3)]
        self.inside = 0.0

    def path(self, x):
        p = self.ph
        return 0.5 + 0.18 * math.sin(2.1 * x + p[0]) + 0.1 * math.sin(4.3 * x + p[1]) + 0.05 * math.sin(9 * x + p[2])

    def xnow(self):
        return self.t / self.limit * 3.0

    def step(self, dt):
        self.vy += ((-1.4 if "up" in self.held else 0) + (1.4 if "down" in self.held else 0)) * dt
        self.vy += self.rng.gauss(0, self.sp(0.8 + 2.4 * self.d)) * dt
        self.vy *= (1 - 4 * dt)
        self.y += self.vy * dt
        if abs(self.y - self.path(self.xnow())) <= self.half:
            self.inside += dt

    def timeout(self):
        frac = self.inside / self.limit
        self.finish(0.5 + 0.5 * (frac - 0.75) / 0.25 if frac >= 0.75 else 0.5 * frac / 0.75)

    def bot(self, rng, skill):
        ahead = self.path(self.xnow() + 0.12) + rng.gauss(0, 0.02 + 0.14 * (1 - skill))
        guess = self.y + 0.2 * self.vy
        out = [("release", "up"), ("release", "down")]
        if guess > ahead + 0.01:
            out.append(("press", "up"))
        elif guess < ahead - 0.01:
            out.append(("press", "down"))
        return out

    def draw(self):
        out = []
        x0 = self.xnow()
        for i in range(48):
            a, b = x0 - 0.6 + i * 0.05, x0 - 0.6 + (i + 1) * 0.05
            out.append(("line", 80 + i * 10, 40 + 280 * self.path(a), 80 + (i + 1) * 10, 40 + 280 * self.path(b),
                        "#3f6a3a", max(2, int(560 * self.half))))
        out.append(("circle", 80 + 12 * 10, 40 + 280 * self.y, 7, ACCENT))
        return out


# ======================================================================================================
# Meters to manage
# ======================================================================================================
class Pickpocket(Game):
    id, title = "pickpocket", "Sleight of hand"
    help = "Hold to reach in while they're not paying attention. Let go when they look."
    limit = 12.0
    holds = True

    def setup(self):
        self.att, self.progress = 0.3, 0.0
        self.w = 1.3 + 2.2 * self.d
        self.thr = 0.9 - 0.32 * self.d
        self.ph = self.rng.uniform(0, 6)

    def step(self, dt):
        self.att = _clamp(0.45 + 0.45 * math.sin(self.sp(self.w) * self.t + self.ph) +
                          0.25 * self.d * math.sin(3.7 * self.sp(self.w) * self.t) + self.rng.gauss(0, 0.03))
        if "hit" in self.held:
            self.progress += self.sp(0.42 - 0.2 * self.d) * dt
            if self.att > self.thr:
                self.finish(self.progress * 0.45, "Caught!")
                return
        if self.progress >= 1:
            self.finish(0.5 + 0.5 * self.time_left)

    def timeout(self):
        self.finish(self.progress * 0.45, "Too slow.")

    def bot(self, rng, skill):
        margin = 0.06 + 0.25 * (1 - skill) * rng.random()
        rising = math.cos(self.sp(self.w) * self.t + self.ph) > 0
        safe = self.att < self.thr - margin - (0.15 if rising else 0)
        return [("press", "hit")] if safe else [("release", "hit")]

    def draw(self):
        return ([("text", 320, 70, "Their attention", 13, INK, "center")] +
                self.bar(140, 90, 360, 22, self.att, BAD if self.att > self.thr else ACCENT) +
                [("rect", 140 + 360 * self.thr, 84, 2, 34, BAD), ("text", 320, 190, "Your hand", 13, INK, "center")] +
                self.bar(140, 210, 360, 22, self.progress, GOOD))


class Calm(Game):
    id, title = "calm", "Animal handling"
    help = "Soothe the animal when it gets restless (don't overdo it)."
    limit = 10.0

    def setup(self):
        self.mood, self.cool, self.total = 0.3, 0.0, 0.0

    def step(self, dt):
        self.mood += self.sp(0.04 + 0.13 * self.d) * dt + (self.rng.uniform(0.08, 0.2 + 0.22 * self.d)
                                                            if self.rng.random() < dt * (0.5 + 0.4 * self.d) else 0)
        self.cool = max(0.0, self.cool - dt)
        self.total += self.mood * dt
        if self.mood >= 1:
            self.finish(self.t / self.limit * 0.45, "It bolts!")

    def on(self, action):
        if action == "hit":
            if self.cool > 0:
                self.mood += 0.1                               # too much fuss
            else:
                self.mood = max(0.0, self.mood - 0.3)
                self.cool = 0.8

    def timeout(self):
        self.finish(0.5 + 0.5 * _clamp(1 - self.total / self.limit))

    def bot(self, rng, skill):
        if self.cool <= 0 and self.mood > 0.45 + rng.gauss(0, 0.2 * (1 - skill)):
            return [("press", "hit"), ("release", "hit")]
        if self.cool > 0 and rng.random() < 0.004 * (1 - skill):
            return [("press", "hit"), ("release", "hit")]
        return []

    def draw(self):
        return [("sprite", "animal", 270, 70, 100, 100), ("text", 320, 190, "Restless", 13, INK, "center")] + \
            self.bar(140, 210, 360, 22, self.mood, BAD if self.mood > 0.7 else ACCENT)


class Tension(Game):
    id, title = "tension", "Fishing"
    help = "Hold to reel in. Keep the line's tension in the green or it snaps."
    limit = 16.0
    holds = True

    def setup(self):
        self.tens, self.progress = 0.4, 0.0
        self.lo, self.hi = 0.3, 0.78 - 0.08 * self.d

    def step(self, dt):
        if "hit" in self.held:
            self.tens += self.sp(0.55) * dt
            if self.lo <= self.tens <= self.hi:
                self.progress += self.sp(0.24 - 0.08 * self.d) * dt
        else:
            self.tens -= self.sp(0.5) * dt
        if self.rng.random() < dt * (0.5 + self.d):
            self.tens += self.rng.uniform(0.04, 0.1 + 0.07 * self.d)
        self.tens = max(0.0, self.tens)
        if self.tens >= 1:
            self.finish(self.progress * 0.45, "The line snaps!")
        elif self.progress >= 1:
            self.finish(0.5 + 0.5 * self.time_left)

    def timeout(self):
        self.finish(self.progress * 0.45, "It gets away.")

    def bot(self, rng, skill):
        want = (self.lo + self.hi) / 2 + rng.gauss(0, 0.02 + 0.15 * (1 - skill))
        return [("press", "hit")] if self.tens < want else [("release", "hit")]

    def draw(self):
        x, w = 140, 360
        return ([("text", 320, 80, "Tension", 13, INK, "center"), ("rect", x, 100, w, 24, BG2),
                 ("rect", x + w * self.lo, 100, w * (self.hi - self.lo), 24, "#3f6a3a"),
                 ("rect", x + w * min(1, self.tens) - 3, 94, 6, 36, ACCENT), ("frame", x, 100, w, 24, DIM),
                 ("text", 320, 190, "Reeling in", 13, INK, "center")] + self.bar(x, 210, w, 22, self.progress))


# ======================================================================================================
# Moving at the right moment
# ======================================================================================================
class Sneak(Game):
    id, title = "sneak", "Stealth"
    help = "Step forward (right / space) only while nobody's looking."
    limit = 14.0

    def setup(self):
        self.limit = 17.0 - 4.0 * self.d
        self.n = 1 + int(2.2 * self.d)
        self.steps, self.goal, self.cool = 0, 8, 0.0
        self.looking = [False] * self.n
        self.until = [self.rng.uniform(1.0, 2.5) for _ in range(self.n)]
        self.warn = 0.45 - 0.3 * self.d

    def step(self, dt):
        self.cool = max(0.0, self.cool - dt)
        for i in range(self.n):
            if self.t >= self.until[i]:
                self.looking[i] = not self.looking[i]
                span = (self.rng.uniform(0.6, 1.6) if self.looking[i] else
                        self.rng.uniform(0.9 - 0.4 * self.d, 2.2 - 0.9 * self.d))
                self.until[i] = self.t + span / (0.5 if self.spec.slow else 1)

    def warning(self, i) -> bool:
        return not self.looking[i] and self.until[i] - self.t < self.warn

    def on(self, action):
        if action not in ("hit", "right") or self.cool > 0:
            return
        if any(self.looking):
            self.finish(self.steps / self.goal * 0.45, "Spotted!")
            return
        self.steps += 1
        self.cool = 0.22
        if self.steps >= self.goal:
            self.finish(0.5 + 0.5 * self.time_left)

    def timeout(self):
        self.finish(self.steps / self.goal * 0.45, "Too slow.")

    def bot(self, rng, skill):
        if self._bot_at is not None:                    # a step decided a moment ago (people react late)
            if self.t >= self._bot_at:
                self._bot_at = None
                return [("press", "right"), ("release", "right")]
            return []
        if self.cool > 0:
            return []
        careful = rng.random() > 0.3 * (1 - skill)
        safe = not any(self.looking) and (not careful or not any(self.warning(i) for i in range(self.n)))
        if safe and rng.random() < 0.15 + 0.4 * skill:
            self._bot_at = self.t + rng.uniform(0.1, 0.25) + 0.25 * (1 - skill)
        return []

    def draw(self):
        out = [("rect", 60, 250, 520, 6, DIM)]
        for i in range(self.n):
            x = 200 + i * 140
            col = BAD if self.looking[i] else (ACCENT if self.warning(i) else GOOD)
            out += [("sprite", "watcher", x - 24, 80, 48, 64), ("circle", x, 160, 10, col)]
        out.append(("circle", 70 + 500 * self.steps / self.goal, 240, 12, INK))
        return out


class Rhythm(Game):
    id, title = "rhythm", "Performance"
    help = "Play each note as it reaches the line (1-4 or the arrow keys)."
    pad = "lanes"
    limit = 24.0

    def setup(self):
        n = 14 + int(12 * self.d)
        beat = (0.62 - 0.22 * self.d) * (1.8 if self.spec.slow else 1.0)
        self.notes = [{"t": 2.0 + i * beat, "lane": self.rng.randrange(4), "score": None, "bot": None}
                      for i in range(n)]
        self.win = 0.17 - 0.09 * self.d
        self.limit = self.notes[-1]["t"] + 1.5

    def on(self, action):
        lane = {"lane:0": 0, "lane:1": 1, "lane:2": 2, "lane:3": 3, "left": 0, "down": 1, "up": 2, "right": 3}.get(action)
        if lane is None:
            return
        best = None
        for nt in self.notes:
            if nt["score"] is None and nt["lane"] == lane and abs(nt["t"] - self.t) <= self.win:
                if best is None or abs(nt["t"] - self.t) < abs(best["t"] - self.t):
                    best = nt
        if best is not None:
            best["score"] = 1.0 - abs(best["t"] - self.t) / self.win * 0.5

    def step(self, dt):
        for nt in self.notes:
            if nt["score"] is None and self.t - nt["t"] > self.win:
                nt["score"] = 0.0

    def timeout(self):
        acc = sum(nt["score"] or 0 for nt in self.notes) / len(self.notes)
        self.finish(0.5 + 0.5 * (acc - 0.65) / 0.35 if acc >= 0.65 else 0.5 * acc / 0.65)

    def bot(self, rng, skill):
        out = []
        for nt in self.notes:
            if nt["score"] is None and nt["bot"] is None and nt["t"] - self.t < 0.25:
                nt["bot"] = nt["t"] + rng.gauss(0, 0.02 + 0.12 * (1 - skill))      # when this player will press
            if nt["score"] is None and nt["bot"] is not None and 0 <= self.t - nt["bot"] < 1.0:
                if rng.random() < 0.75 + 0.25 * skill:
                    out.append(("press", f"lane:{nt['lane']}"))
                nt["bot"] = -1e9
        return out

    def draw(self):
        out = [("rect", 160, 300, 320, 4, ACCENT)]
        for lane in range(4):
            out.append(("rect", 170 + lane * 80, 30, 60, 274, BG2))
            out.append(("text", 200 + lane * 80, 330, str(lane + 1), 13, DIM, "center"))
        for nt in self.notes:
            y = 300 - (nt["t"] - self.t) * 160
            if -10 < y < 360 and nt["score"] is None:
                out.append(("rect", 172 + nt["lane"] * 80, y - 8, 56, 16,
                            ["#e06a6a", "#6ab0e0", "#e0c86a", "#8ae06a"][nt["lane"]]))
        return out


# ======================================================================================================
# Choosing right
# ======================================================================================================
class _Rounds(Game):
    """Several rounds, each a choice among a few options with one right answer."""
    rounds = 3
    per_round = 9.0

    def setup(self):
        self.round, self.correct, self.speed = 0, 0, []

        self.limit = self.rounds * self.sp_time(self.per_round)
        self.started = 0.0
        self.options: list[str] = []
        self.answer = 0
        self.last = ""
        self.new_round()

    def sp_time(self, s):
        return s * (1.0 - 0.45 * self.d) * (1.8 if self.spec.slow else 1.0)

    def required(self) -> int:
        return self.rounds - (1 if self.d < 0.35 else 0)

    def new_round(self):
        pass

    def on(self, action):
        if not action.startswith("pick:"):
            return
        i = int(action[5:])
        if not 0 <= i < len(self.options):
            return
        right = i == self.answer
        self.correct += right
        self.last = "Right." if right else "Wrong."
        self.speed.append(1 - (self.t - self.started) / self.sp_time(self.per_round))
        self.round += 1
        if self.round >= self.rounds or self.rounds - self.round + self.correct < self.required():
            self.end_rounds()
        else:
            self.started = self.t
            self.new_round()

    def step(self, dt):
        if self.t - self.started > self.sp_time(self.per_round):
            self.round += 1
            self.speed.append(0)
            self.last = "Too slow."
            if self.round >= self.rounds or self.rounds - self.round + self.correct < self.required():
                self.end_rounds()
            else:
                self.started = self.t
                self.new_round()

    def end_rounds(self):
        need = self.required()
        if self.correct >= need:
            extra = (self.correct - need) / max(1, self.rounds - need) if self.rounds > need else 1.0
            sp = sum(max(0, s) for s in self.speed) / max(1, len(self.speed))
            self.finish(0.5 + 0.5 * (0.5 * extra + 0.5 * sp))
        else:
            self.finish(0.5 * self.correct / max(1, need))

    def timeout(self):
        self.end_rounds()

    def bot(self, rng, skill):
        if self._bot_at is None:
            think = rng.uniform(0.6, 2.5) * (1.4 - skill) * (1 + 0.5 * self.d)
            self._bot_at = self.t + think
            right = rng.random() < self.bot_accuracy(skill)
            self._bot_pick = self.answer if right else rng.choice(
                [i for i in range(len(self.options)) if i != self.answer] or [0])
            self._bot_round = self.round
        if self._bot_round != self.round:
            self._bot_at = None
            return []
        if self.t >= self._bot_at:
            self._bot_at = None
            return [("press", f"pick:{self._bot_pick}")]
        return []

    def bot_accuracy(self, skill) -> float:
        return _clamp(0.95 - 0.38 * self.d + 0.25 * (skill - 0.6))

    def draw(self):
        out = [("text", 320, 30, f"{min(self.round + 1, self.rounds)} of {self.rounds}", 12, DIM, "center")]
        out += self.prompt()
        for i, o in enumerate(self.options):
            y = 150 + i * 38
            out += [("rect", 120, y, 400, 32, BG2), ("frame", 120, y, 400, 32, DIM),
                    ("text", 134, y + 21, f"{i + 1}.  {o}", 13, INK, "left")]
        left = 1 - (self.t - self.started) / self.sp_time(self.per_round)
        out += self.bar(120, 340, 400, 6, left, ACCENT)
        if self.last:
            out.append(("text", 560, 30, self.last, 12, GOOD if self.last == "Right." else BAD, "center"))
        return out

    def prompt(self) -> list:
        return []

    def boxes(self):
        return [(120, 150 + i * 38, 400, 32, f"pick:{i}") for i in range(len(self.options))]


TRUTH_TELLS = ["meets your eye", "keeps their hands still", "answers steadily", "shrugs easily",
               "takes a sip of their drink", "nods along", "speaks at an even pace", "laughs at the right moment",
               "leans back, relaxed", "taps a slow rhythm"]
LIE_TELLS = ["glances at the door", "touches their nose", "answers a little too quickly", "smiles, but not with "
             "their eyes", "repeats your question back", "goes very still", "over-explains a small detail",
             "voice rises at the end", "hands disappear into their pockets", "blinks fast"]
SUBTLE_LIE = ["pauses a beat before one word", "their smile fades a moment early", "a foot turns toward the door",
              "swallows before answering", "their story changes one small detail"]


class Tell(_Rounds):
    id, title = "tell", "Insight"
    help = "Which of these gives the lie away? (1-5, or click)"

    def new_round(self):
        n = 3 + int(2 * self.d)
        honest = self.rng.sample(TRUTH_TELLS, n - 1)
        lie = self.rng.choice(SUBTLE_LIE if self.d > 0.55 else LIE_TELLS)
        self.answer = self.rng.randrange(n)
        honest.insert(self.answer, lie)
        self.options = [f"They {x}." for x in honest]

    def prompt(self):
        return [("sprite", "speaker", 296, 50, 48, 64), ("text", 320, 135, "As they talk, they...", 13, INK, "center")]


MOODS = {
    "persuasion": {"Proud": "Flatter", "Practical": "Reason", "Grieving": "Sympathize", "Greedy": "Offer",
                   "Bored": "Joke", "Cautious": "Reason"},
    "deception": {"Suspicious": "Feign ignorance", "Busy": "Distract", "Vain": "Flatter", "Gullible": "Bluff",
                  "Status-minded": "Name-drop", "Tired": "Distract"},
    "intimidation": {"Cowardly": "Threaten", "Proud": "Cold stare", "Rowdy": "Shout", "Greedy": "Remind",
                     "Nervous": "Loom", "Stubborn": "Remind"},
}
MOOD_HINTS = {"Proud": "chin up, and waits to be admired", "Practical": "wants to know what's in it for them",
              "Grieving": "looks like they've lost something", "Greedy": "keeps glancing at your purse",
              "Bored": "is barely listening", "Cautious": "weighs every word you say",
              "Suspicious": "watches your hands", "Busy": "keeps looking past you", "Vain": "fusses with their hair",
              "Gullible": "hangs on your every word", "Status-minded": "asks who you know",
              "Tired": "rubs their eyes", "Cowardly": "edges away from you", "Rowdy": "is loud and spoiling for it",
              "Nervous": "won't stop fidgeting", "Stubborn": "folds their arms"}


class Argue(_Rounds):
    id, title = "argue", "Talking them round"
    help = "Play the argument that fits their mood."

    def setup(self):
        k = (self.spec.kind or "persuasion").lower()
        self.table = MOODS.get(k, MOODS["persuasion"])
        self.cards = sorted(set(self.table.values()))
        super().setup()

    def new_round(self):
        self.mood = self.rng.choice(list(self.table))
        n = min(len(self.cards), 3 + int(2 * self.d))
        right = self.table[self.mood]
        others = self.rng.sample([c for c in self.cards if c != right], n - 1)
        self.answer = self.rng.randrange(n)
        others.insert(self.answer, right)
        self.options = others

    def prompt(self):
        hint = MOOD_HINTS.get(self.mood, "")
        say = f"{self.mood}: they {hint}" if self.d < 0.35 else f"They {hint}."
        return [("sprite", "speaker", 296, 40, 48, 64), ("text", 320, 130, say, 13, INK, "center")]


SHAPES = ["round", "pointed", "lobed", "long", "heart"]
LEAF_COLORS = ["#5a9a4a", "#7aaa3a", "#4a7a5a", "#8a9a3a", "#6aa06a"]


def plant_shapes(cx, cy, plant, k=1.0) -> list:
    """A plant drawn as a stem and its leaves (shape, how many, colour)."""
    shape, n, col = plant
    color = LEAF_COLORS[col % len(LEAF_COLORS)]
    out = [("line", cx, cy + 40 * k, cx, cy - 30 * k, "#6a5a3a", 3)]
    for i in range(n):
        side = -1 if i % 2 else 1
        y = cy + 30 * k - i * (60 * k / max(1, n))
        x = cx + side * 14 * k
        if shape == "round":
            out.append(("circle", x, y, 8 * k, color))
        elif shape == "pointed":
            out.append(("line", cx, y, cx + side * 26 * k, y - 10 * k, color, max(3, int(6 * k))))
        elif shape == "lobed":
            out += [("circle", x, y, 6 * k, color), ("circle", x + side * 8 * k, y - 4 * k, 5 * k, color)]
        elif shape == "long":
            out.append(("line", cx, y, cx + side * 34 * k, y + 2 * k, color, max(2, int(4 * k))))
        else:
            out += [("circle", x - 3 * k, y, 6 * k, color), ("circle", x + 3 * k, y, 6 * k, color),
                    ("circle", x, y + 5 * k, 5 * k, color)]
    return out


class Plant(_Rounds):
    id, title = "plant", "Foraging"
    help = "Pick the plant that matches the one you want."

    def new_round(self):
        def make():
            return (self.rng.choice(SHAPES), self.rng.randint(3, 7), self.rng.randrange(len(LEAF_COLORS)))
        self.target = make()
        n = 4 + int(2 * self.d)
        opts = []
        for _ in range(n - 1):
            p = list(self.target)
            k = self.rng.randrange(3)
            if k == 0:
                p[0] = self.rng.choice([s for s in SHAPES if s != p[0]])
            elif k == 1:
                p[1] = p[1] + self.rng.choice([-1, 1]) * (1 if self.d > 0.5 else 2)
            else:
                p[2] = (p[2] + self.rng.choice([1, 2])) % len(LEAF_COLORS)
            opts.append(tuple(p))
        self.answer = self.rng.randrange(n)
        opts.insert(self.answer, self.target)
        self.plants = opts
        self.options = [f"{p[0]} leaves, {p[1]} of them" for p in opts]

    def prompt(self):
        s, n, c = self.target
        return [("text", 320, 30, f"Looking for: {s} leaves, {n} of them", 14, INK, "center")] + \
            plant_shapes(320, 90, self.target, 1.0)

    def draw(self):
        out = [("text", 320, 14, f"{min(self.round + 1, self.rounds)} of {self.rounds}", 11, DIM, "center")]
        out += self.prompt()
        n = len(self.plants)
        for i, p in enumerate(self.plants):
            x = 320 + (i - (n - 1) / 2) * 92
            out += [("rect", x - 42, 160, 84, 150, BG2), ("frame", x - 42, 160, 84, 150, DIM)]
            out += plant_shapes(x, 230, p, 0.8)
            out.append(("text", x, 300, str(i + 1), 13, INK, "center"))
        left = 1 - (self.t - self.started) / self.sp_time(self.per_round)
        return out + self.bar(120, 340, 400, 6, left, ACCENT)

    def boxes(self):
        n = len(self.plants)
        return [(320 + (i - (n - 1) / 2) * 92 - 42, 160, 84, 150, f"pick:{i}") for i in range(n)]


class Tracks(_Rounds):
    id, title = "tracks", "Tracking"
    help = "Which print carries the trail on?"
    rounds = 4

    def new_round(self):
        self.heading = self.rng.uniform(0, 360)
        n = 3 + int(2 * self.d)
        spread = 70 - 45 * self.d
        opts = [self.heading + self.rng.choice([-1, 1]) * self.rng.uniform(spread * 0.6, spread * 1.6)
                for _ in range(n - 1)]
        self.answer = self.rng.randrange(n)
        opts.insert(self.answer, self.heading + self.rng.uniform(-6, 6))
        self.angles = opts
        names = ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"]
        self.options = [f"Print heading {names[int(((a % 360) + 22.5) // 45) % 8]} ({int(a % 360)}°)" for a in opts]

    def prompt(self):
        a = math.radians(self.heading)
        out = []
        for k in range(4):
            out.append(("circle", 320 - math.sin(a) * (60 - k * 15), 90 + math.cos(a) * (60 - k * 15), 5, INK))
        return out + [("text", 320, 135, "The trail so far", 12, DIM, "center")]


# ======================================================================================================
# Remembering
# ======================================================================================================
WIRE_COLORS = ["red", "blue", "green", "yellow", "white", "black", "copper"]
INGREDIENTS = ["salt", "ash", "nightshade", "mint", "sulphur", "honey", "silverleaf", "vinegar"]


class Wires(Game):
    id, title = "wires", "Disarm the trap"
    help = "Remember the order, then cut the wires in it (1-7)."
    names = WIRE_COLORS
    limit = 25.0

    def setup(self):
        self.k = 3 + int(3 * self.d)
        self.choices = self.rng.sample(self.names, min(len(self.names), self.k + 1))
        self.order = self.rng.sample(range(len(self.choices)), self.k)
        self.show = (3.6 - 1.8 * self.d) * (2.0 if self.spec.slow else 1.0)
        self.done_n = 0

    def on(self, action):
        if not action.startswith("pick:") or self.t < self.show:
            return
        i = int(action[5:])
        if i == self.order[self.done_n]:
            self.done_n += 1
            if self.done_n >= self.k:
                self.finish(0.5 + 0.5 * self.time_left)
        else:
            self.finish(self.done_n / self.k * 0.45, "Wrong one!")

    def timeout(self):
        self.finish(self.done_n / self.k * 0.45, "Too slow.")

    def bot(self, rng, skill):
        if self.t < self.show:
            return []
        if self._bot_at is None:
            self._bot_at = self.t + rng.uniform(0.3, 1.2) * (1.4 - skill)
        if self.t >= self._bot_at:
            self._bot_at = None
            p = 0.995 - (0.03 + 0.02 * self.k) * (1.2 - skill) * (1 + 1.5 * self.d)
            want = self.order[self.done_n]
            pick = want if rng.random() < p else rng.randrange(len(self.choices))
            return [("press", f"pick:{pick}")]
        return []

    def boxes(self):
        return [(180, 100 + i * 32, 280, 24, f"pick:{i}") for i in range(len(self.choices))]

    def draw(self):
        out = []
        if self.t < self.show:
            out.append(("text", 320, 60, "Remember: " + ", ".join(self.choices[i] for i in self.order), 14, ACCENT, "center"))
        else:
            out.append(("text", 320, 60, f"{self.done_n} of {self.k} done", 13, INK, "center"))
        for i, c in enumerate(self.choices):
            y = 100 + i * 32
            out += [("rect", 180, y, 280, 24, BG2), ("text", 194, y + 17, f"{i + 1}.  {c}", 13, INK, "left")]
        return out


class Mix(Wires):
    id, title = "mix", "Mixing"
    help = "Remember the recipe, then add each thing in its turn (1-8)."
    names = INGREDIENTS


class Weave(Game):
    id, title = "weave", "Working the pattern"
    help = "Watch the pattern, then repeat it with the arrow keys."
    pad = "arrows"
    limit = 30.0
    DIRS = ["up", "right", "down", "left"]

    def setup(self):
        self.n = 3 + int(4 * self.d)
        self.seq = [self.rng.choice(self.DIRS) for _ in range(self.n)]
        self.each = (0.75 - 0.3 * self.d) * (2.0 if self.spec.slow else 1.0)
        self.show = self.each * self.n + 0.4
        self.i = 0

    def on(self, action):
        if action not in self.DIRS or self.t < self.show:
            return
        if action == self.seq[self.i]:
            self.i += 1
            if self.i >= self.n:
                self.finish(0.5 + 0.5 * self.time_left)
        else:
            self.finish(self.i / self.n * 0.45, "A dropped stitch.")

    def timeout(self):
        self.finish(self.i / self.n * 0.45, "Too slow.")

    def bot(self, rng, skill):
        if self.t < self.show:
            return []
        if self._bot_at is None:
            self._bot_at = self.t + rng.uniform(0.2, 0.8) * (1.4 - skill)
        if self.t >= self._bot_at:
            self._bot_at = None
            p = 0.995 - (0.02 + 0.015 * self.n) * (1.2 - skill) * (1 + 1.5 * self.d)
            return [("press", self.seq[self.i] if rng.random() < p else rng.choice(self.DIRS))]
        return []

    def draw(self):
        arrows = {"up": "↑", "right": "→", "down": "↓", "left": "←"}
        if self.t < self.show:
            k = min(self.n - 1, int(self.t / self.each))
            return [("text", 320, 160, arrows[self.seq[k]], 64, ACCENT, "center"),
                    ("text", 320, 260, f"{k + 1} of {self.n}", 13, DIM, "center")]
        return [("text", 320, 160, " ".join(arrows[s] if j < self.i else "•" for j, s in enumerate(self.seq)), 28,
                 INK, "center")]


class Lore(Game):
    id, title = "lore", "What do you know?"
    help = "Find the matching symbols (click or 1-9, then letters for the rest)."
    limit = 40.0
    SYMBOLS = ["☀", "☽", "★", "⚔", "⚕", "⚘", "⚜", "♁", "♃", "♄"]

    def setup(self):
        pairs = 5 + int(3 * self.d)
        syms = self.rng.sample(self.SYMBOLS, pairs)
        self.cards = syms + syms
        self.rng.shuffle(self.cards)
        self.found: set = set()
        self.up: list = []
        self.flips = 0
        self.max_flips = int(pairs * (2.6 - 0.8 * self.d)) + 2
        self.wait = 0.0
        self.pairs = pairs
        self.seen: dict = {}

    def step(self, dt):
        if self.wait > 0:
            self.wait -= dt
            if self.wait <= 0:
                self.up = []

    def on(self, action):
        if not action.startswith("pick:") or self.wait > 0:
            return
        i = int(action[5:])
        if not 0 <= i < len(self.cards) or i in self.found or i in self.up:
            return
        self.up.append(i)
        self.seen[i] = self.cards[i]
        if len(self.up) == 2:
            self.flips += 1
            a, b = self.up
            if self.cards[a] == self.cards[b]:
                self.found |= {a, b}
                self.up = []
                if len(self.found) == len(self.cards):
                    self.finish(0.5 + 0.5 * _clamp(1 - self.flips / self.max_flips + 0.5 * self.time_left))
                    return
            else:
                self.wait = 0.7 if not self.spec.slow else 1.2
            if self.flips >= self.max_flips:
                self.finish(len(self.found) / len(self.cards) * 0.45, "Out of guesses.")

    def timeout(self):
        self.finish(len(self.found) / len(self.cards) * 0.45, "Out of time.")

    def bot(self, rng, skill):
        if self.wait > 0:
            return []
        if self._bot_at is None:
            self._bot_at = self.t + rng.uniform(0.3, 0.9)
        if self.t < self._bot_at:
            return []
        self._bot_at = None
        recall = 0.35 + 0.5 * skill - 0.2 * self.d
        known = {i: s for i, s in self.seen.items() if i not in self.found and rng.random() < recall}
        hidden = [i for i in range(len(self.cards)) if i not in self.found and i not in self.up]
        if self.up:
            a = self.up[0]
            mate = next((i for i, s in known.items() if s == self.cards[a] and i != a), None)
            return [("press", f"pick:{mate if mate is not None else rng.choice([h for h in hidden if h not in known] or hidden)}")]
        for i, s in known.items():
            for j, s2 in known.items():
                if i < j and s == s2:
                    return [("press", f"pick:{i}")]
        fresh = [h for h in hidden if h not in self.seen] or hidden
        return [("press", f"pick:{rng.choice(fresh)}")]

    def boxes(self):
        cols = 4 if len(self.cards) <= 12 else 6
        return [(120 + (i % cols) * (400 / cols), 44 + (i // cols) * 74, 400 / cols - 10, 64, f"pick:{i}")
                for i in range(len(self.cards))]

    def draw(self):
        out = [("text", 320, 24, f"Guesses left: {self.max_flips - self.flips}", 12, DIM, "center")]
        cols = 4 if len(self.cards) <= 12 else 6
        for i, s in enumerate(self.cards):
            x, y = 120 + (i % cols) * (400 / cols), 44 + (i // cols) * 74
            shown = i in self.found or i in self.up
            out += [("rect", x, y, 400 / cols - 10, 64, "#3a4a5a" if not shown else BG2), ("frame", x, y, 400 / cols - 10, 64, DIM)]
            if shown:
                out.append(("text", x + (400 / cols - 10) / 2, y + 44, s, 28, GOOD if i in self.found else ACCENT, "center"))
        return out


class Spot(Game):
    id, title = "spot", "What's out of place?"
    help = "Click what's hidden in the scene before time runs out."
    limit = 16.0

    def setup(self):
        self.limit = 16.0 - 6.0 * self.d
        n = 26 + int(14 * self.d)
        self.hidden_n = 3 + int(2 * self.d)
        self.objs = []
        for k in range(n):
            x, y = self.rng.uniform(40, 600), self.rng.uniform(50, 330)
            r = self.rng.uniform(8, 18)
            self.objs.append([x, y, r, self.rng.choice(["#6a7a5a", "#7a6a4a", "#5a6a7a", "#7a7a6a"]), k < self.hidden_n])
        self.rng.shuffle(self.objs)
        self.delta = 0.36 - 0.24 * self.d
        self.found = 0
        self.miss = 0

    def on(self, action):
        if not action.startswith("point:"):
            return
        x, y = (float(v) for v in action[6:].split(","))
        for o in self.objs:
            if o[4] and (o[0] - x) ** 2 + (o[1] - y) ** 2 <= (o[2] + 6) ** 2:
                o[4] = False
                o.append(True)
                self.found += 1
                if self.found >= self.hidden_n:
                    self.finish(0.5 + 0.5 * self.time_left)
                return
        self.miss += 1
        self.t += 1.0                                          # a wrong guess costs time

    def timeout(self):
        self.finish(self.found / self.hidden_n * 0.45, "Time's up.")

    def bot(self, rng, skill):
        rate = (0.12 + 0.5 * skill) * (0.3 + self.delta * 1.8)
        if rng.random() < rate * DT:
            left = [o for o in self.objs if o[4]]
            if left and rng.random() < 0.75 + 0.2 * skill:
                o = rng.choice(left)
                return [("press", f"point:{o[0]},{o[1]}")]
            return [("press", f"point:{rng.uniform(40, 600)},{rng.uniform(50, 330)}")]
        return []

    def draw(self):
        out = [("rect", 20, 36, 600, 310, "#2e3a2e")]
        for o in self.objs:
            col = o[3]
            if o[4]:
                c = int(col[1:3], 16)
                col = "#%02x%02x%02x" % (min(255, c + int(80 * self.delta)), int(col[3:5], 16),
                                         max(0, int(col[5:7], 16) - int(40 * self.delta)))
            out.append(("circle", o[0], o[1], o[2], col))
            if len(o) > 5:
                out.append(("frame", o[0] - o[2] - 3, o[1] - o[2] - 3, 2 * o[2] + 6, 2 * o[2] + 6, GOOD))
        out.append(("text", 320, 24, f"Found {self.found} of {self.hidden_n}", 12, INK, "center"))
        return out


# ======================================================================================================
# Lockpicking: pins in turn
# ======================================================================================================
class Lockpick(_Sweep):
    id, title = "lockpick", "Picking the lock"
    help = "Set each pin when it lines up (space). Three slips and the pick breaks."
    limit = 30.0

    def setup(self):
        super().setup()
        self.pins = 3 + int(3 * self.d)
        self.set_n, self.lives = 0, 3
        self.half = 0.14 - 0.07 * self.d
        self.speed = 0.6 + 1.0 * self.d

    def on(self, action):
        if action != "hit":
            return
        if abs(self.pos - self.center) <= self.half:
            self.set_n += 1
            if self.set_n >= self.pins:
                self.finish(0.5 + 0.5 * (0.6 * self.lives / 3 + 0.4 * self.time_left))
            else:
                self.new_zone()
        else:
            self.lives -= 1
            if self.lives <= 0:
                self.finish(self.set_n / self.pins * 0.45, "The pick snaps.")

    def timeout(self):
        self.finish(self.set_n / self.pins * 0.45, "Too slow.")

    def draw(self):
        out = super().draw()
        out.append(("text", 320, 120, f"Pin {self.set_n + 1} of {self.pins}", 14, INK, "center"))
        out.append(("text", 320, 280, "Picks left: " + "| " * self.lives, 13, ACCENT, "center"))
        return out


# ======================================================================================================
# Gaming sets: push your luck
# ======================================================================================================
class Luck(Game):
    id, title = "luck", "A game of chance"
    help = "Roll (space) to add to your pot; a 1 loses it. Bank it (S) to keep it. Three turns."
    pad = "bank"
    limit = 60.0

    def setup(self):
        self.goal = 8 + int(32 * self.d)
        self.turn, self.pot, self.banked, self.last = 0, 0, 0, 0

    def on(self, action):
        if action == "hit":
            r = self.rng.randint(1, 6)
            self.last = r
            if r == 1:
                self.pot = 0
                self.next_turn()
            else:
                self.pot += r
        elif action == "stop":
            self.banked += self.pot
            self.pot = 0
            self.next_turn()

    def next_turn(self):
        self.turn += 1
        if self.turn >= 3:
            g = self.goal
            self.finish(0.5 + 0.5 * _clamp((self.banked - g) / g) if self.banked >= g else 0.5 * self.banked / g)

    def timeout(self):
        self.finish(0.5 * self.banked / self.goal)

    def bot(self, rng, skill):
        if self._bot_at is None:
            self._bot_at = self.t + 0.3
        if self.t < self._bot_at:
            return []
        self._bot_at = None
        need = self.goal - self.banked
        stop_at = min(need, 12 + int(6 * skill)) if self.turn < 2 else need
        return [("press", "stop" if self.pot >= stop_at else "hit")]

    def draw(self):
        return [("text", 320, 80, f"Turn {min(3, self.turn + 1)} of 3   ·   goal {self.goal}", 14, INK, "center"),
                ("text", 320, 150, f"Pot: {self.pot}", 28, ACCENT, "center"),
                ("text", 320, 200, f"Banked: {self.banked}", 18, GOOD, "center"),
                ("text", 320, 250, f"Last roll: {self.last or '-'}", 14, DIM, "center")]


GAMES = {g.id: g for g in (Power, Swing, Hammer, Cook, Balance, Endure, Steady, Pickpocket, Calm, Tension, Sneak,
                           Rhythm, Tell, Argue, Plant, Tracks, Wires, Mix, Weave, Lore, Spot, Lockpick, Luck)}


PADS = {
    "lr": [("◀", "left"), ("▶", "right")],
    "ud": [("▲", "up"), ("▼", "down")],
    "arrows": [("◀", "left"), ("▲", "up"), ("▼", "down"), ("▶", "right")],
    "lanes": [("1", "lane:0"), ("2", "lane:1"), ("3", "lane:2"), ("4", "lane:3")],
    "bank": [("Roll", "hit"), ("Bank it", "stop")],
}


def pads(game: Game) -> list[tuple[str, str]]:
    """The buttons a game needs on a touch screen, besides tapping the board: [(label, action)]. Held
    actions (the arrows) are pressed while a finger is on them; taps on the board are "hit" (and pick what's
    there), so most games need none."""
    out = list(PADS.get(getattr(game, "pad", "") or "", []))
    if getattr(game, "pad_hit", False):
        out.append(("Go", "hit"))
    return out


def make(spec: Spec) -> Game:
    return GAMES[spec.game](spec)


# ======================================================================================================
# Which game for which check
# ======================================================================================================
SKILL_GAME = {"athletics": "power", "acrobatics": "balance", "sleight of hand": "pickpocket", "stealth": "sneak",
              "thieves' tools": "lockpick", "perception": "spot", "investigation": "spot", "insight": "tell",
              "persuasion": "argue", "deception": "argue", "intimidation": "argue", "performance": "rhythm",
              "arcana": "lore", "history": "lore", "religion": "lore", "nature": "lore", "medicine": "steady",
              "survival": "tracks", "animal handling": "calm"}
STAT_GAME = {"str": "power", "dex": "balance", "con": "endure", "int": "lore", "wis": "spot", "cha": "argue"}
TOOL_GAME = {"smith": "hammer", "tinker": "hammer", "mason": "hammer", "carpenter": "hammer", "woodcarver": "hammer",
             "cobbler": "hammer", "leatherworker": "hammer", "alchemist": "mix", "brewer": "mix", "herbalism": "mix",
             "poisoner": "mix", "weaver": "weave", "calligrapher": "weave", "painter": "weave", "cartographer": "weave",
             "jeweler": "weave", "glassblower": "weave", "potter": "weave", "forgery": "weave", "disguise": "weave",
             "cook": "cook", "navigator": "tracks", "dice": "luck", "playing card": "luck", "dragonchess": "luck",
             "thieves": "lockpick"}
INSTRUMENTS = {"bagpipes", "drum", "dulcimer", "flute", "horn", "lute", "lyre", "pan flute", "shawm", "viol"}
WORK_GAME = {"woodcutting": "swing", "mining": "swing", "fishing": "tension", "foraging": "plant",
             "harvesting": "plant", "skinning": "steady", "trapping": "wires"}
CATEGORY = {"athletics": "physical", "acrobatics": "physical", "sleight of hand": "physical", "stealth": "physical",
            "insight": "social", "persuasion": "social", "deception": "social", "intimidation": "social",
            "performance": "social", "animal handling": "social", "arcana": "knowledge", "history": "knowledge",
            "religion": "knowledge", "nature": "knowledge", "investigation": "knowledge", "perception": "knowledge",
            "medicine": "knowledge", "survival": "knowledge"}
STAT_CATEGORY = {"str": "physical", "dex": "physical", "con": "physical", "int": "knowledge", "wis": "knowledge",
                 "cha": "social"}
KINDS = ["physical", "social", "knowledge", "tools", "saves"]


def game_for(option: dict, context: str = "") -> tuple[str, str]:
    """(game id, category) for a check option (game/checks.py) or "work:<kind>"; context "trap" picks the
    wires for thieves' tools."""
    if isinstance(option, str):
        if option.startswith("work:"):
            return WORK_GAME.get(option[5:], "swing"), "tools"
        option = {"label": option, "kind": "Skill", "stat": ""}
    if context.startswith("work:"):                    # gathering (game/gathering.py): the work's own game
        return WORK_GAME.get(context[5:], "swing"), "tools"
    label = str(option.get("label") or "").lower()
    if option.get("kind") == "Save":
        return STAT_GAME.get(option.get("stat") or "con", "endure"), "saves"
    if option.get("kind") == "Tool":
        if "thieves" in label:
            return ("wires" if context == "trap" else "lockpick"), "tools"
        if label in INSTRUMENTS:
            return "rhythm", "tools"
        for key, g in TOOL_GAME.items():
            if key in label:
                return g, "tools"
        return "hammer", "tools"
    if option.get("kind") == "Ability":
        st = option.get("stat") or ""
        return STAT_GAME.get(st, "power"), STAT_CATEGORY.get(st, "physical")
    if label in SKILL_GAME:
        return SKILL_GAME[label], CATEGORY.get(label, "physical")
    st = option.get("stat") or ""
    return STAT_GAME.get(st, "power"), STAT_CATEGORY.get(st, "physical")


def wanted(settings, category: str) -> bool:
    """Should a check of this kind be a minigame? (Settings > Checks: Dice, Minigames, or by kind.)"""
    if settings is None:
        return False
    mode = settings.get("checks_mode", "Dice") or "Dice"
    if mode == "Minigames":
        return True
    if mode == "By kind":
        return bool((settings.get("minigame_kinds") or {}).get(category, False))
    return False


# ======================================================================================================
# Playing one through without a screen (tests, and the "simulated" check)
# ======================================================================================================
def hook(settings, player, in_combat=lambda: False, rng: random.Random | None = None):
    """The minigame player game/checks.py calls (checks.minigame): turns a check into a game when Settings
    say so, and its result back into a natural roll. player(spec) -> perf (0..1), or None to roll after all."""
    rng = rng or random.Random()

    def run(world, member, combatant, option, dc, bonus, mode="normal", context=""):
        if in_combat():
            return None                                    # fights stay dice
        game, category = game_for(option, context)
        if not wanted(settings, category):
            return None
        need = need_for(dc, bonus, mode)
        label = str(option.get("label") or "")
        who = (member or {}).get("name") or getattr(combatant, "name", "")
        spec = Spec(game, need, slow=bool(settings.get("minigame_slow", False)), seed=rng.randrange(1 << 30),
                    title=f"{who}: {label}" + (f" (DC {dc})" if dc else ""), kind=label.lower())
        perf = player(spec)
        return None if perf is None else natural_for(perf, need)
    return run


def autoplay(spec: Spec, skill: float, rng: random.Random | None = None, max_seconds: float = 120.0) -> Game:
    rng = rng or random.Random(spec.seed)
    g = make(spec)
    t = 0.0
    while not g.done and t < max_seconds:
        for kind, action in g.bot(rng, skill):
            (g.press if kind == "press" else g.release)(action)
        g.update(DT)
        t += DT
    if not g.done:
        g.finish(0.0, "Gave up.")
    return g


__all__ = ["Spec", "Game", "GAMES", "PADS", "pads", "make", "game_for", "wanted", "natural_for", "need_for", "autoplay", "hook", "KINDS",
           "W", "H", "DT"]


from game import contests as _contests  # noqa: E402,F401  (the festival contests' own games join GAMES)
