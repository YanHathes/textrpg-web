"""Thieves (Hotfix 20): pickpockets in a crowd, muggers in rough streets at night, and work for a city's thieves'
guild.

Pickpockets
    In a crowd (a City's or Capital's busy street, a Town's market by day, a festival, a full taproom), now and
    then (PICK_ODDS a step, no more than once every PICK_EVERY minutes) a cutpurse tries the party's purse.
    The party gets one roll to notice: the sharpest eyes' Wisdom (Perception), d20 + bonus (as with traps),
    against the cutpurse's Sleight of Hand (CUTPURSE_DC by the size of the town). Noticed: they're caught at it
    (grab them for the watch's reward, or let them go). Not noticed: some coin is simply gone, and nothing is
    said. One of a town's light-fingered homeless (game/homeless.py) can try it too, anywhere and at any
    hour, when the party passes right beside them (BEGGAR_ODDS a step). Only ever coin: never an item, which could leave a party on survival mode without what keeps it alive.
Muggers
    In a rough street (game/thieves.py rough_streets: the lanes, alleys, wharves and yards of a Town, City or
    Capital), at night, now and then (MUG_ODDS a step, at most once a day) a gang steps out of the dark and
    wants the purse and the pack. Hand it over (most of the coin and the best things carried, MUG_ITEMS of
    them, though never what's worn or held), talk your way out (the party's best Persuasion, Intimidation or
    Deception against MUG_DC; failing, they attack), or fight. Beaten, the party wakes where it fell, robbed.
The guild
    In a city with a thieves' guild its fence, or anyone of the guild, has work for quick hands (JOBS): a few
    hours, one check by the party's best at it, pay after the guild's cut, standing with the guild on a job
    done. Better work opens as the party rises in the guild (RANKS). Failing badly means being seen: the crime
    is on the party's head. A Footpad or better is left alone by the city's cutpurses and muggers.

Kept in the save (state.law["thieves"]): {"pick_at", "mug_at" (minutes: the last tries), "mug" (a mugging
going on: {"town", "street", "n"}), "lifted" (copper lost to cutpurses, unnoticed)}.
"""
from __future__ import annotations

import random

PICK_ODDS = 1 / 160
PICK_EVERY = 3 * 60
CUTPURSE_DC = {"Hamlet": 11, "Village": 11, "Town": 12, "City": 13, "Capital": 14}
PICK_SHARE = (0.05, 0.15)                     # of the purse
PICK_MOST = {"Hamlet": 5, "Village": 5, "Town": 15, "City": 25, "Capital": 40}           # gp at most
BEGGAR_ODDS = 1 / 8                           # a step beside one of the light-fingered homeless
GRAB_DC = 12
GRAB_REWARD = (2, 6)                          # gp from the watch
MUG_ODDS = 1 / 90
MUG_EVERY = 24 * 60
MUG_DC = 13
MUG_SHARE = 0.6                               # of the purse
MUG_ITEMS = 2
ROUGH_WORDS = ("Lane", "Alley", "Wharf", "Dock", "Row", "Yard", "Close", "Wynd", "Quay", "Court", "Stews",
               "Narrows", "Gut", "Mews", "Rookery")
BIG = ("Town", "City", "Capital")
CROWD_NEAR = 4
CROWD_COUNT = 2
BUSY_PLACES = ("Tavern", "Inn", "Market", "Casino", "Arena", "Brothel")
# standing with the guild -> rank
RANKS = [(70, "Master thief"), (45, "Thief"), (25, "Footpad"), (10, "Cutpurse"), (0, "")]
PROTECTED_AT = 25
JOBS = [
    {"id": "purses", "name": "Lift purses in the market", "skill": "Sleight of Hand", "ability": "dex", "dc": 12,
     "hours": 3, "gp": (4, 12), "rank": 0, "crime": "pickpocket", "standing": 1},
    {"id": "parcel", "name": "Carry a parcel past the watch", "skill": "Deception", "ability": "cha", "dc": 12,
     "hours": 2, "gp": (5, 10), "rank": 0, "crime": "theft", "standing": 1},
    {"id": "shakedown", "name": "Lean on a shopkeeper who's behind with the guild", "skill": "Intimidation",
     "ability": "cha", "dc": 13, "hours": 2, "gp": (8, 16), "rank": 10, "crime": "assault", "standing": 2},
    {"id": "burglary", "name": "Burgle a merchant's house", "skill": "Thieves' Tools", "ability": "dex", "dc": 15,
     "hours": 5, "gp": (20, 40), "rank": 25, "crime": "lockpicking", "standing": 3, "loot": True},
    {"id": "heist", "name": "A job on a noble's strongroom", "skill": "Stealth", "ability": "dex", "dc": 17,
     "hours": 8, "gp": (60, 120), "rank": 45, "crime": "theft", "standing": 5, "loot": True},
]
GUILD_CUT = 0.3
LOOT_KINDS = ("Trinket", "Gear")


def _data(state) -> dict:
    from game import law
    return law.data(state).setdefault("thieves", {})


# ----------------------------------------------------------------------------------------------------
# The guild
# ----------------------------------------------------------------------------------------------------
def guild_of(world, town):
    from game import factions
    return factions.index(world)["thieves"].get(town.id) if town is not None else None


def rank(world, state, town) -> tuple[str, int]:
    from game import factions
    g = guild_of(world, town)
    if g is None:
        return "", 0
    s = factions.standing(world, state, g.id)
    return next(name for at, name in RANKS if s >= at), s


def protected(world, state, town) -> bool:
    """A Footpad or better of the town's guild: its cutpurses and muggers leave you be."""
    g = guild_of(world, town)
    if g is None:
        return False
    from game import factions
    return factions.standing(world, state, g.id) >= PROTECTED_AT


def guild_npc(world, npc) -> bool:
    """Someone who can put guild work your way: the city's fence, or one of the guild."""
    from game import law
    return law.is_fence(world, npc)


def _npc_town(world, npc):
    from game import places
    return world.entities.get(places.town_of(world, npc) or "")


def jobs_for(world, state, npc, members) -> list[dict]:
    """The work going: each job with whether it's open to you yet and the party's best at it."""
    from game import traps
    town = _npc_town(world, npc)
    _r, standing = rank(world, state, town)
    out = []
    for j in JOBS:
        best = traps._best(world, members, j["skill"], j["ability"])
        who, bonus = (best[1].name, best[3]) if best else ("", 0)
        need = next((name for at, name in reversed(RANKS) if at >= j["rank"] and at), "")
        out.append(dict(j, open=standing >= j["rank"], who=who, bonus=bonus,
                        need=need if standing < j["rank"] else ""))
    return out


def do_job(world, state, members, npc, job_id: str, rng=None, bus=None) -> dict:
    """A job for the guild: the hours pass, one check. {"text", "skip" (title), "caught", "paid"}."""
    from game import factions, law, traps
    rng = rng or random.Random()
    town = _npc_town(world, npc)
    g = guild_of(world, town)
    j = next((x for x in jobs_for(world, state, npc, members) if x["id"] == job_id), None)
    if j is None or g is None:
        return {"text": "There's no such work going."}
    if not j["open"]:
        return {"text": f"\"That's not for the likes of you. Not yet.\" (Needs: {j['need']})"}
    tot, who, ok = traps._roll(world, state, members, j["skill"], j["ability"], j["dc"], rng, bus, j["name"].lower())
    state.advance(j["hours"] * 60, "work for the guild")
    if ok:
        take = rng.randint(*j["gp"])
        mine = max(1, int(round(take * (1 - GUILD_CUT))))
        state.add_copper(mine * 100, "the guild's work")
        factions.change(world, state, g.id, j["standing"], "work for the guild", bus)
        text = f"{who} pulls it off ({tot} vs DC {j['dc']}). After the guild's cut, {mine} gp is yours."
        if j.get("loot"):
            item = _loot(world, rng)
            if item is not None:
                law.take_stolen(world, state, item.id, 1, town)
                text += f" And a {item.name}, which you'd best sell to a fence."
        r, _s = rank(world, state, town)
        if r:
            text += f" (In the guild you're a {r}.)"
        return {"text": text, "skip": "Work for the guild", "paid": mine}
    if tot <= j["dc"] - 5:
        law.commit(world, state, j["crime"], town, [law.CROWD], 0, "", bus)
        factions.change(world, state, g.id, -1, "a botched job", bus)
        return {"text": f"{who} botches it ({tot} vs DC {j['dc']}) and is seen. The watch will be looking for you.",
                "skip": "Work for the guild", "caught": True}
    return {"text": f"{who} can't find a way to do it ({tot} vs DC {j['dc']}). You come back with nothing, "
                    "but nobody saw.", "skip": "Work for the guild"}


def _loot(world, rng):
    """Something worth the lifting: plain (not magic) trinkets and goods of a few gp to a hundred and fifty."""
    def plain(e):
        f = e.fields
        return "magic" not in (e.tags or []) and (f.get("rarity") or "Common") in ("Common", "") and \
            not f.get("requires_attunement")
    goods = [e for e in world.entities.all("item") if e.fields.get("category") in LOOT_KINDS and plain(e) and
             5 <= float(e.fields.get("value") or 0) <= 150]
    return rng.choice(goods) if goods else None


# ----------------------------------------------------------------------------------------------------
# Where
# ----------------------------------------------------------------------------------------------------
def rough_streets(world, town) -> list[str]:
    """A town's rough streets: its lanes, alleys, wharves and yards (or, with none of those, its last back
    street). Towns, Cities and Capitals only."""
    from game import places
    from game import settlements as ST
    if town is None or ST.tier_of(town) not in BIG:
        return []
    rows = places.streets_of(town)
    rough = [s["name"] for s in rows if any(w in s["name"].split() for w in ROUGH_WORDS)]
    if not rough:
        back = [s["name"] for s in rows[1:] if not s.get("exit")]
        rough = back[-1:]
    return rough


def _spot(explorer):
    from game import places
    return places.current(explorer.world, explorer.state)


def _near(explorer, kinds=("crowd", "npc")) -> int:
    return sum(1 for t in explorer.tokens if t.kind in kinds and t.level == explorer.level and not t.hidden
               and max(abs(t.x - explorer.x), abs(t.y - explorer.y)) <= CROWD_NEAR)


def crowded(explorer, spot=None) -> bool:
    """In a crowd: a City's or Capital's busy street, a Town's market street by day, a festival, a full
    taproom or market hall."""
    from game import places
    from game import settlements as ST
    spot = spot or _spot(explorer)
    town = spot.town
    if town is None or spot.kind not in ("street", "building"):
        return False
    st = explorer.state
    tier = ST.tier_of(town)
    if spot.kind == "building":
        b = spot.building
        kind = (b.fields.get("kind") or b.fields.get("type") or b.name or "") if b is not None else ""
        return any(w in kind for w in BUSY_PLACES) and _near(explorer, ("npc", "crowd")) >= 3
    if st.time_of_day == "Night" or tier not in BIG:
        return False
    if tier in ("City", "Capital") and _near(explorer) >= CROWD_COUNT:
        return True
    try:
        from game import townevents as TE
        if TE.festival_at(explorer.world, town, st.minutes):
            return True
    except Exception:  # noqa: BLE001 - no festival, no crowd
        pass
    return spot.street == places.first_street(town) and st.time_of_day in ("Morning", "Day")


def in_rough_street(explorer, spot=None) -> bool:
    spot = spot or _spot(explorer)
    return spot.kind == "street" and spot.town is not None and bool(spot.street) and \
        spot.street in rough_streets(explorer.world, spot.town)


# ----------------------------------------------------------------------------------------------------
# A step in town
# ----------------------------------------------------------------------------------------------------
def on_step(explorer, entered: str = ""):
    """After the party steps somewhere in a town: a word about a rough street at night, a cutpurse, a mugging.
    Returns (message, prompt)."""
    st = explorer.state
    if explorer.area is None or (st.law or {}).get("jail") or explorer.travelling():
        return "", None
    spot = _spot(explorer)
    if spot.town is None or spot.kind not in ("street", "building"):
        return "", None
    d = _data(st)
    if d.get("mug"):
        if st.minutes - int(d["mug"].get("at", 0)) < 30:
            return "", None
        d.pop("mug", None)                        # (a mugging left unanswered, from before a reload: gone)
    msg = ""
    night = st.time_of_day == "Night"
    rough = night and in_rough_street(explorer, spot)
    if entered and rough:
        msg = f"{spot.street} is a rough part of town after dark. Keep a hand on your purse."
    if protected(explorer.world, st, spot.town):
        return msg, None
    rng = explorer.rng
    if rough and st.minutes - int(d.get("mug_at", -10 ** 9)) >= MUG_EVERY and rng.random() < MUG_ODDS:
        d["mug_at"] = st.minutes
        return msg, mug_prompt(explorer, spot)
    if st.minutes - int(d.get("pick_at", -10 ** 9)) >= PICK_EVERY and rng.random() < PICK_ODDS and \
            st.copper > 0 and crowded(explorer, spot):
        d["pick_at"] = st.minutes
        m2, p2 = pickpocket(explorer, spot)
        return (m2 or msg), p2
    beggar = _thief_beside(explorer)                    # one of the homeless, light-fingered (game/homeless.py)
    if beggar is not None and st.copper > 0 and st.minutes - int(d.get("pick_at", -10 ** 9)) >= PICK_EVERY and \
            rng.random() < BEGGAR_ODDS:
        d["pick_at"] = st.minutes
        m2, p2 = pickpocket(explorer, spot, by=beggar)
        return (m2 or msg), p2
    return msg, None


def _thief_beside(explorer):
    """One of the town's homeless who lives by quick fingers, right beside the party."""
    for t in explorer.tokens:
        if t.kind == "crowd" and t.id.startswith("homeless:") and t.level == explorer.level and \
                max(abs(t.x - explorer.x), abs(t.y - explorer.y)) <= 1 and (explorer.crowd_info.get(t.id) or {}).get("thief"):
            return t
    return None


def pickpocket(explorer, spot=None, by=None):
    """A cutpurse tries the purse (by: one of the homeless, a token). One roll to notice it; not noticed,
    coin's gone and nothing is said."""
    from game import settlements as ST
    from game import traps
    from game.explore import Prompt
    st, world, rng = explorer.state, explorer.world, explorer.rng
    spot = spot or _spot(explorer)
    tier = ST.tier_of(spot.town)
    dc = CUTPURSE_DC.get(tier, 12) + rng.randint(0, 2)
    tot, who, seen = traps._roll(world, st, explorer.members(), "Perception", "wis", dc, rng)   # (silent: no bus)
    if seen:
        grab = traps._best(world, explorer.members(), "Athletics", "str")
        opts = []
        if grab is not None:
            opts.append((f"Grab them: {grab[1].name} (Athletics {grab[3]:+d} vs DC {GRAB_DC})",
                         ("thief", "grab"), True))
        opts.append(("Let them go", ("thief", "go"), True))
        gone = (f"catches a {by.name.split(' ', 1)[-1]} with a hand in the purse, already scrambling away"
                if by is not None else "turns as a hand whips back into the crowd")
        return "", Prompt("A cutpurse!", f"{who} feels fingers at the purse (Perception {tot} vs {dc}) and {gone}. "
                                         "Nothing's gone.", opts)
    most = PICK_MOST.get(tier, 5) * 100
    take = min(st.copper, most, max(1, int(st.copper * rng.uniform(*PICK_SHARE))))
    if take > 0:
        st.add_copper(-take, "a cutpurse")
        d = _data(st)
        d["lifted"] = int(d.get("lifted", 0)) + take
        st.save()
    return "", None                              # (you simply don't notice)


def mug_prompt(explorer, spot=None):
    from game import traps
    from game.explore import Prompt
    spot = spot or _spot(explorer)
    st, world = explorer.state, explorer.world
    n = 2 + (1 if len([m for m in explorer.members() if not m.get("dead")]) > 2 else 0)
    street = spot.street or "the street"
    _data(st)["mug"] = {"town": spot.town.id, "street": street, "n": n, "at": st.minutes}
    st.save()
    opts = [("Hand it over", ("mug", "give"), True)]
    best = None
    for label, ab in (("Persuasion", "cha"), ("Intimidation", "cha"), ("Deception", "cha")):
        b = traps._best(world, explorer.members(), label, ab)
        if b is not None and (best is None or b[3] > best[1][3]):
            best = (label, b)
    if best is not None:
        label, b = best
        opts.append((f"Talk your way out: {b[1].name} ({label} {b[3]:+d} vs DC {MUG_DC})", ("mug", "talk", label),
                     True))
    opts.append(("Fight", ("mug", "fight"), True))
    return Prompt("Muggers!", f"{n} figures step out of the dark of {street}, blades out. \"Purse and pack. "
                              "Slowly, now, and nobody gets cut.\"", opts)


def rob(world, state, members, rng=None) -> list[str]:
    """Muggers take most of the coin and the best of what's carried (never what's worn or held, nor what's
    bound to someone, nor a quest's things)."""
    from game import inventory as INV
    from game import party as P
    from game.state import money_text
    rng = rng or random.Random()
    lines = []
    coin = int(state.copper * MUG_SHARE) if state.copper > 1000 else state.copper
    if coin > 0:
        state.add_copper(-coin, "muggers")
        lines.append(f"They take {money_text(coin)}.")
    carried = []                                      # (value, where, item id)
    for iid, n in state.inventory.items():
        if n > 0:
            carried.append((_value(world, iid), "pack", iid))
    for m in members:
        if m.get("dead"):
            continue
        bound = set(m.get("bound") or [])
        for iid in (m.get("inventory") or {}):
            if iid not in bound and INV.count(m, iid) - INV.equipped_count(m, iid) > 0:
                carried.append((_value(world, iid), m["id"], iid))
    carried = [c for c in carried if c[0] > 0 and not _quest_item(world, c[2])]
    carried.sort(key=lambda c: -c[0])
    took = []
    by_id = {m["id"]: m for m in members}
    for _v, where, iid in carried[:MUG_ITEMS]:
        if where == "pack":
            state.remove_item(iid, 1, "muggers")
        else:
            INV.remove(by_id[where], iid, 1)
        took.append(_name(world, iid))
    if took:
        lines.append(("And " if coin > 0 else "They take ") + " and ".join(took) + ".")
    P.save(world, members)
    state.save()
    return lines or ["You've nothing worth the taking. They spit and melt back into the dark."]


def _name(world, iid: str) -> str:
    from game import quality
    e = world.entities.get(iid) or world.entities.get(quality.base_of(iid))
    return e.name if e is not None else iid


def _value(world, iid: str) -> float:
    from game import quality
    e = world.entities.get(iid) or world.entities.get(quality.base_of(iid))
    return float((e.fields.get("value") if e is not None else 0) or 0)


def _quest_item(world, iid: str) -> bool:
    from game import quality
    e = world.entities.get(iid) or world.entities.get(quality.base_of(iid))
    return e is not None and bool(e.fields.get("quest") or (e.fields.get("kind") or "") == "Quest")


def muggers(world, n: int) -> list[dict]:
    rows = []
    thug = world.entities.find_by_name("enemy", "Thug") or world.entities.find_by_name("enemy", "Bandit")
    cut = world.entities.find_by_name("enemy", "Cutpurse")
    if thug is not None:
        rows.append({"id": thug.id, "count": max(1, n - (1 if cut is not None else 0))})
    if cut is not None:
        rows.append({"id": cut.id, "count": 1})
    return rows


def act(world, state, members, explorer, action: tuple, rng=None, bus=None) -> dict:
    """("thief", "grab" | "go") and ("mug", "give" | "talk" | "fight"). Returns {"lines", "fight"}."""
    from game import traps
    rng = rng or random.Random()
    kind, what = action[0], (action[1] if len(action) > 1 else "")
    if kind == "thief":
        if what != "grab":
            return {"lines": ["You let them go. You keep a hand on the purse after that."]}
        tot, who, ok = traps._roll(world, state, members, "Athletics", "str", GRAB_DC, rng, bus, "the cutpurse")
        if ok:
            gp = rng.randint(*GRAB_REWARD)
            state.add_copper(gp * 100, "a cutpurse for the watch")
            return {"lines": [f"{who} gets a fist in the cutpurse's collar ({tot} vs DC {GRAB_DC}) and hands them "
                              f"to the watch, who pay {gp} gp for the trouble."]}
        return {"lines": [f"{who} grabs, and gets a fistful of nothing ({tot} vs DC {GRAB_DC}). Gone."]}
    d = _data(state)
    mug = d.get("mug") or {}
    if what == "give":
        d.pop("mug", None)
        return {"lines": ["You hand it over."] + rob(world, state, members, rng)}
    if what == "talk":
        label = action[2] if len(action) > 2 else "Persuasion"
        tot, who, ok = traps._roll(world, state, members, label, "cha", MUG_DC, rng, bus, "the muggers")
        if ok:
            d.pop("mug", None)
            state.save()
            words = {"Intimidation": "They look at each other, and decide you're not worth it.",
                     "Deception": "They swallow it whole and go looking for someone else.",
                     }.get(label, "Somehow you talk them round. They let you pass.")
            return {"lines": [f"{who}: {label} {tot} vs DC {MUG_DC}. {words}"]}
        return {"lines": [f"{who}: {label} {tot} vs DC {MUG_DC}. \"Enough talk.\" They come at you."],
                "fight": muggers(world, int(mug.get("n", 2)))}
    if what == "fight":
        return {"lines": ["You draw steel."], "fight": muggers(world, int(mug.get("n", 2)))}
    return {"lines": []}


def mugging(state) -> bool:
    return bool(_data(state).get("mug"))


def fought(state, outcome: str) -> None:
    """The mugging fight's over (won, or run from)."""
    _data(state).pop("mug", None)
    state.save()


def beaten(world, state, members, rng=None) -> list[str]:
    """Beaten by muggers: they take what they want, and you come to where you fell."""
    from game import condition
    _data(state).pop("mug", None)
    for m in members:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        condition.apply(state, m, c)
        c.hp = max(1, c.hp)
        condition.store(state, m, c, save=False)
    state.advance(60, "knocked out")
    return ["You come to in the gutter, aching, an hour later."] + rob(world, state, members, rng)


__all__ = ["on_step", "pickpocket", "mug_prompt", "act", "rob", "beaten", "fought", "mugging", "jobs_for",
           "do_job", "rank", "protected", "rough_streets", "crowded", "guild_npc", "JOBS"]
