"""The walking map's art, and the battle map's: floor squares, water and walls that join up with their
neighbours, doors, windows, roofs, and the props that stand about (trees, rocks, veins, furniture...).

The pictures are drawn in game/art/terrain.py and game/art/props.py, in one house style (game/art/pixart.py):
pixel art at 16 art pixels to a square, doubled to the 32 screen pixels of a square here. This module is what
the rest of the game calls; it keeps what each prop is (its footprint, whether it blocks or gives cover) and
caches the pictures.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

from game.art import props as PR
from game.art import terrain as TR
from game.art.canvas import Canvas
from game.art.pixart import from_canvas, rng

T = 32
N, E, S, W = 1, 2, 4, 8
ART_VERSION = 3                 # bump when the pictures change, so pictures made from them are made again
PROP_RISE = 3                   # rows below a stretch of map whose props may reach up into it (a big tree's crown)

# ======================================================================
# Floors, water, walls
# ======================================================================
FLOORS = {k: (label, (lambda kk: (lambda v: TR.floor(kk, v).done()))(k), n) for k, (label, _fn, n) in TR.FLOORS.items()}
WALLS = {k: (label, body) for k, (label, body, _d, _l) in TR.WALLS.items()}
OUTDOOR_FLOORS = TR.OUTDOOR_FLOORS
SOFT_FLOORS = TR.SOFT_FLOORS
SPILL = TR.SPILL


@lru_cache(maxsize=512)
def floor_tile(kind: str, variant: int = 0) -> Canvas:
    return TR.floor(kind, variant).done()


@lru_cache(maxsize=512)
def fringe_tile(kind: str, mask: int, variant: int = 0) -> Canvas:
    """The ragged edge of `kind` spilling onto a square from the sides in mask (see SPILL)."""
    return TR.fringe(kind, mask, variant).done()


@lru_cache(maxsize=256)
def water_tile(mask: int, variant: int = 0, kind: str = "water") -> Canvas:
    """mask: which neighbours (N, E, S, W bits) are ALSO water."""
    return TR.water(mask, variant, kind).done()


@lru_cache(maxsize=512)
def wall_tile(kind: str, mask: int) -> Canvas:
    """mask: which neighbours are ALSO wall. Where nothing stands below, the wall shows its face."""
    return TR.wall(kind, mask).done()


# ======================================================================
# Props
# ======================================================================
@dataclass(frozen=True)
class PropDef:
    id: str
    label: str
    w: int = 1           # squares wide
    h: int = 1           # squares tall
    blocks: bool = True  # blocks movement
    cover: bool = False  # gives cover (later stages)
    tall: bool = False   # drawn above creatures (tree canopies)


_DEFS = {
    "tree": PropDef("tree", "Tree", tall=True, cover=True),
    "big_tree": PropDef("big_tree", "Big tree", 2, 2, tall=True, cover=True),
    "pine": PropDef("pine", "Pine tree", tall=True, cover=True),
    "bush": PropDef("bush", "Bush", blocks=False, cover=True),
    "rock": PropDef("rock", "Rock", cover=True),
    "boulder": PropDef("boulder", "Boulder", 2, 2, cover=True),
    "stump": PropDef("stump", "Stump"),
    "log": PropDef("log", "Fallen log", 2, 1, cover=True),
    "mushrooms": PropDef("mushrooms", "Mushrooms", blocks=False),
    "barrel": PropDef("barrel", "Barrel", cover=True),
    "crate": PropDef("crate", "Crate", cover=True),
    "table": PropDef("table", "Table", 2, 1, cover=True),
    "chair": PropDef("chair", "Chair", blocks=False),
    "bed": PropDef("bed", "Bed", 1, 2),
    "bookshelf": PropDef("bookshelf", "Bookshelf", 2, 1),
    "counter": PropDef("counter", "Counter", 2, 1, cover=True),
    "anvil": PropDef("anvil", "Anvil"),
    "forge": PropDef("forge", "Forge", 2, 2),
    "chest": PropDef("chest", "Chest"),
    "campfire": PropDef("campfire", "Campfire", blocks=False),
    "workbench": PropDef("workbench", "Carpenter's bench", 2, 1, cover=True),
    "loom": PropDef("loom", "Loom", 2, 1, cover=True),
    "tanning_rack": PropDef("tanning_rack", "Tanning rack", 2, 1, cover=True),
    "alchemy_table": PropDef("alchemy_table", "Alchemy table", 2, 1, cover=True),
    "jeweler_bench": PropDef("jeweler_bench", "Jeweler's bench", cover=True),
    "writing_desk": PropDef("writing_desk", "Scribe's desk", 2, 1, cover=True),
    "stove": PropDef("stove", "Kitchen stove"),
    "brazier": PropDef("brazier", "Brazier"),
    "well": PropDef("well", "Well", 2, 2),
    "pillar": PropDef("pillar", "Pillar", cover=True),
    "statue": PropDef("statue", "Statue", cover=True),
    "bones": PropDef("bones", "Bones", blocks=False),
    "rubble": PropDef("rubble", "Rubble", blocks=False),
    "altar": PropDef("altar", "Altar", 2, 1),
    "haybale": PropDef("haybale", "Hay bale", cover=True),
    "fence": PropDef("fence", "Fence"),
    "cart": PropDef("cart", "Cart", 2, 1, cover=True),
    "grave": PropDef("grave", "Grave", blocks=False),
    "stairs_up": PropDef("stairs_up", "Stairs up", blocks=False),
    "stairs_down": PropDef("stairs_down", "Stairs down", blocks=False),
    "pew": PropDef("pew", "Pew", 2, 1, cover=True),
    "rack": PropDef("rack", "Weapon rack", 2, 1),
    "tub": PropDef("tub", "Bathtub", 2, 1),
    "throne": PropDef("throne", "Throne"),
    "rug": PropDef("rug", "Rug", 2, 2, blocks=False),
    "signpost": PropDef("signpost", "Signpost"),
    "cave_mouth": PropDef("cave_mouth", "Cave mouth", 2, 2),
    "lamp": PropDef("lamp", "Street lamp"),
    "fountain": PropDef("fountain", "Fountain", 2, 2),
    "sale_sign": PropDef("sale_sign", "For sale sign"),
    "crops": PropDef("crops", "Crops", blocks=False),
    "ore_vein": PropDef("ore_vein", "Ore vein", cover=True),
    "quarry_rock": PropDef("quarry_rock", "Quarry rock", cover=True),
    "herb_patch": PropDef("herb_patch", "Herbs", blocks=False),
    "wild_grain": PropDef("wild_grain", "Wild grain", blocks=False),
    "berry_bush": PropDef("berry_bush", "Berry bush", blocks=False, cover=True),
    "fishing_spot": PropDef("fishing_spot", "Fish rising", blocks=False),
    "rich_vein": PropDef("rich_vein", "Rich vein", cover=True),
    "rare_herbs": PropDef("rare_herbs", "Rare herbs", blocks=False),
    "spent_vein": PropDef("spent_vein", "Worked-out vein", blocks=False),
    "bare_patch": PropDef("bare_patch", "Picked clean", blocks=False),
    "carcass": PropDef("carcass", "Carcass", blocks=False),
    "fallen_trunk": PropDef("fallen_trunk", "Fallen trunk", blocks=False, cover=True),
    "branches": PropDef("branches", "Fallen branches", blocks=False, cover=True),
    "debris": PropDef("debris", "Debris", blocks=False),
    "burnt_tree": PropDef("burnt_tree", "Burnt tree", tall=True, cover=True),
    "sapling": PropDef("sapling", "Young tree", blocks=False, cover=True),
}


def _drawer(pid: str):
    fn, n = PR.DRAW[pid]
    return (lambda v: fn(v % n).done()), n


PROPS: dict[str, tuple[PropDef, callable, int]] = {pid: (d, *_drawer(pid)) for pid, d in _DEFS.items()}


@lru_cache(maxsize=512)
def prop_sprite(prop_id: str, variant: int = 0) -> Canvas:
    pdef, fn, count = PROPS[prop_id]
    return fn(variant % count)


def prop_def(prop_id: str) -> PropDef:
    return PROPS[prop_id][0]


def prop_offset(prop_id: str, art_w: int, art_h: int) -> tuple[int, int]:
    """Where a prop's picture goes, from the top-left corner of its footprint: centred across it, its foot on
    the footprint's bottom edge (a tree's crown rises above its square)."""
    d = prop_def(prop_id) if prop_id in PROPS else PropDef(prop_id, prop_id)
    return (d.w * T - art_w) // 2, d.h * T - art_h


# ======================================================================
# Walkable maps: doors, windows, roofs and solid ground
# ======================================================================
@lru_cache(maxsize=64)
def door_sprite(wall: str, opened: bool, horizontal: bool = True, gate: bool = False) -> Canvas:
    """A door in a doorway. horizontal: the wall runs left to right."""
    return TR.door(wall, opened, horizontal, gate).done()


@lru_cache(maxsize=16)
def flame_sprite(variant: int = 0, size: int = 2) -> Canvas:
    """Fire burning on a square (game/fire.py): two frames, and a size (1 smouldering .. 3 roaring)."""
    return TR.flames(variant, size).done()


@lru_cache(maxsize=16)
def crack_sprite(stage: int = 1) -> Canvas:
    """Cracks over a damaged wall or thing (game/destruction.py): 1 knocked about, 2 nearly through."""
    return TR.cracks(stage).done()


@lru_cache(maxsize=64)
def trap_sprite(kind: str, status: str = "seen") -> Canvas:
    """A known dungeon trap, laid over its square (game/traps.py)."""
    return TR.trap(kind, status).done()


@lru_cache(maxsize=128)
def window_tile(kind: str, mask: int, horizontal: bool = True) -> Canvas:
    """A wall square with a glazed window in it."""
    return TR.window(kind, mask, horizontal).done()


ROOF_STYLES = TR.ROOF_STYLES


@lru_cache(maxsize=512)
def roof_tile(style: str, mask: int, variant: int = 0) -> Canvas:
    """A roof seen from above; mask: which neighbours are roof too (the open edges get an eave)."""
    return TR.roof(style, mask, variant).done()


@lru_cache(maxsize=16)
def earth_tile(variant: int = 0) -> Canvas:
    """Solid ground below the cellars: what's not dug out."""
    return TR.earth(variant).done()


# ======================================================================
# Weather on the ground, and the seasons
# ======================================================================
LEAFY = {"tree", "big_tree", "bush", "berry_bush"}
SNOW_CAPPED = {"tree", "big_tree", "bush", "berry_bush", "pine", "rock", "boulder", "stump", "log", "haybale",
               "cart", "statue", "well", "fountain", "crate", "barrel", "quarry_rock", "ore_vein", "rich_vein",
               "fence", "signpost", "lamp", "grave", "cave_mouth", "sale_sign"}


@lru_cache(maxsize=256)
def ground_tile(kind: str, floor: str, variant: int = 0) -> Canvas:
    """What the weather has done to a square of open ground (laid over its floor tile)."""
    return TR.ground(kind, floor, variant).done()


@lru_cache(maxsize=128)
def season_tile(season: str, floor: str, variant: int = 0) -> Canvas:
    """How the season shows on open ground: spring flowers, autumn's fallen leaves, winter's dull grass."""
    return TR.season(season, floor, variant).done()


def _leaf_color(p, season: str):
    r, g, b, a = p
    if not (g > r + 8 and g > b + 8) or a == 0:
        return p
    light = (r + g + b) / 3 / 255
    if season == "Autumn":
        k = (r * 7 + g * 3) % 3
        base = [(214, 110, 36), (226, 172, 52), (170, 58, 34)][k]
    elif season == "Winter":
        base = (118, 104, 78)
    else:
        return p
    f = 0.55 + light
    return (min(255, int(base[0] * f)), min(255, int(base[1] * f)), min(255, int(base[2] * f)), a)


@lru_cache(maxsize=256)
def prop_sprite_in(prop_id: str, variant: int = 0, season: str = "", snow: bool = False) -> Canvas:
    """A prop as the season and the weather leave it: leaves turned in autumn, bare and brown in winter, and
    snow lying on whatever faces up when it has fallen."""
    cv = prop_sprite(prop_id, variant)
    leafy = season in ("Autumn", "Winter") and prop_id in LEAFY
    capped = snow and prop_id in SNOW_CAPPED
    if not (leafy or capped):
        return cv
    s = from_canvas(cv)
    if leafy:
        s.map(lambda q: _leaf_color(q, season))
    if capped:
        r = rng("snowcap", prop_id, variant)
        solid = [(x, y) for y in range(s.h) for x in range(s.w) if (s.get(x, y) or (0, 0, 0, 0))[3] == 255]
        if solid:
            top = min(y for _, y in solid)
            bottom = max(y for _, y in solid)
            crowned = prop_id in LEAFY or prop_id == "pine"
            reach = top + (bottom - top) * (0.62 if crowned else 0.45)
            lum = sorted(sum(s.get(x, y)[:3]) for x, y in solid if y <= reach)
            bright = lum[int(len(lum) * 0.55)] if lum else 999
            for x in range(s.w):                   # the top of each column, a pixel or two deep
                for y in range(s.h):
                    q = s.get(x, y)
                    if q is None or q[3] < 255:
                        continue
                    for d in range(1 + (r.random() < 0.4)):
                        qq = s.get(x, y + d)
                        if qq is not None and qq[3] == 255:
                            s.p(x, y + d, (242, 247, 252, 255) if d == 0 else (216, 228, 242, 255))
                    break
            if crowned:                            # and on the lit tops of the leaf clumps
                for x, y in solid:
                    q = s.get(x, y)
                    if y <= reach and sum(q[:3]) >= bright and q[:3] != (242, 247, 252):
                        s.p(x, y, (236, 243, 250, 255) if r.random() < 0.8 else (214, 226, 240, 255))
    return s.done()


@lru_cache(maxsize=64)
def roof_tile_in(style: str, mask: int, variant: int = 0, snow: bool = False) -> Canvas:
    if not snow:
        return roof_tile(style, mask, variant)
    s = TR.roof(style, mask, variant)
    r = rng("roofsnow3", style, mask, variant)
    base = TR.c(TR.ROOF_STYLES.get(style, TR.ROOF_STYLES["Wooden"])[1])
    for y in range(s.h):
        for x in range(s.w):
            q = s.get(x, y)
            if q is None:
                continue
            lip = (y == s.h - 1 and not mask & S) or (x == s.w - 1 and not mask & E)
            if lip:
                continue
            dark = sum(q[:3]) < sum(base[:3]) * 0.86                  # the shingle lines show through
            s.p(x, y, (196, 208, 226, 255) if dark else ((238, 244, 250, 255) if r.random() < 0.85
                                                         else (214, 226, 240, 255)))
    return s.done()


__all__ = ["T", "N", "E", "S", "W", "ART_VERSION", "PROP_RISE", "FLOORS", "WALLS", "PROPS", "PropDef", "ROOF_STYLES",
           "OUTDOOR_FLOORS", "SOFT_FLOORS", "SPILL", "LEAFY", "SNOW_CAPPED", "floor_tile", "fringe_tile",
           "water_tile", "wall_tile", "prop_sprite", "prop_def", "prop_offset", "door_sprite", "window_tile",
           "roof_tile", "earth_tile", "ground_tile", "season_tile", "prop_sprite_in", "roof_tile_in"]
