"""Portraits in the house style (game/art/pixart.py): a person's head and shoulders, the cosy-farm way, made
medieval. 48 x 48 art pixels, doubled to 96 x 96.

Built from the same things as their map figure (game/art/folk.py): the race's body base, their look (skin,
hair, beard, eyes, clothes) and what they wear (armor, helmet, cloak), with touches of their trade (an apron,
spectacles, a straw hat...). Their mood shows in the brows, the eyes and the mouth, and a seed gives each
person small differences of their own (a wider jaw, freckles, a scar) so two people alike aren't twins.
"""
from __future__ import annotations

import random

from game.art import gear as G
from game.art.canvas import Canvas
from game.art.humanoid import BODY_BASES, Look
from game.art.pixart import Px, alpha, c, shade

A = 48
CX = 24
SIZE = A * 2

# head per body base: (half width, half height, jaw (1 square .. 0.6 pointed), eye spread, brow weight)
HEADS = {
    "human": (10, 12, 0.78, 5, 1), "half_elf": (10, 12, 0.74, 5, 1), "elf": (9, 12, 0.66, 5, 1),
    "tiefling": (10, 12, 0.72, 5, 1), "dwarf": (11, 11, 0.95, 5, 2), "halfling": (11, 11, 0.8, 5, 1),
    "gnome": (11, 11, 0.8, 5, 1), "half_orc": (11, 12, 0.95, 5, 2), "orc": (12, 12, 1.0, 6, 2),
    "hobgoblin": (11, 12, 0.9, 5, 2), "goblin": (11, 10, 0.7, 6, 1), "giant": (11, 12, 0.95, 5, 2),
    "ogre": (12, 11, 1.0, 6, 2), "dragonborn": (10, 12, 0.85, 6, 1), "kobold": (10, 11, 0.8, 6, 1),
    "lizardfolk": (10, 12, 0.85, 6, 1), "gnoll": (10, 12, 0.8, 6, 1), "skeleton": (10, 12, 0.7, 5, 0),
    "zombie": (10, 12, 0.78, 5, 1), "ghost": (10, 12, 0.74, 5, 1), "automaton": (10, 12, 0.95, 5, 1),
}
SNOUTED = {"dragonborn", "kobold", "lizardfolk", "gnoll"}
SHOULDERS = {"average": 16, "lean": 15, "small": 15, "stout": 19, "broad": 19, "giant": 19, "gaunt": 14,
             "hulking": 21}
LASH = c("#2a1a18")
WHITE = c("#f6f2ea")
GOLD = c("#e0b84a")
METAL = c("#a7b1ba")


class _P:
    """Everything about one portrait being drawn."""

    def __init__(self, look: Look, gear, ex) -> None:
        self.look = look
        self.gear = gear
        self.ex = ex
        self.rng = random.Random(ex.seed)
        self.base = BODY_BASES.get(look.base, BODY_BASES["human"])
        self.kind = look.base if look.base in HEADS else "human"
        self.feats = set(self.base.features)
        self.undead = self.base.undead
        rx, ry, jaw, eye, brow = HEADS[self.kind]
        self.rx = rx + self.rng.choice((0, 0, 0, 1)) - (1 if self.rng.random() < 0.15 else 0)
        self.ry = ry
        self.jaw = min(1.0, max(0.6, jaw + self.rng.uniform(-0.06, 0.06)))
        self.eye_dx = eye
        self.brow = brow
        self.hx, self.hy = CX, 20
        self.sex = ex.sex or ("male" if (look.beard and look.beard != "none") else
                              ("female" if self.rng.random() < 0.5 else "male"))
        self.skin = c(look.skin) if self.undead != "skeleton" else c("#e8e2cc")
        self.hair = c(look.hair_color or "#3a2a20")
        self.clothes = c(look.clothes or "#5b6b4e")
        self.style = G.ARMOR_STYLES.get(gear.armor) if gear.armor else None
        helmet = gear.helmet or (self.style.helmet if self.style and self.style.helmet else "")
        if helmet == "great_helm":
            helmet = "kettle"                      # a closed helm would hide the face we came to see
        self.helmet = helmet
        acc = ex.accessories
        self.covered = helmet in ("cap", "coif", "kettle", "horned_helm", "hood", "wizard_hat") or \
            any(a in acc for a in ("wrap", "straw_hat", "captain_hat"))
        self.s = Px(A, A)

    def half(self, y: int) -> float:
        """The head's half width on a row."""
        t = (y + 0.5 - self.hy) / self.ry
        if t < -1 or t > 1:
            return -1
        if t <= 0:
            return self.rx * (1 - t * t) ** 0.5
        round_ = (1 - t * t) ** 0.5
        return self.rx * (self.jaw + (1 - self.jaw) * round_) * (1 - t ** 6) ** 0.5

    def rows(self):
        return range(self.hy - self.ry, self.hy + self.ry + 1)


def draw(look: Look, gear=None, extras=None) -> Canvas:
    from game.art import store
    from game.art.doll import Gear
    from game.art.portrait import Extras
    gear = gear or Gear()
    ex = extras or Extras()
    look = look.resolved()
    return store.cached("face", (look, gear, ex), lambda: _draw(look, gear, ex))


def _draw(look: Look, gear, ex) -> Canvas:
    p = _P(look, gear, ex)
    out = Px(A, A)
    _backdrop(out, p)
    s = p.s
    if gear.cloak:
        _cloak_back(p)
    if not p.covered and look.hair in ("long", "braids", "mane", "wild", "curly", "ragged") and \
            p.kind not in ("dragonborn", "automaton", "skeleton"):
        _hair_back(p)
    _torso(p)
    _neck(p)
    if p.kind in SNOUTED:
        _snout_head(p)
    else:
        _ears(p, behind=True)
        _head(p)
        _face(p)
        if look.beard and look.beard != "none" and p.undead != "skeleton":
            _beard(p)
        if not p.covered and p.kind not in ("automaton", "skeleton"):
            _hair_front(p)
        _ears(p, behind=False)
    if "horns" in p.feats and p.helmet not in ("kettle", "coif", "hood"):
        _horns(p)
    if p.helmet:
        _helmet(p)
    for a in ex.accessories:
        _accessory(p, a)
    if gear.cloak:
        _cloak_front(p)
    s.outline(0.55)
    if p.undead == "ghost":
        s.map(lambda q: alpha(q, min(q[3], 200)))
    out.blit(s)
    _frame(out)
    return out.done()


# ======================================================================
def _backdrop(out: Px, p: _P) -> None:
    col = c(p.ex.backdrop) if p.ex.backdrop else _mix(p.clothes, (52, 40, 34, 255), 0.7)
    for y in range(A):
        band = y * 4 // A                           # four bands, light at the top: chunky, not smooth
        out.hline(0, A - 1, y, shade(col, 0.1 - band * 0.06))
    glow = shade(col, 0.16)
    for y in range(4, 34):                          # a soft glow behind the head
        for x in range(8, 40):
            d = ((x + 0.5 - CX) / 15) ** 2 + ((y + 0.5 - 18) / 14) ** 2
            if d < 1 and (x + y) % 2 == 0 or d < 0.7:
                out.p(x, y, glow)


def _frame(out: Px) -> None:
    edge = (30, 20, 16, 255)
    for i in range(A):
        for (x, y) in ((i, 0), (i, A - 1), (0, i), (A - 1, i)):
            out.p(x, y, edge)
    for (x, y) in ((1, 1), (A - 2, 1), (1, A - 2), (A - 2, A - 2)):
        out.p(x, y, edge)


def _mix(a, b, t):
    a, b = c(a), c(b)
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3)) + (255,)


# ---- body
def _torso(p: _P) -> None:
    s = p.s
    sw = SHOULDERS.get(p.base.build, 16)
    top = p.hy + p.ry + 3
    st = p.style
    if st is None or st.pattern == "cloth":
        base = c(p.gear.armor_tint) if (st and p.gear.armor_tint) else p.clothes
        pat = "cloth"
    else:
        base = c(p.gear.armor_tint) if p.gear.armor_tint else c(st.base)
        pat = st.pattern
    if p.undead == "skeleton" and st is None:
        base, pat = c("#4a4038"), "rags"
    for y in range(top, A):
        t = min(1.0, (y - top) / 5)
        half = int(9 + (sw - 9) * (t ** 0.6))
        s.hline(CX - half, CX + half - 1, y, base)
        s.p(CX + half - 1, y, shade(base, -0.2))
        s.p(CX - half, y, shade(base, 0.12))
    lit, dk = shade(base, 0.22), shade(base, -0.22)
    if pat in ("chain", "rings"):
        for y in range(top + 1, A):
            for x in range(CX - sw, CX + sw):
                if (x + y) % 2 == 0 and s.get(x, y) is not None:
                    s.p(x, y, dk if pat == "chain" else lit)
    elif pat == "scale":
        for y in range(top + 1, A, 2):
            for x in range(CX - sw + (y // 2) % 2, CX + sw, 2):
                if s.get(x, y) is not None:
                    s.p(x, y, lit)
                    s.p(x, y + 1, dk)
    elif pat in ("plate", "splint"):
        for side in (-1, 1):                         # pauldrons
            cx = CX + side * (sw - 4)
            s.disc(cx, top + 3, 5, 3, base)
            s.hline(cx - 3, cx + 1, top + 1, lit)
            s.hline(cx - 4, cx + 3, top + 5, dk)
        s.vline(CX - 6, top + 4, A - 1, lit)
        if pat == "splint":
            for x in range(CX - sw + 3, CX + sw - 3, 3):
                s.vline(x, top + 7, A - 1, dk)
        if st and st.trim:
            s.hline(CX - 7, CX + 6, top + 6, c(st.trim))
    elif pat == "quilted":
        for y in range(top + 3, A, 3):
            s.hline(CX - sw + 1, CX + sw - 2, y, dk)
    elif pat in ("leather", "studded", "hide"):
        s.vline(CX - 6, top + 2, A - 1, dk)          # straps
        s.vline(CX + 5, top + 2, A - 1, dk)
        if pat == "studded":
            for y in range(top + 4, A, 3):
                for x in range(CX - sw + 2, CX + sw - 2, 3):
                    s.p(x, y, c("#d8c8a0"))
        if pat == "hide":
            trim = c(st.trim) if st.trim else lit
            for x in range(CX - sw, CX + sw):
                s.p(x, top + (x % 2), trim)
                s.p(x, top + 1, trim)
    elif pat == "robe":
        trim = c(st.trim) if st.trim else lit
        s.vline(CX - 1, top + 3, A - 1, trim)
        s.vline(CX, top + 3, A - 1, trim)
    elif pat == "noble":
        trim = c(st.trim) if st and st.trim else GOLD
        s.vline(CX - 1, top + 2, A - 1, trim)
        for y in range(top + 4, A, 3):
            s.p(CX + 1, y, trim)
        s.hline(CX - 8, CX + 7, top + 2, trim)
    elif pat == "rags":
        for y in range(top + 2, A, 3):
            s.p(CX - 5 + (y % 4), y, shade(base, -0.3))
    # the collar: where the neck meets the clothes
    if pat in ("cloth", "leather", "studded", "quilted", "rags"):
        for i in range(4):                                       # an open neck: a V of skin
            s.hline(CX - 3 + i, CX + 2 - i, top + i, shade(p.skin, -0.1 - 0.03 * i))
        for i in range(5):
            s.p(CX - 4 + i, top + i, shade(base, -0.25))
            s.p(CX + 3 - i, top + i, shade(base, -0.25))
    if pat == "robe":
        s.disc(CX, top + 1, 5, 2, shade(base, -0.15))


def _neck(p: _P) -> None:
    s = p.s
    y0 = p.hy + p.ry - 3
    y1 = p.hy + p.ry + 4
    skin = p.skin
    if p.undead == "skeleton":
        for y in range(y0, y1):
            s.hline(CX - 1, CX, y, shade(skin, -0.1) if y % 2 else skin)
        return
    w = 4 if p.base.build not in ("stout", "broad", "hulking", "giant") else 5
    if "metal" in p.feats:
        s.rect(CX - w + 1, y0, CX + w - 2, y1, shade(skin, -0.25))
        for y in range(y0 + 1, y1, 2):
            s.hline(CX - w + 1, CX + w - 2, y, shade(skin, -0.1))
        return
    s.rect(CX - w, y0, CX + w - 1, y1, shade(skin, -0.06))
    s.hline(CX - w, CX + w - 1, y0 + 1, shade(skin, -0.24))     # the shadow under the chin
    s.vline(CX + w - 1, y0, y1, shade(skin, -0.2))


def _head(p: _P) -> None:
    s = p.s
    skin = p.skin
    if p.undead == "ghost":
        skin = c(p.look.skin)
    for y in p.rows():
        h = p.half(y)
        if h <= 0:
            continue
        x0, x1 = round(CX - h), round(CX + h) - 1
        s.hline(x0, x1, y, skin)
        s.p(x1, y, shade(skin, -0.16))               # the shaded side (light from the top left)
        if x1 - 1 > x0:
            s.p(x1 - 1, y, shade(skin, -0.07))
    s.disc(CX - 5, p.hy - 6, 3, 2, shade(skin, 0.1))  # forehead catching the light
    jaw_y = p.hy + p.ry - 1
    for x in range(round(CX - p.half(jaw_y)) + 1, round(CX + p.half(jaw_y)) - 1):
        s.p(x, jaw_y, shade(skin, -0.12))
    if "metal" in p.feats:
        s.vline(CX - 1, p.hy - p.ry + 1, p.hy - 4, shade(skin, -0.28))   # the seam
        s.hline(CX - 8, CX + 7, p.hy - 3, shade(skin, -0.18))
        if "rivets" in p.feats:
            for x in (CX - 8, CX + 7):
                s.p(x, p.hy - 3, shade(skin, 0.4))
    if p.undead == "zombie":
        for i in range(4):                           # a stitched gash
            s.p(CX + 4 + i, p.hy - 7 + i, shade(skin, -0.35))
            if i % 2:
                s.p(CX + 4 + i, p.hy - 8 + i, shade(skin, -0.2))
    if "scales" in p.feats or "spots" in p.feats:
        for (dx, dy) in ((-6, -6), (4, -8), (7, -2), (-8, 1), (2, -10)):
            s.p(CX + dx, p.hy + dy, shade(skin, -0.12))


def _ears(p: _P, behind: bool) -> None:
    s = p.s
    if p.helmet in ("coif", "hood", "horned_helm", "kettle") or "metal" in p.feats:
        return
    skin = p.skin
    ey = p.hy + 1
    for side in (-1, 1):
        ex = CX + side * p.rx if side > 0 else CX - p.rx - 1
        if "ears" in p.feats or "big_ears" in p.feats:
            if not behind:
                continue
            n = 7 if "big_ears" in p.feats else 5
            for i in range(n):                       # a long point sweeping up and out
                y = ey + 1 - i
                x = ex + side * (i + 1)
                s.vline(x, y, y + max(1, 3 - i // 2), skin if side < 0 else shade(skin, -0.1))
            s.p(ex + side * 2, ey, shade(skin, -0.22))
        elif "small_ears" in p.feats:
            if behind:
                continue
            s.rect(min(ex, ex + side), ey - 1, max(ex, ex + side), ey + 2, skin)
            s.p(ex + side * 2, ey - 2, skin)
            s.p(ex + side, ey, shade(skin, -0.2))
        elif p.undead != "skeleton":
            if behind:
                continue
            s.rect(min(ex, ex + side), ey - 1, max(ex, ex + side), ey + 2, skin if side < 0 else shade(skin, -0.1))
            s.p(ex + side, ey, shade(skin, -0.22))
            if "earring" in p.ex.accessories:
                s.p(ex + side, ey + 3, GOLD)


def _eye(p: _P, x0: int, y: int, side: int, iris) -> None:
    """One eye, 4 x 4: the lash line over it, the white, a big iris with its pupil and glint, the lid's shadow."""
    s = p.s
    mood = p.ex.mood
    solid = p.kind in ("tiefling",) or "lamp_eyes" in p.feats
    s.hline(x0, x0 + 3, y - 1, LASH)
    outer = x0 + 3 + 1 if side > 0 else x0 - 1
    if p.sex == "female":
        s.p(outer, y - 1, LASH)                                        # lashes flick out at the corner
        s.p(outer + side, y - 2, LASH)
    if solid:
        s.rect(x0, y, x0 + 3, y + 1, iris)
        s.p(x0 + 1, y, shade(iris, 0.55))
        s.hline(x0, x0 + 3, y + 2, shade(p.skin, -0.14))
    else:
        s.rect(x0, y, x0 + 3, y + 1, WHITE)
        ix = x0 + 1
        s.rect(ix, y, ix + 1, y + 1, iris)
        s.p(ix + 1, y + 1, shade(iris, -0.45))                         # the pupil
        s.p(ix, y, shade(iris, 0.6))                                   # the glint
        s.p(ix + 1, y, shade(iris, -0.2))
        s.hline(x0, x0 + 3, y + 2, shade(p.skin, -0.14))
    if mood == "wary":                                                 # narrowed: the lid drops
        s.hline(x0, x0 + 3, y, shade(p.skin, -0.2))
        s.hline(x0, x0 + 3, y - 1, p.skin)
        s.hline(x0, x0 + 3, y, LASH)
    elif mood == "smile" and p.rng.random() < 0.25:                    # eyes creased shut with laughing
        s.rect(x0, y - 1, x0 + 3, y + 1, p.skin)
        s.hline(x0 + 1, x0 + 2, y - 1, LASH)
        s.p(x0, y, LASH)
        s.p(x0 + 3, y, LASH)


def _face(p: _P) -> None:
    s, look = p.s, p.look
    skin = p.skin
    ey = p.hy + 1
    lx, rx = CX - p.eye_dx - 3, CX + p.eye_dx
    iris = c(look.eyes or "#4a6a8a")
    if sum(iris[:3]) < 120:                         # dark eyes still need a colour to their iris
        iris = (max(iris[0], 70), max(iris[1], 50), max(iris[2], 40), 255)
    if p.undead == "skeleton":
        for x in (lx, rx):
            s.rect(x, ey - 1, x + 3, ey + 2, c("#2a2026"))
            s.p(x + 1, ey + 1, iris)
        s.rect(CX - 1, ey + 4, CX, ey + 5, c("#3a3036"))
        for x in range(CX - 4, CX + 4):
            s.vline(x, ey + 8, ey + 9, shade(skin, -0.25) if x % 2 else skin)
        return
    if "metal" in p.feats:
        for x in (lx, rx):                          # lamp eyes, glowing
            s.rect(x, ey, x + 3, ey + 1, iris)
            s.hline(x + 1, x + 2, ey, shade(iris, 0.5))
        s.rect(CX - 4, ey + 7, CX + 3, ey + 8, shade(skin, -0.3))      # a grille for a mouth
        for x in range(CX - 3, CX + 3, 2):
            s.vline(x, ey + 7, ey + 8, shade(skin, -0.1))
        return
    _eye(p, lx, ey, -1, iris)
    _eye(p, rx, ey, 1, iris)
    # brows
    hb = shade(p.hair, -0.15) if look.hair != "none" or look.beard not in ("", "none") else shade(skin, -0.3)
    mood = p.ex.mood
    for side, x0 in ((-1, lx), (1, rx)):
        for i in range(4):
            x = x0 + i
            inner = (i == 3) if side < 0 else (i == 0)
            outer = (i == 0) if side < 0 else (i == 3)
            y = ey - 2
            if mood == "angry" and inner:
                y += 1
            elif mood == "smile" and inner:
                y -= 0
            elif mood == "wary" and outer:
                y += 1
            if mood == "smile" and outer:
                y += 1
            s.p(x, y, hb)
            if p.brow >= 2:
                s.p(x, y - 1, hb)
    # nose
    if "big_nose" in p.feats:
        s.disc(CX, ey + 5, 2.2, 1.8, shade(skin, -0.04))
        s.p(CX - 1, ey + 4, shade(skin, 0.15))
        s.hline(CX - 1, CX + 1, ey + 6, shade(skin, -0.25))
    else:
        s.p(CX, ey + 3, shade(skin, -0.12))
        s.p(CX, ey + 4, shade(skin, -0.18))
        s.p(CX - 1, ey + 5, shade(skin, -0.2))
        s.p(CX - 1, ey + 3, shade(skin, 0.12))
    # cheeks
    if p.undead not in ("zombie", "ghost"):
        blush = (min(255, skin[0] + 20), max(0, skin[1] - 22), max(0, skin[2] - 18), 255)
        for x in (lx, rx + 2):
            s.hline(x, x + 1, ey + 4, blush)
    if p.rng.random() < 0.18 and p.kind in ("human", "halfling", "half_elf", "gnome", "dwarf"):
        for (dx, dy) in ((-6, 4), (-4, 5), (5, 4), (7, 5)):          # freckles
            s.p(CX + dx, ey + dy, shade(skin, -0.16))
    if p.rng.random() < 0.08:
        for i in range(3):                                            # an old scar
            s.p(CX + 5 + i, ey - 3 + i, shade(skin, -0.2))
    # mouth
    my = ey + 7
    lip = shade(skin, -0.32)
    if mood == "smile":
        s.hline(CX - 2, CX + 1, my, lip)
        s.p(CX - 3, my - 1, lip)
        s.p(CX + 2, my - 1, lip)
    elif mood == "angry":
        s.hline(CX - 2, CX + 1, my, lip)
        s.p(CX - 3, my + 1, lip)
        s.p(CX + 2, my + 1, lip)
    elif mood == "wary":
        s.hline(CX - 1, CX + 1, my, lip)
    else:
        s.hline(CX - 2, CX + 1, my, lip)
    if p.sex == "female" and mood != "angry":
        s.hline(CX - 1, CX, my + 1, _mix(skin, (190, 80, 90, 255), 0.35))
    if "tusks" in p.feats or "tusks_small" in p.feats:
        tusk = c("#eee8d2")
        for x in (CX - 3, CX + 2):
            s.p(x, my, tusk)
            s.p(x, my - 1, tusk)
            if "tusks" in p.feats:
                s.p(x, my - 2, tusk)
    if p.undead == "zombie":
        s.p(CX, my + 1, c("#6a3030"))


def _beard(p: _P) -> None:
    s = p.s
    beard = p.look.beard
    hair = p.hair
    ey = p.hy + 1
    if beard == "stubble":
        for y in range(ey + 6, p.hy + p.ry):
            h = p.half(y)
            for x in range(round(CX - h) + 1, round(CX + h) - 1):
                if (x + y) % 2 == 0:
                    s.p(x, y, _mix(p.skin, hair, 0.35))
        return
    length = {"short": 1, "full": 4, "braided": 5}.get(beard, 2)
    top = ey + 5
    for y in range(top, p.hy + p.ry + length):
        h = p.half(min(y, p.hy + p.ry - 1)) if y < p.hy + p.ry else max(2, p.half(p.hy + p.ry - 1) - (y - p.hy - p.ry) * 2)
        if h <= 0:
            continue
        side_only = y < ey + 7
        x0, x1 = round(CX - h), round(CX + h) - 1
        if side_only:
            s.hline(x0, x0 + 2, y, hair)
            s.hline(x1 - 2, x1, y, shade(hair, -0.12))
        else:
            s.hline(x0, x1, y, hair)
            s.p(x1, y, shade(hair, -0.2))
    s.hline(CX - 4, CX + 3, ey + 6, hair)                 # the moustache
    s.hline(CX - 2, CX + 1, ey + 7, shade(p.skin, -0.35))  # the mouth shows through
    for y in range(ey + 9, p.hy + p.ry + length, 2):       # strands
        s.p(CX - 3 + (y % 3), y, shade(hair, -0.18))
        s.p(CX + 2 - (y % 3), y, shade(hair, 0.15))
    if beard == "braided":
        for y in range(p.hy + p.ry, p.hy + p.ry + length + 3):
            s.hline(CX - 1, CX, y, shade(hair, -0.15) if y % 2 else hair)
        s.hline(CX - 1, CX, p.hy + p.ry + length + 3, c("#c8a050"))


def _hair_back(p: _P) -> None:
    s, hair = p.s, p.hair
    style = p.look.hair
    dk = shade(hair, -0.18)
    if style == "mane":
        s.disc(CX, p.hy, p.rx + 5, p.ry + 4, dk)
        return
    if style in ("long", "ragged", "braids"):
        bottom = A - 1 if style != "braids" else p.hy + p.ry + 2
        for y in range(p.hy - 6, bottom + 1):
            w = p.rx + 2 + min(3, max(0, y - p.hy) // 4)
            s.hline(CX - w, CX + w - 1, y, dk if y > p.hy else hair)
        if style == "ragged":
            for x in range(CX - p.rx - 4, CX + p.rx + 4, 2):
                s.clear(x, bottom)
    elif style in ("wild", "curly"):
        r = 4 if style == "wild" else 2
        s.disc(CX, p.hy - 2, p.rx + r, p.ry + r - 2, dk)


def _hair_front(p: _P) -> None:
    s, look = p.s, p.look
    style = look.hair or "none"
    hair = p.hair
    lit, dk = shade(hair, 0.24), shade(hair, -0.2)
    top = p.hy - p.ry
    if style == "none":
        s.hline(CX - 6, CX - 3, top + 2, shade(p.skin, 0.25))       # the shine on a bald head
        return
    if style in ("mohawk",):
        for y in range(top - 3, p.hy - 2):
            s.hline(CX - 2, CX + 1, y, hair)
        s.vline(CX - 2, top - 3, p.hy - 3, lit)
        return

    def cap(line: int, swell: int = 1) -> None:
        """Hair over the crown down to a hairline `line` rows below the top of the head."""
        for y in range(top - swell, top + line):
            h = p.half(max(y, top)) + swell
            if h <= 0:
                continue
            s.hline(round(CX - h), round(CX + h) - 1, y, hair)
            s.p(round(CX + h) - 1, y, dk)
        for x in range(CX - 7, CX - 2):                               # a band of shine
            s.p(x, top + 1 + (x - CX + 7) // 3, lit)

    if style in ("short", "ponytail", "braids", "bun", "topknot"):
        cap(7, 1)
        for x in range(CX - p.rx + 2, CX + p.rx - 2):                 # the fringe: a swept edge
            k = (x - (CX - p.rx)) % 5
            s.p(x, top + 7 + (1 if k in (1, 2) else 0), hair if k != 4 else dk)
        for side in (-1, 1):                                          # down past the temples
            x = CX - p.rx if side < 0 else CX + p.rx - 1
            s.vline(x, top + 5, p.hy + 1, hair if side < 0 else dk)
            s.vline(x - side, top + 6, p.hy - 1, hair if side < 0 else dk)
        if style == "bun":
            s.disc(CX, top - 3, 4, 3, hair)
            s.hline(CX - 2, CX, top - 5, lit)
        elif style == "topknot":
            s.disc(CX, top - 3, 2.5, 2.5, hair)
            s.vline(CX, top - 7, top - 4, dk)
        elif style == "ponytail":
            s.rect(CX + p.rx - 1, p.hy - 2, CX + p.rx + 1, p.hy + 6, hair)
            s.p(CX + p.rx, p.hy - 2, c("#a83a3a"))
        elif style == "braids":
            for side in (-1, 1):
                x = CX - p.rx - 1 if side < 0 else CX + p.rx - 1
                for y in range(p.hy + 2, p.hy + p.ry + 8):
                    s.hline(x, x + 1, y, hair if y % 3 else dk)
                s.hline(x, x + 1, p.hy + p.ry + 8, c("#c8a050"))
    elif style in ("long", "ragged"):
        cap(6, 1)
        for x in range(CX - 3, CX + p.rx):                            # parted, swept to one side
            s.p(x, top + 6 + (x - CX + 3) // 4, hair)
        for side in (-1, 1):
            x0 = CX - p.rx - 1 if side < 0 else CX + p.rx - 2
            for y in range(top + 4, p.hy + p.ry + 6):
                s.hline(x0, x0 + 2, y, hair if side < 0 else dk)
    elif style == "curly":
        cap(6, 2)
        for a in range(-p.rx, p.rx + 1, 3):
            s.disc(CX + a, top + 6, 1.6, 1.6, hair)
            s.p(CX + a - 1, top + 5, lit)
        for side in (-1, 1):
            s.disc(CX + side * (p.rx + 1), p.hy - 1, 2, 3, hair)
    elif style == "wild":
        cap(6, 3)
        for (dx, dy) in ((-13, -6), (12, -8), (-8, -15), (7, -15), (0, -16), (14, -1), (-14, 0)):
            s.disc(CX + dx, p.hy + dy, 2, 1.6, hair)
        for x in range(CX - p.rx, CX + p.rx, 3):
            s.vline(x, top + 5, top + 7, hair)
    elif style == "mane":
        cap(5, 3)


def _snout_head(p: _P) -> None:
    """Dragonborn, kobolds, lizardfolk and gnolls: a long head with a muzzle toward you."""
    s, look = p.s, p.look
    skin = p.skin
    accent = c(look.accent or p.base.accent or shade(skin, 0.3))
    gnoll = p.kind == "gnoll"
    hy, rx, ry = p.hy - 2, p.rx, p.ry - 1
    s.disc(CX, hy, rx, ry, skin)                         # the skull
    s.disc(CX, hy + 7, rx - 3, 5, skin)                   # the muzzle
    s.disc(CX, hy + 8, rx - 5, 3.5, shade(skin, 0.14) if not gnoll else c("#3a2e28"))
    for y in range(hy - ry, hy + 13):
        x = None
        for xx in range(A - 1, -1, -1):
            q = s.get(xx, y)
            if q is not None and q[:3] in (skin[:3], shade(skin, 0.14)[:3]):
                x = xx
                break
        if x is not None:
            s.p(x, y, shade(skin, -0.18))
    s.disc(CX - 4, hy - 5, 3, 2, shade(skin, 0.12))
    for side in (-1, 1):                                  # eyes set wide, on the sides of the head
        x0 = CX + side * (rx - 4) - (3 if side < 0 else 0)
        iris = c(look.eyes or "#f2c14e")
        s.hline(x0, x0 + 3, hy - 1, LASH)
        s.hline(x0, x0 + 3, hy, iris)
        s.p(x0 + 2 if side < 0 else x0 + 1, hy, c("#1a1418"))
        s.p(x0 + 1 if side < 0 else x0 + 2, hy, shade(iris, 0.5))
        brow_y = hy - 3 if p.ex.mood != "angry" else hy - 2
        s.hline(x0, x0 + 3, brow_y, shade(skin, -0.3))
    s.p(CX - 2, hy + 6, c("#1a1418"))                     # nostrils
    s.p(CX + 1, hy + 6, c("#1a1418"))
    mouth = hy + 10
    s.hline(CX - 4, CX + 3, mouth, shade(skin, -0.4))
    if p.ex.mood == "angry" or gnoll:
        for x in (CX - 3, CX + 2):
            s.p(x, mouth + 1, c("#eee8d2"))
    if p.ex.mood == "smile":
        s.p(CX - 5, mouth - 1, shade(skin, -0.4))
        s.p(CX + 4, mouth - 1, shade(skin, -0.4))
    if p.kind == "dragonborn" or "frills" in p.feats:
        for side in (-1, 1):                             # horns swept back
            for i in range(6):
                s.vline(CX + side * (5 + i // 2), hy - ry - i + 2, hy - ry - i + 3, accent)
        for (dx, dy) in ((-6, -2), (5, -3), (-3, 3), (6, 2)):
            s.p(CX + dx, hy + dy, shade(skin, -0.12))
    elif "crest" in p.feats:
        for i in range(5):
            s.hline(CX - 1, CX, hy - ry - 1 - i, accent)
    elif "small_horns" in p.feats:
        for side in (-1, 1):
            s.rect(CX + side * 5 - (1 if side < 0 else 0), hy - ry - 1, CX + side * 5 + (0 if side < 0 else 1),
                   hy - ry + 1, accent)
    if gnoll:
        for side in (-1, 1):                             # round ears and a ruff of mane
            s.disc(CX + side * (rx - 1), hy - ry + 1, 2.5, 2.5, skin)
            s.p(CX + side * (rx - 1), hy - ry + 1, shade(skin, -0.3))
        for x in range(CX - 2, CX + 2):
            s.vline(x, hy - ry - 2, hy - ry + 2, p.hair)
        if "spots" in p.feats:
            for (dx, dy) in ((-7, 0), (6, -2), (-5, 5), (7, 4)):
                s.p(CX + dx, hy + dy, shade(skin, -0.25))


def _horns(p: _P) -> None:
    s = p.s
    col = shade(c(p.look.accent or "#3a2a2e"), 0.35)
    top = p.hy - p.ry
    path = [(5, 5, 3), (6, 3, 3), (7, 1, 3), (8, -1, 2), (9, -3, 2), (10, -4, 2), (11, -5, 1), (12, -5, 1),
            (13, -4, 1)]
    for side in (-1, 1):
        for i, (dx, dy, w) in enumerate(path):       # thick at the root, sweeping up and out, curling back
            x = CX + side * dx - (1 if side < 0 else 0)
            for k in range(w):
                s.p(x, top + dy + k, col if side < 0 else shade(col, -0.12))
                if w > 1:
                    s.p(x - side, top + dy + k, col)
            if i % 2 == 0:
                s.p(x, top + dy, shade(col, 0.3))    # ridges catching the light


def _helmet(p: _P) -> None:
    s = p.s
    h = p.helmet
    top = p.hy - p.ry
    tint = c(p.gear.helmet_tint) if p.gear.helmet_tint else None
    if h in ("kettle", "horned_helm", "cap"):
        col = tint or (c("#7a5232") if h == "cap" else METAL)
        lit, dk = shade(col, 0.3), shade(col, -0.25)
        for y in range(top - 2, top + 8):
            hh = p.half(max(y, top)) + 1
            s.hline(round(CX - hh), round(CX + hh) - 1, y, col)
            s.p(round(CX + hh) - 1, y, dk)
        s.hline(CX - 7, CX - 3, top, lit)
        s.vline(CX - 6, top - 1, top + 5, lit)
        if h == "kettle":
            s.hline(CX - p.rx - 4, CX + p.rx + 3, top + 8, col)       # the broad brim
            s.hline(CX - p.rx - 4, CX + p.rx + 3, top + 9, dk)
            s.hline(CX - p.rx - 3, CX - 2, top + 8, lit)
        else:
            s.hline(CX - p.rx - 1, CX + p.rx, top + 8, dk)
            for x in range(CX - p.rx, CX + p.rx, 3):
                s.p(x, top + 8, lit)                                   # rivets on the rim
        if h == "horned_helm":
            bone = c("#e8e2cc")
            for side in (-1, 1):
                for i in range(7):
                    x = CX + side * (p.rx + 1 + i // 2)
                    y = top + 4 - i
                    s.rect(min(x, x + side), y, max(x, x + side), y, bone if i < 5 else shade(bone, -0.2))
    elif h == "coif":
        col = tint or METAL
        for y in range(top - 1, A):
            hh = (p.half(min(max(y, top), p.hy + p.ry - 1)) + 2) if y < p.hy + p.ry + 2 else 14
            s.hline(round(CX - hh), round(CX + hh) - 1, y, col)
        for y in range(top - 1, A):
            for x in range(A):
                q = s.get(x, y)
                if q is not None and q[:3] == col[:3] and (x + y) % 2 == 0:
                    s.p(x, y, shade(col, -0.22))
        fx = p.rx - 3                                                   # the face shows through its window
        for y in range(top + 6, p.hy + p.ry - 1):
            hh = min(fx, p.half(y) - 2)
            if hh > 0:
                s.hline(round(CX - hh), round(CX + hh) - 1, y, p.skin)
        _face(p)
        if p.look.beard and p.look.beard != "none":
            _beard(p)
    elif h == "hood":
        col = c(p.gear.cloak_color) if p.gear.cloak else (tint or shade(p.clothes, -0.12))
        for y in range(top - 3, A):
            hh = p.half(min(max(y, top), p.hy + p.ry - 1)) + 3 if y < p.hy + p.ry else 15
            s.hline(round(CX - hh), round(CX + hh) - 1, y, col)
            s.p(round(CX + hh) - 1, y, shade(col, -0.2))
        s.hline(CX - 8, CX - 3, top - 1, shade(col, 0.2))
        for y in range(top + 5, p.hy + p.ry):                          # the face within, a shadow at its top
            hh = p.half(y) - 1.5
            if hh > 0:
                s.hline(round(CX - hh), round(CX + hh) - 1, y, p.skin)
        s.hline(CX - p.rx + 2, CX + p.rx - 3, top + 5, shade(p.skin, -0.35))
        s.hline(CX - p.rx + 3, CX + p.rx - 4, top + 6, shade(p.skin, -0.18))
        _face(p)
        if p.look.beard and p.look.beard != "none":
            _beard(p)
    elif h == "wizard_hat":
        col = tint or (c(p.gear.armor_tint) if p.gear.armor_tint else c("#3b2f6a"))
        s.hline(CX - p.rx - 5, CX + p.rx + 4, top + 4, shade(col, -0.18))
        s.hline(CX - p.rx - 4, CX + p.rx + 3, top + 3, col)
        for i in range(14):
            half = max(1, 8 - i // 2)
            lean = (i * i) // 28
            y = top + 2 - i
            s.hline(CX - half + lean, CX + half - 1 + lean, y, col)
            s.p(CX - half + lean, y, shade(col, 0.2))
            s.p(CX + half - 1 + lean, y, shade(col, -0.2))
        s.hline(CX - 7, CX + 6, top + 1, GOLD)
        s.p(CX - 3, top - 4, GOLD)
        s.p(CX + 2, top - 8, shade(GOLD, 0.3))
    elif h in ("crown", "circlet"):
        y = top + 4
        hh = p.half(y) + 1
        s.hline(round(CX - hh), round(CX + hh) - 1, y, GOLD)
        s.hline(round(CX - hh), round(CX + hh) - 1, y + 1, shade(GOLD, -0.25))
        if h == "crown":
            for x in range(round(CX - hh), round(CX + hh), 4):
                s.vline(x, y - 3, y, GOLD)
                s.p(x, y - 4, shade(GOLD, 0.35))
            s.rect(CX - 1, y, CX, y + 1, c("#d03a4a"))
            s.p(CX - 6, y, c("#4ab0e0"))
            s.p(CX + 5, y, c("#4ac080"))
        else:
            s.rect(CX - 1, y, CX, y + 1, c("#4ab0e0"))
            s.p(CX - 1, y, c("#c8f0ff"))


def _accessory(p: _P, a: str) -> None:
    s = p.s
    top = p.hy - p.ry
    ey = p.hy + 1
    neck_y = p.hy + p.ry + 4
    if a == "spectacles":
        frame = c("#c8a050")
        for x in (CX - p.eye_dx - 4, CX + p.eye_dx - 1):
            s.hline(x, x + 5, ey - 1, frame)
            s.hline(x, x + 5, ey + 3, frame)
            s.vline(x, ey - 1, ey + 3, frame)
            s.vline(x + 5, ey - 1, ey + 3, frame)
            s.put(x + 1, ey, (220, 240, 255, 80))
        s.hline(CX - 1, CX, ey, frame)
    elif a == "goggles":
        band = c("#5a3a22")
        y = top + 5
        hh = p.half(y) + 1
        s.hline(round(CX - hh), round(CX + hh) - 1, y + 1, band)
        for x in (CX - 8, CX + 2):
            s.rect(x, y - 1, x + 5, y + 3, c("#c8a050"))
            s.rect(x + 1, y, x + 4, y + 2, c("#6ab8c8"))
            s.p(x + 1, y, c("#e8f8ff"))
    elif a == "straw_hat":
        col = c("#e0c070")
        s.hline(CX - p.rx - 6, CX + p.rx + 5, top + 5, col)
        s.hline(CX - p.rx - 5, CX + p.rx + 4, top + 6, shade(col, -0.2))
        for y in range(top - 3, top + 5):
            s.hline(CX - 8, CX + 7, y, col if y % 2 else shade(col, -0.08))
        s.hline(CX - 8, CX + 7, top + 3, c("#a83a3a"))
        s.hline(CX - 6, CX - 2, top - 2, shade(col, 0.3))
    elif a == "captain_hat":
        col = c("#2a2a3a")
        for y in range(top - 3, top + 5):
            w = 13 if y > top else 10
            s.hline(CX - w, CX + w - 1, y, col)
        s.hline(CX - 14, CX + 13, top + 5, shade(col, -0.2))
        s.hline(CX - 13, CX + 12, top + 1, GOLD)
        s.disc(CX, top - 1, 2, 1.5, c("#f0f0f0"))
    elif a == "wrap":
        col = shade(p.clothes, 0.35)
        for y in range(top - 2, top + 7):
            hh = p.half(max(y, top)) + 2
            s.hline(round(CX - hh), round(CX + hh) - 1, y, col if (y // 2) % 2 else shade(col, -0.12))
        s.disc(CX + 6, top + 6, 2.5, 2, shade(col, -0.1))
    elif a == "apron":
        y0 = neck_y + 2
        s.rect(CX - 7, y0, CX + 6, A - 1, c("#7a5a3a"))
        s.rect(CX - 6, y0 + 1, CX + 5, A - 1, shade(c("#8a6a46"), 0.05))
        s.vline(CX - 8, neck_y - 1, y0, c("#5a3a22"))
        s.vline(CX + 7, neck_y - 1, y0, c("#5a3a22"))
        s.hline(CX - 4, CX + 3, y0 + 4, shade(c("#8a6a46"), -0.2))   # a pocket
    elif a == "holy_symbol":
        y = neck_y + 5
        s.line(CX - 5, neck_y + 1, CX - 1, y - 1, GOLD)
        s.line(CX + 4, neck_y + 1, CX, y - 1, GOLD)
        s.vline(CX - 1, y, y + 4, GOLD)
        s.hline(CX - 3, CX + 1, y + 1, GOLD)
        s.p(CX - 1, y, shade(GOLD, 0.4))
    elif a == "tabard":
        col = c(p.ex.tabard) if p.ex.tabard else c("#3a4a6a")
        y0 = neck_y + 3
        s.rect(CX - 8, y0, CX + 7, A - 1, col)
        s.vline(CX + 7, y0, A - 1, shade(col, -0.2))
        s.disc(CX, y0 + 6, 3, 3, GOLD)                                 # a device on it
        s.p(CX - 1, y0 + 5, shade(GOLD, 0.35))
    elif a == "earring":
        pass                                                          # drawn with the ears


def _cloak_back(p: _P) -> None:
    s = p.s
    col = c(p.gear.cloak_color or "#7a2a2a")
    top = p.hy + p.ry
    for y in range(top, A):
        s.hline(CX - 22, CX + 21, y, shade(col, -0.2))


def _cloak_front(p: _P) -> None:
    s = p.s
    col = c(p.gear.cloak_color or "#7a2a2a")
    top = p.hy + p.ry + 3
    sw = SHOULDERS.get(p.base.build, 16)
    for side in (-1, 1):                                              # falling over each shoulder
        for y in range(top, A):
            t = y - top
            x0 = CX + side * (sw - 6 + t // 3)
            x1 = CX + side * (sw + 3)
            s.hline(min(x0, x1), max(x0, x1), y, col if side < 0 else shade(col, -0.15))
        s.hline(CX + side * (sw - 6), CX + side * (sw + 2), top, shade(col, 0.2))
    if p.gear.cloak == "fur_cloak":
        fur = c("#e8dcc4")
        for x in range(CX - sw - 2, CX + sw + 2):
            s.vline(x, top - 1 + (x % 2), top + 2, fur if x % 3 else shade(fur, -0.15))
    s.disc(CX - 8, top + 3, 1.6, 1.6, GOLD)                          # the clasp
    s.p(CX - 9, top + 2, shade(GOLD, 0.4))


__all__ = ["draw", "SIZE", "HEADS", "SNOUTED"]
