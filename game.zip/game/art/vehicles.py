"""What the party rides in, in the house style (game/art/pixart.py), seen side-on like the people and the
beasts: a sailing ship, an airship, a covered wagon and its horse, a cart and its horse, a saddled horse and a
rowboat. Each faces west and carries its other facings in `views` (east mirrored; north and south side-on),
so the map shows it the way it's going.

The walking map draws whichever carries the party in the party's place (ui/explore_view.py): centred on the
party's square, its bottom on the square's bottom, sunk SINK screen pixels lower (a hull sits in the water).
The party itself isn't drawn while it's aboard or mounted.
"""
from __future__ import annotations

from functools import lru_cache

from game.art.canvas import Canvas
from game.art.pixart import Px, alpha, c, shade

WOOD, WOOD_D, WOOD_L = c("#8a5432"), c("#5e3820"), c("#b07a48")
SAIL, SAIL_D = c("#ece2c8"), c("#c8b898")
IRON = c("#5e626e")
SINK = {"ship": 14, "rowboat": 6, "wagon": 0, "cart": 0, "horse": 0, "airship": 0}


def _horse(s: Px, x: int, ground: int, coat=None, saddle=None, step: int = 0, harness: bool = False) -> None:
    """A horse side-on, facing west, its hooves on `ground`, its rump at x + 15."""
    coat = c(coat or "#7a4e30")
    dark = shade(coat, -0.25)
    walk = {0: 0, 1: 1, 2: -1}[step]
    # far legs
    for lx in (x + 3 - walk, x + 12 + walk):
        s.rect(lx, ground - 6, lx + 1, ground, dark)
    # tail
    s.rect(x + 15, ground - 11, x + 16, ground - 5, shade(coat, -0.45))
    s.p(x + 16, ground - 4, shade(coat, -0.45))
    # body
    s.disc(x + 8.5, ground - 9, 8, 3.6, dark)
    s.disc(x + 8.2, ground - 9.5, 7.4, 3, coat)
    s.hline(x + 4, x + 10, ground - 12, shade(coat, 0.2))
    # near legs
    for lx in (x + 2 + walk, x + 11 - walk):
        s.rect(lx, ground - 6, lx + 1, ground, coat)
        s.hline(lx, lx + 1, ground, c("#2a2224"))
    # neck and head, out to the west
    s.poly([(x + 3, ground - 12), (x + 5, ground - 9), (x, ground - 16), (x - 2, ground - 15)], coat)
    s.disc(x - 2, ground - 15.5, 2.4, 1.6, coat)
    s.disc(x - 3.6, ground - 14.8, 1.5, 1.1, shade(coat, 0.1))
    s.p(x - 5, ground - 15, c("#1a1418"))
    s.p(x - 1.5, ground - 16.5, c("#1a1418"))                  # its eye
    s.p(x, ground - 18, coat)                                  # an ear
    for i in range(5):                                         # the mane
        s.p(x + i * 0.8, ground - 17 + i * 1.1, shade(coat, -0.45))
    if saddle:
        sc = c(saddle)
        s.rect(x + 6, ground - 13, x + 10, ground - 11, sc)
        s.hline(x + 6, x + 10, ground - 13, shade(sc, 0.25))
        s.vline(x + 8, ground - 11, ground - 7, shade(sc, -0.3))  # the girth
        s.p(x + 8, ground - 6, c("#c8c8c8"))                   # a stirrup
    if harness:
        s.line(x + 4, ground - 12, x + 15, ground - 9, c("#3a2618"))
        s.hline(x + 1, x + 4, ground - 13, c("#3a2618"))


def _wheel(s: Px, cx: float, cy: float, r: float, step: int = 0) -> None:
    s.disc(cx, cy, r, r, WOOD_D)
    for y in range(int(cy - r) - 1, int(cy + r) + 2):
        for x in range(int(cx - r) - 1, int(cx + r) + 2):
            if ((x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2) < (r - 1.2) ** 2:
                s.clear(x, y)
    spin = step % 2
    for (dx, dy) in (((1, 0), (0, 1)) if not spin else ((1, 1), (1, -1))):
        s.line(round(cx - dx * (r - 1)), round(cy - dy * (r - 1)), round(cx + dx * (r - 1)), round(cy + dy * (r - 1)),
               WOOD)
    s.p(cx, cy, IRON)


def ship(step: int = 0) -> Px:
    """A two-masted ship, 64 x 48 art pixels, the bow to the west; its deck at row 32."""
    s = Px(64, 48)
    deck = 32
    # masts and sails behind the rail
    for mx, top, sw in ((22, 3, 9), (40, 6, 8)):
        s.rect(mx, top, mx + 1, deck, WOOD_D)
        for yy, w in ((top + 3, sw), (top + 12, sw + 2)):
            s.rect(mx - w, yy, mx + w + 1, yy + 7, SAIL)
            s.hline(mx - w, mx + w + 1, yy, SAIL_D)
            s.rect(mx + w - 1, yy + 1, mx + w + 1, yy + 7, SAIL_D)    # the belly of the sail in shade
            s.hline(mx - w - 1, mx + w + 2, yy - 1, WOOD_D)          # the yard
        flag = c("#a8342e")
        s.rect(mx + 2, top, mx + 6, top + 2, flag)
    s.line(4, 26, 22, 3, c("#8a7a6a"))                              # the stays
    s.line(40, 6, 58, 24, c("#8a7a6a"))
    # the hull
    hull = [(2, 24), (10, 31), (54, 31), (60, 21), (63, 21), (60, 37), (50, 43), (14, 43), (4, 34)]
    s.poly(hull, WOOD)
    s.poly([(4, 34), (14, 43), (50, 43), (60, 37), (60, 39), (50, 45), (14, 45), (3, 36)], WOOD_D)
    for y in (35, 39):                                             # its strakes
        s.hline(8, 57, y, shade(WOOD, -0.15))
    s.hline(6, 58, deck - 1, WOOD_L)                               # the rail
    s.hline(52, 62, 21, WOOD_L)                                    # the stern castle's rail
    for x in range(14, 50, 7):
        s.rect(x, 36, x + 2, 37, c("#2a1e1a"))                     # gunports
    s.rect(54, 24, 59, 30, shade(WOOD, -0.1))
    s.rect(55, 25, 58, 27, c("#e8d080"))                           # a lit stern window
    s.line(2, 24, -2, 22, WOOD_D)                                  # the bowsprit
    s.poly([(2, 24), (6, 26), (5, 29), (2, 27)], c("#d8b04a"))     # a figurehead
    s.outline(0.5)
    return s


def rowboat(step: int = 0) -> Px:
    s = Px(32, 24)
    hull = [(2, 14), (8, 19), (26, 19), (30, 14), (27, 22), (6, 22)]
    s.poly(hull, WOOD)
    s.poly([(6, 22), (27, 22), (28, 20), (5, 20)], WOOD_D)
    s.hline(3, 29, 14, WOOD_L)
    s.hline(4, 28, 17, shade(WOOD, -0.15))
    oar = {0: 0, 1: -2, 2: 2}[step]
    s.line(14 + oar, 11, 9 - oar, 23, c("#c8a070"))               # the oar
    s.rect(8 - oar, 22, 10 - oar, 23, c("#c8a070"))
    s.outline(0.5)
    return s


def airship(step: int = 0) -> Px:
    s = Px(64, 48)
    env = c("#c84a3a")
    s.disc(32, 13, 28, 11, shade(env, -0.25))                     # the envelope
    s.disc(31, 12, 27, 10, env)
    for x in range(10, 56, 8):                                    # its gores
        s.vline(x, 4, 22, shade(env, -0.12))
    s.disc(22, 7, 10, 3, shade(env, 0.25))
    s.poly([(58, 9), (64, 4), (64, 18), (58, 15)], shade(env, -0.18))   # its fins
    for x in (18, 32, 46):                                        # the rigging
        s.line(x, 22, x - 2 + (x - 32) // 6, 34, c("#8a7a6a"))
    gondola = [(14, 34), (50, 34), (46, 42), (18, 42)]
    s.poly(gondola, WOOD)
    s.hline(14, 50, 34, WOOD_L)
    s.hline(18, 46, 41, WOOD_D)
    for x in range(20, 46, 6):
        s.rect(x, 36, x + 2, 38, c("#e8d080"))                     # its windows
    prop = {0: 0, 1: 1, 2: -1}[step]
    s.vline(53, 33 - prop, 41 + prop, c("#a7b1ba"))               # the propeller
    s.hline(50, 53, 37, IRON)
    s.outline(0.5)
    return s


def wagon(step: int = 0) -> Px:
    s = Px(48, 32)
    ground = 30
    _horse(s, 4, ground, "#7a4e30", step=step, harness=True)
    s.rect(22, 14, 46, 23, WOOD)                                  # the bed
    s.hline(22, 46, 14, WOOD_L)
    s.hline(22, 46, 23, WOOD_D)
    cover = c("#e8dcc0")
    for x in range(22, 47):                                       # the canvas cover on its hoops
        top = 4 + round(((x - 34) / 12.5) ** 2 * 6)
        s.vline(x, top, 14, cover)
    for x in range(24, 46, 5):
        s.vline(x, 5, 14, shade(cover, -0.15))
    s.disc(34, 6, 6, 2, shade(cover, 0.1))
    s.line(16, 18, 22, 19, WOOD_D)                                # the shaft to the horse
    _wheel(s, 27, 25, 4.5, step)
    _wheel(s, 41, 25, 4.5, step + 1)
    s.outline(0.5)
    return s


def cart(step: int = 0) -> Px:
    s = Px(40, 28)
    ground = 26
    _horse(s, 4, ground, "#9a6a42", step=step, harness=True)
    s.rect(21, 14, 38, 20, WOOD)
    s.hline(21, 38, 14, WOOD_L)
    s.hline(21, 38, 20, WOOD_D)
    for x in (25, 30, 35):
        s.vline(x, 15, 19, WOOD_D)
    s.rect(23, 9, 28, 13, c("#c8a060"))                           # sacks and a crate in it
    s.disc(33, 11, 3, 2.4, c("#d8c8a0"))
    s.line(15, 17, 21, 17, WOOD_D)
    _wheel(s, 30, 22, 4, step)
    s.outline(0.5)
    return s


def horse(step: int = 0) -> Px:
    s = Px(26, 24)
    _horse(s, 6, 23, "#6a4228", saddle="#8a2a2a", step=step)
    s.outline(0.5)
    return s


DRAW = {"ship": ship, "airship": airship, "wagon": wagon, "cart": cart, "horse": horse, "rowboat": rowboat}


@lru_cache(maxsize=16)
def draw(kind: str) -> Canvas:
    """The vessel facing west, with .views for the other facings and .steps (rocking, rolling, walking)."""
    if kind not in DRAW:
        return Canvas(32)
    from game.art import store
    return store.cached("vehicle", kind, lambda: _draw(kind))


def _draw(kind: str) -> Canvas:
    fn = DRAW.get(kind)
    if fn is None:
        return Canvas(32)
    frames = [fn(st) for st in (0, 1, 2)]
    west = [f.done() for f in frames]
    east = [f.flipped().done() for f in frames]
    art = west[0]
    art.views = {0: west[0], 1: west[0], 2: east[0], 3: east[0]}
    art.steps = {0: west[1:], 1: west[1:], 2: east[1:], 3: east[1:]}
    return art


__all__ = ["draw", "DRAW", "SINK"]
