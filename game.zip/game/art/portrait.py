"""Head-and-shoulders portraits of people (party members, townsfolk, and enemies with a face): who gets one,
what they wear for it, and the mood it shows. The drawing is in the house style (game/art/faces.py): built
from the race's body base, the person's look (skin, hair, beard, eyes, clothes) and what they wear (armor,
helmet, cloak), plus a few touches of their trade (a smith's apron, a scholar's spectacles, a farmer's straw
hat). Each person gets small differences of their own from a seed, so two people alike still aren't twins.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from game.art.canvas import Canvas
from game.art.doll import Gear
from game.art.humanoid import Look

SIZE = 96                     # portraits are 48 x 48 art pixels, doubled
HUMANOID = {"human", "elf", "half_elf", "dwarf", "halfling", "gnome", "dragonborn", "tiefling", "half_orc",
            "goblin", "hobgoblin", "orc", "kobold", "gnoll", "lizardfolk", "giant", "ogre", "skeleton", "zombie",
            "ghost", "automaton"}


@dataclass
class Extras:
    """What the portrait adds beyond the look and the gear."""
    sex: str = ""                    # "female" / "male" ("" guesses from the beard)
    mood: str = "neutral"           # "smile", "neutral", "wary", "angry"
    accessories: list[str] = field(default_factory=list)   # apron, spectacles, straw_hat, captain_hat,
    # goggles, wrap, holy_symbol, earring, tabard
    tabard: str = ""                 # tabard color over armor (guards)
    seed: int = 0
    backdrop: str = ""               # background color ("" from the clothes)


RULERS = ("king", "queen", "jarl", "doge", "khan", "khatun", "sultan", "sultana", "mansa", "sky-thane",
          "high warden", "jade prince", "jade princess", "high chief", "ruler")


def outfit(npc) -> tuple[Gear, list[str], str]:
    """(gear, accessories, tabard colour) a person wears by trade, when nothing's equipped."""
    f = npc.fields
    occ = f.get("occupation") or "Commoner"
    desc = (npc.description or "").lower()
    title = desc[4:desc.find(" of ")] if desc.startswith("the ") and " of " in desc else ""
    clothes = (f.get("appearance") or {}).get("clothes") or ""
    rng = random.Random(sum(map(ord, npc.id)))
    g = Gear()
    acc: list[str] = []
    tabard = ""
    if occ == "Guard":
        knight = "knight" in title or f.get("fights_as") in ("enemy.knight",)
        captain = "captain" in title or f.get("fights_as") in ("enemy.veteran",)
        g.armor = "plate" if knight else "half_plate" if captain else rng.choice(["chain_mail", "chain_shirt",
                                                                                  "scale_mail"])
        if not knight and not captain:
            g.helmet = rng.choice(["kettle", "cap", ""])
        tabard = clothes or "#3a4a6a"
    elif occ == "Priest":
        g.armor = "robe"
        g.armor_tint = clothes or "#e8e0c8"
        acc.append("holy_symbol")
    elif occ == "Arcanist":
        g.armor = "robe"
        g.armor_tint = clothes or "#3b2f6a"
        if rng.random() < 0.5:
            g.helmet = "wizard_hat"
    elif occ == "Scholar":
        g.armor = "robe"
        g.armor_tint = clothes or "#4a3f5e"
        if rng.random() < 0.55:
            acc.append("spectacles")
    elif occ == "Noble":
        g.armor = "noble"
        g.armor_tint = clothes
        if any(r == title or title.startswith(r) for r in RULERS):
            g.helmet = "crown"
        elif rng.random() < 0.4:
            g.helmet = "circlet"
    elif occ == "Mercenary":
        g.armor = rng.choice(["studded_leather", "chain_shirt", "leather"])
    elif occ == "Hunter":
        g.armor = rng.choice(["leather", "hide"])
        if rng.random() < 0.4:
            g.helmet = "hood"
    elif occ in ("Blacksmith", "Armorer", "Weaponsmith"):
        g.armor = "tunic"
        acc.append("apron")
    elif occ == "Innkeeper":
        g.armor = "tunic"
        if rng.random() < 0.6:
            acc.append("apron")
    elif occ == "Farmer":
        g.armor = "tunic"
        if rng.random() < 0.5:
            acc.append("straw_hat")
    elif occ == "Ship captain":
        g.armor = "tunic"
        acc += ["captain_hat", "earring"]
    elif occ == "Airship pilot":
        g.armor = "leather"
        acc.append("goggles")
    elif occ == "Caravan master":
        g.armor = "tunic"
        acc.append("wrap")
    elif occ in ("Jeweler", "Tailor"):
        g.armor = "noble"
        g.armor_tint = clothes
        if occ == "Jeweler" and rng.random() < 0.5:
            acc.append("spectacles")
    elif occ == "Alchemist":
        g.armor = "robe"
        g.armor_tint = clothes or "#3f5a3f"
        if rng.random() < 0.4:
            acc.append("goggles")
    else:
        g.armor = "tunic"
    return g, acc, tabard


MOOD = {"Friendly": "smile", "Neutral": "neutral", "Wary": "wary", "Hostile": "angry"}


def portrait_of(world, entity, mood: str = "", gear: Gear | None = None) -> Canvas | None:
    """A portrait for an NPC, enemy or race (None for beasts and other things without a face like ours)."""
    import zlib
    lib = world.sprites
    look_d = lib.resolve_look(entity, world.entities)
    if look_d.get("base", "human") not in HUMANOID or entity.fields.get("unique_sprite"):
        return None
    look = Look(base=look_d.get("base", "human"), skin=look_d.get("skin", ""), hair=look_d.get("hair", ""),
                hair_color=look_d.get("hair_color", ""), beard=look_d.get("beard", ""), eyes=look_d.get("eyes", ""),
                accent=look_d.get("accent", ""), clothes=look_d.get("clothes", ""))
    acc, tabard = [], ""
    if gear is None:
        gear = lib.gear_for(entity, world.entities)
        if entity.type == "npc" and not (entity.fields.get("equipment") or {}):
            gear, acc, tabard = outfit(entity)
        elif entity.type == "npc":
            _g, acc, tabard = outfit(entity)
    if not mood:
        mood = MOOD.get(entity.fields.get("disposition") or "Neutral", "neutral")
        if entity.type == "enemy":
            mood = "angry"
    ex = Extras(sex=str(look_d.get("sex") or ""), mood=mood, accessories=acc, tabard=tabard,
                seed=zlib.crc32(entity.id.encode("utf-8")))
    return draw_portrait(look, gear, ex)


def draw_portrait(look: Look, gear: Gear | None = None, extras: Extras | None = None) -> Canvas:
    """A person's portrait in the house style (game/art/faces.py), SIZE x SIZE."""
    from game.art import faces
    return faces.draw(look, gear, extras)


def member_portrait(world, member: dict, mood: str = "smile") -> Canvas:
    """A party member's portrait: their race's look under their own, in what they have on."""
    import zlib
    race = world.entities.get(member.get("race") or "")
    look_d: dict = {}
    if race is not None:
        look_d.update(race.fields.get("appearance") or {})
    look_d.update({k: v for k, v in (member.get("look") or {}).items() if v})
    base = look_d.get("base", "human")
    if base not in HUMANOID:
        base = "human"
    look = Look(base=base, skin=look_d.get("skin", ""), hair=look_d.get("hair", ""),
                hair_color=look_d.get("hair_color", ""), beard=look_d.get("beard", ""), eyes=look_d.get("eyes", ""),
                accent=look_d.get("accent", ""), clothes=look_d.get("clothes", ""))
    gear = Gear()
    for slot, item_id in (member.get("equipment") or {}).items():
        item = world.entities.get(item_id)
        if item is not None:
            world.sprites.apply_item(gear, item, slot)
    ex = Extras(sex=str(look_d.get("sex") or member.get("sex") or ""), mood=mood,
                seed=zlib.crc32(str(member.get("id") or member.get("name") or "").encode("utf-8")))
    return draw_portrait(look, gear, ex)


__all__ = ["draw_portrait", "member_portrait", "Extras", "outfit", "portrait_of", "MOOD", "HUMANOID", "SIZE"]
