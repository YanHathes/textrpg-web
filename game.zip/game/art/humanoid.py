"""Top-down humanoid bodies: the base layer every person sprite is built on.

Everything faces south (toward the bottom of the screen). Light comes from
the top-left. A Frame holds the positions of head, shoulders, hands and feet
so gear layers (gear.py) can be drawn in exactly the right places at any
size (32px for Medium, 64 for Large, 96 Huge, 128 Gargantuan).

Screen-left hand  (hand_w) is the character's right hand: the main hand.
Screen-right hand (hand_e) is the off hand: shields go here.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from game.art.canvas import Canvas, hex_to_rgba, mix, outline_color, ramp, shift, with_alpha

SHADOW = (8, 12, 10, 70)
EYE = (24, 18, 22, 255)


@dataclass
class Frame:
    size: int                 # canvas size in pixels
    k: float                  # pixel scale relative to a 32px Medium body
    cx: float
    cy: float
    head: tuple[float, float, float]           # x, y, radius
    shoulders: tuple[float, float, float, float]  # x, y, rx, ry
    hand_w: tuple[float, float, float]
    hand_e: tuple[float, float, float]
    foot_w: tuple[float, float]
    foot_e: tuple[float, float]
    foot_r: tuple[float, float]
    shoulder_w: tuple[float, float]
    shoulder_e: tuple[float, float]
    arm_width: float
    two_handed: bool = False

    def scaled(self, v: float) -> float:
        return v * self.k


@dataclass(frozen=True)
class Build:
    scale: float = 1.0         # overall body size inside the square
    shoulder: float = 1.0      # shoulder width factor
    head: float = 1.0          # head size factor
    depth: float = 1.0         # front-to-back thickness
    arm: float = 1.0


BUILDS = {
    "average": Build(),
    "lean": Build(0.98, 0.92, 0.96, 0.95, 0.9),
    "small": Build(0.78, 0.98, 1.12, 0.95, 0.95),
    "stout": Build(0.88, 1.18, 1.05, 1.12, 1.15),
    "broad": Build(1.04, 1.12, 1.02, 1.06, 1.12),
    "giant": Build(1.0, 1.2, 0.95, 1.1, 1.25),
    "gaunt": Build(0.98, 0.88, 0.96, 0.85, 0.75),
    "hulking": Build(1.06, 1.22, 0.92, 1.12, 1.3),
}


def make_frame(size: int, build: Build, two_handed: bool = False) -> Frame:
    k = size / 32.0
    s = build.scale * k
    cx = size / 2
    cy = size / 2 - 0.8 * k
    head_r = 4.6 * build.head * s
    sh_rx = 9.0 * build.shoulder * s
    sh_ry = 5.6 * build.depth * s
    sh_y = cy + 1.8 * s
    head_y = cy - 0.7 * s
    hand_r = 1.75 * build.arm * s
    hand_dx = sh_rx - 0.5 * s
    hand_y = sh_y + 3.9 * s
    if two_handed:
        hand_w = (cx - 3.2 * s, hand_y + 2.2 * s, hand_r)
        hand_e = (cx + 1.8 * s, hand_y + 2.9 * s, hand_r)
    else:
        hand_w = (cx - hand_dx, hand_y, hand_r)
        hand_e = (cx + hand_dx, hand_y, hand_r)
    foot_dx = 3.2 * build.shoulder * s
    foot_y = sh_y + 5.9 * s
    return Frame(
        size=size, k=s, cx=cx, cy=cy, head=(cx, head_y, head_r), shoulders=(cx, sh_y, sh_rx, sh_ry),
        hand_w=hand_w, hand_e=hand_e, foot_w=(cx - foot_dx, foot_y), foot_e=(cx + foot_dx, foot_y),
        foot_r=(2.0 * s, 2.4 * s), shoulder_w=(cx - sh_rx + 1.2 * s, sh_y + 0.6 * s),
        shoulder_e=(cx + sh_rx - 1.2 * s, sh_y + 0.6 * s), arm_width=3.4 * build.arm * s,
        two_handed=two_handed,
    )


# ======================================================================
# Race bases
# ======================================================================
@dataclass(frozen=True)
class BodyBase:
    id: str
    label: str
    build: str
    skin: str                         # default skin color
    skin_options: tuple[str, ...]
    hair: str = "short"               # default hair style
    hair_color: str = "#4a3426"
    hair_options: tuple[str, ...] = ("#2b2220", "#4a3426", "#7a5230", "#b08a4e", "#d9c27a", "#8c2f1e", "#cfcac0")
    features: tuple[str, ...] = ()    # ears, horns, tail, snout, tusks, beard...
    accent: str = ""                  # horn / scale / frill color
    eyes: str = "#1e1a20"
    clothes: str = "#5b6b4e"
    category: str = "Playable races"
    undead: str = ""                  # "skeleton", "zombie", "ghost"
    beard_default: str = "none"


BODY_BASES: dict[str, BodyBase] = {b.id: b for b in [
    BodyBase("human", "Human", "average", "#e0ac84",
             ("#f3cfb0", "#e0ac84", "#c68a62", "#a06a46", "#7a4c30", "#55331f")),
    BodyBase("elf", "Elf", "lean", "#f1cfae",
             ("#f6dcc4", "#f1cfae", "#d9a882", "#b6855e", "#8a5f44", "#c9b8d6"),
             hair="long", hair_color="#e3cf8a", features=("ears",), clothes="#3f6a52"),
    BodyBase("half_elf", "Half-Elf", "average", "#e8b992",
             ("#f3cfb0", "#e8b992", "#c68a62", "#a06a46", "#7a4c30"),
             hair="ponytail", hair_color="#6b4528", features=("small_ears",), clothes="#4d5f7a"),
    BodyBase("dwarf", "Dwarf", "stout", "#dba07a",
             ("#efc2a0", "#dba07a", "#b97c55", "#8f5b3c", "#6b4330"),
             hair="short", hair_color="#8c3b1f", features=("beard",), clothes="#7a4b33",
             beard_default="full"),
    BodyBase("halfling", "Halfling", "small", "#e6b58c",
             ("#f3cfb0", "#e6b58c", "#c68a62", "#a06a46", "#7a4c30"),
             hair="curly", hair_color="#6b4528", features=("bare_feet",), clothes="#6f7f3a"),
    BodyBase("gnome", "Gnome", "small", "#ebbf9b",
             ("#f3d5b8", "#ebbf9b", "#c99a74", "#a37150", "#7d5139"),
             hair="wild", hair_color="#d8d4cc", features=("small_ears", "big_nose"), clothes="#8a3f5c"),
    BodyBase("dragonborn", "Dragonborn", "broad", "#b8432f",
             ("#b8432f", "#2f6db8", "#3a8c45", "#2b2b33", "#d9dde3", "#c9a13a", "#b0702e", "#9a5a3a",
              "#a9b4bf", "#d8b04a"),
             hair="none", features=("snout", "frills", "tail", "scales"), accent="#e0c27a",
             eyes="#f2c14e", clothes="#4b3f5e", hair_options=()),
    BodyBase("tiefling", "Tiefling", "average", "#b5524e",
             ("#b5524e", "#8e3b5a", "#6e3f8c", "#c4685c", "#4f3c6b", "#d08a7a"),
             hair="long", hair_color="#1f1a2b", features=("horns", "tail", "spade"), accent="#3a2a2e",
             eyes="#f5d04a", clothes="#3b2f4a"),
    BodyBase("half_orc", "Half-Orc", "broad", "#8fa36a",
             ("#a3b37a", "#8fa36a", "#7a8f5a", "#9a9a7a", "#7f8a72", "#6b7a52"),
             hair="mohawk", hair_color="#1f1c1a", features=("tusks",), clothes="#6b4a32"),
    BodyBase("automaton", "Automaton", "broad", "#b08a4a",
             ("#b08a4a", "#a86a3a", "#8f969e", "#6e747c", "#c8a85a", "#5f8a7a", "#d8d2c4", "#4a4e56"),
             hair="none", features=("metal", "rivets", "lamp_eyes"), accent="#5a4632", eyes="#7ae6f2",
             clothes="#4a4e5a", hair_options=()),

    BodyBase("goblin", "Goblin", "small", "#7da34b", ("#7da34b", "#8fae55", "#6b8f3c", "#a2b05a"),
             hair="none", features=("ears", "big_ears", "tusks_small"), eyes="#e8c23a",
             clothes="#5e4a33", category="Monstrous peoples", hair_options=()),
    BodyBase("kobold", "Kobold", "small", "#b0613a", ("#b0613a", "#8a4e34", "#c27a3e", "#6e5a8c"),
             hair="none", features=("snout", "tail", "scales", "small_horns"), accent="#e3d2a4",
             eyes="#f0c040", clothes="#5a4a3a", category="Monstrous peoples", hair_options=()),
    BodyBase("orc", "Orc", "hulking", "#7b8f5a", ("#7b8f5a", "#6e7d55", "#8a8a6a", "#5f7048"),
             hair="topknot", hair_color="#1c1a18", features=("tusks",), eyes="#d84a2a",
             clothes="#5a3d2a", category="Monstrous peoples"),
    BodyBase("hobgoblin", "Hobgoblin", "broad", "#c0653a", ("#c0653a", "#b0552f", "#cf7a44", "#9e4a2c"),
             hair="short", hair_color="#2a1a14", features=("ears",), eyes="#f0b030",
             clothes="#6a2a2a", category="Monstrous peoples"),
    BodyBase("gnoll", "Gnoll", "lean", "#b39462", ("#b39462", "#a08055", "#8f7a5a", "#c2a674"),
             hair="mane", hair_color="#3a2e24", features=("snout", "hyena", "round_ears", "spots", "tail_short"),
             eyes="#e86a2a", clothes="#5a4a36", category="Monstrous peoples", hair_options=()),
    BodyBase("lizardfolk", "Lizardfolk", "broad", "#4f8a4a", ("#4f8a4a", "#3f7a5a", "#6a8a3a", "#5a7a6a"),
             hair="none", features=("snout", "tail", "scales", "crest"), accent="#c46a3a",
             eyes="#f0d040", clothes="#5a4a36", category="Monstrous peoples", hair_options=()),
    BodyBase("giant", "Giant", "giant", "#d9a07a",
             ("#e6b592", "#d9a07a", "#b58060", "#9fb3c9", "#c9c9c9", "#a86a4a", "#6a7a8a"),
             hair="long", hair_color="#5a3a22", features=("beard",), clothes="#6a5a3a",
             category="Monstrous peoples", beard_default="full"),
    BodyBase("ogre", "Ogre", "hulking", "#b09a6a", ("#b09a6a", "#a08a5a", "#9a8a6a", "#8f9a6a"),
             hair="wild", hair_color="#3a2e22", features=("tusks_small", "big_nose"), clothes="#6a5038",
             category="Monstrous peoples"),

    BodyBase("skeleton", "Skeleton", "gaunt", "#e8e2cc", ("#e8e2cc", "#d8cfb0", "#c9c2b0", "#b8b8c0"),
             hair="none", features=(), eyes="#c04a2a", clothes="#4a4038", category="Undead",
             undead="skeleton", hair_options=()),
    BodyBase("zombie", "Zombie", "average", "#8a9a7a", ("#8a9a7a", "#7a8a8a", "#9a9a7a", "#6f7f6a"),
             hair="ragged", hair_color="#3a3a30", features=(), eyes="#e8e8a0", clothes="#5a5048",
             category="Undead", undead="zombie"),
    BodyBase("ghost", "Ghost", "average", "#b8d8e8", ("#b8d8e8", "#c8e8d8", "#d8d0e8", "#e8e8e8"),
             hair="long", hair_color="#c8e0ea", features=(), eyes="#1a2a40", clothes="#a8c8d8",
             category="Undead", undead="ghost"),
]}

HAIR_STYLES = ["none", "short", "long", "ponytail", "curly", "wild", "mohawk", "topknot", "braids",
               "bun", "ragged", "mane"]
BEARD_STYLES = ["none", "stubble", "short", "full", "braided"]


@dataclass
class Look:
    base: str = "human"
    skin: str = ""
    hair: str = ""
    hair_color: str = ""
    beard: str = ""
    eyes: str = ""
    accent: str = ""
    clothes: str = ""

    def resolved(self) -> "Look":
        b = BODY_BASES.get(self.base, BODY_BASES["human"])
        return Look(
            base=b.id, skin=self.skin or b.skin, hair=self.hair or b.hair,
            hair_color=self.hair_color or b.hair_color, beard=self.beard or b.beard_default,
            eyes=self.eyes or b.eyes, accent=self.accent or b.accent,
            clothes=self.clothes or b.clothes,
        )


def body_base(base_id: str) -> BodyBase:
    return BODY_BASES.get(base_id, BODY_BASES["human"])


# ======================================================================
# Drawing
# ======================================================================
def draw_shadow(size: int, footprint: float = 1.0) -> Canvas:
    c = Canvas(size)
    k = size / 32
    c.ellipse(size / 2, size / 2 + 2.8 * k, 10.5 * k * footprint, 7.5 * k * footprint, SHADOW)
    return c


def draw_body(frame: Frame, look: Look, layers: dict[str, Canvas]) -> None:
    """Fill `layers` with the body: 'back' (tail, long hair), 'feet', 'torso', 'arms',
    'hands', 'head', 'hair', 'face_front' (beard, snout)."""
    base = body_base(look.base)
    feats = set(base.features)
    size = frame.size
    k = frame.k
    skin = hex_to_rgba(look.skin)
    clothes = hex_to_rgba(look.clothes)
    undead = base.undead

    def layer(name: str) -> Canvas:
        if name not in layers:
            layers[name] = Canvas(size)
        return layers[name]

    # ---- tail and back hair -------------------------------------------
    if "tail" in feats or "tail_short" in feats:
        back = layer("back")
        tail_color = skin
        sx, sy = frame.cx + 0.8 * k, frame.shoulders[1] - frame.shoulders[3] * 0.4
        length = 9.0 * k if "tail" in feats else 4.5 * k
        thick = 1.9 if "scales" in feats else 1.3
        pts = []
        for i in range(15):
            t = i / 14
            x = sx + math.sin(t * 1.9) * 6.2 * k * t
            y = sy - length * t * 0.85 + (t * t) * 2.0 * k
            pts.append((x, y, max(0.55, (thick - (thick - 0.55) * t)) * k))
        for x, y, r in pts:
            back.circle(x, y, r, shift(tail_color, -0.08))
        for x, y, r in pts[1:-2:3]:
            back.put(int(x - 0.3 * k), int(y - r * 0.3), shift(tail_color, 0.05))
        tip_x, tip_y, _ = pts[-1]
        if "spade" in feats:
            back.polygon([(tip_x - 1.4 * k, tip_y + 0.4 * k), (tip_x + 2.6 * k, tip_y - 0.2 * k),
                          (tip_x + 0.6 * k, tip_y - 2.2 * k)], shift(tail_color, -0.1))
        if "hyena" in feats:
            back.circle(tip_x, tip_y, 1.4 * k, look.hair_color)

    # ---- feet ---------------------------------------------------------
    if undead != "ghost":
        feet = layer("feet")
        bare = "bare_feet" in feats or undead == "skeleton" or "scales" in feats
        foot_color = skin if bare else hex_to_rgba("#4a3426")
        if undead == "skeleton":
            foot_color = skin
        for fx, fy in (frame.foot_w, frame.foot_e):
            feet.shaded_ellipse(fx, fy, frame.foot_r[0], frame.foot_r[1], foot_color, steps=3)
            if "scales" in feats or "hyena" in feats:
                feet.put(int(fx - 0.6 * k), int(fy + frame.foot_r[1] - 0.6 * k), base.accent or "#f0f0e0")
                feet.put(int(fx + 0.6 * k), int(fy + frame.foot_r[1] - 0.6 * k), base.accent or "#f0f0e0")

    # ---- torso ---------------------------------------------------------
    torso = layer("torso")
    sx, sy, rx, ry = frame.shoulders
    if undead == "skeleton":
        bone = skin
        # spine and ribs seen from above
        torso.line(sx, sy - ry, sx, sy + ry, shift(bone, -0.1), width=1.6 * k)
        for i in range(-2, 3):
            yy = sy + i * 1.5 * k
            torso.line(sx - rx * 0.75, yy + 0.6 * k, sx + rx * 0.75, yy + 0.6 * k, bone, width=1.0 * k)
        torso.shaded_ellipse(sx - rx * 0.78, sy, 2.1 * k, 1.8 * k, bone, steps=3)
        torso.shaded_ellipse(sx + rx * 0.78, sy, 2.1 * k, 1.8 * k, bone, steps=3)
    elif undead == "ghost":
        ghost = with_alpha(skin, 170)
        for i in range(9):
            t = i / 8
            torso.circle(sx + math.sin(t * 5) * 1.2 * k, sy - ry * 0.5 - t * 7 * k, (rx * 0.65) * (1 - t * 0.85),
                         with_alpha(skin, int(150 - 110 * t)))
        torso.ellipse(sx, sy, rx * 0.92, ry, ghost)
        torso.ellipse(sx - rx * 0.25, sy - ry * 0.35, rx * 0.45, ry * 0.45, with_alpha(shift(skin, 0.12), 150))
    else:
        torso.shaded_ellipse(sx, sy, rx, ry, clothes, steps=4)
        # collar line in front of the neck
        torso.ellipse(sx, sy + ry * 0.35, rx * 0.36, ry * 0.42, shift(clothes, -0.07))
        if undead == "zombie":
            for i in range(6):
                torso.put(int(sx - rx + (i * 3.1 * k) % (2 * rx)), int(sy + ry - 1 - (i % 2)), None)
                torso.put(int(sx - rx * 0.4 + i * 0.7 * k), int(sy - ry * 0.2 + (i % 3)), shift(clothes, -0.12))
        if "scales" in feats:
            # scaled shoulders peek out around clothing
            for side in (-1, 1):
                torso.shaded_ellipse(sx + side * (rx - 1.6 * k), sy - 0.4 * k, 2.2 * k, 2.3 * k, skin, steps=3)
        if "spots" in feats:
            for ox, oy in ((-0.5, -0.5), (0.45, -0.3), (-0.2, 0.4)):
                torso.put(int(sx + ox * rx), int(sy + oy * ry), shift(skin, -0.2))
        if "metal" in feats:
            # plated shoulders over whatever they wear, a rivet in each
            for side in (-1, 1):
                torso.shaded_ellipse(sx + side * (rx - 1.8 * k), sy - 0.3 * k, 2.6 * k, 2.4 * k, skin, steps=3)
                torso.put(int(sx + side * (rx - 1.8 * k)), int(sy - 0.6 * k), shift(skin, 0.3))

    # ---- arms and hands -----------------------------------------------
    arms = layer("arms")
    hands = layer("hands")
    sleeve = clothes if undead not in ("skeleton", "ghost") else skin
    reach = 1.0 if undead != "zombie" else 1.0
    for (shx, shy), (hx, hy, hr) in ((frame.shoulder_w, frame.hand_w), (frame.shoulder_e, frame.hand_e)):
        if undead == "zombie":
            hy += 2.5 * k
        if undead == "skeleton":
            arms.line(shx, shy, hx, hy, shift(skin, -0.05), width=1.4 * k)
        elif undead == "ghost":
            arms.line(shx, shy, hx, hy, with_alpha(skin, 150), width=frame.arm_width * 0.8)
        else:
            arms.line(shx, shy, hx, hy - hr * 0.5 * reach, shift(sleeve, -0.03), width=frame.arm_width)
            arms.line(shx - 0.4 * k, shy, hx - 0.4 * k, hy - hr * 0.8, shift(sleeve, 0.06), width=1.0 * k)
        hand_color = skin if undead != "ghost" else with_alpha(skin, 190)
        hands.shaded_ellipse(hx, hy, hr, hr, hand_color, steps=3)

    # ---- head -------------------------------------------------------------
    head = layer("head")
    hx, hy, hr = frame.head
    if undead == "ghost":
        head.ellipse(hx, hy, hr, hr, with_alpha(skin, 205))
        head.ellipse(hx - hr * 0.3, hy - hr * 0.35, hr * 0.45, hr * 0.4, with_alpha(shift(skin, 0.12), 200))
    else:
        head.shaded_ellipse(hx, hy, hr, hr * 0.98, skin, steps=4, shade_bias=0.18)
    if "metal" in feats:
        head.line(hx, hy - hr * 0.9, hx, hy + hr * 0.3, shift(skin, -0.22), width=max(1.0, 0.7 * k))   # the seam
        head.line(hx - hr * 0.8, hy - 0.2 * k, hx + hr * 0.8, hy - 0.2 * k, shift(skin, -0.14), width=0.6 * k)
        if "rivets" in feats:
            for side in (-1, 1):
                head.put(int(hx + side * hr * 0.55), int(hy - hr * 0.5), shift(skin, 0.35))
    ears = layer("ears")
    if "ears" in feats or "small_ears" in feats or "big_ears" in feats:
        ear_len = 3.2 if "ears" in feats else 1.8
        if "big_ears" in feats:
            ear_len = 4.4
        for side in (-1, 1):
            base_x = hx + side * hr * 0.88
            pts = [(base_x, hy - 1.2 * k), (base_x, hy + 1.4 * k),
                   (base_x + side * ear_len * k, hy - 1.8 * k - ear_len * 0.35 * k)]
            ears.polygon(pts, shift(skin, -0.03))
            ears.put(int(base_x + side * ear_len * 0.45 * k), int(hy - 0.6 * k), shift(skin, -0.14))
    if "round_ears" in feats:
        for side in (-1, 1):
            head.shaded_ellipse(hx + side * hr * 0.8, hy - hr * 0.55, 1.7 * k, 1.7 * k, shift(skin, -0.05), steps=3)
            head.put(int(hx + side * hr * 0.8), int(hy - hr * 0.55), shift(skin, -0.2))

    face = layer("face_front")
    # Face details sit on the south (front) edge of the head.
    fy = hy + hr * 0.42
    if undead == "skeleton":
        for side in (-1, 1):
            face.ellipse(hx + side * 1.8 * k, fy, 1.15 * k, 1.0 * k, (30, 22, 26, 255))
            face.put(int(hx + side * 1.8 * k), int(fy), look.eyes)
        face.put(int(hx), int(fy + 1.6 * k), (60, 50, 50, 255))
        for i in range(-1, 2):
            face.put(int(hx + i * 1.0 * k), int(hy + hr * 0.92), shift(skin, -0.18))
    else:
        eye_dx = 1.9 * k if "snout" not in feats else 2.5 * k
        eye_y = fy if "snout" not in feats else hy + hr * 0.15
        for side in (-1, 1):
            if "lamp_eyes" in feats:                       # they glow
                face.ellipse(hx + side * eye_dx, eye_y + 0.5, 1.6 * k, 1.1 * k, with_alpha(look.eyes, 90))
            face.put(int(hx + side * eye_dx - (0 if side > 0 else 0.5)), int(eye_y), look.eyes)
            if k >= 1.8:
                face.put(int(hx + side * eye_dx - (0 if side > 0 else 0.5)) + 1, int(eye_y), look.eyes)
        if "snout" in feats:
            snout_color = skin
            sn_len = 3.6 if "hyena" not in feats else 3.2
            face.shaded_ellipse(hx, hy + hr * 0.62 + sn_len * 0.5 * k, 2.6 * k, sn_len * k, snout_color, steps=3)
            face.put(int(hx - 1.0 * k), int(hy + hr * 0.62 + sn_len * 1.15 * k), shift(skin, -0.3))
            face.put(int(hx + 1.0 * k), int(hy + hr * 0.62 + sn_len * 1.15 * k), shift(skin, -0.3))
            if "hyena" in feats:
                face.put(int(hx), int(hy + hr * 0.62 + sn_len * 1.4 * k), (30, 26, 26, 255))
        elif "big_nose" in feats:
            face.shaded_ellipse(hx, fy + 1.6 * k, 1.5 * k, 1.4 * k, shift(skin, -0.02), steps=3)
        else:
            face.put(int(hx), int(fy + 1.3 * k), shift(skin, -0.12))
        if "tusks" in feats or "tusks_small" in feats:
            tusk = (238, 232, 210, 255)
            for side in (-1, 1):
                face.put(int(hx + side * 1.6 * k - (0.5 if side < 0 else 0)), int(hy + hr * 0.86), tusk)
                if "tusks" in feats:
                    face.put(int(hx + side * 1.6 * k - (0.5 if side < 0 else 0)), int(hy + hr * 0.86) - 1, tusk)
        if undead == "zombie":
            face.put(int(hx), int(fy + 2.2 * k), (70, 40, 40, 255))

    # ---- horns, frills, crest -------------------------------------------
    top = layer("head_top")
    horn = hex_to_rgba(look.accent or base.accent or "#3a2a2e")
    if "horns" in feats:
        for side in (-1, 1):
            pts = []
            for i in range(9):
                t = i / 8
                pts.append((hx + side * (2.2 + 2.6 * t + 1.0 * math.sin(t * 3)) * k,
                            hy - (1.2 + 4.6 * t) * k, (1.4 - 0.9 * t) * k))
            for x, y, r in pts:
                top.circle(x, y, max(r, 0.55), horn)
            top.put(int(pts[2][0] - side * 0.4 * k), int(pts[2][1]), shift(horn, 0.2))
    if "small_horns" in feats:
        for side in (-1, 1):
            top.circle(hx + side * 2.2 * k, hy - hr * 0.75, 1.1 * k, horn)
            top.put(int(hx + side * 2.6 * k), int(hy - hr * 0.75 - 1.2 * k), horn)
    if "frills" in feats:
        for side in (-1, 1):
            for i in range(2):
                x = hx + side * (1.6 + i * 1.6) * k
                top.line(x, hy - hr * 0.55, x + side * 0.8 * k, hy - hr - 1.4 * k + i * 0.8 * k, horn, width=1.0 * k)
    if "crest" in feats:
        for i in range(5):
            top.circle(hx, hy - hr * 0.2 - i * 1.4 * k, (1.3 - i * 0.12) * k, horn)
    if "scales" in feats:
        for ox, oy in ((-1.6, -1.8), (1.6, -1.8), (0, -3.0), (-2.6, -0.2), (2.6, -0.2)):
            head.put(int(hx + ox * k), int(hy + oy * k), shift(skin, -0.1))

    # ---- hair and beard ---------------------------------------------------
    draw_hair(frame, look, layers)


def draw_hair(frame: Frame, look: Look, layers: dict[str, Canvas], covered: bool = False) -> None:
    style = look.hair or "none"
    beard = look.beard or "none"
    size, k = frame.size, frame.k
    hx, hy, hr = frame.head
    color = hex_to_rgba(look.hair_color or "#4a3426")
    if style == "none" and beard == "none":
        return
    hair = layers.setdefault("hair", Canvas(size))
    back = layers.setdefault("back", Canvas(size))
    face = layers.setdefault("face_front", Canvas(size))

    def cap(extra_r: float, hairline: float, bumpy: bool = False) -> None:
        """Hair covering the top of the head, ending at a curved hairline toward the face."""
        tmp = Canvas(size)
        tmp.shaded_ellipse(hx, hy - 0.3 * k, hr + extra_r * k, hr + extra_r * k, color, steps=3)
        if bumpy:
            for a in range(0, 360, 40):
                r = math.radians(a)
                tmp.shaded_ellipse(hx + math.cos(r) * (hr + 0.4 * k), hy - 0.3 * k + math.sin(r) * (hr + 0.2 * k),
                                   1.5 * k, 1.5 * k, color, steps=3)
        for y in range(size):
            for x in range(size):
                dx = (x + 0.5 - hx) / (hr + 1)
                limit = hy + hairline * k - (dx * dx) * 2.2 * k
                if y + 0.5 > limit:
                    tmp.set(x, y, None)
        # strand texture: a few darker arcs sweeping from the crown to the hairline
        dark = shift(color, -0.09)
        for i in (-2, -1, 1, 2):
            x0 = hx + i * 1.7 * k
            for step in range(int(hr * 1.6)):
                y = hy - hr + 1 + step
                x = x0 + i * 0.12 * step
                if y > hy + hairline * k - 1.5 * k:
                    break
                if tmp.get(int(x), int(y)) is not None and step % 4 != 3:
                    tmp.set(int(x), int(y), dark)
        hair.blit(tmp)

    if covered:
        style = "none"
    if style == "short":
        cap(0.5, 1.2)
    elif style == "curly":
        cap(0.6, 1.0, bumpy=True)
    elif style == "wild":
        cap(1.3, 1.0, bumpy=True)
        for a in (200, 250, 290, 340):
            r = math.radians(a)
            hair.line(hx + math.cos(r) * hr, hy + math.sin(r) * hr, hx + math.cos(r) * (hr + 3 * k),
                      hy + math.sin(r) * (hr + 3 * k), shift(color, -0.04), width=1.4 * k)
    elif style in ("long", "ragged"):
        back.shaded_ellipse(hx, hy - 1.6 * k, hr + 1.4 * k, hr + 3.4 * k, color, steps=3)
        if style == "ragged":
            for i in range(5):
                back.set(int(hx - hr + i * 2.4 * k), int(hy - hr - 3.6 * k + (i % 2)), None)
        cap(0.7, 1.4)
    elif style == "ponytail":
        cap(0.5, 1.2)
        for i in range(8):
            back.circle(hx + math.sin(i * 0.5) * 0.6 * k, hy - hr - 0.5 * k - i * 0.9 * k, (1.7 - i * 0.12) * k, color)
    elif style == "braids":
        cap(0.5, 1.2)
        for side in (-1, 1):
            for i in range(7):
                back.circle(hx + side * (hr - 0.6 * k), hy + i * 1.2 * k, 1.1 * k, shift(color, -0.04 * (i % 2)))
    elif style == "bun":
        cap(0.4, 1.3)
        hair.shaded_ellipse(hx, hy - hr - 0.2 * k, 2.4 * k, 2.2 * k, color, steps=3)
    elif style == "mohawk":
        for i in range(7):
            hair.circle(hx, hy + 0.8 * k - i * 0.95 * k, 1.3 * k, shift(color, 0.06 if i % 2 else 0))
    elif style == "topknot":
        cap(0.2, -0.2)
        hair.shaded_ellipse(hx, hy - hr * 0.4, 2.0 * k, 2.0 * k, color, steps=3)
        back.line(hx, hy - hr * 0.4, hx + 1 * k, hy - hr - 4 * k, color, width=1.6 * k)
    elif style == "mane":
        for a in range(150, 391, 24):
            r = math.radians(a)
            back.shaded_ellipse(hx + math.cos(r) * (hr + 0.5 * k), hy - 0.6 * k + math.sin(r) * (hr + 0.8 * k),
                                1.8 * k, 1.8 * k, color, steps=3)
        for i in range(7):
            back.circle(hx, hy - i * 1.3 * k - hr * 0.4, 1.3 * k, color)

    if beard != "none":
        bc = color
        by = hy + hr * 0.75
        if beard == "stubble":
            for x in range(int(hx - 2.5 * k), int(hx + 2.5 * k) + 1):
                if x % 2 == 0:
                    face.put(x, int(by + 0.6 * k), with_alpha(shift(bc, -0.05), 180))
        else:
            length = {"short": 2.2, "full": 3.6, "braided": 4.4}[beard]
            face.shaded_ellipse(hx, by + length * 0.45 * k, 3.4 * k, length * 0.85 * k, bc, steps=3)
            face.ellipse(hx - 2.6 * k, by - 0.6 * k, 1.2 * k, 1.6 * k, bc)
            face.ellipse(hx + 2.6 * k, by - 0.6 * k, 1.2 * k, 1.6 * k, bc)
            if beard == "braided":
                for i in range(3):
                    face.put(int(hx), int(by + (1.5 + i * 1.2) * k), shift(bc, -0.12))
            # mouth line
            face.put(int(hx - 0.5), int(by - 0.2 * k), shift(bc, -0.2))
            face.put(int(hx + 0.5), int(by - 0.2 * k), shift(bc, -0.2))
