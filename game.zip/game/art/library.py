"""The sprite library: every built-in sprite plus each world's drawn or imported ones.

Sprite ids look like "<kind>/<name>":
    body/elf  creature/canine  armor/plate  weapon/longsword  shield/round
    helmet/great_helm  cloak/cloak  icon/potion_red  prop/barrel  tile/grass
    custom/<slug>        (drawn in the sprite editor or imported, stored in the world)

render_entity() turns an Item, Race, NPC or Enemy into its finished sprite,
building people and monsters from their body base and equipped gear.
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

from game.art import creatures as CR
from game.art import gear as G
from game.art import icons as IC
from game.art import tiles as TL
from game.art.canvas import Canvas
from game.art.doll import Gear, compose, scale_nearest
from game.art.humanoid import BEARD_STYLES, BODY_BASES, HAIR_STYLES, Look
from game.constants import SIZES

KINDS = {
    "body": "Bodies", "creature": "Creatures", "armor": "Armor & clothing", "weapon": "Weapons",
    "shield": "Shields", "helmet": "Helmets & hats", "cloak": "Cloaks", "icon": "Items",
    "prop": "Props", "tile": "Ground", "custom": "Your sprites",
}

# Which slot a built-in gear sprite naturally goes in.
KIND_SLOT = {"weapon": "Main hand", "shield": "Off hand", "armor": "Body", "helmet": "Head", "cloak": "Cloak"}


def split(sprite_id: str) -> tuple[str, str]:
    if not sprite_id or "/" not in sprite_id:
        return "", sprite_id or ""
    kind, name = sprite_id.split("/", 1)
    return kind, name


def builtin_catalog() -> dict[str, list[tuple[str, str]]]:
    """kind -> [(sprite_id, label)] for every built-in sprite."""
    cat: dict[str, list[tuple[str, str]]] = {k: [] for k in KINDS}
    for b in BODY_BASES.values():
        cat["body"].append((f"body/{b.id}", b.label))
    for c in CR.CREATURE_BASES.values():
        cat["creature"].append((f"creature/{c.id}", c.label))
    for a in G.ARMOR_STYLES.values():
        cat["armor"].append((f"armor/{a.id}", a.label))
    for w in G.WEAPONS.values():
        cat["weapon"].append((f"weapon/{w.id}", w.label))
    for s, label in G.SHIELDS.items():
        cat["shield"].append((f"shield/{s}", label))
    for h, label in G.HELMETS.items():
        cat["helmet"].append((f"helmet/{h}", label))
    for c, label in G.CLOAKS.items():
        cat["cloak"].append((f"cloak/{c}", label))
    for i, (label, _) in IC.ICONS.items():
        cat["icon"].append((f"icon/{i}", label))
    for p, (pdef, _, _) in TL.PROPS.items():
        cat["prop"].append((f"prop/{p}", pdef.label))
    for t, (label, _, _) in TL.FLOORS.items():
        cat["tile"].append((f"tile/{t}", label))
    return cat


def body_bases() -> list[tuple[str, str, str]]:
    """(base id, label, group) for every body a race or creature can use."""
    out = [(b.id, b.label, b.category) for b in BODY_BASES.values()]
    out += [(c.id, c.label, c.category) for c in CR.CREATURE_BASES.values()]
    return out


def is_creature_base(base_id: str) -> bool:
    return base_id in CR.CREATURE_BASES


def base_colors(base_id: str) -> tuple[str, tuple[str, ...]]:
    if base_id in BODY_BASES:
        b = BODY_BASES[base_id]
        return b.skin, b.skin_options
    if base_id in CR.CREATURE_BASES:
        c = CR.CREATURE_BASES[base_id]
        return c.main, c.options
    return "#e0ac84", ()


# ======================================================================
# Built-in sprite rendering
# ======================================================================
@lru_cache(maxsize=1024)
def builtin(sprite_id: str, tint: str = "") -> Canvas | None:
    kind, name = split(sprite_id)
    if kind == "body" and name in BODY_BASES:
        from game.art import folk as FK
        return FK.sprite(Look(base=name), Gear(), tiles=1)
    if kind == "creature" and name in CR.CREATURE_BASES:
        return CR.draw_creature(name, 1)
    if kind in ("weapon", "shield", "armor", "helmet", "cloak"):
        valid = {"weapon": G.WEAPONS, "shield": G.SHIELDS, "armor": G.ARMOR_STYLES,
                 "helmet": G.HELMETS, "cloak": G.CLOAKS}[kind]
        if name in valid:
            from game.art import itemart
            return itemart.icon(kind, name, tint=tint)
    if kind == "icon" and name in IC.ICONS:
        from game.art import itemart
        return itemart.icon("icon", name, tint=tint)
    if kind == "prop" and name in TL.PROPS:
        return TL.prop_sprite(name, 0)
    if kind == "tile" and name in TL.FLOORS:
        return TL.floor_tile(name, 0)
    return None


class SpriteLibrary:
    def __init__(self, folder: Path | None) -> None:
        self.folder = Path(folder) if folder else None
        self._custom: dict[str, dict] = {}
        self.reload()

    # ---- custom sprites ---------------------------------------------------
    def reload(self) -> None:
        self._custom.clear()
        if not self.folder or not self.folder.exists():
            return
        for path in sorted(self.folder.glob("*.json")):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                self._custom[f"custom/{path.stem}"] = data
            except (OSError, ValueError):
                continue

    def custom_ids(self) -> list[tuple[str, str]]:
        return sorted(((sid, d.get("name", sid)) for sid, d in self._custom.items()), key=lambda x: x[1].lower())

    def save_custom(self, name: str, canvas: Canvas, kind_hint: str = "", sprite_id: str | None = None) -> str:
        if not self.folder:
            raise RuntimeError("No world open")
        self.folder.mkdir(parents=True, exist_ok=True)
        if sprite_id and sprite_id.startswith("custom/"):
            slug = sprite_id.split("/", 1)[1]
        else:
            base = re.sub(r"[^0-9a-z]+", "-", name.lower()).strip("-") or "sprite"
            slug, n = base, 2
            while (self.folder / f"{slug}.json").exists():
                slug = f"{base}-{n}"
                n += 1
        data = {"name": name, "kind": kind_hint, "art": canvas.to_dict()}
        (self.folder / f"{slug}.json").write_text(json.dumps(data), encoding="utf-8")
        sid = f"custom/{slug}"
        self._custom[sid] = data
        return sid

    def delete_custom(self, sprite_id: str) -> None:
        if not self.folder:
            return
        slug = sprite_id.split("/", 1)[1]
        path = self.folder / f"{slug}.json"
        if path.exists():
            path.unlink()
        self._custom.pop(sprite_id, None)

    def custom_kind(self, sprite_id: str) -> str:
        return self._custom.get(sprite_id, {}).get("kind", "")

    # ---- lookup -------------------------------------------------------------
    def catalog(self) -> dict[str, list[tuple[str, str]]]:
        cat = builtin_catalog()
        cat["custom"] = self.custom_ids()
        return cat

    def label(self, sprite_id: str) -> str:
        if sprite_id in self._custom:
            return self._custom[sprite_id].get("name", sprite_id)
        for items in builtin_catalog().values():
            for sid, label in items:
                if sid == sprite_id:
                    return label
        return sprite_id

    def canvas(self, sprite_id: str, tint: str = "") -> Canvas | None:
        """The sprite's own picture (an icon for gear)."""
        if not sprite_id:
            return None
        if sprite_id in self._custom:
            c = Canvas.from_dict(self._custom[sprite_id]["art"])
            return c.tinted(tint) if tint else c
        return builtin(sprite_id, tint)

    # ---- entities -------------------------------------------------------
    def item_icon(self, item) -> Canvas | None:
        sid = item.fields.get("sprite") or default_item_sprite(item)
        return self.canvas(sid, item.fields.get("tint") or "")

    def resolve_look(self, entity, store) -> dict:
        """Merge an entity's appearance with its race's appearance."""
        look: dict = {}
        race_id = (entity.fields.get("appearance") or {}).get("race") or entity.fields.get("race")
        if entity.type == "race":
            look.update(entity.fields.get("appearance") or {})
        elif race_id:
            race = store.get(race_id)
            if race:
                look.update(race.fields.get("appearance") or {})
        own = entity.fields.get("appearance") or {}
        look.update({k: v for k, v in own.items() if v not in (None, "") and k != "race"})
        look.setdefault("base", "human")
        return look

    def tiles_for(self, entity, store) -> int:
        size = entity.fields.get("size")
        if not size and entity.fields.get("race"):
            race = store.get(entity.fields["race"])
            if race:
                size = race.fields.get("size")
        return SIZES.get(size or "Medium", 1)

    def render_entity(self, entity, store, tiles: int | None = None) -> Canvas:
        """Finished sprite for an Item, Race, NPC or Enemy."""
        if entity.type == "item":
            return self.item_icon(entity) or Canvas(32)
        if tiles is None:
            tiles = self.tiles_for(entity, store) if entity.type != "race" else 1
        unique = entity.fields.get("unique_sprite")
        if unique:
            art = self.canvas(unique)
            if art is not None:
                kind, name = split(unique)
                if kind == "creature":
                    look = self.resolve_look(entity, store)
                    return CR.draw_creature(name, tiles, look.get("skin", ""), look.get("accent", ""),
                                            look.get("eyes", ""), look.get("variant", ""))
                return scale_nearest(art, max(1, (32 * tiles) // max(1, art.w)))
        look = self.resolve_look(entity, store)
        gear = self.gear_for(entity, store)
        return render_look(look, gear, tiles)

    def gear_for(self, entity, store) -> Gear:
        gear = Gear()
        loadout = entity.fields.get("equipment") or {}
        if entity.type == "npc" and not loadout:              # nothing chosen: dressed for their trade
            from game.art.portrait import outfit
            g, _acc, _tabard = outfit(entity)
            g.helmet = g.helmet if g.helmet in ("kettle", "cap", "hood", "wizard_hat", "crown", "circlet") else ""
            return g
        for slot, item_id in loadout.items():
            item = store.get(item_id)
            if not item:
                continue
            self.apply_item(gear, item, slot)
        return gear

    def apply_item(self, gear: Gear, item, slot: str = "") -> None:
        sid = item.fields.get("sprite") or default_item_sprite(item)
        tint = item.fields.get("tint") or ""
        kind, name = split(sid)
        slot = slot or item.fields.get("slot") or KIND_SLOT.get(kind, "")
        if kind == "weapon" and slot == "Off hand":
            gear.off_weapon, gear.off_weapon_tint = name, tint
        elif kind == "weapon":
            gear.weapon, gear.weapon_tint = name, tint
        elif kind == "shield":
            gear.shield, gear.shield_tint = name, tint
        elif kind == "armor":
            gear.armor, gear.armor_tint = name, tint
        elif kind == "helmet":
            gear.helmet, gear.helmet_tint = name, tint
        elif kind == "cloak":
            gear.cloak = name
            if tint:
                gear.cloak_color = tint
        elif kind == "custom":
            art = self.canvas(sid, tint)
            if art is not None:
                gear.custom.append((slot or "Main hand", art))


def default_item_sprite(item) -> str:
    """A sensible built-in sprite for an item that has none chosen yet."""
    f = item.fields
    name = item.name.lower()
    cat = f.get("category", "")
    if cat == "Weapon":
        for wid, w in G.WEAPONS.items():
            if w.label.lower() in name or wid.replace("_", " ") in name:
                return f"weapon/{wid}"
        dtype = f.get("damage_type", "")
        if "ranged" in (f.get("weapon_kind") or "").lower():
            return "weapon/shortbow"
        return {"piercing": "weapon/spear", "bludgeoning": "weapon/mace"}.get(dtype, "weapon/longsword")
    if cat == "Armor":
        for aid, a in G.ARMOR_STYLES.items():
            if a.label.lower() in name:
                return f"armor/{aid}"
        return {"Light": "armor/leather", "Medium": "armor/scale_mail", "Heavy": "armor/plate"}.get(
            f.get("armor_type", ""), "armor/leather")
    if cat == "Shield":
        return "shield/heater" if "steel" in name or "kite" in name else "shield/round"
    if cat == "Consumable":
        return "icon/potion_red" if "potion" in name or f.get("use_effect") == "Heal" else "icon/bottle"
    if cat == "Ammunition":
        return "icon/arrows"
    if cat == "Treasure":
        return "icon/gem_blue" if "gem" in name else "icon/coins"
    if cat == "Clothing":
        return "armor/tunic"
    if cat == "Trinket":
        return "icon/amulet" if "amulet" in name or "necklace" in name else "icon/ring_gold"
    if cat == "Tool":
        return "icon/tool"
    if cat == "Material":
        return "icon/ore_iron"
    return "icon/bag"


def render_look(look: dict, gear: Gear | None = None, tiles: int = 1, folk: bool = True) -> Canvas:
    """A body's sprite from a look: people in the house style (game/art/folk.py, with their facings and
    walking frames), or with folk=False the older top-down figure (the sprite editor's tracing base)."""
    base = look.get("base", "human")
    if base in CR.CREATURE_BASES:
        return CR.draw_creature(base, tiles, look.get("skin", ""), look.get("accent", ""), look.get("eyes", ""),
                                look.get("variant", ""))
    lk = Look(base=base, skin=look.get("skin", ""), hair=look.get("hair", ""), hair_color=look.get("hair_color", ""),
              beard=look.get("beard", ""), eyes=look.get("eyes", ""), accent=look.get("accent", ""),
              clothes=look.get("clothes", ""))
    if folk:
        from game.art import folk as FK
        return FK.sprite(lk, gear or Gear(), tiles=tiles)
    return compose(lk, gear or Gear(), tiles=tiles)


__all__ = ["SpriteLibrary", "render_look", "builtin", "builtin_catalog", "body_bases", "KINDS", "split",
           "HAIR_STYLES", "BEARD_STYLES", "default_item_sprite", "is_creature_base", "base_colors"]
