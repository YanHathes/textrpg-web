"""The title screen's picture, as pixel art: a castle on its crag at golden hour, the sun going down over far
mountains, woods and a winding road below, and a dragon on the wing. Drawn here square by square (no Qt),
320 x 180 art pixels, to be scaled up by a whole number so every pixel stays sharp.

    background()        the still picture (sky, sun, clouds, mountains, castle, woods, road)
    dragon(frame)       the dragon (frame 0..3: its wings' beat), on clear
    banner_flags(t)     the castle's pennants, waving (drawn over the background)
"""
from __future__ import annotations

import math
import random

from game.art.uiskin import Img

W, H = 320, 180
BAYER = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]


def _mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _poly(im: Img, pts, col) -> None:
    """Fill a polygon (scanline, even-odd)."""
    ys = [p[1] for p in pts]
    for y in range(max(0, int(min(ys))), min(im.h, int(max(ys)) + 1)):
        yc = y + 0.5
        xs = []
        for (x1, y1), (x2, y2) in zip(pts, pts[1:] + pts[:1]):
            if (y1 <= yc < y2) or (y2 <= yc < y1):
                xs.append(x1 + (yc - y1) * (x2 - x1) / (y2 - y1))
        xs.sort()
        for a, b in zip(xs[::2], xs[1::2]):
            for x in range(max(0, int(round(a))), min(im.w, int(round(b)))):
                im.set(x, y, col)


def _disc(im: Img, cx, cy, r, col) -> None:
    for y in range(int(cy - r) - 1, int(cy + r) + 2):
        for x in range(int(cx - r) - 1, int(cx + r) + 2):
            if (x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2 <= r * r:
                im.set(x, y, col)


def _noise1(x: float, seed: int) -> float:
    i = int(math.floor(x))
    f = x - i
    a = random.Random(i * 7919 + seed).random()
    b = random.Random((i + 1) * 7919 + seed).random()
    f = f * f * (3 - 2 * f)
    return a + (b - a) * f


# ---------------------------------------------------------------- the sky
SKY = [(0, (38, 32, 78)), (40, (70, 46, 110)), (78, (150, 72, 120)), (104, (226, 112, 98)), (122, (246, 162, 92)),
       (140, (252, 214, 140))]
SUN = (124, 116)


def _sky(im: Img) -> None:
    for y in range(H):
        for (y0, c0), (y1, c1) in zip(SKY, SKY[1:]):
            if y0 <= y < y1 or y >= SKY[-1][0]:
                break
        if y >= SKY[-1][0]:
            c0 = c1 = SKY[-1][1]
            t = 0
        else:
            t = (y - y0) / (y1 - y0)
        steps = 4                                      # bands, dithered at their edges
        q = t * steps
        lo = int(q)
        frac = q - lo
        for x in range(W):
            k = lo + (1 if frac * 16 > BAYER[y % 4][x % 4] else 0)
            im.set(x, y, _mix(c0, c1, min(1.0, k / steps)))
    rng = random.Random(11)
    for _ in range(70):                                # the first stars, up high
        x, y = rng.randrange(W), rng.randrange(0, 52)
        if y < 40 or rng.random() < 0.3:
            im.set(x, y, (255, 240, 220) if rng.random() < 0.25 else (196, 180, 220))
    for x, y in ((40, 12), (120, 20), (262, 8)):       # a few bright ones, with a glint
        im.set(x, y, (255, 255, 240))
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            im.set(x + dx, y + dy, (210, 196, 230))


def _sun(im: Img) -> None:
    cx, cy = SUN
    for r, amt in ((54, 0.18), (42, 0.26), (32, 0.36), (24, 0.5)):   # the glow, in soft bands
        for y in range(cy - r, cy + 1):
            for x in range(cx - r, cx + r + 1):
                if math.hypot(x + 0.5 - cx, y + 0.5 - cy) <= r:
                    old = im.get(x, y)
                    im.set(x, y, _mix(old[:3], (255, 214, 140), amt))
    _disc(im, cx, cy, 15, (255, 236, 176))
    _disc(im, cx - 2, cy - 2, 11, (255, 246, 210))


def _cloud(im: Img, x0: int, y0: int, w: int, seed: int) -> None:
    """A long evening cloud: lilac on top, lit gold and rose underneath (the sun is below it)."""
    rng = random.Random(seed)
    puffs = []
    x = x0
    while x < x0 + w:
        r = rng.randint(4, 8)
        puffs.append((x, y0 - r // 2 + rng.randint(-1, 1), r))
        x += r + rng.randint(1, 4)
    top, mid, under, rim = (132, 92, 150), (176, 108, 146), (236, 146, 120), (255, 206, 150)
    for px, py, r in puffs:
        _disc(im, px, py, r, top)
    for px, py, r in puffs:
        _disc(im, px, py + 2, r - 1, mid)
    for y in range(y0 - 2, y0 + 10):
        for x in range(x0 - 10, x0 + w + 10):
            if im.get(x, y)[:3] in (top, mid) and im.get(x, y + 1)[:3] not in (top, mid, under, rim):
                im.set(x, y, rim)
                im.set(x, y - 1, under)
    for x in range(x0 - 4, x0 + w + 4):                # a flat underside
        for y in range(y0 + 4, y0 + 9):
            if im.get(x, y)[:3] in (top, mid):
                im.set(x, y, under if y < y0 + 6 else rim)


# ---------------------------------------------------------------- the land
def _ridge(im: Img, base: int, amp: float, scale: float, seed: int, col, snow=None, light=None) -> list[int]:
    tops = []
    for x in range(W):
        h = base - amp * (0.65 * _noise1(x / scale, seed) + 0.35 * _noise1(x / (scale / 3), seed + 5))
        peak = abs(((x / scale) * 1.7 + seed) % 2 - 1)          # sharper peaks
        h -= amp * 0.5 * (1 - peak)
        tops.append(int(h))
    for x in range(W):
        for y in range(tops[x], H):
            im.set(x, y, col)
        if snow is not None:
            for y in range(tops[x], min(H, tops[x] + 3)):
                if tops[x] < base - amp * 0.6:
                    im.set(x, y, snow)
        if light is not None and x > 0 and tops[x] < tops[x - 1]:   # the sunward slopes lit
            for y in range(tops[x], min(H, tops[x] + 6)):
                im.set(x, y, light)
    return tops


def _pine(im: Img, x: int, y: int, h: int, dark, mid, light=None) -> None:
    """A pine, from its base (x, y) up h pixels."""
    for i in range(h):
        yy = y - i
        half = max(0, int((h - i) * 0.38)) if i > 1 else 0
        if i <= 1:
            im.set(x, yy, (70, 44, 34))
            continue
        for dx in range(-half, half + 1):
            im.set(x + dx, yy, dark if dx < 0 or (i % 3 == 0 and abs(dx) == half) else mid)
        if light is not None and half > 0:
            im.set(x - half, yy, light)
    im.set(x, y - h, mid)


def _stone(im: Img, x0, y0, x1, y1, lit=True) -> None:
    """Castle stonework: lit on the sun's (left) side, courses of blocks."""
    base = (226, 198, 172) if lit else (150, 118, 140)
    dark = (196, 164, 148) if lit else (122, 94, 120)
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            c = base
            if (y - y0) % 4 == 3 or ((x + (4 if (y - y0) // 4 % 2 else 0)) % 8 == 0):
                c = dark
            im.set(x, y, c)


def _tower(im: Img, cx: int, top: int, bottom: int, half: int, roof_h: int) -> None:
    """A round tower: the lit half and the shaded half, a red cone of a roof, windows lit warm."""
    _stone(im, cx - half, top, cx, bottom, True)
    _stone(im, cx + 1, top, cx + half, bottom, False)
    for x in range(cx - half, cx + half + 1):         # a band where the roof overhangs
        im.set(x, top, (90, 64, 92))
    red, red_d, red_l = (198, 62, 54), (140, 38, 48), (236, 112, 86)
    _poly(im, [(cx - half - 2, top + 1), (cx + half + 3, top + 1), (cx + 0.5, top - roof_h)], red_d)
    _poly(im, [(cx - half - 2, top + 1), (cx + 1, top + 1), (cx + 0.5, top - roof_h)], red)
    for i in range(roof_h):                            # tiles, and a glint down the lit side
        y = top - i
        if i % 3 == 0:
            w = int((half + 2) * (1 - i / roof_h))
            for x in range(cx - w, cx + w + 1, 2):
                if im.get(x, y)[:3] in (red, red_d):
                    im.set(x, y, red_d if x > cx else (176, 50, 50))
        im.set(cx - int((half + 1) * (1 - i / roof_h)), y, red_l)
    im.set(cx, top - roof_h - 1, (90, 64, 92))
    for wy in range(top + 5, bottom - 4, 9):           # windows
        im.rect(cx - 1, wy, cx, wy + 2, (60, 34, 40))
        im.set(cx - 1, wy + 1, (255, 214, 110))
        im.set(cx, wy + 1, (250, 180, 80))


def _castle(im: Img) -> None:
    # the crag
    crag = [(150, 180), (168, 138), (182, 126), (206, 118), (246, 116), (276, 122), (296, 140), (312, 180)]
    mask = Img(W, H)
    _poly(mask, crag, (255, 255, 255))
    rng = random.Random(4)
    for y in range(110, H):                            # rock in strata: lit toward the sun, shaded away
        for x in range(140, W):
            if mask.get(x, y)[3] == 0:
                continue
            shade = (x - 160) / 150.0 + 0.25 * _noise1(x / 9.0 + y / 4.0, 21)
            band = (y // 5) % 2
            if shade < 0.35:
                c = (156, 124, 138) if band else (140, 110, 128)
            elif shade < 0.7:
                c = (118, 92, 118) if band else (106, 82, 108)
            else:
                c = (88, 66, 94) if band else (78, 58, 86)
            if mask.get(x, y - 1)[3] == 0:
                c = (182, 152, 150)                    # the lit rim along the top
            im.set(x, y, c)
    for _ in range(70):                                # cracks and ledges
        x, y = rng.randrange(160, 306), rng.randrange(124, 180)
        if mask.get(x, y)[3]:
            im.rect(x, y, x + rng.randint(2, 6), y, (64, 46, 72))
            im.set(x, y - 1, (190, 162, 156))
    for _ in range(40):                                # tufts of grass and moss clinging on
        x = rng.randrange(165, 300)
        y = next((yy for yy in range(110, H) if mask.get(x, yy)[3]), None)
        if y is not None and y < 160:
            im.set(x, y, (110, 150, 80))
            im.set(x, y - 1, (140, 180, 90))
    # the curtain wall with its battlements
    wall_top, wall_bot = 98, 120
    _stone(im, 186, wall_top, 228, wall_bot, True)
    _stone(im, 229, wall_top, 280, wall_bot, False)
    for x in range(186, 281, 4):
        im.rect(x, wall_top - 3, x + 1, wall_top - 1, (226, 198, 172) if x < 229 else (150, 118, 140))
    # the gate
    _poly(im, [(222, 120), (222, 110), (225, 106), (229, 106), (232, 110), (232, 120)], (52, 30, 34))
    for y in range(110, 120, 2):
        im.rect(223, y, 231, y, (88, 60, 50))
    # the keep, then the towers (tallest in the middle)
    _stone(im, 210, 64, 230, 98, True)
    _stone(im, 231, 64, 252, 98, False)
    for x in range(210, 253, 4):
        im.rect(x, 61, x + 1, 63, (226, 198, 172) if x < 231 else (150, 118, 140))
    for wx in (216, 224, 238, 246):
        im.rect(wx, 74, wx + 1, 79, (60, 34, 40))
        im.rect(wx, 75, wx + 1, 77, (255, 214, 110) if wx < 231 else (250, 176, 80))
    _tower(im, 196, 82, 120, 6, 18)
    _tower(im, 270, 86, 120, 6, 16)
    _tower(im, 231, 40, 64, 5, 20)
    _tower(im, 214, 52, 66, 4, 12)
    _tower(im, 250, 54, 66, 4, 12)


def flags(im: Img, t: float) -> None:
    """The pennants on the tower tops, waving (t in seconds)."""
    for (x, y, col) in ((231, 18, (240, 200, 70)), (196, 62, (196, 50, 50)), (270, 68, (196, 50, 50)),
                        (214, 38, (70, 110, 190)), (250, 40, (70, 110, 190))):
        im.rect(x, y, x, y + 4, (60, 40, 40))
        for i in range(7):
            wave = int(round(math.sin(t * 6 + i * 0.9 + x) * 1.2))
            h = 3 - i // 3
            for j in range(h):
                im.set(x + 1 + i, y + j + wave // 2, col if j else tuple(min(255, c + 40) for c in col))


def _woods_and_road(im: Img) -> None:
    rng = random.Random(9)
    # rolling green hills, back to front
    hill1 = [(0, 132), (40, 126), (90, 130), (140, 134), (170, 140), (170, 180), (0, 180)]
    _poly(im, hill1, (96, 120, 92))
    for x in range(0, 168, 5):                         # a far wood along the hill
        _pine(im, x + rng.randint(-1, 1), 133 + rng.randint(-2, 3), rng.randint(8, 13), (46, 78, 72), (62, 98, 82),
              (110, 140, 96))
    hill2 = [(0, 150), (50, 142), (110, 146), (160, 156), (200, 166), (240, 172), (320, 166), (320, 180), (0, 180)]
    _poly(im, hill2, (120, 160, 86))
    # the river from the crag's foot, catching the sun
    river = [(186, 180), (196, 168), (214, 160), (236, 156), (256, 158), (262, 162), (244, 165), (222, 170),
             (210, 180)]
    _poly(im, river, (110, 120, 170))
    for i in range(30):
        x, y = rng.randrange(196, 258), rng.randrange(157, 178)
        if im.get(x, y)[:3] == (110, 120, 170):
            im.rect(x, y, x + rng.randint(1, 3), y, (250, 206, 140))
    # nearer woods, darker
    for x in range(-4, 150, 7):
        _pine(im, x + rng.randint(-2, 2), 158 + rng.randint(-3, 3), rng.randint(14, 22), (34, 64, 54),
              (52, 92, 70), (132, 168, 96))
    # the near meadow and the road up to the castle gate
    near = [(0, 166), (60, 160), (120, 164), (170, 172), (190, 180), (0, 180)]
    _poly(im, near, (150, 186, 92))
    road = [(96, 180), (112, 170), (130, 162), (150, 154), (170, 146), (186, 136), (200, 128), (214, 121),
            (226, 120), (230, 121), (218, 126), (204, 134), (188, 144), (170, 154), (148, 164), (128, 172),
            (116, 180)]
    _poly(im, road, (206, 170, 112))
    for i in range(60):
        x, y = rng.randrange(96, 230), rng.randrange(120, 180)
        if im.get(x, y)[:3] == (206, 170, 112):
            im.set(x, y, (178, 140, 92))
    for _ in range(140):                               # grass tufts and wildflowers
        x, y = rng.randrange(0, 200), rng.randrange(162, 180)
        if im.get(x, y)[:3] == (150, 186, 92):
            im.set(x, y, (120, 160, 74))
            im.set(x, y - 1, (120, 160, 74))
            if rng.random() < 0.3:
                im.set(x + 1, y - 2, rng.choice([(250, 230, 120), (240, 140, 160), (255, 255, 240), (170, 150, 240)]))
    # a great oak framing the left edge
    for y in range(110, 180):
        w = 6 if y > 168 else 4
        im.rect(14 - w // 2, y, 14 + w // 2, y, (92, 60, 42))
        im.set(14 - w // 2, y, (128, 86, 56))
    for (cx, cy, r) in ((14, 100, 18), (-2, 112, 14), (30, 110, 13), (10, 86, 12), (24, 92, 11)):
        _disc(im, cx, cy, r, (44, 82, 56))
    for (cx, cy, r) in ((10, 96, 12), (26, 106, 9), (2, 108, 9), (8, 82, 7)):
        _disc(im, cx - 2, cy - 2, r - 3, (70, 116, 66))
    for (cx, cy, r) in ((6, 92, 5), (22, 102, 4), (6, 78, 3)):
        _disc(im, cx - 2, cy - 2, r, (124, 168, 80))


def background() -> Img:
    im = Img(W, H, (0, 0, 0))
    _sky(im)
    _sun(im)
    _cloud(im, 26, 54, 70, 1)
    _cloud(im, 116, 34, 56, 2)
    _cloud(im, 248, 62, 60, 3)
    _cloud(im, 160, 86, 40, 4)
    _ridge(im, 122, 34, 46, 3, (126, 84, 130), (238, 214, 226), (168, 112, 150))
    _ridge(im, 132, 18, 28, 8, (98, 72, 116), None, (130, 92, 132))
    _castle(im)
    _woods_and_road(im)
    flags(im, 0.0)
    return im


# ---------------------------------------------------------------- the dragon
def dragon(frame: int = 0) -> Img:
    """A green dragon in flight, facing right (its wings at one of four beats)."""
    im = Img(64, 40)
    body, belly, dark, wing, wing_d, bone = (54, 112, 82), (222, 190, 112), (30, 66, 52), (88, 150, 104), \
        (56, 104, 78), (30, 60, 46)
    beat = [-14, -6, 4, -2][frame % 4]                 # the wingtip's height
    # far wing (behind), near wing (in front)
    _poly(im, [(30, 18), (22, 18 + beat // 2 - 6), (14, 14 + beat // 2), (24, 20)], wing_d)
    # tail
    for i in range(22):
        x = 26 - i
        y = 21 + int(math.sin(i / 5.0) * 3) + i // 6
        t = max(1, 3 - i // 8)
        im.rect(x, y - t // 2, x, y + t // 2, body)
        im.set(x, y + t // 2, dark)
    _poly(im, [(4, 24), (0, 21), (1, 27)], dark)       # the tail's spade
    # body
    for (cx, cy, r) in ((30, 21, 6), (36, 20, 6), (40, 18, 5)):
        _disc(im, cx, cy, r, body)
    for x in range(26, 44):
        im.set(x, 25 - (1 if x > 38 else 0), belly)
        im.set(x, 24 - (1 if x > 38 else 0), belly)
    # neck and head
    for i in range(10):
        _disc(im, 43 + i * 0.9, 16 - i * 0.7, 3, body)
    _poly(im, [(50, 7), (60, 9), (62, 11), (56, 13), (50, 13)], body)
    im.rect(56, 12, 61, 12, belly)
    im.set(55, 9, (255, 230, 90))                      # an eye
    _poly(im, [(50, 7), (47, 2), (52, 6)], (230, 214, 170))   # horns
    _poly(im, [(53, 7), (52, 3), (55, 7)], (230, 214, 170))
    # legs tucked
    im.rect(32, 26, 33, 28, dark)
    im.rect(40, 24, 41, 27, dark)
    # spines
    for x in range(22, 46, 3):
        im.set(x, 14 + (x - 22) // 8, dark)
    # near wing: bones out to the tip, membrane between
    tip = (34 + (4 if beat > 0 else 0), 18 + beat - 12)
    mid = (46, 18 + beat - 8)
    pts = [(32, 17), tip, (28, 18 + beat // 2 - 4), (22, 22 + (beat // 3)), (36, 22), mid, (40, 17)]
    _poly(im, [(32, 17), tip, (24, 21 + beat // 3), (34, 21)], wing)
    _poly(im, [(34, 18), tip, mid, (40, 17)], wing)
    for a, b in (((34, 17), tip), (tip, mid), (tip, (24, 21 + beat // 3))):
        n = max(abs(b[0] - a[0]), abs(b[1] - a[1]), 1)
        for i in range(n + 1):
            im.set(int(a[0] + (b[0] - a[0]) * i / n), int(a[1] + (b[1] - a[1]) * i / n), bone)
    del pts
    # outline everything drawn, for the pixel-art edge
    out = Img(64, 40)
    out.px = list(im.px)
    for y in range(40):
        for x in range(64):
            if im.get(x, y)[3] == 0 and any(im.get(x + dx, y + dy)[3] for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                out.set(x, y, (24, 30, 34))
    return out


__all__ = ["background", "dragon", "flags", "W", "H"]
