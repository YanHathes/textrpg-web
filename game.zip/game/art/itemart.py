"""Inventory icons in the house style (game/art/pixart.py): 16 x 16 art pixels doubled to 32 x 32, outlined in a
darker shade of their own colour, lit from the top left. Weapons lie on the diagonal, grip at the bottom left
and point at the top right, the way a cosy farming game lays out its tools.

    icon("weapon", "longsword")      gear: weapon, armor, shield, helmet, cloak (with an optional tint)
    icon("icon", "potion_red")       everything else: potions, scrolls, gems, food, ore...
"""
from __future__ import annotations

import math
from functools import lru_cache

from game.art import gear as G
from game.art.canvas import Canvas
from game.art.pixart import Px, alpha, c, shade

WOOD, WOOD_D, WOOD_L = c("#9a6236"), c("#6a3e22"), c("#c08850")
STEEL, STEEL_L, STEEL_D = c("#b8c2cc"), c("#eef4f8"), c("#7a8490")
GOLD, GOLD_L = c("#e0b84a"), c("#fff0a0")
LEATHER = c("#8a5a32")


def _diag(s: Px, i0: int, i1: int, col, x0: int = 1, y0: int = 14, w: int = 1) -> None:
    """Pixels along the rising diagonal from (x0, y0): step i is (x0 + i, y0 - i)."""
    for i in range(i0, i1 + 1):
        s.p(x0 + i, y0 - i, col)
        if w >= 2:
            s.p(x0 + i + 1, y0 - i, col)


def _done(s: Px, darken: float = 0.55) -> Canvas:
    s.outline(darken)
    return s.done()


# ======================================================================
# Weapons
# ======================================================================
def _weapon(wid: str, tint: str = "") -> Px:
    w = G.WEAPONS[wid]
    head = c(tint) if tint else c(w.head)
    hl, hd = shade(head, 0.35), shade(head, -0.25)
    grip = c(w.handle)
    guard = c(w.guard)
    k = w.kind
    s = Px()
    n = max(4, min(13, round(w.length * 0.75)))          # how far up the diagonal it reaches
    if k in ("blade", "rapier", "curved"):
        gl = 2 if w.length < 8 else 3
        _diag(s, 0, 0, guard)                            # pommel
        _diag(s, 1, gl, grip)
        g = gl + 1                                        # the crossguard, across the diagonal
        cx, cy = 1 + g, 14 - g
        span = 1 if k == "rapier" or w.length < 6 else 2
        for d in range(-span, span + 1):
            s.p(cx + d, cy + d, guard)
        if k == "rapier":
            s.p(cx - 1, cy, guard)
            s.p(cx, cy + 1, guard)
        top = min(14, g + max(3, n - g))
        broad = w.width >= 1.3 and k != "rapier"
        for i in range(g + 1, top + 1):
            x, y = 1 + i, 14 - i
            bend = 0
            if k == "curved":                               # a scimitar sweeps back toward its point
                bend = ((i - g) * (i - g)) // 9
            s.p(x + bend, y + bend, hl)                  # the lit edge
            s.p(x + 1 + bend, y + bend, head)
            if broad:
                s.p(x + 1 + bend, y + 1 + bend, hd)
        tip = 1 + top
        s.p(tip + 1, 14 - top - 1, hl)
    elif k in ("axe", "double_axe", "pick", "hammer", "mace", "spiked", "flail", "club", "sickle"):
        handle_top = n
        if k == "club":                                   # a cudgel, thickening to its head
            fat = 2.2 if w.width >= 2 else 1.7
            ex, ey = 1 + handle_top + 0.5, 14 - handle_top + 0.5
            px_, py_ = 0.7071, 0.7071
            s.poly([(1.5 - px_ * 0.6, 14.5 - py_ * 0.6), (1.5 + px_ * 0.6, 14.5 + py_ * 0.6),
                    (ex + px_ * fat, ey + py_ * fat), (ex + 1, ey - 1), (ex - px_ * fat, ey - py_ * fat)], grip)
            _diag(s, 2, handle_top, shade(grip, 0.22), x0=1, y0=13)
            for i in range(4, handle_top, 3):
                s.p(2 + i, 14 - i, shade(grip, -0.25))     # knots
            return s
        if k != "flail":
            _diag(s, 0, handle_top, grip)
            _diag(s, 1, handle_top - 1, shade(grip, 0.2), x0=1, y0=13)
        hx, hy = 1 + handle_top, 14 - handle_top
        if k in ("axe", "double_axe"):
            big = 3 if w.width >= 1.3 else 2
            s.poly([(hx - 1, hy - big), (hx + big + 1, hy - 1), (hx + 1, hy + big + 1), (hx - 1, hy + 1)], head)
            s.line(hx + big, hy - 1, hx, hy + big, hl)
            if k == "double_axe":
                s.poly([(hx - big - 2, hy - 1), (hx, hy - big - 2), (hx + 1, hy - 1), (hx - 1, hy + 1)], head)
                s.line(hx - big - 1, hy - 1, hx, hy - big - 1, hl)
        elif k == "pick":
            for d in range(-3, 4):
                s.p(hx + d, hy + d, head if abs(d) < 3 else hl)
        elif k == "hammer":
            wd = 1.5 if w.width >= 1.5 else 1.0            # a solid head across the haft
            ln = 3.2 if w.width >= 1.5 else 2.6
            ux, uy = 0.7071, 0.7071                         # along the head (across the haft)
            vx, vy = 0.7071, -0.7071                        # along the haft
            cx, cy = hx + 0.5, hy + 0.5
            pts = [(cx + ux * a + vx * b, cy + uy * a + vy * b) for a, b in
                   ((-ln, -wd), (ln, -wd), (ln, wd), (-ln, wd))]
            s.poly(pts, head)
            s.line(round(cx - ux * ln + vx * wd), round(cy - uy * ln + vy * wd),
                   round(cx + ux * ln + vx * wd), round(cy + uy * ln + vy * wd), hl)
        elif k in ("mace", "spiked"):
            s.disc(hx + 0.5, hy + 0.5, 2.6, 2.6, head)
            s.p(hx - 1, hy - 1, hl)
            s.p(hx, hy - 1, hl)
            if k == "spiked":
                for (dx, dy) in ((0, -3), (3, 0), (-3, 1), (2, -2), (-2, 3)):
                    s.p(hx + dx, hy + dy, hl)
            else:
                for (dx, dy) in ((0, -3), (3, 0)):
                    s.p(hx + dx, hy + dy, hd)
        elif k == "flail":
            _diag(s, 0, 6, grip)
            for i in range(7, 10):
                s.p(1 + i, 14 - i - (i % 2), STEEL_D)
            s.disc(12, 3, 2.4, 2.4, head)
            s.p(11, 2, hl)
            for (dx, dy) in ((0, -3), (3, 0), (-2, 2)):
                s.p(12 + dx, 3 + dy, hl)
        elif k == "sickle":
            for i, (dx, dy) in enumerate(((0, -1), (1, -2), (2, -2), (3, -1), (4, 0), (4, 1), (3, 2))):
                s.p(hx + dx, hy + dy, hl if i < 4 else head)
    elif k in ("spear", "pike", "lance", "glaive", "halberd", "trident", "staff", "staff_orb"):
        _diag(s, max(0, 13 - n), 11, grip)                  # a javelin is shorter than a spear
        hx, hy = 13, 2
        if k in ("spear", "pike"):
            s.p(hx, hy, hl)
            s.p(hx + 1, hy - 1, hl)
            s.p(hx + 1, hy, head)
            s.p(hx, hy - 1, head)
            s.p(hx - 1, hy + 1, guard)
        elif k == "lance":
            for i in range(6, 12):
                s.p(1 + i, 13 - i, head)
                s.p(2 + i, 14 - i, hd)
            s.p(13, 1, hl)
            for d in (-1, 0, 1):
                s.p(5 + d, 9 + d, guard)
        elif k == "trident":
            for (dx, dy) in ((0, 0), (1, -1), (-1, -1), (0, -2), (2, 0), (2, -2)):
                s.p(hx + dx - 1, hy + dy + 1, hl)
        elif k in ("glaive", "halberd"):
            s.p(hx, hy, hl)
            s.p(hx + 1, hy - 1, hl)
            if k == "halberd":
                s.poly([(hx - 3, hy - 1), (hx - 1, hy - 3), (hx, hy + 1), (hx - 2, hy + 2)], head)
            else:
                s.poly([(hx - 1, hy - 1), (hx + 2, hy - 2), (hx + 1, hy + 2), (hx - 2, hy + 1)], head)
            s.p(hx - 2, hy, hl)
        elif k == "staff":
            _diag(s, 1, 10, shade(grip, 0.2), x0=1, y0=13)
            s.disc(13, 2, 1.5, 1.5, grip)
        else:
            s.disc(13, 2, 2.2, 2.2, head)
            s.p(12, 1, c("#ffffff"))
            for (dx, dy) in ((-2, -1), (2, 1), (1, -2)):
                s.put(13 + dx, 2 + dy, alpha(head, 110))
    elif k == "bow":
        pts = []
        a0, a1 = (2, 13) if w.length >= 7 else (4, 11)    # a longbow from corner to corner, a shortbow less
        for i in range(25):                               # the limbs bowed out toward the top left
            t = i / 24
            x = (1 - t) ** 2 * a0 + 2 * (1 - t) * t * 1.5 + t * t * a1
            y = (1 - t) ** 2 * a1 + 2 * (1 - t) * t * 1.5 + t * t * a0
            pts.append((round(x), round(y)))
        for (x, y) in pts:
            s.p(x, y, grip)
        for (x, y) in pts[3:-3]:
            s.p(x + 1, y + 1, shade(grip, -0.15))
        s.line(a0, a1, a1, a0, c("#e8e0c8"))              # the string
        s.p(4, 5, LEATHER)                                # the grip wrap
        s.p(5, 4, LEATHER)
    elif k == "crossbow":
        size = 2 if w.length <= 5 else (4 if w.length >= 10 else 3)     # hand, light, heavy
        top = 5 + size
        _diag(s, 9 - top, 9, grip)
        _diag(s, 10 - top, 8, shade(grip, 0.2), x0=1, y0=13)
        for d in range(-size, size + 1):                  # the bow across the stock
            s.p(9 + d, 6 + d, head if abs(d) < size else hd)
            if size >= 4:
                s.p(10 + d, 6 + d, hd)
        s.line(9 - size, 6 - size + 1, 9 + size - 1, 6 + size, c("#e8e0c8"))
        s.p(12, 3, STEEL_L)
    elif k == "wand":
        _diag(s, 3, 9, grip)
        s.p(11, 3, head)
        s.p(12, 2, shade(head, 0.5))
        for (dx, dy) in ((2, -1), (-1, -2), (2, 2)):
            s.put(12 + dx, 2 + dy, alpha(head, 120))
    elif k == "torch":
        _diag(s, 1, 8, grip)
        s.disc(11, 4, 2.2, 2.2, c("#f08a30"))
        s.p(11, 3, c("#f6c040"))
        s.p(12, 2, c("#fff0a0"))
        s.p(9, 6, c("#5a3a22"))
    elif k == "whip":
        s.disc(8, 8, 5, 5, LEATHER)
        for y in range(16):
            for x in range(16):
                if ((x + 0.5 - 8) ** 2 + (y + 0.5 - 8) ** 2) < 3.6 ** 2:
                    s.clear(x, y)
        s.line(2, 14, 4, 11, grip)
        s.p(13, 4, shade(LEATHER, 0.3))
    elif k == "sling":
        s.line(2, 2, 8, 9, LEATHER)
        s.line(13, 3, 8, 9, LEATHER)
        s.disc(8, 10, 2.2, 1.6, shade(LEATHER, 0.1))
        s.p(8, 9, c("#a8a098"))
    elif k == "net":
        for x in range(2, 14):
            for y in range(2, 14):
                if (x % 3 == 2 or y % 3 == 2) and (x - 8) ** 2 + (y - 8) ** 2 < 40:
                    s.p(x, y, c("#d8c8a0"))
        s.p(3, 3, STEEL_D)
        s.p(12, 12, STEEL_D)
    elif k == "dart":
        _diag(s, 4, 8, grip)
        s.p(10, 4, head)
        s.p(11, 3, hl)
        s.p(4, 11, c("#c84a3a"))
        s.p(5, 11, c("#c84a3a"))
        s.p(4, 10, c("#c84a3a"))
    elif k == "blowgun":
        _diag(s, 0, 12, grip, w=2)
        s.p(13, 2, c("#2a2224"))
    return s


# ======================================================================
# Armor, helmets, shields, cloaks
# ======================================================================
def _armor(aid: str, tint: str = "") -> Px:
    st = G.ARMOR_STYLES[aid]
    base = c(tint) if tint else c(st.base)
    sleeves = shade(base, -0.1) if tint else c(st.sleeves)
    pat = st.pattern
    lit, dk = shade(base, 0.22), shade(base, -0.22)
    s = Px()
    robe = pat == "robe"
    bottom = 15 if robe else 13
    for y in range(3, bottom + 1):                        # the body
        spread = (y - 9) // 2 if robe and y > 9 else 0
        s.hline(4 - spread, 11 + spread, y, base)
    s.rect(1, 3, 3, 9 if not robe else 11, sleeves)       # the sleeves
    s.rect(12, 3, 14, 9 if not robe else 11, sleeves)
    s.hline(1, 3, 3, shade(sleeves, 0.2))
    s.hline(12, 14, 3, shade(sleeves, 0.1))
    for x in range(6, 10):                                # the neck hole
        s.clear(x, 3)
    s.clear(7, 4)
    s.clear(8, 4)
    s.vline(11, 4, bottom, shade(base, -0.15))
    s.vline(4, 4, bottom, shade(base, 0.12))
    if pat in ("chain", "rings"):
        for y in range(4, bottom + 1):
            for x in range(4, 12):
                if (x + y) % 2 == 0 and s.get(x, y) is not None:
                    s.p(x, y, dk if pat == "chain" else lit)
    elif pat == "scale":
        for y in range(4, bottom, 2):
            for x in range(4 + (y // 2) % 2, 12, 2):
                s.p(x, y, lit)
                s.p(x, y + 1, dk)
    elif pat in ("plate", "splint"):
        s.vline(6, 5, bottom - 1, lit)
        s.p(7, 6, shade(base, 0.45))
        s.hline(4, 11, 9, dk)
        if pat == "splint":
            for x in range(5, 12, 2):
                s.vline(x, 10, bottom, dk)
        s.rect(0, 2, 4, 4, shade(sleeves, 0.08))           # pauldrons
        s.rect(11, 2, 15, 4, shade(sleeves, 0.08))
        s.hline(0, 4, 2, shade(sleeves, 0.35))
        s.hline(11, 15, 2, shade(sleeves, 0.25))
    elif pat == "quilted":
        for y in range(5, bottom, 2):
            s.hline(5, 10, y, dk)
    elif pat in ("leather", "studded"):
        s.vline(8, 5, bottom, dk)
        if pat == "studded":
            for y in range(5, bottom, 2):
                for x in range(5 + (y % 2), 11, 2):
                    s.p(x, y, c("#d8c8a0"))
    elif pat == "hide":
        trim = c(st.trim) if st.trim else lit
        for x in range(1, 15):
            s.p(x, 3 + (x % 2), trim)
    elif robe:
        trim = c(st.trim) if st.trim else lit
        s.vline(7, 5, 15, trim)
        s.hline(3, 12, 15, trim)
    elif pat == "noble":
        trim = c(st.trim) if st.trim else GOLD
        s.vline(7, 4, bottom, trim)
        for y in range(5, bottom, 2):
            s.p(9, y, trim)
    if pat in ("cloth", "leather", "studded", "quilted", "noble", "chain", "scale", "hide", "rings"):
        s.hline(4, 11, bottom - 1, c("#5a3a22"))           # a belt
        s.p(7, bottom - 1, GOLD)
    if st.gauntlets:
        s.rect(1, 9, 3, 10, STEEL)
        s.rect(12, 9, 14, 10, STEEL)
    return s


def _helmet(hid: str, tint: str = "") -> Px:
    s = Px()
    steel = c(tint) if tint else STEEL
    lit, dk = shade(steel, 0.35), shade(steel, -0.25)
    if hid in ("cap", "kettle", "horned_helm", "great_helm", "coif"):
        col = c(tint) if tint else (c("#8a5a32") if hid == "cap" else steel)
        s.disc(8, 9, 6, 6, col)
        s.rect(2, 9, 13, 13 if hid in ("great_helm", "coif") else 10, col)
        s.disc(6, 6, 2.5, 2, shade(col, 0.3))
        if hid == "kettle":
            s.hline(0, 15, 11, shade(col, -0.1))
            s.hline(0, 15, 12, shade(col, -0.3))
            for y in range(13, 16):
                for x in range(16):
                    s.clear(x, y)
        elif hid == "cap":
            s.hline(2, 13, 11, shade(col, -0.25))
            for y in range(12, 16):
                for x in range(16):
                    s.clear(x, y)
            s.p(8, 3, shade(col, -0.2))
        elif hid == "great_helm":
            s.hline(4, 11, 9, c("#1a1418"))               # the eye slit
            s.vline(8, 10, 13, dk)
            for (x, y) in ((5, 12), (11, 12)):
                s.p(x, y, c("#1a1418"))
        elif hid == "coif":
            for y in range(3, 16):
                for x in range(16):
                    if s.get(x, y) is not None and (x + y) % 2 == 0:
                        s.p(x, y, dk)
            for y in range(8, 13):
                for x in range(5, 11):
                    s.clear(x, y)
        elif hid == "horned_helm":
            s.hline(2, 13, 10, dk)
            for y in range(11, 16):
                for x in range(16):
                    s.clear(x, y)
            bone = c("#e8e2cc")
            for side, x0 in ((-1, 2), (1, 13)):
                for i in range(5):
                    s.p(x0 + side * (i // 2 + 1), 8 - i, bone if i < 4 else shade(bone, -0.2))
    elif hid == "hood":
        col = c(tint) if tint else c("#4a5a3a")
        s.disc(8, 8, 6.5, 6.5, col)
        s.rect(1, 8, 14, 15, col)
        s.disc(8, 10, 3.5, 4, c("#1e1a1c"))
        s.disc(6, 4, 2, 1.6, shade(col, 0.25))
        s.vline(14, 8, 15, shade(col, -0.2))
    elif hid == "wizard_hat":
        col = c(tint) if tint else c("#3b2f6a")
        s.poly([(2, 13), (14, 13), (9, 1)], col)
        s.hline(0, 15, 13, shade(col, -0.15))
        s.hline(0, 15, 14, shade(col, -0.3))
        s.hline(4, 12, 11, GOLD)
        s.line(4, 12, 8, 2, shade(col, 0.25))
        s.p(9, 6, GOLD_L)
    elif hid in ("crown", "circlet"):
        col = c(tint) if tint else GOLD
        if hid == "crown":
            s.rect(2, 8, 13, 12, col)
            for x in (2, 5, 8, 11, 13):
                s.vline(x, 4, 8, col)
                s.p(x, 4, shade(col, 0.4))
            s.p(7, 10, c("#d03a4a"))
            s.p(4, 10, c("#4ab0e0"))
            s.p(11, 10, c("#4ac080"))
            s.hline(2, 13, 8, shade(col, 0.3))
        else:
            s.disc(8, 9, 6, 3.5, col)
            for y in range(16):
                for x in range(16):
                    if ((x + 0.5 - 8) / 4.8) ** 2 + ((y + 0.5 - 9) / 2.4) ** 2 < 1:
                        s.clear(x, y)
            s.rect(7, 5, 8, 6, c("#4ab0e0"))
            s.p(7, 5, c("#c8f0ff"))
    return s


def _shield(sid: str, tint: str = "", color: str = "") -> Px:
    s = Px()
    rim = c(tint) if tint else STEEL
    face = c(color) if color else c("#8a5a32")
    if sid in ("round", "buckler"):
        r = 7 if sid == "round" else 5
        s.disc(8, 8, r, r, rim)
        s.disc(8, 8, r - 1.2, r - 1.2, face)
        if sid == "round":
            for a in range(-6, 7, 3):                     # planks
                s.vline(8 + a, 3, 13, shade(face, -0.15))
        s.disc(8, 8, 1.8, 1.8, rim)
        s.p(7, 7, shade(rim, 0.4))
        s.disc(5.5, 5, 1.5, 1, shade(face, 0.2))
    elif sid == "tower":
        s.rect(3, 0, 12, 15, rim)
        s.rect(4, 1, 11, 14, face)
        s.vline(4, 1, 14, shade(face, 0.2))
        s.hline(4, 11, 7, rim)
        s.vline(8, 1, 14, shade(rim, -0.1))
    else:                                                 # heater
        s.poly([(1, 1), (15, 1), (15, 8), (8, 15), (1, 8)], rim)
        s.poly([(2, 2), (14, 2), (14, 8), (8, 14), (2, 8)], face)
        s.vline(8, 2, 13, shade(face, 0.3))
        s.hline(2, 13, 6, shade(face, 0.3))
        s.disc(4.5, 4, 1.5, 1, shade(face, 0.25))
    return s


def _cloak(cid: str, tint: str = "", color: str = "") -> Px:
    s = Px()
    col = c(color or tint or "#7a2a2a")
    short = cid == "cape"
    bottom = 10 if short else 15
    for y in range(2, bottom + 1):
        spread = (y - 2) // 3
        s.hline(4 - spread, 11 + spread, y, col)
        s.p(11 + spread, y, shade(col, -0.2))
        s.p(4 - spread, y, shade(col, 0.15))
    for x in range(6, 12, 3):
        s.vline(x, 5, bottom - 1, shade(col, -0.12))      # folds
    s.hline(4 - (bottom - 2) // 3, 11 + (bottom - 2) // 3, bottom, shade(col, -0.25))
    if cid == "fur_cloak":
        fur = c("#e8dcc4")
        s.rect(3, 1, 12, 3, fur)
        for x in range(3, 13, 2):
            s.p(x, 4, fur)
            s.p(x + 1, 0, shade(fur, -0.1))
    else:
        s.hline(5, 10, 2, shade(col, 0.2))
    s.disc(8, 3, 1.3, 1.3, GOLD)
    return s


# ======================================================================
# Everything else
# ======================================================================
def potion(col="#d03a3a") -> Px:
    s = Px()
    liquid = c(col)
    glass = c("#cfe6ee")
    s.disc(8, 10, 5, 5, glass)
    s.disc(8, 10.5, 4, 4, liquid)
    s.hline(4, 12, 8, shade(liquid, 0.25))                # the liquid's surface
    s.rect(6, 2, 9, 5, glass)
    s.rect(6, 1, 9, 2, c("#8a5a32"))                       # the cork
    s.p(6, 1, c("#b07a48"))
    s.p(5, 9, c("#ffffff"))
    s.p(5, 10, alpha("#ffffff", 180))
    s.p(10, 13, shade(liquid, -0.2))
    return s


def scroll() -> Px:
    s = Px()
    paper = c("#ecdcb4")
    s.rect(3, 3, 12, 12, paper)
    for y in (5, 7, 9):
        s.hline(5, 10, y, c("#a89878"))
    for (y, col) in ((2, shade(paper, -0.05)), (13, shade(paper, -0.1))):
        s.rect(2, y - 1, 13, y + 1, col)
        s.hline(2, 13, y - 1, shade(col, 0.15))
        s.p(1, y, shade(col, -0.2))
        s.p(14, y, shade(col, -0.2))
    s.rect(7, 12, 8, 15, c("#a02a2a"))                     # a ribbon and seal
    s.p(7, 13, c("#d04a4a"))
    return s


def book(col="#7a2a2a") -> Px:
    s = Px()
    cover = c(col)
    s.rect(3, 2, 13, 14, cover)
    s.rect(3, 2, 4, 14, shade(cover, -0.2))               # the spine
    s.rect(12, 3, 13, 13, c("#efe6cc"))                    # the pages' edge
    for y in range(4, 13, 2):
        s.p(13, y, c("#c8bc9c"))
    s.rect(6, 5, 10, 8, GOLD)                              # a gilt plate
    s.rect(7, 6, 9, 7, shade(GOLD, -0.2))
    s.hline(5, 11, 2, shade(cover, 0.2))
    return s


def bag() -> Px:
    s = Px()
    cloth = c("#a07a4a")
    s.disc(8, 10, 6, 5, cloth)
    s.rect(6, 3, 10, 6, cloth)
    s.hline(5, 11, 5, c("#6a4a2a"))                        # the drawstring
    s.p(11, 6, c("#6a4a2a"))
    s.p(12, 7, c("#6a4a2a"))
    s.disc(6, 9, 2, 2, shade(cloth, 0.18))
    s.hline(5, 11, 3, shade(cloth, 0.15))
    return s


def coins() -> Px:
    s = Px()
    for (x, y) in ((4, 11), (8, 12), (11, 10), (6, 8), (10, 7), (7, 4)):
        s.disc(x + 1, y + 1, 2.6, 1.8, shade(GOLD, -0.3))
        s.disc(x + 1, y, 2.6, 1.6, GOLD)
        s.p(x, y - 1, GOLD_L)
    return s


def gem(col="#3ab0e0") -> Px:
    s = Px()
    g = c(col)
    s.poly([(4, 5), (12, 5), (14, 7), (8, 14), (2, 7)], g)
    s.poly([(4, 5), (12, 5), (14, 7), (2, 7)], shade(g, 0.25))  # the table
    s.line(5, 7, 8, 13, shade(g, -0.2))
    s.line(11, 7, 8, 13, shade(g, -0.15))
    s.p(5, 6, c("#ffffff"))
    s.p(6, 6, alpha("#ffffff", 170))
    return s


def ring(col="#e0b84a", stone="#d03a5a") -> Px:
    s = Px()
    band = c(col)
    s.disc(8, 10, 5, 4, band)
    for y in range(16):
        for x in range(16):
            if ((x + 0.5 - 8) / 3.2) ** 2 + ((y + 0.5 - 10.3) / 2.4) ** 2 < 1:
                s.clear(x, y)
    s.disc(8, 5, 2.4, 2.2, c(stone))
    s.p(7, 4, c("#ffffff"))
    s.hline(4, 6, 8, shade(band, 0.35))
    return s


def amulet() -> Px:
    s = Px()
    chain = c("#c8a050")
    for i in range(6):
        s.p(3 + i, 1 + i, chain if i % 2 else shade(chain, 0.3))
        s.p(12 - i, 1 + i, chain if i % 2 else shade(chain, 0.3))
    s.disc(8, 10, 3.5, 3.5, GOLD)
    s.disc(8, 10, 2, 2, c("#3a8ad0"))
    s.p(7, 9, c("#c8f0ff"))
    return s


def key() -> Px:
    s = Px()
    k = c("#c8a050")
    s.disc(4.5, 4.5, 3, 3, k)
    s.clear(4, 4)
    s.clear(5, 4)
    s.clear(4, 5)
    s.clear(5, 5)
    _diag(s, 3, 11, k, x0=3, y0=6 + 0)
    for i in range(6, 12):
        s.p(i, i, k)
    s.p(11, 13, k)
    s.p(12, 12, k)
    s.p(9, 11, k)
    s.p(3, 3, shade(k, 0.35))
    return s


def bread() -> Px:
    s = Px()
    crust = c("#c8843a")
    s.disc(8, 9, 6.5, 4.5, crust)
    s.disc(7, 8, 5, 3, shade(crust, 0.15))
    for x in (5, 8, 11):                                   # scores in the crust
        s.line(x - 1, 7, x + 1, 9, c("#f0d090"))
    s.hline(3, 13, 12, shade(crust, -0.2))
    return s


def bottle(col="#6a3a8a") -> Px:
    s = Px()
    g = c(col)
    s.rect(4, 6, 11, 14, g)
    s.disc(7.5, 6, 4, 2, g)
    s.rect(6, 1, 9, 5, g)
    s.rect(6, 0, 9, 1, c("#8a5a32"))
    s.rect(5, 8, 10, 11, c("#e8dcb4"))                    # a label
    s.hline(6, 9, 9, c("#a89878"))
    s.vline(5, 3, 13, shade(g, 0.35))
    return s


def rope() -> Px:
    s = Px()
    r = c("#c8a868")
    for (rx, ry) in ((6, 5), (4.5, 3.6)):
        for a in range(0, 360, 12):
            x = 8 + math.cos(math.radians(a)) * rx
            y = 9 + math.sin(math.radians(a)) * ry
            s.p(round(x), round(y), r if a % 24 else shade(r, -0.2))
    s.line(13, 9, 15, 14, r)
    return s


def arrows() -> Px:
    s = Px()
    for k, off in enumerate((-2, 0, 2)):
        for i in range(2, 13):
            s.p(i + off, 15 - i + off * 0, WOOD_L if k != 1 else WOOD)
        s.p(13 + off, 2, STEEL_L)
        s.p(14 + off, 1, STEEL)
        s.p(2 + off, 13, c("#e8e0d0"))
        s.p(3 + off, 14, c("#c84a3a"))
    s.line(5, 9, 8, 12, c("#6a4a2a"))                      # the binding
    return s


def ore(col="#8a8680", fleck="#c87a3a") -> Px:
    s = Px()
    rock = c(col)
    s.disc(8, 9, 6, 5, rock)
    s.disc(6, 7, 3, 2.4, shade(rock, 0.2))
    s.hline(4, 12, 13, shade(rock, -0.25))
    for (x, y) in ((5, 9), (9, 7), (11, 10), (7, 11)):
        s.p(x, y, c(fleck))
        s.p(x - 1, y - 1, shade(c(fleck), 0.4))
    return s


def herb() -> Px:
    s = Px()
    stem, leaf = c("#3e7a32"), c("#6ab048")
    s.line(4, 14, 9, 4, stem)
    for (x, y) in ((5, 10), (7, 7), (8, 5)):
        s.disc(x - 2, y, 1.8, 1.2, leaf)
        s.disc(x + 2, y - 1, 1.8, 1.2, shade(leaf, -0.12))
    s.p(9, 3, c("#f4f0e0"))
    s.p(10, 2, c("#f6d84a"))
    return s


def letter() -> Px:
    s = Px()
    paper = c("#efe2c0")
    s.rect(1, 4, 14, 12, paper)
    s.line(1, 4, 7, 9, shade(paper, -0.18))
    s.line(14, 4, 8, 9, shade(paper, -0.18))
    s.disc(7.5, 9, 1.8, 1.6, c("#b02a2a"))
    s.p(7, 8, c("#e05a5a"))
    s.hline(1, 14, 12, shade(paper, -0.2))
    return s


def tool() -> Px:
    s = Px()
    _diag(s, 0, 8, WOOD)
    s.rect(8, 2, 13, 5, STEEL)                             # a hammer
    s.hline(8, 13, 2, STEEL_L)
    s.line(11, 13, 14, 8, STEEL_D)                         # and a chisel
    s.p(14, 8, STEEL_L)
    return s


def chest_small() -> Px:
    s = Px()
    s.rect(1, 6, 14, 14, WOOD)
    s.disc(7.5, 6, 6.6, 3, shade(WOOD, 0.1))
    s.hline(1, 14, 6, WOOD_D)
    for x in (3, 12):
        s.vline(x, 3, 14, c("#5e626e"))
    s.rect(7, 6, 8, 9, GOLD)
    s.p(7, 8, c("#6a4a10"))
    return s


def log(col="#8a5a32", end="#d8b07a") -> Px:
    s = Px()
    bark = c(col)
    s.rect(1, 6, 12, 11, bark)
    s.hline(1, 12, 6, shade(bark, 0.2))
    s.hline(1, 12, 11, shade(bark, -0.25))
    for x in (4, 8):
        s.hline(x, x + 2, 8, shade(bark, -0.2))
    s.disc(13, 8.5, 2.2, 2.8, c(end))
    s.p(13, 8, shade(c(end), -0.2))
    return s


def stone_block() -> Px:
    s = Px()
    st = c("#b0a898")
    s.rect(1, 3, 14, 13, shade(st, -0.18))
    s.rect(1, 3, 14, 7, st)
    s.hline(1, 14, 3, shade(st, 0.25))
    s.vline(6, 8, 13, shade(st, -0.32))
    s.vline(10, 8, 12, shade(st, -0.32))
    return s


def fish(col="#7a9ab0") -> Px:
    s = Px()
    f = c(col)
    s.disc(7, 8, 5.5, 3, f)
    s.poly([(11, 8), (15, 4), (15, 12)], shade(f, -0.1))   # the tail
    s.hline(3, 10, 9, shade(f, 0.3))                        # its pale belly
    s.hline(3, 9, 6, shade(f, -0.2))
    s.p(3, 7, c("#1a1418"))
    s.p(2, 7, c("#ffffff"))
    return s


def berries(col="#3a2a6a") -> Px:
    s = Px()
    b = c(col)
    s.line(8, 1, 8, 5, c("#3e7a32"))
    s.disc(10, 3, 2, 1.2, c("#5aa040"))
    for (x, y) in ((5, 8), (9, 7), (7, 11), (11, 11), (4, 12)):
        s.disc(x, y, 2, 2, b)
        s.p(x - 1, y - 1, shade(b, 0.5))
    return s


def mushroom(cap="#b0743a") -> Px:
    s = Px()
    col = c(cap)
    s.rect(6, 8, 9, 14, c("#e8dcc0"))
    s.vline(9, 8, 14, c("#c8bca0"))
    s.disc(7.5, 7, 6, 4, col)
    s.hline(2, 13, 8, shade(col, -0.25))
    s.disc(5.5, 5, 2, 1.2, shade(col, 0.25))
    for (x, y) in ((6, 4), (10, 5), (8, 6)):
        s.p(x, y, c("#f4ecd8"))
    return s


def grain() -> Px:
    s = Px()
    stalk, ear = c("#b89a4a"), c("#e0c060")
    for k, x in enumerate((5, 8, 11)):
        s.line(8, 14, x, 5, stalk)
        for i in range(4):
            s.p(x + (i % 2) - (1 if k == 0 else 0), 1 + i, ear if i else shade(ear, 0.3))
            s.p(x, 1 + i, ear)
    s.hline(6, 10, 10, c("#a83a3a"))                       # tied in a sheaf
    return s


def hide(col="#9a6a42") -> Px:
    s = Px()
    h = c(col)
    s.poly([(2, 4), (6, 2), (10, 2), (14, 4), (13, 8), (14, 12), (9, 14), (7, 14), (2, 12), (3, 8)], h)
    s.disc(8, 8, 3.5, 3.5, shade(h, 0.15))
    for (x, y) in ((3, 4), (13, 4), (2, 12), (13, 12)):
        s.p(x, y, shade(h, -0.25))
    return s


ICONS = {
    "potion_red": lambda: potion("#d03a3a"), "potion_blue": lambda: potion("#3a6ad0"),
    "potion_green": lambda: potion("#3aa04a"), "potion_gold": lambda: potion("#e0b03a"),
    "scroll": scroll, "book_red": lambda: book("#7a2a2a"), "book_blue": lambda: book("#2a4a7a"), "bag": bag,
    "coins": coins, "gem_blue": lambda: gem("#3ab0e0"), "gem_red": lambda: gem("#e03a4a"),
    "gem_green": lambda: gem("#3ad07a"), "ring_gold": lambda: ring(), "ring_silver": lambda: ring("#c8d0d8", "#3a8ad0"),
    "amulet": amulet, "key": key, "bread": bread, "bottle": bottle, "rope": rope, "arrows": arrows,
    "ore_iron": lambda: ore(), "ore_gold": lambda: ore("#8a7a60", "#f0c840"), "herb": herb, "letter": letter,
    "tool": tool, "chest": chest_small, "log": lambda: log(), "log_dark": lambda: log("#4a3022", "#8a6040"),
    "stone": stone_block, "fish": lambda: fish(), "fish_gold": lambda: fish("#e0a83a"), "berries": lambda: berries(),
    "berries_red": lambda: berries("#c8303a"), "mushroom": lambda: mushroom(), "grain": grain, "hide": lambda: hide(),
}


def icon(kind: str, name: str, tint: str = "", color: str = "") -> Canvas | None:
    """A 32 x 32 inventory icon: kind is weapon, armor, shield, helmet, cloak or icon (a copy: yours to keep)."""
    cv = _icon(kind, name, tint, color)
    return cv.copy() if cv is not None else None


@lru_cache(maxsize=512)
def _icon(kind: str, name: str, tint: str = "", color: str = "") -> Canvas | None:
    if kind == "weapon" and name in G.WEAPONS:
        return _done(_weapon(name, tint))
    if kind == "armor" and name in G.ARMOR_STYLES:
        return _done(_armor(name, tint))
    if kind == "shield" and name in G.SHIELDS:
        return _done(_shield(name, tint, color))
    if kind == "helmet" and name in G.HELMETS:
        return _done(_helmet(name, tint))
    if kind == "cloak" and name in G.CLOAKS:
        return _done(_cloak(name, tint, color))
    if kind == "icon" and name in ICONS:
        cv = _done(ICONS[name]())
        return cv.tinted(tint) if tint else cv
    return None


__all__ = ["icon", "ICONS"]
