"""People on the map, in the house style (game/art/pixart.py): little standing figures seen from the front and a
little above, the cosy-farm way, made medieval. Party members, townsfolk and crowds are drawn by this; beasts
and enemies keep their own art for now.

    art = sprite(Look(base="dwarf", hair_color="#c04a1a"), Gear(armor="chain_mail", weapon="warhammer"))

A sprite is a Canvas of the figure facing you (south), 24 x 32 art pixels doubled to 48 x 64, standing with its
feet on the bottom of its square and rising above it. It carries its other facings in `art.views` (1 west,
2 north, 3 east: the quarter turns the maps use) and two walking frames for each in `art.steps`.
"""
from __future__ import annotations

import zlib
from dataclasses import dataclass
from functools import lru_cache

from game.art import gear as G
from game.art.canvas import Canvas
from game.art.doll import Gear
from game.art.humanoid import BODY_BASES, Look
from game.art.pixart import Px, alpha, c, shade

W, H = 24, 32            # art pixels
CX = 12
FOOT = 29                # the bottom row of the boots


@dataclass(frozen=True)
class Body:
    hw: int              # head width
    hh: int              # head height
    tw: int              # torso width
    th: int              # torso height
    lh: int              # leg height


BODIES = {
    "average": Body(10, 10, 10, 8, 7),
    "lean": Body(10, 10, 9, 8, 8),
    "small": Body(10, 9, 8, 6, 4),
    "stout": Body(10, 10, 12, 7, 4),
    "broad": Body(10, 10, 12, 8, 7),
    "giant": Body(10, 10, 12, 8, 7),
    "gaunt": Body(10, 10, 8, 8, 8),
    "hulking": Body(11, 10, 13, 8, 6),
}

BOOT = c("#4a2e1e")
BELT = c("#5a3a22")
BUCKLE = c("#e0b84a")
METAL = c("#a7b1ba")
GOLD = c("#e0b84a")
BONE = c("#e8e2cc")


def _eye_colour(look: Look):
    e = c(look.eyes or "#1e1a20")
    if sum(e[:3]) > 330:                         # pale eyes stay pale (lamp eyes, ghosts' glow)
        return e
    return shade(e, -0.35)


# ======================================================================
# One figure, one facing
# ======================================================================
class _Fig:
    """Works out where everything goes for one look, build and facing."""

    def __init__(self, look: Look, gear: Gear, view: str, step: int) -> None:
        self.look = look
        self.gear = gear
        self.view = view                        # "front", "back" or "side" (facing west)
        self.step = step                        # 0 standing, 1 or 2 mid-stride
        self.base = BODY_BASES.get(look.base, BODY_BASES["human"])
        self.feats = set(self.base.features)
        self.undead = self.base.undead
        self.b = BODIES.get(self.base.build, BODIES["average"])
        b = self.b
        self.skin = c(look.skin)
        self.hair = c(look.hair_color or "#4a3426")
        self.clothes = c(look.clothes or "#5b6b4e")
        style = G.ARMOR_STYLES.get(gear.armor) if gear.armor else None
        self.style = style
        self.robe = bool(style and style.pattern == "robe")
        self.legless = self.undead == "ghost"
        self.ly0 = FOOT - b.lh + 1
        self.ty0 = self.ly0 - b.th
        self.hy1 = self.ty0
        self.hy0 = self.hy1 - b.hh + 1
        tw = b.tw if view != "side" else max(6, b.tw - 3)
        self.tx0 = CX - tw // 2
        self.tx1 = self.tx0 + tw - 1
        hw = b.hw if view != "side" else b.hw - 1
        self.hx0 = CX - hw // 2
        self.hx1 = self.hx0 + hw - 1
        self.helmet = gear.helmet or (style.helmet if style and style.helmet else "")
        self.s = Px(W, H)

    # ---- colours
    def armor_cols(self):
        st = self.style
        if st is None or st.pattern == "cloth":
            base = c(self.gear.armor_tint) if (st and self.gear.armor_tint) else (
                c(st.base) if st and not self.look.clothes else self.clothes)
            return base, shade(base, -0.08), "cloth"
        base = c(self.gear.armor_tint) if self.gear.armor_tint else c(st.base)
        sleeves = shade(base, -0.1) if self.gear.armor_tint else c(st.sleeves)
        return base, sleeves, st.pattern

    def trousers(self):
        if self.undead == "skeleton":
            return BONE
        return shade(self.clothes, -0.4) if self.style is None else c("#5a4632")


def _draw(look: Look, gear: Gear, view: str, step: int) -> Px:
    f = _Fig(look, gear, view, step)
    s = f.s
    s.shadow(CX, FOOT + 1, 6 if f.b.tw < 12 else 7, 1.6, 75)
    back = view == "back"
    if view == "front":
        _cloak(f, "behind")
        _tail(f)
        _hair_back(f)
        _legs(f)
        _torso(f)
        _arms(f)
        _weapon(f, "front")
        _hands(f)
        _head(f)
        _face(f)
        _beard(f)
        _hair_front(f)
        _helmet(f)
        _horns(f)
        _shield(f, "front")
    elif back:
        _shield(f, "back")
        _legs(f)
        _torso(f)
        _arms(f)
        _tail(f)
        _cloak(f, "over")
        _weapon(f, "back")
        _hands(f)
        _head(f)
        _hair_front(f)
        _helmet(f)
        _horns(f)
    else:
        _weapon(f, "side_far")
        _tail(f)
        _cloak(f, "behind")
        _hair_back(f)
        _legs(f)
        _torso(f)
        _head(f)
        _face(f)
        _beard(f)
        _hair_front(f)
        _helmet(f)
        _horns(f)
        _arms(f)
        _hands(f)
        _shield(f, "side")
    s.outline(0.55)
    if f.undead == "ghost":
        s.map(lambda q: alpha(q, min(q[3], 185)) if q[3] == 255 else q)
    return s


# ======================================================================
# Parts
# ======================================================================
def _legs(f: _Fig) -> None:
    s, b = f.s, f.b
    if f.legless:                                # a ghost trails off into a wisp
        col = shade(f.skin, -0.05)
        for i, y in enumerate(range(f.ly0, FOOT)):
            half = max(0, (f.tx1 - f.tx0) // 2 - i)
            s.rect(CX - half - 1, y, CX + half, y, alpha(col, 200 - i * 22))
        return
    if f.robe:                                   # a robe falls to the boots
        base, sleeves, _ = f.armor_cols()
        for y in range(f.ly0, FOOT):
            spread = (y - f.ly0) // 3
            s.rect(f.tx0 - spread, y, f.tx1 + spread, y, base)
            s.p(f.tx1 + spread, y, shade(base, -0.2))
        s.rect(f.tx0 - 2, FOOT - 1, f.tx1 + 2, FOOT - 1, shade(base, -0.25))
        trim = c(f.style.trim) if f.style.trim else shade(base, 0.25)
        s.vline(CX - 1 if f.view != "side" else f.tx0 + 1, f.ly0, FOOT - 2, trim)
        for x in (CX - 3, CX + 2):
            if f.view != "back":
                s.p(x, FOOT, BOOT)
        return
    tr = f.trousers()
    bare = "bare_feet" in f.feats or f.undead == "skeleton" or "scales" in f.feats
    boot = f.skin if bare else BOOT
    lw = max(3, (f.tx1 - f.tx0 - 1) // 2)
    if f.view == "side":
        # one leg forward, one back, when walking
        fwd = {0: 0, 1: -1, 2: 1}[f.step]
        legs = [(CX - 2 + fwd, shade(tr, -0.15)), (CX - 1 - fwd, tr)]
        for x0, col in legs:
            s.rect(x0, f.ly0, x0 + 2, FOOT - 2, col)
            s.rect(x0 - 1, FOOT - 1, x0 + 2, FOOT, boot)
            s.p(x0 - 1, FOOT - 1, shade(boot, 0.2))
        return
    lift = {0: (0, 0), 1: (1, 0), 2: (0, 1)}[f.step]
    for i, (x0, x1) in enumerate(((f.tx0 + 1, f.tx0 + lw), (f.tx1 - lw, f.tx1 - 1))):
        up = lift[i]
        bottom = FOOT - up
        s.rect(x0, f.ly0, x1, bottom - 2, tr)
        s.vline(x1, f.ly0, bottom - 2, shade(tr, -0.15))
        s.rect(x0, bottom - 1, x1, bottom, boot)
        s.hline(x0, x1 - 1, bottom - 1, shade(boot, 0.18))
        if f.undead == "skeleton":
            for yy in range(f.ly0, bottom + 1):
                for xx in range(x0, x1 + 1):
                    s.clear(xx, yy)
            s.vline((x0 + x1) // 2, f.ly0, bottom, BONE)
            s.hline(x0, x1, bottom, BONE)


def _torso(f: _Fig) -> None:
    s, b = f.s, f.b
    x0, x1, y0, y1 = f.tx0, f.tx1, f.ty0, f.ly0 - 1
    if f.undead == "skeleton" and f.style is None:
        s.vline(CX - (0 if f.view != "side" else 1), y0, y1, BONE)
        for y in range(y0 + 1, y1, 2):
            s.hline(x0 + 1, x1 - 1, y, BONE)
        s.hline(x0, x1, y1, shade(BONE, -0.15))
        return
    base, sleeves, pat = f.armor_cols()
    st = f.style
    for y in range(y0, y1 + 1):
        inset = 1 if y == y0 else 0
        s.rect(x0 + inset, y, x1 - inset, y, base)
    s.vline(x1, y0 + 1, y1, shade(base, -0.18))   # its shaded side
    s.vline(x0, y0 + 1, y1, shade(base, 0.12))    # its lit side
    lit, dk = shade(base, 0.22), shade(base, -0.22)
    if pat == "quilted":
        for y in range(y0 + 2, y1, 2):
            s.hline(x0 + 1, x1 - 1, y, dk)
    elif pat in ("leather", "studded"):
        s.vline(CX if f.view != "side" else x0 + 2, y0 + 1, y1, dk)
        if pat == "studded":
            for y in range(y0 + 2, y1, 2):
                for x in range(x0 + 1 + (y % 2), x1, 2):
                    s.p(x, y, c("#d8c8a0"))
    elif pat == "hide":
        trim = c(st.trim) if st and st.trim else shade(base, 0.3)
        s.hline(x0, x1, y0, trim)
        for x in range(x0, x1 + 1, 2):
            s.p(x, y0 + 1, trim)
        for y in range(y0 + 2, y1):
            s.p(x0 + 1 + (y * 3) % max(1, x1 - x0 - 1), y, dk)
    elif pat in ("chain", "rings"):
        for y in range(y0 + 1, y1 + 1):
            for x in range(x0 + 1, x1):
                if (x + y) % 2 == 0:
                    s.p(x, y, dk if pat == "chain" else shade(base, 0.15))
    elif pat == "scale":
        for y in range(y0 + 1, y1 + 1, 2):
            for x in range(x0 + (y // 2) % 2, x1 + 1, 2):
                s.p(x, y, lit)
                s.p(x, y + 1, dk)
    elif pat == "plate":
        s.vline(x0 + 2, y0 + 1, y1 - 1, lit)
        s.p(x0 + 3, y0 + 2, shade(base, 0.4))
        s.hline(x0 + 1, x1 - 1, y0 + (y1 - y0) // 2 + 1, dk)
        s.vline(x1 - 1, y0 + 1, y1, dk)
    elif pat == "splint":
        for x in range(x0 + 1, x1, 2):
            s.vline(x, y0 + 2, y1, dk)
    elif pat == "robe":
        trim = c(st.trim) if st.trim else lit
        if f.view != "back":
            s.vline(CX - 1 if f.view == "front" else x0 + 1, y0 + 1, y1, trim)
            s.hline(CX - 2, CX + 1, y0, trim) if f.view == "front" else None
        s.hline(x0, x1, y1 - 1, shade(base, -0.12))   # a cord at the waist
    elif pat == "noble":
        trim = c(st.trim) if st and st.trim else GOLD
        if f.view == "front":
            s.vline(CX - 1, y0, y1, trim)
            for y in range(y0 + 2, y1, 2):
                s.p(CX, y, trim)
        s.hline(x0, x1, y0, trim)
    # a belt over the tunic and leathers
    if pat in ("cloth", "leather", "studded", "hide", "quilted", "noble", "chain", "rings", "scale"):
        s.hline(x0, x1, y1 - 1, BELT)
        if f.view == "front":
            s.p(CX - 1, y1 - 1, BUCKLE)
    if pat == "cloth" and f.view == "front":         # a neckline
        s.p(CX - 1, y0, shade(f.skin, -0.1))
        s.p(CX, y0, shade(f.skin, -0.1))
    if st and st.trim and pat in ("plate", "breastplate", "splint"):
        s.hline(x0 + 1, x1 - 1, y0, c(st.trim))
    if f.undead == "zombie":                           # torn
        for x in (x0 + 1, x1 - 2):
            s.clear(x, y1)
            s.p(x + 1, y1 - 2, shade(base, -0.3))


def _arms(f: _Fig) -> None:
    s, b = f.s, f.b
    base, sleeves, pat = f.armor_cols()
    st = f.style
    if f.undead == "skeleton" and st is None:
        sleeves = BONE
    y0, y1 = f.ty0 + 1, f.ly0 - 2
    if f.view == "side":
        swing = {0: 0, 1: -1, 2: 1}[f.step]
        x = CX - 1 + swing
        s.rect(x, y0, x + 1, y1, sleeves)
        s.vline(x + 1, y0, y1, shade(sleeves, -0.18))
        s.vline(x - 1, y0 + 1, y1, shade(sleeves, -0.35))    # where the arm meets the body
        if st and st.pauldrons:
            s.rect(x - 1, y0 - 1, x + 2, y0 + 1, shade(sleeves, 0.1))
            s.hline(x - 1, x + 2, y0 - 1, shade(sleeves, 0.35))
        f.hand_side = (x, y1 + 1)
        return
    sw = {0: (0, 0), 1: (1, -1), 2: (-1, 1)}[f.step]
    for i, (ax0, ax1) in enumerate(((f.tx0 - 2, f.tx0 - 1), (f.tx1 + 1, f.tx1 + 2))):
        drop = max(0, sw[i])
        s.rect(ax0, y0, ax1, y1 + drop, sleeves)
        s.vline(ax1 if i == 1 else ax0, y0 + 1, y1 + drop, shade(sleeves, -0.15 if i == 1 else -0.05))
        s.p(ax0 if i == 0 else ax1, y0, shade(sleeves, 0.18))
        if st and st.pauldrons:
            s.rect(ax0 - 1, y0 - 1, ax1 + (1 if i == 1 else 0), y0 + 1, shade(sleeves, 0.08))
            s.hline(ax0 - 1, ax1 + (1 if i == 1 else 0), y0 - 1, shade(sleeves, 0.35))
        if st and st.sleeve_pattern == "chain":
            for y in range(y0 + 1, y1 + drop, 2):
                s.p(ax0 + (y % 2), y, shade(sleeves, -0.2))
        elif st and st.sleeve_pattern in ("plate", "scale"):
            s.p(ax0, y0 + 3, shade(sleeves, -0.25))
            s.p(ax1, y0 + 3, shade(sleeves, -0.25))
    f.hands = [((f.tx0 - 2), y1 + 1 + max(0, sw[0])), ((f.tx1 + 1), y1 + 1 + max(0, sw[1]))]
    g = f.gear
    if f.view == "front" and g.weapon:                       # the weapon hand held out a little from the body
        x, y = f.hands[0]
        f.hands[0] = (x - 1, y)
    if f.view == "front" and g.off_weapon and not g.two_handed() and not g.shield:
        x, y = f.hands[1]
        f.hands[1] = (x + 1, y)
    if f.view == "back" and g.weapon:
        x, y = f.hands[1]
        f.hands[1] = (x + 1, y)


def _hands(f: _Fig) -> None:
    s = f.s
    col = METAL if (f.style and f.style.gauntlets) else (BONE if f.undead == "skeleton" else f.skin)
    if f.view == "side":
        x, y = f.hand_side
        s.rect(x, y, x + 1, y + 1, col)
        s.p(x + 1, y + 1, shade(col, -0.2))
        return
    for (x, y) in f.hands:
        s.rect(x, y, x + 1, y + 1, col)
        s.p(x + 1, y + 1, shade(col, -0.18))


def _head(f: _Fig) -> None:
    s, b = f.s, f.b
    x0, x1, y0, y1 = f.hx0, f.hx1, f.hy0, f.hy1
    skin = f.skin
    if f.undead == "skeleton":
        skin = BONE
    snout = "snout" in f.feats
    rows = y1 - y0 + 1
    for r in range(rows):
        y = y0 + r
        inset = 2 if r == 0 else 1 if r == 1 else 0
        if r == rows - 1:
            inset = 2
        elif r == rows - 2:
            inset = 1
        if snout and f.view == "front" and r >= rows - 3:
            inset = max(0, inset - 1) + 1
        s.rect(x0 + inset, y, x1 - inset, y, skin)
    if f.view != "back":
        s.vline(x1, y0 + 2, y1 - 2, shade(skin, -0.16))
        s.hline(x0 + 2, x1 - 2, y1, shade(skin, -0.14))
        s.p(x0 + 2, y0 + 1, shade(skin, 0.18))
    if snout and f.view == "side":                # a muzzle pushed forward
        s.rect(x0 - 3, y0 + rows // 2, x0, y1 - 1, skin)
        s.hline(x0 - 3, x0, y1 - 1, shade(skin, -0.18))
        s.p(x0 - 3, y0 + rows // 2, shade(skin, -0.3))   # the nostril
    if "metal" in f.feats:                        # an automaton's seam and rivets
        s.vline(CX - 1 if f.view != "side" else x0 + 3, y0 + 1, y0 + 3, shade(skin, -0.25))
        if "rivets" in f.feats and f.view != "side":
            s.p(x0 + 1, y0 + 3, shade(skin, 0.35))
            s.p(x1 - 1, y0 + 3, shade(skin, 0.35))
    if "scales" in f.feats or "spots" in f.feats:
        for (dx, dy) in ((2, 2), (6, 3), (4, 1), (7, 6)):
            if x0 + dx <= x1:
                s.p(x0 + dx, y0 + dy, shade(skin, -0.12))
    _ears(f)


def _ears(f: _Fig) -> None:
    s = f.s
    x0, x1, y0 = f.hx0, f.hx1, f.hy0
    ey = y0 + (f.hy1 - y0) // 2
    skin = BONE if f.undead == "skeleton" else f.skin
    if f.helmet in ("great_helm", "coif", "hood", "horned_helm"):
        return
    sides = [(-1, x0), (1, x1)] if f.view != "side" else [(1, x1 - 2)]
    for d, x in sides:
        if "ears" in f.feats or "big_ears" in f.feats:
            n = 4 if "big_ears" in f.feats else 3
            for i in range(n):
                s.p(x + d * (i + 1), ey - i // 2, skin if i < n - 1 else shade(skin, -0.1))
            s.p(x + d, ey + 1, shade(skin, -0.12))
        elif "round_ears" in f.feats:
            s.rect(min(x, x + d), y0 - 1, max(x, x + d), y0, shade(skin, -0.05))
        elif "small_ears" in f.feats:
            s.p(x + d, ey, skin)
            s.p(x + d * 2, ey - 1, skin)
        elif "snout" not in f.feats and "metal" not in f.feats and f.undead != "skeleton":
            s.p(x + d, ey, skin)
            s.p(x + d, ey + 1, shade(skin, -0.15))


def _face(f: _Fig) -> None:
    s, look = f.s, f.look
    x0, x1, y0, y1 = f.hx0, f.hx1, f.hy0, f.hy1
    skin = f.skin
    eye = _eye_colour(look)
    snout = "snout" in f.feats
    er = y0 + (y1 - y0) // 2 + (0 if not snout else -1)
    if f.helmet == "great_helm":
        return
    if f.view == "side":
        ex = x0 + 1 if not snout else x0 + 1
        if f.undead == "skeleton":
            s.rect(ex, er, ex + 1, er + 1, c("#2a2026"))
            s.p(ex, er, c(look.eyes))
            return
        s.vline(ex, er, er + 1, eye)
        if "lamp_eyes" in f.feats:
            s.put(ex - 1, er, alpha(eye, 120))
        if not snout:
            s.p(x0 - 1, er + 2, skin)                 # the nose in profile
            s.p(x0, er + 4, shade(skin, -0.28))       # the mouth
            if "big_nose" in f.feats:
                s.rect(x0 - 2, er + 1, x0 - 1, er + 2, skin)
            s.p(x0 + 1, er + 3, _blush(skin))
        if "tusks" in f.feats or "tusks_small" in f.feats:
            s.p(x0, er + 3, c("#eee8d2"))
        return
    lx, rx = x0 + 2, x1 - 2
    if snout:
        lx, rx = x0 + 1, x1 - 1
    if f.undead == "skeleton":
        for x in (lx, rx - 1):
            s.rect(x, er, x + 1, er + 1, c("#2a2026"))
            s.p(x + (1 if x == lx else 0), er + 1, c(look.eyes))
        s.p(CX - 1, er + 2, c("#3a3036"))
        for x in range(CX - 2, CX + 2):
            s.p(x, er + 4, shade(BONE, -0.2) if x % 2 else BONE)
        return
    for x in (lx, rx):
        s.vline(x, er, er + 1, eye)
        if "lamp_eyes" in f.feats:
            s.put(x - 1, er, alpha(eye, 130))
            s.put(x + 1, er, alpha(eye, 130))
    if "metal" in f.feats:
        s.hline(CX - 2, CX + 1, er + 3, shade(skin, -0.3))      # a grille for a mouth
        return
    if snout:
        mz = shade(c(look.accent), 0.05) if look.accent and look.base != "gnoll" else shade(skin, 0.14)
        for y in range(f.hy1 - 3, f.hy1 + 1):                    # the muzzle, lighter, pushed toward you
            inset = 1 if y == f.hy1 else 0
            s.rect(CX - 3 + inset, y, CX + 2 - inset, y, mz)
        s.hline(CX - 2, CX + 1, f.hy1 + 1, shade(skin, -0.2))
        s.p(CX - 2, f.hy1 - 1, shade(skin, -0.35))               # nostrils at the end of the muzzle
        s.p(CX + 1, f.hy1 - 1, shade(skin, -0.35))
        if "hyena" in f.feats:
            s.rect(CX - 1, f.hy1 - 2, CX, f.hy1 - 1, c("#2a2224"))
    else:
        s.p(lx - 1, er + 2, _blush(skin))
        s.p(rx + 1, er + 2, _blush(skin))
        if "big_nose" in f.feats:
            s.rect(CX - 1, er + 1, CX, er + 2, shade(skin, -0.08))
            s.p(CX, er + 2, shade(skin, -0.25))
        s.hline(CX - 1, CX, er + 3, shade(skin, -0.3))           # the mouth
    if "tusks" in f.feats or "tusks_small" in f.feats:
        s.p(CX - 2, er + 3, c("#eee8d2"))
        s.p(CX + 1, er + 3, c("#eee8d2"))
        if "tusks" in f.feats:
            s.p(CX - 2, er + 2, c("#eee8d2"))
            s.p(CX + 1, er + 2, c("#eee8d2"))
    if f.undead == "zombie":
        s.p(CX, er + 3, c("#6a3030"))


def _blush(skin):
    r, g, b, a = skin
    return (min(255, r + 18), max(0, g - 20), max(0, b - 16), 255)


# ---- hair
def _hair_back(f: _Fig) -> None:
    style = f.look.hair or "none"
    if f.helmet in ("great_helm", "coif", "hood") or style not in ("long", "ragged", "braids", "mane", "wild"):
        return
    s, hair = f.s, f.hair
    x0, x1, y0, y1 = f.hx0, f.hx1, f.hy0, f.hy1
    if style == "mane":
        for y in range(y0 - 1, y1 + 2):
            s.rect(x0 - 2, y, x1 + 2, y, shade(hair, -0.1 if y % 2 else 0))
        return
    if style in ("long", "ragged"):
        bottom = f.ty0 + 4
        s.rect(x0 - 1, y0 + 2, x1 + 1, bottom, shade(hair, -0.12))
        if style == "ragged":
            for x in range(x0 - 1, x1 + 2, 2):
                s.clear(x, bottom)
    if style == "wild":
        s.rect(x0 - 2, y0, x1 + 2, y1 - 2, shade(hair, -0.1))


def _hair_front(f: _Fig) -> None:
    look, s, hair = f.look, f.s, f.hair
    style = look.hair or "none"
    if f.helmet in ("great_helm", "coif", "hood", "kettle", "horned_helm", "cap", "wizard_hat"):
        style = {"long": "long_under", "braids": "braids_under", "ragged": "long_under"}.get(style, "none")
    x0, x1, y0, y1 = f.hx0, f.hx1, f.hy0, f.hy1
    lit, dk = shade(hair, 0.22), shade(hair, -0.2)
    back = f.view == "back"
    side = f.view == "side"

    def cap(depth: int, fringe: bool = True, over: int = 0) -> None:
        for r in range(depth):
            y = y0 - over + r
            inset = 2 if r == 0 else 1 if r == 1 else 0
            s.rect(x0 + inset - (1 if r > 1 else 0), y, x1 - inset + (1 if r > 1 else 0), y, hair)
        s.hline(x0 + 3, x0 + 5, y0 - over + 1, lit)                # the shine on top
        if back:
            for y in range(y0 - over + depth, y1 - 1):
                s.rect(x0, y, x1, y, hair if y < y1 - 2 else dk)
            return
        if side:
            s.rect(x0 + 3, y0, x1 + 1, y1 - 3, hair)                # the back of the head
            s.vline(x1 + 1, y0 + 2, y1 - 3, dk)
            s.p(x0 + 2, y0 + depth, hair)
            return
        if fringe:
            y = y0 - over + depth
            for x in range(x0, x1 + 1):
                if (x - x0) % 3 != 1:
                    s.p(x, y, dk if x in (x0, x1) else hair)
            s.vline(x0 - 1, y0 + 2, y0 + depth + 1, hair)            # the sides over the ears
            s.vline(x1 + 1, y0 + 2, y0 + depth + 1, dk)

    if style == "none":
        if f.view != "side":
            s.p(x0 + 3, y0 + 1, shade(f.skin, 0.25))
        return
    if style == "short":
        cap(3)
    elif style in ("long", "long_under", "ragged"):
        if style != "long_under":
            cap(3)
        if not back:
            sx = [x0 - 1, x1 + 1] if not side else [x1 + 1]
            for x in sx:
                s.vline(x, y0 + 3, f.ty0 + 3, hair if x == x0 - 1 else dk)
                s.vline(x + (1 if x == x0 - 1 else -1) * 0, f.ty0 + 3, f.ty0 + 3, dk)
        else:
            s.rect(x0, y1 - 1, x1, f.ty0 + 4, hair)
            s.hline(x0, x1, f.ty0 + 4, dk)
    elif style == "ponytail":
        cap(3)
        if back or side:
            tx = CX if back else x1 + 1
            s.vline(tx, y1 - 1, f.ty0 + 4, hair)
            s.vline(tx - 1 if back else tx + 1, y1, f.ty0 + 3, dk)
            s.p(tx, y1 - 2, c("#a83a3a"))                            # a ribbon
    elif style == "curly":
        cap(4, fringe=False, over=1)
        if not back and not side:
            for x in range(x0 - 1, x1 + 2, 2):
                s.p(x, y0 + 3, hair)
                s.p(x + 1, y0 + 2, lit)
        for x in range(x0, x1 + 1, 3):
            s.p(x, y0 - 1, lit)
    elif style == "wild":
        cap(4, fringe=True, over=1)
        for (x, y) in ((x0 - 2, y0), (x1 + 2, y0 + 1), (x0 + 2, y0 - 2), (x1 - 2, y0 - 2), (CX, y0 - 2)):
            s.p(x, y, hair)
    elif style == "mohawk":
        top = y0 - 2
        mx = CX - 1 if not side else x0 + 4
        s.rect(mx, top, mx + 1, y0 + 3 if not back else y1 - 2, hair)
        s.vline(mx, top, top + 2, lit)
        if f.view != "side":
            s.p(x0 + 3, y0 + 1, shade(f.skin, 0.25))
    elif style == "topknot":
        cap(2, fringe=False)
        kx = CX - 1 if not side else x0 + 5
        s.rect(kx, y0 - 3, kx + 1, y0, hair)
        s.p(kx, y0 - 3, lit)
    elif style in ("braids", "braids_under"):
        if style == "braids":
            cap(3)
        if not back:
            for x in ([x0 - 1, x1 + 1] if not side else [x1 + 1]):
                for y in range(y0 + 4, f.ty0 + 5):
                    s.p(x, y, hair if y % 2 else dk)
    elif style == "bun":
        cap(3)
        bx = CX - 1 if not side else x0 + 6
        s.rect(bx - 1, y0 - 2, bx + 2, y0, hair)
        s.hline(bx, bx + 1, y0 - 2, lit)
    elif style == "mane":
        s.rect(x0, y0 - 1, x1, y0 + 1, hair)
        s.hline(x0 + 2, x1 - 2, y0 - 2, hair)
        if back:
            s.rect(x0 - 1, y0, x1 + 1, f.ty0 + 3, hair)


def _beard(f: _Fig) -> None:
    beard = f.look.beard or "none"
    if beard == "none" or f.helmet == "great_helm" or f.undead == "skeleton":
        return
    s, hair = f.s, f.hair
    x0, x1, y0, y1 = f.hx0, f.hx1, f.hy0, f.hy1
    er = y0 + (y1 - y0) // 2
    if f.view == "side":
        if beard == "stubble":
            s.p(x0, er + 3, shade(f.skin, -0.12))
            return
        n = {"short": 1, "full": 3, "braided": 4}[beard]
        s.rect(x0, er + 2, x0 + 3, y1 + n - 1, hair)
        s.p(x0, y1 + n - 1, shade(hair, -0.2))
        return
    if beard == "stubble":
        for x in range(x0 + 1, x1, 2):
            s.p(x, y1 - 1, shade(f.skin, -0.14))
        return
    n = {"short": 1, "full": 3, "braided": 4}[beard]
    for y in range(er + 2, y1 + n):
        inset = max(0, y - y1) + (1 if y >= y1 else 0)
        s.rect(x0 + inset, y, x1 - inset, y, hair)
    s.vline(x1, er + 2, y1, shade(hair, -0.2))
    s.hline(CX - 1, CX, er + 3, shade(f.skin, -0.3))              # the mouth shows through
    s.p(x0 + 2, er + 2, shade(hair, 0.18))
    if beard == "braided":
        for y in range(y1, y1 + n + 1):
            s.p(CX - 1, y, shade(hair, -0.15) if y % 2 else hair)
        s.p(CX - 1, y1 + n + 1, c("#c8a050"))                      # a bead


def _helmet(f: _Fig) -> None:
    h = f.helmet
    if not h:
        return
    s = f.s
    x0, x1, y0, y1 = f.hx0, f.hx1, f.hy0, f.hy1
    tint = c(f.gear.helmet_tint) if f.gear.helmet_tint else None
    steel = tint or METAL
    lit, dk = shade(steel, 0.3), shade(steel, -0.25)
    back = f.view == "back"
    side = f.view == "side"
    if h in ("kettle", "cap", "horned_helm"):
        col = tint or (c("#7a5232") if h == "cap" else METAL)
        depth = 4
        for r in range(depth):
            inset = 2 if r == 0 else 1 if r == 1 else 0
            s.rect(x0 + inset, y0 - 1 + r, x1 - inset, y0 - 1 + r, col)
        s.hline(x0 + 2, x0 + 4, y0, shade(col, 0.3))
        if h == "kettle":                                          # its broad brim
            s.hline(x0 - 2, x1 + 2, y0 + 3, shade(col, -0.1))
            s.hline(x0 - 1, x1 + 1, y0 + 3, shade(col, 0.1))
        else:
            s.hline(x0 - 1, x1 + 1, y0 + 3, shade(col, -0.2))
        if h == "horned_helm":
            for d, x in ((-1, x0 - 1), (1, x1 + 1)):
                if side and d < 0:
                    continue
                s.p(x, y0 + 1, BONE)
                s.p(x + d, y0, BONE)
                s.p(x + d, y0 - 1, BONE)
                s.p(x + d * 2, y0 - 2, shade(BONE, -0.15))
        if back:
            s.rect(x0, y0 + 3, x1, y0 + 4, shade(col, -0.15))
    elif h == "coif":
        col = steel
        s.rect(x0 - 1, y0 - 1, x1 + 1, y1 + 1, col)
        for y in range(y0 - 1, y1 + 2):
            for x in range(x0 - 1, x1 + 2):
                if (x + y) % 2 == 0:
                    s.p(x, y, dk)
        if not back:
            fx0, fx1 = (x0 + 1, x1 - 1) if not side else (x0, x0 + 4)
            for y in range(y0 + 3, y1):
                for x in range(fx0, fx1 + 1):
                    s.p(x, y, f.skin)
            _face(f)
    elif h == "great_helm":
        s.rect(x0 - 1, y0 - 1, x1 + 1, y1, steel)
        s.vline(x0, y0, y1 - 1, lit)
        s.vline(x1 + 1, y0, y1, dk)
        if not back:
            ey = y0 + (y1 - y0) // 2 - 1
            if side:
                s.hline(x0 - 1, x0 + 2, ey, c("#1a1418"))
            else:
                s.hline(x0 + 1, x1 - 1, ey, c("#1a1418"))
                s.vline(CX - 1, ey + 1, y1 - 2, dk)
                for x in (CX - 3, CX + 2):
                    s.p(x, ey + 3, c("#1a1418"))
        s.hline(x0 - 1, x1 + 1, y1, dk)
    elif h == "hood":
        col = c(f.gear.cloak_color) if f.gear.cloak else (tint or shade(f.clothes, -0.1))
        s.rect(x0 - 1, y0 - 1, x1 + 1, y1 + 1, col)
        s.clear(x0 - 1, y0 - 1)
        s.clear(x1 + 1, y0 - 1)
        s.hline(x0 + 1, x0 + 4, y0, shade(col, 0.2))
        if not back:
            fx0, fx1 = (x0 + 1, x1 - 1) if not side else (x0 - 1, x0 + 3)
            for y in range(y0 + 3, y1 + 1):
                for x in range(fx0, fx1 + 1):
                    s.p(x, y, f.skin)
            s.hline(fx0, fx1, y0 + 3, shade(f.skin, -0.3))     # the shadow under the hood
            _face(f)
            _beard(f)
    elif h == "wizard_hat":
        col = tint or (c(f.gear.armor_tint) if f.gear.armor_tint else c("#3b2f6a"))
        s.hline(x0 - 2, x1 + 2, y0 + 1, shade(col, -0.15))    # brim
        s.hline(x0 - 1, x1 + 1, y0 + 1, col)
        for i in range(8):                                    # the cone, its tip bent back
            half = max(0, 4 - i // 2)
            yy = y0 - i
            lean = i // 4
            s.rect(CX - half - 1 + lean, yy, CX + half - 1 + lean, yy, col)
            s.p(CX - half - 1 + lean, yy, shade(col, 0.2))
        s.hline(CX - 4, CX + 2, y0, GOLD)                     # a band
        s.p(CX + 2, y0 - 8, GOLD)
    elif h in ("crown", "circlet"):
        y = y0 + 1
        s.hline(x0, x1, y, GOLD)
        if h == "crown":
            for x in range(x0, x1 + 1, 3):
                s.p(x, y - 1, GOLD)
                s.p(x, y - 2, shade(GOLD, 0.3))
            if not back and not side:
                s.p(CX - 1, y, c("#d03a4a"))
        elif not back:
            s.p(CX - 1 if not side else x0 + 1, y, c("#4ab0e0"))


def _horns(f: _Fig) -> None:
    if f.helmet in ("great_helm", "coif", "hood", "kettle", "horned_helm"):
        return
    s = f.s
    x0, x1, y0 = f.hx0, f.hx1, f.hy0
    col = shade(c(f.look.accent or f.base.accent or "#3a2a2e"), 0.1)
    sides = [(-1, x0 + 1), (1, x1 - 1)] if f.view != "side" else [(1, x0 + 5)]
    if "horns" in f.feats:
        for d, x in sides:
            s.p(x, y0, col)
            s.p(x + d, y0 - 1, col)
            s.p(x + d * 2, y0 - 1, col)
            s.p(x + d * 2, y0 - 2, shade(col, 0.3))
            s.p(x + d * 3, y0 - 3, shade(col, 0.2))
    if "small_horns" in f.feats:
        for d, x in sides:
            s.p(x + d, y0, col)
            s.p(x + d, y0 - 1, shade(col, 0.25))
    if "frills" in f.feats or "crest" in f.feats:
        if f.view == "side":
            for i in range(3):
                s.p(x0 + 5 + i, y0 - 1 + i, col)
        else:
            for x in range(CX - 2, CX + 2, 2):
                s.p(x, y0 - 1, col)
                s.p(x, y0 - 2, shade(col, 0.25))


def _tail(f: _Fig) -> None:
    if not ("tail" in f.feats or "tail_short" in f.feats):
        return
    s = f.s
    col = shade(f.skin, -0.08)
    long = "tail" in f.feats
    y = f.ly0 - 1
    if f.view == "front":
        x = f.tx1 + 3
        for i in range(3 if long else 1):
            s.p(x + i // 2, y + i, col)
        if "spade" in f.feats:
            s.p(x + 1, y + 3, col)
            s.p(x + 2, y + 3, col)
        return
    if f.view == "back":
        for i in range(6 if long else 2):
            s.p(CX + i // 2, y + i, col)
            s.p(CX + i // 2 + 1, y + i, shade(col, -0.15))
        if "spade" in f.feats:
            s.rect(CX + 3, y + 6, CX + 4, y + 7, col)
        if "hyena" in f.feats:
            s.p(CX + 1, y + 2, f.hair)
        return
    for i in range(6 if long else 2):                         # trailing behind (to the right, facing west)
        s.p(f.tx1 + 1 + i, y + i // 2, col)
    if "spade" in f.feats:
        s.rect(f.tx1 + 6, y + 2, f.tx1 + 7, y + 3, col)


def _cloak(f: _Fig, where: str) -> None:
    g = f.gear
    if not g.cloak:
        return
    s = f.s
    col = c(g.cloak_color or "#7a2a2a")
    fur = g.cloak == "fur_cloak"
    bottom = (FOOT - 2) if g.cloak != "cape" else f.ly0 + 1
    if where == "over":                                       # seen from behind: it covers the back
        for y in range(f.ty0, bottom + 1):
            spread = (y - f.ty0) // 4
            s.rect(f.tx0 - 2 - spread, y, f.tx1 + 2 + spread, y, col)
        s.vline(f.tx1 + 2 + (bottom - f.ty0) // 4, f.ty0, bottom, shade(col, -0.2))
        for x in range(f.tx0, f.tx1, 3):
            s.vline(x, f.ty0 + 3, bottom - 1, shade(col, -0.12))
        s.hline(f.tx0 - 3, f.tx1 + 3, bottom, shade(col, -0.25))
        if fur:
            s.rect(f.tx0 - 2, f.ty0 - 1, f.tx1 + 2, f.ty0 + 1, c("#e8dcc4"))
        return
    if f.view == "side":
        for y in range(f.ty0, bottom + 1):
            spread = (y - f.ty0) // 3
            s.rect(f.tx1 - 1, y, f.tx1 + 1 + spread, y, col)
        s.hline(f.tx1, f.tx1 + 1 + (bottom - f.ty0) // 3, bottom, shade(col, -0.25))
        return
    for y in range(f.ty0 + 1, bottom + 1):                    # from the front: its edges behind the arms
        spread = (y - f.ty0) // 4
        s.p(f.tx0 - 3 - spread, y, shade(col, -0.1))
        s.p(f.tx1 + 3 + spread, y, shade(col, -0.2))
        s.rect(f.tx0 - 2, y, f.tx1 + 2, y, shade(col, -0.3))
    if fur:
        f.fur = True
    f.clasp = True


def _weapon(f: _Fig, where: str) -> None:
    g = f.gear
    wid = g.weapon
    if not wid and not g.off_weapon:
        return
    s = f.s
    if where == "front":
        hand = f.hands[0]
        _weapon_at(s, wid, g.weapon_tint, hand[0], hand[1], +1)
        if g.off_weapon and not g.two_handed() and not g.shield:
            h2 = f.hands[1]
            _weapon_at(s, g.off_weapon, g.off_weapon_tint, h2[0] + 1, h2[1], -1)
        if getattr(f, "clasp", False):                        # the cloak's clasp and collar
            col = c(g.cloak_color or "#7a2a2a")
            if getattr(f, "fur", False):
                s.rect(f.tx0 - 1, f.ty0, f.tx1 + 1, f.ty0, c("#e8dcc4"))
            else:
                s.p(f.tx0, f.ty0, col)
                s.p(f.tx1, f.ty0, col)
            s.p(CX - 1, f.ty0 + 1, GOLD)
    elif where == "back":
        hx, hy = f.hands[1]
        _weapon_at(s, wid, g.weapon_tint, hx, hy, -1)
    else:                                                     # facing west: carried forward, up
        if wid:
            _weapon_at(s, wid, g.weapon_tint, CX - 3, f.ly0 - 1, +1)


def _weapon_at(s: Px, wid: str, tint: str, hx: int, hy: int, out: int) -> None:
    """A weapon held upright in the hand at (hx, hy): the haft below the hand, the business end above;
    `out` is the side its blades and heads turn to. Drawn on its own and outlined, so it stands out from the
    sleeve behind it."""
    if G.WEAPONS.get(wid) is None:
        return
    layer = Px(W, H)
    _weapon_shape(layer, wid, tint, hx, hy, out)
    layer.outline(0.55)
    s.blit(layer)


def _weapon_shape(s: Px, wid: str, tint: str, hx: int, hy: int, out: int) -> None:
    w = G.WEAPONS[wid]
    head = c(tint) if tint else c(w.head)
    hl, hd = shade(head, 0.3), shade(head, -0.25)
    wood = c(w.handle)
    guard = c(w.guard)
    k = w.kind
    x = hx + (0 if out > 0 else 1)
    L = max(3, min(16, round(w.length * 0.62)))
    if k in ("blade", "rapier", "curved"):
        s.vline(x, hy, hy + 2, wood)                            # the grip below the hand
        s.p(x, hy + 3, guard)
        gw = 1 if k == "rapier" else 1
        s.hline(x - gw, x + gw, hy - 1, guard)                  # the crossguard
        broad = w.width >= 1.3
        for i in range(L):
            y = hy - 2 - i
            dx = (i * i) // 40 * out if k == "curved" else 0
            s.p(x + dx, y, hl)
            if broad:
                s.p(x + dx + out, y, head)
        s.p(x, hy - 2 - L, hl)
    elif k in ("axe", "double_axe", "pick"):
        s.vline(x, hy - L, hy + 2, wood)
        top = hy - L
        sides = (out, -out) if k == "double_axe" else (out,)
        for d in sides:
            if k == "pick":
                s.hline(min(x, x + 3 * d), max(x, x + 3 * d), top + 1, head)
                s.p(x + 3 * d, top + 2, hd)
            else:
                size = 3 if w.width >= 1.3 else 2
                s.rect(min(x + d, x + d * size), top, max(x + d, x + d * size), top + size, head)
                s.vline(x + d * size, top, top + size, hl)
    elif k in ("hammer", "mace", "spiked", "club", "flail"):
        s.vline(x, hy - L + 1, hy + 2, wood)
        top = hy - L
        if k == "hammer":
            wd = 2 if w.width >= 1.5 else 1
            s.rect(x - 1 - wd // 2, top - 1, x + 1 + wd // 2, top + 1, head)
            s.hline(x - 1 - wd // 2, x + 1 + wd // 2, top - 1, hl)
        elif k in ("mace", "spiked"):
            s.rect(x - 1, top - 1, x + 1, top + 1, head)
            s.p(x - 1, top - 1, hl)
            if k == "spiked":
                for (dx, dy) in ((0, -2), (-2, 0), (2, 0)):
                    s.p(x + dx, top + dy, hl)
        elif k == "club":
            s.rect(x, top - 1, x + 1, hy - 2, wood)
            s.vline(x, top - 1, hy - 2, shade(wood, 0.2))
        else:                                                   # flail: a ball on a chain
            s.p(x + out, top, c("#9aa0a8"))
            s.rect(x + out, top + 1, x + out * 2, top + 2, head)
    elif k in ("staff", "staff_orb", "spear", "halberd", "glaive", "trident", "pike", "lance"):
        top = hy - L
        s.vline(x, top, min(FOOT, hy + 3), wood)
        s.vline(x, top, hy - 1, shade(wood, 0.15)) if k == "staff" else None
        if k == "staff_orb":
            s.rect(x - 1, top - 2, x + 1, top, head)
            s.p(x - 1, top - 2, c("#ffffff"))
            s.put(x - 2, top - 1, alpha(head, 90))
            s.put(x + 2, top - 1, alpha(head, 90))
        elif k in ("spear", "pike", "lance"):
            s.vline(x, top - 3, top - 1, hl)
            s.p(x + out, top - 1, head)
            if k == "lance":
                s.rect(x - 1, hy - 2, x + 1, hy - 1, head)
        elif k == "trident":
            for d in (-1, 0, 1):
                s.vline(x + d, top - 3 + abs(d), top - 1, hl)
            s.hline(x - 1, x + 1, top - 1, head)
        else:                                                   # halberd, glaive
            s.vline(x, top - 3, top - 1, hl)
            s.rect(x + out, top - 1, x + out * 3, top + 2, head) if k == "halberd" else \
                s.rect(x + out, top - 3, x + out, top + 1, head)
    elif k == "bow":
        bx = x + out
        for i in range(L + 2):
            y = hy - L // 2 - 1 + i
            bend = 1 if 1 < i < L else 0
            s.p(bx + bend * out, y, wood)
        s.vline(bx - out, hy - L // 2 - 1, hy + L // 2, c("#e8e0c8"))  # the string
    elif k == "crossbow":
        s.hline(x - 1, x + 2 * out, hy - 1, wood) if out > 0 else s.hline(x + 2 * out, x + 1, hy - 1, wood)
        s.hline(x - 2, x + 2, hy - 2, head)
        s.p(x, hy - 3, hl)
    elif k == "wand":
        s.vline(x, hy - L, hy, wood)
        s.p(x, hy - L - 1, head)
        s.put(x + 1, hy - L - 1, alpha(head, 120))
    elif k == "torch":
        s.vline(x, hy - L + 2, hy + 2, wood)
        top = hy - L + 1
        s.p(x, top, c("#d8402e"))
        s.p(x, top - 1, c("#f08a30"))
        s.p(x + out, top - 1, c("#f6c040"))
        s.p(x, top - 2, c("#fff0a0"))
    elif k in ("sickle",):
        s.vline(x, hy - 1, hy + 2, wood)
        s.p(x, hy - 2, head)
        s.p(x + out, hy - 3, head)
        s.p(x + out * 2, hy - 3, hl)
    elif k in ("whip", "sling", "net"):
        col = wood
        s.vline(x, hy, hy + 3, col)
        s.p(x + out, hy + 3, col)
        s.p(x + out, hy + 4, shade(col, -0.2))
    elif k in ("dart", "blowgun"):
        s.vline(x, hy - L, hy + 1, wood if k == "blowgun" else head)


def _shield(f: _Fig, where: str) -> None:
    g = f.gear
    if not g.shield or g.two_handed():
        return
    layer = Px(W, H)
    _shield_shape(f, layer, where)
    layer.outline(0.55)
    f.s.blit(layer)


def _shield_shape(f: _Fig, s: Px, where: str) -> None:
    g = f.gear
    sid = g.shield
    face = c(g.shield_color) if g.shield_color else c("#8a5a32")
    rim = c(g.shield_tint) if g.shield_tint else METAL
    if where == "front":
        hx, hy = f.hands[1]
        cx, cy = hx + 2, hy - 2
    elif where == "back":                                     # on the arm away from us, its back to us
        cx, cy = f.tx0 - 3, f.ly0 - 3
        face = shade(c("#8a5a32"), -0.1)
    else:
        cx, cy = CX - 2, f.ly0 - 3
    if sid == "round":
        s.disc(cx, cy, 3.6, 3.6, rim)
        s.disc(cx, cy, 2.7, 2.7, face)
        s.disc(cx - 0.5, cy - 0.5, 1.2, 1.2, shade(face, 0.18))
        if where != "back":
            s.rect(cx - 1, cy - 1, cx, cy, rim)
    elif sid == "buckler":
        s.disc(cx, cy + 1, 2.5, 2.5, rim)
        s.p(cx - 1, cy, shade(rim, 0.3))
    elif sid == "tower":
        x0, y0 = int(cx - 3), int(cy - 6)
        s.rect(x0, y0, x0 + 5, y0 + 11, rim)
        s.rect(x0 + 1, y0 + 1, x0 + 4, y0 + 10, face)
        s.vline(x0 + 1, y0 + 1, y0 + 10, shade(face, 0.18))
    else:                                                     # heater
        x0, y0 = int(cx - 3), int(cy - 4)
        s.poly([(x0, y0), (x0 + 6, y0), (x0 + 6, y0 + 4), (x0 + 3, y0 + 8), (x0, y0 + 4)], rim)
        s.poly([(x0 + 1, y0 + 1), (x0 + 5, y0 + 1), (x0 + 5, y0 + 4), (x0 + 3, y0 + 7), (x0 + 1, y0 + 4)], face)
        if where != "back":
            s.vline(x0 + 3, y0 + 1, y0 + 6, shade(face, 0.25))
            s.hline(x0 + 1, x0 + 5, y0 + 3, shade(face, 0.25))


# ======================================================================
# Out
# ======================================================================
def _scaled(px: Px, tiles: int) -> Canvas:
    cv = px.done()
    if tiles <= 1:
        return cv
    out = Canvas(cv.w * tiles, cv.h * tiles)
    for y in range(out.h):
        row = (y // tiles) * cv.w
        for x in range(out.w):
            out.px[y * out.w + x] = cv.px[row + x // tiles]
    return out


def _key(look: Look, gear: Gear) -> tuple:
    lk = look.resolved()
    return (lk.base, lk.skin, lk.hair, lk.hair_color, lk.beard, lk.eyes, lk.accent, lk.clothes,
            gear.armor, gear.armor_tint, gear.helmet, gear.helmet_tint, gear.cloak, gear.cloak_color, gear.weapon,
            gear.weapon_tint, gear.off_weapon, gear.off_weapon_tint, gear.shield, gear.shield_tint,
            gear.shield_color)


def sprite(look: Look, gear: Gear | None = None, tiles: int = 1) -> Canvas:
    """The figure facing south, with .views (1 west, 2 north, 3 east) and .steps (two walking frames a facing)."""
    gear = gear or Gear()
    return _sprite(_key(look, gear), max(1, int(tiles)))


@lru_cache(maxsize=512)
def _sprite(key: tuple, tiles: int) -> Canvas:
    from game.art import store
    return store.cached("folk", (key, tiles), lambda: _draw_sprite(key, tiles))


def _draw_sprite(key: tuple, tiles: int) -> Canvas:
    look = Look(*key[:8])
    gear = Gear(armor=key[8], armor_tint=key[9], helmet=key[10], helmet_tint=key[11], cloak=key[12],
                cloak_color=key[13], weapon=key[14], weapon_tint=key[15], off_weapon=key[16],
                off_weapon_tint=key[17], shield=key[18], shield_tint=key[19], shield_color=key[20])
    look = look.resolved()
    pics = {}
    for view, q in (("front", 0), ("side", 1), ("back", 2)):
        pics[q] = [_draw(look, gear, view, st) for st in (0, 1, 2)]
    pics[3] = [p.flipped() for p in pics[1]]
    front = _scaled(pics[0][0], tiles)
    front.views = {q: _scaled(pics[q][0], tiles) for q in (1, 2, 3)}
    front.views[0] = front
    front.steps = {q: [_scaled(p, tiles) for p in pics[q][1:]] for q in range(4)}
    return front


def facing(art: Canvas, q: int, step: int = 0) -> Canvas:
    """One of a sprite's facings (0 south, 1 west, 2 north, 3 east), standing or mid-stride (1, 2)."""
    views = getattr(art, "views", None)
    if not views:
        return art
    if step and getattr(art, "steps", None):
        return art.steps[q % 4][(step - 1) % 2]
    return views.get(q % 4, art)


def seed_of(text: str) -> int:
    return zlib.crc32(text.encode("utf-8"))


__all__ = ["sprite", "facing", "BODIES", "W", "H"]
