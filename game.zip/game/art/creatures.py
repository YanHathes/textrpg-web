"""Non-humanoid creature bodies: what each is (its name, colours, variants), and drawing one.

The drawing is in the house style (game/art/beasts.py): standing side-on, a picture for each facing and
walking frames, drawn bigger (with more pixels, not stretched) the more squares the creature fills. Colours
come from the look, so the same body makes a wolf, a dire wolf and a winter wolf.
"""
from __future__ import annotations

from dataclasses import dataclass

from game.art.canvas import Canvas


@dataclass(frozen=True)
class CreatureBase:
    id: str
    label: str
    main: str
    secondary: str
    eyes: str
    options: tuple[str, ...]
    category: str = "Beasts"
    variants: tuple[str, ...] = ()       # named shape variants
    default_variant: str = ""


CREATURE_BASES: dict[str, CreatureBase] = {b.id: b for b in [
    CreatureBase("canine", "Canine (wolf, dog)", "#7d7a74", "#c9c2b4", "#f0d040",
                 ("#7d7a74", "#4a4440", "#e8e8ea", "#9a6a3a", "#c4a070", "#3a3a40")),
    CreatureBase("feline", "Feline (cat, lion)", "#c98e3a", "#5a3a20", "#a8d040",
                 ("#c98e3a", "#e0a040", "#2a2a2e", "#d8c8a8", "#b07040")),
    CreatureBase("bear", "Bear", "#6a4a32", "#a07a52", "#1a1410",
                 ("#6a4a32", "#3a2a22", "#e8e8e0", "#8a6a42")),
    CreatureBase("hoofed", "Hoofed (deer, horse)", "#9a6a42", "#e8d8c0", "#1a1410",
                 ("#9a6a42", "#6a4a32", "#3a2e28", "#c8b8a0", "#e8e4dc"), variants=("plain", "antlers")),
    CreatureBase("boar", "Boar", "#6a5040", "#a08070", "#d04020", ("#6a5040", "#4a3a32", "#8a6a50")),
    CreatureBase("rodent", "Rodent (rat)", "#7a6a5e", "#c8b0a0", "#d02020", ("#7a6a5e", "#4a4038", "#a89888")),
    CreatureBase("lizard", "Lizard", "#5a8a4a", "#d8c86a", "#f0c020",
                 ("#5a8a4a", "#8a6a3a", "#4a6a8a", "#a04a3a")),
    CreatureBase("bird", "Bird", "#7a5a3a", "#e8e0d0", "#f0b020",
                 ("#7a5a3a", "#3a3a40", "#e8e8e8", "#c04030", "#4a6aa0")),
    CreatureBase("bat", "Bat", "#4a3a3a", "#6a5050", "#f04040", ("#4a3a3a", "#2a2a30", "#6a5a4a")),
    CreatureBase("serpent", "Serpent", "#4a7a3a", "#d8c060", "#f0d020",
                 ("#4a7a3a", "#a03a2a", "#3a3a3a", "#c8a050", "#3a5a8a")),
    CreatureBase("spider", "Spider", "#3a3036", "#c02020", "#f04040",
                 ("#3a3036", "#6a5a4a", "#2a2a2a", "#7a7a80")),
    CreatureBase("insect", "Insect (beetle, ant)", "#5a3a2a", "#c0a040", "#f0f0a0",
                 ("#5a3a2a", "#2a3a4a", "#3a5a2a", "#8a2a1a")),
    CreatureBase("ooze", "Ooze", "#6ad07a", "#a0f0a0", "#000000",
                 ("#6ad07a", "#3a3a3a", "#c0a040", "#6ab0e0", "#e06a6a"), category="Oozes", variants=("ooze", "cube")),
    CreatureBase("elemental", "Elemental", "#f08020", "#ffe070", "#ffffff",
                 ("#f08020", "#3a8ad0", "#c0d0e0", "#7a5a3a"), category="Elementals",
                 variants=("fire", "water", "air", "earth"), default_variant="fire"),
    CreatureBase("plant", "Plant creature", "#4a8a3a", "#5a3a22", "#f0e040",
                 ("#4a8a3a", "#6a7a3a", "#3a5a2a", "#8a8a4a"), category="Plants"),
    CreatureBase("dragon", "Dragon", "#b8322a", "#e8b860", "#f0e040",
                 ("#b8322a", "#2a5ab8", "#3a8a3a", "#2a2a30", "#e8eef4", "#c9a13a", "#b06a2e", "#9a5a3a",
                  "#a9b4bf", "#d8b04a"), category="Dragons"),
]}

ELEMENT_COLORS = {
    "fire": ("#f08020", "#ffe070", "#ffffff"),
    "water": ("#2a7ad0", "#a0e0ff", "#ffffff"),
    "air": ("#c0d0e0", "#ffffff", "#3a4a6a"),
    "earth": ("#7a5a3a", "#a08060", "#f0c040"),
}


def draw_creature(base_id: str, tiles: int = 1, main: str = "", secondary: str = "", eyes: str = "",
                  variant: str = "") -> Canvas:
    """A creature's sprite (game/art/beasts.py)."""
    from game.art import beasts
    return beasts.draw(base_id, tiles, main, secondary, eyes, variant)


__all__ = ["CreatureBase", "CREATURE_BASES", "ELEMENT_COLORS", "draw_creature"]
