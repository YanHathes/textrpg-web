"""Mood backgrounds for the log: side-view pixel-art scenes of where you are.

    scene = paint(SceneSpec(place="Tavern", walls="Wooden", people=6, time="Night"))
    scene.canvas   # 320x180 picture
    scene.lights   # fires, candles, torches: (x, y, radius, color) for flicker effects
    scene.ambient  # bright / dim / dark (game.combat.lighting levels)

Interiors are built from the wall material (wood, stone, brick, rich, rustic)
and the kind of building, with more people drawn the busier it is. Outdoor
scenes follow the biome and the time of day.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from functools import lru_cache

from game.art.canvas import Canvas, hex_to_rgba, mix, shift, with_alpha
from game.combat.lighting import BRIGHT, DARK, DIM

W, H = 320, 180
FLOOR_Y = 122          # where interior back walls meet the floor

INTERIOR_PLACES = ["Tavern", "Inn", "Shop", "Market", "Smithy", "Temple", "Library", "House", "Barracks",
                   "Warehouse", "Stable", "Guild hall", "Town hall"]
OUTDOOR_PLACES = ["Forest", "Plains", "Hills", "Mountains", "Swamp", "Desert", "Arctic", "Coast", "Town street"]
UNDERGROUND = ["Cave", "Dungeon"]
ALL_PLACES = INTERIOR_PLACES + OUTDOOR_PLACES + UNDERGROUND
WALLS = ["Wooden", "Stone", "Brick", "Rich", "Rustic"]
TIMES = ["Morning", "Day", "Dusk", "Night"]

SKIN = ["#f3cfb0", "#e0ac84", "#c68a62", "#a06a46", "#7a4c30", "#8fa36a", "#b5524e"]
HAIR = ["#2b2220", "#4a3426", "#7a5230", "#b08a4e", "#d9c27a", "#8c3b1f", "#cfcac0", "#1f1a2b"]
CLOTH = ["#5b6b4e", "#4d5f7a", "#7a4b33", "#6a2a3a", "#3b2f4a", "#8a7a5a", "#2e4a5a", "#7a6a3a", "#5a3a5a"]


@dataclass
class SceneSpec:
    place: str = "Tavern"
    walls: str = "Wooden"
    people: int = 3
    time: str = "Day"
    seed: int = 1


@dataclass
class Scene:
    canvas: Canvas
    lights: list = field(default_factory=list)    # (x, y, radius, color, strength)
    ambient: int = BRIGHT
    outdoor: bool = False


# ======================================================================
# Small drawing helpers
# ======================================================================
def _vgrad(c: Canvas, y0: int, y1: int, top, bottom, x0: int = 0, x1: int = W - 1) -> None:
    top, bottom = hex_to_rgba(top), hex_to_rgba(bottom)
    for y in range(y0, y1 + 1):
        t = (y - y0) / max(1, y1 - y0)
        col = mix(top, bottom, t)
        for x in range(x0, x1 + 1):
            c.set(x, y, col)


def _dither_band(c: Canvas, y: int, col, step: int = 2) -> None:
    for x in range(0, W, step):
        c.set(x + (y % 2), y, col)


def _ridge(c: Canvas, rng: random.Random, base_y: float, amp: float, freq: float, color, jag: float = 0.0) -> None:
    phase = rng.random() * 10
    for x in range(W):
        h = (math.sin(x * freq + phase) * amp + math.sin(x * freq * 2.7 + phase * 1.7) * amp * 0.35
             + (rng.random() - 0.5) * jag)
        top = int(base_y - h)
        for y in range(max(0, top), H):
            c.set(x, y, color)


def _flame(c: Canvas, x: float, y: float, size: float, rng: random.Random) -> None:
    """A little pixel flame with its base at (x, y)."""
    for i in range(int(size * 3)):
        t = i / max(1, size * 3)
        w = size * (1 - t) * 0.9 + 0.5
        cx = x + math.sin(i * 1.7 + rng.random()) * 0.6
        col = mix("#ff5a1a", "#ffe27a", t * 1.2) if t < 0.8 else "#fff3c0"
        c.ellipse(cx, y - i * 0.9, w, 1.0, col)
    c.ellipse(x, y - size * 0.6, size * 0.35, size * 0.6, "#fff6d0")


def _person(c: Canvas, x: int, y: int, rng: random.Random, seated: bool = False, facing: int = 1,
            apron: bool = False, scale: float = 1.0) -> None:
    """A tiny side-view person standing (or sitting) with feet at (x, y)."""
    skin = hex_to_rgba(rng.choice(SKIN))
    hair = hex_to_rgba(rng.choice(HAIR))
    cloth = hex_to_rgba(rng.choice(CLOTH))
    legs = shift(cloth, -0.15) if rng.random() < 0.5 else hex_to_rgba("#3a2e28")
    s = scale
    body_h = int(9 * s)
    if seated:
        hip = y - int(6 * s)
        c.rect(x - int(2 * s), hip, x + int(3 * s), hip + int(2 * s), legs)         # thighs forward
        c.rect(x + int(2 * s) * facing if facing > 0 else x - int(3 * s), hip + int(2 * s),
               x + int(3 * s) if facing > 0 else x - int(2 * s), y, legs)
    else:
        hip = y - int(8 * s)
        c.rect(x - int(2 * s), hip, x - 1, y - 1, legs)
        c.rect(x, hip, x + int(1 * s), y - 1, shift(legs, -0.06))
        c.rect(x - int(2 * s), y - 1, x - 1 + int(1 * s), y - 1, "#2a2220")
    top = hip - body_h
    c.rect(x - int(3 * s), top, x + int(2 * s), hip, cloth)
    c.rect(x - int(3 * s), top, x - int(3 * s), hip, shift(cloth, 0.06))
    if apron:
        c.rect(x - int(2 * s), top + 3, x + int(1 * s), hip, "#d8cdb0")
    arm_x = x + (int(2 * s) if facing > 0 else -int(3 * s))
    c.rect(arm_x, top + 1, arm_x, top + int(6 * s), shift(cloth, -0.08))
    c.rect(arm_x, top + int(6 * s), arm_x, top + int(7 * s), skin)
    hy = top - int(3 * s)
    c.ellipse(x - 0.5, hy, 2.6 * s, 2.9 * s, skin)
    c.ellipse(x - 0.5 - facing * 0.6, hy - 1.4 * s, 2.8 * s, 1.8 * s, hair)
    c.set(int(x + facing * 1.4 * s - 0.5), int(hy), "#1a1416")


def _people(c: Canvas, rng: random.Random, n: int, spots: list[tuple[int, int, bool]], scale: float = 1.0) -> None:
    rng.shuffle(spots)
    for i in range(min(n, len(spots))):
        x, y, seated = spots[i]
        _person(c, x, y, rng, seated=seated, facing=rng.choice((-1, 1)), scale=scale)


# ======================================================================
# Interiors
# ======================================================================
WALL_COLORS = {
    "Wooden": "#6e4a2c", "Stone": "#7a766e", "Brick": "#8a4a3a", "Rich": "#5a2430", "Rustic": "#7a5232",
}


def _back_wall(c: Canvas, walls: str, rng: random.Random) -> None:
    base = hex_to_rgba(WALL_COLORS.get(walls, "#6e4a2c"))
    c.rect(0, 0, W - 1, FLOOR_Y, base)
    if walls == "Wooden":
        x = 0
        while x < W:
            w = rng.randint(9, 13)
            tone = shift(base, (rng.random() - 0.5) * 0.06)
            c.rect(x, 0, x + w - 1, FLOOR_Y, tone)
            c.rect(x, 0, x, FLOOR_Y, shift(base, -0.12))
            for _ in range(3):
                gy = rng.randint(4, FLOOR_Y - 4)
                c.rect(x + 2, gy, x + w - 3, gy, shift(tone, -0.05))
            x += w
        for bx in (0, 96, 208, 312):
            c.rect(bx, 0, bx + 7, FLOOR_Y, shift(base, -0.18))
            c.rect(bx, 0, bx, FLOOR_Y, shift(base, -0.05))
    elif walls in ("Stone", "Brick"):
        bh, bw = (10, 22) if walls == "Stone" else (6, 14)
        mortar = shift(base, -0.18)
        c.rect(0, 0, W - 1, FLOOR_Y, mortar)
        for row in range(FLOOR_Y // bh + 1):
            y0 = row * bh
            off = (bw // 2) if row % 2 else 0
            for x0 in range(-off, W, bw):
                tone = shift(base, (rng.random() - 0.5) * 0.08)
                c.rect(max(0, x0 + 1), y0 + 1, min(W - 1, x0 + bw - 1), min(FLOOR_Y, y0 + bh - 1), tone)
                c.rect(max(0, x0 + 1), y0 + 1, min(W - 1, x0 + bw - 1), y0 + 1, shift(tone, 0.06))
    elif walls == "Rich":
        paper = hex_to_rgba("#5a2430")
        c.rect(0, 0, W - 1, FLOOR_Y, paper)
        for y in range(4, 70, 10):
            for x in range((y // 10 % 2) * 8, W, 16):
                c.ellipse(x, y, 2, 3, shift(paper, 0.08))
                c.set(x, y, "#c9a24a")
        c.rect(0, 72, W - 1, FLOOR_Y, "#4a2e1e")
        for x in range(0, W, 26):
            c.rect(x + 3, 78, x + 22, FLOOR_Y - 5, "#5a3a26")
            c.rect(x + 3, 78, x + 22, 78, "#6e4a30")
        c.rect(0, 70, W - 1, 72, "#c9a24a")
    elif walls == "Rustic":
        for y in range(0, FLOOR_Y, 9):
            tone = shift(base, (rng.random() - 0.5) * 0.08)
            c.rect(0, y, W - 1, y + 8, tone)
            c.rect(0, y, W - 1, y, shift(tone, 0.08))
            c.rect(0, y + 8, W - 1, y + 8, shift(tone, -0.2))
            for x in range(rng.randint(0, 30), W, rng.randint(40, 70)):
                c.ellipse(x, y + 4, 2, 2, shift(tone, -0.1))
    # ceiling beam and shadow under it
    c.rect(0, 0, W - 1, 7, shift(base, -0.28))
    c.rect(0, 8, W - 1, 9, shift(base, -0.2))
    # skirting where wall meets floor
    c.rect(0, FLOOR_Y - 3, W - 1, FLOOR_Y, shift(base, -0.25))


def _floor(c: Canvas, walls: str, rng: random.Random) -> None:
    if walls in ("Stone", "Brick"):
        base = hex_to_rgba("#5e5a54")
        c.rect(0, FLOOR_Y + 1, W - 1, H - 1, base)
        y = FLOOR_Y + 1
        h = 6
        row = 0
        while y < H:
            off = (row % 2) * 12
            for x in range(-off, W, 24 + row * 2):
                c.rect(max(0, x), y, max(0, x), min(H - 1, y + h), shift(base, -0.15))
            c.rect(0, y, W - 1, y, shift(base, -0.15))
            y += h
            h += 2
            row += 1
    else:
        base = hex_to_rgba("#7a5232" if walls != "Rich" else "#5a3a22")
        c.rect(0, FLOOR_Y + 1, W - 1, H - 1, base)
        y = FLOOR_Y + 1
        h = 4
        while y < H:
            tone = shift(base, (rng.random() - 0.5) * 0.06)
            c.rect(0, y, W - 1, min(H - 1, y + h), tone)
            c.rect(0, y, W - 1, y, shift(tone, -0.18))
            y += h + 1
            h += 1
        if walls == "Rich":
            c.rect(70, FLOOR_Y + 14, 250, H - 1, "#7a1e28")
            c.rect(70, FLOOR_Y + 14, 250, FLOOR_Y + 15, "#c9a24a")
            for x in range(80, 245, 12):
                c.set(x, FLOOR_Y + 30, "#c9a24a")
    # soft shadow along the wall
    for d in range(4):
        for x in range(W):
            c.put(x, FLOOR_Y + 1 + d, (0, 0, 0, 60 - d * 14))


def _window(c: Canvas, x: int, y: int, w: int, h: int, time: str, walls: str, stained: bool = False) -> list:
    sky = {"Morning": ("#9fc4e8", "#f3d6a8"), "Day": ("#6aa8e0", "#bfe0f4"), "Dusk": ("#5a4a8a", "#f08a4a"),
           "Night": ("#0e1430", "#1e2a50")}[time]
    frame = shift(WALL_COLORS.get(walls, "#6e4a2c"), -0.3)
    c.rect(x - 2, y - 2, x + w + 1, y + h + 1, frame)
    _vgrad(c, y, y + h - 1, sky[0], sky[1], x, x + w - 1)
    if stained:
        cols = ["#c03a3a", "#3a6ad0", "#e0b84a", "#3aa04a", "#8a3ad0"]
        for i in range(0, w, 4):
            for j in range(0, h, 4):
                c.rect(x + i, y + j, min(x + w - 1, x + i + 3), min(y + h - 1, y + j + 3),
                       with_alpha(cols[(i // 4 + j // 4) % len(cols)], 200))
    elif time == "Night":
        c.set(x + w // 3, y + h // 3, "#ffffff")
        c.set(x + 2 * w // 3, y + 2, "#c8d0ff")
    c.rect(x + w // 2, y, x + w // 2, y + h - 1, frame)
    c.rect(x, y + h // 2, x + w - 1, y + h // 2, frame)
    c.rect(x - 3, y + h + 1, x + w + 2, y + h + 2, shift(frame, 0.1))
    if time in ("Morning", "Day") and not stained:
        # sunlight falling across the room
        for i in range(60):
            yy = y + h + i
            if yy >= H:
                break
            for xx in range(x + i // 2, x + w + i // 2 + 6):
                if 0 <= xx < W:
                    c.put(xx, yy, (255, 240, 200, 18))
    return []


def _table(c: Canvas, x: int, w: int, y: int, rng: random.Random, wood="#6e4a2c") -> None:
    c.rect(x, y, x + w, y + 2, shift(wood, 0.1))
    c.rect(x, y + 3, x + w, y + 3, shift(wood, -0.2))
    c.rect(x + 2, y + 4, x + 3, y + 14, shift(wood, -0.12))
    c.rect(x + w - 3, y + 4, x + w - 2, y + 14, shift(wood, -0.12))
    for _ in range(rng.randint(1, 3)):
        mx = rng.randint(x + 3, x + w - 4)
        kind = rng.random()
        if kind < 0.5:
            c.rect(mx, y - 4, mx + 2, y - 1, "#c8b080")
            c.rect(mx, y - 4, mx + 2, y - 4, "#f4f0e0")
        elif kind < 0.8:
            c.ellipse(mx, y - 1, 3, 1.2, "#d8d0c0")
        else:
            c.rect(mx, y - 6, mx + 1, y - 1, "#3a6a3a")


def _barrel(c: Canvas, x: int, y: int, h: int = 14) -> None:
    c.rect(x, y - h, x + 10, y, "#8a5a32")
    for xx in (x + 3, x + 7):
        c.rect(xx, y - h, xx, y, "#6e4a2c")
    for yy in (y - h + 2, y - 3):
        c.rect(x, yy, x + 10, yy, "#5a5e62")
    c.rect(x, y - h, x + 10, y - h, "#a06a3a")


def _crate(c: Canvas, x: int, y: int, s: int = 12) -> None:
    c.rect(x, y - s, x + s, y, "#a07040")
    c.rect(x, y - s, x + s, y - s, "#c08850")
    c.line(x, y - s, x + s, y, "#7a5230")
    c.rect(x, y - s, x, y, "#7a5230")
    c.rect(x + s, y - s, x + s, y, "#7a5230")


def _shelf(c: Canvas, x: int, y: int, w: int, rows: int, rng: random.Random, books: bool = False) -> None:
    c.rect(x - 2, y - 2, x + w + 2, y + rows * 14 + 2, "#4e3420")
    for r in range(rows):
        sy = y + r * 14
        c.rect(x, sy, x + w, sy + 11, "#2a1e16")
        xx = x + 1
        while xx < x + w - 1:
            if books:
                bw = rng.randint(1, 3)
                bh = rng.randint(7, 10)
                c.rect(xx, sy + 11 - bh, xx + bw - 1, sy + 10,
                       rng.choice(["#8a2a2a", "#2a4a7a", "#3a6a3a", "#7a6a2a", "#5a2a5a", "#a08a6a"]))
                xx += bw + (1 if rng.random() < 0.15 else 0)
            else:
                kind = rng.random()
                col = rng.choice(["#c03a3a", "#3a6ad0", "#3aa04a", "#e0b84a", "#a070e0", "#c8b080"])
                if kind < 0.5:
                    c.rect(xx, sy + 4, xx + 2, sy + 10, col)
                    c.rect(xx + 1, sy + 2, xx + 1, sy + 3, "#d8d0c0")
                    xx += 4
                else:
                    c.rect(xx, sy + 6, xx + 4, sy + 10, shift(col, -0.1))
                    xx += 6
        c.rect(x, sy + 11, x + w, sy + 12, "#6e4a2c")


def _hearth(c: Canvas, x: int, rng: random.Random, lights: list, scale: int = 1) -> None:
    w = 46
    top = FLOOR_Y - 46
    c.rect(x, top, x + w, FLOOR_Y, "#6a665e")
    for yy in range(top, FLOOR_Y, 6):
        off = 4 if (yy // 6) % 2 else 0
        for xx in range(x + off, x + w, 9):
            c.rect(xx, yy, xx, yy + 5, "#4e4a44")
        c.rect(x, yy, x + w, yy, "#4e4a44")
    c.rect(x - 4, top - 4, x + w + 4, top, "#5a3a22")
    c.rect(x + 9, top + 16, x + w - 9, FLOOR_Y, "#1a1210")
    c.rect(x + 12, FLOOR_Y - 4, x + w - 12, FLOOR_Y - 2, "#3a2a20")
    for fx in range(x + 15, x + w - 13, 5):
        _flame(c, fx, FLOOR_Y - 4, 3.2 + rng.random() * 1.6, rng)
    c.rect(x + 14, top + 22, x + 16, top + 26, "#3a3a3a")
    lights.append((x + w / 2, FLOOR_Y - 10, 70, "#ff8a3a", 1.0))


def _torch(c: Canvas, x: int, y: int, rng: random.Random, lights: list) -> None:
    c.rect(x - 1, y, x + 1, y + 9, "#5a3a22")
    c.rect(x - 2, y + 4, x + 2, y + 5, "#3a3a3a")
    _flame(c, x, y, 2.6, rng)
    lights.append((x, y - 3, 44, "#ffa04a", 0.8))


def _candle(c: Canvas, x: int, y: int, rng: random.Random, lights: list) -> None:
    c.rect(x, y - 4, x + 1, y, "#f0e8d0")
    _flame(c, x + 0.5, y - 4, 1.0, rng)
    lights.append((x, y - 6, 18, "#ffd27a", 0.5))


def _paint_interior(spec: SceneSpec, rng: random.Random) -> Scene:
    c = Canvas(W, H)
    lights: list = []
    walls = spec.walls if spec.walls in WALL_COLORS else "Wooden"
    _back_wall(c, walls, rng)
    _floor(c, walls, rng)
    place = spec.place
    n = max(0, int(spec.people))
    stand = []    # (x, y, seated) where people can go

    if place in ("Tavern", "Inn", "Guild hall", "Town hall", "House", "Barracks"):
        _window(c, 128, 26, 30, 34, spec.time, walls)
        if place in ("Tavern", "Inn"):
            # bar with bottles behind it
            _shelf(c, 14, 30, 70, 2, rng)
            c.rect(10, FLOOR_Y - 22, 92, FLOOR_Y - 18, "#6e4a2c")
            c.rect(14, FLOOR_Y - 18, 90, FLOOR_Y + 8, "#5a3a22")
            for xx in range(18, 88, 10):
                c.rect(xx, FLOOR_Y - 16, xx + 7, FLOOR_Y + 6, "#4e3420")
            _person(c, 50, FLOOR_Y - 18, rng, apron=True)                     # the keeper
            for i in range(4):
                c.rect(24 + i * 15, FLOOR_Y - 26, 26 + i * 15, FLOOR_Y - 22, "#c8b080")
            _hearth(c, 250, rng, lights)
            for bx in (200, 212):
                _barrel(c, bx, FLOOR_Y + 2)
            tables = [(108, 46), (176, 40), (60, 44), (228, 50)]
        elif place == "House":
            _hearth(c, 240, rng, lights)
            c.rect(20, FLOOR_Y - 14, 76, FLOOR_Y + 8, "#6a4a3a")
            c.rect(20, FLOOR_Y - 18, 76, FLOOR_Y - 13, "#d8d0c0")
            c.rect(20, FLOOR_Y - 18, 30, FLOOR_Y - 10, "#f0ece4")
            _shelf(c, 190, 34, 34, 1, rng)
            tables = [(120, 40)]
        elif place == "Barracks":
            for bx in (14, 84):
                c.rect(bx, FLOOR_Y - 30, bx + 56, FLOOR_Y - 26, "#6e4a2c")
                c.rect(bx, FLOOR_Y - 8, bx + 56, FLOOR_Y - 4, "#6e4a2c")
                c.rect(bx + 2, FLOOR_Y - 34, bx + 54, FLOOR_Y - 30, "#7a6a4a")
                c.rect(bx + 2, FLOOR_Y - 12, bx + 54, FLOOR_Y - 8, "#7a6a4a")
            for i, sx in enumerate(range(200, 300, 18)):
                c.ellipse(sx, 50, 7, 8, ["#8a2a2a", "#2a4a7a", "#7a6a2a"][i % 3])
                c.ellipse(sx, 50, 2, 2, "#c8c8c8")
            _torch(c, 186, 40, rng, lights)
            _torch(c, 300, 40, rng, lights)
            tables = [(220, 60)]
        else:   # guild hall, town hall
            for bx in (30, 260):
                c.rect(bx, 14, bx + 20, 60, "#7a1e28")
                c.rect(bx, 14, bx + 20, 16, "#c9a24a")
                c.polygon([(bx, 60), (bx + 20, 60), (bx + 10, 68)], "#7a1e28")
                c.ellipse(bx + 10, 36, 5, 5, "#c9a24a")
            tables = [(70, 180)]
            for cx in (110, 210):
                c.rect(cx - 10, 18, cx + 10, 19, "#3a3a3a")
                for k in range(-8, 9, 4):
                    _candle(c, cx + k, 18, rng, lights)
        for tx, tw in tables:
            _table(c, tx, tw, FLOOR_Y + 22, rng)
            stand += [(tx + 6, FLOOR_Y + 36, True), (tx + tw - 6, FLOOR_Y + 36, True),
                      (tx + tw // 2, FLOOR_Y + 40, False)]
        stand += [(x, FLOOR_Y + 30 + rng.randint(0, 20), False) for x in range(30, 300, 26)]
        if place in ("Tavern", "Inn") and spec.time != "Day":
            for cx in (120, 200):
                c.rect(cx - 8, 22, cx + 8, 23, "#3a3a3a")
                _candle(c, cx - 6, 22, rng, lights)
                _candle(c, cx + 5, 22, rng, lights)
    elif place in ("Shop", "Market"):
        _window(c, 230, 26, 34, 34, spec.time, walls)
        _shelf(c, 14, 20, 96, 4, rng)
        _shelf(c, 124, 20, 70, 3, rng)
        c.rect(60, FLOOR_Y + 2, 220, FLOOR_Y + 8, "#6e4a2c")
        c.rect(64, FLOOR_Y + 9, 216, FLOOR_Y + 30, "#5a3a22")
        c.rect(130, FLOOR_Y - 4, 146, FLOOR_Y + 1, "#c9a24a")
        _person(c, 100, FLOOR_Y + 2, rng, apron=True)
        for i in range(3):
            _crate(c, 250 + i * 14, H - 6)
        stand += [(x, H - 4 - rng.randint(0, 10), False) for x in range(20, 310, 22)]
    elif place == "Smithy":
        # forge, anvil, weapon rack
        c.rect(20, FLOOR_Y - 50, 90, FLOOR_Y, "#5a5650")
        c.rect(26, FLOOR_Y - 60, 84, FLOOR_Y - 50, "#4a4640")
        c.rect(36, FLOOR_Y - 34, 74, FLOOR_Y - 8, "#1a1210")
        for fx in range(40, 72, 4):
            _flame(c, fx, FLOOR_Y - 10, 3.0 + rng.random() * 2, rng)
        c.rect(36, FLOOR_Y - 10, 74, FLOOR_Y - 8, "#ff7a2a")
        lights.append((55, FLOOR_Y - 20, 90, "#ff6a20", 1.2))
        c.rect(150, FLOOR_Y + 14, 156, FLOOR_Y + 30, "#3a3a3a")
        c.polygon([(134, FLOOR_Y + 8), (176, FLOOR_Y + 8), (182, FLOOR_Y + 12), (176, FLOOR_Y + 14),
                   (140, FLOOR_Y + 14)], "#5a6068")
        c.rect(136, FLOOR_Y + 8, 176, FLOOR_Y + 9, "#8a929a")
        c.rect(158, FLOOR_Y + 4, 168, FLOOR_Y + 7, "#ff9a4a")
        for i, sx in enumerate(range(212, 300, 14)):
            c.rect(sx, 30, sx + 1, 92, "#a7b1ba")
            c.rect(sx - 3, 88, sx + 4, 89, "#c9a24a")
            c.rect(sx, 90, sx + 1, 98, "#5e3b22")
        c.rect(205, 26, 305, 28, "#5e3b22")
        c.rect(205, 99, 305, 101, "#5e3b22")
        _person(c, 168, FLOOR_Y + 32, rng, apron=True)
        stand += [(x, FLOOR_Y + 34 + rng.randint(0, 16), False) for x in range(100, 310, 24)]
        n = max(0, n - 1)
    elif place == "Temple":
        _window(c, 140, 14, 40, 60, spec.time, walls, stained=True)
        c.rect(120, FLOOR_Y - 18, 200, FLOOR_Y + 4, "#a8a49c")
        c.rect(118, FLOOR_Y - 20, 202, FLOOR_Y - 17, "#c8c4bc")
        c.rect(156, FLOOR_Y - 30, 164, FLOOR_Y - 20, "#e8d070")
        for cx in range(126, 196, 10):
            _candle(c, cx, FLOOR_Y - 20, rng, lights)
        for row, y in enumerate((FLOOR_Y + 20, FLOOR_Y + 36)):
            for x in (30, 200):
                c.rect(x, y, x + 90, y + 3, "#6e4a2c")
                c.rect(x, y - 8, x + 90, y - 6, "#5a3a22")
                stand += [(x + k, y + 2, True) for k in range(10, 90, 18)]
        for bx in (40, 260):
            c.rect(bx, 16, bx + 18, 70, "#e8e0c8")
            c.ellipse(bx + 9, 36, 5, 5, "#c9a24a")
    elif place == "Library":
        for sx in (10, 90, 200, 260):
            _shelf(c, sx, 16, 50 if sx != 260 else 52, 6, rng, books=True)
        _table(c, 140, 50, FLOOR_Y + 20, rng)
        _candle(c, 160, FLOOR_Y + 19, rng, lights)
        _candle(c, 172, FLOOR_Y + 19, rng, lights)
        stand += [(146, FLOOR_Y + 34, True), (184, FLOOR_Y + 34, True)] + \
            [(x, FLOOR_Y + 36 + rng.randint(0, 12), False) for x in range(20, 310, 30)]
    elif place == "Warehouse":
        for i in range(10):
            x = rng.randint(4, 300)
            stack = rng.randint(1, 3)
            for s in range(stack):
                (_crate if rng.random() < 0.6 else _barrel)(c, x, FLOOR_Y + 10 - s * 14)
        lights.append((160, 30, 50, "#ffc070", 0.6))
        c.rect(158, 10, 162, 30, "#3a3a3a")
        c.rect(154, 30, 166, 36, "#e0b860")
        stand += [(x, FLOOR_Y + 40 + rng.randint(0, 14), False) for x in range(20, 310, 30)]
    elif place == "Stable":
        for sx in range(10, 300, 70):
            c.rect(sx, FLOOR_Y - 40, sx + 3, FLOOR_Y + 30, "#6e4a2c")
            c.rect(sx, FLOOR_Y - 10, sx + 66, FLOOR_Y - 8, "#6e4a2c")
        for hx in (40, 180):
            c.ellipse(hx + 14, FLOOR_Y + 2, 16, 9, "#7a5232")
            c.ellipse(hx + 34, FLOOR_Y - 8, 6, 7, "#7a5232")
            c.rect(hx + 2, FLOOR_Y + 8, hx + 4, FLOOR_Y + 22, "#5a3a22")
            c.rect(hx + 24, FLOOR_Y + 8, hx + 26, FLOOR_Y + 22, "#5a3a22")
        for i in range(4):
            c.rect(110 + i * 9, FLOOR_Y + 14, 118 + i * 9, FLOOR_Y + 30, "#d8b850")
        lights.append((150, 30, 46, "#ffc070", 0.6))
        c.rect(148, 30, 152, 36, "#e0b860")
        stand += [(x, FLOOR_Y + 40 + rng.randint(0, 14), False) for x in range(20, 310, 30)]
    else:
        _window(c, 140, 26, 30, 34, spec.time, walls)
        _hearth(c, 240, rng, lights)
        _table(c, 100, 40, FLOOR_Y + 22, rng)
        stand += [(x, FLOOR_Y + 36 + rng.randint(0, 14), False) for x in range(20, 300, 30)]

    # Stone rooms with no fire of their own get a pair of wall torches.
    if walls in ("Stone", "Brick") and not lights and place in ("Tavern", "Inn", "Guild hall", "Town hall",
                                                                 "House", "Warehouse", "Stable"):
        for tx in (100, 220):
            _torch(c, tx, 50, rng, lights)
    _people(c, rng, n, stand)
    ambient = BRIGHT if (lights or spec.time != "Night") else DIM
    return Scene(c, lights, ambient, outdoor=False)


# ======================================================================
# Outdoors
# ======================================================================
SKIES = {
    "Morning": ("#86b8e8", "#f6d8b0"),
    "Day": ("#4f8fd8", "#b8dcf4"),
    "Dusk": ("#3a2a6a", "#f0904a"),
    "Night": ("#05081a", "#1a2448"),
}


def _sky(c: Canvas, time: str, rng: random.Random, horizon: int) -> None:
    top, bottom = SKIES.get(time, SKIES["Day"])
    _vgrad(c, 0, horizon, top, bottom)
    c.rect(0, horizon + 1, W - 1, H - 1, bottom)      # no gaps behind the land
    if time == "Night":
        for _ in range(90):
            x, y = rng.randrange(W), rng.randrange(horizon)
            c.set(x, y, mix("#ffffff", "#8090c0", rng.random() * 0.6))
        c.ellipse(250, 28, 9, 9, "#e8ecf4")
        c.ellipse(253, 26, 8, 8, top)
    elif time == "Dusk":
        c.ellipse(70, horizon - 6, 14, 14, "#ffb060")
        c.ellipse(70, horizon - 6, 10, 10, "#ffd890")
    else:
        sx, sy = (60, 40) if time == "Morning" else (240, 26)
        for r, a in ((16, 40), (11, 90)):
            c.ellipse(sx, sy, r, r, (255, 244, 200, a))
        c.ellipse(sx, sy, 7, 7, "#fff6d8")
        for _ in range(3):
            cx, cy = rng.randrange(W), rng.randrange(8, horizon // 2)
            for k in range(5):
                c.ellipse(cx + k * 7, cy + (2 if k % 2 else 0), 9, 4, (255, 255, 255, 170))


def _time_tint(col, time: str):
    if time == "Night":
        return mix(shift(col, -0.25), "#10183a", 0.55)
    if time == "Dusk":
        return mix(col, "#6a3a4a", 0.25)
    if time == "Morning":
        return mix(col, "#f0c8a0", 0.08)
    return hex_to_rgba(col)


def _tree(c: Canvas, x: int, base: int, h: int, col, rng: random.Random, pine: bool = False, dead: bool = False,
          snow: bool = False) -> None:
    trunk = shift(col, -0.3) if not dead else hex_to_rgba("#4a3a30")
    c.rect(x - max(1, h // 18), base - h // 3, x + max(1, h // 18), base, mix(trunk, "#4a3020", 0.5))
    if dead:
        c.rect(x - 1, base - h, x + 1, base, "#4a3a30")
        for k in range(3):
            yy = base - h + k * h // 4
            side = 1 if k % 2 else -1
            c.line(x, yy + 4, x + side * h // 4, yy - 2, "#4a3a30", width=1)
        return
    if pine:
        for i in range(5):
            t = i / 4
            w = h * (0.12 + 0.3 * t)
            yy = base - h + int(h * 0.82 * t)
            c.polygon([(x, yy - h * 0.18), (x - w, yy + h * 0.08), (x + w, yy + h * 0.08)],
                      shift(col, -0.03 * i))
            if snow:
                c.polygon([(x, yy - h * 0.18), (x - w * 0.5, yy - h * 0.04), (x + w * 0.5, yy - h * 0.04)], "#f0f4f8")
        return
    for k in range(6):
        ox = (rng.random() - 0.5) * h * 0.5
        oy = -h * 0.55 - rng.random() * h * 0.35
        r = h * (0.22 + rng.random() * 0.12)
        c.ellipse(x + ox, base + oy, r, r * 0.9, shift(col, (rng.random() - 0.5) * 0.08))
    c.ellipse(x - h * 0.08, base - h * 0.78, h * 0.16, h * 0.14, shift(col, 0.1))


def _paint_outdoor(spec: SceneSpec, rng: random.Random) -> Scene:
    c = Canvas(W, H)
    lights: list = []
    t = spec.time
    place = spec.place
    horizon = 104 if place not in ("Mountains", "Coast") else 96
    _sky(c, t, rng, horizon)
    tint = lambda col: _time_tint(col, t)  # noqa: E731

    if place == "Mountains":
        _ridge(c, rng, 80, 34, 0.02, tint("#7a8494"), jag=1.5)
        # snow on the peaks: lighten the top few rows of the far range
        rock = tint("#7a8494")[:3]
        for x in range(W):
            for y in range(H):
                p = c.get(x, y)
                if p is not None and p[:3] == rock:
                    if y < 66:
                        for k in range(min(6, 66 - y)):
                            c.set(x, y + k, tint("#eef2f6"))
                    break
        _ridge(c, rng, 116, 18, 0.03, tint("#5a6a5a"), jag=2)
        _ridge(c, rng, 140, 8, 0.05, tint("#4a6a3a"))
    elif place == "Hills":
        _ridge(c, rng, 100, 10, 0.015, tint("#7a9a8a"))
        _ridge(c, rng, 118, 14, 0.02, tint("#5a8a4a"))
        _ridge(c, rng, 142, 10, 0.03, tint("#4d7c3c"))
    elif place == "Desert":
        _ridge(c, rng, 108, 6, 0.012, tint("#d8b878"))
        _ridge(c, rng, 128, 10, 0.02, tint("#e0c088"))
        _ridge(c, rng, 150, 8, 0.03, tint("#e8cc94"))
        for _ in range(4):
            x = rng.randrange(20, 300)
            y = rng.randint(140, 170)
            c.rect(x, y - 16, x + 2, y, tint("#4a7a3a"))
            c.rect(x - 4, y - 12, x - 3, y - 6, tint("#4a7a3a"))
            c.rect(x - 4, y - 7, x, y - 6, tint("#4a7a3a"))
    elif place == "Arctic":
        _ridge(c, rng, 96, 18, 0.02, tint("#c8d4e0"), jag=2)
        _ridge(c, rng, 124, 8, 0.02, tint("#e6eef4"))
        for _ in range(16):
            x = rng.randrange(W)
            base = rng.randint(118, 170)
            _tree(c, x, base, rng.randint(18, 36), tint("#2e5a44"), rng, pine=True, snow=True)
    elif place == "Coast":
        c.rect(0, horizon, W - 1, 132, tint("#2d5f8a"))
        for y in range(horizon, 132, 3):
            for x in range(rng.randint(0, 9), W, rng.randint(12, 22)):
                c.rect(x, y, x + 4, y, tint("#5a8ab8"))
        for x in range(W):
            edge = 132 + int(math.sin(x * 0.07) * 3)
            for y in range(edge, H):
                c.set(x, y, tint("#d8c088") if y > edge + 2 else tint("#f0f4f8"))
        for _ in range(5):
            x = rng.randrange(W)
            c.shaded_ellipse(x, rng.randint(150, 172), rng.randint(5, 10), rng.randint(3, 6), tint("#7a766e"), steps=3)
        for _ in range(3):
            gx, gy = rng.randrange(40, 280), rng.randrange(20, 70)
            c.line(gx - 3, gy, gx, gy + 1, "#f0f0f0")
            c.line(gx, gy + 1, gx + 3, gy, "#f0f0f0")
    elif place == "Swamp":
        _ridge(c, rng, 104, 4, 0.02, tint("#3a4a3a"))
        c.rect(0, 120, W - 1, H - 1, tint("#3e4a32"))
        for _ in range(7):
            x, y, w = rng.randrange(W), rng.randint(126, 170), rng.randint(20, 60)
            c.ellipse(x, y, w, 4, tint("#2e3e3a"))
            c.line(x - w * 0.6, y, x + w * 0.2, y, tint("#4e5e5a"))
        for _ in range(7):
            _tree(c, rng.randrange(W), rng.randint(122, 160), rng.randint(30, 60), tint("#3a3a30"), rng, dead=True)
        for _ in range(30):
            x, y = rng.randrange(W), rng.randint(124, 178)
            c.rect(x, y - rng.randint(4, 9), x, y, tint("#6a7a3a"))
        for y in range(108, 140):
            for x in range(0, W, 2):
                c.put(x + (y % 2), y, (200, 210, 200, 22))
    elif place == "Town street":
        c.rect(0, 130, W - 1, H - 1, tint("#7d7a74"))
        for y in range(132, H, 5):
            for x in range((y // 5 % 2) * 4, W, 9):
                c.rect(x, y, x + 6, y + 3, tint(shift("#8a8680", (rng.random() - 0.5) * 0.1)))
        x = -10
        while x < W:
            w = rng.randint(54, 76)
            hgt = rng.randint(60, 90)
            wall = rng.choice(["#c8b89a", "#a88a6a", "#8a8680", "#b0a080", "#9a6a5a"])
            top = 130 - hgt
            c.rect(x, top, x + w, 130, tint(wall))
            for bx in range(x, x + w, 14):
                c.rect(bx, top, bx + 1, 130, tint(shift(wall, -0.12)))
            roof = rng.choice(["#6a3a2a", "#4a4a5a", "#7a5a3a"])
            c.polygon([(x - 4, top + 2), (x + w + 4, top + 2), (x + w // 2, top - 22)], tint(roof))
            c.rect(x + w // 2 - 5, 112, x + w // 2 + 5, 130, tint("#5a3a22"))
            for wx in (x + 8, x + w - 18):
                lit = t in ("Dusk", "Night") and rng.random() < 0.7
                c.rect(wx, top + 16, wx + 10, top + 30, "#ffd27a" if lit else tint("#3a4a6a"))
                c.rect(wx + 5, top + 16, wx + 5, top + 30, tint("#3a2a20"))
                if lit:
                    lights.append((wx + 5, top + 23, 22, "#ffc870", 0.45))
            x += w + rng.randint(2, 10)
        for lx in (60, 200):
            c.rect(lx, 96, lx + 1, 132, "#2a2a2e")
            c.rect(lx - 3, 92, lx + 4, 97, "#3a3a3e")
            c.rect(lx - 2, 93, lx + 3, 96, "#ffd890" if t in ("Dusk", "Night") else "#a8a4a0")
            if t in ("Dusk", "Night"):
                lights.append((lx, 94, 46, "#ffc870", 0.9))
        stand = [(x, 150 + rng.randint(0, 22), False) for x in range(14, 310, 18)]
        _people(c, rng, spec.people, stand, scale=1.3)
    else:  # Forest, Plains
        forest = place == "Forest"
        _ridge(c, rng, horizon, 6, 0.02, tint("#7a9aaa" if not forest else "#4a6a5a"))
        if forest:
            for layer, (col, base0, hmin, hmax) in enumerate(((tint("#2e5040"), 112, 40, 60),
                                                              (tint("#3a6a40"), 126, 50, 74),
                                                              (tint("#4a7a3a"), 150, 60, 90))):
                for _ in range(10 - layer * 2):
                    _tree(c, rng.randrange(-10, W + 10), base0 + rng.randint(0, 12), rng.randint(hmin, hmax),
                          col, rng, pine=rng.random() < 0.3)
                if layer == 0:
                    c.rect(0, 112, W - 1, H - 1, tint("#3e6a32"))
            c.rect(0, 160, W - 1, H - 1, tint("#3a6230"))
        else:
            c.rect(0, horizon, W - 1, H - 1, tint("#5a8a3a"))
            for _ in range(5):
                _tree(c, rng.randrange(W), horizon + rng.randint(2, 8), rng.randint(14, 22), tint("#3e6a3a"), rng)
            for y in range(horizon + 14, H, 4):
                for x in range(rng.randint(0, 6), W, 7):
                    c.rect(x, y, x, y + 2, tint("#6a9a44"))
            c.rect(0, 150, W - 1, 151, tint("#6e4a2c"))
            for fx in range(6, W, 24):
                c.rect(fx, 144, fx + 1, 156, tint("#6e4a2c"))
        for _ in range(60):
            x, y = rng.randrange(W), rng.randint(150, H - 1)
            c.set(x, y, tint("#7aa850"))
        stand = [(x, 166 + rng.randint(0, 8), False) for x in range(20, 300, 28)]
        _people(c, rng, spec.people, stand, scale=1.2)

    ambient = {"Morning": BRIGHT, "Day": BRIGHT, "Dusk": DIM, "Night": DARK}.get(t, BRIGHT)
    return Scene(c, lights, ambient, outdoor=True)


# ======================================================================
# Underground
# ======================================================================
def _paint_cave(spec: SceneSpec, rng: random.Random) -> Scene:
    c = Canvas(W, H)
    lights: list = []
    _vgrad(c, 0, H - 1, "#2a2622", "#3a342e")
    for x in range(W):
        top = int(10 + math.sin(x * 0.05) * 8 + rng.random() * 4)
        for y in range(top):
            c.set(x, y, "#1a1714")
    for _ in range(18):
        x = rng.randrange(W)
        h = rng.randint(8, 30)
        c.polygon([(x - 4, 10), (x + 4, 10), (x, 10 + h)], "#24201c")
    _ridge(c, rng, 150, 6, 0.04, "#4a443c")
    for _ in range(30):
        c.shaded_ellipse(rng.randrange(W), rng.randint(150, 178), rng.randint(3, 9), rng.randint(2, 5),
                         "#5a5248", steps=3)
    for _ in range(6):
        x, y = rng.randrange(10, 310), rng.randint(130, 172)
        col = rng.choice(["#5ad0f0", "#7af0a0", "#c07af0"])
        for k in range(3):
            c.polygon([(x + k * 4 - 2, y), (x + k * 4 + 2, y), (x + k * 4, y - rng.randint(6, 12))], col)
        lights.append((x + 4, y - 4, 26, col, 0.55))
    if spec.people:
        _people(c, rng, spec.people, [(x, 170, False) for x in range(30, 300, 30)])
    return Scene(c, lights, DARK, outdoor=False)


def _paint_dungeon(spec: SceneSpec, rng: random.Random) -> Scene:
    c = Canvas(W, H)
    lights: list = []
    _back_wall(c, "Stone", rng)
    for i in range(W * FLOOR_Y):
        p = c.px[i]
        if p is not None:
            c.px[i] = mix(p, "#1a1c24", 0.35)
    _floor(c, "Stone", rng)
    for ax in (40, 200):
        c.rect(ax, 30, ax + 60, FLOOR_Y, "#121216")
        c.ellipse(ax + 30, 34, 30, 16, "#121216")
        for k in range(0, 60, 10):
            c.rect(ax + k, 34, ax + k + 1, FLOOR_Y, "#2a2a30")
    for tx in (20, 150, 290):
        _torch(c, tx, 46, rng, lights)
    for _ in range(3):
        x = rng.randrange(20, 300)
        c.line(x, 0, x, rng.randint(20, 50), "#4a4a50", width=1)
    for _ in range(4):
        x = rng.randrange(20, 300)
        y = rng.randint(140, 170)
        c.line(x, y, x + 6, y - 2, "#e8e2cc", width=1)
        c.ellipse(x + 8, y - 2, 2, 2, "#e8e2cc")
    if spec.people:
        _people(c, rng, spec.people, [(x, FLOOR_Y + 40, False) for x in range(30, 300, 30)])
    return Scene(c, lights, DIM, outdoor=False)


# ======================================================================
@lru_cache(maxsize=48)
def _paint_cached(place: str, walls: str, people: int, time: str, seed: int) -> Scene:
    spec = SceneSpec(place, walls, people, time, seed)
    rng = random.Random(f"{place}|{walls}|{people}|{time}|{seed}")
    if place in INTERIOR_PLACES:
        return _paint_interior(spec, rng)
    if place == "Cave":
        return _paint_cave(spec, rng)
    if place == "Dungeon":
        return _paint_dungeon(spec, rng)
    return _paint_outdoor(spec, rng)


def paint(spec: SceneSpec) -> Scene:
    return _paint_cached(spec.place, spec.walls, max(0, min(14, int(spec.people))), spec.time, spec.seed)


# ======================================================================
# Light and darkness, applied to a finished scene
# ======================================================================
def lit(scene: Scene, darkvision: bool) -> Canvas:
    """The scene as the party sees it.

    Bright: unchanged. Dim (dusk, a dungeon between torches): darker, and
    pools of torchlight stand out. Dark: only what light sources reach is
    visible. With darkvision, dim areas look normal and dark areas are seen
    in shades of gray, as the SRD describes.
    """
    base = scene.canvas
    if scene.ambient == BRIGHT:
        return base
    out = Canvas(W, H)
    lights = [(lx, ly, r, hex_to_rgba(col), s) for lx, ly, r, col, s in scene.lights]
    for y in range(H):
        for x in range(W):
            p = base.px[y * W + x]
            if p is None:
                continue
            glow, warm = 0.0, None
            for lx, ly, radius, col, strength in lights:
                d = math.hypot(x - lx, y - ly)
                if d < radius:
                    g = ((1 - d / radius) ** 1.4) * min(1.0, strength + 0.35)
                    if g > glow:
                        glow, warm = g, col
            if warm is not None and glow > 0:
                lit_p = mix(p, warm, min(0.25, glow * 0.3))
            else:
                lit_p = p
            if scene.ambient == DIM:
                if darkvision:
                    out.px[y * W + x] = p
                    continue
                f = min(1.0, 0.5 + glow * 1.2)
                out.px[y * W + x] = (int(lit_p[0] * f), int(lit_p[1] * f), int(lit_p[2] * f), 255)
                continue
            # darkness
            f = min(1.0, glow * 1.7)
            if darkvision:
                g = int((p[0] * 0.3 + p[1] * 0.59 + p[2] * 0.11) * 0.62)
                grey = (g, g, g, 255)
                out.px[y * W + x] = mix(grey, lit_p, f)
            else:
                floor = (0.28, 0.3, 0.42) if scene.outdoor else (0.08, 0.08, 0.1)
                out.px[y * W + x] = tuple(int(lit_p[i] * max(floor[i], f)) for i in range(3)) + (255,)
    return out


def place_for_building_kind(kind: str) -> str:
    return {"Inn": "Inn", "Tavern": "Tavern", "Shop": "Shop", "Market": "Market", "Smithy": "Smithy",
            "Temple": "Temple", "Library": "Library", "House": "House", "Barracks": "Barracks",
            "Warehouse": "Warehouse", "Stable": "Stable", "Guild hall": "Guild hall",
            "Town hall": "Town hall"}.get(kind, "House")


def walls_for_interior(style: str) -> str:
    return {"Wooden": "Wooden", "Stone": "Stone", "Rich": "Rich", "Rustic": "Rustic", "Brick": "Brick"}.get(style, "Wooden")


@lru_cache(maxsize=32)
def lit_cached(place: str, walls: str, people: int, time: str, seed: int, darkvision: bool) -> Canvas:
    return lit(paint(SceneSpec(place, walls, people, time, seed)), darkvision)
