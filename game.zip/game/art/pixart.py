"""The drawing kit for the walking map's art: pixel art drawn at 16 art pixels to a square and doubled to the
game's 32, so the pixels are chunky and every one counts.

The house style (game/art/terrain.py and game/art/props.py follow it):
  * light from the top left; a lit cap on top of things, their undersides in shade;
  * outlines in a darker shade of the colour they edge, never black;
  * things sit on a soft, cool shadow;
  * warm in the light, cool in the shade (see shade()).
"""
from __future__ import annotations

import random
import zlib

from game.art.canvas import Canvas

ART = 16                     # art pixels per square
SCALE = 2                    # screen pixels per art pixel (32 / 16)


def rng(*key) -> random.Random:
    """The same random numbers every run for the same key."""
    return random.Random(zlib.crc32(repr(key).encode()))


def c(h, a: int = 255):
    """'#rrggbb' to a colour."""
    if not isinstance(h, str):
        return h
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def shade(col, k: float):
    """Lighter (k > 0) or darker (k < 0), leaning warm in the light and cool in the shade."""
    col = c(col)
    r, g, b = col[:3]
    if k >= 0:
        r, g, b = r + (255 - r) * k, g + (245 - g) * k, b + (215 - b) * k * 0.8
    else:
        k = -k
        r, g, b = r * (1 - k * 1.05), g * (1 - k), b * (1 - k * 0.8) + 18 * k
    return (max(0, min(255, int(r))), max(0, min(255, int(g))), max(0, min(255, int(b))), col[3])


def alpha(col, a: int):
    col = c(col)
    return (col[0], col[1], col[2], a)


class Px:
    """A picture drawn in art pixels; done() doubles it to screen pixels."""

    def __init__(self, w: int = ART, h: int = ART) -> None:
        self.w, self.h = int(w), int(h)
        self.px: list = [None] * (self.w * self.h)

    # ---- pixels ------------------------------------------------------
    def inside(self, x, y) -> bool:
        return 0 <= x < self.w and 0 <= y < self.h

    def p(self, x, y, col) -> None:
        x, y = int(x), int(y)
        if col is not None and 0 <= x < self.w and 0 <= y < self.h:
            self.px[y * self.w + x] = c(col)

    def clear(self, x, y) -> None:
        x, y = int(x), int(y)
        if 0 <= x < self.w and 0 <= y < self.h:
            self.px[y * self.w + x] = None

    def get(self, x, y):
        x, y = int(x), int(y)
        if 0 <= x < self.w and 0 <= y < self.h:
            return self.px[y * self.w + x]
        return None

    def put(self, x, y, col) -> None:
        """Blend a see-through colour over what's there."""
        x, y = int(x), int(y)
        if not (0 <= x < self.w and 0 <= y < self.h) or col is None:
            return
        col = c(col)
        under = self.px[y * self.w + x]
        if col[3] >= 255 or under is None:
            self.px[y * self.w + x] = col
            return
        a = col[3] / 255
        ua = under[3] / 255
        oa = a + ua * (1 - a)
        rgb = [int((col[i] * a + under[i] * ua * (1 - a)) / oa) for i in range(3)]
        self.px[y * self.w + x] = (rgb[0], rgb[1], rgb[2], int(oa * 255))

    # ---- shapes ------------------------------------------------------
    def rect(self, x0, y0, x1, y1, col) -> None:
        for y in range(int(y0), int(y1) + 1):
            for x in range(int(x0), int(x1) + 1):
                self.p(x, y, col)

    def hline(self, x0, x1, y, col) -> None:
        self.rect(x0, y, x1, y, col)

    def vline(self, x, y0, y1, col) -> None:
        self.rect(x, y0, x, y1, col)

    def disc(self, cx, cy, rx, ry, col) -> None:
        rx, ry = max(0.1, rx), max(0.1, ry)
        for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
            for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
                if ((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 <= 1:
                    self.p(x, y, col)

    def lit_disc(self, cx, cy, rx, ry, base, light: float = 0.22, dark: float = 0.28) -> None:
        """A rounded mass lit from the top left: shaded underside, body, light cap."""
        self.disc(cx, cy, rx, ry, shade(base, -dark))
        self.disc(cx - 0.4, cy - 0.5, rx - 0.6, ry - 0.7, base)
        self.disc(cx - rx * 0.35, cy - ry * 0.4, rx * 0.45, ry * 0.4, shade(base, light))

    def line(self, x0, y0, x1, y1, col) -> None:
        n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
        for i in range(n + 1):
            t = i / max(1, n)
            self.p(round(x0 + (x1 - x0) * t), round(y0 + (y1 - y0) * t), col)

    def poly(self, pts, col) -> None:
        """A filled polygon (even-odd), sampled at pixel centres."""
        ys = [p[1] for p in pts]
        for y in range(int(min(ys)), int(max(ys)) + 1):
            yc = y + 0.5
            xs = []
            for i in range(len(pts)):
                (ax, ay), (bx, by) = pts[i], pts[(i + 1) % len(pts)]
                if (ay <= yc < by) or (by <= yc < ay):
                    xs.append(ax + (yc - ay) * (bx - ax) / (by - ay))
            xs.sort()
            for a, b in zip(xs[::2], xs[1::2]):
                for x in range(int(round(a)), int(round(b))):
                    self.p(x, y, col)

    def shadow(self, cx, cy, rx, ry, a: int = 70) -> None:
        """A soft, cool shadow on the ground."""
        for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
            for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
                if ((x + 0.5 - cx) / rx) ** 2 + ((y + 0.5 - cy) / ry) ** 2 <= 1:
                    self.put(x, y, (30, 24, 40, a))

    def speckle(self, r: random.Random, n: int, cols, x0=0, y0=0, x1=None, y1=None, only_on=None) -> None:
        x1 = self.w - 1 if x1 is None else x1
        y1 = self.h - 1 if y1 is None else y1
        cols = [c(k) for k in cols]
        for _ in range(n):
            x, y = r.randint(int(x0), int(x1)), r.randint(int(y0), int(y1))
            if only_on is not None:
                here = self.get(x, y)
                if here is None or here[:3] != c(only_on)[:3]:
                    continue
            self.p(x, y, r.choice(cols))

    def blit(self, other: "Px", ox: int = 0, oy: int = 0) -> None:
        for y in range(other.h):
            for x in range(other.w):
                q = other.px[y * other.w + x]
                if q is not None:
                    self.put(x + ox, y + oy, q)

    def outline(self, darken: float = 0.5) -> None:
        """Trace every edge of the solid drawing in a darker shade of the colour beside it (soft shadows don't
        count as solid, and get traced over)."""
        src = self.px
        w, h = self.w, self.h
        solid = [q is not None and q[3] == 255 for q in src]
        out = list(src)
        for y in range(h):
            for x in range(w):
                i = y * w + x
                if solid[i]:
                    continue
                for dx, dy in ((0, 1), (1, 0), (-1, 0), (0, -1)):
                    xx, yy = x + dx, y + dy
                    if 0 <= xx < w and 0 <= yy < h and solid[yy * w + xx]:
                        out[i] = shade(src[yy * w + xx], -darken)
                        break
        self.px = out

    def map(self, fn) -> None:
        self.px = [None if q is None else fn(q) for q in self.px]

    def flipped(self) -> "Px":
        out = Px(self.w, self.h)
        for y in range(self.h):
            for x in range(self.w):
                out.px[y * self.w + x] = self.px[y * self.w + (self.w - 1 - x)]
        return out

    def rotated(self) -> "Px":
        """A quarter turn clockwise."""
        out = Px(self.h, self.w)
        for y in range(self.h):
            for x in range(self.w):
                out.px[x * out.w + (self.h - 1 - y)] = self.px[y * self.w + x]
        return out

    # ---- out ---------------------------------------------------------
    def done(self) -> Canvas:
        """Doubled to screen pixels."""
        out = Canvas(self.w * SCALE, self.h * SCALE)
        w = self.w
        rows = []
        for y in range(self.h):
            row = []
            for x in range(w):
                q = self.px[y * w + x]
                row.append(q)
                row.append(q)
            rows.append(row)
            rows.append(row)
        out.px = [q for row in rows for q in row]
        return out


def from_canvas(cv: Canvas) -> Px:
    """A screen-pixel canvas back to art pixels (its top-left pixel of each pair)."""
    out = Px(cv.w // SCALE, cv.h // SCALE)
    for y in range(out.h):
        for x in range(out.w):
            out.px[y * out.w + x] = cv.px[(y * SCALE) * cv.w + x * SCALE]
    return out


__all__ = ["Px", "ART", "SCALE", "rng", "c", "shade", "alpha", "from_canvas"]
