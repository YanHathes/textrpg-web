"""A tiny pixel canvas for drawing sprites in code, plus color helpers.

Pure Python (no Qt) so sprites can be generated, saved and tested anywhere.
Pixels are (r, g, b, a) tuples, or None for fully transparent.
Light in every sprite comes from the top-left (north-west).
"""
from __future__ import annotations

from itertools import chain as _chain

import base64
import colorsys
import math
import struct
import zlib
from typing import Iterable

RGBA = tuple[int, int, int, int]


# ======================================================================
# Colors
# ======================================================================
def hex_to_rgba(value, alpha: int = 255) -> RGBA:
    if isinstance(value, tuple):
        return value if len(value) == 4 else (*value, alpha)
    v = str(value).lstrip("#")
    if len(v) == 3:
        v = "".join(c * 2 for c in v)
    r, g, b = int(v[0:2], 16), int(v[2:4], 16), int(v[4:6], 16)
    a = int(v[6:8], 16) if len(v) >= 8 else alpha
    return (r, g, b, a)


def rgba_to_hex(c: RGBA, with_alpha: bool = False) -> str:
    s = f"#{c[0]:02x}{c[1]:02x}{c[2]:02x}"
    return s + f"{c[3]:02x}" if with_alpha else s


def clamp(v: float, lo: float = 0, hi: float = 255) -> int:
    return int(max(lo, min(hi, round(v))))


def mix(a, b, t: float) -> RGBA:
    a, b = hex_to_rgba(a), hex_to_rgba(b)
    return tuple(clamp(a[i] + (b[i] - a[i]) * t) for i in range(4))  # type: ignore[return-value]


def with_alpha(c, alpha: int) -> RGBA:
    c = hex_to_rgba(c)
    return (c[0], c[1], c[2], alpha)


def shift(c, light: float = 0.0, hue: float = 0.0, sat: float = 0.0) -> RGBA:
    """Lighten/darken with pixel-art hue shifting: shadows lean cool, highlights lean warm."""
    r, g, b, a = hex_to_rgba(c)
    h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
    l = max(0.0, min(1.0, l + light))
    s = max(0.0, min(1.0, s + sat))
    h = (h + hue) % 1.0
    r2, g2, b2 = colorsys.hls_to_rgb(h, l, s)
    return (clamp(r2 * 255), clamp(g2 * 255), clamp(b2 * 255), a)


def _toward(h: float, target: float, amount: float) -> float:
    d = ((target - h + 0.5) % 1.0) - 0.5
    return d * amount


def ramp(base, steps: int = 4, spread: float = 0.13) -> list[RGBA]:
    """Shading ramp from darkest to lightest around a base color (base sits at index 1)."""
    r, g, b, a = hex_to_rgba(base)
    h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
    out = []
    offsets = {1: [0], 2: [-1, 0], 3: [-1, 0, 1], 4: [-1, 0, 1, 2], 5: [-2, -1, 0, 1, 2]}[max(1, min(5, steps))]
    for o in offsets:
        if o < 0:
            hue = _toward(h, 0.68, 0.10 * -o)   # toward blue-violet
            out.append(shift(base, light=spread * o * (0.9 if l > 0.25 else 0.6), hue=hue, sat=0.04 * -o))
        elif o > 0:
            hue = _toward(h, 0.13, 0.07 * o)    # toward warm yellow
            out.append(shift(base, light=spread * o * 0.85, hue=hue, sat=-0.03 * o))
        else:
            out.append(hex_to_rgba(base))
    return out


def outline_color(c) -> RGBA:
    """Dark, slightly saturated version of a color for selective outlines."""
    r, g, b, a = hex_to_rgba(c)
    h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
    l2 = max(0.04, min(0.16, l * 0.32))
    r2, g2, b2 = colorsys.hls_to_rgb((h + _toward(h, 0.68, 0.15)) % 1.0, l2, min(1.0, s * 0.8 + 0.1))
    return (clamp(r2 * 255), clamp(g2 * 255), clamp(b2 * 255), 255)


# ======================================================================
# Canvas
# ======================================================================
class Canvas:
    def __init__(self, width: int, height: int | None = None) -> None:
        self.w = int(width)
        self.h = int(height if height is not None else width)
        self.px: list[RGBA | None] = [None] * (self.w * self.h)

    # ---- basic access --------------------------------------------------
    def inside(self, x: int, y: int) -> bool:
        return 0 <= x < self.w and 0 <= y < self.h

    def get(self, x: int, y: int) -> RGBA | None:
        if not self.inside(x, y):
            return None
        return self.px[y * self.w + x]

    def set(self, x: int, y: int, c) -> None:
        """Overwrite a pixel (no blending)."""
        x, y = int(x), int(y)
        if self.inside(x, y):
            self.px[y * self.w + x] = None if c is None else hex_to_rgba(c)

    def put(self, x: int, y: int, c) -> None:
        """Draw a pixel, blending if the color is translucent."""
        x, y = int(x), int(y)
        if not self.inside(x, y) or c is None:
            return
        c = hex_to_rgba(c)
        if c[3] >= 255:
            self.px[y * self.w + x] = c
            return
        if c[3] <= 0:
            return
        under = self.px[y * self.w + x]
        if under is None:
            self.px[y * self.w + x] = c
            return
        a = c[3] / 255
        out_a = a + under[3] / 255 * (1 - a)
        rgb = tuple(clamp((c[i] * a + under[i] * (under[3] / 255) * (1 - a)) / out_a) for i in range(3))
        self.px[y * self.w + x] = (*rgb, clamp(out_a * 255))

    def copy(self) -> "Canvas":
        c = Canvas(self.w, self.h)
        c.px = list(self.px)
        return c

    def opaque(self, x: int, y: int) -> bool:
        p = self.get(x, y)
        return p is not None and p[3] > 40

    # ---- shapes ----------------------------------------------------------
    def rect(self, x0, y0, x1, y1, c) -> None:
        for y in range(int(y0), int(y1) + 1):
            for x in range(int(x0), int(x1) + 1):
                self.put(x, y, c)

    def ellipse(self, cx, cy, rx, ry, c) -> None:
        for y, x in _ellipse_pixels(cx, cy, rx, ry):
            self.put(x, y, c)

    def circle(self, cx, cy, r, c) -> None:
        self.ellipse(cx, cy, r, r, c)

    def shaded_ellipse(self, cx, cy, rx, ry, base, steps: int = 4, light=(-0.55, -0.8),
                       highlight: bool = True, shade_bias: float = 0.0) -> None:
        """Ellipse shaded like a lit dome: light top-left, shadow bottom-right."""
        tones = ramp(base, steps)
        lx, ly = light
        norm = math.hypot(lx, ly)
        lx, ly = lx / norm, ly / norm
        for y, x in _ellipse_pixels(cx, cy, rx, ry):
            nx = (x + 0.5 - cx) / max(rx, 0.5)
            ny = (y + 0.5 - cy) / max(ry, 0.5)
            d2 = min(1.0, nx * nx + ny * ny)
            nz = math.sqrt(1 - d2)
            intensity = 0.55 * nz + 0.45 * (nx * lx + ny * ly) * 1.1 + shade_bias
            if intensity < -0.05:
                tone = 0
            elif intensity < 0.42:
                tone = 1
            elif intensity < 0.78 or not highlight:
                tone = 2 if steps > 2 else 1
            else:
                tone = 3 if steps > 3 else 2
            self.put(x, y, tones[min(tone, len(tones) - 1)])

    def line(self, x0, y0, x1, y1, c, width: float = 1.0) -> None:
        x0, y0, x1, y1 = float(x0), float(y0), float(x1), float(y1)
        steps = int(max(abs(x1 - x0), abs(y1 - y0)) * 2) + 1
        for i in range(steps + 1):
            t = i / steps
            x = x0 + (x1 - x0) * t
            y = y0 + (y1 - y0) * t
            if width <= 1.0:
                self.put(math.floor(x), math.floor(y), c)
            else:
                self._stamp(x, y, width / 2, c)

    def _stamp(self, x, y, r, c) -> None:
        for py in range(int(math.floor(y - r)), int(math.ceil(y + r)) + 1):
            for px in range(int(math.floor(x - r)), int(math.ceil(x + r)) + 1):
                if (px + 0.5 - x) ** 2 + (py + 0.5 - y) ** 2 <= r * r + 0.15:
                    self.put(px, py, c)

    def thick_line(self, x0, y0, x1, y1, c, width: float) -> None:
        self.line(x0, y0, x1, y1, c, width)

    def polygon(self, points: list[tuple[float, float]], c) -> None:
        if len(points) < 3:
            return
        ys = [p[1] for p in points]
        for y in range(int(math.floor(min(ys))), int(math.ceil(max(ys))) + 1):
            yc = y + 0.5
            xs = []
            for i in range(len(points)):
                (xa, ya), (xb, yb) = points[i], points[(i + 1) % len(points)]
                if (ya <= yc < yb) or (yb <= yc < ya):
                    xs.append(xa + (yc - ya) * (xb - xa) / (yb - ya))
            xs.sort()
            for i in range(0, len(xs) - 1, 2):
                for x in range(int(math.ceil(xs[i] - 0.5)), int(math.floor(xs[i + 1] - 0.5)) + 1):
                    self.put(x, y, c)

    # ---- whole-canvas operations -------------------------------------
    def blit(self, other: "Canvas", ox: int = 0, oy: int = 0) -> None:
        for y in range(other.h):
            for x in range(other.w):
                p = other.px[y * other.w + x]
                if p is not None:
                    self.put(x + ox, y + oy, p)

    def blit_under(self, other: "Canvas", ox: int = 0, oy: int = 0) -> None:
        """Draw `other` only where this canvas is empty."""
        for y in range(other.h):
            for x in range(other.w):
                p = other.px[y * other.w + x]
                if p is not None and self.get(x + ox, y + oy) is None:
                    self.set(x + ox, y + oy, p)

    def outline(self, color=None, diagonal: bool = False) -> None:
        """Add a 1px outline around every opaque area. color=None picks a dark
        version of each neighbor (selective outline)."""
        adds = []
        n4 = ((1, 0), (-1, 0), (0, 1), (0, -1))
        n8 = n4 + ((1, 1), (1, -1), (-1, 1), (-1, -1))
        for y in range(self.h):
            for x in range(self.w):
                if self.opaque(x, y):
                    continue
                best = None
                for dx, dy in (n8 if diagonal else n4):
                    p = self.get(x + dx, y + dy)
                    if p is not None and p[3] > 40:
                        if best is None or sum(p[:3]) < sum(best[:3]):
                            best = p
                if best is not None:
                    adds.append((x, y, color if color is not None else outline_color(best)))
        for x, y, c in adds:
            self.set(x, y, c)

    def inner_shadow_mask(self, mask: "Canvas", color, dx: int = 1, dy: int = 1) -> None:
        """Darken pixels of this canvas that `mask` covers when shifted by (dx, dy)."""
        for y in range(self.h):
            for x in range(self.w):
                if self.opaque(x, y) and mask.opaque(x - dx, y - dy):
                    self.put(x, y, color)

    def recolor(self, mapping: dict) -> "Canvas":
        m = {hex_to_rgba(k)[:3]: hex_to_rgba(v) for k, v in mapping.items()}
        out = self.copy()
        for i, p in enumerate(out.px):
            if p is not None and p[:3] in m:
                n = m[p[:3]]
                out.px[i] = (n[0], n[1], n[2], p[3])
        return out

    def tinted(self, color, strength: float = 0.35) -> "Canvas":
        c = hex_to_rgba(color)
        out = self.copy()
        for i, p in enumerate(out.px):
            if p is not None:
                out.px[i] = (*mix(p, c, strength)[:3], p[3])
        return out

    def rotated(self, quarter_turns: int) -> "Canvas":
        """Rotate clockwise in 90 degree steps (lossless)."""
        q = quarter_turns % 4
        out = self.copy()
        for _ in range(q):
            nxt = Canvas(out.h, out.w)
            for y in range(out.h):
                for x in range(out.w):
                    nxt.px[x * nxt.w + (out.h - 1 - y)] = out.px[y * out.w + x]
            out = nxt
        return out

    def flipped_h(self) -> "Canvas":
        out = Canvas(self.w, self.h)
        for y in range(self.h):
            for x in range(self.w):
                out.px[y * self.w + (self.w - 1 - x)] = self.px[y * self.w + x]
        return out

    def is_empty(self) -> bool:
        return all(p is None for p in self.px)

    def bbox(self) -> tuple[int, int, int, int] | None:
        xs = [i % self.w for i, p in enumerate(self.px) if p is not None]
        ys = [i // self.w for i, p in enumerate(self.px) if p is not None]
        if not xs:
            return None
        return min(xs), min(ys), max(xs), max(ys)

    # ---- serialization ---------------------------------------------------
    def to_rgba_bytes(self) -> bytes:
        clear = (0, 0, 0, 0)
        return bytes(_chain.from_iterable(clear if p is None else p for p in self.px))

    @classmethod
    def from_rgba_bytes(cls, w: int, h: int, data: bytes) -> "Canvas":
        c = cls(w, h)
        for i in range(w * h):
            r, g, b, a = data[i * 4:i * 4 + 4]
            c.px[i] = None if a == 0 else (r, g, b, a)
        return c

    def to_dict(self) -> dict:
        """Compact JSON form: a palette plus one string of palette characters per row."""
        palette: list[RGBA] = []
        index: dict[RGBA, int] = {}
        for p in self.px:
            if p is not None and p not in index:
                index[p] = len(palette)
                palette.append(p)
        if len(palette) <= len(_PALETTE_CHARS):
            rows = []
            for y in range(self.h):
                rows.append("".join("." if (p := self.px[y * self.w + x]) is None else _PALETTE_CHARS[index[p]]
                                    for x in range(self.w)))
            return {"w": self.w, "h": self.h, "palette": [rgba_to_hex(p, True) for p in palette], "rows": rows}
        return {"w": self.w, "h": self.h, "rgba": base64.b64encode(zlib.compress(self.to_rgba_bytes())).decode()}

    @classmethod
    def from_dict(cls, data: dict) -> "Canvas":
        w, h = int(data["w"]), int(data["h"])
        if "rgba" in data:
            return cls.from_rgba_bytes(w, h, zlib.decompress(base64.b64decode(data["rgba"])))
        palette = [hex_to_rgba(p) for p in data["palette"]]
        c = cls(w, h)
        for y, row in enumerate(data["rows"][:h]):
            for x, ch in enumerate(row[:w]):
                if ch != ".":
                    c.px[y * w + x] = palette[_PALETTE_CHARS.index(ch)]
        return c

    def to_png(self, scale: int = 1) -> bytes:
        """Encode as PNG without any imaging library."""
        w, h = self.w * scale, self.h * scale
        raw = bytearray()
        for y in range(h):
            raw.append(0)
            sy = y // scale
            for x in range(w):
                p = self.px[sy * self.w + x // scale]
                raw.extend(p if p is not None else (0, 0, 0, 0))

        def chunk(tag: bytes, data: bytes) -> bytes:
            return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

        return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b""))


_PALETTE_CHARS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!#$%&*+-/:;<=>?@^_~"


def _ellipse_pixels(cx, cy, rx, ry) -> Iterable[tuple[int, int]]:
    rx = max(rx, 0.5)
    ry = max(ry, 0.5)
    for y in range(int(math.floor(cy - ry)), int(math.ceil(cy + ry)) + 1):
        for x in range(int(math.floor(cx - rx)), int(math.ceil(cx + rx)) + 1):
            nx = (x + 0.5 - cx) / rx
            ny = (y + 0.5 - cy) / ry
            if nx * nx + ny * ny <= 1.0:
                yield y, x
