"""The look of every window, button and panel: pixel art in the spirit of a cosy farming game, with a
medieval air. Wooden frames round parchment, plank buttons with nail heads, iron corner brackets, red cloth
banners for titles, wax seals, an iron gauntlet for a pointer.

Every piece is drawn here in art pixels and saved as a PNG at a whole-number scale (one art pixel = 2 or
3 screen pixels), so the stylesheet (ui/theme.py) can stretch it as a nine-slice border image: the corners
stay put, the edges repeat along. Nothing here needs Qt.

    write(folder, scale) -> {name: (path, border in screen pixels)}
"""
from __future__ import annotations

import struct
import zlib
from pathlib import Path

VERSION = 6

# ---------------------------------------------------------------- the palette
INK = (58, 33, 20)
WOOD_DD = (92, 46, 22)
WOOD_D = (122, 62, 28)
WOOD = (176, 98, 45)
WOOD_L = (214, 140, 72)
WOOD_HI = (236, 178, 104)
PAPER_HI = (255, 246, 214)
PAPER = (250, 230, 182)
PAPER_D = (232, 202, 146)
PAPER_DD = (214, 178, 118)
TEXT = (74, 43, 24)
IRON_D = (52, 54, 62)
IRON = (86, 88, 98)
IRON_L = (150, 154, 166)
IRON_HI = (205, 210, 220)
GOLD = (238, 190, 70)
GOLD_D = (176, 120, 34)
GOLD_HI = (255, 230, 140)
RED = (150, 40, 36)
RED_D = (98, 24, 26)
RED_L = (196, 70, 56)
GREEN = (86, 140, 62)
GREEN_D = (52, 96, 40)
BLUE = (64, 110, 186)
BLUE_D = (38, 66, 130)
PURPLE = (124, 84, 168)
PURPLE_D = (78, 50, 116)
NIGHT = (34, 24, 18)
NIGHT_L = (52, 38, 28)
CLEAR = (0, 0, 0, 0)
BTN = (158, 84, 36)            # a button's face: dark enough that cream lettering stands out on it
BTN_HOVER = (182, 102, 46)


class Img:
    """A small RGBA picture, drawn pixel by pixel."""

    def __init__(self, w: int, h: int, fill=CLEAR) -> None:
        self.w, self.h = w, h
        self.px = [self._c(fill)] * (w * h)

    @staticmethod
    def _c(c):
        return tuple(c) if len(c) == 4 else tuple(c) + (255,)

    def set(self, x: int, y: int, c) -> None:
        if 0 <= x < self.w and 0 <= y < self.h:
            self.px[y * self.w + x] = self._c(c)

    def get(self, x: int, y: int):
        return self.px[y * self.w + x] if 0 <= x < self.w and 0 <= y < self.h else CLEAR

    def rect(self, x0: int, y0: int, x1: int, y1: int, c) -> None:
        """Fill x0..x1, y0..y1 (both ends included)."""
        c = self._c(c)
        for y in range(max(0, min(y0, y1)), min(self.h, max(y0, y1) + 1)):
            for x in range(max(0, min(x0, x1)), min(self.w, max(x0, x1) + 1)):
                self.px[y * self.w + x] = c

    def outline(self, x0: int, y0: int, x1: int, y1: int, c) -> None:
        self.rect(x0, y0, x1, y0, c)
        self.rect(x0, y1, x1, y1, c)
        self.rect(x0, y0, x0, y1, c)
        self.rect(x1, y0, x1, y1, c)

    def scaled(self, k: int) -> "Img":
        out = Img(self.w * k, self.h * k)
        for y in range(self.h):
            row = self.px[y * self.w:(y + 1) * self.w]
            big = [p for p in row for _ in range(k)]
            for dy in range(k):
                out.px[(y * k + dy) * out.w:(y * k + dy + 1) * out.w] = big
        return out

    def rotated(self) -> "Img":
        """A quarter turn clockwise (a vertical piece made into a horizontal one)."""
        out = Img(self.h, self.w)
        for y in range(self.h):
            for x in range(self.w):
                out.set(self.h - 1 - y, x, self.get(x, y))
        return out

    def png(self) -> bytes:
        raw = b"".join(b"\x00" + bytes(v for p in self.px[y * self.w:(y + 1) * self.w] for v in p)
                       for y in range(self.h))

        def chunk(kind, data):
            return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
        return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", self.w, self.h, 8, 6, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def _grain(im: Img, x0, y0, x1, y1, col, every: int = 23) -> None:
    for y in range(y0, y1 + 1, 3):
        for x in range(x0, x1 + 1):
            if (x * 7 + y * 13) % every == 0:
                im.rect(x, y, min(x1, x + 2), y, col)


def _bracket(im: Img, cx: int, cy: int, sx: int, sy: int) -> None:
    """An iron corner bracket with three rivets."""
    for k in range(6):
        for t in range(3):
            im.set(cx + sx * k, cy + sy * t, IRON)
            im.set(cx + sx * t, cy + sy * k, IRON)
    for k in range(6):
        im.set(cx + sx * k, cy, IRON_L)
        im.set(cx, cy + sy * k, IRON_L)
    for (a, b) in ((1, 1), (4, 1), (1, 4)):
        im.set(cx + sx * a, cy + sy * b, IRON_HI)


# ---------------------------------------------------------------- the pieces
def frame(inner=PAPER, brackets: bool = True, size: int = 32) -> Img:
    """A chunky wooden frame round a panel (parchment, or dark for the map's overlays)."""
    s = size
    im = Img(s, s, WOOD)
    e = s - 1
    im.outline(0, 0, e, e, INK)
    im.rect(1, 1, e - 1, 1, WOOD_HI)
    im.rect(1, 1, 1, e - 1, WOOD_L)
    im.rect(1, e - 1, e - 1, e - 1, WOOD_D)
    im.rect(e - 1, 1, e - 1, e - 1, WOOD_D)
    _grain(im, 2, 3, e - 2, e - 3, WOOD_D)
    t = 6
    im.outline(t - 1, t - 1, e - t + 1, e - t + 1, WOOD_D)
    im.outline(t, t, e - t, e - t, INK)
    im.rect(t + 1, t + 1, e - t - 1, e - t - 1, inner)
    if inner == PAPER:
        im.rect(t + 1, t + 1, e - t - 1, t + 1, PAPER_DD)
        im.rect(t + 1, t + 1, t + 1, e - t - 1, PAPER_D)
    else:
        im.rect(t + 1, t + 1, e - t - 1, t + 1, NIGHT_L)
    if brackets:
        _bracket(im, 0, 0, 1, 1)
        _bracket(im, e, 0, -1, 1)
        _bracket(im, 0, e, 1, -1)
        _bracket(im, e, e, -1, -1)
    return im


def thin_frame(inner=PAPER) -> Img:
    """A slimmer wooden frame (chat box, prompts, portraits, map labels)."""
    im = Img(16, 16, WOOD)
    im.outline(0, 0, 15, 15, INK)
    im.rect(1, 1, 14, 1, WOOD_HI)
    im.rect(1, 1, 1, 14, WOOD_L)
    im.rect(1, 14, 14, 14, WOOD_D)
    im.rect(14, 1, 14, 14, WOOD_D)
    im.outline(3, 3, 12, 12, INK)
    im.rect(4, 4, 11, 11, inner)
    if inner == PAPER:
        im.rect(4, 4, 11, 4, PAPER_DD)
    for x, y in ((2, 2), (13, 2), (2, 13), (13, 13)):
        im.set(x, y, IRON_L)
    return im


def card(fill=PAPER, edge=INK, hi=PAPER_HI, lo=PAPER_DD) -> Img:
    """A parchment card: inked edge, light top-left, shaded bottom-right."""
    im = Img(12, 12, fill)
    im.outline(0, 0, 11, 11, edge)
    im.rect(1, 1, 10, 1, hi)
    im.rect(1, 1, 1, 10, hi)
    im.rect(1, 10, 10, 10, lo)
    im.rect(10, 1, 10, 10, lo)
    for x, y in ((0, 0), (11, 0), (0, 11), (11, 11)):
        im.set(x, y, CLEAR)
    im.set(1, 1, edge)
    im.set(10, 1, edge)
    im.set(1, 10, edge)
    im.set(10, 10, edge)
    return im


def inset(edge=INK) -> Img:
    """A text box: parchment pressed into the page."""
    im = Img(12, 12, PAPER_HI)
    im.outline(0, 0, 11, 11, edge)
    im.rect(1, 1, 10, 2, PAPER_DD)
    im.rect(1, 1, 2, 10, PAPER_D)
    im.rect(3, 3, 10, 3, PAPER)
    return im


def plank(face=WOOD, hi=WOOD_HI, lo=WOOD_D, trim=None, pressed: bool = False, nails: bool = True) -> Img:
    """A plank button: inked edge, lit top, dark underside (only its rim is fixed; the face stretches to fit
    any text, so the label is never squeezed)."""
    im = Img(24, 14, face)
    im.outline(0, 0, 23, 13, INK)
    for x, y in ((0, 0), (23, 0), (0, 13), (23, 13)):
        im.set(x, y, CLEAR)
    if pressed:
        im.rect(1, 1, 22, 1, lo)
        im.rect(1, 12, 22, 12, hi)
    else:
        im.rect(1, 1, 22, 1, hi)
        im.rect(1, 11, 22, 12, lo)
    im.rect(1, 2, 1, 10, hi if not pressed else lo)
    im.rect(22, 2, 22, 10, lo if not pressed else hi)
    if trim is not None:
        im.outline(1, 1, 22, 12, trim)
        im.rect(2, 2, 21, 2, GOLD_HI if trim == GOLD else trim)
    return im


def tab(selected: bool = False, hover: bool = False) -> Img:
    """A tab: a wooden tag, or (chosen) parchment running into the page below."""
    im = Img(16, 12, PAPER if selected else (BTN_HOVER if hover else BTN))
    im.rect(0, 0, 15, 0, INK)
    im.rect(0, 0, 0, 11, INK)
    im.rect(15, 0, 15, 11, INK)
    im.set(0, 0, CLEAR)
    im.set(15, 0, CLEAR)
    if selected:
        im.rect(1, 1, 14, 1, PAPER_HI)
        im.rect(1, 1, 1, 11, PAPER_HI)
    else:
        im.rect(1, 1, 14, 1, WOOD_HI)
        im.rect(0, 11, 15, 11, INK)
        im.rect(1, 10, 14, 10, WOOD_D)
    return im


def checkbox(on: bool, hover: bool = False) -> Img:
    im = Img(9, 9, PAPER_HI)
    im.outline(0, 0, 8, 8, GOLD_D if hover else INK)
    im.rect(1, 1, 7, 1, PAPER_DD)
    im.rect(1, 1, 1, 7, PAPER_D)
    if on:                                            # a red mark, like a quill's tick
        for x, y in ((2, 4), (3, 5), (4, 6), (5, 5), (5, 4), (6, 3), (6, 2), (7, 1)):
            im.set(x, y, RED)
        for x, y in ((2, 5), (3, 6), (4, 7), (5, 6), (6, 4), (7, 2)):
            im.set(x, y, RED_D)
    return im


def radio(on: bool, hover: bool = False) -> Img:
    im = Img(9, 9)
    edge = GOLD_D if hover else INK
    rows = ["..#####..", ".#ppppp#.", "#ppppppp#", "#ppppppp#", "#ppppppp#", "#ppppppp#", "#ppppppp#",
            ".#ppppp#.", "..#####.."]
    for y, row in enumerate(rows):
        for x, v in enumerate(row):
            if v == "#":
                im.set(x, y, edge)
            elif v == "p":
                im.set(x, y, PAPER_HI if y > 2 else PAPER_D)
    if on:
        im.rect(3, 3, 5, 5, RED)
        im.set(3, 3, RED_L)
        im.set(5, 5, RED_D)
    return im


def groove(w: int = 12, h: int = 6) -> Img:
    """A dark channel (scroll bars, progress bars, sliders)."""
    im = Img(w, h, NIGHT)
    im.outline(0, 0, w - 1, h - 1, INK)
    im.rect(1, 1, w - 2, 1, (24, 16, 12))
    im.rect(1, h - 2, w - 2, h - 2, NIGHT_L)
    return im


def fill(col, dark) -> Img:
    """The coloured part of a bar: lit top, dark bottom."""
    im = Img(6, 6, col)
    im.outline(0, 0, 5, 5, INK)
    light = tuple(min(255, c + 60) for c in col)
    im.rect(1, 1, 4, 1, light)
    im.rect(1, 4, 4, 4, dark)
    return im


def handle_v(hover: bool = False) -> Img:
    """A scroll bar's wooden thumb (upright)."""
    im = Img(8, 16, WOOD_L if hover else WOOD)
    im.outline(0, 0, 7, 15, INK)
    for x, y in ((0, 0), (7, 0), (0, 15), (7, 15)):
        im.set(x, y, CLEAR)
    im.rect(1, 1, 6, 1, WOOD_HI)
    im.rect(1, 1, 1, 14, WOOD_HI)
    im.rect(6, 1, 6, 14, WOOD_D)
    im.rect(1, 14, 6, 14, WOOD_D)
    for y in (6, 8, 10):
        im.rect(2, y - 1, 5, y - 1, WOOD_D)
    return im


def knob(hover: bool = False) -> Img:
    """A slider's iron knob."""
    im = Img(8, 12, IRON_L if hover else IRON)
    im.outline(0, 0, 7, 11, INK)
    for x, y in ((0, 0), (7, 0), (0, 11), (7, 11)):
        im.set(x, y, CLEAR)
    im.rect(1, 1, 6, 1, IRON_HI)
    im.rect(1, 1, 1, 10, IRON_HI if hover else IRON_L)
    im.rect(1, 10, 6, 10, IRON_D)
    im.rect(3, 4, 4, 7, IRON_D)
    return im


def banner() -> Img:
    """A red cloth banner with gold trim and swallow tails (titles and name plates)."""
    w, h = 28, 15
    im = Img(w, h)
    mid = h // 2
    for y in range(h):
        notch = abs(y - mid)
        inset_ = max(0, 4 - notch) if True else 0          # the swallow tail cut into each end
        for x in range(w):
            if x < inset_ or x > w - 1 - inset_:
                continue
            im.set(x, y, RED)
        im.set(inset_, y, INK)
        im.set(w - 1 - inset_, y, INK)
    im.rect(0, 0, w - 1, 0, INK)
    im.rect(0, h - 1, w - 1, h - 1, INK)
    im.rect(5, 2, w - 6, 2, GOLD)
    im.rect(5, h - 3, w - 6, h - 3, GOLD_D)
    im.rect(5, 3, w - 6, 3, RED_L)
    im.rect(5, h - 4, w - 6, h - 4, RED_D)
    for x in (5, w - 6):
        im.rect(x, 2, x, h - 3, GOLD_D)
    return im


def plaque() -> Img:
    """A small wooden plaque (a panel's name, a section)."""
    im = Img(16, 11, WOOD)
    im.outline(0, 0, 15, 10, INK)
    for x, y in ((0, 0), (15, 0), (0, 10), (15, 10)):
        im.set(x, y, CLEAR)
    im.rect(1, 1, 14, 1, WOOD_HI)
    im.rect(1, 9, 14, 9, WOOD_D)
    im.set(2, 5, IRON_HI)
    im.set(13, 5, IRON_HI)
    return im


def close_button(hover: bool = False) -> Img:
    im = Img(11, 11, RED if hover else IRON)
    im.outline(0, 0, 10, 10, INK)
    im.rect(1, 1, 9, 1, RED_L if hover else IRON_L)
    im.rect(1, 9, 9, 9, RED_D if hover else IRON_D)
    for k in range(5):
        for x, y in ((3 + k, 3 + k), (7 - k, 3 + k)):
            im.set(x, y, PAPER_HI)
            im.set(x + 1 if x < 9 else x, y, PAPER_HI if k in (0, 4) else PAPER_D)
    return im


def arrow(direction: str, col=INK) -> Img:
    rows = {"down": ["#######", ".#####.", "..###..", "...#..."], "up": ["...#...", "..###..", ".#####.", "#######"],
            "right": ["#...", "##..", "###.", "####", "###.", "##..", "#..."],
            "left": ["...#", "..##", ".###", "####", ".###", "..##", "...#"]}[direction]
    im = Img(len(rows[0]), len(rows))
    for y, row in enumerate(rows):
        for x, v in enumerate(row):
            if v == "#":
                im.set(x, y, col)
    return im


def wood_planks() -> Img:
    """Dark floorboards to tile behind everything (the main window, full-screen menus)."""
    w, h = 32, 24
    im = Img(w, h, (70, 40, 24))
    for row in range(3):
        y0 = row * 8
        im.rect(0, y0, w - 1, y0, (40, 22, 14))
        im.rect(0, y0 + 1, w - 1, y0 + 1, (92, 54, 32))
        off = (row * 11) % w
        for x in (off, (off + 16) % w):
            im.rect(x, y0 + 1, x, y0 + 7, (40, 22, 14))
            im.set((x + 1) % w, y0 + 3, (110, 112, 120))
        for x in range(w):
            if (x * 5 + row * 7) % 13 == 0:
                im.set(x, y0 + 4, (58, 32, 20))
            if (x * 3 + row * 11) % 17 == 0:
                im.set(x, y0 + 6, (82, 48, 28))
    return im


def divider() -> Img:
    """A ruled line with a little diamond in the middle of each stretch."""
    im = Img(16, 5)
    im.rect(0, 2, 15, 2, PAPER_DD)
    im.rect(0, 3, 15, 3, PAPER_HI)
    im.set(7, 1, GOLD_D)
    im.set(6, 2, GOLD_D)
    im.set(8, 2, GOLD_D)
    im.set(7, 3, GOLD_D)
    im.set(7, 2, GOLD)
    return im


def gauntlet(point: bool = True) -> Img:
    """The mouse pointer: an iron gauntlet (pointing, for things you can click)."""
    rows = (["..##........", ".#ii#.......", ".#iI#.......", ".#ii###.....", ".#iI#ii##...", "##ii#iI#i#..",
             "#ii#iiiiiI#.", "#iiiiiiiiI#.", ".#iiiiiiii#.", "..#iiiiiI#..", "...#iiiii#..", "...#######.."]
            if point else
            ["#...........", "##..........", "#i#.........", "#ii#........", "#iI##.......", "#iiiI#......",
             "#iiiiI#.....", "#iiiiii#....", "#iiii####...", "#i#ii#......", "##.#ii#.....", "....##......"])
    im = Img(12, 12)
    for y, row in enumerate(rows):
        for x, v in enumerate(row):
            c = {"#": INK, "i": IRON_L, "I": IRON_HI}.get(v)
            if c is not None:
                im.set(x, y, c)
    return im


def seal() -> Img:
    """A red wax seal with ribbon tails (a notice's mark)."""
    im = Img(13, 17)
    for y in range(13):
        for x in range(13):
            d = (x - 6) ** 2 + (y - 6) ** 2
            if d <= 36:
                im.set(x, y, INK if d > 25 else (RED_L if d <= 9 else RED))
    for x, y in ((5, 5), (7, 5), (6, 6), (5, 7), (7, 7)):
        im.set(x, y, RED_D)
    for k in range(5):
        im.set(4 - k // 2, 12 + k, RED_D)
        im.set(8 + k // 2, 12 + k, RED_D)
    return im


# ---------------------------------------------------------------- the set
def pieces() -> dict:
    """name -> (picture, nine-slice border in art pixels: (top, right, bottom, left))."""
    p = {
        "frame": (frame(), (8, 8, 8, 8)),
        "frame_plain": (frame(brackets=False), (8, 8, 8, 8)),
        "frame_dark": (frame(NIGHT, brackets=True), (8, 8, 8, 8)),
        "thin": (thin_frame(), (5, 5, 5, 5)),
        "thin_dark": (thin_frame(NIGHT), (5, 5, 5, 5)),
        "card": (card(), (3, 3, 3, 3)),
        "card_hover": (card(edge=GOLD_D), (3, 3, 3, 3)),
        "card_on": (card(fill=(255, 238, 196), edge=GOLD_D, hi=GOLD_HI), (3, 3, 3, 3)),
        "card_dark": (card(fill=NIGHT, edge=INK, hi=NIGHT_L, lo=(24, 16, 12)), (3, 3, 3, 3)),
        "inset": (inset(), (4, 3, 3, 4)),
        "inset_focus": (inset(GOLD_D), (4, 3, 3, 4)),
        "button": (plank(BTN, WOOD_L, WOOD_D), (3, 3, 3, 3)),
        "button_hover": (plank(BTN_HOVER, WOOD_HI, WOOD_D), (3, 3, 3, 3)),
        "button_pressed": (plank(WOOD_D, WOOD_HI, WOOD_DD, pressed=True), (3, 3, 3, 3)),
        "button_disabled": (plank((150, 130, 112), (178, 164, 148), (112, 98, 86), nails=False), (3, 3, 3, 3)),
        "button_primary": (plank(BTN, WOOD_L, WOOD_D, trim=GOLD), (3, 3, 3, 3)),
        "button_primary_hover": (plank(BTN_HOVER, WOOD_HI, WOOD_D, trim=GOLD), (3, 3, 3, 3)),
        "button_danger": (plank(RED, RED_L, RED_D), (3, 3, 3, 3)),
        "button_danger_hover": (plank(RED_L, (230, 120, 100), RED), (3, 3, 3, 3)),
        "button_on": (plank(GREEN, (140, 190, 100), GREEN_D, trim=GOLD), (3, 3, 3, 3)),
        "tab": (tab(), (4, 5, 3, 5)),
        "tab_hover": (tab(hover=True), (4, 5, 3, 5)),
        "tab_selected": (tab(True), (4, 5, 2, 5)),
        "check": (checkbox(False), None),
        "check_hover": (checkbox(False, True), None),
        "check_on": (checkbox(True), None),
        "radio": (radio(False), None),
        "radio_hover": (radio(False, True), None),
        "radio_on": (radio(True), None),
        "groove": (groove(), (2, 2, 2, 2)),
        "groove_v": (groove(6, 12), (2, 2, 2, 2)),
        "handle_v": (handle_v(), (4, 3, 4, 3)),
        "handle_v_hover": (handle_v(True), (4, 3, 4, 3)),
        "handle_h": (handle_v().rotated(), (3, 4, 3, 4)),
        "handle_h_hover": (handle_v(True).rotated(), (3, 4, 3, 4)),
        "knob": (knob(), None),
        "knob_hover": (knob(True), None),
        "bar_green": (fill(GREEN, GREEN_D), (2, 2, 2, 2)),
        "bar_red": (fill((206, 48, 44), (140, 24, 24)), (2, 2, 2, 2)),
        "bar_blue": (fill(BLUE, BLUE_D), (2, 2, 2, 2)),
        "bar_purple": (fill(PURPLE, PURPLE_D), (2, 2, 2, 2)),
        "bar_gold": (fill(GOLD, GOLD_D), (2, 2, 2, 2)),
        "bar_orange": (fill((222, 140, 50), (160, 90, 30)), (2, 2, 2, 2)),
        "banner": (banner(), (0, 6, 0, 6)),
        "plaque": (plaque(), (3, 4, 3, 4)),
        "close": (close_button(), None),
        "close_hover": (close_button(True), None),
        "arrow_down": (arrow("down"), None),
        "arrow_up": (arrow("up"), None),
        "arrow_right": (arrow("right"), None),
        "arrow_left": (arrow("left"), None),
        "arrow_down_light": (arrow("down", PAPER_HI), None),
        "planks": (wood_planks(), None),
        "divider": (divider(), (0, 0, 0, 0)),
        "pointer": (gauntlet(False), None),
        "point": (gauntlet(True), None),
        "seal": (seal(), None),
    }
    return p


def write(folder: Path, scale: int = 2) -> dict:
    """Save every piece at this scale. Returns {name: (path, border in screen pixels or None)}."""
    folder = Path(folder) / f"v{VERSION}-x{scale}"
    folder.mkdir(parents=True, exist_ok=True)
    out = {}
    for name, (im, border) in pieces().items():
        path = folder / f"{name}.png"
        if not path.exists():
            tmp = path.with_suffix(".tmp")
            tmp.write_bytes(im.scaled(scale).png())
            tmp.replace(path)
        out[name] = (path, tuple(b * scale for b in border) if border else None)
    return out


__all__ = ["pieces", "write", "Img", "VERSION"]
