"""Gear drawn over humanoid bodies: armor, helmets, cloaks, shields and weapons.

Each piece draws into named layers using the body's Frame, so the same gear
fits a halfling, a dwarf or a hill giant. Gear can also be drawn on its own
as an inventory icon.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from game.art.canvas import Canvas, hex_to_rgba, mix, ramp, shift, with_alpha
from game.art.humanoid import Frame

STEEL = "#a7b1ba"
DARK_STEEL = "#6c7680"
IRON = "#7d858c"
BRASS = "#c9a24a"
GOLD = "#e0b84a"
WOOD = "#8a5a32"
DARK_WOOD = "#5e3b22"
LEATHER = "#7a5232"
DARK_LEATHER = "#4e3420"
CLOTH = "#cbb48a"


# ======================================================================
# Armor
# ======================================================================
@dataclass(frozen=True)
class ArmorStyle:
    id: str
    label: str
    pattern: str            # how the torso surface looks
    base: str               # main color
    sleeves: str            # sleeve color
    sleeve_pattern: str = "plain"
    pauldrons: float = 0.0  # 0 = none, otherwise size
    helmet: str = ""        # helmet drawn with this armor
    gauntlets: bool = False
    trim: str = ""
    category: str = "Armor"


ARMOR_STYLES: dict[str, ArmorStyle] = {a.id: a for a in [
    ArmorStyle("padded", "Padded", "quilted", "#cbb48a", "#bba378"),
    ArmorStyle("leather", "Leather", "leather", LEATHER, "#6a462a", trim=DARK_LEATHER),
    ArmorStyle("studded_leather", "Studded Leather", "studded", "#6e4a2e", "#5e3e26", trim=DARK_LEATHER),
    ArmorStyle("hide", "Hide", "hide", "#8a7356", "#7a6448", trim="#c2ad8a"),
    ArmorStyle("chain_shirt", "Chain Shirt", "chain", STEEL, "#5d6b4e", trim=DARK_LEATHER),
    ArmorStyle("scale_mail", "Scale Mail", "scale", "#b08d4e", "#9c7c42", sleeve_pattern="scale"),
    ArmorStyle("breastplate", "Breastplate", "plate", "#b9c3cc", "#6a5a48", trim=BRASS),
    ArmorStyle("half_plate", "Half Plate", "plate", "#b3bdc6", "#8e98a2", sleeve_pattern="plate",
               pauldrons=2.6, trim=BRASS),
    ArmorStyle("ring_mail", "Ring Mail", "rings", "#6e4c32", "#62442c", sleeve_pattern="rings"),
    ArmorStyle("chain_mail", "Chain Mail", "chain", "#9ea8b1", "#9ea8b1", sleeve_pattern="chain",
               helmet="coif"),
    ArmorStyle("splint", "Splint", "splint", "#9aa4ad", "#8a949d", sleeve_pattern="plate", pauldrons=2.4,
               helmet="kettle", trim=DARK_LEATHER),
    ArmorStyle("plate", "Plate", "plate", "#c4ced6", "#b0bac3", sleeve_pattern="plate", pauldrons=3.2,
               helmet="great_helm", gauntlets=True, trim=GOLD),
    # Clothing (not armor in the rules, but worn on the body)
    ArmorStyle("robe", "Robe", "robe", "#3f4f8a", "#3f4f8a", trim="#d8c070", category="Clothing"),
    ArmorStyle("tunic", "Tunic", "cloth", "#5b6b4e", "#4f5e44", category="Clothing"),
    ArmorStyle("noble", "Fine Clothes", "noble", "#7a2a3a", "#6a2232", trim=GOLD, category="Clothing"),
]}

HELMETS = {
    "cap": "Leather Cap", "coif": "Chain Coif", "kettle": "Kettle Helm", "great_helm": "Great Helm",
    "horned_helm": "Horned Helm", "hood": "Hood", "wizard_hat": "Pointed Hat", "crown": "Crown",
    "circlet": "Circlet",
}

CLOAKS = {"cloak": "Cloak", "fur_cloak": "Fur Cloak", "cape": "Short Cape"}


def _torso_region(frame: Frame, grow: float = 0.45):
    sx, sy, rx, ry = frame.shoulders
    return sx, sy, rx + grow * frame.k, ry + grow * frame.k


def draw_armor(style_id: str, frame: Frame, layers: dict[str, Canvas], tint: str | None = None,
               helmet: bool = True) -> None:
    style = ARMOR_STYLES.get(style_id)
    if not style:
        return
    size, k = frame.size, frame.k
    base = hex_to_rgba(style.base)
    if tint:
        base = mix(base, tint, 0.45)
    body = layers.setdefault("armor_body", Canvas(size))
    arms = layers.setdefault("armor_arms", Canvas(size))
    sx, sy, rx, ry = _torso_region(frame)

    # --- torso shell ---------------------------------------------------------
    if style.pattern == "robe":
        body.shaded_ellipse(sx, sy + 1.2 * k, rx + 0.4 * k, ry + 2.6 * k, base, steps=4)
    elif style.pattern == "hide":
        body.shaded_ellipse(sx, sy, rx + 0.3 * k, ry + 0.3 * k, base, steps=4)
        for a in range(0, 360, 30):
            r = math.radians(a)
            body.shaded_ellipse(sx + math.cos(r) * rx * 0.95, sy + math.sin(r) * ry * 0.95,
                                1.3 * k, 1.3 * k, base, steps=3)
    else:
        body.shaded_ellipse(sx, sy, rx, ry, base, steps=4)

    tones = ramp(base, 4)
    x0, x1 = int(sx - rx - 2), int(sx + rx + 2)
    y0, y1 = int(sy - ry - 3 * k), int(sy + ry + 3 * k)

    def each(fn):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                if body.get(x, y) is not None:
                    fn(x, y)

    unit = max(1, round(k))
    if style.pattern == "quilted":
        each(lambda x, y: body.set(x, y, shift(body.get(x, y), -0.08)) if (x - int(sx)) % (3 * unit) == 0 else None)
    elif style.pattern in ("chain",):
        each(lambda x, y: body.set(x, y, shift(body.get(x, y), -0.1 if (x // unit + y // unit) % 2 else 0.04)))
    elif style.pattern == "rings":
        def ring(x, y):
            if (x // unit) % 3 == 1 and (y // unit) % 3 == 1:
                body.set(x, y, shift("#9aa3ab", -0.05 if y > sy else 0.05))
        each(ring)
    elif style.pattern == "scale":
        def scale(x, y):
            row = (y // (2 * unit))
            off = unit * 1.5 if row % 2 else 0
            if int(x + off) % (3 * unit) == 0 or y % (2 * unit) == 0:
                body.set(x, y, shift(body.get(x, y), -0.12))
        each(scale)
    elif style.pattern == "splint":
        each(lambda x, y: body.set(x, y, shift(body.get(x, y), -0.13)) if (x - int(sx)) % (2 * unit) == 0 else None)
    elif style.pattern == "studded":
        def stud(x, y):
            if (x // unit) % 3 == 0 and ((y // unit) + (x // (3 * unit))) % 3 == 0:
                body.set(x, y, "#cfd4d8")
        each(stud)
    elif style.pattern == "plate":
        # central ridge and a bright polish streak
        body.line(sx, sy - ry + 1, sx, sy + ry - 1, shift(base, 0.12), width=1)
        body.line(sx + 1, sy - ry + 1, sx + 1, sy + ry - 1, shift(base, -0.1), width=1)
        body.line(sx - rx * 0.55, sy - ry * 0.35, sx - rx * 0.25, sy - ry * 0.6, shift(base, 0.22), width=k)
    elif style.pattern == "noble":
        body.line(sx, sy - ry + 1, sx, sy + ry - 1, style.trim, width=k)

    # straps, collars and trims
    if style.pattern in ("leather", "studded", "chain") and style.trim:
        body.line(sx - rx * 0.8, sy - ry * 0.4, sx + rx * 0.55, sy + ry * 0.8, style.trim, width=1.2 * k)
    if style.pattern == "hide":
        body.shaded_ellipse(sx, sy + ry * 0.2, rx * 0.5, ry * 0.65, style.trim, steps=3)
    if style.pattern == "robe" and style.trim:
        body.line(sx, sy + ry * 0.3, sx, sy + ry + 2.6 * k, style.trim, width=k)
        body.ellipse(sx, sy + ry * 0.3, rx * 0.38, ry * 0.4, shift(base, -0.12))
    if style.pattern in ("plate", "splint") and style.trim:
        body.ellipse(sx, sy + ry * 0.45, rx * 0.34, ry * 0.36, shift(base, -0.15))

    # --- sleeves -------------------------------------------------------------
    sleeve = hex_to_rgba(style.sleeves)
    if tint and style.sleeve_pattern != "plain":
        sleeve = mix(sleeve, tint, 0.45)
    for (shx, shy), (hx, hy, hr) in ((frame.shoulder_w, frame.hand_w), (frame.shoulder_e, frame.hand_e)):
        end_y = hy - hr * (0.2 if style.gauntlets else 0.9)
        arms.line(shx, shy, hx, end_y, shift(sleeve, -0.03), width=frame.arm_width + 0.4 * k)
        arms.line(shx - 0.4 * k, shy, hx - 0.4 * k, end_y - 0.5 * k, shift(sleeve, 0.08), width=max(1.0, 0.9 * k))
        if style.sleeve_pattern in ("plate", "scale", "chain", "rings"):
            steps = 3
            for i in range(1, steps + 1):
                t = i / (steps + 1)
                x = shx + (hx - shx) * t
                y = shy + (end_y - shy) * t
                arms.put(int(x - frame.arm_width * 0.45), int(y), shift(sleeve, -0.18))
                arms.put(int(x + frame.arm_width * 0.45), int(y), shift(sleeve, -0.18))

    # --- pauldrons ---------------------------------------------------------
    if style.pauldrons:
        for side, (shx, shy) in ((-1, frame.shoulder_w), (1, frame.shoulder_e)):
            pr = style.pauldrons * k
            arms.shaded_ellipse(shx - side * 0.2 * k, shy - 0.6 * k, pr, pr * 0.85, base, steps=4)
            arms.line(shx - pr * 0.7, shy + pr * 0.35, shx + pr * 0.7, shy + pr * 0.35, shift(base, -0.18), width=1)
            if style.trim:
                arms.put(int(shx - side * 0.2 * k), int(shy - 0.6 * k), style.trim)

    # --- gauntlets ---------------------------------------------------------
    if style.gauntlets:
        gloves = layers.setdefault("gloves", Canvas(size))
        for hx, hy, hr in (frame.hand_w, frame.hand_e):
            gloves.shaded_ellipse(hx, hy, hr + 0.3 * k, hr + 0.2 * k, base, steps=4)

    if helmet and style.helmet:
        draw_helmet(style.helmet, frame, layers, tint=tint)


def draw_helmet(helmet_id: str, frame: Frame, layers: dict[str, Canvas], tint: str | None = None,
                color: str | None = None) -> None:
    size, k = frame.size, frame.k
    hx, hy, hr = frame.head
    layer = layers.setdefault("helmet", Canvas(size))
    layers["_hides_hair"] = Canvas(1)  # marker: hair is mostly covered

    def col(default):
        c = hex_to_rgba(color or default)
        return mix(c, tint, 0.45) if tint else c

    if helmet_id == "great_helm":
        steel = col("#c4ced6")
        layer.shaded_ellipse(hx, hy, hr + 0.8 * k, hr + 0.8 * k, steel, steps=4)
        layer.line(hx - hr * 0.7, hy + hr * 0.45, hx + hr * 0.7, hy + hr * 0.45, (26, 28, 34, 255), width=max(1, 0.9 * k))
        layer.line(hx, hy - hr - 0.5 * k, hx, hy + hr * 0.3, shift(steel, 0.14), width=1)
        layer.put(int(hx - hr * 0.3), int(hy + hr * 0.75), (40, 44, 52, 255))
        layer.put(int(hx + hr * 0.3), int(hy + hr * 0.75), (40, 44, 52, 255))
    elif helmet_id == "horned_helm":
        steel = col(IRON)
        layer.shaded_ellipse(hx, hy - 0.2 * k, hr + 0.6 * k, hr + 0.5 * k, steel, steps=4)
        for side in (-1, 1):
            for i in range(7):
                t = i / 6
                layer.circle(hx + side * (hr + 0.5 * k + t * 3 * k), hy - t * 3.5 * k, (1.2 - 0.6 * t) * k, "#e8dcc0")
        _hairline_cut(layer, frame, 1.6)
    elif helmet_id == "kettle":
        steel = col("#9aa4ad")
        for a in range(0, 360, 4):
            r = math.radians(a)
            rr = hr + 1.4 * k
            layer.circle(hx + math.cos(r) * rr, hy - 0.2 * k + math.sin(r) * rr, max(0.6, 0.75 * k),
                         shift(steel, -0.04 if math.sin(r) > 0 else 0.06))
        layer.shaded_ellipse(hx, hy - 0.5 * k, hr + 0.3 * k, hr + 0.2 * k, steel, steps=4)
        _hairline_cut(layer, frame, 0.9)
        for a in range(0, 360, 4):
            r = math.radians(a)
            rr = hr + 1.4 * k
            if math.sin(r) > 0.2:
                layer.circle(hx + math.cos(r) * rr, hy - 0.2 * k + math.sin(r) * rr, max(0.6, 0.75 * k),
                             shift(steel, -0.06))
    elif helmet_id == "coif":
        mail = col("#9ea8b1")
        tmp = Canvas(size)
        tmp.shaded_ellipse(hx, hy, hr + 0.9 * k, hr + 0.9 * k, mail, steps=4)
        for y in range(size):
            for x in range(size):
                if tmp.get(x, y) is not None and (x // max(1, round(k)) + y // max(1, round(k))) % 2:
                    tmp.set(x, y, shift(tmp.get(x, y), -0.08))
        # face opening
        tmp.ellipse(hx, hy + hr * 0.62, hr * 0.62, hr * 0.42, None)
        for y in range(size):
            for x in range(size):
                nx, ny = (x + 0.5 - hx) / (hr * 0.62), (y + 0.5 - hy - hr * 0.62) / (hr * 0.42)
                if nx * nx + ny * ny <= 1:
                    tmp.set(x, y, None)
        layer.blit(tmp)
    elif helmet_id == "cap":
        c = col(LEATHER)
        layer.shaded_ellipse(hx, hy - 0.4 * k, hr + 0.4 * k, hr + 0.3 * k, c, steps=3)
        _hairline_cut(layer, frame, 0.6)
        layer.line(hx, hy - hr, hx, hy + 0.3 * k, shift(c, -0.15), width=1)
    elif helmet_id == "hood":
        c = col("#4a5a3a")
        layer.shaded_ellipse(hx, hy - 0.6 * k, hr + 1.3 * k, hr + 1.6 * k, c, steps=4)
        layer.ellipse(hx, hy + hr * 0.55, hr * 0.7, hr * 0.55, None)
        for y in range(size):
            for x in range(size):
                nx, ny = (x + 0.5 - hx) / (hr * 0.72), (y + 0.5 - hy - hr * 0.5) / (hr * 0.6)
                if nx * nx + ny * ny <= 1:
                    layer.set(x, y, None)
        layers.setdefault("helmet_back", Canvas(size)).shaded_ellipse(hx, hy - hr - 1.2 * k, 2.2 * k, 2.4 * k, c, steps=3)
    elif helmet_id == "wizard_hat":
        c = col("#3f4f8a")
        layer.shaded_ellipse(hx, hy - 0.4 * k, hr + 3.0 * k, hr + 2.6 * k, shift(c, -0.05), steps=3)
        for i in range(6):
            t = i / 5
            layer.shaded_ellipse(hx + t * 1.6 * k, hy - 0.6 * k - t * 2.4 * k, (hr - 0.5 * k) * (1 - 0.75 * t) + 0.5,
                                 (hr - 0.5 * k) * (1 - 0.75 * t) + 0.5, c, steps=3)
        layer.put(int(hx + 1.6 * k), int(hy - 3.2 * k), "#e8d070")
        layers.pop("_hides_hair", None)
        layers["_hair_short"] = Canvas(1)
    elif helmet_id == "crown":
        c = col(GOLD)
        for a in range(0, 360, 12):
            r = math.radians(a)
            layer.put(int(hx + math.cos(r) * (hr - 0.3 * k)), int(hy - 0.4 * k + math.sin(r) * (hr - 0.6 * k)), c)
        for a in (210, 250, 290, 330, 30, 150):
            r = math.radians(a)
            layer.circle(hx + math.cos(r) * (hr - 0.4 * k), hy - 0.4 * k + math.sin(r) * (hr - 0.7 * k), 0.9 * k,
                         shift(c, 0.1))
        layers.pop("_hides_hair", None)
    elif helmet_id == "circlet":
        c = col("#d8dce0")
        for a in range(0, 360, 10):
            r = math.radians(a)
            layer.put(int(hx + math.cos(r) * (hr - 0.4 * k)), int(hy - 0.3 * k + math.sin(r) * (hr - 0.8 * k)), c)
        layer.put(int(hx), int(hy + hr * 0.15), "#5ab0e0")
        layers.pop("_hides_hair", None)


def _hairline_cut(layer: Canvas, frame: Frame, hairline: float) -> None:
    hx, hy, hr = frame.head
    k = frame.k
    for y in range(layer.h):
        for x in range(layer.w):
            dx = (x + 0.5 - hx) / (hr + 1)
            if y + 0.5 > hy + hairline * k - dx * dx * 2.2 * k and abs(x + 0.5 - hx) < hr * 1.4:
                if layer.get(x, y) is not None and (x + 0.5 - hx) ** 2 + (y + 0.5 - hy) ** 2 < (hr + 1.2 * k) ** 2:
                    layer.set(x, y, None)


def draw_cloak(cloak_id: str, frame: Frame, layers: dict[str, Canvas], color: str = "#7a2a2a",
               tint: str | None = None) -> None:
    size, k = frame.size, frame.k
    sx, sy, rx, ry = frame.shoulders
    c = hex_to_rgba(color)
    if tint:
        c = mix(c, tint, 0.45)
    back = layers.setdefault("cloak", Canvas(size))
    if cloak_id == "cape":
        back.shaded_ellipse(sx, sy - ry * 0.6, rx + 0.4 * k, ry + 1.2 * k, c, steps=3)
    else:
        length = 4.0 if cloak_id == "cloak" else 3.0
        back.shaded_ellipse(sx, sy - ry * 0.5 - length * 0.4 * k, rx + 1.3 * k, ry + length * k, c, steps=4)
        for i in range(-2, 3):
            back.line(sx + i * 2.4 * k, sy - ry * 0.4, sx + i * 2.9 * k, sy - ry - length * 1.15 * k,
                      shift(c, -0.08), width=1)
        if cloak_id == "fur_cloak":
            for a in range(180, 361, 30):
                r = math.radians(a)
                back.shaded_ellipse(sx + math.cos(r) * rx * 0.85, sy + math.sin(r) * ry * 0.7, 1.7 * k, 1.5 * k,
                                    "#c9b896", steps=3)
    front = layers.setdefault("armor_body", Canvas(size))
    front.circle(sx, sy - ry * 0.05 + 0.4 * k, max(0.8, 0.9 * k), BRASS)


# ======================================================================
# Shields
# ======================================================================
SHIELDS = {"round": "Round Shield", "heater": "Heater Shield", "tower": "Tower Shield", "buckler": "Buckler"}


def draw_shield(shield_id: str, frame: Frame, layers: dict[str, Canvas], tint: str | None = None,
                color: str | None = None, icon: bool = False) -> None:
    size, k = frame.size, frame.k
    layer = layers.setdefault("shield", Canvas(size))
    hx, hy, hr = frame.hand_e
    if icon:
        hx, hy = size / 2, size / 2
    face = hex_to_rgba(color or ("#8a5a32" if shield_id in ("round", "buckler") else "#3f5f8a"))
    if tint:
        face = mix(face, tint, 0.4)
    rim = hex_to_rgba("#8c949c")
    if shield_id == "round":
        r = (4.4 if not icon else 11) * k
        cx, cy = hx + 0.8 * k, hy - 0.6 * k
        layer.shaded_ellipse(cx, cy, r, r, rim, steps=3)
        layer.shaded_ellipse(cx, cy, r - max(1, k), r - max(1, k), face, steps=4)
        for i in (-1, 1):
            layer.line(cx + i * r * 0.35, cy - r + 1.5 * k, cx + i * r * 0.35, cy + r - 1.5 * k, shift(face, -0.1), width=1)
        layer.shaded_ellipse(cx, cy, max(1.2, r * 0.26), max(1.2, r * 0.26), "#b8c0c8", steps=3)
    elif shield_id == "buckler":
        r = (3.0 if not icon else 8) * k
        cx, cy = hx + 0.5 * k, hy - 0.3 * k
        layer.shaded_ellipse(cx, cy, r, r, "#a7b1ba", steps=4)
        layer.shaded_ellipse(cx, cy, r * 0.4, r * 0.4, "#c9d1d8", steps=3)
    else:
        mult = (2.4 if shield_id == "heater" else 1.75) if icon else 1
        w = (4.2 if shield_id == "heater" else 5.0) * k * mult
        h = (5.8 if shield_id == "heater" else 7.6) * k * mult
        cx, cy = hx + 0.8 * k, hy - 0.4 * k
        if shield_id == "heater":
            pts = [(cx - w, cy - h * 0.55), (cx + w, cy - h * 0.55), (cx + w, cy + h * 0.05),
                   (cx, cy + h * 0.6), (cx - w, cy + h * 0.05)]
        else:
            pts = [(cx - w, cy - h * 0.5), (cx + w, cy - h * 0.5), (cx + w, cy + h * 0.5), (cx - w, cy + h * 0.5)]
        layer.polygon(pts, rim)
        inner = [(x + (cx - x) * (k / max(w, 1)) * 1.1, y + (cy - y) * (k / max(h, 1)) * 1.4) for x, y in pts]
        layer.polygon(inner, face)
        # light top-left, shade bottom-right
        for y in range(layer.h):
            for x in range(layer.w):
                p = layer.get(x, y)
                if p is not None and p[:3] == face[:3]:
                    d = (x - cx) / w + (y - cy) / h
                    if d < -0.55:
                        layer.set(x, y, shift(face, 0.08))
                    elif d > 0.55:
                        layer.set(x, y, shift(face, -0.1))
        layer.line(cx, cy - h * 0.45, cx, cy + h * 0.4, shift(face, 0.18) if shield_id == "heater" else GOLD, width=max(1, k))
        layer.line(cx - w * 0.75, cy - h * 0.15, cx + w * 0.75, cy - h * 0.15,
                   shift(face, 0.18) if shield_id == "heater" else GOLD, width=max(1, k))


# ======================================================================
# Weapons
# ======================================================================
@dataclass(frozen=True)
class WeaponShape:
    id: str
    label: str
    kind: str          # blade, curved, rapier, axe, double_axe, hammer, mace, spiked, flail, club,
                       # staff, spear, halberd, glaive, trident, pike, lance, bow, crossbow, sling,
                       # whip, pick, sickle, dart, blowgun, net
    length: float      # in 32px units, measured from the hand
    width: float = 1.0
    two_handed: bool = False
    head: str = STEEL
    handle: str = DARK_WOOD
    guard: str = BRASS


WEAPONS: dict[str, WeaponShape] = {w.id: w for w in [
    WeaponShape("club", "Club", "club", 7, 1.6, handle=WOOD),
    WeaponShape("dagger", "Dagger", "blade", 4.5, 1.0),
    WeaponShape("greatclub", "Greatclub", "club", 10, 2.2, two_handed=True, handle=WOOD),
    WeaponShape("handaxe", "Handaxe", "axe", 6, 1.0),
    WeaponShape("javelin", "Javelin", "spear", 13, 1.0, handle=WOOD),
    WeaponShape("light_hammer", "Light Hammer", "hammer", 6, 0.9),
    WeaponShape("mace", "Mace", "mace", 7, 1.0, head=IRON),
    WeaponShape("quarterstaff", "Quarterstaff", "staff", 19, 1.1, handle=WOOD),
    WeaponShape("sickle", "Sickle", "sickle", 6, 1.0),
    WeaponShape("spear", "Spear", "spear", 17, 1.0, handle=WOOD),
    WeaponShape("light_crossbow", "Light Crossbow", "crossbow", 8, 1.0, two_handed=True, handle=WOOD),
    WeaponShape("dart", "Dart", "dart", 4, 0.8),
    WeaponShape("shortbow", "Shortbow", "bow", 6, 1.0, two_handed=True, handle=WOOD),
    WeaponShape("sling", "Sling", "sling", 5, 1.0, handle=LEATHER),
    WeaponShape("battleaxe", "Battleaxe", "axe", 8, 1.3),
    WeaponShape("flail", "Flail", "flail", 7, 1.0, head=IRON),
    WeaponShape("glaive", "Glaive", "glaive", 19, 1.2, two_handed=True),
    WeaponShape("greataxe", "Greataxe", "double_axe", 11, 1.6, two_handed=True),
    WeaponShape("greatsword", "Greatsword", "blade", 13, 1.8, two_handed=True),
    WeaponShape("halberd", "Halberd", "halberd", 19, 1.3, two_handed=True),
    WeaponShape("lance", "Lance", "lance", 20, 1.6, handle="#d8c8a0"),
    WeaponShape("longsword", "Longsword", "blade", 9.5, 1.3),
    WeaponShape("maul", "Maul", "hammer", 11, 2.0, two_handed=True, head=IRON),
    WeaponShape("morningstar", "Morningstar", "spiked", 8, 1.2, head=IRON),
    WeaponShape("pike", "Pike", "pike", 21, 1.0, two_handed=True),
    WeaponShape("rapier", "Rapier", "rapier", 10, 0.8),
    WeaponShape("scimitar", "Scimitar", "curved", 8.5, 1.3),
    WeaponShape("shortsword", "Shortsword", "blade", 7, 1.2),
    WeaponShape("trident", "Trident", "trident", 16, 1.0),
    WeaponShape("war_pick", "War Pick", "pick", 7.5, 1.0),
    WeaponShape("warhammer", "Warhammer", "hammer", 8, 1.3, head=IRON),
    WeaponShape("whip", "Whip", "whip", 9, 1.0, handle=LEATHER),
    WeaponShape("blowgun", "Blowgun", "blowgun", 9, 0.8, handle="#a08a5a"),
    WeaponShape("hand_crossbow", "Hand Crossbow", "crossbow", 5, 0.8, handle=WOOD),
    WeaponShape("heavy_crossbow", "Heavy Crossbow", "crossbow", 10, 1.3, two_handed=True, handle=DARK_WOOD),
    WeaponShape("longbow", "Longbow", "bow", 8, 1.0, two_handed=True, handle=WOOD),
    WeaponShape("net", "Net", "net", 6, 1.0, handle="#b8a880"),
    # non-SRD extras useful for spellcasters and monsters
    WeaponShape("staff_orb", "Wizard Staff", "staff_orb", 19, 1.1, handle=DARK_WOOD, head="#6ac0f0"),
    WeaponShape("wand", "Wand", "wand", 5, 0.8, handle="#5a3a2a", head="#e8d070"),
    WeaponShape("torch", "Torch", "torch", 6, 1.0, handle=WOOD, head="#f0a030"),
]}

POLEARMS = {"spear", "halberd", "glaive", "trident", "pike", "lance", "staff", "staff_orb"}


def weapon_two_handed(weapon_id: str) -> bool:
    w = WEAPONS.get(weapon_id)
    return bool(w and w.two_handed)


def draw_weapon(weapon_id: str, frame: Frame, layers: dict[str, Canvas], tint: str | None = None,
                icon: bool = False) -> None:
    w = WEAPONS.get(weapon_id)
    if not w:
        return
    size, k = frame.size, frame.k
    layer = layers.setdefault("weapon", Canvas(size))
    head = hex_to_rgba(w.head)
    if tint:
        head = mix(head, tint, 0.5)
    handle = hex_to_rgba(w.handle)
    guard = hex_to_rgba(w.guard)

    if icon:
        # Diagonal, bottom-left to top-right, scaled to fill the square.
        ux, uy = math.cos(math.radians(-45)), math.sin(math.radians(-45))
        if w.kind in ("bow", "crossbow", "net", "whip", "sling"):
            sk = size / 32 * (1.15 if w.kind == "bow" else 1.25)
            span = w.length + 3
        else:
            span = w.length + 3.5
            head_room = w.width * 3.2 if w.kind in ("axe", "double_axe", "hammer", "halberd", "glaive", "club", "flail") else 0
            sk = max(1.0, min(2.4, 31.0 / (span + head_room))) * size / 32
        total = span * sk
        ox = size / 2 - ux * total / 2 + 0.5
        oy = size / 2 - uy * total / 2 - 0.5
        hand = (ox + ux * 2.6 * sk, oy + uy * 2.6 * sk)
        _shape(layer, w, hand, (ux, uy), sk, head, handle, guard, icon=True)
        return

    hx, hy, hr = frame.hand_w
    tip = (1.6 * k, size - 1.8 * k)          # weapons point toward the lower-left corner
    if w.kind in ("bow", "crossbow") and w.two_handed:
        ux, uy = 0.0, 1.0
        hx = frame.cx
        hy = frame.hand_w[1] + 0.6 * k
        _shape(layer, w, (hx, hy), (ux, uy), k, head, handle, guard)
        return
    dx, dy = tip[0] - hx, tip[1] - hy
    reach = math.hypot(dx, dy)
    ux, uy = dx / reach, dy / reach
    length = None
    if w.kind in POLEARMS:
        length = reach + 0.6 * k
    elif w.two_handed:
        length = min(w.length * k, reach + 1.0 * k)
    elif w.length * k > reach + 1.0 * k:
        length = reach + 1.0 * k
    _shape(layer, w, (hx, hy), (ux, uy), k, head, handle, guard, length_px=length)


def _shape(layer: Canvas, w: WeaponShape, hand, direction, k: float, head, handle, guard, icon: bool = False,
           length_px: float | None = None):
    hx, hy = hand
    ux, uy = direction
    px, py = -uy, ux                      # perpendicular
    L = length_px if length_px is not None else w.length * k
    wd = w.width * k

    def at(t, side=0.0):
        return hx + ux * t + px * side, hy + uy * t + py * side

    kind = w.kind
    if kind in ("blade", "curved", "rapier"):
        # pommel and grip behind the hand, guard, then blade
        gx0, gy0 = at(-2.4 * k)
        gx1, gy1 = at(1.0 * k)
        layer.line(gx0, gy0, gx1, gy1, handle, width=max(1.0, 1.1 * k))
        layer.circle(*at(-2.6 * k), max(0.7, 0.8 * k), guard)
        gw = (2.6 if kind != "rapier" else 2.0) * k + wd * 0.8
        layer.line(*at(1.3 * k, -gw), *at(1.3 * k, gw), guard, width=max(1.0, 0.9 * k))
        if kind == "rapier":
            layer.circle(*at(1.6 * k), 1.3 * k, shift(guard, 0.05))
        tip = L
        pts = []
        steps = 10
        for i in range(steps + 1):
            t = i / steps
            along = 2.0 * k + (tip - 2.0 * k) * t
            curve = (math.sin(t * math.pi * 0.9) * 1.8 * k) if kind == "curved" else 0.0
            half = wd * (1 - t * 0.55) if kind != "rapier" else max(0.5, wd * 0.6)
            if t > 0.86 and kind != "rapier":
                half *= (1 - t) / 0.14
            pts.append((along, curve, half))
        left = [at(a, c - h) for a, c, h in pts]
        right = [at(a, c + h) for a, c, h in reversed(pts)]
        layer.polygon(left + right, shift(head, -0.04))
        # edge highlight along one side, fuller line along the middle
        for a, c, h in pts[1:-1]:
            layer.put(*map(int, at(a, c - h * 0.55)), shift(head, 0.18))
        if kind == "blade" and w.width >= 1.2:
            for a, c, h in pts[1:-2]:
                layer.put(*map(int, at(a, c + h * 0.15)), shift(head, -0.14))
    elif kind in ("axe", "double_axe", "hammer", "mace", "spiked", "club", "pick", "sickle", "flail", "torch", "wand"):
        grip_back = -2.0 * k
        shaft_end = L - (1.5 * k if kind not in ("club", "torch", "wand") else 0)
        if kind == "club":
            for i in range(9):
                t = i / 8
                layer.circle(*at(grip_back + (L - grip_back) * t), (0.7 + 1.0 * t) * wd * 0.8 + 0.2, shift(handle, 0.04 * (i % 2)))
            layer.put(*map(int, at(L * 0.75, -wd * 0.4)), shift(handle, -0.15))
            return
        if kind == "flail":
            layer.line(*at(grip_back), *at(L * 0.45), handle, width=max(1.0, 1.1 * k))
            for i in range(4):
                layer.put(*map(int, at(L * 0.45 + i * 0.9 * k, i * 0.5 * k)), "#8c949c")
            ball = at(L * 0.45 + 4.4 * k, 2.0 * k)
            layer.shaded_ellipse(*ball, 1.6 * k * w.width, 1.6 * k * w.width, head, steps=3)
            for a in range(0, 360, 60):
                r = math.radians(a)
                layer.put(int(ball[0] + math.cos(r) * 2.2 * k), int(ball[1] + math.sin(r) * 2.2 * k), shift(head, 0.15))
            return
        layer.line(*at(grip_back), *at(shaft_end), handle, width=max(1.0, 1.1 * k * (1.2 if w.two_handed else 1)))
        layer.line(*at(grip_back, -0.3 * k), *at(shaft_end * 0.8, -0.3 * k), shift(handle, 0.1), width=1)
        hxp, hyp = at(L - 1.0 * k)
        if kind in ("axe", "double_axe"):
            size_h = 2.6 * wd
            for side in ((-1,) if kind == "axe" else (-1, 1)):
                pts = [at(L - 2.6 * k, side * 0.6 * k)]
                for i in range(9):
                    tt = i / 8
                    along = L - 4.8 * k + 5.6 * k * tt
                    out = size_h + 1.2 * k * math.sin(math.pi * tt)
                    pts.append(at(along, side * out))
                pts.append(at(L + 0.4 * k, side * 0.6 * k))
                layer.polygon(pts, head)
                for i in range(1, 8):
                    tt = i / 8
                    along = L - 4.8 * k + 5.6 * k * tt
                    out = size_h + 1.2 * k * math.sin(math.pi * tt) - 0.6
                    layer.put(*map(int, at(along, side * out)), shift(head, 0.2))
                layer.line(*at(L - 2.4 * k, side * 1.0 * k), *at(L + 0.2 * k, side * 1.0 * k), shift(head, -0.15), width=1)
        elif kind == "hammer":
            hw = 1.8 * wd
            layer.polygon([at(L - 2.6 * k, -hw), at(L - 2.6 * k, hw), at(L + 0.4 * k, hw), at(L + 0.4 * k, -hw)], head)
            layer.line(*at(L - 2.4 * k, -hw + 0.5), *at(L + 0.2 * k, -hw + 0.5), shift(head, 0.18), width=1)
        elif kind in ("mace", "spiked"):
            r = 1.7 * wd
            layer.shaded_ellipse(hxp, hyp, r, r, head, steps=3)
            for a in range(0, 360, 45 if kind == "spiked" else 90):
                rad = math.radians(a)
                layer.put(int(hxp + math.cos(rad) * (r + 0.9 * k)), int(hyp + math.sin(rad) * (r + 0.9 * k)),
                          shift(head, 0.1))
        elif kind == "pick":
            layer.line(*at(L - 1.5 * k, -3.4 * k), *at(L - 1.0 * k, 2.4 * k), head, width=max(1.0, 1.1 * k))
            layer.put(*map(int, at(L - 1.6 * k, -3.6 * k)), shift(head, 0.2))
        elif kind == "sickle":
            for i in range(9):
                a = math.radians(-20 + i * 22)
                layer.put(*map(int, at(L - 2.0 * k + math.sin(a) * 2.6 * k, -math.cos(a) * 2.6 * k)), head)
        elif kind == "torch":
            fx, fy = at(L)
            layer.shaded_ellipse(fx, fy, 1.6 * k, 1.8 * k, "#f08020", steps=3)
            layer.circle(fx, fy - 0.3 * k, 0.9 * k, "#ffe070")
            layer.ellipse(fx, fy, 3.5 * k, 3.5 * k, (255, 200, 80, 40))
        elif kind == "wand":
            layer.circle(*at(L), max(0.8, 0.9 * k), head)
    elif kind in POLEARMS:
        back = -9.0 * k if not icon else -2.0 * k
        layer.line(*at(back), *at(L - 2.5 * k), handle, width=max(1.0, 1.1 * k))
        layer.line(*at(back, -0.35 * k), *at(L - 3.0 * k, -0.35 * k), shift(handle, 0.1), width=1)
        if kind in ("spear", "pike", "lance"):
            length = 3.4 if kind != "lance" else 5.0
            layer.polygon([at(L - 3.0 * k, -1.1 * wd), at(L - 3.0 * k, 1.1 * wd), at(L + length * k - 2.5 * k, 0)], head)
            layer.put(*map(int, at(L - 2.0 * k, -0.4 * wd)), shift(head, 0.2))
            if kind == "lance":
                layer.polygon([at(L - 6 * k, -2.0 * k), at(L - 6 * k, 2.0 * k), at(L - 3 * k, 1.0 * k), at(L - 3 * k, -1.0 * k)],
                              "#c8b890")
        elif kind == "trident":
            layer.line(*at(L - 3.0 * k, -2.2 * k), *at(L - 3.0 * k, 2.2 * k), head, width=1)
            for s in (-2.2, 0, 2.2):
                layer.line(*at(L - 3.0 * k, s * k), *at(L + 0.6 * k, s * k), head, width=1)
        elif kind == "halberd":
            layer.polygon([at(L - 5.5 * k, 0), at(L - 6.0 * k, -3.6 * wd), at(L - 2.6 * k, -3.8 * wd), at(L - 2.6 * k, 0)], head)
            layer.polygon([at(L - 3.0 * k, -0.8 * k), at(L - 3.0 * k, 0.8 * k), at(L + 0.8 * k, 0)], head)
            layer.line(*at(L - 4.8 * k, 0), *at(L - 4.8 * k, 1.8 * k), head, width=1)
        elif kind == "glaive":
            pts = [at(L - 5.0 * k, -0.6 * k), at(L - 5.0 * k, 1.0 * k), at(L, 1.6 * k), at(L + 1.0 * k, 0.0)]
            layer.polygon(pts, head)
            layer.line(*at(L - 4.5 * k, -0.4 * k), *at(L + 0.6 * k, 0.2 * k), shift(head, 0.18), width=1)
        elif kind == "staff":
            layer.circle(*at(L - 2.5 * k), max(0.9, 1.2 * k), shift(handle, -0.06))
            layer.circle(*at(back), max(0.9, 1.1 * k), shift(handle, -0.06))
        elif kind == "staff_orb":
            ox, oy = at(L - 1.4 * k)
            layer.line(*at(L - 3.6 * k, -1.4 * k), ox - px * 1.6 * k, oy - py * 1.6 * k, handle, width=1)
            layer.line(*at(L - 3.6 * k, 1.4 * k), ox + px * 1.6 * k, oy + py * 1.6 * k, handle, width=1)
            layer.shaded_ellipse(ox, oy, 1.6 * k, 1.6 * k, head, steps=4)
            layer.ellipse(ox, oy, 3.0 * k, 3.0 * k, with_alpha(head, 45))
    elif kind == "bow":
        span = (7.0 if w.id == "shortbow" else 9.5) * k
        if icon:
            span *= 1.2
        depth = 3.0 * k
        pts = []
        for i in range(17):
            t = i / 16 * 2 - 1
            pts.append(at(depth * (1 - t * t) + 1.0 * k, t * span))
        for a, b in zip(pts, pts[1:]):
            layer.line(*a, *b, handle, width=max(1.0, 1.2 * k))
        layer.line(*pts[0], *pts[-1], (230, 225, 210, 255), width=1)
        layer.line(*at(-0.5 * k), *at(depth + 3.0 * k), "#d8c8a0", width=1)
        layer.put(*map(int, at(depth + 3.2 * k)), STEEL)
        layer.put(*map(int, at(-0.8 * k, -0.6 * k)), "#e05050")
        layer.put(*map(int, at(-0.8 * k, 0.6 * k)), "#e05050")
    elif kind == "crossbow":
        span = (4.5 if w.length < 6 else 6.5 if w.length < 9 else 7.5) * k
        stock_back = -2.5 * k
        layer.line(*at(stock_back), *at(L - 2 * k), handle, width=max(1.0, 1.6 * k * w.width))
        pts = []
        for i in range(11):
            t = i / 10 * 2 - 1
            pts.append(at(L - 2.0 * k + 1.2 * k * (1 - t * t), t * span))
        for a, b in zip(pts, pts[1:]):
            layer.line(*a, *b, "#6c7680", width=max(1.0, 1.0 * k))
        layer.line(*pts[0], *at(L * 0.4), (225, 220, 205, 255), width=1)
        layer.line(*pts[-1], *at(L * 0.4), (225, 220, 205, 255), width=1)
        layer.line(*at(L * 0.4), *at(L + 0.5 * k), STEEL, width=1)
    elif kind == "sling":
        layer.line(*at(0), *at(L * 0.6, -1.0 * k), handle, width=1)
        layer.line(*at(0), *at(L * 0.6, 1.0 * k), handle, width=1)
        layer.shaded_ellipse(*at(L * 0.65), 1.2 * k, 1.2 * k, "#8a8a8a", steps=3)
    elif kind == "whip":
        x, y = at(-1.5 * k)
        layer.line(x, y, *at(1.5 * k), DARK_WOOD, width=max(1.0, 1.1 * k))
        pts = []
        for i in range(24):
            t = i / 23
            pts.append(at(1.5 * k + t * L, math.sin(t * 7) * 2.2 * k * t))
        for a, b in zip(pts, pts[1:]):
            layer.line(*a, *b, handle, width=1)
    elif kind == "dart":
        layer.line(*at(0), *at(L), STEEL, width=1)
        layer.put(*map(int, at(-0.6 * k, -0.6 * k)), "#d04040")
        layer.put(*map(int, at(-0.6 * k, 0.6 * k)), "#d04040")
    elif kind == "blowgun":
        layer.line(*at(-1.0 * k), *at(L), handle, width=max(1.0, 1.1 * k))
        layer.put(*map(int, at(L)), shift(handle, -0.3))
    elif kind == "net":
        cx, cy = at(L * 0.6)
        r = 3.2 * k * (1.6 if icon else 1)
        for a in range(0, 360, 30):
            rad = math.radians(a)
            layer.line(cx, cy, cx + math.cos(rad) * r, cy + math.sin(rad) * r, handle, width=1)
        for rr in (r * 0.5, r):
            for a in range(0, 360, 8):
                rad = math.radians(a)
                layer.put(int(cx + math.cos(rad) * rr), int(cy + math.sin(rad) * rr), handle)
