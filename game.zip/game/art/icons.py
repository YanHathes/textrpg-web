"""32x32 inventory icons for items that aren't worn (potions, scrolls, gems...)."""
from __future__ import annotations

import math

from game.art.canvas import Canvas, shift


def _done(c: Canvas) -> Canvas:
    c.outline()
    return c


def potion(color="#d03a3a") -> Canvas:
    c = Canvas(32)
    c.shaded_ellipse(16, 20, 7.5, 7.5, color, steps=4)
    c.ellipse(16, 20, 7.5, 3.4, shift(color, 0.06))
    c.rect(14, 7, 17, 13, "#b8d4e0")
    c.rect(13, 5, 18, 7, "#8a5a32")
    c.ellipse(13, 17, 2, 2.6, (255, 255, 255, 150))
    return _done(c)


def scroll() -> Canvas:
    c = Canvas(32)
    c.rect(8, 9, 23, 23, "#e8dcb8")
    for y in range(12, 22, 3):
        c.line(10, y, 21, y, "#a89878", width=1)
    c.shaded_ellipse(15.5, 9, 9, 2.2, "#d8c8a0", steps=3)
    c.shaded_ellipse(15.5, 23.5, 9, 2.2, "#d8c8a0", steps=3)
    c.rect(14, 22, 17, 26, "#a02a2a")
    return _done(c)


def book(color="#7a2a2a") -> Canvas:
    c = Canvas(32)
    c.rect(8, 7, 24, 25, color)
    c.rect(8, 7, 10, 25, shift(color, -0.12))
    c.rect(22, 9, 24, 23, "#e8e0c8")
    c.rect(13, 12, 19, 16, "#d8b04a")
    return _done(c)


def bag() -> Canvas:
    c = Canvas(32)
    c.shaded_ellipse(16, 19, 9, 8, "#9a7448", steps=4)
    c.shaded_ellipse(16, 10, 4, 2.6, "#8a6438", steps=3)
    c.line(11, 12, 21, 12, "#5e3b22", width=1)
    return _done(c)


def coins() -> Canvas:
    c = Canvas(32)
    for x, y in ((11, 20), (19, 21), (15, 16), (21, 15), (12, 13)):
        c.shaded_ellipse(x, y, 4.2, 3.4, "#e0b84a", steps=4)
        c.put(x, y, "#a8822a")
    return _done(c)


def gem(color="#3ab0e0") -> Canvas:
    c = Canvas(32)
    c.polygon([(16, 6), (25, 13), (16, 27), (7, 13)], color)
    c.polygon([(16, 6), (25, 13), (16, 13)], shift(color, 0.15))
    c.polygon([(7, 13), (16, 13), (16, 27)], shift(color, -0.12))
    c.line(7, 13, 25, 13, shift(color, 0.25), width=1)
    return _done(c)


def ring(color="#e0b84a", stone="#d03a5a") -> Canvas:
    c = Canvas(32)
    for a in range(0, 360, 5):
        r = math.radians(a)
        c.circle(16 + math.cos(r) * 7, 17 + math.sin(r) * 6, 1.6, shift(color, 0.1 if math.sin(r) < 0 else -0.08))
    c.shaded_ellipse(16, 10, 3, 3, stone, steps=3)
    return _done(c)


def amulet() -> Canvas:
    c = Canvas(32)
    for a in range(200, 341, 6):
        r = math.radians(a)
        c.put(int(16 + math.cos(r) * 10), int(14 + math.sin(r) * 9), "#c9a24a")
    c.line(6, 15, 14, 22, "#c9a24a", width=1)
    c.line(26, 15, 18, 22, "#c9a24a", width=1)
    c.shaded_ellipse(16, 23, 4, 4.4, "#5ab0e0", steps=4)
    return _done(c)


def key() -> Canvas:
    c = Canvas(32)
    for a in range(0, 360, 8):
        r = math.radians(a)
        c.put(int(11 + math.cos(r) * 4), int(11 + math.sin(r) * 4), "#c9a24a")
    c.line(14, 14, 25, 25, "#c9a24a", width=2)
    c.line(21, 25, 23, 23, "#c9a24a", width=2)
    c.line(24, 22, 26, 20, "#c9a24a", width=2)
    return _done(c)


def bread() -> Canvas:
    c = Canvas(32)
    c.shaded_ellipse(16, 17, 11, 7, "#c88a42", steps=4)
    for x in (11, 16, 21):
        c.line(x - 1, 14, x + 1, 19, "#9a6428", width=1)
    return _done(c)


def bottle(color="#6a3a8a") -> Canvas:
    c = Canvas(32)
    c.rect(12, 13, 20, 26, color)
    c.rect(12, 13, 13, 26, shift(color, 0.1))
    c.rect(14, 6, 17, 13, shift(color, -0.05))
    c.rect(14, 4, 17, 6, "#8a5a32")
    c.rect(13, 17, 19, 21, "#e8dcb8")
    return _done(c)


def rope() -> Canvas:
    c = Canvas(32)
    for r in (10, 7, 4):
        for a in range(0, 360, 6):
            rad = math.radians(a)
            c.circle(16 + math.cos(rad) * r, 16 + math.sin(rad) * r * 0.8, 1.3, "#b8986a" if r != 7 else "#a8885a")
    return _done(c)


def arrows() -> Canvas:
    c = Canvas(32)
    c.rect(9, 12, 15, 27, "#6e4a2c")
    for i in range(4):
        x = 10 + i * 2
        c.line(x, 4, x + 1, 12, "#d8c8a0", width=1)
        c.put(x, 4, "#e05050")
    c.line(17, 27, 25, 7, "#d8c8a0", width=1)
    c.put(25, 6, "#a7b1ba")
    return _done(c)


def ore(color="#8a8680", fleck="#c87a3a") -> Canvas:
    c = Canvas(32)
    c.shaded_ellipse(15, 18, 9, 7, color, steps=4)
    c.shaded_ellipse(20, 14, 5, 4, shift(color, 0.04), steps=4)
    for x, y in ((12, 17), (17, 20), (20, 13), (14, 21)):
        c.put(x, y, fleck)
    return _done(c)


def herb() -> Canvas:
    c = Canvas(32)
    c.line(16, 27, 16, 10, "#3a6a2a", width=1)
    for i, y in enumerate((12, 16, 20, 24)):
        side = -1 if i % 2 else 1
        c.shaded_ellipse(16 + side * 4, y, 3.6, 2, "#5aa040", steps=3)
    return _done(c)


def letter() -> Canvas:
    c = Canvas(32)
    c.rect(6, 10, 26, 23, "#e8dcb8")
    c.line(6, 10, 16, 17, "#a89878", width=1)
    c.line(26, 10, 16, 17, "#a89878", width=1)
    c.shaded_ellipse(16, 17, 2.4, 2.4, "#a02a2a", steps=3)
    return _done(c)


def tool() -> Canvas:
    c = Canvas(32)
    c.line(8, 25, 20, 13, "#8a5a32", width=2)
    c.polygon([(18, 9), (25, 8), (24, 15), (21, 12)], "#a7b1ba")
    c.line(14, 26, 25, 15, "#6c7680", width=2)
    return _done(c)


def chest_small() -> Canvas:
    c = Canvas(32)
    c.rect(6, 11, 25, 24, "#8a5a32")
    c.rect(6, 11, 25, 15, "#9a6a3a")
    c.rect(6, 16, 25, 16, "#c9a24a")
    c.rect(15, 15, 17, 18, "#e0c060")
    return _done(c)


def log(color="#8a5a32", end="#d8b07a") -> Canvas:
    c = Canvas(32)
    c.rect(7, 12, 23, 21, color)
    c.rect(7, 12, 23, 13, shift(color, 0.08))
    c.line(9, 16, 20, 16, shift(color, -0.1), width=1)
    c.shaded_ellipse(23.5, 16.5, 3, 5, end, steps=3)
    c.circle(23.5, 16.5, 1.2, shift(end, -0.15))
    return _done(c)


def stone_block() -> Canvas:
    c = Canvas(32)
    c.rect(7, 13, 23, 24, "#8e8c86")
    c.polygon([(7, 13), (12, 8), (27, 8), (23, 13)], "#aaa8a0")
    c.polygon([(23, 13), (27, 8), (27, 19), (23, 24)], "#74726c")
    return _done(c)


def fish(color="#7a9ab0") -> Canvas:
    c = Canvas(32)
    c.shaded_ellipse(15, 16, 9, 4.5, color, steps=4)
    c.polygon([(23, 16), (28, 11), (28, 21)], shift(color, -0.1))
    c.circle(10, 15, 1, "#202020")
    c.line(12, 18, 19, 18, shift(color, 0.12), width=1)
    return _done(c)


def berries(color="#3a2a6a") -> Canvas:
    c = Canvas(32)
    for x, y in ((12, 17), (17, 15), (20, 20), (14, 22), (19, 25), (10, 23)):
        c.shaded_ellipse(x, y, 3.2, 3.2, color, steps=3)
    c.shaded_ellipse(15, 10, 4, 2, "#4a8a3a", steps=2)
    return _done(c)


def mushroom(cap="#b0743a") -> Canvas:
    c = Canvas(32)
    c.rect(14, 15, 18, 25, "#e8dcc0")
    c.shaded_ellipse(16, 14, 9, 5, cap, steps=4)
    return _done(c)


def grain() -> Canvas:
    c = Canvas(32)
    for dx in (-4, 0, 4):
        c.line(16 + dx, 27, 16 + dx // 2, 9, "#a08a3a", width=1)
        for y in range(9, 18, 2):
            c.shaded_ellipse(16 + dx // 2 + 1, y, 1.6, 1, "#e0c060", steps=2)
    return _done(c)


def hide(color="#9a6a42") -> Canvas:
    c = Canvas(32)
    c.polygon([(8, 9), (13, 11), (19, 11), (24, 9), (22, 17), (25, 25), (17, 23), (15, 23), (7, 25), (10, 17)], color)
    c.shaded_ellipse(16, 17, 4, 5, shift(color, 0.06), steps=3)
    return _done(c)


ICONS = {
    "potion_red": ("Potion (red)", lambda: potion("#d03a3a")),
    "potion_blue": ("Potion (blue)", lambda: potion("#3a6ad0")),
    "potion_green": ("Potion (green)", lambda: potion("#3aa04a")),
    "potion_gold": ("Potion (gold)", lambda: potion("#e0b03a")),
    "scroll": ("Scroll", scroll),
    "book_red": ("Book (red)", lambda: book("#7a2a2a")),
    "book_blue": ("Book (blue)", lambda: book("#2a4a7a")),
    "bag": ("Bag", bag),
    "coins": ("Coins", coins),
    "gem_blue": ("Gem (blue)", lambda: gem("#3ab0e0")),
    "gem_red": ("Gem (red)", lambda: gem("#e03a4a")),
    "gem_green": ("Gem (green)", lambda: gem("#3ad07a")),
    "ring_gold": ("Ring (gold)", lambda: ring()),
    "ring_silver": ("Ring (silver)", lambda: ring("#c8d0d8", "#3a8ad0")),
    "amulet": ("Amulet", amulet),
    "key": ("Key", key),
    "bread": ("Food", bread),
    "bottle": ("Bottle", bottle),
    "rope": ("Rope", rope),
    "arrows": ("Arrows", arrows),
    "ore_iron": ("Ore", lambda: ore()),
    "ore_gold": ("Gold ore", lambda: ore("#8a7a60", "#f0c840")),
    "herb": ("Herb", herb),
    "letter": ("Letter", letter),
    "tool": ("Tools", tool),
    "chest": ("Small chest", chest_small),
    "log": ("Log", lambda: log()),
    "log_dark": ("Log (dark wood)", lambda: log("#4a3022", "#8a6040")),
    "stone": ("Stone block", stone_block),
    "fish": ("Fish", lambda: fish()),
    "fish_gold": ("Fish (gold)", lambda: fish("#e0a83a")),
    "berries": ("Berries", lambda: berries()),
    "berries_red": ("Berries (red)", lambda: berries("#c8303a")),
    "mushroom": ("Mushroom", lambda: mushroom()),
    "grain": ("Grain", grain),
    "hide": ("Hide", lambda: hide()),
}
