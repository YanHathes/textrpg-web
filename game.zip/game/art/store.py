"""Pictures drawn once and kept (step 18): people, their portraits, creatures and vehicles take a few
milliseconds each to draw in Python, and a town has hundreds of them. Once drawn, a picture (with its facings
and walking frames) is kept as raw RGBA bytes, squeezed:

    game/art/prerendered.db   shipped with the game (tools/make_art.py): every creature, vehicle and the
                              stock looks, drawn before the game ever starts. Read only.
    <data>/cache/art.db       this computer's own: everything else, the first time it's drawn.

A picture read back is a RawCanvas: its bytes go straight to the screen (ui/sprites.py) without becoming
Python pixels unless something asks for those (`.px`), when they're made then.

Keys carry a fingerprint of the drawing code (VERSION below, from the art modules' source), so a new version
of the art is drawn afresh and never mixed with the old.
"""
from __future__ import annotations

import hashlib
import sqlite3
import struct
import threading
import zlib
from pathlib import Path

from game.art.canvas import Canvas

HERE = Path(__file__).resolve().parent
SHIPPED = HERE / "prerendered.db"
_ART_FILES = ("canvas.py", "pixart.py", "folk.py", "faces.py", "doll.py", "beasts.py", "creatures.py",
              "vehicles.py", "portrait.py", "gear.py", "itemart.py")
_lock = threading.Lock()
_user: list = [None]             # the user cache's connection (configure())
_shipped: list = []              # the shipped file's connection, once looked for
_version: list = []
enabled = True                   # off: draw everything every time (the tests of the drawing code)


class RawCanvas(Canvas):
    """A Canvas whose pixels are kept as RGBA bytes until something reads `.px`."""

    def __init__(self, w: int, h: int | None = None, raw: bytes | None = None) -> None:
        if raw is None:                          # made like any other canvas
            super().__init__(w, h)
            raw = b""
        self.w, self.h = int(w), int(h if h is not None else w)
        self._raw = raw

    def __getattr__(self, name):
        if name == "px":                         # first asked for: made from the bytes, then a plain attribute
            raw = self.__dict__["_raw"]
            it = iter(raw)
            px = [None if a == 0 else (r, g, b, a) for r, g, b, a in zip(it, it, it, it)]
            self.__dict__["px"] = px
            return px
        raise AttributeError(name)

    def to_rgba_bytes(self) -> bytes:
        if "px" not in self.__dict__:
            return self._raw
        return Canvas.to_rgba_bytes(self)


def version() -> str:
    if not _version:
        h = hashlib.sha1()
        for name in _ART_FILES:
            try:
                h.update((HERE / name).read_bytes())
            except OSError:
                h.update(name.encode())
        _version.append(h.hexdigest()[:16])
    return _version[0]


def configure(folder) -> None:
    """Where this computer keeps the pictures it draws (None: nowhere, draw again each run)."""
    with _lock:
        if _user[0] is not None:
            _user[0].close()
            _user[0] = None
        if folder is None:
            return
        try:
            Path(folder).mkdir(parents=True, exist_ok=True)
            con = sqlite3.connect(str(Path(folder) / "art.db"), check_same_thread=False, isolation_level=None)
            con.execute("PRAGMA synchronous=OFF")
            con.execute("CREATE TABLE IF NOT EXISTS art (key TEXT PRIMARY KEY, data BLOB NOT NULL)")
            # pictures from other versions of the art are no use: let them go
            con.execute("DELETE FROM art WHERE substr(key, 1, 17) != ?", (version() + "|",))
            _user[0] = con
        except sqlite3.Error:
            _user[0] = None


def _shipped_db():
    if not _shipped:
        con = None
        if SHIPPED.exists():
            try:
                con = sqlite3.connect(f"file:{SHIPPED}?mode=ro", uri=True, check_same_thread=False)
            except sqlite3.Error:
                con = None
        _shipped.append(con)
    return _shipped[0]


def key_of(kind: str, key) -> str:
    return version() + "|" + kind + "|" + hashlib.sha1(repr(key).encode("utf-8")).hexdigest()


def cached(kind: str, key, make):
    """The picture for (kind, key): from the shipped file or this computer's, else make() and keep it."""
    if not enabled:
        return make()
    k = key_of(kind, key)
    for con in (_shipped_db(), _user[0]):
        if con is None:
            continue
        try:
            with _lock:
                row = con.execute("SELECT data FROM art WHERE key=?", (k,)).fetchone()
        except sqlite3.Error:
            row = None
        if row is not None:
            try:
                return decode(row[0])
            except Exception:          # noqa: BLE001 - a broken entry is drawn again
                break
    art = make()
    if _user[0] is not None:
        put(_user[0], k, art)
    return art


def put(con, k: str, art) -> None:
    try:
        with _lock:
            con.execute("INSERT OR REPLACE INTO art (key, data) VALUES (?, ?)", (k, encode(art)))
    except sqlite3.Error:
        pass


# ---- the bytes
def encode(art: Canvas) -> bytes:
    """A picture with its facings and walking frames: each different frame once, then which is which."""
    frames: list = []
    index: dict = {}

    def ix(c) -> int:
        if id(c) not in index:
            index[id(c)] = len(frames)
            frames.append(c)
        return index[id(c)]
    main = ix(art)
    views = {q: ix(c) for q, c in (getattr(art, "views", None) or {}).items()}
    steps = {q: [ix(c) for c in cs] for q, cs in (getattr(art, "steps", None) or {}).items()}
    out = bytearray(struct.pack("<HH", len(frames), main))
    for c in frames:
        raw = c.to_rgba_bytes()
        out += struct.pack("<HHI", c.w, c.h, len(raw)) + raw
    out += struct.pack("<H", len(views))
    for q, i in sorted(views.items()):
        out += struct.pack("<HH", q, i)
    out += struct.pack("<H", len(steps))
    for q, ixs in sorted(steps.items()):
        out += struct.pack("<HH", q, len(ixs)) + b"".join(struct.pack("<H", i) for i in ixs)
    return zlib.compress(bytes(out), 6)


def decode(data: bytes) -> Canvas:
    b = zlib.decompress(data)
    n, main = struct.unpack_from("<HH", b, 0)
    pos = 4
    frames = []
    for _ in range(n):
        w, h, size = struct.unpack_from("<HHI", b, pos)
        pos += 8
        frames.append(RawCanvas(w, h, b[pos:pos + size]))
        pos += size
    (nv,) = struct.unpack_from("<H", b, pos)
    pos += 2
    views = {}
    for _ in range(nv):
        q, i = struct.unpack_from("<HH", b, pos)
        pos += 4
        views[q] = frames[i]
    (ns,) = struct.unpack_from("<H", b, pos)
    pos += 2
    steps = {}
    for _ in range(ns):
        q, m = struct.unpack_from("<HH", b, pos)
        pos += 4
        steps[q] = [frames[struct.unpack_from("<H", b, pos + 2 * j)[0]] for j in range(m)]
        pos += 2 * m
    art = frames[main]
    if views:
        art.views = views
    if steps:
        art.steps = steps
    return art


__all__ = ["cached", "configure", "RawCanvas", "encode", "decode", "version", "SHIPPED"]
