"""The walking map's ground, water, walls, doors, windows and roofs, in the house style (game/art/pixart.py).

Every square is 16 x 16 art pixels (32 x 32 on screen). Floors tile seamlessly; water, walls and roofs look at
their four neighbours (mask bits N, E, S, W: that neighbour is the same) and draw their own edges. Walls stand up:
their top seen from above, and where nothing stands below them, a face turned toward you.
"""
from __future__ import annotations

from game.art.pixart import Px, c, rng, shade, alpha

N, E, S, W = 1, 2, 4, 8
A = 16                                  # art pixels a side


# ======================================================================
# Floors
# ======================================================================
def _grass(v: int) -> Px:
    base, dark, light, deep = c("#6aa840"), c("#538e36"), c("#8cc452"), c("#3e7030")
    r = rng("grass3", v)
    s = Px()
    s.rect(0, 0, 15, 15, base)
    for _ in range(3):                             # soft patches of a slightly different green
        cx, cy = r.randrange(16), r.randrange(16)
        tone = shade(base, r.choice((-0.05, 0.05)))
        for dy in range(-2, 3):
            for dx in range(-3, 4):
                if (dx / 3.2) ** 2 + (dy / 2.2) ** 2 <= 1:
                    s.p((cx + dx) % 16, (cy + dy) % 16, tone)
    for _ in range(13):                            # tufts: a two-pixel blade with a lit tip beside it
        x, y = r.randrange(16), r.randrange(16)
        s.p(x, y, dark)
        s.p(x, (y + 1) % 16, dark)
        s.p((x + 1) % 16, y, light if r.random() < 0.5 else dark)
    for _ in range(3):
        s.p(r.randrange(16), r.randrange(16), deep)
    if v % 4 == 1:                                 # a few flowers
        for _ in range(2):
            x, y = r.randrange(1, 15), r.randrange(1, 14)
            s.p(x, y, r.choice([c("#f4f0e0"), c("#f6d84a"), c("#c890e0")]))
            s.p(x, y + 1, dark)
    return s


def _ground(name: str, v: int, base, dark, light, pebble, specks: int = 18, pebbles: int = 3, tuft=None) -> Px:
    r = rng("ground3", name, v)
    s = Px()
    b, d, l_, pb = c(base), c(dark), c(light), c(pebble)
    s.rect(0, 0, 15, 15, b)
    for _ in range(specks):
        s.p(r.randrange(16), r.randrange(16), d if r.random() < 0.6 else l_)
    for _ in range(pebbles):                       # pebbles: a lit pixel over its shadow
        x, y = r.randrange(16), r.randrange(15)
        s.p(x, y, pb)
        s.p(x, y + 1, d)
    if tuft:                                       # a weed or two
        for _ in range(2):
            x, y = r.randrange(16), r.randrange(1, 16)
            s.p(x, y, c(tuft))
            s.p(x, y - 1, shade(c(tuft), 0.2))
    return s


def _sand(v: int) -> Px:
    s = _ground("sand", v, "#e4c88c", "#cfae70", "#f4e0b0", "#b89a68", 14, 2)
    r = rng("sand-ripple", v)
    for _ in range(3):                             # ripples blown by the wind
        x, y = r.randrange(16), r.randrange(16)
        for i in range(4):
            s.p((x + i) % 16, y, c("#d2b478"))
    return s


def _snow(v: int) -> Px:
    s = _ground("snow", v, "#eef3f8", "#d6e0ee", "#ffffff", "#b8c8dc", 10, 1)
    r = rng("snow-drift", v)
    for _ in range(2):                             # little drifts with a shaded underside
        x, y = r.randrange(16), r.randrange(15)
        for i in range(3):
            s.p((x + i) % 16, y, c("#ffffff"))
            s.p((x + i) % 16, y + 1, c("#d0dcec"))
    return s


def _cobble(v: int) -> Px:
    """Rounded setts in dark mortar, each a slightly different stone, lit on top; rows offset, and seamless."""
    r = rng("cobble3", v)
    s = Px()
    s.rect(0, 0, 15, 15, c("#4a4240"))
    tints = ["#a69e94", "#9a9488", "#b0a490", "#948c86", "#a89a8a"]
    rows = ((0, 5, ((0, 5), (5, 6), (11, 5))), (5, 5, ((14, 5), (3, 6), (9, 5))), (10, 6, ((0, 6), (6, 6), (12, 4))))
    for y0, h, stones in rows:
        for x0, w in stones:
            base = shade(c(r.choice(tints)), r.uniform(-0.06, 0.06))
            for yy in range(h):
                for xx in range(w):
                    if xx in (0, w - 1) and yy in (0, h - 1):
                        continue                    # rounded corners: the mortar shows
                    if xx == w - 1 or yy == h - 1:
                        continue                    # the joint on the right and below
                    col = base
                    if yy == 0 or xx == 0:
                        col = shade(base, 0.22)
                    elif yy == h - 2 or xx == w - 2:
                        col = shade(base, -0.2)
                    s.p((x0 + xx) % 16, y0 + yy, col)
    return s


def _planks(v: int, base="#b0703e", seam="#6a3e22") -> Px:
    r = rng("planks3", v, base)
    s = Px()
    for row in range(4):                           # four boards, their butt joints staggered
        y0 = row * 4
        tone = shade(c(base), (row % 2) * -0.06 + r.uniform(-0.03, 0.03))
        s.rect(0, y0, 15, y0 + 3, tone)
        s.hline(0, 15, y0, shade(tone, 0.16))
        s.hline(0, 15, y0 + 3, c(seam))
        j = (row * 5 + v * 7 + 3) % 16
        s.vline(j, y0, y0 + 2, c(seam))
        s.p((j + 1) % 16, y0 + 1, c("#d8b06a"))     # a nail by the joint
        for _ in range(2):                         # grain
            x = r.randrange(16)
            s.hline(x, min(15, x + r.randint(1, 3)), y0 + 2, shade(tone, -0.1))
    return s


def _flags(v: int, base="#8e8a86", mortar="#625c5a", cracks: bool = False, moss: bool = False) -> Px:
    r = rng("flags3", v, base)
    s = Px()
    s.rect(0, 0, 15, 15, c(mortar))
    slabs = ((0, 0, 8, 7), (9, 0, 15, 5), (9, 6, 15, 12), (0, 8, 5, 15), (6, 8, 8, 15), (9, 13, 15, 15))
    if v % 2:
        slabs = tuple((15 - x1 + 0, y0, 15 - x0 + 0, y1) for (x0, y0, x1, y1) in slabs)
    for (x0, y0, x1, y1) in slabs:
        tone = shade(c(base), r.uniform(-0.06, 0.06))
        s.rect(x0, y0, x1 - 1, y1 - 1, tone)
        s.hline(x0, x1 - 1, y0, shade(tone, 0.18))
        s.vline(x1 - 1, y0, y1 - 1, shade(tone, -0.14))
    if cracks and v % 3 == 0:
        x, y = r.randint(2, 12), r.randint(2, 10)
        for _ in range(4):
            s.p(x, y, c(mortar))
            x, y = x + r.choice((-1, 0, 1)), y + 1
    if moss:
        s.speckle(r, 5, ["#4e6a3a", "#5e7a44"])
    return s


def _cave(v: int) -> Px:
    s = _ground("cave", v, "#5a5048", "#463e38", "#6e6458", "#8a7e70", 24, 4)
    r = rng("cave-rocks", v)
    if v % 3 == 2:                                 # a loose stone
        x, y = r.randint(3, 11), r.randint(3, 11)
        s.rect(x, y, x + 2, y + 1, c("#7e7468"))
        s.hline(x, x + 2, y, c("#9a8e80"))
        s.hline(x, x + 2, y + 2, c("#3a3430"))
    return s


def _carpet(v: int) -> Px:
    s = Px()
    red, dk, gold = c("#a8342e"), c("#7a2024"), c("#e0b04a")
    s.rect(0, 0, 15, 15, red)
    for i in range(16):                            # a woven diamond, seamless
        for j in range(16):
            d = abs((i % 8) - 4) + abs((j % 8) - 4)
            if d == 4:
                s.p(i, j, dk)
            elif d == 1:
                s.p(i, j, gold)
            elif d == 0:
                s.p(i, j, c("#f0d080"))
    return s


def _ford(v: int) -> Px:
    """Shallow water over a stony bottom."""
    r = rng("ford3", v)
    s = Px()
    s.rect(0, 0, 15, 15, c("#5a9ab4"))
    for _ in range(5):                             # stones under the water
        x, y = r.randrange(16), r.randrange(15)
        s.rect(x, y, (x + 1) % 16 if x < 15 else 15, y, c("#8ab0bc"))
        s.p(x, y + 1, c("#4a8098"))
    for _ in range(3):                             # ripples
        x, y = r.randrange(13), r.randrange(16)
        s.hline(x, x + 2, y, c("#b0dcea"))
    return s


FLOORS = {
    "grass": ("Grass", _grass, 4),
    "dirt": ("Dirt", lambda v: _ground("dirt", v, "#946240", "#7a4e32", "#ae7a52", "#c8a080"), 3),
    "sand": ("Sand", _sand, 3),
    "snow": ("Snow", _snow, 3),
    "cobble": ("Cobblestone", _cobble, 3),
    "wood": ("Wooden floor", _planks, 3),
    "stone": ("Stone floor", lambda v: _flags(v), 2),
    "dungeon": ("Dungeon floor", lambda v: _flags(v, "#6e7078", "#3e3c44", cracks=True, moss=v == 2), 3),
    "cave": ("Cave floor", _cave, 3),
    "carpet": ("Carpet", _carpet, 1),
    "path": ("Dirt path", lambda v: _ground("path", v, "#c09468", "#a87c54", "#d4ac80", "#e2c49c", 14, 3), 3),
    "track": ("Track", lambda v: _ground("track", v, "#a88a5a", "#8e7248", "#c0a070", "#d0b890", 16, 2,
                                         tuft="#5e9a3a"), 3),
    "ford": ("Ford", _ford, 3),
    "ash": ("Ash", lambda v: _ground("ash", v, "#4e4844", "#38322e", "#625a54", "#7a706a", 22, 2), 3),
}


def floor(kind: str, v: int = 0) -> Px:
    label, fn, n = FLOORS.get(kind, FLOORS["grass"])
    return fn(v % n)


# where one natural ground meets another, the one higher here spills over the edge onto the other
SPILL = {"cave": 1, "cobble": 2, "dirt": 2, "track": 3, "path": 3, "sand": 4, "grass": 6, "snow": 7}


def fringe(kind: str, mask: int, v: int = 0) -> Px:
    """The ragged edge of `kind` (grass, snow...) spilling onto a square from the sides in mask; see-through
    elsewhere. Laid over the square's own floor."""
    src = floor(kind, v)
    r = rng("fringe3", kind, mask, v)
    s = Px()
    reach = [[0.0] * 16 for _ in range(16)]
    narrow = (mask & N and mask & S) or (mask & E and mask & W)      # spilling from both sides: a light touch
    pick = (0, 0, 0, 1) if narrow else (0, 0, 1, 1, 2)
    jag = [1 + r.choice(pick) for _ in range(16)]
    jag2 = [1 + r.choice(pick) for _ in range(16)]
    for y in range(16):
        for x in range(16):
            best = 99
            if mask & N:
                best = min(best, y - jag[x])
            if mask & S:
                best = min(best, (15 - y) - jag2[x])
            if mask & W:
                best = min(best, x - jag[y])
            if mask & E:
                best = min(best, (15 - x) - jag2[y])
            reach[y][x] = best
    lip = shade(src.get(8, 8), -0.3)
    for y in range(16):
        for x in range(16):
            if reach[y][x] < 0:
                s.p(x, y, src.get(x, y))
            elif reach[y][x] < 1:
                s.p(x, y, alpha(lip, 150))         # the shadowed lip where it overhangs
    return s


# ======================================================================
# Water, with banks
# ======================================================================
WATER = {
    #        deep        body        glint       bank        bank shade  foam
    "water": ("#2c6aa0", "#3c84b8", "#8cc8e8", "#d8bc80", "#a88a58", "#e8f4f8"),
    "sea": ("#1e4e86", "#2a64a0", "#7ab4dc", "#e2c890", "#b09460", "#f4fbff"),
    "swamp": ("#3a4a2e", "#4a5a36", "#7a8a52", "#6a5a3a", "#4a3e2a", "#8a9a5a"),
    "sky": ("#8cc0e4", "#a8d4f0", "#ffffff", "#6a4a2e", "#4a321e", "#e8f4ff"),
}


def water(mask: int, v: int = 0, kind: str = "water") -> Px:
    """mask: which neighbours are water too. Open edges get a bank and a lip of foam."""
    deep, body, glint, bank, bank_d, foam = (c(h) for h in WATER.get(kind, WATER["water"]))
    r = rng("water3", mask, v, kind)
    s = Px()
    s.rect(0, 0, 15, 15, body)
    for y in range(16):                            # darker bands in the middle of the water
        for x in range(16):
            if (x + 2 * y + v * 3) % 11 == 0:
                s.p(x, y, deep)
    if kind == "sky":                              # clouds drifting below
        for _ in range(2):
            x, y = r.randrange(12), r.randrange(3, 13)
            s.hline(x, x + 4, y, glint)
            s.hline(x + 1, x + 3, y - 1, glint)
            s.hline(x, x + 4, y + 1, shade(body, 0.3))
    else:
        for _ in range(3):                         # glints
            x, y = r.randrange(1, 12), r.randrange(2, 14)
            s.hline(x, x + 2, y, glint)
            s.p(x + 1, y + 1, shade(body, -0.1))
    if kind == "swamp":
        for _ in range(2):                         # lily pads and a bloom
            x, y = r.randrange(2, 13), r.randrange(3, 13)
            s.disc(x + 1, y + 1, 1.6, 1.1, c("#5e8a3a"))
            s.p(x, y, c("#7aa84a"))
            if r.random() < 0.4:
                s.p(x + 1, y, c("#f0c0d0"))
        for _ in range(2):                         # reeds standing in it
            x, y = r.randrange(1, 15), r.randrange(4, 15)
            s.vline(x, y - 3, y, c("#6a8a3a"))
            s.p(x, y - 4, c("#7a5a2e"))
    for bit, side in ((N, "n"), (E, "e"), (S, "s"), (W, "w")):
        if mask & bit:
            continue
        for i in range(16):
            wob = (i * 5 + bit * 3 + v) % 4 == 0
            depth = 3 if wob else 2
            for d in range(depth + 1):
                x, y = {"n": (i, d), "s": (i, 15 - d), "e": (15 - d, i), "w": (d, i)}[side]
                if d < depth:
                    s.p(x, y, bank_d if (d == depth - 1 and side in "nw") or (d == 0 and side in "se") else bank)
                else:
                    s.p(x, y, foam if (i + v) % 3 else glint)
        if side == "n" and kind in ("water", "swamp"):     # reeds along the far bank
            for x in (3, 10):
                if r.random() < 0.6:
                    s.vline(x, 0, 2, c("#4e8a3a"))
                    s.p(x, 0, c("#8a5a2e"))
    return s


# ======================================================================
# Walls: a top seen from above, and a face toward you where nothing stands below
# ======================================================================
WALLS = {
    #               label           body        shade       light
    "stone_wall": ("Stone wall", "#a49c94", "#7e766e", "#c8c0b4"),
    "wood_wall": ("Wooden wall", "#9a6236", "#74452a", "#c08850"),
    "rock_wall": ("Cave rock", "#8a7c70", "#665a50", "#ae9e8c"),
    "brick_wall": ("Brick wall", "#b0563e", "#843a2e", "#d07a5a"),
    "hedge": ("Hedge", "#4e8a3a", "#36662c", "#78b052"),
}
CAP = 7                                  # art rows of top a facing wall shows above its face
ROUNDED = ("rock_wall", "hedge")


def _wall_top(s: Px, kind: str, y1: int, mask: int) -> None:
    label, body, dark, light = WALLS[kind]
    cap = shade(c(body), 0.2)
    r = rng("walltop3", kind, mask)
    s.rect(0, 0, 15, y1, cap)
    joint = shade(cap, -0.2)
    if kind == "stone_wall":                       # big capstones
        for y in range(0, y1 + 1, 5):
            s.hline(0, 15, y + 4, joint)
            off = 0 if (y // 5) % 2 else 4
            for x in range(off, 16, 8):
                s.vline(x, y, y + 3, joint)
                s.p(x + 1, y, shade(cap, 0.25))
    elif kind == "brick_wall":
        for y in range(0, y1 + 1, 3):
            s.hline(0, 15, y + 2, joint)
            for x in range(2 if (y // 3) % 2 else 6, 16, 8):
                s.vline(x, y, y + 1, joint)
    elif kind == "wood_wall":                      # the tops of upright logs: rings
        for x in range(0, 16, 4):
            s.vline(x, 0, y1, joint)
            s.p(x + 2, 1, shade(cap, 0.25))
        for _ in range(4):
            s.p(r.randrange(16), r.randrange(y1 + 1), shade(cap, -0.1))
    elif kind == "rock_wall":
        s.speckle(r, 22, [shade(cap, -0.18), shade(cap, 0.15), c(dark)], 0, 0, 15, y1)
        for _ in range(3):
            x, y = r.randrange(2, 13), r.randrange(0, max(1, y1 - 1))
            s.hline(x, x + 2, y, shade(cap, 0.25))
            s.hline(x, x + 2, y + 1, shade(cap, -0.2))
    else:                                          # hedge: leaf clumps
        s.speckle(r, 34, [light, c(dark), shade(c(body), 0.1)], 0, 0, 15, y1)
        for _ in range(3):
            s.p(r.randrange(16), r.randrange(y1 + 1), c("#f4f0e0") if r.random() < 0.5 else c("#e890b0"))


def _wall_face(s: Px, kind: str, y0: int) -> None:
    label, body, dark, light = WALLS[kind]
    base, dk, lt = shade(c(body), -0.12), shade(c(dark), -0.12), c(light)
    r = rng("wallface3", kind)
    s.rect(0, y0, 15, 15, base)
    if kind == "stone_wall":                       # coursed blocks
        for row, y in enumerate(range(y0 + 1, 16, 3)):
            s.hline(0, 15, min(15, y + 2), dk)
            for x in range((row % 2) * 4, 16, 8):
                s.vline(x, y, min(15, y + 2), dk)
                s.p(x + 1, y, lt)
    elif kind == "brick_wall":
        for row, y in enumerate(range(y0 + 1, 16, 2)):
            s.hline(0, 15, min(15, y + 1), c("#d8c0a8"))
            for x in range((row % 2) * 2, 16, 4):
                s.p(x, y, c("#d8c0a8"))
    elif kind == "wood_wall":                      # upright boards, a beam across
        for x in range(0, 16, 4):
            s.vline(x, y0 + 1, 15, dk)
            s.p(x + 1, y0 + 2, lt)
        s.hline(0, 15, y0 + 4, shade(dk, -0.1))
        s.p(2, y0 + 4, c("#d8b06a"))
        s.p(10, y0 + 4, c("#d8b06a"))
    elif kind == "rock_wall":                      # rough rock with cracks
        s.speckle(r, 16, [dk, shade(base, 0.12)], 0, y0 + 1, 15, 15)
        for x in (3, 9, 13):
            s.vline(x, y0 + 2, y0 + 5, dk)
            s.p(x + 1, y0 + 2, lt)
    else:                                          # hedge
        s.speckle(r, 26, [dk, lt, shade(base, 0.08)], 0, y0 + 1, 15, 15)
    s.hline(0, 15, y0, c("#3a2a24"))               # the edge where the top meets the face
    s.hline(0, 15, 15, shade(dk, -0.25))            # its foot on the ground


def wall(kind: str, mask: int) -> Px:
    """mask: which neighbours are wall (or a door) too."""
    if kind not in WALLS:
        kind = "stone_wall"
    label, body, dark, light = WALLS[kind]
    s = Px()
    face = not (mask & S)
    top_y1 = CAP - 1 if face else 15
    _wall_top(s, kind, top_y1, mask)
    if face:
        _wall_face(s, kind, CAP)
    rim = c("#3a2a24")
    if not (mask & N):
        s.hline(0, 15, 0, shade(c(dark), -0.3))
        s.hline(0, 15, 1, c(light))
    if not (mask & W):
        s.vline(0, 0, 15, shade(c(dark), -0.3))
        s.vline(1, 1 if not (mask & N) else 0, top_y1, c(light))
    if not (mask & E):
        s.vline(15, 0, 15, rim)
        s.vline(14, 0, top_y1, shade(c(body), -0.05))
    if kind in ROUNDED:                            # natural walls: rounded outer corners, the floor shows
        for (bx, by, cx, cy) in ((N, W, 0, 0), (N, E, 15, 0), (S, W, 0, 15), (S, E, 15, 15)):
            if mask & bx or mask & by:
                continue
            for (dx, dy) in ((0, 0), (1, 0), (0, 1)):
                s.clear(abs(cx - dx), abs(cy - dy))
            s.p(abs(cx - 1), abs(cy - 1), shade(c(dark), -0.3))
            s.p(abs(cx - 2), abs(cy - 0), shade(c(dark), -0.3))
            s.p(abs(cx - 0), abs(cy - 2), shade(c(dark), -0.3))
    return s


def wall_has_face(mask: int) -> bool:
    return not (mask & S)


# ---- doors and windows
DOOR_WOOD = {"wood_wall": "#8a5432", "stone_wall": "#7a4a2a", "brick_wall": "#7a4a2a", "rock_wall": "#6a5040",
             "hedge": "#8a5432"}


def door(wall_kind: str, opened: bool, horizontal: bool = True, gate: bool = False) -> Px:
    """A door in a doorway. horizontal: the wall runs left to right, and we see the door's face; otherwise we
    look down on it edge-on."""
    if wall_kind not in WALLS:
        wall_kind = "stone_wall"
    label, body, dark, light = WALLS[wall_kind]
    wood = c("#5e646e") if gate else c(DOOR_WOOD.get(wall_kind, "#7a4a2a"))
    s = Px()
    if horizontal:
        cap = shade(c(body), 0.2)
        s.rect(0, 0, 15, CAP - 1, cap)              # the lintel, continuing the wall's top
        s.hline(0, 15, 0, shade(c(dark), -0.3))
        s.hline(0, 15, 1, c(light))
        s.rect(0, CAP, 1, 15, shade(c(body), -0.12))     # the jambs
        s.rect(14, CAP, 15, 15, shade(c(body), -0.12))
        s.hline(0, 15, CAP, c("#3a2a24"))
        if opened:
            s.rect(2, CAP + 1, 13, 15, c("#2a1e1a"))          # dark within
            s.rect(2, CAP + 1, 3, 15, wood)                  # the leaf swung back
            s.vline(2, CAP + 1, 15, shade(wood, 0.2))
            for y in range(CAP + 4, 16, 3):
                s.hline(4, 13, y, alpha("#ffe8b0", 30))
        else:
            s.rect(2, CAP + 1, 13, 15, wood)
            s.hline(2, 13, CAP + 1, shade(wood, 0.18))
            for x in (5, 8, 11):
                s.vline(x, CAP + 1, 15, shade(wood, -0.18))
            if gate:
                for x in range(3, 13, 2):
                    s.vline(x, CAP + 1, 15, c("#8a929a"))
                s.hline(2, 13, CAP + 4, c("#8a929a"))
            else:
                s.hline(2, 13, CAP + 3, c("#4a4448"))          # iron straps
                s.hline(2, 13, CAP + 7, c("#4a4448"))
                s.p(11, CAP + 5, c("#e8c060"))               # the ring handle
                s.p(11, CAP + 6, c("#a07a30"))
    else:
        cap = shade(c(body), 0.2)
        s.rect(5, 0, 10, 2, cap)                    # the jambs at either end, seen from above
        s.rect(5, 13, 10, 15, cap)
        s.hline(5, 10, 0, c(light))
        s.hline(5, 10, 15, shade(c(dark), -0.3))
        if opened:
            s.rect(10, 3, 12, 11, wood)              # the leaf swung back against the wall
            s.vline(10, 3, 11, shade(wood, 0.2))
            s.vline(13, 3, 11, alpha("#1a1418", 70))
        else:
            s.rect(7, 3, 8, 12, wood)
            s.vline(7, 3, 12, shade(wood, 0.2))
            if gate:
                for y in range(3, 13, 2):
                    s.p(8, y, c("#8a929a"))
    return s


def window(kind: str, mask: int, horizontal: bool = True) -> Px:
    """A wall square with a glazed window in it: in the face where the wall shows one, else a slit in its top."""
    s = wall(kind, mask)
    label, body, dark, light = WALLS.get(kind, WALLS["stone_wall"])
    frame, glass, gl = c("#5a3a22"), c("#8ab8d8"), c("#e8f6ff")
    if horizontal and wall_has_face(mask):
        s.rect(4, CAP + 2, 11, CAP + 7, frame)
        s.rect(5, CAP + 3, 10, CAP + 6, glass)
        s.vline(7, CAP + 3, CAP + 6, frame)
        s.p(5, CAP + 3, gl)
        s.p(8, CAP + 3, gl)
        s.hline(3, 12, CAP + 8, shade(c(light), 0.1))     # the sill
    elif horizontal:
        s.rect(3, 6, 12, 9, frame)
        s.rect(4, 7, 11, 8, glass)
        s.hline(4, 7, 7, gl)
    else:
        s.rect(6, 3, 9, 12, frame)
        s.rect(7, 4, 8, 11, glass)
        s.vline(7, 4, 7, gl)
    return s


# ======================================================================
# Roofs (seen from above, before you step inside)
# ======================================================================
ROOF_STYLES = {
    "Wooden": ("Shingles", "#8a5432"), "Rustic": ("Thatch", "#c8a050"), "Stone": ("Slate", "#56606e"),
    "Rich": ("Red tile", "#b84a32"), "Brick": ("Terracotta", "#c0683e"), "Tent": ("Canvas", "#d8c8a0"),
}


def roof(style: str, mask: int, v: int = 0) -> Px:
    label, color = ROOF_STYLES.get(style, ROOF_STYLES["Wooden"])
    base = c(color)
    r = rng("roof3", style, v)
    s = Px()
    s.rect(0, 0, 15, 15, base)
    if label == "Thatch":                          # layered straw, each layer's lip in shade
        for y0 in range(0, 16, 5):
            for x in range(16):
                ln = r.randint(2, 4)
                tone = shade(base, r.uniform(-0.1, 0.12))
                s.vline(x, y0, min(15, y0 + ln), tone)
            s.hline(0, 15, min(15, y0 + 4), shade(base, -0.25))
    elif label == "Canvas":                        # stripes and seams
        for x in range(16):
            if (x // 4) % 2 == 1:
                s.vline(x, 0, 15, c("#b84a3a"))
        for x in range(0, 16, 4):
            s.vline(x, 0, 15, shade(base, -0.2) if (x // 4) % 2 == 0 else shade(c("#b84a3a"), -0.2))
    else:
        rows, wide = (4, 4) if label in ("Slate", "Shingles") else (4, 3)
        for row in range(16 // rows):
            y0 = row * rows
            off = (wide // 2) * (row % 2) + v % 2
            for x0 in range(-wide, 16, wide):
                tone = shade(base, r.uniform(-0.07, 0.07))
                xs = range(x0 + off, x0 + off + wide)
                for x in xs:
                    if 0 <= x < 16:
                        s.vline(x, y0, y0 + rows - 1, tone)
                if label == "Red tile":            # rounded tiles: lit crown, shaded sides
                    mid = x0 + off + wide // 2
                    if 0 <= mid < 16:
                        s.vline(mid, y0, y0 + rows - 2, shade(tone, 0.22))
                    if 0 <= x0 + off < 16:
                        s.vline(x0 + off, y0, y0 + rows - 1, shade(tone, -0.22))
                elif label == "Terracotta":
                    if 0 <= x0 + off < 16:
                        s.vline(x0 + off, y0, y0 + rows - 1, shade(tone, 0.2))
                else:
                    if 0 <= x0 + off < 16:
                        s.vline(x0 + off, y0, y0 + rows - 2, shade(tone, -0.18))
            s.hline(0, 15, y0, shade(base, 0.1))
            s.hline(0, 15, y0 + rows - 1, shade(base, -0.25))
    for bit in (N, E, S, W):                       # eaves: lit along the top, dark overhang below and right
        if mask & bit:
            continue
        if bit == N:
            s.hline(0, 15, 0, shade(base, -0.45))
            s.hline(0, 15, 1, shade(base, 0.2))
        elif bit == W:
            s.vline(0, 0, 15, shade(base, -0.45))
            s.vline(1, 0, 15, shade(base, 0.12))
        elif bit == S:
            s.hline(0, 15, 14, shade(base, -0.3))
            s.hline(0, 15, 15, shade(base, -0.55))
        else:
            s.vline(15, 0, 15, shade(base, -0.55))
    return s


def earth(v: int = 0) -> Px:
    """Solid ground below the cellars: what's not dug out."""
    s = _ground("earth", v, "#2a241e", "#1e1a16", "#3a3028", "#4a4036", 30, 3)
    return s


# ======================================================================
# The weather on the ground, and the seasons
# ======================================================================
OUTDOOR_FLOORS = {"grass", "dirt", "sand", "path", "track", "cobble", "snow", "ford"}
SOFT_FLOORS = {"dirt", "path", "track", "sand"}


def ground(kind: str, floor_kind: str, v: int = 0) -> Px:
    """What the weather has done to a square of open ground (laid over its floor): wet, puddles (mud on soft
    ground), snow, frost or cracks. See-through where it leaves the ground be."""
    r = rng("weather3", kind, floor_kind, v)
    s = Px()
    if floor_kind not in OUTDOOR_FLOORS or not kind:
        return s
    if kind == "wet":
        s.rect(0, 0, 15, 15, (10, 16, 30, 60))
        for _ in range(2):
            x, y = r.randrange(12), r.randrange(16)
            s.hline(x, x + r.randint(1, 3), y, (220, 232, 255, 60))
    elif kind == "puddles":
        s.rect(0, 0, 15, 15, (10, 16, 30, 26))
        if floor_kind in SOFT_FLOORS and v % 4 == 0:
            for _ in range(2):
                s.disc(r.randrange(16), r.randrange(16), r.uniform(1, 2.5), r.uniform(0.8, 1.5), (60, 40, 22, 90))
        if v % 7 == 3:
            cx, cy = r.uniform(5, 11), r.uniform(5, 11)
            rx, ry = r.uniform(3.5, 5.5), r.uniform(2, 3)
            s.disc(cx, cy + 0.5, rx, ry, (40, 54, 80, 200))
            s.disc(cx, cy, rx, ry, (80, 110, 150, 210))
            s.hline(int(cx - rx / 2), int(cx), int(cy - ry / 2), (190, 214, 236, 220))
    elif kind == "snow":
        base = (240, 245, 252, 245) if floor_kind not in ("cobble", "path", "track") else (230, 236, 246, 220)
        s.rect(0, 0, 15, 15, base)
        s.speckle(r, 12, [(212, 224, 240, 245)])
        for _ in range(v % 3):                     # where the ground shows through
            x, y = r.randrange(15), r.randrange(15)
            s.clear(x, y)
            s.clear(x + 1, y)
            s.p(x, y + 1, (200, 214, 232, 230))
    elif kind == "frost":
        s.rect(0, 0, 15, 15, (220, 232, 248, 40))
        s.speckle(r, 22, [(236, 244, 252, 170)])
    elif kind == "cracked":
        if floor_kind == "grass":
            s.rect(0, 0, 15, 15, (200, 176, 80, 80))          # parched
        if floor_kind in ("grass", "dirt", "sand", "path", "track") and v % 3 == 0:
            x, y = r.randint(3, 12), r.randint(3, 12)
            for _ in range(5):
                s.p(x, y, (90, 62, 36, 150))
                x, y = x + r.choice((-1, 1)), y + r.choice((-1, 0, 1))
    return s


def season(season_name: str, floor_kind: str, v: int = 0) -> Px:
    """How the season shows on grass: spring flowers, autumn's fallen leaves, winter's dull grass."""
    r = rng("season3", season_name, floor_kind, v)
    s = Px()
    if floor_kind != "grass":
        return s
    if season_name == "Spring" and v % 5 in (0, 2):
        for _ in range(r.randint(1, 3)):
            x, y = r.randrange(1, 15), r.randrange(1, 14)
            col = r.choice([(240, 140, 180, 255), (250, 230, 110, 255), (250, 250, 250, 255), (170, 150, 240, 255)])
            s.p(x, y, col)
            s.p(x + 1, y, shade(col, -0.15))
            s.p(x, y + 1, (62, 112, 48, 255))
    elif season_name == "Autumn":
        s.rect(0, 0, 15, 15, (190, 140, 50, 45))
        for _ in range(r.randint(1, 3)):
            col = r.choice([(214, 110, 36, 255), (226, 172, 52, 255), (170, 58, 34, 255)])
            x, y = r.randrange(15), r.randrange(15)
            s.p(x, y, col)
            s.p(x + 1, y, shade(col, -0.2))
    elif season_name == "Winter":
        s.rect(0, 0, 15, 15, (150, 140, 110, 60))
    return s


__all__ = ["FLOORS", "WALLS", "WATER", "ROOF_STYLES", "SPILL", "OUTDOOR_FLOORS", "SOFT_FLOORS", "CAP",
           "floor", "fringe", "water", "wall", "wall_has_face", "door", "window", "roof", "earth", "ground",
           "season"]


def flames(variant: int = 0, size: int = 2) -> Px:
    """Fire on a square (game/fire.py), laid over whatever is burning: tongues of flame, taller the bigger it
    is (1 smouldering, 2 burning, 3 roaring), in two frames that flicker."""
    r = rng("flames3", variant, size)
    s = Px(16, 24)
    reds = [c("#a8281e"), c("#d8402e"), c("#f08a30"), c("#f6c040"), c("#fff0a0")]
    tongues = {1: 3, 2: 5, 3: 7}.get(size, 5)
    tall = {1: 5, 2: 10, 3: 16}.get(size, 10)
    for _ in range(tongues):
        cx = r.randint(3, 12)
        h = r.randint(max(2, tall // 2), tall)
        base = 22 - r.randint(0, 3)
        for i in range(h):
            y = base - i
            half = max(0, int((h - i) * 0.35))
            for x in range(cx - half, cx + half + 1):
                k = min(4, max(0, (h - i) * 4 // max(1, h) - abs(x - cx)))
                if s.get(x, y) is None or k > 2:
                    s.p(x, y, reds[4 - k] if i > h // 3 else reds[min(4, k + 1)])
            if variant % 2 and i == h - 1:
                cx += r.choice((-1, 1))
    for _ in range(size * 3):                                    # sparks
        s.p(r.randint(1, 14), r.randint(0, 22 - tall), alpha(reds[3], 180))
    return s


def cracks(stage: int = 1) -> Px:
    """Cracks across a battered wall or thing (game/destruction.py): a few hairlines, or splits right through."""
    r = rng("cracks3", stage)
    s = Px()
    dark = alpha(c("#1a1410"), 200)
    n = 2 if stage <= 1 else 4
    for _ in range(n):
        x, y = r.randint(2, 13), r.randint(1, 5)
        for _i in range(r.randint(5, 9) + stage * 2):
            s.p(x, y, dark)
            x = max(0, min(15, x + r.choice((-1, 0, 0, 1))))
            y += 1
            if y > 15:
                break
    if stage >= 2:
        for _ in range(3):
            s.rect(r.randint(2, 12), r.randint(8, 13), r.randint(2, 12) + 1, r.randint(8, 13) + 1,
                   alpha(c("#0e0a08"), 220))
    return s


def trap(kind: str, status: str = "seen") -> Px:
    """A dungeon trap the party knows of (game/traps.py), drawn over the floor: a red-ringed warning while
    it's set; done with (disarmed) greyed and still; an open pit once one's been sprung."""
    s = Px()
    metal, dark, warn = c("#8a8e96"), c("#2a2228"), c("#d84a3a")
    done = status in ("disarmed", "sprung")
    if kind == "pit" and status == "sprung":
        s.rect(2, 3, 13, 13, c("#141016"))                   # the open pit
        s.hline(2, 13, 3, c("#5a4a44"))
        s.vline(2, 3, 13, c("#3a302e"))
        s.vline(13, 3, 13, c("#3a302e"))
        s.rect(4, 9, 11, 13, c("#0a080c"))
        s.p(5, 11, c("#6a6a70"))
        s.p(9, 10, c("#6a6a70"))                             # spikes glinting at the bottom
        return s
    if kind == "glyph":
        col = c("#6a6a80") if done else c("#9ad8ff")
        s.disc(8, 8, 5, 5, alpha(col, 50))
        for x0, y0, x1, y1 in ((8, 3, 8, 13), (3, 8, 13, 8), (5, 5, 11, 11), (11, 5, 5, 11)):
            s.line(x0, y0, x1, y1, alpha(col, 200))
        s.disc(8, 8, 2, 2, col)
    elif kind in ("darts", "gas", "block", "flame", "pit"):
        plate = shade(metal, -0.1) if not done else c("#5a5a5e")
        s.rect(4, 4, 11, 11, shade(plate, -0.35))            # a pressure plate, a little proud of the floor
        s.rect(5, 5, 10, 10, plate)
        s.hline(5, 10, 5, shade(plate, 0.25))
        if kind == "flame":
            for x, y in ((3, 3), (12, 3), (3, 12), (12, 12)):
                s.p(x, y, dark)
                s.p(x, y - 1 if y > 3 else y + 1, c("#c8702a") if not done else dark)
        elif kind == "gas":
            for x in (2, 13):
                for y in (5, 8, 11):
                    s.p(x, y, c("#6aa04a") if not done else dark)
        elif kind == "darts":
            for x in (1, 14):
                for y in (6, 9):
                    s.p(x, y, dark)
        elif kind == "block":
            s.rect(6, 6, 9, 9, shade(plate, -0.2))
    else:                                                    # a tripwire (blade, alarm)
        wire = c("#c8c0a8") if not done else c("#6a6460")
        if done:
            s.line(1, 9, 6, 11, wire)                         # cut, hanging slack
            s.line(14, 9, 10, 11, wire)
        else:
            s.hline(1, 14, 9, wire)
        s.rect(0, 8, 1, 10, metal)
        s.rect(14, 8, 15, 10, metal)
        if kind == "alarm":
            s.disc(13, 4, 2, 2, c("#c8a040"))                 # the bell
            s.vline(13, 6, 8, wire)
    if not done:                                             # a warning ring round it
        for i in range(16):
            for x, y in ((i, 0), (i, 15), (0, i), (15, i)):
                if (x + y) % 3 == 0:
                    s.p(x, y, alpha(warn, 230))
    return s
