"""The start-up splash picture: a dusk mountain scene, a party of heroes, a dragon, and the title in a
hand-made pixel font. Pure pixel art (a Canvas), so it can be previewed without Qt."""
from __future__ import annotations

import random

from game.art.canvas import Canvas, mix
from game.art.doll import Gear, Look, compose
from game.art import creatures as CR
from game.art.scenes import SceneSpec, paint

W, H = 320, 180
TITLE = "YanCo"
SUBTITLE = "Branded RPG"

# 5 x 7 pixel glyphs ("#" = ink). Only what the title needs, plus a few spares.
GLYPHS = {
    "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.."],
    "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###."],
    "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."],
    "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"],
    "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#...."],
    "G": [".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".####"],
    "a": [".....", ".....", ".###.", "....#", ".####", "#...#", ".####"],
    "n": [".....", ".....", "####.", "#...#", "#...#", "#...#", "#...#"],
    "o": [".....", ".....", ".###.", "#...#", "#...#", "#...#", ".###."],
    "r": [".....", ".....", "#.##.", "##..#", "#....", "#....", "#...."],
    "d": ["....#", "....#", ".####", "#...#", "#...#", "#...#", ".####"],
    "e": [".....", ".....", ".###.", "#...#", "#####", "#....", ".###."],
    " ": [".....", ".....", ".....", ".....", ".....", ".....", "....."],
}


def text_width(text: str, scale: int, gap: int = 1) -> int:
    return len(text) * (5 + gap) * scale - gap * scale


def draw_text(c: Canvas, text: str, x: int, y: int, scale: int, top, bottom, gap: int = 1) -> None:
    """Pixel text with a top-to-bottom colour fade, a dark outline and a drop shadow."""
    layer = Canvas(c.w, c.h)
    for i, ch in enumerate(text):
        rows = GLYPHS.get(ch) or GLYPHS[" "]
        ox = x + i * (5 + gap) * scale
        for ry, row in enumerate(rows):
            col = mix(top, bottom, ry / 6.0)
            for rx, bit in enumerate(row):
                if bit == "#":
                    layer.rect(ox + rx * scale, y + ry * scale, ox + rx * scale + scale - 1,
                               y + ry * scale + scale - 1, col)
                    # a bright highlight on the top edge of each stroke
                    if ry == 0 or rows[ry - 1][rx] != "#":
                        layer.rect(ox + rx * scale, y + ry * scale, ox + rx * scale + scale - 1, y + ry * scale,
                                   mix(col, "#ffffff", 0.45))
    shadow = Canvas(c.w, c.h)
    for yy in range(c.h):
        for xx in range(c.w):
            if layer.opaque(xx, yy):
                shadow.set(xx + max(1, scale // 2), yy + max(1, scale // 2), (12, 8, 20, 200))
    c.blit(shadow)
    layer.outline((20, 12, 28, 255))
    c.blit(layer)


def _hero(look: Look, gear: Gear) -> Canvas:
    from game.art import folk
    return folk.sprite(look, gear, tiles=1)


def _doubled(src: Canvas) -> Canvas:
    out = Canvas(src.w * 2, src.h * 2)
    for y in range(src.h):
        for x in range(src.w):
            p = src.get(x, y)
            if p is not None and p[3]:
                out.rect(x * 2, y * 2, x * 2 + 1, y * 2 + 1, p)
    return out


def build(seed: int = 3) -> Canvas:
    rng = random.Random(seed)
    c = paint(SceneSpec(place="Mountains", people=0, time="Dusk", seed=seed)).canvas.copy()
    # darken the sky behind the title so it reads
    for y in range(0, 78):
        t = (1 - y / 78) * 0.55
        for x in range(W):
            p = c.get(x, y)
            if p is not None:
                c.set(x, y, mix(p, (14, 10, 30, 255), t))
    # a dragon wheeling in the sky
    dragon = CR.draw_creature("dragon", 2, "#b8322a", "#e8b860")
    c.blit(dragon.flipped_h(), 246, 84)
    # the party on the ridge
    party = [
        _hero(Look(base="human", hair="short", hair_color="#6a4a2a"),
              Gear(armor="chain_mail", weapon="longsword", shield="heater", shield_color="#2a6a3a",
                   cloak="cloak", cloak_color="#7a2a2a")),
        _hero(Look(base="elf", hair="long", hair_color="#e8d8a0"),
              Gear(armor="robe", armor_tint="#3a4a9a", weapon="quarterstaff", helmet="wizard_hat")),
        _hero(Look(base="dwarf", beard="braided", hair_color="#c04a1a"),
              Gear(armor="half_plate", weapon="warhammer", helmet="horned_helm", shield="round")),
        _hero(Look(base="halfling", hair="ponytail", hair_color="#2b2220"),
              Gear(armor="leather", weapon="shortsword", off_weapon="dagger", cloak="cape", cloak_color="#2a3a2a")),
    ]
    xs = [18, 70, 122, 174]
    for x, hero in zip(xs, party):
        c.blit(hero, x, 112)
    # title
    big, small = 5, 3
    draw_text(c, TITLE, (W - text_width(TITLE, big)) // 2, 10, big, "#ffe9a0", "#d08a20")
    draw_text(c, SUBTITLE, (W - text_width(SUBTITLE, small)) // 2, 56, small, "#e8f4e0", "#7ad07a")
    _ = rng
    return c


__all__ = ["build", "draw_text", "text_width", "W", "H"]
