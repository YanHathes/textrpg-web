"""Creatures in the house style (game/art/pixart.py): beasts and monsters standing side-on, the way farm
animals stand in a cosy farming game, outlined in a darker shade of their own colour and lit from the top left.

    art = draw("canine", tiles=1, main="#7d7a74", secondary="#c9c2b4", eyes="#f0d040")

Each is drawn on a box 24 art pixels a square (doubled on screen), so a bigger creature is drawn with more
pixels rather than stretched, its feet on the bottom of its squares, rising above them if it's tall. The
picture faces west; it carries `views` (1 west, 3 east mirrored, south and north side-on too) and two
walking or flapping frames for each in `steps`, like the people (game/art/folk.py).
"""
from __future__ import annotations

import math
from functools import lru_cache

from game.art.canvas import Canvas
from game.art.pixart import Px, alpha, c, shade

U = 24                         # art pixels a square's box is drawn on


class B:
    """A box for one creature: coordinates are given for a 1-square creature (a 24 x 24 box) and scaled up."""

    def __init__(self, tiles: int, wide: float = 1.0, tall: float = 1.0) -> None:
        self.t = tiles
        self.s = Px(round(U * tiles * wide), round(U * tiles * tall))
        self.ox = (self.s.w - U * tiles) / 2         # where the unit box sits in a wider picture
        self.oy = self.s.h - U * tiles

    def X(self, x):
        return self.ox + x * self.t

    def Y(self, y):
        return self.oy + y * self.t

    def disc(self, x, y, rx, ry, col):
        self.s.disc(self.X(x), self.Y(y), max(0.6, rx * self.t), max(0.6, ry * self.t), col)

    def lit(self, x, y, rx, ry, col, light=0.2, dark=0.25):
        t = self.t
        self.s.disc(self.X(x), self.Y(y), rx * t, ry * t, shade(col, -dark))
        self.s.disc(self.X(x) - 0.4 * t, self.Y(y) - 0.5 * t, max(0.6, (rx - 0.6) * t), max(0.6, (ry - 0.7) * t), col)
        self.s.disc(self.X(x - rx * 0.35), self.Y(y - ry * 0.4), max(0.6, rx * 0.4 * t), max(0.6, ry * 0.35 * t),
                    shade(col, light))

    def poly(self, pts, col):
        self.s.poly([(self.X(x), self.Y(y)) for x, y in pts], col)

    def line(self, x0, y0, x1, y1, col, width: float = 1):
        n = max(1, round(width * self.t))
        for k in range(n):
            off = k - (n - 1) / 2
            self.s.line(round(self.X(x0) + off * 0), round(self.Y(y0) + off), round(self.X(x1) + off * 0),
                        round(self.Y(y1) + off), col)

    def rect(self, x0, y0, x1, y1, col):
        self.s.rect(round(self.X(x0)), round(self.Y(y0)), round(self.X(x1)) - 1, round(self.Y(y1)) - 1, col)

    def p(self, x, y, col):
        self.s.p(self.X(x), self.Y(y), col)

    def eye(self, x, y, col):
        """An eye: a dark pupil with a glint, as big as the creature allows."""
        t = self.t
        ex, ey = round(self.X(x)), round(self.Y(y))
        if t >= 2:
            self.s.rect(ex, ey, ex + t - 1, ey + t - 1, c(col))
            self.s.p(ex, ey, shade(c(col), 0.55))
            self.s.p(ex + t - 1, ey + t - 1, shade(c(col), -0.45))
        else:
            self.s.p(ex, ey, c(col) if sum(c(col)[:3]) > 200 else c("#1a1418"))

    def shadow(self, x, y, rx):
        self.s.shadow(self.X(x), self.Y(y), rx * self.t, max(1.2, 1.2 * self.t), 70)


def _leg(b: B, x, top, bottom, col, w=2.0, hoof=None):
    b.rect(x, top, x + w, bottom, col)
    b.rect(x + w * 0.55, top + 0.5, x + w, bottom, shade(col, -0.12))
    if hoof is not None:
        b.rect(x - 0.2, bottom - 1, x + w + 0.2, bottom, hoof)


# ======================================================================
# Quadrupeds
# ======================================================================
QUAD = {
    #            body len, body h, leg len, head r, snout, neck, leg w, ground y
    "canine": dict(bl=13, bh=7, ll=6, hr=3.6, sn=3.0, nk=3, lw=1.8),
    "feline": dict(bl=14, bh=6.5, ll=6, hr=3.4, sn=1.6, nk=2.5, lw=1.8),
    "bear": dict(bl=15, bh=9.5, ll=5, hr=4.2, sn=2.6, nk=2, lw=3.0),
    "hoofed": dict(bl=14, bh=7, ll=9, hr=3.2, sn=3.2, nk=5.5, lw=1.6),
    "boar": dict(bl=14, bh=8.5, ll=4.5, hr=4.0, sn=3.4, nk=1, lw=2.2),
    "rodent": dict(bl=11, bh=6, ll=2.5, hr=3.2, sn=2.4, nk=0.5, lw=1.4),
    "lizard": dict(bl=12, bh=4.5, ll=2.6, hr=2.8, sn=2.8, nk=1, lw=1.6),
}


def quadruped(kind: str, t: int, main, sec, eyes, step: int, variant: str = "") -> Px:
    q = QUAD[kind]
    tall = 1.25 if kind == "hoofed" else 1.0
    b = B(t, wide=1.25, tall=tall)
    main, sec = c(main), c(sec)
    dark = shade(main, -0.22)
    ground = 22.5
    bl, bh, ll, hr, sn, nk, lw = q["bl"], q["bh"], q["ll"], q["hr"], q["sn"], q["nk"], q["lw"]
    by = ground - ll - bh / 2                      # body centre
    bx0, bx1 = 12 - bl / 2, 12 + bl / 2
    b.shadow(12, ground + 0.5, bl / 2 + 1)
    # tail, behind
    tail_col = (sec if variant == "antlers" else shade(main, -0.35)) if kind == "hoofed" else main
    if kind == "canine":
        b.lit(bx1 + 2.2, by - 2.5, 2.4, 1.6, main)
        b.disc(bx1 + 3.6, by - 3.6, 1.2, 1.0, sec)
    elif kind == "feline":
        for i in range(8):
            a = i / 7
            b.disc(bx1 + 0.5 + a * 4, by - 1 + math.sin(a * 2.6) * -4, 0.9, 0.9, main)
        b.disc(bx1 + 4.5, by - 3.5, 1.0, 1.0, shade(main, -0.3))
    elif kind == "hoofed":
        b.disc(bx1 + 0.8, by - 1.5, 1.3, 1.8, tail_col)
    elif kind == "boar":
        b.line(bx1, by - 1, bx1 + 2, by - 2.5, main)
        b.p(bx1 + 2.2, by - 3, main)
    elif kind == "rodent":
        for i in range(10):
            a = i / 9
            b.p(bx1 + a * 7, by + 1 + a * 2.2 - math.sin(a * 3) * 1.4, c("#d89a9a"))
    elif kind == "lizard":
        b.poly([(bx1 - 1, by - 1.5), (bx1 + 7, ground - 0.4), (bx1 + 7.5, ground), (bx1 - 1, by + 2)], main)
        b.line(bx1, by - 1.2, bx1 + 6, ground - 0.8, shade(main, 0.2))
    elif kind == "bear":
        b.disc(bx1 - 0.2, by - 1.5, 1.4, 1.2, main)
    # legs: the far pair first (darker), then the near pair
    swing = {0: 0.0, 1: 1.0, 2: -1.0}[step]
    hoof = c("#2a2224") if kind in ("hoofed", "boar") else None
    leg_top = by + bh * 0.15
    far = shade(main, -0.25)
    if kind == "lizard":                            # sprawled
        for x, s_ in ((bx0 + 1.5, 1), (bx1 - 3, -1)):
            b.line(x, by, x - 1.5 + swing * s_, ground, far, 1.4)
    else:
        _leg(b, bx0 + 2.4 - swing * 0.6, leg_top, ground, far, lw, hoof)
        _leg(b, bx1 - lw - 1.2 + swing * 0.6, leg_top, ground, far, lw, hoof)
    # the body
    b.lit(12, by, bl / 2, bh / 2, main)
    b.disc(12, by + bh * 0.24, bl / 2 - 1.4, bh * 0.22, sec if kind not in ("bear", "boar") else shade(main, 0.08))
    if kind == "bear":
        b.disc(bx0 + 3, by - bh / 2 + 1.5, 3, 2.4, shade(main, 0.12))      # the hump
    if kind == "boar":
        for i in range(6):                           # bristles along the spine
            b.p(bx0 + 3 + i * 1.6, by - bh / 2 - 0.4, shade(main, -0.35))
    if kind == "lizard":
        for i in range(5):
            b.p(bx0 + 2 + i * 2, by - bh / 2 + 0.4, sec)
    if kind == "feline" and variant != "plain":
        for i in range(4):                           # stripes
            b.line(bx0 + 4 + i * 2.6, by - bh / 2 + 0.6, bx0 + 3.4 + i * 2.6, by - 0.4, shade(main, -0.28))
    # the near legs
    if kind == "lizard":
        for x, s_ in ((bx0 + 2.5, -1), (bx1 - 2, 1)):
            b.line(x, by + 1, x - 1 + swing * s_, ground, main, 1.4)
            b.p(x - 1.6 + swing * s_, ground, shade(main, -0.25))
    else:
        _leg(b, bx0 + 1.4 + swing * 0.6, leg_top, ground, main, lw, hoof)
        _leg(b, bx1 - lw - 2.2 - swing * 0.6, leg_top, ground, main, lw, hoof)
        if kind in ("canine", "feline", "bear", "rodent"):
            for x in (bx0 + 1.4 + swing * 0.6, bx1 - lw - 2.2 - swing * 0.6):
                b.rect(x - 0.3, ground - 0.8, x + lw, ground, shade(main, -0.15))     # paws
    # the neck and head, out in front (west)
    hx = bx0 - hr * 0.45
    hy = by - bh / 2 - nk + hr * 0.6
    if kind in ("hoofed", "canine", "feline"):
        b.poly([(bx0 + 1, by - bh / 2 + 0.5), (bx0 + 4.5, by), (hx + hr * 0.4, hy + hr * 0.4),
                (hx + hr * 0.2, hy - hr * 0.5)], main)
        if kind == "hoofed" and variant != "antlers":
            for i in range(5):                       # a mane down the neck
                b.disc(hx + hr * 0.6 + i * 0.9, hy - hr * 0.3 + i * 1.1, 0.8, 0.8, shade(main, -0.3))
    if kind in ("lizard", "rodent", "boar", "bear"):
        hy = by - bh * 0.15
    b.lit(hx, hy, hr, hr * 0.9, main)
    # snout
    sy = hy + hr * 0.25
    snout_col = sec if kind in ("canine", "hoofed", "bear") else shade(main, 0.1)
    if kind == "boar":
        snout_col = c("#c89a8a")
    b.disc(hx - hr * 0.6 - sn * 0.4, sy, sn * 0.75, hr * 0.48, snout_col)
    b.p(hx - hr * 0.6 - sn * 1.05, sy - 0.4, c("#1a1418"))                  # the nose
    if kind == "boar":
        b.line(hx - hr * 0.4, sy + 0.8, hx - hr * 0.8, sy - 1.2, c("#f0ead6"))   # tusks
    if kind == "lizard":
        b.line(hx - hr - sn * 0.9, sy + 0.4, hx - hr - sn * 1.5, sy + 0.4, c("#d03a4a"))
    # ears
    ex = hx + hr * 0.25
    ey = hy - hr * 0.85
    if kind == "canine":
        b.poly([(ex - 1.4, ey + 1), (ex - 0.4, ey - 2.2), (ex + 0.8, ey + 1)], shade(main, -0.08))
        b.poly([(ex + 0.4, ey + 1.2), (ex + 1.6, ey - 1.8), (ex + 2.4, ey + 1.4)], shade(main, -0.25))
    elif kind == "feline":
        b.poly([(ex - 1.2, ey + 1), (ex - 0.6, ey - 1.6), (ex + 0.8, ey + 1)], main)
        b.p(ex - 0.6, ey, c("#e8a0a0"))
    elif kind == "bear":
        b.disc(ex + 0.6, ey + 0.4, 1.2, 1.1, main)
        b.p(ex + 0.6, ey + 0.4, shade(main, -0.3))
    elif kind == "hoofed":
        b.poly([(ex, ey + 1), (ex + 2.2, ey - 0.6), (ex + 1.4, ey + 1.4)], main)
        if variant == "antlers":
            ant = c("#cdb68a")
            b.line(ex + 0.4, ey + 0.6, ex + 1.6, ey - 4.5, ant)
            b.line(ex + 1.6, ey - 4.5, ex + 3.6, ey - 6.5, ant)
            b.line(ex + 1.2, ey - 2.8, ex - 0.6, ey - 4.6, ant)
            b.line(ex + 2.6, ey - 5.5, ex + 2.4, ey - 7.5, ant)
    elif kind == "boar":
        b.poly([(ex, ey + 1.2), (ex + 1, ey - 0.4), (ex + 1.8, ey + 1.2)], shade(main, -0.15))
    elif kind == "rodent":
        b.disc(ex + 0.3, ey + 0.2, 1.5, 1.5, shade(main, 0.1))
        b.disc(ex + 0.3, ey + 0.4, 0.8, 0.8, c("#d89a9a"))
    # eye
    b.eye(hx - hr * 0.35, hy - hr * 0.25, eyes)
    return b.s


# ======================================================================
# Fliers, crawlers and the rest
# ======================================================================
def bird(t: int, main, sec, eyes, step: int, bat: bool = False) -> Px:
    b = B(t, wide=1.5 if bat else 1.2, tall=1.15)
    main, sec = c(main), c(sec)
    ground = 22.5
    if bat:                                         # a bat hangs in the air, wings spread
        cy = 10 + {0: 0, 1: -1, 2: 1}[step]
        b.shadow(12, ground + 0.5, 4)
        up = {0: 0, 1: -3, 2: 3}[step]
        for side in (-1, 1):
            tip = (12 + side * 12, cy - 4 + up)
            pts = [(12 + side * 1.5, cy - 1.5), tip, (12 + side * 10, cy + 3 + up * 0.3),
                   (12 + side * 7, cy + 1.5), (12 + side * 4.5, cy + 3), (12 + side * 2, cy + 1.5)]
            b.poly(pts, shade(main, -0.12 if side < 0 else -0.25))
            b.line(12 + side * 1.5, cy - 1.5, tip[0], tip[1], shade(main, 0.2))
        b.lit(12, cy, 2.6, 3.2, main)
        for side in (-1, 1):
            b.poly([(12 + side * 0.8, cy - 2.6), (12 + side * 2.2, cy - 5.6), (12 + side * 2.4, cy - 2.2)], main)
        b.eye(11, cy - 1, eyes)
        b.eye(13, cy - 1, eyes)
        b.p(12, cy + 1.2, c("#f0ead6"))
        return b.s
    flap = {0: 0, 1: -2.5, 2: 1.5}[step]
    b.shadow(12, ground + 0.5, 5)
    # legs
    for x in (11.5, 13.5):
        b.line(x, 17.5, x, ground, c("#d8a040"))
        b.line(x, ground, x - 1.2, ground, c("#d8a040"))
    # tail feathers out behind (east)
    b.poly([(15, 13), (21, 11 + flap * 0.2), (21.5, 13.5), (15.5, 16)], shade(main, -0.15))
    b.lit(12.5, 13.5, 5.2, 4.4, main)                # the body
    b.disc(11.5, 15.5, 3.6, 2.2, sec)                 # its breast
    b.poly([(11, 12.5), (17, 11.5 + flap), (19, 13 + flap * 0.4), (16.5, 15.5), (12.5, 15.5)],
           shade(main, -0.1))                          # the wing
    for i in range(3):
        b.line(13 + i * 1.6, 15, 15.5 + i * 1.3, 12.2 + flap * (0.6 + i * 0.2), shade(main, -0.28))
    b.lit(8.5, 9, 3, 2.8, main)                       # the head
    b.poly([(6, 8.4), (3, 9.4), (6, 10.4)], c("#e0a83a"))     # the beak
    b.eye(7.6, 8.4, eyes)
    return b.s


def serpent(t: int, main, sec, eyes, step: int) -> Px:
    b = B(t, wide=1.2)
    main, sec = c(main), c(sec)
    ground = 22.5
    phase = {0: 0.0, 1: 0.8, 2: -0.8}[step]
    b.shadow(12, ground + 0.3, 9)
    pts = []
    for i in range(40):                              # the coils, lying along the ground
        a = i / 39
        x = 21 - a * 14
        y = ground - 1.6 - math.sin(a * 9 + phase) * 1.6 * (1 - a * 0.5)
        r = 1.6 + 0.8 * math.sin(a * math.pi)
        pts.append((x, y, r))
    for (x, y, r) in pts:
        b.disc(x, y + 0.4, r, r * 0.9, shade(main, -0.25))
    for (x, y, r) in pts:
        b.disc(x - 0.2, y, r * 0.85, r * 0.75, main)
    for k, (x, y, r) in enumerate(pts):
        if k % 4 == 0:
            b.p(x, y + r * 0.4, sec)                  # the belly scales
        if k % 5 == 2:
            b.p(x, y - r * 0.4, shade(main, -0.32))   # markings
    nx, ny = pts[-1][0], pts[-1][1]
    for i in range(8):                               # the neck rearing up
        a = i / 7
        b.disc(nx - a * 2.5, ny - a * 7, 1.6, 1.4, main)
    b.lit(nx - 3.6, ny - 8.5, 2.6, 2, main)
    b.eye(nx - 4.4, ny - 9.2, eyes)
    b.line(nx - 6, ny - 8.2, nx - 7.6, ny - 8.2, c("#d03a4a"))     # the tongue
    b.p(nx - 8, ny - 8.8, c("#d03a4a"))
    return b.s


def spider(t: int, main, sec, eyes, step: int, insect: bool = False) -> Px:
    b = B(t, wide=1.3)
    main, sec = c(main), c(sec)
    ground = 22.5
    lift = {0: 0, 1: 1, 2: -1}[step]
    b.shadow(12, ground + 0.5, 9)
    if insect:                                       # a beetle: a shell in two halves, six legs, antennae
        for k, x in enumerate((7, 11, 15)):
            l_ = lift if k % 2 else -lift
            b.line(x, 17, x - 2 + l_ * 0.5, ground, shade(main, -0.3))
        b.lit(13, 15.5, 7, 4.8, main)
        b.line(13, 11, 13, 20, shade(main, -0.3))
        b.disc(10.5, 13.5, 2, 1, shade(main, 0.35))
        for x in (11, 14, 17):
            b.p(x, 16, sec)
        for k, x in enumerate((8, 12, 16)):
            l_ = -lift if k % 2 else lift
            b.line(x, 18, x - 2.5 + l_ * 0.5, ground, shade(main, -0.12))
        b.lit(5.5, 15.5, 2.4, 2.2, shade(main, -0.08))
        b.line(4.5, 14, 1.5, 10, shade(main, -0.25))
        b.line(5.5, 13.8, 3.5, 9.5, shade(main, -0.25))
        b.eye(4.6, 15.2, eyes)
        return b.s
    for k in range(4):                               # the far legs
        x = 8 + k * 2.6
        l_ = lift if k % 2 else -lift
        b.line(x, 15, x - 3 + k * 2, 9 + l_, shade(main, -0.35))
        b.line(x - 3 + k * 2, 9 + l_, x - 5 + k * 3.3, ground, shade(main, -0.35))
    b.lit(15.5, 14.5, 5.6, 4.8, main)                # the abdomen
    for (x, y) in ((15, 12.5), (17, 14.5), (14.5, 16)):
        b.p(x, y, sec)                               # its markings
    b.lit(8.5, 16, 3.2, 2.8, shade(main, 0.06))      # the head and thorax
    for k in range(4):                               # the near legs
        x = 7.5 + k * 2.4
        l_ = -lift if k % 2 else lift
        b.line(x, 16.5, x - 2.6 + k * 1.6, 11.5 + l_, shade(main, -0.12))
        b.line(x - 2.6 + k * 1.6, 11.5 + l_, x - 4.8 + k * 3.2, ground, shade(main, -0.12))
    for (dx, dy) in ((0, 0), (1.3, -0.4), (0.4, -1.4)):
        b.eye(6.2 + dx, 15.4 + dy, eyes)
    b.line(5.5, 17.5, 5, 19, c("#e8e0d0"))           # fangs
    return b.s


def ooze(t: int, main, sec, eyes, step: int, cube: bool = False) -> Px:
    b = B(t)
    main, sec = c(main), c(sec)
    ground = 22.5
    sq = {0: 0.0, 1: 0.8, 2: -0.6}[step]
    b.shadow(12, ground + 0.4, 9)
    if cube:
        jelly = alpha(main, 150)
        b.rect(3, 6 + sq, 21, ground, jelly)
        b.rect(3, 6 + sq, 21, 8 + sq, alpha(shade(main, 0.3), 170))
        b.rect(17, 8 + sq, 21, ground, alpha(shade(main, -0.25), 160))
        b.disc(11, 15, 2, 1.4, c("#e8e2cc"))         # something it's swallowed: a skull, a sword
        b.p(10.5, 15, c("#2a2226"))
        b.line(6, 19, 12, 12, c("#a7b1ba"))
        b.p(5, 7.5 + sq, alpha("#ffffff", 200))
        return b.s
    b.disc(12, ground - 4 + sq * 0.5, 9 + sq, 5.5 - sq, shade(main, -0.25))
    b.disc(11.6, ground - 4.6 + sq * 0.5, 8.4 + sq, 5 - sq, main)
    b.disc(9, ground - 7 + sq, 3, 1.6, shade(main, 0.3))
    b.p(7.5, ground - 7.5 + sq, c("#ffffff"))
    for (x, y) in ((15, ground - 2.5), (17.5, ground - 4.5), (8, ground - 2)):
        b.disc(x, y, 0.9, 0.9, sec)                  # bubbles
    b.eye(9.5, ground - 5.5 + sq, eyes)
    b.eye(13.5, ground - 5.5 + sq, eyes)
    b.disc(3.2, ground - 0.4, 1.2, 0.6, main)        # a drip left behind
    return b.s


def elemental(t: int, main, sec, eyes, step: int, variant: str) -> Px:
    b = B(t, tall=1.3)
    main, sec = c(main), c(sec)
    ground = 22.5
    sway = {0: 0.0, 1: 0.8, 2: -0.8}[step]
    if variant == "earth":                           # a golem of boulders
        b.shadow(12, ground + 0.5, 8)
        for x, y, r in ((9, 20, 2.6), (15, 20, 2.6)):
            b.lit(x, y, r, r, shade(main, -0.08))
        b.lit(12, 13, 6.5, 5.5, main)
        b.lit(4.5 + sway * 0.5, 14, 2.8, 3.6, main)
        b.lit(19.5 - sway * 0.5, 14, 2.8, 3.6, main)
        b.lit(12, 5.5, 3.6, 3, shade(main, 0.08))
        for (x, y) in ((10, 11), (14, 15), (12, 9)):
            b.line(x, y, x + 1.5, y + 2, shade(main, -0.35))
        for (x, y) in ((9, 14), (15, 12)):
            b.p(x, y, sec)
        b.eye(10.8, 5.4, eyes)
        b.eye(13.2, 5.4, eyes)
        return b.s
    if variant == "air":                             # a whirl of cloud
        b.shadow(12, ground + 0.5, 6)
        for i in range(30):
            a = i / 29
            r = 1.2 + a * 6
            ang = a * 9 + sway
            b.disc(12 + math.cos(ang) * r * 0.9, ground - 1 - a * 17 + math.sin(ang) * 1.2, 1.6 + a * 1.8,
                   1.1 + a * 1.1, main if i % 3 else sec)
        b.eye(10.5, 8.5, eyes)
        b.eye(13.5, 8.5, eyes)
        return b.s
    # fire and water: a tapering column, wilder at its crown
    b.shadow(12, ground + 0.5, 6)
    for i in range(22):
        a = i / 21
        y = ground - a * 20
        r = 5.5 * math.sin(math.pi * (0.18 + a * 0.75)) + 1
        x = 12 + math.sin(a * 6 + sway * 2) * 1.2
        b.disc(x, y, r, 1.6, shade(main, -0.15 if a < 0.3 else 0))
    for i in range(14):
        a = i / 13
        x = 12 + math.sin(a * 6 + sway * 2) * 1.2
        b.disc(x - 1, ground - 2 - a * 16, 2.6 * (1 - a * 0.6), 1.2, sec)
    for k, (dx, h) in enumerate(((-4, 5), (0, 7), (4, 5))):   # the tongues at its crown
        b.poly([(12 + dx - 1.4, 5.5), (12 + dx + sway * (k - 1), 5.5 - h * 0.6), (12 + dx + 1.4, 5.5)], main)
    if variant == "water":
        b.p(9, 9, c("#ffffff"))
        b.line(8, 15, 11, 14, shade(sec, 0.2))
    b.eye(10.5, 9, eyes)
    b.eye(13.5, 9, eyes)
    return b.s


def plant(t: int, main, sec, eyes, step: int) -> Px:
    b = B(t, tall=1.2)
    main, sec = c(main), c(sec)
    ground = 22.5
    sway = {0: 0.0, 1: 1.0, 2: -1.0}[step]
    b.shadow(12, ground + 0.5, 7)
    for (x, y, r) in ((7, ground - 1.5, 3), (17, ground - 1.5, 3), (12, ground - 1, 3.5)):
        b.lit(x, y, r, 1.8, main)                    # leaves at its foot
    for i in range(10):                              # the stalk, swaying
        a = i / 9
        b.disc(12 + math.sin(a * 2.5) * 1.5 + sway * a, ground - 2 - a * 10, 1.3, 1.3, sec)
    hx, hy = 12 + sway, 8.5
    b.lit(hx, hy, 5.2, 4.2, main)                    # the jaws
    b.poly([(hx - 5.5, hy), (hx + 4, hy - 1), (hx + 4, hy + 1)], c("#5a1a22"))
    for k in range(5):
        x = hx - 4.5 + k * 2
        b.p(x, hy - 0.6, c("#f0ead6"))               # teeth
        b.p(x + 1, hy + 0.6, c("#f0ead6"))
    for (x, y) in ((hx - 2, hy - 3), (hx + 2, hy - 3.2)):
        b.p(x, y, c("#e04a5a"))                      # spots on its lips
    b.eye(hx + 1, hy - 2.2, eyes)
    return b.s


def dragon(t: int, main, sec, eyes, step: int) -> Px:
    b = B(t, wide=1.4, tall=1.25)
    main, sec = c(main), c(sec)
    dark = shade(main, -0.24)
    ground = 22.5
    flap = {0: 0.0, 1: -3.0, 2: 2.0}[step]
    walk = {0: 0.0, 1: 0.8, 2: -0.8}[step]
    b.shadow(13, ground + 0.5, 12)
    # the far wing, raised behind
    b.poly([(11, 11), (15 + flap * 0.2, -4 + flap), (23, -1 + flap * 0.6), (21, 4), (18, 6), (15, 11)],
           shade(main, -0.32))
    # the tail: down to the ground, along it, flicking up at its spade
    tail = []
    for i in range(20):
        a = i / 19
        x = 18 + a * 10
        y = 15.5 + math.sin(min(1, a * 1.6) * math.pi / 2) * 5.5 - max(0, a - 0.75) * 10
        tail.append((x, y, 2.6 * (1 - a * 0.7)))
    for (x, y, r) in tail:
        b.disc(x, y + 0.4, r, r * 0.85, dark)
    for (x, y, r) in tail:
        b.disc(x - 0.2, y, r * 0.85, r * 0.7, main)
    for k in range(3, 18, 3):
        x, y, r = tail[k]
        b.poly([(x - 0.8, y - r * 0.6), (x + 0.2, y - r - 1.2), (x + 1, y - r * 0.6)], sec)    # spines
    tx, ty, _ = tail[-1]
    b.poly([(tx - 0.5, ty - 0.5), (tx + 2.5, ty - 2.5), (tx + 2, ty + 1), (tx + 0.5, ty + 1.5)], sec)
    # far legs
    for x in (8.5 - walk, 16 + walk):
        b.rect(x, 15, x + 2.4, ground, dark)
    # the body, low and heavy
    b.lit(13, 14.5, 7.8, 4.4, main)
    b.disc(12.5, 16.8, 6.4, 1.7, sec)                # pale belly plates
    for i in range(6):
        b.p(8.5 + i * 1.6, 16.8, shade(sec, -0.22))
    for i in range(5):                               # spines along the back
        b.poly([(8 + i * 2.2, 10.6), (9 + i * 2.2, 8.4), (10 + i * 2.2, 10.6)], sec)
    # near legs, bent, with claws
    for x in (7 + walk, 15.5 - walk):
        b.lit(x + 1.4, 16, 2.2, 2.4, main)           # the haunch
        b.rect(x + 0.2, 16.5, x + 2.8, ground, main)
        b.rect(x - 0.6, ground - 0.9, x + 2.8, ground, shade(main, -0.18))
        b.p(x - 0.8, ground, c("#f0ead6"))
        b.p(x + 0.6, ground, c("#f0ead6"))
    # the neck, an S rising forward to the head
    for i in range(12):
        a = i / 11
        x = 7.5 - a * 4 - math.sin(a * math.pi) * 1.2
        y = 12.5 - a * 7.5
        r = 2.6 - a * 0.7
        b.disc(x, y + 0.3, r, r, dark)
        b.disc(x - 0.2, y, r * 0.85, r * 0.85, main)
        if i % 2 == 0:
            b.p(x + r * 0.5, y + r * 0.2, sec)       # the throat plates
    # the head: a long skull, a snout, a heavy jaw, horns swept back
    hx, hy = 3, 4.2
    b.lit(hx, hy, 3.4, 2.6, main)
    b.disc(hx - 3.2, hy + 0.9, 2.6, 1.5, main)
    b.disc(hx - 2.6, hy + 2.0, 2.4, 0.9, shade(main, -0.12))   # the jaw
    b.line(hx - 5.4, hy + 1.6, hx - 0.5, hy + 1.6, shade(main, -0.42))
    b.p(hx - 5.6, hy + 0.4, c("#1a1418"))            # a nostril
    b.p(hx - 4, hy + 2.4, c("#f0ead6"))              # a fang
    b.line(hx + 1, hy - 2, hx + 5, hy - 4.5, sec)
    b.line(hx + 1.8, hy - 1.4, hx + 5.6, hy - 2.6, shade(sec, -0.2))
    b.poly([(hx + 2.5, hy + 0.5), (hx + 4.5, hy + 1.5), (hx + 2.6, hy + 2)], sec)    # a cheek frill
    b.eye(hx - 0.6, hy - 1.0, eyes)
    # the near wing, folded or beating, its membrane scalloped
    pts = [(10, 10.5), (13 + flap * 0.3, -3.5 + flap), (21, -1.5 + flap * 0.7), (20, 3), (17.5, 4.5),
           (16.5, 8), (14, 9), (13, 12)]
    b.poly(pts, shade(main, -0.06))
    for k in range(3):                               # the wing's bones
        b.line(10.5, 10.5, 14 + k * 2.8 + flap * 0.3, -2.5 + k * 1.6 + flap * (1 - k * 0.25), shade(main, 0.2))
    b.line(10, 10.5, 13 + flap * 0.3, -3.5 + flap, shade(main, 0.32))
    return b.s


# ======================================================================
# Out
# ======================================================================
def _draw(base_id: str, t: int, main, sec, eyes, variant: str, step: int) -> Px:
    if base_id in QUAD:
        v = variant if base_id != "feline" else (variant or "striped")
        return quadruped(base_id, t, main, sec, eyes, step, v)
    if base_id in ("bird", "bat"):
        return bird(t, main, sec, eyes, step, bat=base_id == "bat")
    if base_id == "serpent":
        return serpent(t, main, sec, eyes, step)
    if base_id in ("spider", "insect"):
        return spider(t, main, sec, eyes, step, insect=base_id == "insect")
    if base_id == "ooze":
        return ooze(t, main, sec, eyes, step, cube=variant == "cube")
    if base_id == "elemental":
        return elemental(t, main, sec, eyes, step, variant or "fire")
    if base_id == "plant":
        return plant(t, main, sec, eyes, step)
    if base_id == "dragon":
        return dragon(t, main, sec, eyes, step)
    raise KeyError(base_id)


def _finish(s: Px) -> Px:
    s.outline(0.55)
    return s


@lru_cache(maxsize=256)
def _sprite(base_id: str, tiles: int, main: str, sec: str, eyes: str, variant: str) -> Canvas:
    from game.art import store
    return store.cached("beast", (base_id, tiles, main, sec, eyes, variant),
                        lambda: _draw_sprite(base_id, tiles, main, sec, eyes, variant))


def _draw_sprite(base_id: str, tiles: int, main: str, sec: str, eyes: str, variant: str) -> Canvas:
    frames = [_finish(_draw(base_id, tiles, main, sec, eyes, variant, st)) for st in (0, 1, 2)]
    west = [f.done() for f in frames]
    east = [f.flipped().done() for f in frames]
    art = west[0]
    art.views = {0: west[0], 1: west[0], 2: east[0], 3: east[0]}
    art.steps = {0: west[1:], 1: west[1:], 2: east[1:], 3: east[1:]}
    return art


def draw(base_id: str, tiles: int = 1, main: str = "", secondary: str = "", eyes: str = "",
         variant: str = "") -> Canvas:
    """A creature facing west (with its other facings and walking frames)."""
    from game.art.creatures import CREATURE_BASES, ELEMENT_COLORS
    base = CREATURE_BASES.get(base_id)
    if not base:
        raise KeyError(base_id)
    variant = variant or base.default_variant
    if base_id == "elemental" and not main:
        main, secondary, eyes = ELEMENT_COLORS.get(variant or "fire", ELEMENT_COLORS["fire"])
    return _sprite(base_id, max(1, int(tiles)), main or base.main, secondary or base.secondary, eyes or base.eyes,
                   variant or "")


__all__ = ["draw", "QUAD", "U"]
