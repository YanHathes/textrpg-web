"""Everything that stands on the walking map: trees, rocks, veins, herbs, crops... and every stick of furniture,
in the house style (game/art/pixart.py).

Each drawing is at least its footprint (16 art pixels a square) and may rise above it: a tree's crown, a
bookshelf's height, a lamp on its post. It stands centred on its footprint with its foot on the footprint's
bottom edge (game/art/tiles.py prop_offset).
"""
from __future__ import annotations

import math

from game.art.pixart import Px, c, rng, shade, alpha

# ---- shared colours
WOOD, WOOD_D, WOOD_L = c("#a8683a"), c("#7a4626"), c("#d0904e")
DARKWOOD, DARKWOOD_L = c("#6a3e24"), c("#8a5432")
IRON, IRON_L, IRON_D = c("#5e626e"), c("#9aa0aa"), c("#3e4048")
STONE, STONE_L, STONE_D = c("#a49c94"), c("#c8c0b4"), c("#7a726a")
GOLD, GOLD_L = c("#e0b04a"), c("#fff0a0")
LEAF = [c("#4a8a38"), c("#3e7a32"), c("#56983c")]
CLOTH = [c("#4a6aa8"), c("#a83a3a"), c("#4a8a5a"), c("#8a4aa0")]
FIRE = [c("#d8402e"), c("#f08a30"), c("#f6c040"), c("#fff0a0")]


# ======================================================================
# helpers
# ======================================================================
def _box(s: Px, x0, y0, x1, y1, col, top: int = 3) -> None:
    """A block seen from above and in front: its lit top `top` rows deep, its front below."""
    s.rect(x0, y0, x1, y1, shade(col, -0.14))
    s.rect(x0, y0, x1, y0 + top - 1, col)
    s.hline(x0, x1, y0, shade(col, 0.18))
    s.hline(x0, x1, y0 + top - 1, shade(col, -0.05))


def _legs(s: Px, xs, y0, y1, col=None) -> None:
    for x in xs:
        s.vline(x, y0, y1, col or WOOD_D)


def _flame(s: Px, cx, base, h: int = 4) -> None:
    """A little fire: red at the root, yellow-white at its heart."""
    for i in range(h):
        y = base - i
        half = max(0, (h - i) // 2)
        for x in range(cx - half, cx + half + 1):
            k = 0 if abs(x - cx) == half and half > 0 else min(3, 1 + (h - i) // 2 - abs(x - cx) // 1)
            s.p(x, y, FIRE[max(0, min(3, 3 - k if i > h // 2 else k))])
    s.p(cx, base - h, FIRE[1])
    s.p(cx, base - 1, FIRE[3])


def _glow(s: Px, cx, cy, r: float, col, a: int = 50) -> None:
    for y in range(int(cy - r) - 1, int(cy + r) + 2):
        for x in range(int(cx - r) - 1, int(cx + r) + 2):
            d = math.hypot(x + 0.5 - cx, y + 0.5 - cy)
            if d <= r and s.get(x, y) is None:
                s.put(x, y, alpha(col, int(a * (1 - d / r))))


# ======================================================================
# Trees and plants
# ======================================================================
def oak(v: int) -> Px:
    """An oak: a broad crown of leaf clumps over a short trunk standing on its square."""
    r = rng("oak3", v)
    s = Px(32, 40)
    s.shadow(16, 37, 10, 2.5, 80)
    trunk = c("#7a4e30")
    s.rect(14, 24, 17, 37, trunk)
    s.rect(16, 24, 17, 37, shade(trunk, -0.25))
    s.vline(14, 26, 37, shade(trunk, 0.15))
    s.rect(12, 36, 19, 37, trunk)                  # roots
    s.p(12, 35, trunk)
    s.p(19, 35, shade(trunk, -0.25))
    green = LEAF[v % 3]
    blobs = [(16, 14, 11, 9), (9, 17, 7, 6), (23, 17, 7, 6), (11, 9, 6, 5), (21, 9, 6, 5), (16, 6, 7, 5),
             (16, 21, 9, 4)]
    for (bx, by, rx, ry) in blobs:
        s.disc(bx, by, rx, ry, shade(green, -0.3))
    for (bx, by, rx, ry) in blobs:
        s.disc(bx - 0.6, by - 0.8, rx - 1, ry - 1, green)
    for (bx, by, rx, ry) in blobs[3:6] + blobs[:1]:
        s.disc(bx - rx * 0.3, by - ry * 0.35, rx * 0.5, ry * 0.45, shade(green, 0.2))
    for _ in range(26):                            # leaf texture
        x, y = r.randrange(5, 28), r.randrange(2, 24)
        if s.get(x, y) is not None and s.get(x, y)[:3] == green[:3]:
            s.p(x, y, shade(green, -0.15))
            s.p(x + 1, y, shade(green, -0.15))
    if v == 5:                                     # now and then, an apple tree
        for (x, y) in ((10, 13), (20, 11), (15, 18), (23, 17)):
            s.p(x, y, c("#d8402e"))
            s.p(x, y - 1, c("#f08060"))
    s.outline(0.5)
    return s.flipped() if v >= 3 else s


def big_tree(v: int) -> Px:
    """An old tree two squares across."""
    r = rng("bigtree3", v)
    s = Px(48, 60)
    s.shadow(24, 56, 17, 4, 85)
    trunk = c("#6e4630")
    s.rect(20, 34, 27, 57, trunk)
    s.rect(25, 34, 27, 57, shade(trunk, -0.25))
    s.vline(21, 36, 56, shade(trunk, 0.15))
    for (x, d) in ((16, -1), (31, 1)):            # spreading roots
        s.rect(min(x, x + 3 * d), 54, max(x, x + 3 * d), 57, trunk)
    s.rect(17, 56, 30, 57, trunk)
    s.vline(23, 40, 50, shade(trunk, -0.35))       # a crack in the bark
    green = [c("#3e7a32"), c("#4a8a38"), c("#5a8a34")][v % 3]
    blobs = [(24, 22, 17, 13), (12, 26, 10, 8), (36, 26, 10, 8), (15, 14, 9, 7), (33, 14, 9, 7),
             (24, 9, 10, 7), (24, 32, 13, 6)]
    for (bx, by, rx, ry) in blobs:
        s.disc(bx, by, rx, ry, shade(green, -0.3))
    for (bx, by, rx, ry) in blobs:
        s.disc(bx - 0.8, by - 1, rx - 1.2, ry - 1.2, green)
    for (bx, by, rx, ry) in blobs[3:6] + blobs[:1]:
        s.disc(bx - rx * 0.3, by - ry * 0.35, rx * 0.5, ry * 0.45, shade(green, 0.2))
    for _ in range(60):
        x, y = r.randrange(6, 44), r.randrange(3, 36)
        if s.get(x, y) is not None and s.get(x, y)[:3] == green[:3]:
            s.p(x, y, shade(green, -0.15))
            s.p(x + 1, y, shade(green, -0.15))
    s.outline(0.5)
    return s


def pine(v: int) -> Px:
    s = Px(24, 44)
    s.shadow(12, 41, 7, 2, 80)
    s.rect(11, 33, 13, 41, c("#6a4228"))
    s.vline(13, 33, 41, c("#4a2c18"))
    green = [c("#2e6a4a"), c("#30704a"), c("#3a6a40")][v % 3]
    tiers = ((3, 4), (9, 7), (16, 9), (23, 11)) if v != 1 else ((5, 4), (11, 7), (18, 10), (25, 11))
    for top, width in tiers:
        for i in range(10):
            y = top + i
            half = int(width * (i + 1) / 10) + (1 if i > 6 else 0)
            for x in range(12 - half, 13 + half):
                col = green if x < 12 else shade(green, -0.22)
                if i == 9:
                    col = shade(green, -0.32)
                elif x == 12 - half:
                    col = shade(green, 0.18)
                s.p(x, y, col)
        s.p(12 - width // 2, top + 6, shade(green, 0.3))
        s.p(12 + width // 3, top + 8, shade(green, -0.1))
    s.p(12, 2, shade(green, 0.2))
    s.outline(0.5)
    return s


def bush(v: int, berries=None) -> Px:
    s = Px()
    s.shadow(8, 13.5, 6.5, 2)
    g = [c("#4e8e3a"), c("#3e7e36"), c("#5a9440"), c("#4a8640")][v % 4]
    for (bx, by, rx, ry) in ((5, 9.5, 4, 4), (11, 9.5, 4, 4), (8, 6.5, 5, 4), (8, 11, 5.5, 3)):
        s.lit_disc(bx, by, rx, ry, g)
    if berries:
        dark, light = berries
        for (x, y) in ((5, 7), (9, 5), (11, 9), (7, 10), (12, 7), (4, 11)):
            s.p(x, y, c(dark))
            s.p(x, y - 1, c(light))
    s.outline(0.5)
    return s.flipped() if v % 2 else s


BERRIES = [("#2a3a8a", "#7a90e0"), ("#a01e28", "#f06060"), ("#5a2a8a", "#a070d0")]


def berry_bush(v: int) -> Px:
    return bush(v, BERRIES[v % 3])


def stump(v: int) -> Px:
    s = Px()
    s.shadow(8, 13.5, 6.5, 2)
    bark, ring, ring_l = c("#6a4228"), c("#c89a5e"), c("#e0b878")
    s.rect(3, 7, 12, 13, bark)
    s.rect(10, 7, 12, 13, shade(bark, -0.2))
    s.vline(4, 9, 12, shade(bark, 0.15))
    s.disc(7.5, 7, 4.8, 2.4, ring)
    s.disc(7.5, 7, 3, 1.4, ring_l)
    s.p(7, 7, ring)
    s.hline(2, 3, 13, bark)
    s.hline(12, 13, 13, bark)
    s.outline(0.45)
    return s


def log(v: int) -> Px:
    s = Px(32, 16)
    s.shadow(16, 12.5, 14, 2)
    bark = c("#7a4e30")
    s.rect(2, 6, 28, 11, bark)
    s.hline(2, 28, 6, shade(bark, 0.18))
    s.hline(2, 28, 11, shade(bark, -0.3))
    for x in (7, 15, 22):                          # bark furrows
        s.hline(x, x + 3, 8, shade(bark, -0.2))
        s.hline(x + 2, x + 4, 10, shade(bark, -0.2))
    s.disc(28, 8.5, 2.2, 3, c("#c89a5e"))
    s.p(28, 8, c("#a87a44"))
    s.vline(11, 4, 6, c("#4e8a3a"))                # a sprig growing from it
    s.p(12, 4, c("#78b052"))
    s.outline(0.45)
    return s


def mushrooms(v: int) -> Px:
    s = Px()
    cap, spot = [(c("#c8402e"), c("#f4f0e0")), (c("#b0743a"), c("#e8c890")), (c("#3aa0b0"), c("#c0f8ff"))][v % 3]
    if v % 3 == 2:
        _glow(s, 7, 10, 7, c("#80e8ff"), 60)
    for (x, y, rr) in ((5, 9, 3), (11, 11, 2), (8, 13, 1.5)):
        s.rect(x, y, x, y + 3, c("#e8dcc0"))
        s.disc(x, y, rr, max(1, rr - 0.8), cap)
        s.p(x - 1, y - 1, spot)
        if rr > 2:
            s.p(x + 1, y, spot)
    s.outline(0.5)
    return s


def herbs(v: int) -> Px:
    s = Px()
    flower = [c("#f4f0e0"), c("#c890e0"), c("#f6d84a"), c("#f08aa0")][v % 4]
    stem, leaf = c("#3e7a32"), c("#68b048")
    for x, top in ((4, 6), (8, 5), (11, 7), (6, 9)):
        s.vline(x, top + 1, 13, stem)
        s.p(x - 1, top + 4, leaf)
        s.p(x + 1, top + 3, leaf)
        s.p(x - 1, top + 2, leaf)
        s.p(x, top, flower)
        s.p(x, top - 1, shade(flower, 0.2))
        s.p(x + 1, top, shade(flower, -0.15))
    s.outline(0.5)
    return s


def rare_herbs(v: int) -> Px:
    s = Px()
    _glow(s, 8, 8, 8, c("#c0a0ff"), 70)
    stem, leaf = c("#2e6a4a"), c("#5aa080")
    for x, top in ((4, 5), (8, 3), (12, 6)):
        s.vline(x, top + 1, 13, stem)
        s.p(x - 1, top + 4, leaf)
        s.p(x + 1, top + 3, leaf)
        s.p(x, top, c("#b080ff"))
        s.p(x - 1, top, c("#7a50d0"))
        s.p(x + 1, top, c("#7a50d0"))
        s.p(x, top - 1, c("#f0e0ff"))
    s.p(6, 2, c("#ffffff"))                        # a sparkle
    s.p(14, 3, c("#e8d8ff"))
    s.outline(0.5)
    return s


def grain(v: int) -> Px:
    s = Px()
    stalk, ear = [(c("#b89a4a"), c("#e0c060")), (c("#c0a860"), c("#f0dc90")), (c("#8aa048"), c("#c8c860"))][v % 3]
    for x in (2, 5, 8, 11, 14):
        lean = (x % 3) - 1
        s.vline(x, 7, 14, stalk)
        s.vline(x + lean, 3, 7, ear)
        s.p(x + lean, 3, shade(ear, 0.3))
        s.p(x + lean + 1, 5, ear)
        s.p(x + lean - 1, 6, shade(ear, -0.15))
    s.outline(0.5)
    return s


def crops(v: int) -> Px:
    s = Px()
    soil = c("#6a442a")
    for y in (4, 11):                              # two furrows
        s.rect(1, y, 14, y + 2, soil)
        s.hline(1, 14, y, shade(soil, 0.15))
        s.hline(1, 14, y + 2, shade(soil, -0.25))
    for y in (4, 11):
        for x in (3, 7, 11):
            if v % 3 == 0:                         # sprouts
                s.vline(x, y - 1, y, c("#5aa83a"))
                s.p(x - 1, y - 2, c("#78c050"))
                s.p(x + 1, y - 2, c("#78c050"))
            elif v % 3 == 1:                       # cabbages
                s.disc(x + 0.5, y, 2, 1.6, c("#6ab048"))
                s.p(x, y - 1, c("#a8d878"))
            else:                                  # pumpkins under their leaves
                s.p(x - 1, y - 2, c("#4e9a3a"))
                s.p(x + 1, y - 2, c("#4e9a3a"))
                s.rect(x - 1, y - 1, x + 1, y, c("#f08a30"))
                s.p(x - 1, y - 1, c("#f8b060"))
                s.p(x, y - 2, c("#5a7a2a"))
    return s


def bare_patch(v: int) -> Px:
    """Picked clean: turned earth and stubble."""
    r = rng("bare3", v)
    s = Px()
    s.disc(8, 10, 6, 3.5, c("#7a5236"))
    s.disc(7.5, 9.5, 4.5, 2.5, c("#8a6040"))
    for _ in range(6):
        x, y = r.randint(3, 12), r.randint(8, 12)
        s.vline(x, y - 1, y, c("#b8a050") if v % 2 == 0 else c("#6a8a3a"))
    return s


def fishing_spot(v: int) -> Px:
    s = Px()
    ring = c("#d8f0f8")
    for (cx, cy, rr) in ((8, 8, 6), (8, 8, 3.5)):
        for a in range(0, 360, 15):
            x = cx + math.cos(math.radians(a)) * rr
            y = cy + math.sin(math.radians(a)) * rr * 0.5
            if (a // 15) % 4 != 0:
                s.p(round(x), round(y), ring)
    s.hline(7, 9, 7, c("#3a5a7a"))                 # a fish's back breaking the water
    s.p(10, 6, c("#3a5a7a"))
    s.p(8, 6, c("#8ab0c8"))
    return s


def carcass(v: int) -> Px:
    """A deer brought down, ready to skin."""
    s = Px(16, 16)
    s.shadow(8, 12, 7, 2)
    hide = c("#a0683e")
    s.disc(8, 10, 5.5, 2.6, hide)
    s.disc(7, 9.2, 3.5, 1.3, shade(hide, 0.18))
    s.disc(13, 8.5, 2, 1.6, hide)                  # the head
    s.p(14, 8, c("#2a1e1a"))
    s.line(13, 7, 15, 4, c("#e8d8b8"))             # antlers
    s.line(12, 7, 11, 4, c("#e8d8b8"))
    s.p(15, 5, c("#e8d8b8"))
    for x in (4, 7, 10):                           # legs
        s.line(x, 12, x - 1, 14, shade(hide, -0.3))
    s.p(4, 9, c("#f0e8d8"))                        # the white tail
    s.outline(0.5)
    return s


# ======================================================================
# Stone
# ======================================================================
def rock(v: int) -> Px:
    s = Px()
    s.shadow(8, 13.5, 7, 2)
    base = [c("#9a948c"), c("#a09888"), c("#8e8a86"), c("#9a948c")][v % 4]
    wide = v % 2 == 0
    rx, ry, cy = (7, 4.6, 9.5) if wide else (5.5, 5.2, 9)
    s.disc(8, cy, rx, ry, shade(base, -0.3))
    s.disc(7.6, cy - 0.6, rx - 0.8, ry - 0.6, base)
    s.disc(6, cy - 2, rx * 0.5, ry * 0.45, shade(base, 0.22))
    s.hline(4, 11, int(cy + ry - 2), shade(base, -0.18))
    s.p(9, cy - 1, shade(base, -0.2))
    s.p(10, cy, shade(base, -0.2))
    if v == 3:                                     # moss on its shoulder
        for (x, y) in ((5, 6), (6, 6), (7, 5), (4, 7), (9, 6)):
            s.p(x, y, c("#5a8a3a"))
    s.outline(0.45)
    return s.flipped() if v == 2 else s


def boulder(v: int) -> Px:
    s = Px(32, 32)
    s.shadow(16, 28.5, 14, 3)
    base = c("#948e86") if v % 2 == 0 else c("#8a8478")
    s.disc(16, 18, 14, 11, shade(base, -0.3))
    s.disc(15.4, 17, 12.8, 9.8, base)
    s.disc(11, 12, 6, 4.5, shade(base, 0.22))
    s.disc(22, 21, 5, 3.5, shade(base, -0.12))
    s.line(16, 9, 19, 17, shade(base, -0.28))      # a crack
    s.line(19, 17, 17, 22, shade(base, -0.28))
    s.hline(6, 26, 26, shade(base, -0.2))
    if v % 2:
        s.speckle(rng("boulder-moss", v), 14, ["#5a8a3a", "#6a9a44"], 6, 7, 20, 12)
    s.outline(0.45)
    return s


def quarry_rock(v: int) -> Px:
    """Pale building stone, cut square, chisel marks on it."""
    s = Px()
    s.shadow(8, 14, 7, 2)
    base = [c("#d0c4a8"), c("#c8bca4"), c("#bcb4a8")][v % 3]
    s.rect(2, 4, 13, 13, shade(base, -0.18))        # front
    s.rect(2, 4, 13, 8, base)                       # top
    s.hline(2, 13, 4, shade(base, 0.25))
    s.vline(2, 4, 13, shade(base, 0.1))
    for x in (5, 9):
        s.vline(x, 9, 12, shade(base, -0.32))
    s.p(11, 6, shade(base, -0.2))
    s.p(6, 6, shade(base, -0.2))
    s.outline(0.45)
    return s


# ore_vein variants, in the order mining reads them (game/gathering.py ORE_BY_VARIANT)
ORES = [("stone", None, None), ("coal", "#2a2624", "#4a4440"), ("copper", "#d07a3a", "#f0a868"),
        ("iron", "#9a6a5a", "#c8a090"), ("silver", "#d0d8e0", "#ffffff"), ("gold", "#e8b830", "#fff0a0")]


def ore_vein(v: int) -> Px:
    """A dark outcrop with the ore showing in it."""
    name, dark, light = ORES[v % len(ORES)]
    s = Px()
    s.shadow(8, 13.5, 7, 2)
    base = c("#7e7870")
    s.disc(8, 9, 7, 5, shade(base, -0.3))
    s.disc(7.6, 8.4, 6.2, 4.4, base)
    s.disc(5.5, 6.5, 3.2, 2.2, shade(base, 0.2))
    s.line(3, 10, 8, 8, shade(base, -0.25))       # a seam running through it
    s.line(8, 8, 12, 9, shade(base, -0.25))
    if dark is None:                               # plain stone: quartz threads
        for (x, y) in ((5, 9), (9, 7), (10, 10)):
            s.p(x, y, c("#e8e4dc"))
    else:
        for (x, y) in ((4, 9), (6, 8), (9, 8), (11, 9), (7, 11), (10, 11)):
            s.p(x, y, c(dark))
            s.p(x, y - 1, c(light))
        if name in ("silver", "gold"):
            s.p(9, 6, c("#ffffff"))                 # a glint
    s.outline(0.45)
    return s


def rich_vein(v: int) -> Px:
    s = Px()
    _glow(s, 8, 8, 8, c("#ffe080"), 60)
    s.shadow(8, 14, 7, 2)
    base = c("#706a64")
    s.disc(8, 10, 7, 4.5, shade(base, -0.3))
    s.disc(7.6, 9.4, 6.2, 3.9, base)
    for (x, top, col) in ((5, 4, "#e8b830"), (8, 2, "#d0d8e0"), (11, 5, "#e8b830")):   # crystals
        s.vline(x, top, 9, c(col))
        s.vline(x + 1, top + 1, 9, shade(c(col), -0.25))
        s.p(x, top, c("#ffffff"))
    s.outline(0.45)
    return s


def spent_vein(v: int) -> Px:
    """A worked-out vein: broken rock lying low."""
    r = rng("spent3", v)
    s = Px()
    base = c("#8a847c")
    for _ in range(4 + v):
        x, y = r.randint(3, 11), r.randint(8, 12)
        s.rect(x, y, x + 1, y + 1, shade(base, r.uniform(-0.1, 0.1)))
        s.p(x, y, shade(base, 0.2))
    s.speckle(r, 6, ["#6a645c", "#a8a098"], 2, 10, 13, 13)
    s.outline(0.4)
    return s


def rubble(v: int) -> Px:
    r = rng("rubble3", v)
    s = Px()
    s.shadow(8, 13, 6.5, 2, 50)
    base = c("#9a928a")
    for _ in range(6):
        x, y = r.randint(2, 11), r.randint(6, 12)
        w = r.randint(1, 3)
        s.rect(x, y, x + w, y + 1, shade(base, r.uniform(-0.15, 0.08)))
        s.hline(x, x + w, y, shade(base, 0.2))
    s.outline(0.45)
    return s


def bones(v: int) -> Px:
    s = Px()
    bone = c("#e8dcc0")
    s.disc(6, 8, 2.2, 2, bone)                     # a skull
    s.p(5, 8, c("#4a3e34"))
    s.p(7, 8, c("#4a3e34"))
    s.hline(5, 7, 10, bone)
    s.line(9, 11, 14, 9, bone)                     # long bones
    s.p(14, 8, bone)
    s.p(9, 12, bone)
    s.line(3, 13, 8, 13, bone)
    s.p(3, 12, bone)
    s.outline(0.4)
    return s


# ======================================================================
# Furniture
# ======================================================================
def barrel(v: int) -> Px:
    s = Px()
    s.shadow(8, 14.5, 5.5, 1.8)
    s.rect(4, 3, 11, 14, WOOD)
    s.rect(3, 5, 12, 12, WOOD)
    s.rect(9, 3, 11, 14, shade(WOOD, -0.18))
    s.vline(5, 4, 13, shade(WOOD, 0.15))
    for y in (5, 11):
        s.hline(3, 12, y, IRON)
        s.p(4, y, IRON_L)
    s.disc(7.5, 3, 3.6, 1.4, c("#c08850"))
    s.p(6, 3, shade(c("#c08850"), 0.2))
    s.outline(0.5)
    return s


def crate(v: int) -> Px:
    s = Px()
    s.shadow(8, 14.5, 6.5, 1.8)
    s.rect(2, 3, 13, 14, c("#b88a50"))
    s.rect(2, 3, 13, 6, c("#d0a468"))               # the lid seen from above
    s.hline(2, 13, 3, c("#e0b878"))
    s.hline(2, 13, 6, c("#8a6036"))
    for i in range(8):                             # cross brace on the front
        s.p(3 + i * 10 / 7, 7 + i, c("#8a6036"))
        s.p(12 - i * 10 / 7, 7 + i, c("#8a6036"))
    s.outline(0.5)
    return s


def table(v: int) -> Px:
    s = Px(32, 16)
    s.shadow(16, 14.5, 14, 2)
    top = [WOOD, c("#b07848"), WOOD][v % 3]
    _box(s, 1, 3, 30, 10, top, top=6)
    for x in (6, 13, 20, 26):                      # the boards of the top
        s.vline(x, 4, 8, shade(top, -0.1))
    if v % 3 == 2:                                 # a cloth over it
        s.rect(6, 3, 25, 10, c("#e8e0d0"))
        s.hline(6, 25, 3, c("#ffffff"))
        s.rect(6, 9, 25, 10, c("#c8c0b0"))
    _legs(s, (2, 29), 11, 14)
    if v % 3 != 0:                                 # bread and a jug
        s.disc(10, 6, 2.5, 1.5, c("#c8904a"))
        s.hline(9, 11, 5, c("#e8b878"))
        s.rect(20, 4, 22, 7, c("#c8b8a0"))
        s.p(20, 4, c("#ffffff"))
    else:                                          # a mug and a plate
        s.rect(9, 5, 10, 6, c("#e8e0d0"))
        s.disc(20, 6, 2, 1.2, c("#f0e8d8"))
        s.p(20, 6, c("#c87a3a"))
    s.outline(0.5)
    return s


def chair(v: int) -> Px:
    s = Px(16, 18)
    s.shadow(8, 16.5, 4, 1.5)
    s.rect(5, 2, 10, 9, WOOD_D)                    # the back
    s.rect(6, 3, 9, 8, WOOD)
    s.hline(6, 9, 3, WOOD_L)
    _box(s, 4, 9, 11, 12, WOOD, top=2)
    _legs(s, (4, 11), 13, 16)
    s.outline(0.5)
    return s


def bed(v: int) -> Px:
    s = Px(16, 32)
    s.shadow(8, 30.5, 7, 2)
    s.rect(1, 0, 14, 30, WOOD_D)                   # the frame, its headboard up top
    s.rect(2, 0, 13, 4, WOOD)
    s.hline(2, 13, 0, WOOD_L)
    s.rect(2, 5, 13, 9, c("#f2ead8"))              # the pillow
    s.rect(3, 6, 12, 8, c("#fffaf0"))
    blanket = CLOTH[v % 3]
    s.rect(2, 10, 13, 28, blanket)
    s.rect(2, 10, 13, 11, shade(blanket, 0.25))
    for y in range(14, 28, 4):                     # quilting
        s.hline(2, 13, y, shade(blanket, -0.18))
    for x in (6, 9):
        s.vline(x, 12, 28, shade(blanket, -0.18))
    s.rect(1, 29, 14, 30, WOOD)                    # the footboard
    s.outline(0.5)
    return s


BOOKS = [c("#a83a3a"), c("#3a5aa8"), c("#3a8a4a"), c("#d8b04a"), c("#7a4aa0"), c("#c86a2a")]


def bookshelf(v: int) -> Px:
    s = Px(32, 24)
    s.rect(0, 0, 31, 23, DARKWOOD)
    s.rect(1, 1, 30, 22, c("#3a2416"))
    s.hline(0, 31, 0, DARKWOOD_L)
    r = rng("books3", v)
    for y in (1, 8, 15):
        x = 1
        while x < 30:
            w = r.choice([1, 1, 2])
            h = r.randint(4, 6)
            if r.random() < 0.08 and v != 0:       # a gap with a bottle or a skull
                s.rect(x + 1, y + 6 - 3, x + 2, y + 5, c("#4a8a6a") if v == 1 else c("#e8dcc0"))
                x += 4
                continue
            col = r.choice(BOOKS)
            s.rect(x, y + 6 - h, min(30, x + w - 1), y + 5, col)
            s.p(x, y + 6 - h, shade(col, 0.3))
            if w == 2:
                s.vline(x + 1, y + 7 - h, y + 5, shade(col, -0.2))
            x += w
        s.hline(0, 31, y + 6, WOOD)
    s.outline(0.4)
    return s


def counter(v: int) -> Px:
    s = Px(32, 18)
    s.shadow(16, 17, 15, 1.5, 50)
    _box(s, 0, 2, 31, 16, WOOD, top=6)
    for x in range(2, 30, 7):                      # panels on its front
        s.rect(x, 10, x + 4, 15, shade(WOOD_D, 0.1))
        s.hline(x, x + 4, 10, shade(WOOD_D, -0.15))
    s.rect(5, 0, 6, 4, c("#d8c8a0"))               # a tankard and a ledger on top
    s.p(7, 1, c("#d8c8a0"))
    s.p(5, 0, c("#ffffff"))
    s.rect(18, 3, 24, 6, c("#6a3a2a"))
    s.rect(19, 3, 23, 5, c("#f0e6d0"))
    s.outline(0.5)
    return s


def anvil(v: int) -> Px:
    s = Px()
    s.shadow(8, 14.5, 6.5, 1.8)
    s.rect(5, 10, 10, 14, c("#6a4228"))            # the block it sits on
    s.hline(5, 10, 10, shade(c("#6a4228"), 0.2))
    s.rect(6, 8, 9, 10, IRON_D)
    s.rect(3, 5, 12, 8, IRON)
    s.hline(3, 12, 5, IRON_L)
    s.rect(0, 5, 3, 6, IRON)                       # the horn
    s.p(0, 5, IRON_L)
    s.outline(0.5)
    return s


def forge(v: int) -> Px:
    s = Px(32, 44)
    brick, mortar = c("#9a4a38"), c("#d8c0a8")
    s.rect(11, 0, 20, 14, shade(brick, -0.15))     # the chimney
    s.hline(11, 20, 0, shade(brick, 0.2))
    for y in range(2, 14, 3):
        s.hline(11, 20, y, shade(mortar, -0.2))
    _box(s, 1, 14, 30, 41, brick, top=8)
    for y in range(24, 41, 3):
        s.hline(1, 30, y, mortar)
        for x in range(1 + (y // 3 % 2) * 3, 31, 6):
            s.p(x, y + 1, mortar)
    s.rect(7, 25, 24, 36, c("#2a1a14"))            # the fire mouth
    s.hline(7, 24, 25, c("#4a2a1e"))
    for x in range(8, 24, 3):
        _flame(s, x, 35, 4 + (x % 2) * 2)
    s.hline(8, 23, 36, c("#5a3420"))
    s.rect(2, 17, 8, 20, c("#2a2624"))             # coal heaped on top, a pair of tongs
    s.p(3, 17, c("#4a4440"))
    s.line(22, 16, 29, 19, IRON_L)
    s.outline(0.4)
    return s


def chest(v: int) -> Px:
    s = Px()
    s.shadow(8, 14.5, 6.5, 1.8)
    s.rect(2, 7, 13, 14, WOOD)
    s.disc(7.5, 7, 5.9, 3.2, shade(WOOD, 0.1))      # the domed lid
    s.hline(2, 13, 4, shade(WOOD, 0.25))
    s.hline(2, 13, 7, WOOD_D)
    for x in (4, 11):
        s.vline(x, 4, 14, IRON)
    s.rect(7, 7, 8, 9, GOLD)                        # the lock
    s.p(7, 8, c("#6a4a10"))
    s.outline(0.5)
    return s


def campfire(v: int) -> Px:
    s = Px(16, 18)
    _glow(s, 8, 11, 8, c("#ffb050"), 70)
    for a in range(0, 360, 45):                    # the ring of stones
        x = 8 + math.cos(math.radians(a)) * 5.5
        y = 13 + math.sin(math.radians(a)) * 2.6
        s.disc(x, y, 1.3, 1, STONE)
        s.p(round(x - 0.5), round(y - 0.6), STONE_L)
    s.line(4, 14, 11, 11, c("#6a4228"))            # logs
    s.line(4, 11, 12, 14, c("#7a4e30"))
    _flame(s, 8, 12, 6)
    _flame(s, 6, 12, 3)
    _flame(s, 10, 12, 4)
    s.outline(0.45)
    return s


def brazier(v: int) -> Px:
    s = Px(16, 22)
    _glow(s, 8, 8, 8, c("#ffb050"), 60)
    s.shadow(8, 20.5, 4, 1.4)
    s.line(5, 20, 7, 14, IRON)                     # three legs
    s.line(11, 20, 9, 14, IRON)
    s.vline(8, 14, 20, IRON_D)
    s.disc(8, 12, 5, 2.4, IRON)                    # the bowl
    s.hline(3, 13, 11, IRON_L)
    s.rect(4, 10, 12, 10, c("#5a2a18"))
    _flame(s, 8, 10, 6)
    _flame(s, 6, 10, 4)
    _flame(s, 10, 10, 4)
    s.outline(0.45)
    return s


def stove(v: int) -> Px:
    """A kitchen hearth with a pot hanging over the fire."""
    s = Px(16, 24)
    s.rect(1, 0, 14, 23, STONE)
    s.rect(1, 0, 14, 2, STONE_L)
    for y in (6, 11, 16):
        s.hline(1, 14, y, STONE_D)
    for (x, y) in ((5, 3), (10, 8), (4, 13), (9, 18)):
        s.vline(x, y, y + 2, STONE_D)
    s.rect(3, 12, 12, 23, c("#2a1e1a"))            # the firebox
    s.hline(3, 12, 12, c("#5a463a"))
    _flame(s, 6, 21, 4)
    _flame(s, 9, 21, 5)
    s.hline(4, 11, 22, c("#5a3420"))
    s.vline(7, 13, 15, IRON_D)                     # the pot on its chain
    s.disc(7.5, 17, 2.6, 1.8, IRON_D)
    s.hline(5, 10, 16, IRON)
    s.outline(0.4)
    return s


def workbench(v: int) -> Px:
    s = Px(32, 18)
    s.shadow(16, 16.5, 14, 1.8)
    _box(s, 1, 4, 30, 11, c("#b88a50"), top=6)
    _legs(s, (2, 29), 12, 16)
    s.hline(2, 29, 14, WOOD_D)                     # the stretcher
    s.rect(4, 5, 14, 7, c("#e0b878"))              # a plank being worked
    s.hline(4, 14, 5, c("#f0d098"))
    s.rect(18, 4, 24, 5, IRON_L)                   # a saw
    s.rect(24, 4, 26, 6, WOOD_D)
    s.rect(27, 6, 28, 8, IRON)                     # a hammer
    s.hline(26, 29, 6, IRON)
    s.speckle(rng("shavings"), 5, ["#f0d098", "#e0b878"], 2, 15, 29, 17)
    s.outline(0.5)
    return s


def loom(v: int) -> Px:
    s = Px(32, 24)
    s.shadow(16, 22.5, 14, 1.6)
    for x in (2, 29):                              # the frame
        s.rect(x, 1, x + 1, 22, WOOD)
        s.vline(x, 1, 22, WOOD_L)
    s.rect(2, 1, 30, 2, WOOD)
    s.rect(2, 16, 30, 17, WOOD)
    s.hline(2, 30, 1, WOOD_L)
    for x in range(5, 28, 2):                      # the warp threads
        s.vline(x, 3, 15, c("#e8dcc0"))
    woven = c("#a83a3a")
    s.rect(5, 10, 27, 15, woven)                   # the cloth growing on it
    for y in (11, 13):
        s.hline(5, 27, y, shade(woven, 0.2))
    s.hline(5, 27, 15, GOLD)
    s.rect(12, 18, 19, 19, WOOD_D)                 # the treadles
    s.outline(0.45)
    return s


def tanning_rack(v: int) -> Px:
    s = Px(32, 24)
    s.shadow(16, 22.5, 14, 1.6)
    for x in (3, 28):
        s.rect(x, 1, x + 1, 22, WOOD)
        s.vline(x, 1, 22, WOOD_L)
    s.rect(3, 2, 29, 3, WOOD)
    s.rect(3, 18, 29, 19, WOOD)
    hide = c("#b07a4a")
    s.poly([(7, 5), (24, 5), (26, 10), (24, 16), (7, 16), (5, 10)], hide)   # a stretched hide
    s.disc(15, 9, 5, 3, shade(hide, 0.12))
    for (x, y) in ((7, 5), (24, 5), (7, 16), (24, 16), (5, 10), (26, 10)):
        s.line(x, y, 4 if x < 15 else 28, 3 if y < 10 else (18 if y > 10 else y), c("#d8c8a0"))
    s.outline(0.45)
    return s


def alchemy_table(v: int) -> Px:
    s = Px(32, 20)
    s.shadow(16, 18.5, 14, 1.8)
    _box(s, 1, 8, 30, 14, DARKWOOD, top=5)
    _legs(s, (2, 29), 15, 18, DARKWOOD)
    for (x, col, h) in ((4, "#4ac080", 6), (8, "#c04a8a", 4), (12, "#4a80d0", 7)):   # flasks
        s.disc(x + 1, 11 - 1, 1.8, 1.6, c(col))
        s.vline(x + 1, 11 - h, 9, c("#c8e0e8"))
        s.p(x, 9, shade(c(col), 0.4))
    s.disc(23, 9, 4, 2.6, IRON_D)                   # a little cauldron bubbling
    s.disc(23, 8, 3, 1.4, c("#7ad050"))
    s.p(22, 7, c("#c8ff90"))
    s.p(25, 4, c("#a8e880"))
    s.p(23, 2, c("#a8e880"))
    s.rect(15, 11, 18, 12, c("#e8dcc0"))           # an open book
    s.vline(16, 11, 12, c("#8a7a6a"))
    s.outline(0.45)
    return s


def jeweler_bench(v: int) -> Px:
    s = Px(16, 18)
    s.shadow(8, 16.5, 7, 1.6)
    _box(s, 1, 6, 14, 12, DARKWOOD, top=5)
    _legs(s, (2, 13), 13, 16, DARKWOOD)
    s.rect(3, 7, 7, 9, c("#2a2a3a"))               # a velvet tray of stones
    for (x, y, col) in ((4, 8, "#e04a5a"), (6, 8, "#4ac0e0"), (5, 7, "#60e080")):
        s.p(x, y, c(col))
    s.vline(11, 2, 8, IRON)                        # a lamp with a lens
    s.disc(11, 2, 1.5, 1.2, c("#f6e090"))
    s.outline(0.45)
    return s


def writing_desk(v: int) -> Px:
    s = Px(32, 20)
    s.shadow(16, 18.5, 14, 1.8)
    _box(s, 1, 6, 30, 13, WOOD, top=6)
    _legs(s, (2, 29), 14, 18)
    s.rect(18, 14, 27, 17, WOOD_D)                 # a drawer
    s.p(22, 15, GOLD)
    s.rect(6, 7, 15, 11, c("#f0e6d0"))             # parchment with lines of writing
    for y in (8, 10):
        s.hline(7, 13, y, c("#8a7a6a"))
    s.line(17, 4, 19, 9, c("#f4f0e8"))             # a quill in its ink
    s.disc(19, 10, 1.4, 1, c("#2a2a3a"))
    s.rect(25, 3, 26, 8, c("#f4ecd8"))             # a candle
    s.p(25, 2, FIRE[2])
    s.p(25, 1, FIRE[3])
    s.outline(0.5)
    return s


def well(v: int) -> Px:
    s = Px(32, 40)
    s.shadow(16, 37, 14, 2.5)
    s.disc(16, 29, 13, 8, STONE_D)                 # the round wall
    s.disc(16, 28, 12.4, 7.2, STONE)
    s.disc(16, 26, 9, 4.2, c("#5a524a"))
    s.disc(16, 26.6, 8, 3.4, c("#2c4a6a"))         # the water down below
    s.hline(13, 16, 26, c("#6a90b0"))
    for a in range(200, 345, 25):                   # stones on its front
        x = 16 + math.cos(math.radians(a)) * -12
        y = 30 + math.sin(math.radians(a)) * -5
        s.p(x, y, STONE_D)
    for x in (5, 26):                              # the posts and their little roof
        s.rect(x, 6, x + 1, 30, WOOD_D)
        s.vline(x, 6, 30, WOOD)
    roof_c = c("#a8342e")
    s.poly([(2, 7), (16, 0), (30, 7), (30, 9), (2, 9)], roof_c)
    s.line(2, 7, 16, 0, shade(roof_c, 0.3))
    s.hline(2, 30, 9, shade(roof_c, -0.3))
    s.hline(6, 26, 12, WOOD_D)                     # the winch, the rope, the bucket
    s.vline(16, 12, 20, c("#d8c8a0"))
    s.rect(14, 20, 18, 23, WOOD)
    s.hline(14, 18, 20, IRON)
    s.outline(0.45)
    return s


def pillar(v: int) -> Px:
    s = Px(16, 32)
    s.shadow(8, 30.5, 6, 1.6)
    s.rect(2, 26, 13, 30, STONE_D)                 # base
    s.rect(2, 26, 13, 27, STONE_L)
    s.rect(4, 4, 11, 26, STONE)
    s.vline(4, 4, 26, STONE_L)
    s.vline(10, 4, 26, shade(STONE, -0.15))
    s.vline(11, 4, 26, STONE_D)
    for x in (6, 8):                               # fluting
        s.vline(x, 5, 25, shade(STONE, -0.08))
    s.rect(2, 1, 13, 4, STONE)                     # capital
    s.hline(2, 13, 1, STONE_L)
    s.hline(2, 13, 4, STONE_D)
    s.outline(0.45)
    return s


def statue(v: int) -> Px:
    """A knight in stone on a plinth."""
    s = Px(16, 32)
    s.shadow(8, 30.5, 6, 1.6)
    s.rect(2, 24, 13, 30, STONE_D)
    s.rect(2, 24, 13, 25, STONE_L)
    st, st_l, st_d = c("#b8b0a4"), c("#d8d0c4"), c("#8a8278")
    s.disc(8, 4, 2.4, 2.4, st)                     # head
    s.p(7, 3, st_l)
    s.rect(5, 7, 10, 16, st)                       # body
    s.vline(5, 7, 16, st_l)
    s.vline(10, 7, 16, st_d)
    s.rect(5, 17, 7, 23, st)                       # legs
    s.rect(8, 17, 10, 23, st_d)
    s.vline(12, 2, 22, st_l)                       # a sword held point down
    s.hline(11, 13, 8, st)
    s.rect(2, 8, 4, 15, st_d)                      # a shield
    s.vline(2, 8, 15, st)
    s.outline(0.45)
    return s


def altar(v: int) -> Px:
    s = Px(32, 20)
    s.shadow(16, 18.5, 15, 1.8)
    _box(s, 1, 6, 30, 17, STONE, top=6)
    s.rect(9, 6, 22, 17, c("#e8e0d0"))             # an altar cloth
    s.rect(9, 6, 22, 11, c("#f4ecd8"))
    s.rect(14, 12, 17, 16, GOLD)                   # a sun sigil
    s.p(15, 13, GOLD_L)
    for x in (4, 27):                              # candles
        s.rect(x, 2, x + 1, 8, c("#f4ecd8"))
        s.p(x, 1, FIRE[2])
        s.p(x, 0, FIRE[3])
    s.outline(0.45)
    return s


def haybale(v: int) -> Px:
    s = Px()
    s.shadow(8, 14.5, 7, 1.8)
    hay = c("#d8b858")
    _box(s, 1, 4, 14, 14, hay, top=5)
    r = rng("hay3", v)
    s.speckle(r, 22, [shade(hay, 0.2), shade(hay, -0.15)], 1, 4, 14, 14)
    for x in (5, 10):                              # binding twine
        s.vline(x, 4, 14, c("#8a6a3a"))
    s.outline(0.45)
    return s


def fence(v: int) -> Px:
    s = Px(16, 18)
    s.shadow(8, 16, 8, 1.4, 50)
    for x in (2, 13):                              # posts
        s.rect(x, 3, x + 1, 16, WOOD)
        s.vline(x, 3, 16, WOOD_L)
        s.p(x, 3, shade(WOOD_L, 0.2))
    for y in (6, 11):                              # rails
        s.rect(0, y, 15, y + 1, WOOD)
        s.hline(0, 15, y, WOOD_L)
    s.outline(0.45)
    return s


def cart(v: int) -> Px:
    s = Px(32, 22)
    s.shadow(16, 20.5, 14, 1.8)
    _box(s, 3, 4, 26, 14, WOOD, top=6)             # the bed
    for x in (8, 14, 20):
        s.vline(x, 10, 14, WOOD_D)
    s.rect(5, 5, 12, 8, c("#d8b858"))              # sacks and a barrel in it
    s.disc(18, 7, 2.5, 2, c("#c8b890"))
    s.disc(22, 7, 2.5, 2, c("#c8b890"))
    s.line(26, 12, 31, 14, WOOD_D)                 # the shaft
    for cx in (8, 22):                             # wheels
        s.disc(cx, 16, 4, 4, WOOD_D)
        s.disc(cx, 16, 2.8, 2.8, c("#4a2c18"))
        s.line(cx - 3, 16, cx + 3, 16, WOOD)
        s.line(cx, 13, cx, 19, WOOD)
        s.p(cx, 16, IRON)
    s.outline(0.45)
    return s


def grave(v: int) -> Px:
    s = Px(16, 20)
    soil = c("#6a4a32")
    s.disc(8, 16, 6, 3, soil)                      # the mound
    s.disc(7.5, 15.5, 4.5, 2, shade(soil, 0.12))
    s.rect(4, 2, 11, 13, STONE)                    # the headstone
    s.disc(7.5, 3, 3.6, 2, STONE)
    s.vline(4, 3, 13, STONE_L)
    s.vline(11, 3, 13, STONE_D)
    s.vline(7, 5, 10, STONE_D)                     # a cross carved in it
    s.hline(6, 9, 7, STONE_D)
    s.p(13, 16, c("#f0e0f0"))                      # flowers someone left
    s.p(12, 17, c("#c890e0"))
    s.outline(0.45)
    return s


def stairs(down: bool) -> Px:
    s = Px()
    if down:                                       # steps going down into the dark
        for i in range(5):
            y = i * 3
            tone = shade(STONE, -0.12 * i)
            s.rect(1, y, 14, y + 2, tone)
            s.hline(1, 14, y, shade(tone, 0.2))
        s.rect(1, 14, 14, 15, c("#1a1418"))
        s.vline(0, 0, 15, STONE_D)
        s.vline(15, 0, 15, STONE_D)
    else:                                          # steps rising toward the light
        for i in range(5):
            y = 12 - i * 3
            tone = shade(STONE, 0.06 * i)
            s.rect(1, y, 14, y + 3, shade(tone, -0.15))
            s.rect(1, y, 14, y + 1, tone)
            s.hline(1, 14, y, shade(tone, 0.2))
        s.vline(0, 0, 15, WOOD_D)
        s.vline(15, 0, 15, WOOD_D)
    return s


def pew(v: int) -> Px:
    s = Px(32, 18)
    s.shadow(16, 16.5, 15, 1.6)
    s.rect(1, 1, 30, 7, WOOD_D)                    # the back
    s.rect(2, 2, 29, 6, WOOD)
    s.hline(2, 29, 2, WOOD_L)
    _box(s, 1, 8, 30, 12, WOOD, top=3)
    _legs(s, (1, 30), 13, 16)
    s.outline(0.5)
    return s


def rack(v: int) -> Px:
    """A weapon rack: swords, spears or axes."""
    s = Px(32, 24)
    s.shadow(16, 22.5, 14, 1.6)
    s.rect(1, 2, 2, 22, WOOD)
    s.rect(29, 2, 30, 22, WOOD)
    s.rect(1, 6, 30, 7, WOOD)
    s.rect(1, 18, 30, 19, WOOD)
    s.hline(1, 30, 6, WOOD_L)
    for x in range(6, 27, 5):
        if v % 3 == 0:                             # swords
            s.vline(x, 4, 18, IRON_L)
            s.vline(x + 1, 5, 18, IRON)
            s.hline(x - 1, x + 2, 15, GOLD)
            s.vline(x, 16, 20, WOOD_D)
        elif v % 3 == 1:                           # spears
            s.vline(x, 2, 21, WOOD)
            s.rect(x - 1, 0, x + 1, 2, IRON_L)
            s.p(x, 0, c("#ffffff"))
        else:                                      # axes
            s.vline(x, 4, 21, WOOD)
            s.rect(x + 1, 4, x + 3, 8, IRON)
            s.vline(x + 3, 4, 8, IRON_L)
    s.outline(0.45)
    return s


def tub(v: int) -> Px:
    s = Px(32, 16)
    s.shadow(16, 14.5, 15, 1.6)
    s.disc(16, 8, 14.5, 6.5, WOOD_D)
    s.disc(16, 7.6, 13.5, 5.6, WOOD)
    s.disc(16, 7, 11, 4, c("#6aa8c8"))             # the water
    s.hline(10, 15, 5, c("#c8e8f4"))
    s.hline(18, 21, 8, c("#c8e8f4"))
    for x in (6, 26):
        s.vline(x, 8, 13, IRON)
    s.outline(0.45)
    return s


def throne(v: int) -> Px:
    s = Px(16, 28)
    s.shadow(8, 26.5, 7, 1.6)
    s.rect(2, 0, 13, 26, GOLD)                     # the high back
    s.rect(3, 2, 12, 15, c("#a8242e"))
    s.rect(4, 3, 11, 14, c("#c8343e"))
    s.p(7, 0, GOLD_L)
    s.clear(2, 0)
    s.clear(13, 0)
    s.p(5, 1, c("#e04a5a"))                        # jewels in the crest
    s.p(10, 1, c("#4a80e0"))
    _box(s, 1, 16, 14, 22, c("#c8343e"), top=3)     # the seat cushion
    s.rect(0, 15, 1, 25, GOLD)                     # arms
    s.rect(14, 15, 15, 25, GOLD)
    s.rect(2, 23, 13, 26, shade(GOLD, -0.2))
    s.outline(0.45)
    return s


RUGS = [(c("#2e5a8a"), c("#1e3a60"), GOLD), (c("#a8342e"), c("#7a2024"), GOLD), (c("#3e7a4a"), c("#2a5634"),
                                                                                c("#e8dcc0"))]


def rug(v: int) -> Px:
    s = Px(32, 32)
    body, dk, trim = RUGS[v % 3]
    s.rect(1, 2, 30, 29, body)
    s.rect(1, 2, 30, 2, trim)
    s.rect(1, 29, 30, 29, trim)
    s.vline(1, 2, 29, trim)
    s.vline(30, 2, 29, trim)
    s.rect(4, 5, 27, 26, dk)
    s.rect(5, 6, 26, 25, body)
    for i in range(10):                            # a lozenge in the middle
        s.hline(16 - i, 15 + i, 6 + i, dk if i % 3 else trim)
        s.hline(16 - i, 15 + i, 25 - i, dk if i % 3 else trim)
    s.rect(13, 13, 18, 18, trim)
    for x in range(2, 30, 2):                      # tassels at both ends
        s.p(x, 1, c("#f0e0b0"))
        s.p(x, 30, c("#f0e0b0"))
    return s


def signpost(v: int) -> Px:
    s = Px(16, 26)
    s.shadow(8, 24.5, 4, 1.4)
    s.rect(7, 3, 8, 24, WOOD)
    s.vline(7, 3, 24, WOOD_L)
    s.poly([(1, 4), (12, 4), (15, 6.5), (12, 9), (1, 9)], c("#c89860"))        # arrow boards
    s.hline(2, 11, 6, c("#6a4a2a"))
    s.poly([(14, 11), (3, 11), (0, 13.5), (3, 16), (14, 16)], c("#b88850"))
    s.hline(4, 13, 13, c("#6a4a2a"))
    s.outline(0.45)
    return s


def cave_mouth(v: int) -> Px:
    s = Px(32, 32)
    rock_c = c("#8a7c70")
    s.disc(16, 17, 16, 15, shade(rock_c, -0.3))
    s.disc(15.4, 16, 15, 14, rock_c)
    s.speckle(rng("cave-mouth"), 30, [shade(rock_c, 0.15), shade(rock_c, -0.18)], 1, 2, 30, 30)
    s.disc(11, 8, 6, 4, shade(rock_c, 0.2))
    s.disc(16, 24, 9, 9, c("#120e10"))              # the dark way in
    s.rect(7, 24, 25, 31, c("#120e10"))
    s.disc(16, 24, 7, 7, c("#000000"))
    s.hline(9, 23, 31, c("#2a2228"))
    s.outline(0.45)
    return s


def lamp(v: int) -> Px:
    s = Px(16, 30)
    _glow(s, 8, 6, 8, c("#ffe090"), 60)
    s.shadow(8, 28.5, 3.5, 1.2)
    s.rect(7, 8, 8, 28, IRON)
    s.vline(7, 8, 28, IRON_L)
    s.rect(5, 26, 10, 28, IRON_D)
    s.rect(5, 2, 10, 8, IRON_D)                    # the lantern
    s.rect(6, 3, 9, 7, c("#f6d870"))
    s.rect(7, 4, 8, 6, c("#fff4c0"))
    s.hline(4, 11, 2, IRON)
    s.p(7, 1, IRON)
    s.outline(0.45)
    return s


def fountain(v: int) -> Px:
    s = Px(32, 36)
    s.shadow(16, 33, 15, 2.5)
    s.disc(16, 26, 15, 8, STONE_D)                 # the basin
    s.disc(16, 25, 14.4, 7.2, STONE)
    s.disc(16, 24, 11.5, 5, c("#3c84b8"))
    for (x, y) in ((9, 23), (20, 25), (13, 26)):
        s.hline(x, x + 2, y, c("#a8d8f0"))
    s.rect(14, 10, 17, 24, STONE)                  # the column and its bowl
    s.vline(14, 10, 24, STONE_L)
    s.disc(16, 10, 5, 2, STONE)
    s.disc(16, 9.6, 4, 1.2, c("#5a9ad0"))
    for (x0, x1) in ((11, 8), (21, 24)):            # water falling
        s.line(x0, 10, x1, 21, c("#c8e8f8"))
    s.vline(16, 3, 8, c("#c8e8f8"))
    s.p(16, 2, c("#ffffff"))
    s.outline(0.45)
    return s


def sale_sign(v: int) -> Px:
    s = Px(16, 24)
    s.shadow(8, 22.5, 4, 1.4)
    s.rect(7, 2, 8, 22, WOOD)
    s.vline(7, 2, 22, WOOD_L)
    s.rect(1, 4, 14, 12, c("#f0e2c0"))             # the board
    s.hline(1, 14, 4, c("#fff4dc"))
    s.rect(0, 3, 15, 3, WOOD_D)
    for (x0, x1, y) in ((3, 6, 6), (8, 12, 6), (3, 12, 9)):
        s.hline(x0, x1, y, c("#a8342e"))           # "FOR SALE", as a passer-by sees it
    s.p(12, 11, GOLD)                              # a coin painted in the corner
    s.outline(0.45)
    return s


# ======================================================================
# Destruction (game/destruction.py, game/fire.py): fallen trees, splinters, charred and young trees
# ======================================================================
def fallen_trunk(v: int) -> Px:
    """A length of felled trunk on its square: 0 lying east-west, 1 north-south, 2 and 3 aslant."""
    s = Px()
    bark = c("#7a4e30")
    k = v % 4
    if k == 0:
        s.shadow(8, 12.5, 8, 1.5, 55)
        s.rect(0, 6, 15, 11, bark)
        s.hline(0, 15, 6, shade(bark, 0.18))
        s.hline(0, 15, 11, shade(bark, -0.3))
        s.hline(4, 7, 8, shade(bark, -0.2))
        s.hline(10, 13, 9, shade(bark, -0.2))
    elif k == 1:
        s.shadow(9, 8, 3.5, 8, 55)
        s.rect(5, 0, 10, 15, bark)
        s.vline(5, 0, 15, shade(bark, 0.18))
        s.vline(10, 0, 15, shade(bark, -0.3))
        s.vline(7, 3, 6, shade(bark, -0.2))
        s.vline(8, 9, 12, shade(bark, -0.2))
    else:
        s.shadow(8, 9, 7, 6, 45)
        for i in range(-1, 17):
            x, y = (i, i) if k == 2 else (15 - i, i)
            for d in range(-2, 3):
                col = shade(bark, 0.18) if d == -2 else shade(bark, -0.3) if d == 2 else bark
                s.p(x + d, y, col)
    s.outline(0.45)
    return s


def branches(v: int) -> Px:
    """The crown of a felled tree, lying where it came down: a tangle of leafy boughs."""
    r = rng("branches3", v)
    s = Px()
    s.shadow(8, 11, 7, 4, 50)
    green = LEAF[v % 3]
    wood = c("#6a4228")
    for _ in range(4):
        s.line(8, 8, r.randint(1, 14), r.randint(2, 14), wood)
    for _ in range(7):
        s.lit_disc(r.randint(3, 12), r.randint(4, 12), r.uniform(2, 3.5), r.uniform(1.5, 3), green)
    s.outline(0.45)
    return s


def debris(v: int) -> Px:
    """What's left of a smashed table, crate or cart: splintered planks and a bent nail or two."""
    r = rng("debris3", v)
    s = Px()
    s.shadow(8, 12, 6.5, 2, 45)
    for _ in range(6):
        x, y = r.randint(2, 12), r.randint(6, 12)
        L = r.randint(3, 6)
        col = shade(WOOD, r.uniform(-0.25, 0.1))
        if r.random() < 0.5:
            s.hline(x, min(15, x + L), y, col)
            s.p(min(15, x + L), y - 1, shade(col, 0.2))
        else:
            s.line(x, y, min(15, x + L // 2), max(2, y - L // 2), col)
    s.p(r.randint(4, 11), r.randint(8, 12), IRON_L)
    s.outline(0.45)
    return s


def burnt_tree(v: int) -> Px:
    """A tree the fire went through: a black trunk and a few bare, charred limbs."""
    s = Px(24, 36)
    s.shadow(12, 33, 6, 1.5, 70)
    char, ember = c("#2a2420"), c("#4a3c34")
    s.rect(10, 12, 13, 33, char)
    s.vline(10, 14, 32, ember)
    for (x0, y0, x1, y1) in ((11, 18, 4, 9), (12, 15, 19, 6), (12, 22, 20, 16), (11, 25, 5, 19), (12, 12, 12, 4)):
        s.line(x0, y0, x1, y1, char)
    if v % 2:
        s.p(11, 28, c("#c8502e"))                  # still smouldering
    s.outline(0.4)
    return s.flipped() if v % 3 == 2 else s


def sapling(v: int) -> Px:
    """A young tree come up thick after a fire: a slim stem and a little crown."""
    s = Px(16, 24)
    s.shadow(8, 21.5, 4, 1.2, 60)
    s.vline(8, 11, 21, c("#7a5a38"))
    green = [c("#5aa040"), c("#4e9038"), c("#66aa48")][v % 3]
    for (bx, by, rx, ry) in ((8, 8, 5, 4), (5, 10, 3, 2.5), (11, 10, 3, 2.5)):
        s.lit_disc(bx, by, rx, ry, green)
    s.outline(0.5)
    return s.flipped() if v % 2 else s


# ======================================================================
# The list: id -> (draw, variants)
# ======================================================================
DRAW = {
    "tree": (oak, 6), "big_tree": (big_tree, 3), "pine": (pine, 3), "bush": (bush, 4), "rock": (rock, 4),
    "boulder": (boulder, 2), "stump": (stump, 1), "log": (log, 1), "mushrooms": (mushrooms, 3),
    "barrel": (barrel, 1), "crate": (crate, 1), "table": (table, 3), "chair": (chair, 1), "bed": (bed, 3),
    "bookshelf": (bookshelf, 3), "counter": (counter, 1), "anvil": (anvil, 1), "forge": (forge, 1),
    "chest": (chest, 1), "campfire": (campfire, 1), "workbench": (workbench, 1), "loom": (loom, 1),
    "tanning_rack": (tanning_rack, 1), "alchemy_table": (alchemy_table, 1), "jeweler_bench": (jeweler_bench, 1),
    "writing_desk": (writing_desk, 1), "stove": (stove, 1), "brazier": (brazier, 1), "well": (well, 1),
    "pillar": (pillar, 1), "statue": (statue, 1), "bones": (bones, 1), "rubble": (rubble, 3), "altar": (altar, 1),
    "haybale": (haybale, 1), "fence": (fence, 1), "cart": (cart, 1), "grave": (grave, 1),
    "stairs_up": (lambda v: stairs(False), 1), "stairs_down": (lambda v: stairs(True), 1), "pew": (pew, 1),
    "rack": (rack, 3), "tub": (tub, 1), "throne": (throne, 1), "rug": (rug, 3), "signpost": (signpost, 1),
    "cave_mouth": (cave_mouth, 1), "lamp": (lamp, 1), "fountain": (fountain, 1), "sale_sign": (sale_sign, 1),
    "crops": (crops, 3), "ore_vein": (ore_vein, 6), "quarry_rock": (quarry_rock, 3), "herb_patch": (herbs, 4),
    "wild_grain": (grain, 3), "berry_bush": (berry_bush, 3), "fishing_spot": (fishing_spot, 1),
    "rich_vein": (rich_vein, 1), "rare_herbs": (rare_herbs, 1), "spent_vein": (spent_vein, 3),
    "bare_patch": (bare_patch, 2), "carcass": (carcass, 1),
    "fallen_trunk": (fallen_trunk, 4), "branches": (branches, 3), "debris": (debris, 3),
    "burnt_tree": (burnt_tree, 3), "sapling": (sapling, 3),
}


__all__ = ["DRAW", "ORES"]
