"""Paper-doll compositing: body base + customization + equipped gear -> one sprite.

    sprite = compose(Look(base="dwarf", hair_color="#c04a1a"),
                     Gear(armor="chain_mail", weapon="warhammer", shield="round"),
                     tiles=1)

Layers are stacked in a fixed order and each group gets its own outline, which
gives clean separation between e.g. a sword and the hand holding it.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from game.art.canvas import Canvas
from game.art import gear as G
from game.art.humanoid import BODY_BASES, BUILDS, Look, draw_body, draw_hair, draw_shadow, make_frame

# Outline groups, back to front.
GROUPS = [
    ("back", "helmet_back"),
    ("cloak",),
    ("feet",),
    ("torso", "armor_body", "custom_body"),
    ("arms", "armor_arms"),
    ("weapon", "custom_main"),
    ("hands", "gloves"),
    ("head", "face_front", "hair", "ears", "helmet", "head_top", "custom_head"),
    ("shield", "weapon_off", "custom_off"),
    ("custom_other",),
]

HELMETS_HIDE_EARS = {"great_helm", "coif", "horned_helm", "hood"}


@dataclass
class Gear:
    armor: str = ""             # gear.ARMOR_STYLES id
    armor_tint: str = ""
    helmet: str = ""            # gear.HELMETS id (also comes with some armor)
    helmet_tint: str = ""
    cloak: str = ""             # gear.CLOAKS id
    cloak_color: str = "#7a2a2a"
    weapon: str = ""            # gear.WEAPONS id
    weapon_tint: str = ""
    off_weapon: str = ""        # a weapon or torch held in the off hand
    off_weapon_tint: str = ""
    shield: str = ""            # gear.SHIELDS id
    shield_tint: str = ""
    shield_color: str = ""
    # Hand-drawn layers for custom items: list of (slot, Canvas at 32x32)
    custom: list = field(default_factory=list)

    def two_handed(self) -> bool:
        if self.weapon and G.weapon_two_handed(self.weapon):
            return True
        return any(slot == "Two hands" for slot, _ in self.custom)


def compose(look: Look, gear: Gear | None = None, tiles: int = 1, shadow: bool = True) -> Canvas:
    gear = gear or Gear()
    look = look.resolved()
    size = 32 * max(1, int(tiles))
    base = BODY_BASES.get(look.base, BODY_BASES["human"])
    two = gear.two_handed()
    frame = make_frame(size, BUILDS[base.build], two_handed=two)

    layers: dict[str, Canvas] = {}
    if gear.cloak:
        G.draw_cloak(gear.cloak, frame, layers, gear.cloak_color or "#7a2a2a")
    draw_body(frame, look, layers)
    if gear.armor:
        G.draw_armor(gear.armor, frame, layers, tint=gear.armor_tint or None, helmet=not gear.helmet)
    if gear.helmet:
        G.draw_helmet(gear.helmet, frame, layers, tint=gear.helmet_tint or None)
    if gear.weapon:
        G.draw_weapon(gear.weapon, frame, layers, tint=gear.weapon_tint or None)
    if gear.off_weapon and not two and not gear.shield:
        tmp: dict[str, Canvas] = {}
        G.draw_weapon(gear.off_weapon, frame, tmp, tint=gear.off_weapon_tint or None)
        if "weapon" in tmp:
            layers["weapon_off"] = tmp["weapon"].flipped_h()
    if gear.shield and not two:
        G.draw_shield(gear.shield, frame, layers, tint=gear.shield_tint or None, color=gear.shield_color or None)

    # Helmets hide most of the hair (long hair still shows down the back).
    helmet_kind = gear.helmet or (G.ARMOR_STYLES[gear.armor].helmet if gear.armor in G.ARMOR_STYLES else "")
    if "_hides_hair" in layers:
        layers.pop("hair", None)
        if helmet_kind in HELMETS_HIDE_EARS:
            layers.pop("ears", None)
    if "_hair_short" in layers:
        layers.pop("hair", None)
    layers.pop("_hides_hair", None)
    layers.pop("_hair_short", None)

    _place_custom(gear.custom, size, layers)

    out = draw_shadow(size, footprint=0.92) if shadow else Canvas(size)
    for group in GROUPS:
        g = Canvas(size)
        for name in group:
            if name in layers:
                g.blit(layers[name])
        if not g.is_empty():
            g.outline()
            out.blit(g)
    return out


SLOT_LAYER = {
    "Main hand": "custom_main", "Two hands": "custom_main", "Off hand": "custom_off",
    "Body": "custom_body", "Head": "custom_head", "Cloak": "cloak",
}


def _place_custom(custom: list, size: int, layers: dict[str, Canvas]) -> None:
    for slot, art in custom:
        if art is None:
            continue
        scaled = scale_nearest(art, size // max(1, art.w)) if art.w != size else art
        name = SLOT_LAYER.get(slot, "custom_other")
        layers.setdefault(name, Canvas(size)).blit(scaled)


def scale_nearest(c: Canvas, factor: int) -> Canvas:
    factor = max(1, int(factor))
    if factor == 1:
        return c.copy()
    out = Canvas(c.w * factor, c.h * factor)
    for y in range(out.h):
        for x in range(out.w):
            out.px[y * out.w + x] = c.px[(y // factor) * c.w + x // factor]
    return out


# ----------------------------------------------------------------------
# Single-piece renders (inventory icons, picker thumbnails)
# ----------------------------------------------------------------------
def gear_icon(kind: str, piece: str, tint: str = "", color: str = "") -> Canvas:
    """A 32x32 icon of one piece of gear on its own."""
    size = 32
    frame = make_frame(size, BUILDS["average"])
    layers: dict[str, Canvas] = {}
    if kind == "weapon":
        G.draw_weapon(piece, frame, layers, tint=tint or None, icon=True)
    elif kind == "shield":
        G.draw_shield(piece, frame, layers, tint=tint or None, color=color or None, icon=True)
    elif kind == "armor":
        f2 = make_frame(size, BUILDS["average"])
        G.draw_armor(piece, f2, layers, tint=tint or None, helmet=False)
        layers.pop("gloves", None)
    elif kind == "helmet":
        f2 = make_frame(56, BUILDS["average"])
        sub: dict[str, Canvas] = {}
        G.draw_helmet(piece, f2, sub, tint=tint or None)
        sub.pop("_hides_hair", None)
        sub.pop("_hair_short", None)
        big = Canvas(56)
        for n in ("helmet_back", "helmet"):
            if n in sub:
                big.blit(sub[n])
        hx, hy, _ = f2.head
        crop = Canvas(32)
        ox, oy = int(hx - 16), int(hy - 16)
        for y in range(32):
            for x in range(32):
                crop.px[y * 32 + x] = big.get(x + ox, y + oy)
        layers["helmet"] = crop
    elif kind == "cloak":
        G.draw_cloak(piece, frame, layers, color or "#7a2a2a", tint=tint or None)
    out = Canvas(size)
    for name in ("cloak", "armor_body", "armor_arms", "helmet", "weapon", "shield"):
        if name in layers:
            g = layers[name].copy()
            g.outline()
            out.blit(g)
    return out
