"""The game's icon (step 19): a twenty-sided die in the house style (game/art/pixart.py), in the brown of the
main menu's buttons, with "YanCo" over "RPG" across its face in the buttons' cream, in the game's pixel font
(the words may run past the die's edges; they're centred on it). 48 x 48 art pixels, lit from the top left.
Used for the window and the Android app's launcher.

    python -m game.art.icon        writes game/art/icon.png (480 x 480) and icon-192.png
"""
from __future__ import annotations

from pathlib import Path

from game.art import pixelfont as F
from game.art.canvas import Canvas
from game.art.pixart import Px, c, shade

SIZE = 48
BROWN = c("#9e5424")          # the main menu's button planks (game/art/uiskin.py, button_primary)
CREAM = c("#fff0cd")          # the words on them (ui/theme.py, accent_text)
INK = c("#2a1208")            # round the words, so they read on any face of the die

O = 4                          # the die's 40 x 40 box inside the icon (drawn from a 32 x 32 plan, x 1.25)
K = 1.25
G = [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###."]   # a G that can't be read as a 6
TOP, UR, LR, BOT, LL, UL = (16, 1), (29, 8.5), (29, 23.5), (16, 31), (3, 23.5), (3, 8.5)
FACE = [(16, 6), (25.5, 22), (6.5, 22)]          # the middle face (point up)


def _at(pt):
    return (pt[0] * K + O, pt[1] * K + O)


def _words(s: Px, text: str, y: int) -> None:
    """A line of the pixel font, each stroke two pixels wide, centred across the icon, ringed in ink."""
    on = set()
    x = (SIZE - (F.width(text) + len(text))) // 2      # (each letter a pixel wider for the bolder strokes)
    for ch in text:
        rows = G if ch == "G" else F.glyph(ch)
        for gy, row in enumerate(rows):
            for gx, bit in enumerate(row):
                if bit == "#":
                    on.add((x + gx, y + gy))
                    on.add((x + gx + 1, y + gy))
        x += len(rows[0]) + 2
    for (px, py) in on:
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                if (px + dx, py + dy) not in on:
                    s.p(px + dx, py + dy, INK)
    for (px, py) in on:
        s.p(px, py, CREAM)


def draw() -> Canvas:
    s = Px(SIZE, SIZE)
    a, b, m = FACE
    faces = [                                    # the faces round the middle one, lit from the top left
        ([TOP, UL, a], 0.30), ([TOP, a, UR], 0.12), ([UR, a, b], -0.05), ([UR, LR, b], -0.22),
        ([LR, BOT, b], -0.32), ([BOT, m, b], -0.18), ([BOT, LL, m], -0.30), ([LL, UL, m], -0.08),
        ([UL, a, m], 0.18),
    ]
    for pts, light in faces:
        s.poly([_at(p) for p in pts], shade(BROWN, light))
    s.poly([_at(p) for p in FACE], shade(BROWN, 0.05))
    edge = shade(BROWN, -0.55)
    for p0, p1 in ((a, b), (b, m), (m, a), (TOP, a), (UR, a), (UR, b), (LR, b), (BOT, b), (BOT, m), (LL, m),
                   (UL, m), (UL, a)):
        p0, p1 = _at(p0), _at(p1)
        s.line(round(p0[0]), round(p0[1]), round(p1[0]), round(p1[1]), edge)
    for gx, gy in ((9, 10), (10, 9)):              # a glint
        s.p(round(gx * K + O), round(gy * K + O), shade(BROWN, 0.6))
    s.outline(0.5)
    # "YanCo" over "RPG", the pair centred on the die
    gap = 3
    top = round(O + 18 * K) - (2 * F.BASELINE + gap) // 2
    _words(s, "YanCo", top)
    _words(s, "RPG", top + F.BASELINE + gap)
    return s.done()


def write(folder: Path | None = None) -> list[Path]:
    folder = Path(folder or Path(__file__).parent)
    cv = draw()                                   # (Px doubles: 96 x 96 screen pixels)
    out = []
    for name, scale in (("icon.png", 5), ("icon-192.png", 2)):
        path = folder / name
        path.write_bytes(cv.to_png(scale))
        out.append(path)
    return out


if __name__ == "__main__":
    for p in write():
        print(p)
