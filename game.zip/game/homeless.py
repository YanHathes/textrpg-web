"""The homeless (Hotfix 22): the share of a town's people who don't live in its houses.

How many
    Each tier has an average share of its people sleeping rough (SHARE: from 2% of a hamlet to 12% of a
    capital), and each town sits somewhere around its tier's average (SPREAD, fixed by the town), but never
    more than a third of the town (MOST_SHARE). count(town) is that many people; the walking map shows some
    of them (shown(town): one figure for every PER_FIGURE, between the tier's FIGURES), enough to notice.
Where
    By night they're out of doors, bedded down against the walls of the town's buildings, and stay put. By
    day they drift about the streets near where they slept. They're the same people every day (the town's
    roster), not saved: nothing about them is in the world but the town's population.
Who
    Most sleep rough for want of work; some had a trade once (SKILLED_SHARE) and some live by quick fingers
    (THIEF_SHARE): those try a purse when the party passes close by (game/thieves.py), by day or by night,
    crowd or no crowd. Only ever coin, as with every cutpurse.
Hiring
    Speak to one and you can offer them work: a hired hand for your land (game/estate.py) at a fraction of
    a townsperson's wage (WAGE_SHARE). They become a person of the save (an overlay NPC), and leave the
    roster (holdings["workers"][i]["homeless"]).
"""
from __future__ import annotations

import math
import random
import zlib

from game import settlements as ST

SHARE = {"Camp": 0.0, "Hamlet": 0.02, "Village": 0.03, "Town": 0.05, "City": 0.08, "Capital": 0.12}
SPREAD = (0.6, 1.4)                       # a town's share, against its tier's average
MOST_SHARE = 1 / 3
PER_FIGURE = {"Hamlet": 1, "Village": 2, "Town": 4, "City": 12, "Capital": 20}
FIGURES = {"Hamlet": (0, 1), "Village": (1, 3), "Town": (5, 10), "City": (10, 18), "Capital": (14, 24)}
SKILLED_SHARE = 0.15
THIEF_SHARE = 0.3
WAGE_SHARE = 0.4                          # of a hired hand's wage
ROLE = "homeless"
TRADES = ["mason", "carpenter", "smith", "weaver", "tanner", "cooper", "farmer", "miner", "potter"]
TRADE_OCC = {"mason": "Mason", "carpenter": "Carpenter", "smith": "Blacksmith", "weaver": "Weaver",
             "tanner": "Leatherworker", "cooper": "Carpenter", "farmer": "Farmer", "miner": "Miner",
             "potter": "Potter"}
TITLES = ["vagrant", "beggar", "drifter", "rough sleeper"]
LINES = ["Spare a copper? Anything helps.", "Cold one tonight.", "Don't mind me. I'm not going anywhere.",
         "The watch moves us on, we come back. Where else would we go?", "Bless you, whatever you give.",
         "I had a house once. Roof and all.", "Got any work? I'll do anything. Anything honest, mostly.",
         "The temple gives out bread at dawn, if you're quick.", "Watch your purse round here. Not from me, mind."]
TRADE_LINES = ["I was a {trade} before the debts. Good one, too.", "Give me a day's work and I'll show you. "
               "I was a {trade} once.", "Hands still remember the {trade}'s work. Nobody wants them."]
DRAB = ("#5a5048", "#4a4038", "#4f4a40", "#5b5446", "#463e36")


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


def share(town) -> float:
    """The share of this town that sleeps rough: its tier's average, give or take (fixed by the town)."""
    if town is None:
        return 0.0
    avg = SHARE.get(ST.tier_of(town), 0.0)
    lo, hi = SPREAD
    return min(MOST_SHARE, avg * (lo + (hi - lo) * _rng("homeless share", town.id).random()))


def count(town) -> int:
    """How many of the town's people are homeless (never more than a third)."""
    pop = int(town.fields.get("population") or 0) if town is not None else 0
    return min(pop // 3, int(round(pop * share(town))))


def shown(town) -> int:
    """How many of them the walking map shows."""
    n = count(town)
    if n <= 0:
        return 0
    tier = ST.tier_of(town)
    lo, hi = FIGURES.get(tier, (0, 0))
    want = math.ceil(n / PER_FIGURE.get(tier, 4))
    return min(n, max(lo, min(hi, want)))


def hired_ids(state) -> set:
    h = getattr(state, "holdings", None) or {}
    return {w.get("homeless") for w in (h.get("workers") or []) if w.get("homeless")}


def roster(world, town, state=None, looks: list | None = None) -> list[dict]:
    """The town's homeless the map shows, as crowd figures (game/crowds.py) with "role" "homeless":
    [{"id", "name", "race", "role", "look", "armor", "tint", "line", "thief", "trade", "sex"}]."""
    from game.art.humanoid import BODY_BASES, HAIR_STYLES
    n = shown(town)
    if not n:
        return []
    gone = hired_ids(state) if state is not None else set()
    out = []
    for i in range(n):
        hid = f"homeless:{town.id}:{i}"
        if hid in gone:
            continue
        rng = _rng("homeless", town.id, i)
        base = (rng.choice(looks).get("base") if looks else "") or "human"
        if base == "automaton":
            base = "human"
        b = BODY_BASES.get(base) or BODY_BASES["human"]
        male = rng.random() < 0.55
        hair = "none" if b.hair == "none" else ("ragged" if "ragged" in HAIR_STYLES and rng.random() < 0.6
                                                 else rng.choice([h for h in HAIR_STYLES if h not in ("none", "mane")]))
        look = {"base": b.id, "skin": rng.choice(b.skin_options) if b.skin_options else b.skin, "hair": hair,
                "hair_color": rng.choice(b.hair_options) if b.hair_options else b.hair_color,
                "beard": (rng.choice(["stubble", "full", "full", "short"]) if male and b.hair != "none" and
                          "metal" not in b.features else "none"),
                "clothes": rng.choice(DRAB), "sex": "male" if male else "female"}
        trade = rng.choice(TRADES) if rng.random() < SKILLED_SHARE else ""
        thief = rng.random() < THIEF_SHARE
        title = rng.choice(TITLES)
        line = rng.choice(TRADE_LINES).format(trade=trade) if trade and rng.random() < 0.6 else rng.choice(LINES)
        out.append({"id": hid, "name": f"{b.label} {title}", "race": b.id, "role": ROLE, "look": look,
                    "armor": "tunic", "tint": look["clothes"], "line": line, "thief": thief, "trade": trade,
                    "sex": look["sex"]})
    return out


def is_homeless(d: dict | None) -> bool:
    return bool(d) and d.get("role") == ROLE


def at_night(state) -> bool:
    return state.time_of_day in ("Night", "Dusk")


def wage(world, d: dict) -> float:
    from game import estate
    s, u = estate.wages(world)
    return round((s if d.get("trade") else u) * WAGE_SHARE, 2)


def prompt(explorer, t):
    """Speaking to one of them: their line, a few coppers, or work."""
    from game.explore import Prompt
    from game.state import money_text
    d = explorer.crowd_info.get(t.id) or {}
    pay = wage(explorer.world, d)
    opts = [("Give them a few coppers", ("homeless", "give", t.id), explorer.state.copper >= 5),
            (f"Offer them work on your land ({money_text(int(round(pay * 100)))} a day)", ("homeless", "hire", t.id),
             True),
            ("Leave them be", ("homeless", "leave", t.id), True)]
    who = f"{t.name[:1].upper()}{t.name[1:]}"
    extra = f" (Once a {d['trade']}: a skilled hand.)" if d.get("trade") else ""
    return Prompt(who, f"\"{d.get('line') or '...'}\"{extra}", opts)


def act(world, state, explorer, action: tuple, bus=None) -> dict:
    """("homeless", "give" | "hire" | "leave", token id). Returns {"lines"}."""
    what, tid = (action[1] if len(action) > 1 else ""), (action[2] if len(action) > 2 else "")
    d = explorer.crowd_info.get(tid) if explorer is not None else None
    if not is_homeless(d):
        return {"lines": ["They've wandered off."]}
    if what == "give":
        if state.copper < 5:
            return {"lines": ["You've nothing to give."]}
        state.add_copper(-5, "alms")
        state.save()
        return {"lines": [f"You press a few coppers into a cold hand. \"Gods keep you,\" the {_title(d)} says."]}
    if what == "hire":
        town = _town(world, tid)
        ok, text, _w = hire(world, state, d, town, bus)
        if ok and explorer is not None:
            explorer.refresh_people(force=True)
        return {"lines": [text]}
    return {"lines": []}


def _title(d: dict) -> str:
    return d["name"].split(" ", 1)[-1] if " " in d.get("name", "") else "stranger"


def _town(world, hid: str):
    parts = hid.split(":")
    return world.entities.get(parts[1]) if len(parts) >= 3 else None


def hire(world, state, d: dict, town, bus=None):
    """Take one of the homeless on as a hired hand: a person of the save now, at a cut wage."""
    from game import estate
    from game import worldfill as WF
    from game.state import money_text
    if d.get("id") in hired_ids(state):
        return False, "They already work for you.", None
    rng = _rng("homeless name", d["id"])
    folk = [n for n in world.entities.by_field("npc", "town", town.id)] if town is not None else []
    used = {n.name for n in folk}
    name, _family, _sex = WF._name_like(rng, [n for n in folk if " " in n.name] or folk, used)
    race = world.entities.find_by_name("race", d.get("race", "human").replace("_", "-").title()) or \
        world.entities.find_by_name("race", "Human")
    occ = TRADE_OCC.get(d.get("trade") or "", "Laborer")
    lk = dict(d["look"])
    n = world.entities.create("npc", name, {
        "race": race.id if race is not None else None, "occupation": occ, "class": None, "level": 1,
        "disposition": "Friendly", "faction": None, "trains": [], "building": "", "town": town.id if town else "",
        "street": "", "home": None, "schedule": [], "greeting": "Work, and a wage. I won't let you down.",
        "talk": None, "quest_cooldown_days": 0, "quests": [], "sells_tags": [], "shop_items": [], "gold": 0,
        "price_markup": 100, "passages": [], "relationships": [], "title": f"once a {_title(d)}",
        "appearance": lk, "equipment": {}, "fights_as": None, "homeless": d["id"]},
        "Taken in off the streets to work for the party.", ["Townsfolk"], overlay=True)
    pay = wage(world, d)
    w = {"id": state.next_id("worker"), "kind": "hired", "npc": n.id, "name": name, "skilled": bool(d.get("trade")),
         "wage": pay, "grade": "", "building": "", "hired": state.day, "homeless": d["id"]}
    estate.workers(state).append(w)
    state.ticks.setdefault("estate", state.minutes)
    estate._save(world, state)
    msg = f"{name} works for you now, for {money_text(int(round(pay * 100)))} a day" + \
        (f" (a skilled hand: once a {d['trade']})." if d.get("trade") else ".")
    if bus is not None:
        bus.emit("log", kind="quest", text=msg)
    return True, msg, w


__all__ = ["share", "count", "shown", "roster", "is_homeless", "prompt", "act", "hire", "wage", "SHARE",
           "MOST_SHARE"]
