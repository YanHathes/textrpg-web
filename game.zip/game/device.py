"""Which machine the game is on (step 19): a desktop, or an Android phone.

    is_android()       running inside the Android app (pyside6-android-deploy / python-for-android)
    data_dir(root)     where settings, worlds and saves go: next to the game on a desktop; the app's own
                       private folder on a phone (the game's own folder can't be written there)
    handheld(settings) whether to use the handheld layout (ui/handheld.py): always on a phone; on a desktop
                       when the Game screen setting says so, or TEXTRPG_HANDHELD=1 / --handheld
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


def is_android() -> bool:
    if hasattr(sys, "getandroidapilevel"):
        return True
    return bool(os.environ.get("ANDROID_ARGUMENT") or os.environ.get("ANDROID_PRIVATE")
                or os.environ.get("ANDROID_APP_PATH"))


def is_ios() -> bool:
    """An iPhone or iPad (Python 3.13 and later say "ios"; Qt for Python on iOS is newer still)."""
    return sys.platform == "ios" or os.environ.get("TEXTRPG_IOS") == "1"


def is_mobile() -> bool:
    return is_android() or is_ios()


def media_backend() -> str:
    """Which of Qt's sound systems to use: the phone's own (Android's, or Apple's AVFoundation), never the
    FFmpeg one, which made the Android app too big and crashed it on start-up (step 19)."""
    if is_android():
        return "android"
    if is_ios():
        return "darwin"
    return ""


def data_dir(root: Path) -> Path:
    if is_android():
        for base in _android_homes(root):
            folder = Path(base) / "textrpg-data"
            if _writable(folder):
                return folder
        import tempfile
        return Path(tempfile.gettempdir()) / "textrpg-data"
    return Path(root) / "data"


def _android_homes(root: Path) -> list:
    """Where an Android app may keep its files: what the app's launcher says, else beside the game's own
    files (unpacked into the app's private storage), else its home."""
    out = [os.environ.get(k) for k in ("ANDROID_PRIVATE", "ANDROID_APP_PATH", "HOME")]
    out.append(str(Path(root).parent))
    out.append(str(root))
    try:
        out.append(str(Path.home()))
    except Exception:  # noqa: BLE001 - no home at all
        pass
    return [b for b in out if b]


def _writable(folder: Path) -> bool:
    try:
        folder.mkdir(parents=True, exist_ok=True)
        probe = folder / ".write-test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        return True
    except Exception:  # noqa: BLE001
        return False


def handheld(settings=None, argv: list[str] | None = None) -> bool:
    if is_android():
        return True
    argv = sys.argv if argv is None else argv
    if "--handheld" in argv or os.environ.get("TEXTRPG_HANDHELD") == "1":
        return True
    return bool(settings is not None and settings.get("ui_mode", "Map") == "Handheld")


__all__ = ["is_android", "data_dir", "handheld"]
