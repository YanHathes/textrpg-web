"""Placeholder content so the layout can be judged before real systems exist.

Everything here is replaced by real game state in later stages. The shapes
are deliberately generic: the character sheet draws whatever resources,
stat groups and sections it is given, rather than assuming specific stats.
"""

PREVIEW_CHARACTER = {
    "name": "Rowan Ashby",
    "tags": ["Level 3", "Human", "Fighter"],
    "resources": [
        {"label": "Hit Points", "current": 24, "max": 31, "color": "danger"},
        {"label": "Second Wind", "current": 1, "max": 1, "color": "info"},
        {"label": "Experience", "current": 1200, "max": 2700, "color": "accent"},
    ],
    "badges": [
        {"label": "Armor", "value": "16"},
        {"label": "Initiative", "value": "+2"},
        {"label": "Speed", "value": "30 ft"},
        {"label": "Proficiency", "value": "+2"},
    ],
    "stat_groups": [
        {
            "title": "Abilities",
            "columns": 3,
            "stats": [
                {"label": "STR", "main": "+3", "sub": "16"},
                {"label": "DEX", "main": "+2", "sub": "14"},
                {"label": "CON", "main": "+2", "sub": "15"},
                {"label": "INT", "main": "+0", "sub": "10"},
                {"label": "WIS", "main": "+1", "sub": "12"},
                {"label": "CHA", "main": "-1", "sub": "8"},
            ],
        }
    ],
    "sections": [
        {
            "title": "Equipment",
            "rows": [
                ["Main Hand", "Longsword"],
                ["Off Hand", "Shield"],
                ["Armor", "Chain Mail"],
                ["Trinket", "Brass Compass"],
            ],
        },
        {
            "title": "Inventory",
            "rows": [
                ["Healing Potion", "x2"],
                ["Torch", "x5"],
                ["Rations", "x4"],
                ["Rope (50 ft)", "x1"],
                ["Letter, sealed", ""],
            ],
            "footer": "Gold  48",
        },
        {
            "title": "Skills",
            "rows": [
                ["Athletics", "+5"],
                ["Perception", "+3"],
                ["Intimidation", "+1"],
                ["Survival", "+3"],
            ],
        },
        {
            "title": "Features",
            "rows": [
                ["Fighting Style", "Defense"],
                ["Action Surge", "1 / rest"],
            ],
            "collapsed": True,
        },
    ],
}

PREVIEW_QUESTS = [
    {
        "title": "Ore for the Forge",
        "giver": "Mara Holt",
        "kind": "Fetch",
        "tracked": True,
        "objectives": [
            {"text": "Find iron ore in the Old Quarry", "done": True},
            {"text": "Return the ore to Mara Holt", "done": False},
        ],
        "reward": "60 gold  ·  150 XP",
    },
    {
        "title": "Wolves on the North Road",
        "giver": "Captain Iver",
        "kind": "Defeat",
        "tracked": False,
        "objectives": [
            {"text": "Defeat the dire wolf (CR 1)", "done": False},
        ],
        "reward": "90 gold  ·  200 XP",
    },
    {
        "title": "The Hermit's Lantern",
        "giver": "Old Pell",
        "kind": "Visit",
        "tracked": False,
        "objectives": [
            {"text": "Visit the lighthouse at Gull Point", "done": False},
        ],
        "reward": "35 gold  ·  100 XP",
    },
]

PREVIEW_LOCATION = {
    "breadcrumb": ["Westmarch", "Briarwell", "Anvil Street"],
    "name": "Holt's Forge",
    "description": (
        "Heat rolls off the forge in waves. Racks of half-finished blades line "
        "the walls, and the air tastes of coal and iron."
    ),
    "people": [
        {"id": "mara", "name": "Mara Holt", "role": "Blacksmith"},
        {"id": "tobin", "name": "Tobin", "role": "Apprentice"},
        {"id": "grisk", "name": "Grisk", "role": "Mercenary"},
    ],
    "exits": [
        {"name": "Leave to Anvil Street", "kind": "street"},
    ],
    # what the picture behind the log shows (the world stage will fill this in for real)
    "scene": {"place": "Smithy", "walls": "Stone", "time": "Morning"},
}

PREVIEW_CLOCK = "Day 3  ·  Morning  ·  08:40"

# (kind, text, speaker)
PREVIEW_LOG = [
    ("scene", "Briarwell", None),
    ("narration", "Rain drums on the slate roofs as you make your way down Anvil Street. "
                  "The ring of a hammer draws you toward an open doorway.", None),
    ("scene", "Holt's Forge", None),
    ("narration", "A broad-shouldered woman sets down her tongs and wipes her brow.", None),
    ("dialogue", "Back already? Tell me you found that ore.", "Mara Holt"),
    ("player", "check perception", None),
    ("roll", "Perception check: d20 (14) + 3 = 17 vs DC 15  ·  Success", None),
    ("narration", "You notice a sword on the far rack, its edge faintly glowing.", None),
    ("loot", "You received: Iron Ore x3", None),
    ("quest", "Quest updated: Ore for the Forge  ·  Return the ore to Mara Holt", None),
    ("damage", "You brush the hot anvil and take 1 fire damage.", None),
    ("heal", "You drink a Healing Potion and recover 7 HP.", None),
    ("system", "This is preview content. Real game systems arrive in later stages.", None),
]
