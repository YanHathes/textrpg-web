"""Landmarks and dungeon entrances as small walkable maps, laid into the world by game/worldmap.py.

Each kind of landmark gets its own little scene: tumbled ruins, a lonely tower, a cave mouth in a rocky
knoll, standing stones, a grove round an old altar, a monument on its plinth, a camp, a shipwreck, a
shrine, an old battlefield, a bridge. A landmark that leads into a dungeon has a door (or a cave mouth)
that takes the party down into it.
"""
from __future__ import annotations

import math
import random
import zlib

from game import area as A

GROUND = {"Plains": "grass", "Forest": "grass", "Hills": "grass", "Mountains": "dirt", "Coast": "sand",
          "Swamp": "grass", "Desert": "sand", "Arctic": "snow", "Taiga": "grass", "Tundra": "snow",
          "Savanna": "grass", "Jungle": "grass", "Badlands": "dirt", "Ocean": "sand", "Lake": "sand"}
SIZE = 26


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(str(k) for k in key).encode("utf-8")))


def build(world, e, kind: str, biome: str) -> A.Area:
    """A landmark (kind 'landmark') or a lone dungeon's entrance (kind 'dungeon')."""
    from game import dungeons as DG
    rng = _rng("site", e.id)
    n = SIZE
    a = A.Area(f"site:{e.id}", "site", n, n, e.name)
    lv = A.Level("0", 0, 0, n, n, GROUND.get(biome, "grass"))
    a.levels["0"] = lv
    loc = DG.landmark_id(e.id) if kind == "landmark" else ""
    z = a.zone_id(loc) if loc else 0
    for y in range(n):
        for x in range(n):
            if (x - n / 2) ** 2 + (y - n / 2) ** 2 <= (n / 2 - 1) ** 2:
                lv.set_zone(x, y, z)
    dungeon = None
    if kind == "dungeon":
        dungeon = e
        what = {"Cave": "Cave", "Lair": "Cave", "Mine": "Mine", "Tower": "Tower", "Crypt": "Crypt",
                "Ruins": "Ruins", "Fortress": "Ruins", "Temple": "Shrine", "Sewer": "Ruins"}.get(
            e.fields.get("kind") or "", "Ruins")
    else:
        dungeon = world.entities.get(e.fields.get("dungeon") or "") if e.fields.get("dungeon") else None
        what = e.fields.get("kind") or "Ruins"
    c = n // 2
    door = None
    builder = SCENES.get(what, _ruins)
    door = builder(lv, rng, c, dungeon is not None)
    if dungeon is not None and door is not None:
        target = DG.room_id(dungeon.id, "")          # the way in (worked out when someone goes in)
        cell, horizontal, wall = door
        lv.walls.pop(cell, None)
        lv.doors[cell] = {"kind": "dungeon", "bid": dungeon.id, "horizontal": horizontal, "wall": wall,
                          "rooms": ("", target), "names": ("", ""), "lock": 0, "room": "", "target": target,
                          "label": dungeon.name}
    spot = A._nearest_free(lv, c, n - 4)
    if loc and spot:
        a.spawns[loc] = ("0", spot[0], spot[1])
    a.finish()
    return a


# ======================================================================
# The scenes. Each returns the dungeon door ((x, y), horizontal, wall kind), or None.
# ======================================================================
def _ring(lv, c, r, kind, gaps, rng, keep=()):
    for i in range(int(2 * math.pi * r * 1.6)):
        t = i / (2 * math.pi * r * 1.6) * 2 * math.pi
        x, y = int(round(c + math.cos(t) * r)), int(round(c + math.sin(t) * r))
        if (x, y) in keep or rng.random() < gaps:
            continue
        lv.walls[(x, y)] = kind


def _box(lv, x0, y0, w, h, wall, floor) -> None:
    for y in range(y0, y0 + h + 1):
        for x in range(x0, x0 + w + 1):
            if x in (x0, x0 + w) or y in (y0, y0 + h):
                lv.walls[(x, y)] = wall
            else:
                lv.set_floor(x, y, floor)


def _scatter(lv, rng, c, radius, props, count) -> None:
    for _ in range(count):
        x, y = c + rng.randint(-radius, radius), c + rng.randint(-radius, radius)
        lv.add_prop(rng.choice(props), x, y, rng.randrange(4))


def _ruins(lv, rng, c, down):
    for y in range(c - 7, c + 8):
        for x in range(c - 7, c + 8):
            if rng.random() < 0.55:
                lv.set_floor(x, y, "stone")
    for x0, y0, w, h in ((c - 7, c - 7, 7, 6), (c + 1, c - 5, 6, 7), (c - 5, c + 2, 8, 5)):
        for y in range(y0, y0 + h + 1):
            for x in range(x0, x0 + w + 1):
                if (x in (x0, x0 + w) or y in (y0, y0 + h)) and rng.random() < 0.6:
                    lv.walls[(x, y)] = "stone_wall"
    _scatter(lv, rng, c, 8, ["rubble", "rubble", "pillar", "bones"], 14)
    if down:
        _box(lv, c - 2, c - 2, 4, 4, "stone_wall", "stone")
        lv.add_prop("stairs_down", c, c)
        return (c, c + 2), True, "stone_wall"
    return None


def _tower(lv, rng, c, down):
    r = 5
    for y in range(c - r, c + r + 1):
        for x in range(c - r, c + r + 1):
            d = math.hypot(x - c, y - c)
            if d <= r - 0.5:
                lv.set_floor(x, y, "stone")
            if r - 1.2 <= d <= r + 0.4:
                lv.walls[(x, y)] = "stone_wall"
    for y in range(c - r + 1, c + r):
        for x in range(c - r + 1, c + r):
            if math.hypot(x - c, y - c) < r - 1.2:
                lv.walls.pop((x, y), None)
    lv.add_prop("stairs_up", c, c - 2)
    _scatter(lv, rng, c, 9, ["rubble", "rock"], 6)
    door = (c, c + r)
    if down:
        return door, True, "stone_wall"
    lv.walls.pop(door, None)
    lv.set_floor(door[0], door[1], "stone")
    return None


def _cave(lv, rng, c, down):
    for y in range(c - 8, c + 3):
        for x in range(c - 9, c + 10):
            if ((x - c) / 9.5) ** 2 + ((y - c + 3) / 6) ** 2 <= 1 + (rng.random() - 0.5) * 0.25:
                lv.walls[(x, y)] = "rock_wall"
    _scatter(lv, rng, c + 3, 6, ["rock", "rock", "bush", "bones"], 8)
    door = (c, c + 2)
    for y in range(c + 3, c + 6):
        lv.walls.pop((c, y), None)
    if down:
        return door, True, "rock_wall"
    lv.walls.pop(door, None)
    lv.set_floor(door[0], door[1], "cave")
    return None


def _mine(lv, rng, c, down):
    door = _cave(lv, rng, c, down)
    for y in range(c + 3, c + 9):
        lv.set_floor(c, y, "path")
    lv.add_prop("cart", c + 2, c + 5)
    lv.add_prop("crate", c - 2, c + 4)
    return door


def _stones(lv, rng, c, down):
    for i in range(9):
        t = i / 9 * 2 * math.pi
        lv.add_prop(rng.choice(["statue", "pillar", "pillar"]), int(c + math.cos(t) * 6), int(c + math.sin(t) * 6))
    lv.add_prop("altar", c - 1, c)
    if down:
        _box(lv, c - 1, c - 4, 2, 2, "stone_wall", "stone")
        return (c, c - 2), True, "stone_wall"
    return None


def _grove(lv, rng, c, down):
    for i in range(40):
        t = rng.random() * 2 * math.pi
        rr = rng.uniform(6, 11)
        lv.add_prop(rng.choice(["tree", "big_tree", "tree"]), int(c + math.cos(t) * rr), int(c + math.sin(t) * rr),
                    rng.randrange(6))
    lv.add_prop("altar", c - 1, c)
    _scatter(lv, rng, c, 4, ["mushrooms", "bush"], 5)
    if down:
        _box(lv, c - 1, c + 2, 2, 2, "rock_wall", "cave")
        return (c, c + 2), True, "rock_wall"
    return None


def _monument(lv, rng, c, down):
    for y in range(c - 4, c + 5):
        for x in range(c - 4, c + 5):
            lv.set_floor(x, y, "cobble")
    lv.add_prop("statue", c, c)
    for dx, dy in ((-4, -4), (4, -4), (-4, 4), (4, 4)):
        lv.add_prop("pillar", c + dx, c + dy)
    if down:
        _box(lv, c - 1, c - 8, 2, 2, "stone_wall", "stone")
        return (c, c - 6), True, "stone_wall"
    return None


def _camp(lv, rng, c, down):
    lv.add_prop("campfire", c, c)
    for dx, dy in ((-4, -2), (3, -3), (-3, 3), (4, 2)):
        lv.add_prop(rng.choice(["haybale", "crate", "barrel", "cart"]), c + dx, c + dy)
    for i in range(14):
        t = i / 14 * 2 * math.pi
        if i % 5:
            lv.add_prop("fence", int(c + math.cos(t) * 8), int(c + math.sin(t) * 8))
    if down:
        return _cave(lv, rng, c - 6, True)
    return None


def _shipwreck(lv, rng, c, down):
    for y in range(c - 3, c + 4):
        for x in range(c - 8, c + 9):
            if abs(y - c) <= 3 - abs(x - c) / 4:
                lv.set_floor(x, y, "wood")
                if rng.random() < 0.12:
                    lv.walls[(x, y)] = "wood_wall"
    _scatter(lv, rng, c, 7, ["crate", "barrel", "rubble"], 9)
    if down:
        _box(lv, c - 1, c + 4, 2, 2, "wood_wall", "wood")
        return (c, c + 4), True, "wood_wall"
    return None


def _shrine(lv, rng, c, down):
    _box(lv, c - 3, c - 4, 6, 6, "stone_wall", "stone")
    lv.walls.pop((c, c + 2), None)
    lv.add_prop("altar", c - 1, c - 2)
    lv.add_prop("brazier", c - 2, c - 3)
    lv.add_prop("brazier", c + 2, c - 3)
    if down:
        lv.add_prop("stairs_down", c + 1, c)
        return (c - 3, c), False, "stone_wall"
    return None


def _battlefield(lv, rng, c, down):
    _scatter(lv, rng, c, 10, ["bones", "bones", "rubble", "grave", "cart"], 22)
    if down:
        return _ruins(lv, rng, c, True)
    return None


def _bridge(lv, rng, c, down):
    for y in range(2, SIZE - 2):
        for x in range(c - 6, c + 7):
            if abs(x - c) > 1:
                lv.water[(x, y)] = "water"
    for y in range(c - 2, c + 3):
        for x in range(c - 7, c + 8):
            lv.water.pop((x, y), None)
            lv.set_floor(x, y, "wood")
    return None


SCENES = {"Ruins": _ruins, "Tower": _tower, "Cave": _cave, "Lair": _cave, "Mine": _mine,
          "Standing stones": _stones, "Grove": _grove, "Monument": _monument, "Camp": _camp,
          "Shipwreck": _shipwreck, "Shrine": _shrine, "Battlefield": _battlefield, "Bridge": _bridge,
          "Crypt": _shrine}


__all__ = ["build", "SCENES"]
