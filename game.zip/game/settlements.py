"""The settlement rules: what a place of each size has. One table, read by the world generator (every town
is grown to fit it) and, later, by the party's own settlements (which climb it as settlers arrive).

    Tier      people    named      defences                         lots   safe zone
    Camp      1-24      everyone   none                              -      1/4 mi   (the party's own only)
    Hamlet    25-150    10-25      hedge or none                     1-2    1/2 mi
    Village   150-1000  25-50      ditch or palisade (half)          2-4    1 mi
    Town      1k-6k     60-120     wooden or stone wall, gates       4-8    2 mi
    City      6k-20k    150-300    stone walls, towers, gatehouses   6-12   3 mi
    Capital   20k+      300-600    double walls, keep or castle      8-16   4 mi

"Safe zone": no roaming monster comes within this distance of the place (game/encounters.py).
What each town produces comes from its land; what it needs is what it can't make (game/trade.py will set
prices from both).
"""
from __future__ import annotations

import random
import zlib

TIERS = ["Camp", "Hamlet", "Village", "Town", "City", "Capital"]

RULES = {
    "Camp":    {"people": (1, 24), "named": (1, 24), "defenses": ["None"], "lots": (0, 0), "safe_miles": 0.25,
                "wells": (0, 0), "needs": ["Campfire"]},
    "Hamlet":  {"people": (25, 150), "named": (10, 25), "defenses": ["None", "Hedge"], "lots": (1, 2),
                "safe_miles": 0.5, "wells": (1, 1), "needs": ["Well", "Farm"]},
    "Village": {"people": (150, 1000), "named": (25, 50), "defenses": ["Ditch", "Palisade"], "lots": (2, 4),
                "safe_miles": 1.0, "wells": (2, 3), "needs": ["Well", "Granary", "Shrine"]},
    "Town":    {"people": (1000, 6000), "named": (60, 120), "defenses": ["Wooden wall", "Stone wall"],
                "lots": (4, 8), "safe_miles": 2.0, "wells": (3, 5), "needs": ["Well", "Market", "Jail", "Temple"]},
    "City":    {"people": (6000, 20000), "named": (150, 300), "defenses": ["Stone walls with towers"],
                "lots": (6, 12), "safe_miles": 3.0, "wells": (5, 8), "needs": ["Market", "Jail", "Temple", "Bank"]},
    "Capital": {"people": (20000, 10 ** 9), "named": (300, 600), "defenses": ["Double walls"], "lots": (8, 16),
                "safe_miles": 4.0, "wells": (8, 12), "needs": ["Market", "Jail", "Temple", "Bank", "Castle"]},
}
DEFENSES = ["", "None", "Hedge", "Ditch", "Palisade", "Wooden wall", "Stone wall", "Stone walls with towers",
            "Double walls"]
WALLED = {"Wooden wall", "Stone wall", "Stone walls with towers", "Double walls"}

# goods a town's land gives it (the tags trade will price them by)
GOODS = ["ore", "stone", "gems", "timber", "fish", "salt", "grain", "livestock", "wool", "furs", "herbs",
         "spices", "dyes", "wine", "cloth", "tools"]
LAND_GOODS = {
    "Mountains": ["ore", "stone", "gems"], "Hills": ["ore", "stone", "wool", "wine"],
    "Forest": ["timber", "herbs", "furs"], "Taiga": ["timber", "furs"], "Jungle": ["timber", "spices", "dyes"],
    "Plains": ["grain", "livestock", "wool"], "Savanna": ["livestock", "spices"], "Coast": ["fish", "salt"],
    "Lake": ["fish"], "Swamp": ["herbs", "dyes"], "Desert": ["salt", "spices", "dyes"],
    "Badlands": ["ore", "gems"], "Arctic": ["furs", "fish"], "Tundra": ["furs", "livestock"],
}
# what bigger places make from what the land gives
CRAFT_GOODS = {"Town": ["tools"], "City": ["tools", "cloth"], "Capital": ["tools", "cloth"]}


def tier_for(population: int) -> str:
    """The tier a population makes (a Camp below 25)."""
    p = int(population or 0)
    if p < 25:
        return "Camp"
    if p < 150:
        return "Hamlet"
    if p < 1000:
        return "Village"
    if p < 6000:
        return "Town"
    if p < 20000:
        return "City"
    return "Capital"


def tier_of(town) -> str:
    """A town's tier: its Kind if set, else from its population."""
    kind = (town.fields.get("kind") or "") if town is not None else ""
    return kind if kind in RULES else tier_for(int(town.fields.get("population") or 0) if town is not None else 0)


def rules(tier: str) -> dict:
    return RULES.get(tier) or RULES["Village"]


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


def named_target(town) -> int:
    """How many named people a town should have (fixed per town, within its tier's range)."""
    lo, hi = rules(tier_of(town))["named"]
    span = max(0, (hi - lo) // 4)                 # towards the lower end: a quarter of the range
    return lo + _rng("named", town.id).randint(0, span)


def lots_target(town) -> int:
    lo, hi = rules(tier_of(town))["lots"]
    return _rng("lots", town.id).randint(lo, hi) if hi else 0


def defenses(town) -> str:
    """What protects a town: its Defenses field if set, else picked (once, the same every time) for its tier."""
    own = (town.fields.get("defenses") or "") if town is not None else ""
    if own:
        return own
    choices = rules(tier_of(town))["defenses"]
    return _rng("walls", town.id).choice(choices)


def walled(town) -> bool:
    return defenses(town) in WALLED


def safe_miles(town) -> float:
    return float(rules(tier_of(town))["safe_miles"])


def wells(town) -> int:
    lo, hi = rules(tier_of(town))["wells"]
    return _rng("wells", town.id).randint(lo, hi) if hi else 0


def produces(town) -> list[str]:
    """Two or three goods from the land around it (its Produces field if set)."""
    own = list(town.fields.get("produces") or []) if town is not None else []
    if own:
        return own
    land = town.fields.get("terrain") or "Plains"
    pool = list(LAND_GOODS.get(land, LAND_GOODS["Plains"]))
    rng = _rng("produces", town.id)
    rng.shuffle(pool)
    out = pool[:rng.randint(2, 3)] if len(pool) >= 2 else pool
    for g in CRAFT_GOODS.get(tier_of(town), []):
        if g not in out and rng.random() < 0.5:
            out.append(g)
    return out


def needs(town) -> list[str]:
    """Two or three goods it doesn't make (its Needs field if set)."""
    own = list(town.fields.get("needs") or []) if town is not None else []
    if own:
        return own
    made = set(produces(town))
    pool = [g for g in GOODS if g not in made]
    rng = _rng("needs", town.id)
    rng.shuffle(pool)
    return pool[:rng.randint(2, 3)]


def has_everything(town, kinds: set[str]) -> list[str]:
    """What a tier asks for that the place lacks (building kinds or features); [] when it has it all.
    Wells and farms are laid out on the town's map (game/townlayout.py); a temple will do for a shrine."""
    from game import townlayout
    have = set(kinds)
    if wells(town):
        have.add("Well")
    if townlayout.farm_count(town):
        have.add("Farm")
    if "Temple" in have:
        have.add("Shrine")
    return [n for n in rules(tier_of(town))["needs"] if n not in have]


# ----------------------------------------------------------------------------------------------------
# Safe zones and danger in the open (game/explore.py, game/travel.py, game/hexes.py roll with this)
# ----------------------------------------------------------------------------------------------------
GRADE_SAFETY = {"highway": 0.25, "road": 0.5, "track": 0.75, "": 1.0}   # roads are watched (highways most)
DANGER_NEAR, DANGER_PER_MILE, DANGER_MAX = 0.5, 0.1, 1.6
_BIN = 16.0                                      # miles per side of the lookup bins


def _town_bins(world) -> dict:
    from game import geography as G
    pos = G.town_positions(world)
    cached = getattr(world, "_safe_bins", None)
    if cached is not None and cached[0] is pos:
        return cached[1]
    bins: dict = {}
    for tid, (x, y) in pos.items():
        t = world.entities.get(tid)
        if t is not None:
            bins.setdefault((int(x // _BIN), int(y // _BIN)), []).append((x, y, safe_miles(t), t))
    world._safe_bins = (pos, bins)
    return bins


def beyond_safe(world, x: float, y: float) -> tuple[float, object]:
    """How far (miles) a point is outside the nearest town's safe zone (0 or less: inside it), and that
    town. Searches a few bins round the point; farther off than that counts as far."""
    bins = _town_bins(world)
    bx, by = int(x // _BIN), int(y // _BIN)
    best, town = _BIN * 2, None
    for j in range(by - 1, by + 2):
        for i in range(bx - 1, bx + 2):
            for (tx, ty, safe, t) in bins.get((i, j), ()):
                d = ((tx - x) ** 2 + (ty - y) ** 2) ** 0.5 - safe
                if d < best:
                    best, town = d, t
    return best, town


def is_safe(world, x: float, y: float) -> bool:
    """Inside some town's safe zone: no roaming monsters come here (raids, quest quarry and lairs still do)."""
    return beyond_safe(world, x, y)[0] <= 0


def danger_factor(world, x: float, y: float, grade: str = "") -> float:
    """What to multiply a roaming encounter's chance by at a point (miles): 0 inside a safe zone, about half
    just outside it, rising a tenth a mile to 1.6 far from anywhere; and less on a road (by its grade)."""
    excess, _t = beyond_safe(world, x, y)
    if excess <= 0:
        return 0.0
    f = min(DANGER_MAX, DANGER_NEAR + DANGER_PER_MILE * excess)
    return f * GRADE_SAFETY.get(grade or "", 1.0)


__all__ = ["TIERS", "RULES", "GOODS", "tier_for", "tier_of", "rules", "named_target", "lots_target", "defenses",
           "walled", "safe_miles", "wells", "produces", "needs", "DEFENSES", "WALLED", "beyond_safe", "is_safe",
           "danger_factor", "GRADE_SAFETY"]
