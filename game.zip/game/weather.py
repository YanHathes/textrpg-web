"""Weather: what the sky is doing, worked out (never saved) from the world seed, the clock and the place.

Each land has its own table, and the season shifts the odds:

    Forest, Plains, Hills, Taiga   clear, overcast, fog, rain, storm; snow in winter (when it's cold enough)
    Jungle, Swamp                  humid haze, heavy rain, storm, fog
    Desert, Badlands, Savanna      clear, heat haze, dust storm, rare rain
    Mountains, Tundra, Arctic      clear, wind, snow, blizzard
    Coast, Ocean, Lake             clear, sea fog, rain, gale

The weather is rolled every BLOCK_HOURS for each WEATHER_MILES square of the map; a "front" lasts
FRONT_HOURS, so it holds for a while before it turns. What fell lately shows on the ground: wet in the
rain, puddles and mud after it, white with snow, frosted on cold mornings, cracked in a drought.

Effects follow the SRD's obscurement rules: fog, sea fog, heavy rain and snow lightly obscure (disadvantage
on Perception that relies on sight); blizzards and dust storms obscure more, cut sight further and slow
travel.
"""
from __future__ import annotations

import hashlib
import zlib
from dataclasses import dataclass

from game import calendar as CAL

BLOCK_HOURS = 4
FRONT_HOURS = 12
WEATHER_MILES = 24.0

KINDS = ["Clear", "Overcast", "Fog", "Rain", "Heavy rain", "Storm", "Snow", "Blizzard", "Humid haze", "Heat haze",
         "Dust storm", "Wind", "Sea fog", "Gale"]

GROUPS = {
    "temperate": {"Forest", "Plains", "Hills", "Taiga", "Urban"},
    "wet": {"Jungle", "Swamp"},
    "dry": {"Desert", "Badlands", "Savanna"},
    "cold": {"Mountains", "Tundra", "Arctic"},
    "sea": {"Coast", "Ocean", "Lake"},
}
TABLES = {
    "temperate": {"Clear": 40, "Overcast": 22, "Fog": 8, "Rain": 18, "Storm": 6},
    "wet": {"Humid haze": 30, "Heavy rain": 25, "Storm": 12, "Fog": 18, "Clear": 15},
    "dry": {"Clear": 55, "Heat haze": 25, "Dust storm": 8, "Rain": 4},
    "cold": {"Clear": 35, "Wind": 25, "Snow": 25, "Blizzard": 10},
    "sea": {"Clear": 42, "Sea fog": 18, "Rain": 25, "Gale": 10},
}
SEASON_ODDS = {
    "Spring": {"Rain": 1.3, "Heavy rain": 1.2, "Fog": 1.2, "Blizzard": 0.6},
    "Summer": {"Storm": 1.6, "Heat haze": 1.6, "Fog": 0.6, "Sea fog": 0.7, "Snow": 0.4, "Blizzard": 0.2,
               "Clear": 1.2, "Dust storm": 1.4},
    "Autumn": {"Fog": 1.5, "Overcast": 1.3, "Sea fog": 1.3, "Gale": 1.4, "Wind": 1.3},
    "Winter": {"Storm": 0.5, "Heat haze": 0.3, "Blizzard": 2.0, "Snow": 1.4, "Gale": 1.5, "Humid haze": 0.7},
}
RAINY = {"Rain", "Heavy rain", "Storm"}
SNOWY = {"Snow", "Blizzard"}
LIGHT_OBSCURE = {"Fog", "Sea fog", "Heavy rain", "Snow", "Storm"}
HEAVY_OBSCURE = {"Blizzard", "Dust storm"}
SIGHT = {"Fog": 0.55, "Sea fog": 0.55, "Heavy rain": 0.65, "Snow": 0.7, "Storm": 0.65, "Rain": 0.85,
         "Blizzard": 0.35, "Dust storm": 0.35, "Humid haze": 0.85, "Heat haze": 0.9, "Overcast": 1.0}
TRAVEL = {"Blizzard": 0.5, "Dust storm": 0.5, "Storm": 0.75, "Heavy rain": 0.8, "Snow": 0.8, "Gale": 0.8}
CLOUDY = {"Overcast", "Rain", "Heavy rain", "Storm", "Snow", "Blizzard", "Fog", "Sea fog", "Dust storm", "Gale"}
DIMMING = {"Overcast": 0.12, "Rain": 0.18, "Heavy rain": 0.26, "Storm": 0.38, "Snow": 0.12, "Blizzard": 0.3,
           "Fog": 0.08, "Sea fog": 0.08, "Dust storm": 0.2, "Gale": 0.15}
PARTICLES = {"Rain": "rain", "Heavy rain": "rain", "Storm": "rain", "Gale": "rain", "Snow": "snow",
             "Blizzard": "snow", "Dust storm": "dust", "Wind": "wind"}
DENSITY = {"Rain": 0.45, "Heavy rain": 0.85, "Storm": 1.0, "Gale": 0.5, "Snow": 0.5, "Blizzard": 1.0,
           "Dust storm": 0.9, "Wind": 0.35}
HAZE = {"Fog": (200, 206, 212, 90), "Sea fog": (196, 208, 214, 100), "Humid haze": (190, 214, 190, 40),
        "Heat haze": (255, 226, 170, 36), "Dust storm": (196, 150, 96, 120), "Blizzard": (230, 236, 244, 110)}
GROUND_KINDS = ["", "wet", "puddles", "snow", "frost", "cracked"]


@dataclass(frozen=True)
class Weather:
    kind: str = "Clear"
    biome: str = "Plains"
    season: str = "Spring"
    temperature: int = 60
    ground: str = ""                       # "", wet, puddles, snow, frost, cracked
    obscure: str = ""                      # "", light, heavy
    sight: float = 1.0                     # sight range multiplier outdoors
    travel: float = 1.0                    # travel speed multiplier
    particles: str = ""                    # rain, snow, dust, wind
    density: float = 0.0                   # 0..1, how many particles
    lightning: bool = False
    cloudy: bool = False                   # hides the moon
    dim: float = 0.0                       # how much the clouds darken the day (0..1)
    haze: tuple = (0, 0, 0, 0)             # a colour laid over everything (fog, dust)

    @property
    def wet(self) -> bool:
        return self.kind in RAINY

    def describe(self) -> str:
        words = {"Clear": "clear skies", "Overcast": "overcast", "Fog": "fog", "Rain": "rain",
                 "Heavy rain": "heavy rain", "Storm": "a thunderstorm", "Snow": "snow", "Blizzard": "a blizzard",
                 "Humid haze": "a humid haze", "Heat haze": "shimmering heat", "Dust storm": "a dust storm",
                 "Wind": "a cold wind", "Sea fog": "sea fog", "Gale": "a gale"}
        return f"{words.get(self.kind, self.kind.lower())}, {self.temperature}°F"


def group_of(biome: str) -> str:
    for g, lands in GROUPS.items():
        if biome in lands:
            return g
    return "temperate"


def _seed(world) -> int:
    try:
        from game import geography as G
        return int(G.settings(world)["seed"])
    except Exception:  # noqa: BLE001 - a world without a map still has weather
        return zlib.crc32(str(getattr(world, "slug", "world")).encode("utf-8"))


def _roll(seed: int, *key) -> float:
    h = hashlib.blake2b("|".join(str(k) for k in (seed,) + key).encode("utf-8"), digest_size=8).digest()
    return int.from_bytes(h, "little") / 2.0 ** 64


def _pick(world, seed: int, biome: str, block: int, cell, salt: str) -> str:
    g = group_of(biome)
    minutes = block * BLOCK_HOURS * 60
    season = CAL.season(world, minutes)
    odds = SEASON_ODDS.get(season, {})
    table = [(k, w * odds.get(k, 1.0)) for k, w in TABLES[g].items()]
    if biome == "Savanna" and season == "Summer":         # the wet season
        table.append(("Storm", 10))
        table = [(k, w * (4 if k == "Rain" else 1)) for k, w in table]
    total = sum(w for _k, w in table)
    r = _roll(seed, salt, cell[0], cell[1], block) * total
    kind = table[-1][0]
    for k, w in table:
        r -= w
        if r <= 0:
            kind = k
            break
    if g in ("temperate", "sea") and kind in RAINY | {"Gale"}:
        temp = CAL.temperature(world, minutes + 12 * 60, biome)
        if temp <= 34:                                     # cold enough to come down as snow
            kind = "Blizzard" if kind in ("Storm", "Gale") else "Snow"
    if g == "cold" and kind in SNOWY and season == "Summer" and biome == "Mountains":
        kind = "Rain" if kind == "Snow" else "Storm"
    return kind


def kind_at(world, minutes: int, biome: str, cell=(0, 0), seed: int | None = None) -> str:
    """The weather in one block of time, in one weather cell."""
    seed = _seed(world) if seed is None else seed
    block = int(minutes) // (BLOCK_HOURS * 60)
    front = int(minutes) // (FRONT_HOURS * 60)
    if biome in ("Cave", "Dungeon", "Interior", "Underdark"):
        return "Clear"
    if _roll(seed, "hold", cell[0], cell[1], block) < 0.6:     # the front holds
        return _pick(world, seed, biome, front * (FRONT_HOURS // BLOCK_HOURS), cell, "front")
    return _pick(world, seed, biome, block, cell, "block")


def cell_of(x: float, y: float) -> tuple[int, int]:
    return int(x // WEATHER_MILES), int(y // WEATHER_MILES)


def at(world, minutes: int, biome: str, x: float = 0.0, y: float = 0.0) -> Weather:
    """The weather at a point of the map (miles) at a time."""
    seed = _seed(world)
    cell = cell_of(x, y)
    kind = kind_at(world, minutes, biome, cell, seed)
    season = CAL.season(world, minutes)
    temp = CAL.temperature(world, minutes, biome, kind)
    span = BLOCK_HOURS * 60
    recent = [kind_at(world, minutes - k * span, biome, cell, seed) for k in (1, 2, 3, 4, 5, 6)]
    ground = ""
    winter_avg = CAL.climate_of(biome)[3]
    if kind in SNOWY or (any(r in SNOWY for r in recent) and temp < 40):
        ground = "snow"
    elif biome == "Arctic" or (season == "Winter" and winter_avg <= 34 and biome not in ("Ocean",)) or \
            (biome == "Tundra" and season != "Summer"):
        ground = "snow"                                    # winter's snow lies on the land
    elif kind in RAINY:
        ground = "wet"
    elif any(r in RAINY for r in recent[:2]):
        ground = "puddles"
    elif 4 * 60 <= int(minutes) % CAL.DAY < 9 * 60 and temp <= 36:
        ground = "frost"                                   # a cold morning
    elif group_of(biome) == "dry" and season != "Winter" and (season == "Summer" or biome == "Desert") and \
            not any(r in RAINY for r in recent):
        ground = "cracked"                                 # a drought
    obscure = "heavy" if kind in HEAVY_OBSCURE else "light" if kind in LIGHT_OBSCURE else ""
    if biome == "Ocean":
        ground = ""
    return Weather(kind=kind, biome=biome, season=season, temperature=temp, ground=ground, obscure=obscure,
                   sight=SIGHT.get(kind, 1.0), travel=TRAVEL.get(kind, 1.0), particles=PARTICLES.get(kind, ""),
                   density=DENSITY.get(kind, 0.0), lightning=kind == "Storm", cloudy=kind in CLOUDY,
                   dim=DIMMING.get(kind, 0.0), haze=HAZE.get(kind, (0, 0, 0, 0)))


def biome_here(world, state) -> tuple[str, float, float]:
    """The land the party is in, and where (miles; 0, 0 in a world without a map)."""
    from game import geography as G
    from game import places
    try:
        pos = G.party_position(world, state)
    except Exception:  # noqa: BLE001
        pos = None
    if pos is not None:
        try:
            b = G.biome_at(world, *pos)
            if b:
                return b, pos[0], pos[1]
        except Exception:  # noqa: BLE001 - no land map: fall back on the town's terrain
            pass
    spot = places.current(world, state)
    town = getattr(spot, "town", None)
    terrain = (town.fields.get("terrain") if town is not None else "") or "Plains"
    return terrain, (pos or (0.0, 0.0))[0], (pos or (0.0, 0.0))[1]


def here(world, state) -> Weather:
    b, x, y = biome_here(world, state)
    return at(world, state.minutes, b, x, y)


__all__ = ["Weather", "KINDS", "GROUPS", "TABLES", "at", "here", "kind_at", "biome_here", "group_of",
           "GROUND_KINDS", "BLOCK_HOURS"]
