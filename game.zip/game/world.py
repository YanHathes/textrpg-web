"""Worlds: separate collections of everything you create.

data/worlds/<slug>/
    world.json        name, description, rules
    entities/         entities.db: every entity (game/entities.py; one JSON file per type before step 18)
    templates/        this world's extra template fields
    sprites/          sprites drawn or imported in this world
"""
from __future__ import annotations

import copy
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Callable

from game.entities import EntityStore, slugify
from game.templates import TemplateRegistry

WORLD_FORMAT = 8   # ... 6: characters, 7: exploration, 8: continents, hexes, passages (game/migrate.py)

DEFAULT_RULES = {
    # Stat variable names used by the core rules. The SRD rebuild fills these in;
    # a homebrew world can point them at its own stats.
    "melee_stat": "str",
    "ranged_stat": "dex",
    "finesse_stats": ["str", "dex"],
    "armor_stat": "dex",
    "initiative_stat": "dex",
    "hp_stat": "con",
    "default_modifier": "floor((value - 10) / 2)",
    "unarmed_damage": "1",
    "crit_on": 20,
    "feet_per_square": 5,
    "quest_cooldown_days": 7,
    "quest_difficulty": "Medium",        # Easy, Medium, Hard, Deadly (5e encounter budget for Defeat quests)
    "quest_reward_scale": 1.0,
    "quest_kinds": ["Fetch", "Defeat", "Visit"],
    "shop_restock_days": 7,
    "sell_price_percent": 50,
    "wild_encounter_chance": 35,     # % per hour of exploring
    "camp_encounter_chance": 25,     # % for a night camping in the wilds
    "mechanics_announce": False,     # note in the log whenever a mechanic runs
    "magic_system": "Mana",          # Mana (10 x casting score, spells cost 10 x level) or Spell slots
    "mana_per_point": 10,
    "mana_per_spell_level": 10,
    "short_rest_stamina": 100,       # % of Stamina a short rest brings back
    "short_rest_mana": 0,            # % of Mana a short rest brings back
    "death_saves": True,
    "party_falls": "Wake up in town",   # Wake up in town, Game over, Hardcore
    "levelling": "XP",               # XP or Milestone
    "hp_on_level": "Choose",         # Choose, Roll, Average
    "multiclassing": True,
    "feats": True,
    "flexible_racial_bonuses": True,
    "encumbrance": "Off",            # Off, Standard, Variant
    "attunement_slots": 3,           # magic items a character can attune to (features can add more)
    "revive_cost": 500,              # gold a temple asks to raise the dead
    "npc_schedules": True,           # NPCs follow their daily schedules (work, home)
    "fog_of_war": True,
    "hex_miles": 6,                  # how wide a hex of the overland map is
    "hex_encounter_chance": 6,       # % per hex crossed off-road (plus a quarter of the region's danger)              # the map only shows what the party has seen
    "sight_miles": 15,               # how far the party sees around itself on the map
    "travel_mph": 3,                 # walking pace: roads without a travel time use the map distance
    "days_per_week": 7,
    "player_level_cr_ratio": 0.5,
    "season_days": 30,               # days in each season (spring, summer, autumn, winter)
    "training_price": 500,           # gp a trainer asks to make someone proficient with a tool (game/tools.py)
    "regrow_percent": 100,           # how long cut trees and dug veins take to grow back (game/gathering.py)
    "gathering": {},                 # changes to what gathering gives: {work: {key: [[item, weight, seasons]]}}
    "craft_pace": 5,                 # gp of work a crafter (and each hired helper) does a day (game/crafting.py)
    "wage_skilled": 2,               # gp a day for a skilled hired helper
    "wage_untrained": 0.2,           # gp a day for an untrained one
    "craft_kinds": {},               # changes to the recipe table: kind -> {stations, tools, materials}
    "craft_stations": {},            # changes to the stations: name -> {label, rent, stat, tools}
    "raw_materials": [],             # more item names that are raw materials (no recipe)
    "magic_days": {},                # days to make a magic item, by rarity (blank: 5, 10, 50, 125, 250)
    "potion_days": {},               # days for a magic potion or scroll, by rarity
}


class World:
    def __init__(self, path: Path, on_change: Callable | None = None) -> None:
        self.path = Path(path)
        self.slug = self.path.name
        self.meta = self._read_meta()
        self.templates = TemplateRegistry(self.path / "templates")
        self.entities = EntityStore(self.path / "entities", self.templates, on_change)
        self.sprite_dir = self.path / "sprites"
        self.sprite_dir.mkdir(parents=True, exist_ok=True)
        from game.art.library import SpriteLibrary
        self.sprites = SpriteLibrary(self.sprite_dir)
        if int(self.meta.get("format", 1) or 1) < WORLD_FORMAT and (self.path / "entities").exists():
            from game.migrate import migrate
            migrate(self)

    @property
    def name(self) -> str:
        return self.meta.get("name", self.slug)

    def close(self) -> None:
        """Let go of the world's files (before its folder is deleted, or another world is opened)."""
        from game import bigmap, diskcache
        bigmap.close(self)
        self.entities.close()
        diskcache.close(self)

    @property
    def rules(self) -> dict:
        return {**DEFAULT_RULES, **self.meta.get("rules", {})}

    def set_rule(self, key: str, value) -> None:
        self.meta.setdefault("rules", {})[key] = value
        self.save_meta()

    def _read_meta(self) -> dict:
        path = self.path / "world.json"
        if path.exists():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                pass
        return {"name": self.path.name, "description": "", "format": WORLD_FORMAT}

    def save_meta(self) -> None:
        self.path.mkdir(parents=True, exist_ok=True)
        (self.path / "world.json").write_text(json.dumps(self.meta, indent=2), encoding="utf-8")

    def modifier(self, stat_key: str, score: float) -> int:
        """The bonus a stat score gives, using the stat's own formula or the world default."""
        from game import formula
        stat = self.entities.stat_by_key(stat_key)
        expr = (stat.fields.get("modifier") if stat else None)
        if stat is not None and not expr:
            return 0
        expr = expr or self.rules["default_modifier"]
        try:
            return int(formula.evaluate(expr, {"value": score}))
        except Exception:
            return 0


BUNDLED = Path(__file__).resolve().parent.parent / "bundled" / "worlds"   # ready-made worlds (the phone app)

class WorldManager:
    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def list(self) -> list[dict]:
        worlds = []
        for folder in sorted(self.root.iterdir()):
            if not (folder / "world.json").exists():
                continue
            try:
                meta = json.loads((folder / "world.json").read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            counts = _counts(folder / "entities")
            worlds.append({"slug": folder.name, "name": meta.get("name", folder.name),
                           "description": meta.get("description", ""), "created": meta.get("created", ""),
                           "counts": counts})
        return worlds

    def exists(self, slug: str) -> bool:
        return (self.root / slug / "world.json").exists()

    def _free_slug(self, name: str) -> str:
        base = slugify(name)
        slug, n = base, 2
        while (self.root / slug).exists():
            slug = f"{base}-{n}"
            n += 1
        return slug

    def create(self, name: str, description: str = "", starter="test") -> str:
        """starter: "test", "srd" (the sample town plus the SRD), "blank", or a list of built-in pack keys
        (see game/builtin_packs.py) to combine."""
        slug = self._free_slug(name)
        path = self.root / slug
        (path / "entities").mkdir(parents=True)
        (path / "templates").mkdir()
        (path / "sprites").mkdir()
        meta = {"name": name.strip() or "New World", "description": description, "format": WORLD_FORMAT,
                "created": datetime.now().isoformat(timespec="seconds"), "rules": {}}
        (path / "world.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        if isinstance(starter, (list, tuple, set)):
            from game import builtin_packs
            builtin_packs.start_world(World(path), starter)
        elif starter and starter != "blank":
            from game.starter import install_starter
            world = World(path)
            install_starter(world, starter)
        return slug

    def open(self, slug: str, on_change: Callable | None = None) -> World:
        if not self.exists(slug):
            raise FileNotFoundError(slug)
        return World(self.root / slug, on_change)

    def rename(self, slug: str, name: str, description: str | None = None) -> None:
        path = self.root / slug / "world.json"
        meta = json.loads(path.read_text(encoding="utf-8"))
        meta["name"] = name.strip() or meta.get("name", slug)
        if description is not None:
            meta["description"] = description
        path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    def duplicate(self, slug: str, new_name: str) -> str:
        new_slug = self._free_slug(new_name)
        shutil.copytree(self.root / slug, self.root / new_slug)
        meta_path = self.root / new_slug / "world.json"
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        meta["name"] = new_name
        meta["created"] = datetime.now().isoformat(timespec="seconds")
        meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
        return new_slug

    def delete(self, slug: str) -> None:
        target = (self.root / slug).resolve()
        if target.parent != self.root.resolve():
            raise ValueError("Refusing to delete outside the worlds folder")
        from game import diskcache
        diskcache.close_folder(target)                  # (an open file can't be deleted on Windows)
        shutil.rmtree(target)

    def ensure_default(self) -> str:
        """Make sure at least one world exists; return a usable slug. A world that comes ready-made with the
        game (bundled/worlds, made by tools/prebuild_world.py: the phone app has one) is copied in rather
        than made, which takes a while and a good deal of memory."""
        worlds = self.list()
        if worlds:
            return worlds[0]["slug"]
        if BUNDLED.is_dir():
            made = []
            for src in sorted(p for p in BUNDLED.iterdir() if (p / "world.json").exists()):
                if not (self.root / src.name).exists():
                    shutil.copytree(src, self.root / src.name)
                    made.append(src.name)
            if made:
                return made[0]
        from game import builtin_packs
        return self.create("First World", "A world to experiment in.",
                           starter=[k for k, _label in builtin_packs.choices()])


def default_rules() -> dict:
    return copy.deepcopy(DEFAULT_RULES)


def _counts(folder: Path) -> dict[str, int]:
    """How many of each type a world has, without opening it."""
    import sqlite3
    db_file = folder / "entities.db"
    if db_file.exists():
        try:
            con = sqlite3.connect(f"file:{db_file}?mode=ro", uri=True)
            try:
                return {t: n for t, n in con.execute("SELECT type, COUNT(*) FROM entities GROUP BY type")}
            finally:
                con.close()
        except sqlite3.Error:
            return {}
    counts = {}
    for f in folder.glob("*.json"):                     # a world from before step 18
        try:
            counts[f.stem] = len(json.loads(f.read_text(encoding="utf-8")).get("entities", []))
        except (OSError, ValueError):
            pass
    return counts
