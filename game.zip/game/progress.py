"""Progress for slow work (opening a world, building its caches), shown by the loading screen.

Game code reports how far along it is; it never knows whether anything is listening:

    progress.report(0.4, "Laying out the land")

A caller that knows the bigger picture maps a piece of work into its share of the whole bar:

    with progress.part(0.0, 0.5, "Reading the world"):
        open_world()            # its own report(0..1) calls fill the first half of the bar

The UI installs a reporter (set_reporter) that draws the bar; without one, reports cost next to nothing.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Callable

Reporter = Callable[[float, str], None]

_reporter: Reporter | None = None
_stack: list[tuple[float, float, str]] = []
_step: list = [0.0, ""]          # the innermost piece of work: how far along it is, and its name


def set_reporter(fn: Reporter | None) -> Reporter | None:
    """Install a reporter (fraction 0..1, text). Returns the previous one."""
    global _reporter
    old, _reporter = _reporter, fn
    return old


def active() -> bool:
    return _reporter is not None


def report(fraction: float, text: str = "") -> None:
    if _reporter is None:
        return
    f = max(0.0, min(1.0, float(fraction)))
    _step[0], _step[1] = f, text or (_stack[-1][2] if _stack else "")
    label = text
    for lo, hi, name in reversed(_stack):
        f = lo + f * (hi - lo)
        label = label or name
    _reporter(f, label)


def step() -> tuple[float, str]:
    """How far along the piece of work being done right now is (0..1), and its name: the second bar of a
    loading screen."""
    return _step[0], _step[1]


@contextmanager
def part(lo: float, hi: float, text: str = ""):
    """Within this block, report(0..1) fills the bar from lo to hi (of the enclosing part)."""
    _stack.append((float(lo), float(hi), text))
    try:
        report(0.0, text)
        yield
        report(1.0, text)
    finally:
        _stack.pop()


__all__ = ["set_reporter", "report", "part", "active", "step"]
