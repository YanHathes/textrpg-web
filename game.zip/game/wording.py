"""The words for working the game (step 20): "tap" on a phone, "click" with a mouse, "press" with a
controller. The game's text is written for a mouse; say(text) turns it into the words for how the game is
being played now.

    how()          "touch", "mouse" or "pad"
    set_how(h)     the main window sets it: touch on a phone, pad while a controller is connected
    say(text)      the text in the right words ("Click a square" -> "Tap a square" on a phone)
    verb(cap)      just the word: "tap", "click" or "press" (capitalised if cap)

Only words about working the game change: narration ("she presses a coin into your hand") is left alone.
"""
from __future__ import annotations

import re

_HOW = {"now": "mouse"}
HOWS = ("touch", "mouse", "pad")

WORDS = {   # base, -s, -ing, -ed
    "touch": ("tap", "taps", "tapping", "tapped"),
    "mouse": ("click", "clicks", "clicking", "clicked"),
    "pad": ("press", "presses", "pressing", "pressed"),
}
KEYS = {    # keys named in the mouse-and-keyboard text, for the other ways of playing
    "touch": {"Esc": "Back", "Enter": "Go", "Space": "Go"},
    "pad": {"Esc": "B", "Enter": "A", "Space": "A"},
}

# click words (and, in the other two, tap words) as an instruction; "Press" only as an instruction to the
# player (the start of a sentence, or "press" before a key or button) so "presses gold on you" is left be
_CLICK = re.compile(r"\b(?:(double|right|left)[- ])?(click|tap)(s|ing|ed|ped|ping)?\b", re.I)
_PRESS = re.compile(r"\b(press)(?= (?:Esc|Enter|Space|Done|it|the|a|an|one|when|[A-Z0-9]\b))", re.I)
_KEY = re.compile(r"\b(Esc|Enter|Space)\b")


def how() -> str:
    return _HOW["now"]


def set_how(h: str) -> bool:
    """Returns True if it changed."""
    h = h if h in HOWS else "mouse"
    if _HOW["now"] == h:
        return False
    _HOW["now"] = h
    return True


def verb(cap: bool = False, h: str | None = None) -> str:
    w = WORDS[h or how()][0]
    return w.capitalize() if cap else w


def _match_case(word: str, like: str) -> str:
    if like.isupper() and len(like) > 1:
        return word.upper()
    return word.capitalize() if like[:1].isupper() else word


def say(text: str, h: str | None = None) -> str:
    """text in the words for how the game is played (h, or how())."""
    h = h or how()
    if not text:
        return text
    base, s, ing, ed = WORDS[h]

    def click(m: re.Match) -> str:
        side, word, end = m.group(1), m.group(2), (m.group(3) or "").lower()
        if h == "mouse" and word.lower() == "click":
            return m.group(0)                             # written for the mouse already
        new = {"": base, "s": s, "ing": ing, "ping": ing, "ed": ed, "ped": ed}.get(end, base)
        if side:
            side_l = side.lower()
            if side_l == "double":
                lead = m.group(0)[:len(side)]
                return lead + m.group(0)[len(side)] + _match_case(new, word)
            if side_l == "right":                         # a right click: a long press on a phone, X on a pad
                alt = {"touch": "long-press", "pad": "X", "mouse": "right-click"}[h]
                return _match_case(alt, side)
            return _match_case(new, side)                 # "left click" is just a click (a tap, a press)
        return _match_case(new, word)
    text = _CLICK.sub(click, text)
    if h != "mouse":
        text = _PRESS.sub(lambda m: _match_case(base, m.group(1)), text)
        keys = KEYS[h]
        text = _KEY.sub(lambda m: keys.get(m.group(1), m.group(1)), text)
    return text


_HINTS = {   # keyboard hints in the minigames' help, for the other ways of playing
    "touch": [
        (re.compile(r"\s*\((?:keys? )?[0-9][^)]*\)"), ""),                         # "(keys 1-3)", "(1-5, or click)"
        (re.compile(r"\s*\(click or [^)]*\)"), ""),
        (re.compile(r"\s*\((?:right / )?space(?: or click)?\)"), ""),             # "(space)", "(space or click)"
        (re.compile(r"\s*\([A-Z]\)"), ""),                                        # "Bank it (S)": a button below
        (re.compile(r"\((?:left|right|up|down|arrows)[^)]*\)"), "(the arrows below)"),
        (re.compile(r"\bthe arrow keys\b"), "the arrows below"),
        (re.compile(r"\b[Hh]old space\b"), "Hold a finger down"),
        (re.compile(r"\bspace\b"), "a tap"),
    ],
    "pad": [
        (re.compile(r"\s*\((?:keys? )?[0-9][^)]*\)"), ""),
        (re.compile(r"\s*\(click or [^)]*\)"), ""),
        (re.compile(r"\(right / space\)"), "(A)"),
        (re.compile(r"\((?:left|right|up|down)[^)]*\)"), "(the d-pad)"),
        (re.compile(r"\(space(?: or click)?\)"), "(A)"),
        (re.compile(r"\b[Hh]old space\b"), "Hold A"),
        (re.compile(r"\bspace\b"), "A"),
        (re.compile(r"\bthe arrow keys\b"), "the d-pad"),
        (re.compile(r"\(arrows\)"), "(the d-pad)"),
    ],
}


def game_help(text: str, h: str | None = None) -> str:
    """A minigame's help ("Throw (space) when..."), for how the game is played: no keys on a phone."""
    h = h or how()
    for pat, rep in _HINTS.get(h, []):
        text = pat.sub(rep, text)
    return say(text, h)


def give_up(h: str | None = None) -> str:
    """How to roll the dice instead of playing a minigame."""
    return {"touch": "", "pad": "B: roll the dice instead"}.get(h or how(), "Esc: roll the dice instead")


__all__ = ["how", "set_how", "say", "verb", "game_help", "give_up", "HOWS"]
