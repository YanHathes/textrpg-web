"""The world map: where towns and landmarks are, what the land is like, and what the party has seen.

Distances are miles from the map's top-left corner (y grows southward).
  * Towns with a "position" are where they say. Others are placed by their roads: a road's
    direction and length (hours x travel_mph) from a town that is already placed.
  * Landmarks: their position, or a few miles out from their town in their direction.
  * The land is a grid of cells (world map setting "cell", miles per cell; by default it grows with
    the size of the world so big worlds stay quick).
  * Continents are rough ovals with ragged coasts, filled with their main biome; everything outside
    them is ocean. Regions colour the land inside them (a region only paints its own continent).
    Where regions meet, the nearer one wins. A world with no continents works as before: regions on
    an ocean background, or, with no regions either, land shaped around its towns' terrain.
  * Fog of war: cells within sight (rule sight_miles) of everywhere the party has been are
    revealed. Stored in the game state as a base64 bitset.

Nothing here draws: ui/map_dialog.py does.
"""
from __future__ import annotations

import base64
import math
from dataclasses import dataclass

from game.constants import BIOMES

VECTORS = {"North": (0, -1), "South": (0, 1), "East": (1, 0), "West": (-1, 0),
           "North-east": (0.707, -0.707), "North-west": (-0.707, -0.707),
           "South-east": (0.707, 0.707), "South-west": (-0.707, 0.707)}
BIOME_COLOR = {"Plains": "#9ab05a", "Forest": "#3f7a3a", "Hills": "#a08a5a", "Mountains": "#8a8a90",
               "Coast": "#d6c690", "Swamp": "#5a7050", "Desert": "#d0b070", "Arctic": "#d8e4ec",
               "Jungle": "#2c6428", "Badlands": "#a0603a", "Lake": "#4a90c0", "Ocean": "#2a5a8a",
               "Taiga": "#3a6050", "Tundra": "#a8b4a0", "Savanna": "#c0b060"}
MARGIN = 60          # miles of land kept around everything on an auto-sized map


def mph(world) -> float:
    return max(0.5, float(world.rules.get("travel_mph", 3) or 3))


def _pt(value) -> tuple[float, float] | None:
    if isinstance(value, dict) and ("x" in value or "y" in value):
        try:
            return float(value.get("x") or 0), float(value.get("y") or 0)
        except (TypeError, ValueError):
            return None
    return None


# ======================================================================
# Where things are
# ======================================================================
def _road_miles(world, road) -> float:
    hours = float(road.get("hours") or 0)
    return (hours if hours > 0 else 8) * mph(world)


def _town_positions(world) -> dict[str, tuple[float, float]]:
    towns = world.entities.all("town")
    pos: dict[str, tuple[float, float]] = {}
    for t in towns:
        p = _pt(t.fields.get("position"))
        if p is not None:
            pos[t.id] = p
    explicit = bool(pos)
    links: dict[str, list] = {}
    for t in towns:
        for r in t.fields.get("roads") or []:
            dest = r.get("leads_to")
            if not dest or not r.get("direction") or world.entities.get(dest) is None:
                continue
            vx, vy = VECTORS.get(r["direction"], (1, 0))
            miles = _road_miles(world, r)
            links.setdefault(t.id, []).append((dest, vx * miles, vy * miles))
            links.setdefault(dest, []).append((t.id, -vx * miles, -vy * miles))

    def spread(start_ids):
        queue = list(start_ids)
        while queue:
            tid = queue.pop(0)
            x, y = pos[tid]
            for dest, dx, dy in links.get(tid, []):
                if dest not in pos:
                    pos[dest] = (x + dx, y + dy)
                    queue.append(dest)

    spread(list(pos))
    for t in towns:                                  # towns not connected to anything placed yet
        if t.id in pos:
            continue
        if pos:
            right = max(x for x, _ in pos.values()) + 40
            top = min(y for _, y in pos.values())
            pos[t.id] = (right, top)
        else:
            pos[t.id] = (0.0, 0.0)
        spread([t.id])
    if pos and not explicit:                         # only road layout: shift it onto the map
        minx = min(x for x, _ in pos.values())
        miny = min(y for _, y in pos.values())
        pos = {k: (x - minx + MARGIN, y - miny + MARGIN) for k, (x, y) in pos.items()}
    return pos


def town_positions(world) -> dict[str, tuple[float, float]]:
    return world.entities.custom_index("town", "positions", lambda _towns: _town_positions(world))


def town_position(world, town) -> tuple[float, float] | None:
    if town is None:
        return None
    return town_positions(world).get(town.id)


def landmark_position(world, lm) -> tuple[float, float] | None:
    p = _pt(lm.fields.get("position"))
    if p is not None:
        return p
    town = world.entities.get(lm.fields.get("near_town") or "")
    base = town_position(world, town)
    if base is None:
        return None
    vx, vy = VECTORS.get(lm.fields.get("direction") or "North", (0, -1))
    miles = max(3.0, float(lm.fields.get("travel_minutes") or 60) / 60 * mph(world) + 2)
    return base[0] + vx * miles, base[1] + vy * miles


def dungeon_position(world, d) -> tuple[float, float] | None:
    lm = next(iter(world.entities.by_field("landmark", "dungeon", d.id)), None)
    if lm is not None:
        return landmark_position(world, lm)
    town = world.entities.get(d.fields.get("town") or "")
    base = town_position(world, town)
    if base is None:
        return None
    vx, vy = VECTORS.get(d.fields.get("direction") or "North", (0, -1))
    return base[0] + vx * 8, base[1] + vy * 8


def distance(a, b) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def road_hours(world, town, road) -> float:
    """A road's travel time: its own hours, or (when 0) the map distance at walking pace."""
    hours = float(road.get("hours") or 0)
    if hours > 0:
        return hours
    dest = world.entities.get(road.get("leads_to") or "")
    a, b = town_position(world, town), town_position(world, dest)
    if a is None or b is None or (a == b):
        return 8.0
    return max(0.5, round(distance(a, b) * 1.15 / mph(world), 1))


# ======================================================================
# The land
# ======================================================================
@dataclass
class Grid:
    cols: int
    rows: int
    cell: float
    width: float
    height: float
    biome: bytearray            # index into BIOMES per cell
    region: list                # region entity id per cell ("" = none)
    continent: list = None      # continent entity id per cell ("" = sea, or no continents)

    def index(self, x: float, y: float) -> int | None:
        c, r = int(x // self.cell), int(y // self.cell)
        if 0 <= c < self.cols and 0 <= r < self.rows:
            return r * self.cols + c
        return None

    def biome_at(self, x: float, y: float) -> str:
        i = self.index(x, y)
        return BIOMES[self.biome[i]] if i is not None else "Ocean"


def settings(world) -> dict:
    m = dict(world.meta.get("map") or {})
    w, h = float(m.get("width") or 0), float(m.get("height") or 0)
    regions = world.entities.all("region")
    continents = world.entities.all("continent")
    if not w or not h:
        xs, ys = [0.0], [0.0]
        for x, y in town_positions(world).values():
            xs.append(x)
            ys.append(y)
        for r in list(regions) + list(continents):
            p = _pt(r.fields.get("center"))
            if p is not None:
                size = float(r.fields.get("size_miles") or 60) * max(1.0, float(r.fields.get("stretch") or 1))
                xs += [p[0] - size, p[0] + size]
                ys += [p[1] - size, p[1] + size]
        w = w or max(300.0, max(xs) + MARGIN)
        h = h or max(200.0, max(ys) + MARGIN)
    # about 600 cells across at most, so a world thousands of miles wide is still quick to draw
    cell = max(0.5, float(m.get("cell") or max(2.0, math.ceil(max(w, h) / 600.0))))
    background = m.get("background") or ("Ocean" if regions or continents else "Plains")
    return {"width": w, "height": h, "cell": cell, "background": background, "seed": int(m.get("seed") or 7)}


def _hash(ix: int, iy: int, seed: int) -> float:
    n = (ix * 374761393 + iy * 668265263 + seed * 2147483647) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


def noise(x: float, y: float, scale: float = 24.0, seed: int = 7) -> float:
    """Smooth value noise in 0..1 (two octaves)."""
    total, amp, norm = 0.0, 1.0, 0.0
    for octave in range(2):
        s = scale / (2 ** octave)
        gx, gy = x / s, y / s
        ix, iy = int(math.floor(gx)), int(math.floor(gy))
        fx, fy = gx - ix, gy - iy
        fx, fy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
        a, b = _hash(ix, iy, seed + octave), _hash(ix + 1, iy, seed + octave)
        c, d = _hash(ix, iy + 1, seed + octave), _hash(ix + 1, iy + 1, seed + octave)
        total += amp * (a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy)
        norm += amp
        amp *= 0.5
    return total / norm


def _shapes(world) -> list[tuple]:
    """(region id, biome index, cx, cy, rx, ry) for every region on the map; or, with no regions,
    one patch per town in its terrain."""
    out = []
    for r in world.entities.all("region"):
        p = _pt(r.fields.get("center"))
        if p is None:
            continue
        size = max(1.0, float(r.fields.get("size_miles") or 60))
        stretch = max(0.2, float(r.fields.get("stretch") or 1))
        biome = r.fields.get("biome") or "Plains"
        out.append((r.id, BIOMES.index(biome) if biome in BIOMES else 0, p[0], p[1], size * stretch, size))
    if out:
        return out
    for t in world.entities.all("town"):
        p = town_position(world, t)
        if p is None:
            continue
        terrain = t.fields.get("terrain") or "Plains"
        out.append(("", BIOMES.index(terrain) if terrain in BIOMES else 0, p[0], p[1], 30.0, 30.0))
    return out


def _continent_shapes(world) -> list[tuple]:
    """(continent id, biome index, cx, cy, rx, ry, ragged 0..1) for every placed continent."""
    out = []
    for c in world.entities.all("continent"):
        p = _pt(c.fields.get("center"))
        if p is None:
            continue
        size = max(1.0, float(c.fields.get("size_miles") or 400))
        stretch = max(0.2, float(c.fields.get("stretch") or 1))
        biome = c.fields.get("biome") or "Plains"
        ragged = max(0.0, min(1.0, float(c.fields.get("ragged") if c.fields.get("ragged") not in (None, "") else 50)
                              / 100.0))
        out.append((c.id, BIOMES.index(biome) if biome in BIOMES else 0, p[0], p[1], size * stretch, size, ragged))
    return out


def _region_continents(world) -> dict[str, str]:
    """region id -> the continent it was put on ("" = whichever continent it lies on)."""
    return {r.id: (r.fields.get("continent") or "") for r in world.entities.all("region")}


def _signature(world, s: dict, shapes: list) -> tuple:
    return (round(s["width"], 1), round(s["height"], 1), s["cell"], s["background"], s["seed"], tuple(shapes),
            tuple(_continent_shapes(world)), tuple(sorted(_region_continents(world).items())))


def terrain(world) -> Grid:
    """The land as a grid (cached until regions, towns or map settings change)."""
    s = settings(world)
    shapes = _shapes(world)
    sig = _signature(world, s, shapes)
    cached = getattr(world, "_terrain_cache", None)
    if cached is not None and cached[0] == sig:
        return cached[1]
    from game import diskcache
    fp = diskcache.fingerprint("terrain", sig, tuple(Grid.__dataclass_fields__), BIOMES)
    grid = diskcache.load(world, "terrain", fp)                 # worked out on an earlier run
    if grid is not None:
        world._terrain_cache = (sig, grid)
        return grid
    cell = s["cell"]
    cols, rows = max(1, int(math.ceil(s["width"] / cell))), max(1, int(math.ceil(s["height"] / cell)))
    bg = BIOMES.index(s["background"]) if s["background"] in BIOMES else 0
    biome = bytearray([bg]) * (cols * rows)
    region = [""] * (cols * rows)
    continent = [""] * (cols * rows)
    seed = s["seed"]
    lands = _continent_shapes(world)
    if lands:
        best_c = [1.0] * (cols * rows)
        from game import progress
        for li, (cid, b, cx, cy, rx, ry, ragged) in enumerate(lands):
            progress.report(0.3 * li / max(1, len(lands)), "Raising the continents")
            reach = 1.0 + 0.6 * ragged
            c0, c1 = max(0, int((cx - rx * reach) // cell)), min(cols - 1, int((cx + rx * reach) // cell))
            r0, r1 = max(0, int((cy - ry * reach) // cell)), min(rows - 1, int((cy + ry * reach) // cell))
            coast = max(rx, ry) / 4.0                 # the size of bays and headlands
            for r in range(r0, r1 + 1):
                y = (r + 0.5) * cell
                dy = (y - cy) / ry
                base = r * cols
                for c in range(c0, c1 + 1):
                    x = (c + 0.5) * cell
                    dx = (x - cx) / rx
                    d = math.sqrt(dx * dx + dy * dy)
                    if d > reach:
                        continue
                    score = d - (noise(x, y, coast, seed + 11) - 0.5) * 1.1 * ragged \
                        - (noise(x, y, coast / 4.0, seed + 23) - 0.5) * 0.3 * ragged
                    i = base + c
                    if score < best_c[i]:
                        best_c[i] = score
                        biome[i] = b
                        continent[i] = cid
    on = _region_continents(world)
    best = [1.0] * (cols * rows)                     # beyond 1.0 (with wobble) is outside every region
    from game import progress
    for si, (rid, b, cx, cy, rx, ry) in enumerate(shapes):
        if si % 8 == 0:
            progress.report(0.3 + 0.7 * si / max(1, len(shapes)), "Shaping the land")
        wanted = on.get(rid, "")
        reach = 1.35
        c0, c1 = max(0, int((cx - rx * reach) // cell)), min(cols - 1, int((cx + rx * reach) // cell))
        r0, r1 = max(0, int((cy - ry * reach) // cell)), min(rows - 1, int((cy + ry * reach) // cell))
        for r in range(r0, r1 + 1):
            y = (r + 0.5) * cell
            dy = (y - cy) / ry
            base = r * cols
            for c in range(c0, c1 + 1):
                x = (c + 0.5) * cell
                dx = (x - cx) / rx
                d = math.sqrt(dx * dx + dy * dy)
                if d > reach:
                    continue
                score = d - (noise(x, y, 28.0, seed) - 0.5) * 0.55
                i = base + c
                if lands and (not continent[i] or (wanted and continent[i] != wanted)):
                    continue                          # regions only colour their own continent's land
                if score < best[i]:
                    best[i] = score
                    biome[i] = b
                    region[i] = rid
    grid = Grid(cols, rows, cell, s["width"], s["height"], biome, region, continent)
    world._terrain_cache = (sig, grid)
    diskcache.store(world, "terrain", fp, grid)
    return grid


def biome_at(world, x: float, y: float) -> str:
    return terrain(world).biome_at(x, y)


def region_at(world, x: float, y: float):
    g = terrain(world)
    i = g.index(x, y)
    return world.entities.get(g.region[i]) if i is not None and g.region[i] else None


def continent_at(world, x: float, y: float):
    g = terrain(world)
    i = g.index(x, y)
    if i is None or not g.continent or not g.continent[i]:
        return None
    return world.entities.get(g.continent[i])


def continent_of_region(world, region):
    if region is None:
        return None
    c = world.entities.get(region.fields.get("continent") or "")
    if c is not None:
        return c
    p = _pt(region.fields.get("center"))
    return continent_at(world, *p) if p is not None else None


def continent_of_town(world, town):
    if town is None:
        return None
    r = world.entities.get(town.fields.get("region_ref") or "")
    if r is not None and r.fields.get("continent"):
        return world.entities.get(r.fields["continent"])
    p = town_position(world, town)
    return continent_at(world, *p) if p is not None else None


def continent_bounds(world, c) -> tuple[float, float, float, float] | None:
    """(x0, y0, x1, y1) in miles around a continent's land."""
    p = _pt(c.fields.get("center"))
    if p is None:
        return None
    size = max(1.0, float(c.fields.get("size_miles") or 400))
    rx, ry = size * max(0.2, float(c.fields.get("stretch") or 1)) * 1.25, size * 1.25
    return p[0] - rx, p[1] - ry, p[0] + rx, p[1] + ry


def region_bounds(world, r) -> tuple[float, float, float, float] | None:
    p = _pt(r.fields.get("center"))
    if p is None:
        return None
    size = max(1.0, float(r.fields.get("size_miles") or 60))
    rx, ry = size * max(0.2, float(r.fields.get("stretch") or 1)) * 1.2, size * 1.2
    return p[0] - rx, p[1] - ry, p[0] + rx, p[1] + ry


def party_continent(world, state):
    p = party_position(world, state)
    return continent_at(world, *p) if p is not None else None


def region_of_town(world, town):
    if town is None:
        return None
    r = world.entities.get(town.fields.get("region_ref") or "")
    if r is not None:
        return r
    p = town_position(world, town)
    return region_at(world, *p) if p is not None else None


def settlement_kind(town) -> str:
    kind = town.fields.get("kind") or ""
    if kind:
        return kind
    pop = int(town.fields.get("population") or 0)
    return "Hamlet" if pop < 100 else "Village" if pop < 1000 else "Town" if pop < 6000 else "City" \
        if pop < 25000 else "Capital"


# ======================================================================
# The party on the map, and fog of war
# ======================================================================
def party_position(world, state) -> tuple[float, float] | None:
    from game import places
    spot = places.current(world, state)
    pos = (getattr(state, "explore", None) or {}).get("pos") or {}
    if pos.get("area") == "world" and pos.get("loc") == state.location and spot.kind in ("street", "building",
                                                                                         "hex", "landmark", "wild"):
        from game.worldmap import SQ
        return float(pos.get("x", 0)) / SQ, float(pos.get("y", 0)) / SQ      # exactly where the party walked
    return party_position_of(world, spot, state)


def party_position_of(world, spot, state=None) -> tuple[float, float] | None:
    """Where on the map a place (a Spot) is."""
    if spot.kind == "hex":
        from game import hexes as H
        return H.center(world, spot.extra["q"], spot.extra["r"])
    if spot.kind == "landmark" and spot.extra.get("landmark") is not None:
        return landmark_position(world, spot.extra["landmark"])
    if spot.kind == "dungeon" and spot.extra.get("dungeon") is not None:
        return dungeon_position(world, spot.extra["dungeon"])
    base = town_position(world, spot.town)
    if base is None:
        return None
    if spot.kind == "voyage" and state is not None and state.journey:
        j = state.journey
        a = town_position(world, world.entities.get(j.get("from") or ""))
        b = town_position(world, world.entities.get(j.get("to") or ""))
        if a is not None and b is not None:
            t = min(1.0, float(j.get("done", 0)) / max(1.0, float(j.get("days", 1))))
            return a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t
    if spot.kind == "road" and state is not None and state.journey:
        j = state.journey
        a = town_position(world, world.entities.get(j.get("from") or ""))
        b = town_position(world, world.entities.get(j.get("to") or ""))
        if a is not None and b is not None:
            t = min(1.0, float(j.get("done", 0)) / max(0.1, float(j.get("hours", 1))))
            return a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t
    if spot.kind == "wild":
        vx, vy = VECTORS.get(spot.direction, (0, 0))
        return base[0] + vx * 5, base[1] + vy * 5
    return base


def fog_enabled(world) -> bool:
    return bool(world.rules.get("fog_of_war", True))


def _fog_bits(world, state) -> bytearray:
    g = terrain(world)
    n = (g.cols * g.rows + 7) // 8
    cache = getattr(state, "_fog_cache", None)
    if cache is not None and cache[0] == (g.cols, g.rows) and cache[2] == state.fog:
        return cache[1]
    bits = bytearray(n)
    if state.fog:
        try:
            raw = base64.b64decode(state.fog.split(":", 1)[-1])
            dims = state.fog.split(":", 1)[0] if ":" in state.fog else ""
            if dims == f"{g.cols}x{g.rows}" and len(raw) == n:
                bits = bytearray(raw)
        except (ValueError, TypeError):
            pass
    state._fog_cache = ((g.cols, g.rows), bits, state.fog)
    return bits


def _store_fog(world, state, bits: bytearray) -> None:
    g = terrain(world)
    state.fog = f"{g.cols}x{g.rows}:" + base64.b64encode(bytes(bits)).decode("ascii")
    state._fog_cache = ((g.cols, g.rows), bits, state.fog)


def reveal(world, state, x: float, y: float, radius: float | None = None) -> None:
    g = terrain(world)
    radius = float(radius if radius is not None else world.rules.get("sight_miles", 15) or 15)
    bits = _fog_bits(world, state)
    cr = int(math.ceil(radius / g.cell))
    c0, r0 = int(x // g.cell), int(y // g.cell)
    changed = False
    for r in range(max(0, r0 - cr), min(g.rows, r0 + cr + 1)):
        for c in range(max(0, c0 - cr), min(g.cols, c0 + cr + 1)):
            if (c - c0) ** 2 + (r - r0) ** 2 <= cr * cr:
                i = r * g.cols + c
                if not bits[i >> 3] & (1 << (i & 7)):
                    bits[i >> 3] |= 1 << (i & 7)
                    changed = True
    if changed:
        _store_fog(world, state, bits)


def reveal_here(world, state) -> None:
    p = party_position(world, state)
    if p is not None:
        reveal(world, state, *p)


def seen(world, state, x: float, y: float) -> bool:
    if not fog_enabled(world):
        return True
    g = terrain(world)
    i = g.index(x, y)
    if i is None:
        return False
    return bool(_fog_bits(world, state)[i >> 3] & (1 << (i & 7)))


def seen_cells(world, state) -> bytearray | None:
    """The fog bitset (None when fog of war is off)."""
    return _fog_bits(world, state) if fog_enabled(world) else None


def town_known(world, state, town) -> bool:
    if not fog_enabled(world) or town.id in state.visited:
        return True
    p = town_position(world, town)
    return p is not None and seen(world, state, *p)
