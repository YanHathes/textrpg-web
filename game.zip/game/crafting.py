"""Crafting: every item can be made, its recipe worked out from what the item is.

Where a recipe comes from, first that applies:

    1. a Recipe entity for the item (Library > Recipes)
    2. the item's own "recipe" field (the Crafting step of the item editor)
    3. the hand-made recipes for the in-between goods (BASE: ore into ingots, logs into planks, hides into
       leather, fibre into cloth, grain into flour...)
    4. the automatic one: the item's kind (from its category, weapon or armor type, tags and name) says
       where it's made and with what tools (KINDS, a world rule), and its materials are that kind's table,
       scaled by value so they cost about half the item's price (as in the 2014 rules). Magic items need
       their mundane base item, monster parts chosen by rarity and what the item does (a Frost Heart for
       cold, a Wyvern Stinger for poison...), and, if they cast a spell, a scroll of it.

Raw materials (ore, logs, hides, herbs, fish, gems, monster parts, farm goods...) have no recipe: they're
gathered (game/gathering.py), skinned, looted or bought.

A recipe:

    {"item": id, "makes": n, "stations": ["forge"], "tools": ["Smith's Tools"], "stat": "str",
     "materials": [[item id or "tag:hide", count], ...], "work": gp of work, "dc": n, "kind": ..., "auto": bool}

Work goes at 5 gp a day per worker (world rule craft_pace), plus 5 a day for each hired helper; magic
items and consumables take days by rarity instead (world rules magic_days, potion_days). A job is kept in
the save's holdings (game/holdings.py) and goes on while the party is away (game/ticker.py), as long as the
station is paid for. When it's done, a check with the station's tool (or its minigame) sets the quality.

Recipes are learned (state.recipes) the moment the party has everything one needs, counting what it could
make from what it has (iron ore and coal teach the iron ingot; with coal enough left over, the steel one).
"""
from __future__ import annotations

import math
import random
import re
import zlib

DAY = 1440
STEP_AT = 4                      # a material used more than this many times steps up to a better one
MAX_COUNT = 20
MAX_MAKES = 50

STATIONS = {
    "forge": {"label": "Forge", "prop": "forge", "rent": 2.0, "stat": "str", "tools": ["Smith's Tools"]},
    "carpenter's bench": {"label": "Carpenter's bench", "prop": "workbench", "rent": 1.0, "stat": "dex",
                          "tools": ["Carpenter's Tools", "Woodcarver's Tools"]},
    "tannery": {"label": "Tannery", "prop": "tanning_rack", "rent": 1.0, "stat": "dex",
                "tools": ["Leatherworker's Tools"]},
    "loom": {"label": "Loom", "prop": "loom", "rent": 1.0, "stat": "dex", "tools": ["Weaver's Tools"]},
    "alchemy lab": {"label": "Alchemy lab", "prop": "alchemy_table", "rent": 3.0, "stat": "int",
                    "tools": ["Alchemist's Supplies", "Herbalism Kit"]},
    "scribe's desk": {"label": "Scribe's desk", "prop": "writing_desk", "rent": 1.0, "stat": "int",
                      "tools": ["Calligrapher's Supplies"]},
    "jeweler's bench": {"label": "Jeweler's bench", "prop": "jeweler_bench", "rent": 2.0, "stat": "dex",
                        "tools": ["Jeweler's Tools"]},
    "kitchen": {"label": "Kitchen", "prop": "stove", "rent": 0.5, "stat": "wis", "tools": ["Cook's utensils"]},
    "campfire": {"label": "Campfire", "prop": "campfire", "rent": 0.0, "stat": "wis", "tools": ["Cook's utensils"]},
}
# Building facilities (constants.FACILITIES) and the stations they are
FACILITY_STATION = {"Forge": "forge", "Carpenter's bench": "carpenter's bench", "Tannery": "tannery",
                    "Loom": "loom", "Alchemy lab": "alchemy lab", "Scribe's desk": "scribe's desk",
                    "Jeweler's bench": "jeweler's bench", "Kitchen": "kitchen"}
# who works where (for buildings with no facilities set): the owner's or workers' trade
TRADE_STATIONS = {"Blacksmith": ["forge"], "Armorer": ["forge", "tannery"], "Weaponsmith": ["forge"],
                  "Fletcher": ["carpenter's bench"], "Tailor": ["loom", "tannery"], "Alchemist": ["alchemy lab"],
                  "Jeweler": ["jeweler's bench"], "Innkeeper": ["kitchen"], "Scholar": ["scribe's desk"],
                  "Librarian": ["scribe's desk"]}
KIND_STATIONS = {"Smithy": ["forge"], "Inn": ["kitchen"], "Tavern": ["kitchen"], "Library": ["scribe's desk"],
                 "Boatwright": ["carpenter's bench"], "Workshop": ["carpenter's bench"]}

# kind -> where it's made, with what, and what from (shares of the material budget). Tokens: "herb", "gem",
# "part" pick a material by budget (and by what a magic item does); "tag:x" takes anything tagged x.
KINDS = {
    "metal weapon": {"stations": ["forge"], "tools": ["Smith's Tools"],
                     "materials": [["Iron Ingot", 0.75], ["Tanned Leather", 0.1], ["Timber Plank", 0.15]]},
    "metal armor": {"stations": ["forge"], "tools": ["Smith's Tools"],
                    "materials": [["Iron Ingot", 0.85], ["Tanned Leather", 0.15]]},
    "metal goods": {"stations": ["forge"], "tools": ["Smith's Tools", "Tinker's Tools"],
                    "materials": [["Iron Ingot", 0.8], ["Timber Plank", 0.2]]},
    "wooden goods": {"stations": ["carpenter's bench"], "tools": ["Carpenter's Tools", "Woodcarver's Tools"],
                     "materials": [["Timber Plank", 0.8], ["Iron Ingot", 0.2]]},
    "bow": {"stations": ["carpenter's bench"], "tools": ["Woodcarver's Tools", "Carpenter's Tools"],
            "materials": [["Yew Stave", 0.7], ["Tanned Leather", 0.2], ["Flax", 0.1]]},
    "ammunition": {"stations": ["carpenter's bench"], "tools": ["Woodcarver's Tools"],
                   "materials": [["Ash Shafts", 0.5], ["Goose Feathers", 0.25], ["Iron Ingot", 0.25]]},
    "instrument": {"stations": ["carpenter's bench"], "tools": ["Woodcarver's Tools", "Carpenter's Tools"],
                   "materials": [["Timber Plank", 0.7], ["Tanned Leather", 0.2], ["Flax", 0.1]]},
    "leather": {"stations": ["tannery"], "tools": ["Leatherworker's Tools", "Cobbler's Tools"],
                "materials": [["Tanned Leather", 0.85], ["Iron Ingot", 0.15]]},
    "cloth": {"stations": ["loom"], "tools": ["Weaver's Tools"],
              "materials": [["Bolt of Wool", 0.85], ["Tanned Leather", 0.15]]},
    "potion": {"stations": ["alchemy lab"], "tools": ["Alchemist's Supplies", "Herbalism Kit"],
               "materials": [["Vial", "=1"], ["herb", 0.85]]},
    "oils": {"stations": ["alchemy lab"], "tools": ["Alchemist's Supplies"],
             "materials": [["Lamp Oil Flask", 0.7], ["Flax", 0.3]]},
    "scroll": {"stations": ["scribe's desk"], "tools": ["Calligrapher's Supplies"],
               "materials": [["Parchment (one sheet)", "=1"], ["Ink (1 ounce bottle)", "=1"], ["part", 0.6]]},
    "book": {"stations": ["scribe's desk"], "tools": ["Calligrapher's Supplies", "Cartographer's Tools"],
             "materials": [["Paper (one sheet)", 0.4], ["Ink (1 ounce bottle)", "=1"], ["Tanned Leather", 0.3]]},
    "jewelry": {"stations": ["jeweler's bench"], "tools": ["Jeweler's Tools"],
                "materials": [["Copper Ingot", 0.6], ["gem", 0.4]]},
    "glass": {"stations": ["forge"], "tools": ["Glassblower's Tools"],
              "materials": [["Vial", 0.7], ["Iron Ingot", 0.3]]},
    "meal": {"stations": ["kitchen", "campfire"], "tools": ["Cook's utensils"], "materials": []},
    "drink": {"stations": ["kitchen"], "tools": ["Brewer's Supplies", "Cook's utensils"], "materials": []},
}
STEP_UP = {"Iron Ingot": "Steel Ingot", "Copper Ingot": "Silver Ingot", "Silver Ingot": "Gold Ingot",
           "Bolt of Wool": "Bolt of Linen", "Bolt of Linen": "Bolt of Silk"}

# the in-between goods: name -> (station, [(material, n)], makes, tools)
BASE = {
    "Iron Ingot": ("forge", [("Iron Ore", 2), ("Coal", 1)], 1, None),
    "Steel Ingot": ("forge", [("Iron Ingot", 1), ("Coal", 2)], 1, None),
    "Copper Ingot": ("forge", [("Copper Ore", 1), ("Coal", 1)], 1, None),
    "Silver Ingot": ("forge", [("Silver Ore", 4), ("Coal", 2)], 1, None),
    "Gold Ingot": ("forge", [("Gold Nugget", 2), ("Coal", 1)], 1, None),
    "Mithral Ingot": ("forge", [("Mithral Ore", 2), ("Coal", 3)], 1, None),
    "Timber Plank": ("carpenter's bench", [("tag:log", 1)], 4, None),
    "Ironwood Plank": ("carpenter's bench", [("Ironwood Log", 1)], 1, None),
    "Yew Stave": ("carpenter's bench", [("tag:log", 1)], 1, None),
    "Ash Shafts": ("carpenter's bench", [("tag:log", 1)], 2, None),
    "Tanned Leather": ("tannery", [("tag:hide", 1), ("Pouch of Salt", 1)], 2, None),
    "Parchment (one sheet)": ("tannery", [("Tanned Leather", 1)], 5, None),
    "Bolt of Wool": ("loom", [("Wool Fleece", 5)], 1, None),
    "Bolt of Linen": ("loom", [("Flax", 12)], 1, None),
    "Bolt of Silk": ("loom", [("Silk Cocoons", 5)], 1, None),
    "Dyed Velvet": ("loom", [("Bolt of Silk", 1), ("Jungle Orchid", 2)], 1, None),
    "Sack of Flour": ("kitchen", [("tag:grain", 2)], 1, None),
    "Paper (one sheet)": ("scribe's desk", [("Timber Plank", 2)], 1, None),
    "Ink (1 ounce bottle)": ("alchemy lab", [("Vial", 1), ("Coal", 1), ("Nightshade", 2)], 1, None),
    "Vial": ("forge", [("Stone Block", 2), ("Coal", 1)], 2, ["Glassblower's Tools"]),
    "Bottle, glass": ("forge", [("Stone Block", 2), ("Coal", 1)], 1, ["Glassblower's Tools"]),
    "Lamp Oil Flask": ("alchemy lab", [("tag:fish", 2)], 1, None),
    "Oil (flask)": ("alchemy lab", [("tag:fish", 2)], 1, None),
}
# raw materials: no recipe; gathered, skinned, looted or bought
RAW_TAGS = {"ore", "herb", "hide", "monster", "gem", "fish", "berry", "mushroom", "grain", "log", "fibre",
            "meat", "farm", "feather", "stone"}
RAW_CATEGORIES = {"Material", "Treasure", "Gear"}
RAW_NAMES = {"Pouch of Salt", "Pouch of Pepper", "Saffron Threads", "Brick of Tea", "Sack of Apples",
             "Mango Basket", "Dried Dates", "Sack of Rice", "Seal Blubber", "Powdered Sulphur", "Saltpetre",
             "Vial of Quicksilver", "Spiced Coffee", "Sprig of mistletoe", "Little bag of sand", "String (10 feet)"}
NOT_RAW_CATEGORIES = {"Weapon", "Armor", "Shield", "Tool", "Ammunition", "Clothing", "Trinket", "Consumable"}

# magic: monster parts by what the item does, and how many by rarity
EFFECT_PARTS = [
    (("cold", "frost", "ice", "freez", "winter", "snow"), ["Frost Heart", "Hoarfrost Core", "Rimewraith Shroud"]),
    (("fire", "flame", "burn", "heat", "sun", "dawn"), ["Ash Wraith Ember", "Dragon Scale"]),
    (("poison", "venom", "toxin"), ["Wyvern Stinger", "Scorpion Venom Gland"]),
    (("heal", "health", "regenerat", "life", "restor", "vitality", "troll"), ["Troll Blood", "Royal Jelly"]),
    (("lightning", "storm", "thunder", "shock", "wind"), ["Storm Kite Plume", "Griffon Feather"]),
    (("necrotic", "death", "undead", "life drain", "ghost", "spirit", "wraith"), ["Wraith Essence", "Ghoul Claw"]),
    (("fly", "flight", "feather", "levitat", "speed", "haste", "jump"), ["Griffon Feather", "Harpy Feather"]),
    (("water", "sea", "swim", "tide", "ocean", "breath"), ["Kelp Horror Heart", "Serpent Scale"]),
    (("armor class", "protection", "resistance", "shield", "ward", "defen"), ["Ironback Carapace", "Dragon Scale"]),
    (("see", "sight", "vision", "eye", "true", "detect", "scry"), ["Basilisk Eye", "Crystal Spider Shard"]),
    (("invisib", "shadow", "stealth", "darkness", "hide"), ["Shadow Hound Fang", "Bog Witch Charm"]),
    (("strength", "giant", "might", "ogre"), ["Ogre Tooth", "Troll Blood"]),
    (("charm", "mind", "fear", "illusion", "enchant"), ["Bog Witch Charm", "Feathered Serpent Plume"]),
    (("acid", "corro"), ["Sand Reaver Mandible", "Mantis Blade"]),
]
DEFAULT_PART = {"Common": "Harpy Feather", "Uncommon": "Owlbear Feathers", "Rare": "Griffon Feather",
                "Very rare": "Wraith Essence", "Legendary": "Dragon Scale", "Artifact": "Dragon Scale"}
PART_COUNT = {"Common": 1, "Uncommon": 1, "Rare": 2, "Very rare": 3, "Legendary": 5, "Artifact": 10}
PART_KINDS = {"Common": 1, "Uncommon": 1, "Rare": 2, "Very rare": 2, "Legendary": 3, "Artifact": 3}
HERB_HINTS = [(("heal", "cure", "restor"), "Silverleaf"), (("fire", "flame", "heat"), "Fire Lily"),
              (("cold", "frost", "ice"), "Frostcap"), (("sleep", "slumber"), "Mandrake Root"),
              (("poison", "venom", "toxin"), "Nightshade"), (("vision", "see", "clairvoy"), "Thornapple"),
              (("ghost", "ethereal", "necrotic"), "Ghostcap"), (("water", "breath"), "Bog Myrtle"),
              (("night", "dark", "moon"), "Moonpetal"), (("resist", "toughness"), "Wolfsbane")]
FOCI = {"wand", "rod", "staff", "orb", "amulet", "crystal", "lantern", "lamp", "mirror", "bell", "horn",
        "robes", "totem", "chalk", "censer", "emblem", "reliquary", "hourglass"}
MAGIC_DAYS = {"Common": 5, "Uncommon": 10, "Rare": 50, "Very rare": 125, "Legendary": 250, "Artifact": 500}
POTION_DAYS = {"Common": 1, "Uncommon": 4, "Rare": 10, "Very rare": 20, "Legendary": 40, "Artifact": 80}
RARITY_DC = {"Common": 10, "Uncommon": 15, "Rare": 18, "Very rare": 21, "Legendary": 25, "Artifact": 28}
QUALITY_STEPS = [(15, "Legendary"), (10, "Masterwork"), (5, "Fine"), (0, "Standard")]
# what each trade makes at work (NPCs at work), by kind
TRADE_KINDS = {"Blacksmith": ["metal weapon", "metal armor", "metal goods"], "Armorer": ["metal armor", "leather"],
               "Weaponsmith": ["metal weapon"], "Fletcher": ["bow", "ammunition"], "Tailor": ["cloth", "leather"],
               "Alchemist": ["potion", "oils"], "Jeweler": ["jewelry"], "Innkeeper": ["meal", "drink"],
               "Scholar": ["book", "scroll"], "Librarian": ["book"]}
TRADE_HARVEST = {"Farmer": ["Wild Wheat", "Wild Barley", "Flax", "Wool Fleece", "Pail of Milk", "Sack of Apples"],
                 "Hunter": ["Game Meat", "Rough Hide", "Small Pelt", "Deer Hide", "Rabbit Furs"]}
NPC_MAX_VALUE = 60.0                 # NPCs at work make everyday goods, not plate armor
NPC_STOCK_CAP = 12                   # a shop keeps no more than this many of what its people make


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


def _rules(world) -> dict:
    try:
        return world.rules
    except AttributeError:
        return {}


def pace(world) -> float:
    return float(_rules(world).get("craft_pace", 5) or 5)


def kinds(world) -> dict:
    own = _rules(world).get("craft_kinds") or {}
    if not own:
        return KINDS
    out = dict(KINDS)
    out.update(own)
    return out


def station_info(world, name: str) -> dict:
    own = (_rules(world).get("craft_stations") or {}).get(name)
    base = dict(STATIONS.get(name) or {"label": name.title(), "prop": "table", "rent": 1.0, "stat": "int",
                                      "tools": []})
    if own:
        base.update(own)
    return base


def _value(item) -> float:
    try:
        return max(0.0, float(item.fields.get("value") or 0))
    except (TypeError, ValueError, AttributeError):
        return 0.0


def _tags(item) -> set[str]:
    return {str(t).lower() for t in (item.tags or [])}


def _text(item) -> str:
    return f"{item.name} {item.description or ''}".lower()


def _has(text: str, *words) -> bool:
    return any(re.search(r"\b" + re.escape(w), text) for w in words)


# ----------------------------------------------------------------------------------------------------
# What an item is
# ----------------------------------------------------------------------------------------------------
def is_raw(world, item) -> bool:
    """No recipe: gathered, skinned, looted or bought."""
    if item is None:
        return True
    name = item.name
    if name in BASE:
        return False
    own = set(_rules(world).get("raw_materials") or [])
    if name in RAW_NAMES or name in own:
        return True
    cat = item.fields.get("category") or ""
    if cat in NOT_RAW_CATEGORIES or "magic" in _tags(item):
        return False
    t = _tags(item)
    if not (t & RAW_TAGS):
        return False
    if cat == "Gear":                                   # food that's gathered, not cooked: fish, berries...
        return bool(t & {"fish", "berry", "mushroom", "grain", "meat", "farm"}) or "food" not in t
    return cat in RAW_CATEGORIES


def kind_of(world, item) -> str:
    """The kind of thing an item is, for its automatic recipe ("" for a raw material)."""
    if is_raw(world, item):
        return ""
    own = item.fields.get("craft_kind")
    if own and own in kinds(world):
        return own
    f = item.fields
    cat = f.get("category") or ""
    t = _tags(item)
    n = item.name.lower()
    if cat == "Weapon":
        if _has(n, "bow", "crossbow"):
            return "bow"
        if _has(n, "whip", "sling"):
            return "leather"
        if _has(n, "net"):
            return "cloth"
        if _has(n, "blowgun"):
            return "wooden goods"
        if "metal" in t:
            return "metal weapon"
        return "wooden goods"
    if cat == "Ammunition":
        return "ammunition" if _has(n, "arrow", "bolt") else "metal goods"
    if cat == "Armor":
        at = f.get("armor_type") or ""
        if at == "Heavy" or "metal" in t:
            return "metal armor"
        if _has(n, "padded"):
            return "cloth"
        return "leather"
    if cat == "Shield":
        return "metal armor" if "metal" in t and "magic" in t else "wooden goods"
    if cat == "Tool":
        if "tool: music" in t:
            return "instrument"
        if _has(n, "supplies", "kit", "utensils"):
            return "leather" if not _has(n, "alchemist", "brewer", "glassblower") else "glass"
        return "metal goods"
    if cat == "Consumable":
        if t & {"food"}:
            return "meal"
        return "potion"
    if t & {"scroll"} and _has(n, "scroll", "map"):
        return "scroll" if _has(n, "scroll") else "book"
    if "book" in t:
        return "book" if not _has(n, "ink", "pen", "paper", "parchment", "case") else (
            "leather" if _has(n, "case") else "metal goods" if _has(n, "pen") else "book")
    if t & {"jewelry", "holy", "relic", "treasure"} or cat == "Trinket":
        if t & {"clothing"}:
            return "leather" if _has(n, "boots", "gauntlet", "bracer", "glove", "belt", "quiver") else "cloth"
        if _has(n, "banner", "standard", "shroud", "mask"):
            return "cloth"
        if _has(n, "ledger", "chart", "map", "grimoire", "tablet"):
            return "book"
        if _has(n, "strongbox", "sceptre", "staff", "crook"):
            return "metal goods" if _has(n, "strongbox") else "wooden goods"
        if _has(n, "incense", "candle"):
            return "oils"
        return "jewelry"
    if cat == "Clothing" or "clothing" in t:
        return "leather" if _has(n, "boots", "gauntlet", "bracer", "glove", "belt") else "cloth"
    if "food" in t:
        return "meal"
    if "drink" in t:
        return "drink"
    if "alchemical" in t or _has(n, "acid", "antitoxin", "poison", "perfume", "holy water", "soap"):
        return "potion"
    if _has(n, "candle", "oil", "incense", "chalk", "sealing wax", "torch", "tinderbox"):
        return "oils"
    if _has(n, "bottle", "vial", "hourglass", "magnifying", "spyglass", "crystal", "orb", "lens", "flask"):
        return "glass"
    if _has(n, "rope", "blanket", "bedroll", "tent", "robe", "vestment", "sack", "string", "net", "basket",
            "cloak", "wrap"):
        return "cloth"
    if _has(n, "backpack", "pouch", "waterskin", "quiver", "case", "pack", "saddle", "bag", "kit", "snare"):
        return "leather"
    if _has(n, "barrel", "chest", "ladder", "pole", "staff", "wand", "rod", "totem", "abacus", "bucket", "ram",
            "crook", "beads", "token", "box", "scale", "dice", "card", "jug", "pitcher", "tankard", "cup"):
        return "wooden goods"
    if cat in ("Material",) and t & {"wood"}:
        return "wooden goods"
    if cat == "Material" and t & {"cloth"}:
        return "cloth"
    if cat == "Material" and t & {"metal"}:
        return "metal goods"
    if cat == "Material" and t & {"alchemical"}:
        return "potion"
    return "metal goods"


# ----------------------------------------------------------------------------------------------------
# The index of every item's recipe
# ----------------------------------------------------------------------------------------------------
class _Lookup:
    """What the automatic recipes pick from: materials by name, herbs, gems and parts by value, spell
    scrolls by spell, the mundane items magic ones are made from."""

    def __init__(self, world, items) -> None:
        self.world = world
        self.by_name = {i.name.lower(): i for i in items}
        self.by_tag: dict[str, list] = {}
        for i in items:
            for t in _tags(i):
                self.by_tag.setdefault(t, []).append(i)
        mats = [i for i in items if i.fields.get("category") == "Material"]
        self.herbs = sorted((i for i in mats if "herb" in _tags(i) and _value(i) > 0), key=lambda i: (_value(i), i.name))
        self.gems = sorted((i for i in items if "gem" in _tags(i) and _value(i) > 0), key=lambda i: (_value(i), i.name))
        self.parts = sorted((i for i in mats if "monster" in _tags(i) and _value(i) > 0),
                            key=lambda i: (_value(i), i.name))
        self.scrolls = {}
        for i in items:
            m = re.match(r"spell scroll \((.+)\)$", i.name.lower())
            if m:
                self.scrolls[m.group(1)] = i
        self._scroll_re = None
        if self.scrolls:
            names = sorted(self.scrolls, key=len, reverse=True)
            self._scroll_re = re.compile(r"\b(" + "|".join(re.escape(n) for n in names) + r")\b")
        mundane = [i for i in items if "magic" not in _tags(i) and (i.fields.get("category") or "") in
                   ("Weapon", "Armor", "Shield", "Ammunition") and not is_raw(world, i)]
        self.mundane = sorted(mundane, key=lambda i: -len(i.name))
        self.foci = sorted((i for i in items if "magic" not in _tags(i) and (i.fields.get("category") or "") == "Gear"
                            and " " not in i.name and "," not in i.name and not is_raw(world, i)
                            and i.name.lower() in FOCI), key=lambda i: -len(i.name))

    def item(self, name: str):
        return self.by_name.get(str(name).lower())

    def tag_value(self, tag: str) -> float:
        vals = [_value(i) for i in self.by_tag.get(tag, []) if is_raw(self.world, i) and _value(i) > 0]
        return min(vals) if vals else 0.05

    def base_for(self, item):
        """The mundane item a magic weapon or armor is made from."""
        cat = item.fields.get("category") or ""
        n = item.name.lower()
        if cat not in ("Weapon", "Armor", "Shield", "Ammunition"):
            for m in self.foci:
                if re.search(r"(^|[^a-z])" + re.escape(m.name.lower()) + r"($|[^a-z])", n):
                    return m
            return None
        for m in self.mundane:
            if m.id != item.id and (m.fields.get("category") or "") == cat and \
                    re.search(r"(^|[^a-z])" + re.escape(m.name.lower()) + r"($|[^a-z])", n):
                return m
        f = item.fields
        for m in self.mundane:
            mf = m.fields
            if (mf.get("category") or "") != cat:
                continue
            if cat == "Weapon" and mf.get("damage") == f.get("damage") and mf.get("weapon_kind") == f.get("weapon_kind"):
                return m
            if cat == "Armor" and mf.get("armor_type") == f.get("armor_type") and \
                    int(mf.get("armor_class") or 0) == int(f.get("armor_class") or 0):
                return m
            if cat in ("Shield", "Ammunition"):
                return m
        if cat == "Armor":
            same = [m for m in self.mundane if (m.fields.get("category") or "") == "Armor" and
                    m.fields.get("armor_type") == f.get("armor_type")]
            if same:
                return min(same, key=lambda m: abs(int(m.fields.get("armor_class") or 0) -
                                                   int(f.get("armor_class") or 0)))
        return None

    def spells_in(self, item) -> list:
        if self._scroll_re is None or item.name.lower().startswith("spell scroll"):
            return []
        found = []
        for m in self._scroll_re.finditer((item.description or "").lower()):
            s = self.scrolls.get(m.group(1))
            if s is not None and s not in found:
                found.append(s)
            if len(found) >= 2:
                break
        return found


def _count(budget: float, value: float) -> int:
    if value <= 0:
        return 1
    return max(1, min(MAX_COUNT, int(round(budget / value))))


def _pick_material(lk: _Lookup, name: str, budget: float):
    """(item, count) for a named material, stepping up to a better one when it would take too many."""
    item = lk.item(name)
    if item is None:
        return None, 0
    n = _count(budget, _value(item))
    while n > STEP_AT and name in STEP_UP and lk.item(STEP_UP[name]) is not None:
        name = STEP_UP[name]
        item = lk.item(name)
        n = _count(budget, _value(item))
    return item, n


def _hinted(text: str, table) -> list[str]:
    out = []
    for words, names in table:
        if any(w in text for w in words):
            out += names if isinstance(names, list) else [names]
    return out


def _pick_herb(lk: _Lookup, budget: float, text: str):
    for name in _hinted(text, HERB_HINTS):
        h = lk.item(name)
        if h is not None:
            return h, max(1, min(12, int(round(budget / max(_value(h), 0.01)))))
    if not lk.herbs:
        return None, 0
    ok = [h for h in lk.herbs if _value(h) * 2 <= budget] or lk.herbs[:1]
    h = ok[-1]
    return h, max(1, min(12, int(round(budget / _value(h)))))


def _pick_gem(lk: _Lookup, budget: float):
    ok = [g for g in lk.gems if _value(g) <= budget]
    if not ok:
        return None, 0
    g = ok[-1]
    return g, max(1, min(6, int(budget // _value(g))))


def _pick_part(lk: _Lookup, budget: float, text: str = ""):
    for name in _hinted(text, EFFECT_PARTS):
        p = lk.item(name)
        if p is not None and _value(p) <= max(budget, _value(p) if budget >= 20 else 0):
            return p, max(1, min(6, int(budget // max(_value(p), 0.01))))
    ok = [p for p in lk.parts if _value(p) <= budget]
    if not ok:
        return None, 0
    p = ok[-1]
    return p, max(1, min(6, int(budget // _value(p))))


def _meal_materials(lk: _Lookup, item) -> list[tuple[str, float]]:
    n = item.name.lower()
    if _has(n, "cheese", "butter", "kumis"):
        return [("Pail of Milk", 0.9), ("Pouch of Salt", 0.1)]
    if _has(n, "fish", "herring", "cod", "trout"):
        return [("tag:fish", 0.8), ("Pouch of Salt", 0.2)]
    if _has(n, "sausage", "pork", "jerky", "mutton", "meat", "broth"):
        return [("Game Meat", 0.8), ("Pouch of Salt", 0.2)]
    if _has(n, "stew", "pie", "rations"):
        return [("Game Meat", 0.5), ("Sack of Flour", 0.3), ("Field Mushrooms", 0.2)]
    if _has(n, "rice"):
        return [("Sack of Rice", 1.0)]
    if _has(n, "honey", "cake"):
        return [("Sack of Flour", 0.6), ("tag:berry", 0.4)]
    if _has(n, "cider"):
        return [("Sack of Apples", 1.0)]
    if _has(n, "wine", "mead"):
        return [("tag:berry", 0.8), ("tag:grain", 0.2)]
    if _has(n, "tea"):
        return [("Brick of Tea", 1.0)]
    if _has(n, "stout", "ale", "beer", "frostwine", "spirit"):
        return [("Wild Barley", 1.0)]
    if "drink" in _tags(item):
        return [("tag:grain", 1.0)]
    return [("Sack of Flour", 0.8), ("Pouch of Salt", 0.2)]


def _ref_value(lk: _Lookup, ref: str) -> float:
    if ref.startswith("tag:"):
        return lk.tag_value(ref[4:])
    it = lk.item(ref)
    return _value(it) if it is not None else 0.0


def _ref_id(lk: _Lookup, ref: str) -> str | None:
    if ref.startswith("tag:"):
        return ref if lk.by_tag.get(ref[4:]) else None
    it = lk.item(ref)
    return it.id if it is not None else None


def _stackable(item) -> bool:
    return bool(item.fields.get("stackable")) or (item.fields.get("category") or "") in (
        "Ammunition", "Consumable", "Material")


def auto_recipe(world, item, lk: _Lookup | None = None) -> dict | None:
    """The recipe worked out from what the item is (None for a raw material)."""
    if item is None or is_raw(world, item):
        return None
    lk = lk or _Lookup(world, world.entities.all("item"))
    table = kinds(world)
    if item.name in BASE:
        st, mats, makes, tools = BASE[item.name]
        out = []
        for ref, n in mats:
            rid = _ref_id(lk, ref)
            if rid is not None:
                out.append([rid, n])
        kind = {"forge": "metal goods", "carpenter's bench": "wooden goods", "tannery": "leather", "loom": "cloth",
                "kitchen": "meal", "scribe's desk": "book", "alchemy lab": "potion"}.get(st, "metal goods")
        if tools:
            kind = "glass"
        return _finish(world, item, {"kind": kind, "stations": [st], "tools": tools or table.get(kind, {}).get(
            "tools") or STATIONS[st]["tools"], "materials": out, "makes": makes}, magic=False)
    kind = kind_of(world, item)
    spec = table.get(kind) or table["metal goods"]
    tags = _tags(item)
    magic = "magic" in tags and (item.fields.get("rarity") or "Common") != "" and not item.name.lower().startswith(
        "spell scroll")
    value = _value(item)
    rarity = item.fields.get("rarity") or "Common"
    text = _text(item)
    for fid in item.fields.get("features") or []:
        feat = world.entities.get(fid)
        if feat is not None:
            text += " " + _text(feat) + " " + " ".join(str(e.get("effect", "")) + " " + str(e.get("detail", ""))
                                                       for e in feat.fields.get("effects") or [])
    mats: list[list] = []
    base = lk.base_for(item) if magic else None
    if base is not None:
        mats.append([base.id, 1])
        kind = kind_of(world, base) or kind
        spec = table.get(kind) or spec
    else:
        budget = value / 2.0
        if magic:                                         # no base: its kind's materials, as for a fine one
            budget = min(budget, 5.0)
        rows = spec.get("materials") or []
        if kind in ("meal", "drink"):
            rows = _meal_materials(lk, item)
        for name, share in rows:
            if isinstance(share, str) and share.startswith("="):       # a fixed count ("=1": one vial)
                got = lk.item(name) if not str(name).startswith("tag:") else None
                if got is not None and got.id != item.id:
                    mats.append([got.id, max(1, int(share[1:] or 1))])
                elif str(name).startswith("tag:") and _ref_id(lk, name):
                    mats.append([name, max(1, int(share[1:] or 1))])
                continue
            b = budget * float(share)
            if name == "herb":
                got, n = _pick_herb(lk, b, text)
            elif name == "gem":
                got, n = _pick_gem(lk, b)
            elif name == "part":
                got, n = _pick_part(lk, b, text)
            elif str(name).startswith("tag:"):
                rid = _ref_id(lk, name)
                if rid is not None:
                    mats.append([rid, _count(b, lk.tag_value(name[4:]))])
                continue
            else:
                got, n = _pick_material(lk, name, b)
            if got is not None and got.id != item.id:
                mats.append([got.id, n])
    if magic:
        found = []
        for words, names in EFFECT_PARTS:
            if any(w in text for w in words):
                for nm in names:
                    p = lk.item(nm)
                    if p is not None and p not in found:
                        found.append(p)
                        break
        want = PART_KINDS.get(rarity, 1)
        d = lk.item(DEFAULT_PART.get(rarity, "Owlbear Feathers"))
        if len(found) < want and d is not None and d not in found:
            found.append(d)
        for p in found[:want]:
            mats.append([p.id, PART_COUNT.get(rarity, 1)])
        for s in lk.spells_in(item):
            mats.append([s.id, 1])
        for word, metal, k in (("mithral", "Mithral Ingot", 4), ("adamantine", "Mithral Ingot", 6)):
            if word in item.name.lower() and lk.item(metal) is not None:
                mats.append([lk.item(metal).id, k])
    if not mats:                                          # nothing fitted: a little of the kind's first material
        first = (spec.get("materials") or [["Iron Ingot", 1]])[0][0]
        it = lk.item(first if first not in ("herb", "gem", "part") else "Iron Ingot")
        if it is not None and it.id != item.id:
            mats.append([it.id, 1])
    mats = _merge(mats)
    makes = 1
    if not magic and (_stackable(item) or value < 1) and value > 0:
        cost = sum(n * _ref_value(lk, ref if ref.startswith("tag:") else (world.entities.get(ref).name
                                                                         if world.entities.get(ref) else ref))
                   for ref, n in mats)
        makes = max(1, min(MAX_MAKES, int(round(cost / (value / 2.0))))) if cost > value else 1
    return _finish(world, item, {"kind": kind, "stations": list(spec.get("stations") or ["forge"]),
                                 "tools": list(spec.get("tools") or []), "materials": mats, "makes": makes},
                   magic=magic, base=base)


def _merge(mats: list) -> list:
    out: dict = {}
    for ref, n in mats:
        out[ref] = out.get(ref, 0) + int(n)
    return [[k, v] for k, v in out.items()]


def _finish(world, item, r: dict, magic: bool = False, base=None) -> dict:
    rarity = item.fields.get("rarity") or "Common"
    value = _value(item)
    if magic:
        consumable = (item.fields.get("category") or "") == "Consumable" or "potion" in _tags(item) or \
            "scroll" in _tags(item)
        days = (_rules(world).get("potion_days") if consumable else _rules(world).get("magic_days")) or (
            POTION_DAYS if consumable else MAGIC_DAYS)
        work = float(days.get(rarity, 10)) * pace(world)
    else:
        work = value * max(1, int(r.get("makes") or 1))
    r.update(item=item.id, work=round(max(0.05, work), 3), dc=dc_for(item), auto=True,
             stat=station_info(world, (r.get("stations") or ["forge"])[0]).get("stat", "int"))
    return r


def dc_for(item) -> int:
    rarity = item.fields.get("rarity") or "Common"
    if "magic" in _tags(item) or rarity not in ("", "Common"):
        return RARITY_DC.get(rarity, 15)
    v = _value(item)
    return 10 if v < 10 else 12 if v < 100 else 15 if v < 1000 else 18


def _build_auto(world, items) -> dict:
    lk = _Lookup(world, items)
    out = {}
    for i in items:
        r = auto_recipe(world, i, lk)
        if r is not None:
            out[i.id] = r
    return out


def _own_recipe(world, item, raw: dict) -> dict | None:
    """A hand-set recipe (a Recipe entity's fields, or an item's own "recipe" field) made whole."""
    if not raw or not (raw.get("materials") or []):
        return None
    mats = []
    for row in raw.get("materials") or []:
        if isinstance(row, dict):
            ref, n = row.get("item") or "", row.get("count") or 1
        else:
            ref, n = row[0], row[1]
        if ref and (str(ref).startswith("tag:") or world.entities.get(ref) is not None):
            mats.append([ref, max(1, int(n or 1))])
    if not mats:
        return None
    st = raw.get("station") or (raw.get("stations") or [""])[0] or "forge"
    tool = raw.get("tool") or ""
    tool_ent = world.entities.get(tool) if tool else None
    r = {"item": item.id, "makes": max(1, int(raw.get("makes") or 1)), "stations": [st],
         "tools": [tool_ent.name] if tool_ent is not None else (raw.get("tools") or STATIONS.get(st, {}).get("tools", [])),
         "materials": mats, "kind": raw.get("kind") or "own", "auto": False,
         "stat": station_info(world, st).get("stat", "int")}
    work = float(raw.get("work") or 0) or _value(item) * r["makes"]
    r["work"] = round(max(0.05, work), 3)
    r["dc"] = int(raw.get("dc") or 0) or dc_for(item)
    return r


def recipes(world) -> dict:
    """item id -> recipe, for every item that can be made."""
    auto = world.entities.custom_index("item", "crafting", lambda items: _build_auto(world, items))
    own = world.entities.custom_index("recipe", "crafting", lambda rs: {
        (r.fields.get("item") or ""): r for r in rs if r.fields.get("item")})
    has_own_field = world.entities.custom_index("item", "crafting-own", lambda items: [
        i.id for i in items if (i.fields.get("recipe") or {}).get("materials")])
    if not own and not has_own_field:
        return auto
    out = dict(auto)
    for iid in has_own_field:
        item = world.entities.get(iid)
        r = _own_recipe(world, item, item.fields.get("recipe") or {}) if item is not None else None
        if r is not None:
            out[iid] = r
    for iid, ent in own.items():
        item = world.entities.get(iid)
        if item is None:
            continue
        r = _own_recipe(world, item, dict(ent.fields, station=ent.fields.get("station") or "forge"))
        if r is not None:
            r["recipe_entity"] = ent.id
            out[iid] = r
    return out


def recipe_for(world, item_id: str) -> dict | None:
    from game import quality
    return recipes(world).get(quality.base_of(item_id))


def recipe_from_values(world, values: dict) -> dict | None:
    """The automatic recipe for an item that isn't saved yet (the item editor, as it's filled in)."""
    from game.entities import Entity
    e = Entity("item._new", "item", values.get("name") or "New item", values.get("description") or "",
               list(values.get("tags") or []), {k: v for k, v in values.items() if k not in ("name", "description",
                                                                                          "tags")}, [], "", "")
    own = _own_recipe(world, e, values.get("recipe") or {})
    return own or auto_recipe(world, e)


# ----------------------------------------------------------------------------------------------------
# Raw materials and where they come from
# ----------------------------------------------------------------------------------------------------
def sources(world) -> dict[str, list[str]]:
    """raw item id -> how it's got ("gathered", "skinned", "sold by Blacksmiths"...)."""
    from game import gathering as GA
    from game import trade
    from game.constants import OCCUPATIONS
    out: dict[str, list[str]] = {}

    def add(name, how):
        e = world.entities.find_by_name("item", name)
        if e is not None:
            out.setdefault(e.id, []).append(how)
    for table in GA.drops_table(world).values():
        for rows in table.values():
            for row in rows:
                add(row[0], "gathered")
    for n in GA.ORE_BY_VARIANT + ["Mithral Ore"] + list(getattr(GA, "RICH_EXTRA", [])):
        add(n, "mined")
    for _k, n in GA.HIDES:
        add(n, "skinned")
    for n in getattr(GA, "SKIN_EXTRA", []):
        add(n, "skinned")
    for i in world.entities.all("item"):
        tags = trade.item_tags(i)
        for occ, sells in OCCUPATIONS.items():
            if sells and tags & set(sells) and (i.fields.get("rarity") or "Common") in trade.GOOD_RARITIES:
                out.setdefault(i.id, []).append(f"sold by {occ.lower()}s")
                break
    for e in world.entities.all("enemy"):
        for row in e.fields.get("loot") or []:
            iid = row.get("item") if isinstance(row, dict) else row
            if iid:
                out.setdefault(iid, []).append("looted")
    return out


def resolve(world, item_id: str, depth: int = 0, seen: frozenset = frozenset()) -> set[str]:
    """The raw materials a recipe comes down to (raises ValueError on a loop or a dead end)."""
    from game import quality
    item_id = quality.base_of(item_id)
    item = world.entities.get(item_id)
    if item is None:
        raise ValueError(f"no such item {item_id}")
    if is_raw(world, item):
        return {item_id}
    if item_id in seen or depth > 12:
        raise ValueError(f"loop through {item.name}")
    r = recipes(world).get(item_id)
    if r is None:
        raise ValueError(f"no recipe for {item.name}")
    out: set[str] = set()
    for ref, _n in r["materials"]:
        if ref.startswith("tag:"):
            out.add(ref)
            continue
        out |= resolve(world, ref, depth + 1, seen | {item_id})
    return out


# ----------------------------------------------------------------------------------------------------
# Having what a recipe needs
# ----------------------------------------------------------------------------------------------------
def pool_of(world, state, members=None) -> dict[str, int]:
    """Everything the party holds: the pack and each member's own bag (item id -> count)."""
    pool = dict(state.inventory or {}) if state is not None else {}
    for m in members or []:
        for k, v in (m.get("inventory") or {}).items():
            pool[k] = pool.get(k, 0) + int(v)
    return {k: v for k, v in pool.items() if v > 0}


def _matches(world, ref: str, item_id: str) -> bool:
    from game import quality
    if ref.startswith("tag:"):
        it = world.entities.get(quality.base_of(item_id))
        return it is not None and ref[4:] in _tags(it)
    return quality.base_of(item_id) == ref and not quality.parse(item_id)[2]


def _take(world, pool: dict, ref: str, n: int) -> list[tuple[str, int]] | None:
    """Take n of ref from a pool (virtually); the ids taken, or None if there isn't enough."""
    got = []
    need = n
    for iid in sorted(pool, key=lambda k: (k != ref, k)):
        if need <= 0:
            break
        if pool[iid] <= 0 or not _matches(world, ref, iid):
            continue
        k = min(pool[iid], need)
        pool[iid] -= k
        need -= k
        got.append((iid, k))
    if need > 0:
        for iid, k in got:
            pool[iid] += k
        return None
    return got


def can_make(world, recipe: dict, pool: dict, batches: int = 1, depth: int = 1, rs: dict | None = None) -> bool:
    """Is there enough in the pool for this many batches, counting what it could make on the way (to
    `depth` steps)? Takes from the pool as it goes (pass a copy)."""
    rs = rs if rs is not None else recipes(world)
    for ref, n in recipe["materials"]:
        need = int(n) * batches
        if _take(world, pool, ref, need) is not None:
            continue
        if depth <= 0 or ref.startswith("tag:") or ref not in rs:
            return False
        have = sum(v for k, v in pool.items() if _matches(world, ref, k))
        _take(world, pool, ref, have)
        sub = rs[ref]
        more = math.ceil((need - have) / max(1, int(sub.get("makes") or 1)))
        if not can_make(world, sub, pool, more, depth - 1, rs):
            return False
    return True


def missing(world, recipe: dict, pool: dict, batches: int = 1) -> list[tuple[str, int, int]]:
    """[(material ref, have, need)] for what's short (counting only what's held)."""
    out = []
    for ref, n in recipe["materials"]:
        need = int(n) * batches
        have = sum(v for k, v in pool.items() if _matches(world, ref, k))
        if have < need:
            out.append((ref, have, need))
    return out


def ref_name(world, ref: str) -> str:
    if ref.startswith("tag:"):
        return "any " + {"hide": "hide", "log": "log", "fish": "fish", "grain": "grain", "berry": "berries"}.get(
            ref[4:], ref[4:])
    e = world.entities.get(ref)
    return e.name if e is not None else ref


def _leaves(rs: dict, item_id: str, depth: int = 2) -> set[str]:
    r = rs.get(item_id)
    if r is None:
        return set()
    out = set()
    for ref, _n in r["materials"]:
        out.add(ref)
        if depth > 0 and ref in rs:
            out |= _leaves(rs, ref, depth - 1)
    return out


def _uses_index(world) -> dict[str, list[str]]:
    """material ref -> the recipes it goes into (two steps down), for learning."""
    def build(_items):
        rs = recipes(world)
        idx: dict[str, list[str]] = {}
        for iid in rs:
            for ref in _leaves(rs, iid):
                idx.setdefault(ref, []).append(iid)
        return idx
    return world.entities.custom_index("item", "crafting-uses", build)


def learn(world, state, members=None, changed: list[str] | None = None, bus=None) -> list[str]:
    """Learn every recipe the party now has everything for. changed: the items just got (only the
    recipes using them are looked at); None looks at all. Returns the item ids newly learned."""
    from game import quality
    known = set(state.recipes or [])
    rs = recipes(world)
    if changed is None:
        cands = [i for i in rs if i not in known]
    else:
        idx = _uses_index(world)
        cands = []
        for iid in changed:
            base = quality.base_of(iid)
            it = world.entities.get(base)
            refs = [base] + ([f"tag:{t}" for t in _tags(it)] if it is not None else [])
            for ref in refs:
                cands += [c for c in idx.get(ref, []) if c not in known]
        cands = list(dict.fromkeys(cands))
    if not cands:
        return []
    pool = pool_of(world, state, members)
    new = []
    for iid in cands:
        if can_make(world, rs[iid], dict(pool), 1, 1, rs):
            new.append(iid)
    if new:
        state.recipes = list(state.recipes or []) + new
        state.save()
        if bus is not None:
            for iid in new:
                e = world.entities.get(iid)
                text = f"New recipe: {e.name if e else iid}"
                bus.emit("recipe.learned", item=iid, text=text)
                bus.emit("log", kind="loot", text=text + ".")
    return new


def known(world, state, station: str | None = None) -> list[str]:
    rs = recipes(world)
    out = [i for i in (state.recipes or []) if i in rs]
    if station:
        out = [i for i in out if station in rs[i]["stations"]]
    return out


# ----------------------------------------------------------------------------------------------------
# Taking materials
# ----------------------------------------------------------------------------------------------------
def consume(world, state, members, recipe: dict, batches: int = 1) -> list[list]:
    """Take a recipe's materials from the pack (then the members' bags). Returns what was taken [[id, n]],
    or raises ValueError if there isn't enough."""
    from game import inventory
    pool = pool_of(world, state, members)
    plan = []
    for ref, n in recipe["materials"]:
        got = _take(world, pool, ref, int(n) * batches)
        if got is None:
            raise ValueError(f"not enough {ref_name(world, ref)}")
        plan += got
    taken = []
    for iid, k in plan:
        left = k
        got = state.remove_item(iid, left, reason="crafting")
        left -= got
        for m in members or []:
            if left <= 0:
                break
            left -= inventory.remove(m, iid, left)
        taken.append([iid, k - left])
    return taken


# ----------------------------------------------------------------------------------------------------
# Jobs (kept in the save's holdings)
# ----------------------------------------------------------------------------------------------------
def jobs(state) -> list[dict]:
    h = getattr(state, "holdings", None)
    if h is None:
        return []
    return [j for j in h.setdefault("jobs", []) if j.get("kind") == "craft"]


def rate(world, job: dict) -> float:
    """gp of work a day."""
    h = job.get("helpers") or {}
    return pace(world) * (1 + int(h.get("skilled", 0)) + int(h.get("untrained", 0)))


def wages(world, helpers: dict) -> float:
    r = _rules(world)
    return int(helpers.get("skilled", 0)) * float(r.get("wage_skilled", 2) or 2) + \
        int(helpers.get("untrained", 0)) * float(r.get("wage_untrained", 0.2) or 0.2)


def rent(world, station: str, owned: bool = False) -> float:
    if owned:
        return 0.0
    return float(station_info(world, station).get("rent", 1.0) or 0)


def days_for(world, recipe: dict, batches: int = 1, helpers: dict | None = None) -> float:
    return float(recipe["work"]) * batches / max(0.01, rate(world, {"helpers": helpers or {}}))


def start(world, state, members, item_id: str, station: str, where: str, crafter: str, batches: int = 1,
          helpers: dict | None = None, days_paid: float | None = None, owned: bool = False, bus=None) -> tuple[bool, str, dict | None]:
    """Begin a job at a station: take the materials and pay for the station and helpers. Returns (ok,
    message, job)."""
    r = recipe_for(world, item_id)
    if r is None:
        return False, "That can't be made.", None
    if station not in r["stations"]:
        return False, f"That isn't made at a {station_info(world, station)['label'].lower()}.", None
    helpers = {"skilled": int((helpers or {}).get("skilled", 0)), "untrained": int((helpers or {}).get("untrained", 0))}
    need_days = days_for(world, r, batches, helpers)
    days = need_days if days_paid is None else float(days_paid)
    days = max(days, min(need_days, 1.0))
    cost = int(round((rent(world, station, owned) + wages(world, helpers)) * math.ceil(days) * 100))
    if cost > state.copper:
        from game.state import money_text
        return False, f"That costs {money_text(cost)} for the station and helpers. You can't afford it.", None
    if not can_make(world, r, pool_of(world, state, members), batches, 0):
        short = missing(world, r, pool_of(world, state, members), batches)
        return False, "Missing: " + ", ".join(f"{ref_name(world, ref)} ({have}/{need})" for ref, have, need in short), None
    taken = consume(world, state, members, r, batches)
    if cost:
        state.add_copper(-cost, "station and helpers")
    now = state.minutes
    item = world.entities.get(r["item"])
    job = {"id": f"craft-{now}-{zlib.crc32((item_id + crafter).encode()) % 100000}", "kind": "craft",
           "item": r["item"], "batches": batches, "makes": int(r.get("makes") or 1), "work": float(r["work"]) * batches,
           "done": 0.0, "station": station, "where": where, "crafter": crafter, "helpers": helpers,
           "start": now, "last": now, "paid_until": now + int(math.ceil(days) * DAY) if not owned else None,
           "status": "working", "materials": taken, "tools": r.get("tools") or [], "stat": r.get("stat", "int"),
           "dc": int(r.get("dc") or 10), "name": item.name if item else item_id}
    state.holdings.setdefault("jobs", []).append(job)
    state.ticks.setdefault("crafting", now)               # the ticker counts from here on this save
    _save_holdings(world, state)
    if bus is not None:
        bus.emit("craft.started", job=job["id"], item=job["item"])
    return True, f"Work begins on {job['name']}" + (f" x{batches * job['makes']}" if batches * job["makes"] > 1 else "") + \
        f": about {_days_text(need_days)}.", job


def _days_text(days: float) -> str:
    if days < 1 / 24 * 1.5:
        return f"{max(1, int(round(days * 1440)))} minutes"
    if days < 1.5:
        return f"{days * 24:.0f} hours"
    return f"{days:.0f} days" if days < 10 else f"{days:.0f} days"


def progress(world, job: dict, now: int) -> float:
    """0..1 at the given minute (without changing the job)."""
    if job.get("status") == "ready":
        return 1.0
    until = now if job.get("paid_until") is None else min(now, int(job["paid_until"]))
    gp = float(job.get("done") or 0) + max(0, until - int(job.get("last") or job.get("start") or 0)) * rate(world, job) / DAY
    return max(0.0, min(1.0, gp / max(0.001, float(job["work"]))))


def time_left(world, job: dict, now: int) -> int:
    """Minutes of work left."""
    p = progress(world, job, now)
    return int(math.ceil((1 - p) * float(job["work"]) / max(0.01, rate(world, job)) * DAY))


def _catch_up(world, state, since: int, now: int) -> None:
    """The ticker: every job moves on (while its station is paid for); finished ones wait to be collected."""
    changed = False
    bus = getattr(state, "bus", None)
    for job in jobs(state):
        if job.get("status") != "working":
            continue
        p = progress(world, job, now)
        until = now if job.get("paid_until") is None else min(now, int(job["paid_until"]))
        job["done"] = round(min(float(job["work"]), p * float(job["work"])), 4)
        job["last"] = max(int(job.get("last") or 0), until)
        changed = True
        if p >= 1.0:
            job["status"] = "ready"
            job["finished_at"] = min(now, int(job["start"]) + 1 + int(math.ceil(
                float(job["work"]) / max(0.01, rate(world, job)) * DAY)))
            text = f"{job['name']} is finished: collect it at the {station_info(world, job['station'])['label'].lower()}."
            if bus is not None:
                bus.emit("craft.ready", job=job["id"], item=job["item"], text=text)
                bus.emit("log", kind="loot", text=text)
        elif job.get("paid_until") is not None and now >= int(job["paid_until"]):
            if not job.get("paused_said"):
                job["paused_said"] = True
                if bus is not None:
                    bus.emit("log", kind="narration", text=f"Work on {job['name']} has stopped: the "
                             f"{station_info(world, job['station'])['label'].lower()} is no longer paid for.")
    if changed:
        _save_holdings(world, state)


def _save_holdings(world, state) -> None:
    try:
        from game import holdings
        holdings.save(world, state)
    except Exception:  # noqa: BLE001 - a test state with no world folder
        pass


def pay_more(world, state, job: dict, days: int) -> tuple[bool, str]:
    cost = int(round((rent(world, job["station"]) + wages(world, job.get("helpers") or {})) * days * 100))
    if cost > state.copper:
        return False, "You can't afford that."
    _catch_up(world, state, state.minutes, state.minutes)
    base = max(state.minutes, int(job.get("paid_until") or state.minutes))
    if state.minutes > int(job.get("paid_until") or 0):
        job["last"] = state.minutes                      # nothing happened while it stood unpaid
    job["paid_until"] = base + days * DAY
    job.pop("paused_said", None)
    state.add_copper(-cost, "station and helpers")
    _save_holdings(world, state)
    return True, f"Paid for {days} more day{'s' if days != 1 else ''}."


def cancel(world, state, job: dict) -> str:
    """Stop a job: the materials come back (what's been worked is lost)."""
    for iid, n in job.get("materials") or []:
        state.add_item(iid, n, source="cancelled")
    state.holdings["jobs"] = [j for j in state.holdings.get("jobs", []) if j is not job and j.get("id") != job.get("id")]
    _save_holdings(world, state)
    return f"Work on {job['name']} stopped; the materials are back in the pack."


def quality_from(total: int, dc: int, natural: int | None) -> str:
    over = total - dc
    if over < 0:
        return "Poor"
    for need, q in QUALITY_STEPS:
        if over >= need:
            if q == "Legendary" and natural != 20:
                continue
            return q
    return "Standard"


def check_option(world, job_or_recipe: dict):
    """The check for the work: the first of the station's tools the world has as a skill, else its stat."""
    from game import checks
    opts = checks.options(world)
    for t in job_or_recipe.get("tools") or []:
        o = next((o for o in opts if o["label"].lower() == str(t).lower()), None)
        if o is not None:
            return o
    st = job_or_recipe.get("stat") or "int"
    return next((o for o in opts if o.get("stat") == st and o["kind"] == "Ability"), opts[0] if opts else None)


def collect(world, state, members, job: dict, rng: random.Random | None = None, bus=None) -> tuple[bool, str, str]:
    """Finish a ready job: the check (or its minigame) for its quality, the goods into the pack, and each
    day of work counted as a use of the tool. Returns (ok, message, item id made)."""
    from game import checks, condition, quality, tools
    if job.get("status") != "ready":
        return False, "It isn't finished yet.", ""
    rng = rng or random.Random()
    m = next((x for x in members or [] if x.get("id") == job.get("crafter")), None) or \
        next((x for x in members or [] if not x.get("dead")), None)
    item = world.entities.get(job["item"])
    count = int(job.get("batches") or 1) * int(job.get("makes") or 1)
    q = "Standard"
    text_check = ""
    if m is not None:
        c = condition.combatant(world, m)
        opt = check_option(world, job)
        mode = "advantage" if int((job.get("helpers") or {}).get("skilled", 0)) > 0 else "normal"
        if opt is not None:
            r = checks.roll(world, m, c, opt, int(job.get("dc") or 10), mode=mode, rng=rng, bus=bus,
                            target=f"making {job['name'].lower()}", context="craft")
            if r.get("total") is None:                   # never used the tool: the station's stat, untrained
                opt = check_option(world, {"tools": [], "stat": job.get("stat") or "int"})
                r = checks.roll(world, m, c, opt, int(job.get("dc") or 10), mode=mode, rng=rng, bus=bus,
                                target=f"making {job['name'].lower()}", context="craft") if opt else {}
            if r.get("total") is not None:
                q = quality_from(int(r["total"]), int(job.get("dc") or 10), r.get("roll"))
                text_check = f" ({opt['label']} {r['total']} vs DC {job.get('dc')})"
        key = _tool_key(world, job)
        days = max(1, int(round(float(job["work"]) / max(0.01, rate(world, job)))))
        if key:
            tools.record_use(world, m, key, days, bus)
    made = job["item"]
    if item is not None and quality.can_vary(item):
        made = quality.variant(job["item"], q)
    state.add_item(made, count, source="crafted")
    state.holdings["jobs"] = [j for j in state.holdings.get("jobs", []) if j.get("id") != job.get("id")]
    _save_holdings(world, state)
    name = world.entities.get(made).name if world.entities.get(made) else job["name"]
    msg = f"Made: {name}" + (f" x{count}" if count > 1 else "") + text_check + "."
    if bus is not None:
        bus.emit("craft.done", item=made, count=count, quality=q)
        bus.emit("log", kind="loot", text=msg)
    return True, msg, made


def _tool_key(world, job: dict) -> str:
    for t in job.get("tools") or []:
        sk = world.entities.find_by_name("skill", t)
        if sk is not None:
            return sk.id
    return ""


def ready_jobs(state, where: str | None = None) -> list[dict]:
    return [j for j in jobs(state) if j.get("status") == "ready" and (where is None or j.get("where") == where)]


def jobs_at(state, where: str) -> list[dict]:
    return [j for j in jobs(state) if j.get("where") == where]


# ----------------------------------------------------------------------------------------------------
# Restoring and salvage
# ----------------------------------------------------------------------------------------------------
RESTORE_SHARE = 0.25
SALVAGE_SHARE = 0.5


def restore_recipe(world, item_id: str) -> dict | None:
    """Mending a damaged item: a quarter of its materials and a quarter of the work."""
    from game import quality
    base, q, damaged = quality.parse(item_id)
    if not damaged:
        return None
    r = recipe_for(world, base)
    if r is None:
        return None
    mats = []
    for ref, n in r["materials"]:
        if ref == base or (world.entities.get(ref) is not None and "magic" not in _tags(world.entities.get(ref))
                           and len(r["materials"]) > 1 and ref == r["materials"][0][0] and _is_base_item(world, r, ref)):
            continue                                      # (not a whole new base item)
        k = int(math.ceil(int(n) * RESTORE_SHARE / max(1, int(r.get("makes") or 1))))
        if k > 0:
            mats.append([ref, k])
    if not mats:
        mats = [[r["materials"][0][0], 1]]
    out = dict(r, materials=mats, work=round(float(r["work"]) * RESTORE_SHARE / max(1, int(r.get("makes") or 1)), 3),
               makes=1, restore=item_id)
    return out


def _is_base_item(world, r: dict, ref: str) -> bool:
    e = world.entities.get(ref)
    return e is not None and (e.fields.get("category") or "") in ("Weapon", "Armor", "Shield", "Ammunition")


def restore(world, state, members, item_id: str, bus=None) -> tuple[bool, str]:
    """Mend a damaged item with materials (done on the spot at a station: a short piece of work)."""
    from game import quality
    r = restore_recipe(world, item_id)
    if r is None:
        return False, "That doesn't need mending."
    pool = pool_of(world, state, members)
    if not can_make(world, r, pool, 1, 0):
        short = missing(world, r, pool_of(world, state, members))
        return False, "Missing: " + ", ".join(f"{ref_name(world, ref)} ({have}/{need})" for ref, have, need in short)
    if state.count(item_id) <= 0:
        return False, "Put it in the party's pack first."
    consume(world, state, members, r)
    base, q, _d = quality.parse(item_id)
    state.remove_item(item_id, 1, reason="restored")
    whole = quality.variant(base, q, False)
    state.add_item(whole, 1, source="restored")
    minutes = max(10, int(float(r["work"]) / pace(world) * DAY))
    state.advance(minutes, "mending")
    e = world.entities.get(whole)
    return True, f"{e.name if e else whole} is as good as new ({_days_text(minutes / DAY)} of work)."


def salvage_yield(world, item_id: str) -> list[list]:
    """What breaking an item down gives back: about half its materials (at least one of something)."""
    r = recipe_for(world, item_id)
    if r is None:
        return []
    out = []
    makes = max(1, int(r.get("makes") or 1))
    for ref, n in r["materials"]:
        k = int(int(n) * SALVAGE_SHARE / makes)
        if ref.startswith("tag:"):
            cands = [i for i in world.entities.all("item") if ref[4:] in _tags(i) and is_raw(world, i)]
            if not cands:
                continue
            ref = min(cands, key=lambda i: (_value(i), i.name)).id
        if k > 0:
            out.append([ref, k])
    if not out and r["materials"] and makes == 1:
        ref = r["materials"][0][0]
        if not ref.startswith("tag:"):
            out.append([ref, 1])
    return out


def salvage(world, state, item_id: str, n: int = 1, bus=None) -> tuple[bool, str]:
    from game import trade
    if trade.locked(world, state, item_id):
        return False, "You need that for a quest."
    got = salvage_yield(world, item_id)
    if not got:
        return False, "Nothing worth keeping would come of breaking that down."
    if state.count(item_id) < n:
        return False, "You don't have that."
    state.remove_item(item_id, n, reason="salvaged")
    lines = []
    for ref, k in got:
        state.add_item(ref, k * n, source="salvage")
        e = world.entities.get(ref)
        lines.append(f"{e.name if e else ref} x{k * n}")
    state.advance(max(10, 10 * n), "salvaging")
    e = world.entities.get(item_id)
    return True, f"Broke down {e.name if e else item_id}" + (f" x{n}" if n > 1 else "") + ": " + ", ".join(lines) + "."


# ----------------------------------------------------------------------------------------------------
# Stations in towns
# ----------------------------------------------------------------------------------------------------
def building_stations(world, b) -> list[str]:
    """The crafting stations a building has: its facilities if set, else what its kind and its people's
    trades call for."""
    fac = [FACILITY_STATION[f] for f in (b.fields.get("facilities") or []) if f in FACILITY_STATION]
    if fac:
        return list(dict.fromkeys(fac))
    out = list(KIND_STATIONS.get(b.fields.get("kind") or "", []))
    if (b.fields.get("kind") or "") in ("Shop", "Smithy", "Workshop", "Guild hall", "Market"):
        owner = world.entities.get(b.fields.get("owner") or "") if b.fields.get("owner") else None
        occs = set()
        for n in _workers(world, b):
            occs.add(n.fields.get("occupation") or "")
        if owner is not None and owner.type == "npc":
            occs.add(owner.fields.get("occupation") or "")
        for occ in sorted(occs):
            out += TRADE_STATIONS.get(occ, [])
    return list(dict.fromkeys(out))


def _workers(world, b) -> list:
    return sorted(world.entities.by_field("npc", "building", b.id), key=lambda n: n.name.lower())


def rents_out(b) -> bool:
    """Town smithies, workshops, alchemists and the rest rent their stations by the day (not homes)."""
    return not b.fields.get("owner") or (b.fields.get("kind") or "") != "House"


# ----------------------------------------------------------------------------------------------------
# NPCs at work
# ----------------------------------------------------------------------------------------------------
def trade_products(world, occupation: str) -> list[str]:
    """What someone of this trade makes or brings in at work (item ids), cached per world."""
    def build(_items):
        rs = recipes(world)
        out: dict[str, list[str]] = {}
        for occ, ks in TRADE_KINDS.items():
            lst = []
            for iid, r in rs.items():
                it = world.entities.get(iid)
                if it is None or "magic" in _tags(it) or r.get("kind") not in ks:
                    continue
                if (it.fields.get("rarity") or "Common") not in ("", "Common"):
                    continue
                if float(r["work"]) > NPC_MAX_VALUE or float(r["work"]) <= 0:
                    continue
                lst.append(iid)
            out[occ] = sorted(lst)
        for occ, names in TRADE_HARVEST.items():
            out[occ] = [e.id for e in (world.entities.find_by_name("item", n) for n in names) if e is not None]
        return out
    return world.entities.custom_index("item", "crafting-trades", build).get(occupation or "", [])


def _npc_product(world, npc, n: int):
    """The n-th thing this person makes (the same in every save): (item id, minutes it takes, count)."""
    prods = trade_products(world, npc.fields.get("occupation") or "")
    if not prods:
        return None
    iid = _rng("npcwork", npc.id, n).choice(prods)
    rs = recipes(world)
    r = rs.get(iid)
    it = world.entities.get(iid)
    if r is not None:
        work = float(r["work"])
        makes = int(r.get("makes") or 1)
    else:                                                # harvested: a morning's work for a few
        work = max(0.5, _value(it) * 6) if it is not None else 1.0
        makes = 3
    minutes = max(30, int(work / pace(world) * DAY))
    return iid, minutes, makes


def npc_work(world, state, npc, now: int | None = None) -> dict | None:
    """What a working NPC is making and how far along it is, caught up to now: finished pieces go into their
    shop's stock. {"item", "progress" 0..1, "start", "minutes"}; None for those who don't make things."""
    if npc is None or not trade_products(world, npc.fields.get("occupation") or ""):
        return None
    now = int(state.minutes if now is None else now)
    mem = state.npc(npc.id)
    w = mem.get("work")
    if not w:
        prod = _npc_product(world, npc, 0)
        if prod is None:
            return None
        rng = _rng("npcstart", npc.id)
        w = {"n": 0, "item": prod[0], "minutes": prod[1], "makes": prod[2],
             "start": now - int(rng.random() * prod[1])}
        mem["work"] = w
    done = 0
    while now >= int(w["start"]) + int(w["minutes"]) and done < 40:
        finish = int(w["start"]) + int(w["minutes"])
        _to_stock(world, state, npc, w["item"], int(w.get("makes") or 1))
        n = int(w["n"]) + 1
        prod = _npc_product(world, npc, n)
        if prod is None:
            break
        w.update(n=n, item=prod[0], minutes=prod[1], makes=prod[2], start=finish)
        done += 1
    if done >= 40:                                        # away a long time: start afresh
        w["start"] = now - int(w["minutes"]) // 3
    mem["work"] = w
    p = (now - int(w["start"])) / max(1, int(w["minutes"]))
    return {"item": w["item"], "progress": max(0.0, min(1.0, p)), "start": int(w["start"]), "minutes": int(w["minutes"])}


def _to_stock(world, state, npc, item_id: str, n: int) -> None:
    """A finished piece goes on sale (if the person sells things), up to the shop's cap."""
    from game import trade
    if not trade.is_merchant(world, npc) and not (npc.fields.get("building")):
        return
    mem = state.npc(npc.id)
    stock = mem.get("stock")
    if stock is None:
        return                                            # stocked the first time someone trades there
    stock[item_id] = min(NPC_STOCK_CAP, int(stock.get(item_id, 0)) + n)
    made = mem.setdefault("made", {})
    made[item_id] = made.get(item_id, 0) + n


def bar_for(world, state, npc, seen_key: str | None = None) -> float | None:
    """The work bar over someone at work: how far along their piece is at the clock's time (it only moves
    when the clock does, and catches up when they come back into sight). Notes when they were seen."""
    from game import ticker
    w = npc_work(world, state, npc)
    if w is None:
        return None
    ticker.mark_seen(state, seen_key or f"work:{npc.id}")
    return w["progress"]


# ----------------------------------------------------------------------------------------------------
# The ticker
# ----------------------------------------------------------------------------------------------------
def _register() -> None:
    from game import ticker
    ticker.register("crafting", _catch_up)


_register()

__all__ = ["recipes", "recipe_for", "auto_recipe", "recipe_from_values", "kind_of", "is_raw", "resolve", "sources",
           "learn", "known", "start", "progress", "collect", "cancel", "pay_more", "restore", "restore_recipe",
           "salvage", "salvage_yield", "building_stations", "npc_work", "bar_for", "STATIONS", "KINDS", "BASE",
           "can_make", "missing", "pool_of", "jobs", "jobs_at", "ready_jobs", "station_info", "days_for",
           "ref_name", "trade_products", "quality_from", "time_left"]
