"""What the walking map lays over the land: the colour of the hour, the dark with soft holes cut by every
light, the weather's haze, its rain, snow and dust, and lightning.

Everything is worked out here, as plain numbers and bytes, so the Qt view (ui/explore_view.py) only has to
draw it, and tests and previews can draw it the same way without Qt.

    overlay(...)    -> (dark RGBA bytes, glow RGBA bytes, width, height) at RES pixels per square, to be
                       stretched smoothly over the squares it covers (that gives the soft edges)
    lights_in(...)  -> the light sources in a part of the map (lamps, braziers, forges, lit windows...)
    particles(...)  -> the rain, snow or dust to draw this frame
    flash(...)      -> how bright a lightning flash is right now (0 most of the time)
"""
from __future__ import annotations

import math
import zlib

from game import calendar as CAL
from game.combat import lighting as LT

RES = 2                                   # overlay pixels per square
GLOW_ALPHA = 46                           # how warm the light near a fire looks
DUNGEON_DARK = (0, 0, 0, 178)


def _hex(c: str) -> tuple[int, int, int]:
    c = c.lstrip("#")
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def tint_for(minutes: int, weather=None, kind: str = "world") -> tuple[int, int, int, int]:
    """The colour over the land: the hour's (dawn pink, dusk orange, night blue-black), darkened by clouds,
    lightened by the moon. A dungeon is always dark."""
    if kind == "dungeon":
        return DUNGEON_DARK
    r, g, b, a = CAL.sky_tint(minutes)
    cloudy = bool(weather is not None and weather.cloudy)
    if CAL.phase(minutes) == "Night" and not cloudy:
        a = int(a * (1 - 0.3 * CAL.moonlight(minutes)))     # moonlight
    dim = float(getattr(weather, "dim", 0.0) or 0.0) if weather is not None else 0.0
    if dim:
        storm = (52, 58, 72, int(dim * 150))
        if a < storm[3]:                                     # clouds over the day: grey
            k = a / max(1, storm[3])
            r, g, b = (int(storm[i] * (1 - k) + (r, g, b)[i] * k) for i in range(3))
            a = storm[3]
        else:
            a = min(235, int(a + dim * 40))
    return int(r), int(g), int(b), int(a)


def haze_for(weather, minutes: int) -> tuple[int, int, int, int]:
    """Fog, dust or driving snow over everything: as pale as the day allows (dark grey at night)."""
    if weather is None or not weather.haze[3]:
        return (0, 0, 0, 0)
    r, g, b, a = weather.haze
    k = 0.3 + 0.7 * CAL.daylight(minutes)
    return int(r * k), int(g * k), int(b * k), int(a * (0.6 + 0.4 * k))


def lights_in(area, level: str, x0: int, y0: int, x1: int, y1: int, minutes: int, lit_windows: bool = True,
              pad: int = 8) -> list[tuple]:
    """Light sources in (and a little round) a rectangle of squares: (x, y, bright, dim, colour). Props that
    burn (game/combat/lighting.py PROP_LIGHTS) and, at dusk and night, most windows."""
    out = []
    seen = set()
    night = CAL.phase(minutes) in ("Dusk", "Night", "Dawn") and lit_windows
    for y in range(max(0, y0 - pad), min(area.h, y1 + pad)):
        for x in range(max(0, x0 - pad), min(area.w, x1 + pad)):
            lv = area.layer(level, x, y)
            p = lv.prop_cells.get((x, y))
            if p is not None and p.id in LT.PROP_LIGHTS and id(p) not in seen:
                seen.add(id(p))
                b, d, col, _fl = LT.PROP_LIGHTS[p.id]
                pd = p.defn
                out.append((p.x + pd.w / 2, p.y + pd.h / 2, b, d, col))
            if night and (x, y) in lv.windows and zlib.crc32(f"{x},{y}".encode()) % 10 < 7:
                b, d, col, _fl = LT.WINDOW_LIGHT
                out.append((x + 0.5, y + 0.5, b, d, col))
    return out


def overlay(x0: int, y0: int, w: int, h: int, tint: tuple, lights: list[tuple]) -> tuple[bytes, bytes, int, int]:
    """The dark (tint with soft holes where the lights are) and the warm glow round the lights, for the
    squares x0..x0+w, y0..y0+h. Each is RGBA bytes, RES pixels to a square."""
    W, H = w * RES, h * RES
    r, g, b, a = tint
    n = W * H
    dark = bytearray(bytes((r, g, b, a)) * n)
    glow = bytearray(n * 4)
    if a <= 0 or not lights:
        return bytes(dark), bytes(glow), W, H
    lit: dict[int, float] = {}
    warm: dict[int, tuple] = {}
    inv = 1.0 / RES
    for (sx, sy, br, dm, col) in lights:
        reach = br + dm + 1.0
        px0 = max(0, int((sx - reach - x0) * RES))
        px1 = min(W, int(math.ceil((sx + reach - x0) * RES)))
        py0 = max(0, int((sy - reach - y0) * RES))
        py1 = min(H, int(math.ceil((sy + reach - y0) * RES)))
        if px0 >= px1 or py0 >= py1:
            continue
        rgb = _hex(col)
        for py in range(py0, py1):
            dy = y0 + (py + 0.5) * inv - sy
            row = py * W
            for px in range(px0, px1):
                dx = x0 + (px + 0.5) * inv - sx
                d = math.sqrt(dx * dx + dy * dy)
                if d <= br:
                    v = 1.0
                elif d <= br + dm:
                    v = 1.0 - 0.6 * (d - br) / max(dm, 0.01)
                elif d <= reach:
                    v = 0.4 * (reach - d)
                else:
                    continue
                i = row + px
                if v > lit.get(i, 0.0):
                    lit[i] = v
                    warm[i] = rgb
    for i, v in lit.items():
        dark[i * 4 + 3] = int(a * (1.0 - v))
        cr, cg, cb = warm[i]
        j = i * 4
        glow[j], glow[j + 1], glow[j + 2], glow[j + 3] = cr, cg, cb, int(GLOW_ALPHA * v * v * min(1.0, a / 120))
    return bytes(dark), bytes(glow), W, H


# ----------------------------------------------------------------------------------------------------
# Particles and lightning
# ----------------------------------------------------------------------------------------------------
PARTICLE_STYLE = {                       # colour, width (pixels at zoom 1), length (pixels), speed (px/s)
    "rain": ((170, 196, 230, 150), 1, 14, (-120, 900)),
    "snow": ((245, 248, 255, 220), 2, 0, (-20, 70)),
    "dust": ((196, 152, 98, 150), 1, 22, (520, 60)),
    "wind": ((235, 240, 245, 70), 1, 34, (700, 40)),
}
MAX_PARTICLES = 260


def particles(kind: str, density: float, t: float, w: int, h: int, cam_x: float = 0.0, cam_y: float = 0.0,
              scale: float = 1.0) -> tuple[list[tuple[float, float, float, float]], tuple, float]:
    """This frame's particles over a view w x h pixels: ([(x1, y1, x2, y2)], colour, line width). Snow comes
    back as zero-length lines (dots). They're anchored to the land (cam_x, cam_y: the camera in pixels)."""
    style = PARTICLE_STYLE.get(kind)
    if style is None or density <= 0 or w <= 0 or h <= 0:
        return [], (0, 0, 0, 0), 1.0
    col, width, length, (vx, vy) = style
    n = int(MAX_PARTICLES * density * min(2.0, (w * h) / (1280 * 720)))
    out = []
    span_x, span_y = w + 60, h + 60
    for i in range(n):
        hsh = zlib.crc32(f"{kind}{i}".encode())
        bx, by = hsh % 10007 / 10007 * span_x, (hsh >> 13) % 9973 / 9973 * span_y
        sp = 0.75 + ((hsh >> 7) % 50) / 100.0
        x = (bx + vx * sp * t - cam_x) % span_x - 30
        y = (by + vy * sp * t - cam_y) % span_y - 30
        if kind == "snow":
            x += math.sin(t * 1.3 + i) * 6 * scale
            out.append((x, y, x + 0.01, y + 0.01))
        else:
            k = length * scale / math.hypot(vx, vy)
            out.append((x, y, x - vx * k, y - vy * k))
    return out, col, max(1.0, width * scale)


def flash(t: float, seed: int = 0) -> float:
    """Lightning: 0 most of the time; a bright flash every 7 to 18 seconds, fading over a third of a second
    (with a flicker)."""
    t = t % 600.0
    k = 0
    start = 0.0
    while True:
        gap = 7 + zlib.crc32(f"{seed}:{k}".encode()) % 1100 / 100.0
        if start + gap > t:
            break
        start += gap
        k += 1
    since = t - start
    if since > 0.45:
        return 0.0
    v = max(0.0, 1.0 - since / 0.45)
    if 0.08 < since < 0.14:                      # the flicker
        v *= 0.3
    return v


def flash_started(t0: float, t1: float, seed: int = 0) -> bool:
    """Did a flash start between two moments? (For the thunder.)"""
    return flash(t1, seed) > 0.9 and flash(t0, seed) < 0.9


__all__ = ["haze_for", "tint_for", "lights_in", "overlay", "particles", "flash", "flash_started", "RES"]
