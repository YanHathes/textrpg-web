"""The running game for one world: clock, party purse and pack, where the party is,
what NPCs remember, and quests.

Stored in <world>/state.json and written after every change, so progress is never
lost. (Named save slots come with the connection stage; they'll copy this file.)

Time is counted in minutes since the start: day 1, 08:00.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

FILE = "state.json"
FORMAT = 3

# Sections of the save the later systems fill in. They start empty, and old saves load with them empty.
SECTIONS = {
    "world_changes": dict,   # chunk -> square -> change: trees cut, veins dug, buildings placed (game/landchanges.py)
    "reputation": dict,      # faction id -> standing
    "dialogue": dict,        # conversation flags, what each NPC has told the party
    "tool_use": dict,        # member id -> tool -> uses; proficiencies earned that way
    "recipes": list,         # recipes learned
    "npc_seen": dict,        # what was last in view, and when (game/ticker.py)
    "chains": dict,          # quest chain progress
    "pin": dict,             # the pinned quest
    "rumors": list,          # rumors heard
    "lore": dict,            # books read, lore entries found, courses taken
    "taming": dict,          # animal -> successful checks so far
    "law": dict,             # crimes, bounties, jail time
    "arena": dict,           # tournament record
    "events": dict,          # festivals and raids seen
    "survival": dict,        # member id -> hunger, thirst, sleep, diseases, curses
    "destruction": dict,     # things battered and broken, ruins, fires (game/destruction.py, game/fire.py)
}
START_MINUTE = 8 * 60        # day 1 starts at 08:00
DAY = 24 * 60


def money_text(copper: int) -> str:
    """1234 -> '12 gp 3 sp 4 cp' (zero parts left out)."""
    copper = int(copper)
    if copper <= 0:
        return "0 gp"
    gp, rest = divmod(copper, 100)
    sp, cp = divmod(rest, 10)
    parts = [f"{gp} gp" if gp else "", f"{sp} sp" if sp else "", f"{cp} cp" if cp else ""]
    return " ".join(p for p in parts if p)


def time_of_day(minute_of_day: int) -> str:
    """Morning, Day, Dusk or Night, as the location pictures and lighting use them."""
    h = (minute_of_day // 60) % 24
    if 5 <= h < 10:
        return "Morning"
    if 10 <= h < 17:
        return "Day"
    if 17 <= h < 20:
        return "Dusk"
    return "Night"


class GameState:
    def __init__(self, world, bus=None) -> None:
        self.world = world
        self.bus = bus
        self.path = Path(world.path) / FILE
        self.minutes = START_MINUTE
        self.copper = 0                         # all money, in copper pieces (100 cp = 1 gp)
        self.xp = 0
        self.inventory: dict[str, int] = {}     # item id -> count
        self.location = ""                      # entity id: a building or a town
        self.visited: list[str] = []
        self.npcs: dict[str, dict] = {}         # npc id -> {"last_quest_day", "offer", "line"}
        self.quests: list[dict] = []            # quest instances (see game/quests.py)
        self.kills: dict[str, int] = {}         # entity id -> defeated count, all time
        self.counter = 0                        # for unique quest ids
        self.party: dict[str, dict] = {}        # member id -> {"hp", "hit_dice", "slots", "uses"} between fights
        self.journey: dict | None = None        # a road journey in progress (game/travel.py)
        self.last_town = ""                     # where a beaten party wakes up
        self.last_long_rest = -10 ** 9          # minute the last long rest ended
        self.fog = ""                           # map cells seen, a base64 bitset (game/geography.py)
        self.discovered: list[str] = []         # landmarks and dungeons found
        self.dungeons: dict[str, dict] = {}     # dungeon id -> {"cleared": [...], "looted": [...], "day"}
        self.trek: dict | None = None           # a cross-country trip over hexes in progress (game/hexes.py)
        self.passages: list[str] = []           # ways to other continents the party has been given (game/passage.py)
        self.explore: dict = {}                 # walking maps: position, what's been seen, doors (game/explore.py)
        self.ticks: dict[str, int] = {}         # catch-up function -> minute it last ran (game/ticker.py)
        for key, make in SECTIONS.items():      # room for the later systems (each fills its own)
            setattr(self, key, make())
        self.holdings: dict = {}                # what the party owns (game/holdings.py, holdings.json)
        world._state_for_places = self          # places.neighbors needs to know what's been discovered
        self.load()
        from game import destruction
        destruction.bind(self)                  # (ruins: shut shops, people sleeping rough)
        from game import builtin_packs, dialogue, factions, holdings
        builtin_packs.upgrade(world)            # worlds made before a pack existed get what builds on theirs
        factions.ensure(world)                  # worlds get their factions made the first time a game starts
        dialogue.ensure(world)                  # ...and their Everyday talk and occupation conversations
        from game import estate, survival
        estate.ensure(world)                    # ...and the starting blueprints (game/estate.py)
        survival.ensure(world)                  # ...meals and drinks marked, remedies and feed (game/survival.py)
        holdings.load(world, self)

    # ------------------------------------------------------------------
    # Saving
    # ------------------------------------------------------------------
    def to_dict(self) -> dict:
        out = {"format": FORMAT, "minutes": self.minutes, "copper": self.copper, "xp": self.xp,
                "inventory": self.inventory, "location": self.location, "visited": self.visited,
                "npcs": self.npcs, "quests": self.quests, "kills": self.kills, "counter": self.counter,
                "party": self.party, "journey": self.journey, "last_town": self.last_town,
                "last_long_rest": self.last_long_rest, "fog": self.fog, "discovered": self.discovered,
                "dungeons": self.dungeons, "trek": self.trek, "passages": self.passages,
                "explore": self.explore, "ticks": self.ticks}
        for key in SECTIONS:
            out[key] = getattr(self, key)
        return out

    def load(self) -> None:
        if not self.path.exists():
            return
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        self.minutes = int(d.get("minutes", START_MINUTE))
        self.copper = int(d.get("copper", int(d.get("gold", 0)) * 100))
        self.xp = int(d.get("xp", 0))
        self.inventory = {k: int(v) for k, v in (d.get("inventory") or {}).items() if int(v) > 0}
        self.location = d.get("location") or ""
        self.visited = list(d.get("visited") or [])
        self.npcs = dict(d.get("npcs") or {})
        self.quests = list(d.get("quests") or [])
        self.kills = dict(d.get("kills") or {})
        self.counter = int(d.get("counter", 0))
        self.party = dict(d.get("party") or {})
        self.journey = d.get("journey") or None
        self.last_town = d.get("last_town") or ""
        self.last_long_rest = int(d.get("last_long_rest", -10 ** 9))
        self.fog = str(d.get("fog") or "")
        self.discovered = list(d.get("discovered") or [])
        self.dungeons = dict(d.get("dungeons") or {})
        self.trek = d.get("trek") or None
        self.passages = list(d.get("passages") or [])
        self.explore = dict(d.get("explore") or {})
        self.ticks = {k: int(v) for k, v in (d.get("ticks") or {}).items()}
        for key, make in SECTIONS.items():
            v = d.get(key)
            setattr(self, key, v if isinstance(v, make) else make())

    def save(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def reset(self) -> None:
        """Start the world over (keeps the world's content, clears progress)."""
        from game import holdings
        for p in (self.path, holdings.path(self.world)):
            if p.exists():
                p.unlink()
        self.world.entities.clear_overlay()
        self.__init__(self.world, self.bus)
        if not holdings.path(self.world).exists():
            holdings.save(self.world, self)        # an empty one, so nothing is migrated again

    def _emit(self, name: str, **data: Any) -> None:
        if self.bus is not None:
            self.bus.emit(name, **data)

    def next_id(self, prefix: str = "q") -> str:
        self.counter += 1
        return f"{prefix}{self.counter}"

    # ------------------------------------------------------------------
    # Time
    # ------------------------------------------------------------------
    @property
    def day(self) -> int:
        return self.minutes // DAY + 1

    @property
    def minute_of_day(self) -> int:
        return self.minutes % DAY

    @property
    def time_of_day(self) -> str:
        return time_of_day(self.minute_of_day)

    def clock_text(self) -> str:
        m = self.minute_of_day
        return f"Day {self.day}  ·  {self.time_of_day}  ·  {m // 60:02d}:{m % 60:02d}"

    def advance(self, minutes: int, reason: str = "") -> None:
        if minutes <= 0:
            return
        before_day, before_tod = self.day, self.time_of_day
        self.minutes += int(minutes)
        from game import ticker
        ticker.run(self)                        # everything that changes with time catches up
        self.save()
        self._emit("time.passed", minutes=int(minutes), reason=reason, day=self.day)
        if self.day != before_day:
            self._emit("time.new_day", day=self.day)
        if self.time_of_day != before_tod:
            self._emit("time.changed", time_of_day=self.time_of_day)

    # ------------------------------------------------------------------
    # Purse and pack
    # ------------------------------------------------------------------
    def count(self, item_id: str) -> int:
        return int(self.inventory.get(item_id, 0))

    def add_item(self, item_id: str, n: int = 1, source: str = "") -> None:
        if not item_id or n <= 0:
            return
        self.inventory[item_id] = self.count(item_id) + n
        self.save()
        self._emit("inventory.changed", item=item_id, change=n, count=self.count(item_id), source=source)

    def remove_item(self, item_id: str, n: int = 1, reason: str = "") -> int:
        have = self.count(item_id)
        take = min(have, max(0, n))
        if take <= 0:
            return 0
        if have - take > 0:
            self.inventory[item_id] = have - take
        else:
            self.inventory.pop(item_id, None)
        self.save()
        self._emit("inventory.changed", item=item_id, change=-take, count=self.count(item_id), source=reason)
        return take

    @property
    def gold(self) -> int:
        """Whole gold pieces' worth of money (for quick checks and display)."""
        return self.copper // 100

    def add_gold(self, n: float, source: str = "") -> None:
        self.add_copper(int(round(float(n) * 100)), source)

    def add_copper(self, n: int, source: str = "") -> None:
        if n == 0:
            return
        self.copper = max(0, self.copper + int(n))
        self.save()
        self._emit("gold.changed", change=int(n), gold=self.gold, copper=self.copper, source=source)

    def money_text(self) -> str:
        return money_text(self.copper)

    def add_xp(self, n: int, source: str = "") -> None:
        if n <= 0:
            return
        self.xp += int(n)
        self.save()
        self._emit("xp.gained", amount=int(n), total=self.xp, source=source)

    def give_rewards(self, rewards: dict, source: str = "") -> list[str]:
        """Apply {"xp", "gold", "items": {id: n}}. Returns readable lines."""
        lines = []
        if rewards.get("xp"):
            self.add_xp(int(rewards["xp"]), source)
            lines.append(f"{int(rewards['xp'])} experience")
        if rewards.get("gold"):
            self.add_gold(int(rewards["gold"]), source)
            lines.append(f"{int(rewards['gold'])} gold")
        for item_id, n in (rewards.get("items") or {}).items():
            self.add_item(item_id, int(n), source)
            item = self.world.entities.get(item_id)
            lines.append(f"{item.name if item else item_id} x{int(n)}")
        return lines

    # ------------------------------------------------------------------
    # NPC memory
    # ------------------------------------------------------------------
    def npc(self, npc_id: str) -> dict:
        return self.npcs.setdefault(npc_id, {})

    def disposition(self, npc) -> str:
        """How an NPC feels about the party now (attacking them makes them Hostile)."""
        return self.npcs.get(npc.id, {}).get("disposition") or npc.fields.get("disposition") or "Neutral"

    def npc_dead(self, npc_id: str) -> bool:
        return bool(self.npcs.get(npc_id, {}).get("dead"))

    def record_kill(self, entity_id: str) -> None:
        if entity_id:
            self.kills[entity_id] = self.kills.get(entity_id, 0) + 1
            self.save()


__all__ = ["GameState", "time_of_day", "money_text", "DAY", "START_MINUTE", "SECTIONS"]
