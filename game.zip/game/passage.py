"""Passages: the way to other continents. Ships, airships and caravans.

An NPC's "Offers passage" rows are trips from their town to a town elsewhere: by Boat, Airship or
Caravan, at a price, taking some days. Talking to them, the party can buy a trip; from then on the
party knows that way (state.passages), and the map shows it.

A voyage goes day by day (location "voyage|<from town>|<to town>"). Each day there's a chance of
trouble: a fight in that method's theme (pirates and sea beasts, sky raiders and flying things,
desert raiders and beasts of the road) on a ship's deck, an airship's deck or around the wagons; or
a hazard (storms, lightning, sandstorms...) that tests everyone. Quiet days pass with a night's rest.
"""
from __future__ import annotations

import random

from game import dice

THEMES = {
    "Boat": {"tags": {"sea", "aquatic", "pirate", "water", "coast"}, "env": {"Coast", "Underwater"},
             "map": "ship", "raiders": ("Pirate", "Pirate Captain"),
             "noun": "the ship", "verb": "sail",
             "calm": ["The wind holds fair all day.", "Gulls follow the ship for hours.", "Dolphins race the bow.",
                      "The crew sings as they work the lines.", "Grey water, grey sky, and nothing on the horizon."],
             "hazards": [("A storm hits", "con", 12, "1d6", "bludgeoning", True),
                         ("A rogue wave sweeps the deck", "str", 12, "1d8", "bludgeoning", False),
                         ("Fog rolls in and the ship crawls blind", "", 0, "", "", True)],
             "fight": ["Sails on the horizon: pirates, and they're closing fast!",
                       "Something huge rises from the water beside the ship!"]},
    "Airship": {"tags": {"flying", "sky", "air", "bird", "dragon"}, "env": {"Mountains", "Hills"},
                "map": "airship", "raiders": ("Sky Raider", "Sky Raider Captain"),
                "noun": "the airship", "verb": "fly",
                "calm": ["The land slides past far below.", "You drift above a sea of cloud.",
                         "The envelope creaks in the cold wind.", "A flock of birds keeps pace for a while.",
                         "The pilot points out a city, tiny as a toy, far beneath you."],
                "hazards": [("A lightning storm crackles around the airship", "dex", 13, "2d6", "lightning", False),
                            ("Turbulence throws everyone across the deck", "con", 12, "1d6", "bludgeoning", False),
                            ("The engine sputters; you limp along for a day", "", 0, "", "", True)],
                "fight": ["Winged shapes dive out of the sun!", "A raider skiff pulls alongside, grapnels flying!"]},
    "Caravan": {"tags": {"bandit", "raider", "desert", "beast"}, "env": {"Desert", "Plains", "Badlands"},
                "map": "caravan", "raiders": ("Raider", "Raider Chief"),
                "noun": "the caravan", "verb": "travel",
                "calm": ["The wagons roll on through the heat.", "Dust, and more dust.",
                         "You camp at a well that night, and the water is sweet.",
                         "A merchant shares stories of the road over the fire.", "The road is empty and quiet."],
                "hazards": [("A sandstorm buries the road", "con", 12, "1d6", "slashing", True),
                            ("The heat is brutal", "con", 11, "1d4", "fire", False),
                            ("A wagon's axle breaks; you lose a day fixing it", "", 0, "", "", True)],
                "fight": ["Riders on the ridge: raiders, coming for the wagons!",
                          "Something has been following the caravan, and now it strikes!"]},
}
DAY = 24 * 60


def offers(world, npc) -> list[dict]:
    """The trips an NPC offers: [{"to": town, "method", "price", "days", "danger", "note"}]."""
    out = []
    for row in npc.fields.get("passages") or []:
        dest = world.entities.get(row.get("to") or "")
        if dest is None or dest.type != "town":
            continue
        out.append({"to": dest, "method": row.get("method") if row.get("method") in THEMES else "Boat",
                    "price": max(0, int(float(row.get("price") or 0))), "days": max(1, int(row.get("days") or 1)),
                    "danger": max(0, min(100, int(row.get("danger") if row.get("danger") not in (None, "") else 35))),
                    "note": row.get("note") or "", "npc": npc})
    return out


def key(npc, dest) -> str:
    return f"{npc.id}>{dest.id}"


def known(world, state) -> list[dict]:
    """Passages the party has been given: [{"npc", "from" town, "to" town, "method", ...}]."""
    from game import places
    out = []
    for k in state.passages:
        npc_id, _s, to_id = k.partition(">")
        npc = world.entities.get(npc_id)
        if npc is None:
            continue
        for o in offers(world, npc):
            if o["to"].id == to_id:
                o["from"] = world.entities.get(places.town_of(world, npc))
                out.append(o)
    return out


def ways_to_continent(world, state, continent) -> list[dict]:
    """Known passages that land on that continent."""
    from game import geography as G
    return [o for o in known(world, state) if G.continent_of_town(world, o["to"]) is continent]


def voyage_id(from_id: str, to_id: str) -> str:
    return f"voyage|{from_id}|{to_id}"


def start(world, state, offer: dict, bus=None) -> tuple[bool, str]:
    """Pay for a trip and set off."""
    from game import places
    npc, dest = offer["npc"], offer["to"]
    cost = offer["price"] * 100
    if cost > state.copper:
        return False, "You can't afford the fare."
    if state.journey:
        return False, "You're already travelling."
    if cost:
        state.add_copper(-cost, f"passage to {dest.name}")
    k = key(npc, dest)
    if k not in state.passages:
        state.passages.append(k)
    home = world.entities.get(places.town_of(world, npc))
    state.trek = None
    state.journey = {"kind": "voyage", "method": offer["method"], "from": home.id if home else "", "to": dest.id,
                     "days": offer["days"], "done": 0, "danger": offer["danger"], "npc": npc.id,
                     "hours": offer["days"] * 24.0}
    places.enter(world, state, voyage_id(home.id if home else "", dest.id), bus)
    th = THEMES[offer["method"]]
    text = (f"You pay {offer['price']} gold and board {th['noun']}, bound for {dest.name}. "
            f"It's {offer['days']} day{'s' if offer['days'] != 1 else ''} away.")
    if bus is not None:
        bus.emit("log", kind="narration", text=text)
        bus.emit("voyage.started", journey=dict(state.journey))
    return True, text


def _enemies(world, method: str, levels: list[int], rng: random.Random, region=None) -> dict | None:
    """A fight in this method's theme."""
    from game.quests import encounter_options
    th = THEMES[method]
    diff = rng.choice(["Easy", "Medium", "Medium"])
    opts = encounter_options(world, levels, diff) or encounter_options(world, levels, "Easy")
    themed = [o for o in opts if {t.lower() for t in o[0].tags} & th["tags"]
              or set(o[0].fields.get("environments") or []) & th["env"]]
    if themed:
        enemy, n, _a, _s = rng.choice(themed[:6])
        return {"rows": [{"id": enemy.id, "count": n}]}
    # nothing themed in this world: human raiders (bandits, renamed)
    bandit = world.entities.find_by_name("enemy", "Bandit")
    captain = world.entities.find_by_name("enemy", "Bandit Captain")
    if bandit is None:
        if not opts:
            return None
        enemy, n, _a, _s = rng.choice(opts[:6])
        return {"rows": [{"id": enemy.id, "count": n}]}
    lvl = max(1, round(sum(levels) / max(1, len(levels))))
    rows = [{"id": bandit.id, "count": max(2, min(8, len(levels) + lvl // 2)), "name": th["raiders"][0]}]
    if captain is not None and lvl >= 3:
        rows.append({"id": captain.id, "count": 1, "name": th["raiders"][1]})
    return {"rows": rows, "raiders": True}


def step(world, state, rng: random.Random, levels: list[int], members: list | None = None, bus=None) -> dict:
    """One day of the voyage. Returns {"kind": "progress" | "encounter" | "arrived", ...}."""
    from game import condition, places
    j = state.journey
    if not j or j.get("kind") != "voyage":
        return {"kind": "arrived"}
    th = THEMES.get(j.get("method"), THEMES["Boat"])
    dest = world.entities.get(j["to"])
    state.advance(DAY, "a day's travel")
    j["done"] = int(j.get("done", 0)) + 1
    state.save()
    say = (lambda text, kind="narration": bus.emit("log", kind=kind, text=text)) if bus is not None else (
        lambda text, kind="narration": None)
    if rng.random() < j.get("danger", 35) / 100.0:
        if rng.random() < 0.6:
            found = _enemies(world, j.get("method", "Boat"), levels, rng)
            if found:
                style = ""
                if j.get("method") == "Caravan":
                    home = world.entities.get(j.get("from") or "")
                    style = (home.fields.get("terrain") if home is not None else "") or "Plains"
                found.update(kind="encounter", environment=th["map"], style=style,
                             text=th["fight"][0] if found.get("raiders") else th["fight"][1])
                return found
        title, stat, dc, dmg, dtype, delay = rng.choice(th["hazards"])
        lines = [title + "!"]
        for m in members or []:
            if m.get("dead") or not stat:
                continue
            c = condition.combatant(world, m)
            condition.apply(state, m, c)
            roll = rng.randint(1, 20) + c.mod(stat) + (c.prof if stat in c.saves else 0)
            if roll < dc:
                loss = min(c.hp - 1, max(0, dice.roll(dmg, rng).total))
                c.hp -= loss
                condition.store(state, m, c, save=False)
                lines.append(f"{c.name} ({stat.upper()} save {roll}) takes {loss} {dtype} damage.")
        if delay:
            j["days"] = int(j["days"]) + 1
            j["hours"] = j["days"] * 24.0
            lines.append("You lose a day.")
        say(" ".join(lines), "damage")
    else:
        say(rng.choice(th["calm"]) + f" (day {j['done']} of {j['days']})")
    if members:
        condition.long_rest(world, state, members, None, minutes=0)
    if j["done"] >= j["days"]:
        state.journey = None
        if j.get("own"):                                  # the party's own boat ties up here (game/animals.py)
            from game import animals
            animals.moored(world, state, j["own"], dest.id)
        places.enter(world, state, places.street_id(dest.id, places.first_street(dest)), bus)
        if bus is not None:
            bus.emit("voyage.arrived", town=dest.id)
            bus.emit("log", kind="narration", text=f"You arrive in {dest.name}.")
        state.save()
        return {"kind": "arrived", "town": dest.id}
    return {"kind": "progress"}
