"""Crime and the law.

Crimes: stealing what's someone's (from a shop's stock), picking a pocket (Sleight of Hand), picking a lock
that isn't yours, being where you shouldn't after hours (trespass), assault and murder (a fight with
townsfolk), robbing a bank, and an unpaid debt (game/bank.py).

Witnesses: those who see it happen. On the walking map that's whoever is in sight, by the light and the
weather (the same sight the party has: far by day, short at dusk, a few squares on a dark night unless
you carry a light; fog and snow cut it; indoors lamps light the room). Without the map, anyone in the same
place, fewer of them in the dark. Each of them notices unless the party's Stealth beats their passive
Perception (10, and 12 for a guard). A crowd in the street counts as a witness that can't be silenced.

Bounties: each realm keeps one on the party: the fines for every crime done in its towns that someone
living saw. A crime with no living witnesses posts nothing, so silencing every witness takes it off.
Guards who see a wanted party stop it: pay the fine, go to jail (a few days, by the size of the bounty,
and stolen goods are taken), or resist (a fight with the watch).

Stolen goods carry a stolen mark (an item variant, game/quality.py: "item.x@standard~"). Merchants won't
buy them, except a shopkeeper in another neighborhood (game/neighborhood.py) from where they were taken;
a fence (one merchant in every city with a thieves' guild) always will.

Standing: a crime that's seen costs standing with the town and its realm; every crime is worth a little
with the thieves' guild.

Kept in the save (state.law): {"crimes": [{"id", "kind", "town", "realm", "day", "fine", "witnesses",
"victim", "settled"}], "stolen": {item variant id: [town ids]}, "jailed": days, "confronted": minute}.
"""
from __future__ import annotations

import math
import random
import zlib

# what each crime adds to the bounty (gp; some add what was taken), and what it costs in standing
FINES = {"cheating": 25, "theft": 5, "pickpocket": 10, "lockpicking": 10, "trespass": 5, "assault": 40, "murder": 1000,
         "bank robbery": 2500, "debt": 0, "jailbreak": 200, "vandalism": 15, "arson": 500}
TOWN_STANDING = {"cheating": -5, "theft": -3, "pickpocket": -4, "lockpicking": -2, "trespass": -2, "assault": -10, "murder": -30,
                 "bank robbery": -40, "debt": -10, "jailbreak": -15, "vandalism": -4, "arson": -30}
GUILD_STANDING = {"cheating": 1, "theft": 2, "pickpocket": 2, "lockpicking": 1, "trespass": 1, "assault": 1, "murder": 3,
                  "bank robbery": 10, "debt": 0, "jailbreak": 5, "vandalism": 1, "arson": 2}
WORDS = {"cheating": "cheating at the tables", "theft": "theft", "pickpocket": "picking pockets", "lockpicking": "breaking a lock", "trespass": "trespass",
         "assault": "assault", "murder": "murder", "bank robbery": "robbing a bank", "debt": "an unpaid debt",
         "jailbreak": "breaking out of jail", "vandalism": "wrecking property", "arson": "arson"}
CROWD = "crowd"            # a witness nobody can silence
LEDGER = "ledger"          # the bank's books (a debt)
JAIL_GP_PER_DAY = 50
CONFRONT_EVERY = 60        # minutes between the watch's challenges
GUARD_PASSIVE = 12
PASSIVE = 10
STOLEN_SELL = 0.4          # what a fence pays, of the item's value (a far-off shopkeeper pays the usual)


def data(state) -> dict:
    d = state.law
    d.setdefault("crimes", [])
    d.setdefault("stolen", {})
    return d


def _gp(c: float) -> int:
    return int(round(c))


# ----------------------------------------------------------------------------------------------------
# Realms
# ----------------------------------------------------------------------------------------------------
def realm_key(world, town) -> str:
    from game import factions
    if town is None:
        return ""
    r = factions.realm_of_town(world, town)
    return r.id if r is not None else f"town:{town.id}"


def realm_name(world, key: str) -> str:
    if key.startswith("town:"):
        t = world.entities.get(key[5:])
        return t.name if t is not None else "the town"
    f = world.entities.get(key)
    return f.name if f is not None else "the realm"


def thieves_guild(world, town):
    """The thieves' guild of this town's city (or the nearest city that has one)."""
    from game import factions
    from game import geography as G
    idx = factions.index(world)["thieves"]
    if town is None or not idx:
        return None
    if town.id in idx:
        return idx[town.id]
    cache = world.__dict__.setdefault("_guild_of", {})
    if town.id in cache:
        return world.entities.get(cache[town.id])
    p0 = G.town_position(world, town)
    best = None
    for tid, f in idx.items():
        t = world.entities.get(tid)
        p = G.town_position(world, t) if t is not None else None
        d = math.hypot(p[0] - p0[0], p[1] - p0[1]) if (p and p0) else 0
        if best is None or d < best[0]:
            best = (d, f)
    cache[town.id] = best[1].id if best else ""
    return best[1] if best else None


# ----------------------------------------------------------------------------------------------------
# Witnesses
# ----------------------------------------------------------------------------------------------------
def _light_share(world, state) -> float:
    """Without the walking map: how many of those about see clearly (by the hour and the weather)."""
    from game import places
    from game import weather as W
    from game.combat import lighting as LT
    spot = places.current(world, state)
    if spot.kind == "building":
        return 1.0
    try:
        w = W.here(world, state)
        light = LT.outdoor_light(state.minutes, w)
        sight = float(getattr(w, "sight", 1.0) or 1.0)
    except Exception:  # noqa: BLE001
        light, sight = LT.BRIGHT, 1.0
    share = 1.0 if light == LT.BRIGHT else 0.6 if light == LT.DIM else 0.3
    return max(0.1, share * min(1.0, sight))


def onlookers(world, state, explorer=None, rng: random.Random | None = None, exclude=()) -> list[str]:
    """Who could see what the party is doing right now (before the Stealth check): NPC ids, and CROWD."""
    from game import places
    rng = rng or random.Random()
    out: list[str] = []
    skip = set(exclude)
    ex = explorer
    if ex is not None and getattr(ex, "area", None) is not None and ex.area.kind != "world":
        vis = ex.visible if ex.visible else ex.look()
        r = ex.sight_radius()
        for t in ex.tokens:
            if t.hidden or t.level != ex.level or (t.x, t.y) not in vis:
                continue
            if max(abs(t.x - ex.x), abs(t.y - ex.y)) > r:
                continue
            if t.kind == "npc" and t.entity not in skip and not state.npc_dead(t.entity):
                out.append(t.entity)
            elif t.kind == "crowd" and CROWD not in out:
                out.append(CROWD)
        return out
    spot = places.current(world, state)
    share = _light_share(world, state)
    try:
        people = places.people_in(world, spot, state)
    except Exception:  # noqa: BLE001
        people = []
    for n in people:
        if n.id in skip or state.npc_dead(n.id):
            continue
        if rng.random() < share:
            out.append(n.id)
    if spot.kind == "street" and spot.town is not None and rng.random() < share:
        out.append(CROWD)
    return out


def _passive(world, who: str) -> int:
    if who == CROWD:
        return PASSIVE
    n = world.entities.get(who)
    return GUARD_PASSIVE if n is not None and (n.fields.get("occupation") or "") == "Guard" else PASSIVE


def sneak_roll(world, members, rng: random.Random | None = None, bus=None) -> int:
    """The party's best Stealth (one roll, by whoever is best at it)."""
    from game import checks, condition
    rng = rng or random.Random()
    opt = next((o for o in checks.options(world) if o["label"] == "Stealth"), None)
    best = None
    for m in members or []:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        b = checks.bonus(world, m, c, opt)[0] if opt else c.mods.get("dex", 0)
        if best is None or b > best[2]:
            best = (m, c, b)
    if best is None:
        return 0
    if opt is None:
        return rng.randint(1, 20) + best[2]
    r = checks.roll(world, best[0], best[1], opt, 0, rng=rng, bus=bus, target="keeping out of sight")
    return int(r.get("total") or 0)


def witnesses(world, state, members, explorer=None, rng: random.Random | None = None, exclude=(), sneak=None,
              bus=None) -> list[str]:
    """Those who see the deed: everyone in sight whose passive Perception beats the party's Stealth."""
    rng = rng or random.Random()
    who = onlookers(world, state, explorer, rng, exclude)
    if not who:
        return []
    s = sneak_roll(world, members, rng, bus) if sneak is None else int(sneak)
    return [w for w in who if _passive(world, w) >= s]


def alive(state, who: str) -> bool:
    if who in (CROWD, LEDGER):
        return True
    return not state.npc_dead(who)


# ----------------------------------------------------------------------------------------------------
# Crimes and bounties
# ----------------------------------------------------------------------------------------------------
def commit(world, state, kind: str, town, seen_by: list[str], amount_gp: float = 0, victim: str = "",
           bus=None) -> dict:
    """Record a crime. Seen, it costs standing with the town and the realm, and goes on the bounty for as
    long as one witness lives. Every crime is worth a little with the thieves' guild."""
    from game import factions
    d = data(state)
    fine = FINES.get(kind, 10) + (_gp(amount_gp) if kind != "bank robbery" else _gp(amount_gp) * 2)
    crime = {"id": state.next_id("c"), "kind": kind, "town": town.id if town is not None else "",
             "realm": realm_key(world, town), "day": state.day, "fine": max(1, fine) if kind != "debt" else
             max(1, _gp(amount_gp)), "witnesses": list(dict.fromkeys(seen_by)), "victim": victim, "settled": False}
    d["crimes"].append(crime)
    if seen_by and town is not None and kind != "debt":    # the watch comes running (game/schedules.py)
        from game import places
        here = places.current(world, state)
        at = here.building.id if here.kind == "building" and here.building is not None else \
            here.id if here.kind == "street" else ""
        d["alarm"] = {"town": town.id, "until": state.minutes + 60, "at": at}
    if seen_by and town is not None:
        tf = factions.town_faction(world, town)
        if tf is not None:
            factions.change(world, state, tf.id, TOWN_STANDING.get(kind, -2), f"for {WORDS.get(kind, kind)}", bus)
    g = thieves_guild(world, town)
    if g is not None and GUILD_STANDING.get(kind):
        factions.change(world, state, g.id, GUILD_STANDING[kind], "word gets around", None)
    if bus is not None:
        if seen_by:
            bus.emit("log", kind="system", text=f"You were seen: {WORDS.get(kind, kind)}. "
                                                  f"There's a bounty on you in {realm_name(world, crime['realm'])}.")
        else:
            bus.emit("log", kind="system", text="Nobody saw.")
        bus.emit("law.crime", crime=dict(crime))
    state.save()
    return crime


def counts(state, crime: dict) -> bool:
    """Does this crime still stand against the party (not settled, and someone who saw it lives)?"""
    return not crime.get("settled") and any(alive(state, w) for w in crime.get("witnesses") or [])


def bounty(world, state, key: str) -> int:
    """gp on the party's head in a realm."""
    return sum(int(c["fine"]) for c in data(state)["crimes"] if c.get("realm") == key and counts(state, c))


def bounties(world, state) -> dict[str, int]:
    out: dict[str, int] = {}
    for c in data(state)["crimes"]:
        if counts(state, c):
            out[c["realm"]] = out.get(c["realm"], 0) + int(c["fine"])
    return out


def wanted_here(world, state) -> tuple[str, int]:
    from game import places
    town = places.current(world, state).town
    if town is None:
        return "", 0
    key = realm_key(world, town)
    return key, bounty(world, state, key)


def jail_days(gp: int) -> int:
    return max(1, min(60, int(math.ceil(gp / JAIL_GP_PER_DAY))))


def settle(world, state, key: str, how: str, bus=None) -> None:
    """Every standing crime in the realm is answered for (paid, served or forgiven)."""
    from game import bank
    for c in data(state)["crimes"]:
        if c.get("realm") == key and not c.get("settled"):
            c["settled"] = how
            if c["kind"] == "debt":
                bank.debt_settled(world, state, key)
    state.save()


def pay_fine(world, state, key: str, bus=None) -> tuple[bool, str]:
    gp = bounty(world, state, key)
    if gp <= 0:
        return False, "You're not wanted here."
    if state.copper < gp * 100:
        return False, f"The fine is {gp} gp. You can't pay it."
    state.add_copper(-gp * 100, "a fine")
    settle(world, state, key, "paid", bus)
    return True, f"You pay {gp} gp. The watch lets you go, with a warning."


def go_to_jail(world, state, key: str, bus=None) -> tuple[bool, str]:
    """A time skip in the cells; stolen goods are taken."""
    from game import places
    gp = bounty(world, state, key)
    if gp <= 0:
        return False, "You're not wanted here."
    days = jail_days(gp)
    took = 0
    for iid in [i for i in list(state.inventory) if is_stolen(i)]:
        took += state.remove_item(iid, state.count(iid), reason="taken by the watch")
    town = places.current(world, state).town
    jail = next((b for b in places.buildings_in(world, town) if (b.fields.get("kind") or "") in ("Jail", "Barracks")),
                None) if town is not None else None
    if jail is not None:
        places.enter(world, state, jail.id, bus)
    state.advance(days * 24 * 60, "in jail")
    data(state)["jailed"] = int(data(state).get("jailed", 0)) + days
    settle(world, state, key, "served", bus)
    if town is not None:
        places.enter(world, state, places.street_id(town.id, places.first_street(town)), bus)
    return True, f"You spend {days} day{'s' if days != 1 else ''} in the cells" + \
        (f", and the watch keeps the stolen goods ({took})" if took else "") + ". You walk out free."


def guards_for(world, town, n: int = 2) -> list[dict]:
    """The watch that comes to take a party that resists: enemy rows for a fight."""
    from game import places
    rows = []
    people = [p for b in (places.buildings_in(world, town) if town is not None else [])
              for p in (world.entities.get(x) for x in b.fields.get("npcs") or [])
              if p is not None and (p.fields.get("occupation") or "") == "Guard"]
    for p in people[:n]:
        rows.append({"id": p.id, "count": 1})
    if len(rows) < n:
        g = world.entities.find_by_name("enemy", "Guard")
        if g is not None:
            rows.append({"id": g.id, "count": n - len(rows), "name": "Town guard"})
    return rows


def resisted(world, state, key: str, town, bus=None) -> dict:
    """Resisting arrest is assault on the watch."""
    return commit(world, state, "assault", town, [CROWD], 0, "", bus)


def should_confront(world, state) -> tuple[str, int]:
    """(realm key, bounty) when the watch should stop the party here and now."""
    if not (state.law or {}).get("crimes") or (state.law or {}).get("jail"):    # (not while locked up)
        return "", 0
    key, gp = wanted_here(world, state)
    if gp <= 0:
        return "", 0
    d = data(state)
    if state.minutes - int(d.get("confronted", -10 ** 9)) < CONFRONT_EVERY:
        return "", 0
    return key, gp


def confronted(state) -> None:
    data(state)["confronted"] = state.minutes
    state.save()


def guard_prompt_options(world, state, key: str, gp: int) -> list[tuple[str, tuple, bool]]:
    from game import jail, places
    days = f"{jail_days(gp)} day{'s' if jail_days(gp) != 1 else ''} in jail"
    here = places.current(world, state).town
    b, _miles = jail.jail_for(world, here)
    if b is not None:
        there = world.entities.get(b.fields.get("town"))
        days = "to the gallows: you'll hang for this" if jail.capital(world, state, key) else \
            days + ", stripped of your gear"
        if there is not None and here is not None and there.id != here.id:
            days += f"; taken to {there.name}'s jail"
    return [(f"Pay the fine ({gp} gp)", ("law", "pay", key), state.copper >= gp * 100),
            (f"Go quietly ({days})", ("law", "jail", key), True),
            ("Resist", ("law", "resist", key), True)]


# ----------------------------------------------------------------------------------------------------
# Stolen goods and fences
# ----------------------------------------------------------------------------------------------------
def is_stolen(item_id: str) -> bool:
    from game import quality
    return quality.is_stolen(item_id)


def take_stolen(world, state, item_id: str, n: int, town, source: str = "stolen") -> str:
    """Put stolen things in the pack, marked, remembering where they were taken."""
    from game import quality
    sid = quality.stolen(item_id)
    state.add_item(sid, n, source=source)
    where = data(state)["stolen"].setdefault(sid, [])
    if town is not None and town.id not in where:
        where.append(town.id)
    state.save()
    return sid


def is_fence(world, npc) -> bool:
    """One merchant in every city with a thieves' guild (or anyone who belongs to a thieves' guild)."""
    from game import factions, places
    if npc is None:
        return False
    own = factions.get(world, npc.fields.get("faction"))
    if own is not None and (own.fields.get("kind") or "") == "Criminal" and own.fields.get("town"):
        return True
    town = world.entities.get(places.town_of(world, npc) or "")
    if town is None or town.id not in factions.index(world)["thieves"]:
        return False
    return fence_of(world, town) == npc.id


def fence_of(world, town) -> str:
    from game import places

    cache = world.entities.memo("npc", "fences")
    if town.id not in cache:
        merchants = [n for b in places.buildings_in(world, town) for n in (world.entities.get(x) for x in
                     b.fields.get("npcs") or []) if n is not None and (n.fields.get("occupation") or "") == "Merchant"]
        cache[town.id] = min(merchants, key=lambda n: zlib.crc32(n.id.encode())).id if merchants else ""
    return cache[town.id]


def fence_in(world, town):
    fid = fence_of(world, town) if town is not None else ""
    return world.entities.get(fid) if fid else None


def will_buy_stolen(world, state, npc, item_id: str) -> tuple[bool, bool]:
    """(will they buy it, is it a fence's price)."""
    from game import neighborhood as NB
    if is_fence(world, npc):
        return True, True
    town = world.entities.get(NB.npc_town(world, npc))
    if town is None:
        return False, False
    hood = NB.neighborhood(world, town)
    taken = data(state)["stolen"].get(item_id) or []
    if not taken:
        return False, False
    return not any(t in hood.town_ids for t in taken), False


# ----------------------------------------------------------------------------------------------------
# The deeds
# ----------------------------------------------------------------------------------------------------
def _check(world, members, label: str, dc: int, rng, bus=None, target: str = "") -> tuple[bool, int, dict | None]:
    from game import checks, condition, tools
    opt = next((o for o in checks.options(world) if o["label"] == label), None)
    best = None
    for m in members or []:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        if opt is not None and opt["kind"] == "Tool" and not checks.proficient(world, m, opt) and \
                not opt.get("untrained", True) and not tools.level(world, m, opt["id"])[1]:
            continue
        b = checks.bonus(world, m, c, opt)[0] if opt else c.mods.get("dex", 0)
        if best is None or b > best[2]:
            best = (m, c, b)
    if best is None:
        return False, 0, None
    if opt is None:
        total = rng.randint(1, 20) + best[2]
        return total >= dc, total, best[0]
    r = checks.roll(world, best[0], best[1], opt, dc, rng=rng, bus=bus, target=target)
    return bool(r.get("success")), int(r.get("total") or 0), best[0]


def steal(world, state, members, npc, rng: random.Random | None = None, explorer=None, bus=None,
          item_id: str = "") -> dict:
    """Lift something off a trader's shelves (Sleight of Hand). Fumbled, the trader sees; the rest see what
    their eyes allow."""
    from game import neighborhood as NB
    from game import trade
    rng = rng or random.Random()
    town = world.entities.get(NB.npc_town(world, npc))
    stock = trade.stock(world, state, npc, rng)
    cands = [i for i, n in stock.items() if n > 0 and world.entities.get(i) is not None]
    if not cands:
        return {"ok": False, "text": "There's nothing within reach.", "seen": []}
    iid = item_id if item_id in cands else rng.choice(cands)
    it = world.entities.get(iid)
    value = float(it.fields.get("value") or 0)
    dc = 12 + (3 if value >= 50 else 0) + (3 if value >= 500 else 0)
    ok, total, who = _check(world, members, "Sleight of Hand", dc, rng, bus, f"lifting the {it.name.lower()}")
    seen = witnesses(world, state, members, explorer, rng, exclude=(npc.id,), sneak=total, bus=bus)
    if not ok:
        seen = list(dict.fromkeys([npc.id] + seen))
        commit(world, state, "theft", town, seen, value, npc.id, bus)
        state.npc(npc.id)["disposition"] = "Hostile"
        return {"ok": False, "text": f"{npc.name} catches your hand on the {it.name.lower()}!", "seen": seen}
    trade_mem = state.npc(npc.id)
    trade_mem["stock"][iid] = stock[iid] - 1
    sid = take_stolen(world, state, iid, 1, town)
    commit(world, state, "theft", town, seen, value, npc.id, bus)
    return {"ok": True, "item": sid, "seen": seen,
            "text": f"{(who or {}).get('name', 'You')} palms {it.name}" + (" unseen." if not seen else ", but someone saw.")}


def pickpocket(world, state, members, npc, rng: random.Random | None = None, explorer=None, bus=None) -> dict:
    """Sleight of Hand against their eyes (passive Perception, 10 or 12 for a guard, +5 for a wary one)."""
    from game import neighborhood as NB
    from game import trade
    rng = rng or random.Random()
    town = world.entities.get(NB.npc_town(world, npc))
    dc = _passive(world, npc.id) + (5 if state.disposition(npc) in ("Wary", "Hostile") else 0)
    ok, total, who = _check(world, members, "Sleight of Hand", dc, rng, bus, f"{npc.name}'s purse")
    seen = witnesses(world, state, members, explorer, rng, exclude=(npc.id,), sneak=total, bus=bus)
    if not ok:
        seen = list(dict.fromkeys([npc.id] + seen))
        commit(world, state, "pickpocket", town, seen, 0, npc.id, bus)
        state.npc(npc.id)["disposition"] = "Hostile"
        return {"ok": False, "text": f"{npc.name} feels the hand in their pocket and shouts!", "seen": seen}
    purse = trade.purse(state, npc)
    take = min(purse, max(1, int(purse * rng.uniform(0.05, 0.2))), 50_00)
    state.npc(npc.id)["purse"] = purse - take
    state.add_copper(take, "picked a pocket")
    commit(world, state, "pickpocket", town, seen, take / 100, npc.id, bus)
    from game.state import money_text
    return {"ok": True, "copper": take, "seen": seen,
            "text": f"{(who or {}).get('name', 'You')} comes away with {money_text(take)}" +
                    (" and nobody the wiser." if not seen else ". Someone saw.")}


def broke_in(world, state, members, town, after_hours: bool, explorer=None, rng=None, bus=None, sneak=None) -> list:
    """A lock that isn't yours, picked or forced (and being inside after hours is trespass)."""
    rng = rng or random.Random()
    seen = witnesses(world, state, members, explorer, rng, sneak=sneak, bus=bus)
    commit(world, state, "lockpicking", town, seen, 0, "", bus)
    if after_hours:
        commit(world, state, "trespass", town, seen, 0, "", bus)
    return seen


def harmed(world, state, victim, killed: bool, seen: list[str], bus=None) -> dict:
    """A fight with townsfolk: assault, or murder."""
    from game import neighborhood as NB
    town = world.entities.get(NB.npc_town(world, victim))
    who = [w for w in seen if w != victim.id] + ([victim.id] if not killed else [])
    return commit(world, state, "murder" if killed else "assault", town, who, 0, victim.id, bus)


def activities(world, state, spot) -> list[dict]:
    """Crimes to try where the walking map isn't (the places panel), and the way to settle a bounty."""
    from game import bank, places, trade
    out = []
    if spot.kind not in ("street", "building") or spot.town is None:
        return out
    people = [n for n in places.people_in(world, spot, state) if not state.npc_dead(n.id)]
    merchant = next((n for n in people if trade.is_merchant(world, n)), None)
    if merchant is not None and spot.kind == "building":
        out.append({"label": f"Steal from {merchant.name}'s wares (a crime)", "target": f"crime:steal:{merchant.id}",
                    "enabled": True, "note": "Sleight of Hand", "group": "Crime"})
    mark = next((n for n in people if (n.fields.get("occupation") or "") != "Guard"), None)
    if mark is not None:
        out.append({"label": f"Pick {mark.name}'s pocket (a crime)", "target": f"crime:pickpocket:{mark.id}",
                    "enabled": True, "note": "Sleight of Hand", "group": "Crime"})
    if spot.kind == "building" and bank.is_bank(spot.building):
        out.append({"label": "Break into the vault (a crime)", "target": "crime:rob", "enabled": True,
                    "note": "Thieves' Tools", "group": "Crime"})
    key, gp = wanted_here(world, state)
    if gp and spot.kind == "building" and (spot.building.fields.get("kind") or "") in ("Jail", "Barracks", "Town hall"):
        out.append({"label": f"Answer for your bounty ({gp} gp)", "target": "law:face", "enabled": True,
                    "note": f"wanted in {realm_name(world, key)}", "group": "Crime"})
    return out


__all__ = ["activities", "commit", "bounty", "bounties", "wanted_here", "settle", "pay_fine", "go_to_jail", "guards_for",
           "witnesses", "onlookers", "steal", "pickpocket", "broke_in", "harmed", "is_fence", "fence_in",
           "will_buy_stolen", "take_stolen", "is_stolen", "realm_key", "realm_name", "should_confront",
           "confronted", "guard_prompt_options", "jail_days", "CROWD", "LEDGER", "data"]
