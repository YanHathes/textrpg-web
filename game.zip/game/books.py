"""Books, lore, libraries and colleges.

Books are items you can read (category Book, or anything tagged "book"). Most are written from the
world's own data the first time a world is opened, so every world has its own library (tagged "Library"):

    History      "{region}: A History"        lore entries; +2 on History checks about the region and its towns
    Religion     "The Way of {god}"            lore entries; +2 on Religion checks about the god's temples
    Bestiary     "Creatures of the {land}"     each creature's resistances and weaknesses shown in fights;
                                               +2 on checks about them
    Map          "Map of {region}"             the region's towns, landmarks and roads shown on the map
    Field guide  "Herbs and Ores of {region}"  what grows and lies there; two hidden deposits revealed (rumors)
    Manual       "{Kind} Enchantments"         magic recipes learned (game/crafting.py)
    Letters      "A Letter from {dungeon}"     leads to lairs and relics (rumors)

A book's fields: book_kind, pages (text: a blank line between pages), about (what it tells of), teaches
(magic items whose recipes it holds), reveals (places it shows on the map), read_minutes.

Reading takes time. The first read adds the book's entries to the Lore section of the journal, so the book
needn't be carried to be remembered (state.lore: {"read": [ids], "entries": [...], "topics": [ids],
"bestiary": [enemy ids], "notes": text, "loans": {book id: deposit copper}}).

Libraries (Library buildings; temple archives in towns and up) let the party read for free inside, or
borrow a book for a deposit. Bookshops (scholars) sell copies, and books turn up as loot.

Colleges (College buildings: some cities, every capital) run paid courses, played through the time-skip
scene: a language, a skill proficiency (expensive and long), spells for a wizard's spellbook (at the
SRD's cost: 50 gp and 2 hours a level), and magic recipes. Standing with the college's people lowers the
fees and opens the advanced courses.
"""
from __future__ import annotations

import random
import re
import zlib

LIB_VERSION = 1
BOOK_KINDS = ["History", "Religion", "Bestiary", "Map", "Field guide", "Manual", "Letters", "Other"]
LORE_SKILLS = {"History": {"History"}, "Religion": {"Religion"}, "Bestiary": {"Nature", "Arcana", "Religion",
                                                                                 "Survival", "Investigation"},
               "Field guide": {"Nature", "Survival"}, "Map": {"History", "Survival"}}
LORE_BONUS = 2
MAX_LETTERS = 60
LANG_DEFAULT = ["Common", "Dwarvish", "Elvish", "Giant", "Gnomish", "Goblin", "Halfling", "Orc", "Abyssal",
                "Celestial", "Draconic", "Deep Speech", "Infernal", "Primordial", "Sylvan", "Undercommon"]
COURSE = {"language": (150, 30), "skill": (400, 60), "recipes": (200, 10)}     # gp, days
TUITION = {"Friendly": 0.95, "Honored": 0.85, "Revered": 0.75}
ADVANCED = ("Honored", "Revered")
BORROW_DEPOSIT = 2.0                  # times the book's value (at least 5 gp)


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


def lore(state) -> dict:
    d = state.lore
    for k, f in (("read", list), ("entries", list), ("topics", list), ("bestiary", list), ("loans", dict)):
        d.setdefault(k, f())
    d.setdefault("notes", "")
    return d


def is_book(item) -> bool:
    if item is None:
        return False
    if (item.fields.get("category") or "") == "Book":
        return True
    tags = {str(t).lower() for t in item.tags or []}
    return "book" in tags and not any(w in item.name.lower() for w in ("ink", "pen", "paper", "parchment", "case"))


def kind_of(item) -> str:
    k = item.fields.get("book_kind") or ""
    if k:
        return k
    n = item.name.lower()
    if n.startswith("map of"):
        return "Map"
    if "bestiary" in n:
        return "Bestiary"
    if "herbalist" in n or "primer" in n:
        return "Field guide"
    if "hours" in n or "prayer" in n:
        return "Religion"
    if "log" in n or "letter" in n or "journal" in n:
        return "Letters"
    return "Other"


def pages(item) -> list[str]:
    txt = str(item.fields.get("pages") or "").strip()
    if not txt:
        txt = item.description or "The pages are blank."
    return [p.strip() for p in re.split(r"\n\s*\n", txt) if p.strip()]


def read_minutes(item) -> int:
    m = int(item.fields.get("read_minutes") or 0)
    if m:
        return m
    words = sum(len(p.split()) for p in pages(item))
    return max(15, min(8 * 60, int(words / 4)))           # slow, careful reading


# ----------------------------------------------------------------------------------------------------
# Writing the world's library
# ----------------------------------------------------------------------------------------------------
def gods(world) -> list[tuple[str, list]]:
    """(god, their temples) for the world's gods (from holy symbols named "(God)", and faction gods)."""
    names = []
    for i in world.entities.all("item"):
        if "holy" in {str(t).lower() for t in i.tags or []}:
            m = re.search(r"\(([^)]+)\)$", i.name)
            if m and m.group(1) not in names:
                names.append(m.group(1))
    for f in world.entities.all("faction"):
        g = f.fields.get("god") or ""
        if g and g not in names:
            names.append(g)
    temples = sorted(world.entities.by_field("building", "kind", "Temple"), key=lambda b: b.name.lower())
    out = []
    for g in names:
        mine = [b for b in temples if g.lower() in (b.name + " " + (b.description or "")).lower()]
        out.append((g, mine))
    return out


def _first(text: str) -> str:
    t = (text or "").strip()
    return (t.split(". ")[0].rstrip(".") + ".") if t else ""


def _book(world, made: list, name: str, kind: str, value: float, page_list: list[str], about=(), teaches=(),
          reveals=(), sprite: str = "icon/book_blue", desc: str = "") -> None:
    if world.entities.find_by_name("item", name) is not None:
        return
    f = {"category": "Book", "rarity": "Common", "value": value, "weight": 3, "stackable": False,
         "sprite": sprite, "book_kind": kind, "pages": "\n\n".join(p for p in page_list if p),
         "about": [a for a in about if a], "teaches": [t for t in teaches if t], "reveals": [r for r in reveals if r]}
    e = world.entities.create("item", name, f, desc or _first(page_list[0] if page_list else ""),
                              ["Library", "book"], save=False)
    made.append(e.id)


def ensure_library(world, force: bool = False) -> int:
    """Write the world's own books (once per world; a later version adds what's new). Returns how many."""
    if not force and int((world.meta or {}).get("library_v") or 0) >= LIB_VERSION:
        return 0
    from game import crafting
    from game import gathering as GA
    made: list = []
    store = world.entities
    towns_by_region: dict = {}
    for t in store.all("town"):
        rid = t.fields.get("region_ref") or ""
        towns_by_region.setdefault(rid, []).append(t)
    for reg in store.all("region"):
        towns = sorted(towns_by_region.get(reg.id, []), key=lambda t: -int(t.fields.get("population") or 0))
        lms = [lm for lm in store.all("landmark") if lm.fields.get("region") == reg.id]
        tids = {t.id for t in towns}
        dgs = [d for d in store.all("dungeon") if (d.fields.get("town") or "") in tids]
        p = [f"{reg.name}. {reg.description or ''}".strip()]
        lo, hi = int(reg.fields.get("level_min") or 1), int(reg.fields.get("level_max") or 4)
        p.append(f"The land is {str(reg.fields.get('biome') or 'open country').lower()}, and those who travel it "
                 f"should be ready for dangers fit for adventurers of level {lo} to {hi}.")
        for t in towns[:8]:
            p.append(f"{t.name}, a {str(t.fields.get('kind') or 'town').lower()}. {_first(t.description)}")
        if dgs or lms:
            p.append("Places of note: " + ", ".join(x.name for x in (lms + dgs)[:10]) + ".")
        _book(world, made, f"{reg.name}: A History", "History", 15, p, [reg.id] + [t.id for t in towns],
              sprite="icon/book_red")
        mp = [f"A map of {reg.name}, its roads and its places, drawn by a careful hand.",
              "Marked on it: " + ", ".join(x.name for x in towns[:12] + lms[:8]) + "."]
        _book(world, made, f"Map of {reg.name}", "Map", 10, mp, [reg.id], reveals=[x.id for x in towns + lms],
              sprite="icon/scroll")
        biome = reg.fields.get("biome") or "Plains"
        table = GA.drops_table(world)
        herbs = sorted({row[0] for k, rows in table.get("foraging", {}).items()
                        if k in (f"herb:{biome}", f"land:{biome}", "*") for row in rows})
        ores = ["Coal", "Copper Ore", "Iron Ore"] + (["Silver Ore", "Gold Nugget"] if int(reg.fields.get("danger") or 0)
                                                     >= 10 else [])
        fg = [f"What grows and what lies under the ground in {reg.name}.",
              "Herbs: " + ", ".join(herbs) + "." if herbs else "",
              "Ores: " + ", ".join(ores) + ". Rich veins and rare herbs hide in the wild places; the notes in the "
              "margins say where a few of them are."]
        _book(world, made, f"Herbs and Ores of {reg.name}", "Field guide", 12, fg, [reg.id], sprite="icon/book_blue")
    for g, temples in gods(world):
        rp = [f"The teachings of {g}, as the priests tell them.",
              f"The faithful of {g} keep shrines and temples across the land" +
              (": " + ", ".join(b.name for b in temples[:8]) + "." if temples else ".")]
        _book(world, made, f"The Way of {g[0].upper()}{g[1:]}", "Religion", 15, rp, [b.id for b in temples],
              sprite="icon/book_red")
    by_env: dict = {}
    for e in store.all("enemy"):
        if "summon" in (e.tags or []):
            continue
        for env in e.fields.get("environments") or []:
            by_env.setdefault(env, []).append(e)
    for env, es in sorted(by_env.items()):
        es = sorted(es, key=lambda e: (float(str(e.fields.get("cr") or 0).replace("1/", "0.") or 0), e.name))[:16]
        bp = [f"Creatures of the {env.lower()}: what they are, what hurts them and what doesn't."]
        for e in es:
            bits = []
            for key, word in (("vulnerabilities", "weak to"), ("resistances", "resists"), ("immunities", "immune to")):
                v = [str(x).lower() for x in e.fields.get(key) or []]
                if v:
                    bits.append(f"{word} {', '.join(v)}")
            bp.append(f"{e.name} (CR {e.fields.get('cr', '?')}): " + ("; ".join(bits) if bits else "no special defences") + ".")
        _book(world, made, f"Creatures of the {env}", "Bestiary", 25, bp, [e.id for e in es], sprite="icon/book_blue")
    rs = crafting.recipes(world)
    magic_by_kind: dict = {}
    for iid, r in rs.items():
        it = store.get(iid)
        if it is None or "magic" not in {str(t).lower() for t in it.tags or []}:
            continue
        if (it.fields.get("rarity") or "") not in ("Common", "Uncommon", "Rare"):
            continue
        magic_by_kind.setdefault(r.get("kind") or "other", []).append(it)
    for k, its in sorted(magic_by_kind.items()):
        its = sorted(its, key=lambda i: i.name)
        for vol in range(0, min(len(its), 24), 8):
            part = its[vol:vol + 8]
            title = f"{k.title()} Enchantments" + (f", Volume {vol // 8 + 1}" if len(its) > 8 else "")
            mp = [f"How to make {', '.join(i.name for i in part)}: the materials, the parts and the patience."]
            _book(world, made, title, "Manual", 150, mp, teaches=[i.id for i in part], sprite="icon/book_red")
    n = 0
    for d in sorted(store.all("dungeon"), key=lambda d: d.id):
        relic = next((i for i in store.all("item") if i.fields.get("found_in") == d.id), None)
        if relic is None and (d.fields.get("kind") or "") not in ("Lair",):
            continue
        town = store.get(d.fields.get("town") or "")
        lp = [f"A stained letter, its seal long broken. The writer was near {town.name if town else 'the old roads'}.",
              f"...if anyone finds this, do not go into {d.name}. " +
              (f"{relic.name} is there, I swear it, but so is whatever guards it." if relic else
               "Something has made its lair there, and it is always hungry...")]
        _book(world, made, f"A Letter from {d.name}", "Letters", 1, lp, [d.id], reveals=[d.id], sprite="icon/letter")
        n += 1
        if n >= MAX_LETTERS:
            break
    if made:
        store.save("item")
    world.meta["library_v"] = LIB_VERSION
    try:
        world.save_meta()
    except Exception:  # noqa: BLE001
        pass
    return len(made)


# ----------------------------------------------------------------------------------------------------
# Reading
# ----------------------------------------------------------------------------------------------------
def has_read(state, book_id: str) -> bool:
    return book_id in lore(state)["read"]


def read(world, state, book_id: str, bus=None, rng: random.Random | None = None) -> tuple[int, list[str]]:
    """Read a book (takes its time). The first read adds its lore and does what the book does. Returns
    (minutes, what came of it)."""
    from game import quality
    b = world.entities.get(quality.base_of(book_id))
    if b is None or not is_book(b):
        return 0, ["That isn't something to read."]
    minutes = read_minutes(b)
    state.advance(minutes, "reading")
    L = lore(state)
    if b.id in L["read"]:
        return minutes, [f"You read {b.name} again."]
    L["read"].append(b.id)
    kind = kind_of(b)
    out = [f"You read {b.name}."]
    L["entries"].append({"book": b.id, "title": b.name, "kind": kind, "text": " ".join(pages(b))[:1200],
                         "about": list(b.fields.get("about") or []), "day": state.day})
    for a in b.fields.get("about") or []:
        if a not in L["topics"]:
            L["topics"].append(a)
    if kind == "Bestiary":
        for a in b.fields.get("about") or []:
            e = world.entities.get(a)
            if e is not None and e.type == "enemy" and a not in L["bestiary"]:
                L["bestiary"].append(a)
        out.append("You'll know these creatures' weaknesses when you meet them.")
    if kind == "Map":
        shown = _reveal(world, state, b)
        if shown:
            out.append(f"{shown} place{'s' if shown != 1 else ''} marked on your map.")
    if kind == "Manual":
        known = set(state.recipes or [])
        new = [t for t in b.fields.get("teaches") or [] if t not in known and world.entities.get(t) is not None]
        if new:
            state.recipes = list(state.recipes or []) + new
            out.append("You learn how to make " + ", ".join(world.entities.get(t).name for t in new) + ".")
            if bus is not None:
                for t in new:
                    bus.emit("recipe.learned", item=t, text=f"New recipe: {world.entities.get(t).name}")
    if kind == "Field guide":
        got = _guide_deposits(world, state, b, rng, bus)
        if got:
            out.append(f"The notes in the margins point to {got} hidden place{'s' if got != 1 else ''} (see Rumors).")
    if kind == "Letters":
        from game import rumors
        for a in (b.fields.get("reveals") or b.fields.get("about") or [])[:1]:
            d = world.entities.get(a)
            if d is None:
                continue
            town = world.entities.get(d.fields.get("town") or "")
            if town is not None:
                r = rumors.hear(world, state, town, rng, source=b.name, kinds=("relic", "lair"), bus=bus, about=d.id)
                if r is not None:
                    out.append("It's a lead: " + r["text"])
    state.save()
    if bus is not None:
        bus.emit("lore.read", book=b.id)
        for line in out:
            bus.emit("log", kind="quest", text=line)
    return minutes, out


def _reveal(world, state, b) -> int:
    from game import geography as G
    from game import places
    n = 0
    for a in b.fields.get("reveals") or []:
        e = world.entities.get(a)
        if e is None:
            continue
        try:
            if e.type == "town":
                p = G.town_position(world, e)
            elif e.type == "landmark":
                p = G.landmark_position(world, e)
            elif e.type == "dungeon":
                p = G.dungeon_position(world, e)
            else:
                p = None
            if p is not None:
                G.reveal(world, state, p[0], p[1], 3)
                n += 1
        except Exception:  # noqa: BLE001 - a world without a map
            continue
    del places
    return n


def _guide_deposits(world, state, b, rng, bus) -> int:
    from game import rumors
    reg = next((world.entities.get(a) for a in b.fields.get("about") or [] if (world.entities.get(a) or None) is not None
                and world.entities.get(a).type == "region"), None)
    if reg is None:
        return 0
    towns = [t for t in world.entities.all("town") if t.fields.get("region_ref") == reg.id]
    rng = rng or _rng("guide", b.id)
    n = 0
    for t in sorted(towns, key=lambda t: t.id)[:6]:
        if n >= 2:
            break
        r = rumors.hear(world, state, t, rng, source=b.name, kinds=("deposit",), bus=bus)
        if r is not None:
            n += 1
    return n


def bonus(world, state, label: str, about: str = "") -> int:
    """+2 on a History, Religion, Nature... check about something the party has read of (or about where it
    is: its town, region or dungeon)."""
    if state is None:
        return 0
    L = lore(state)
    if not L["topics"] and not L["bestiary"]:
        return 0
    topics = set(L["topics"])
    want = {about} if about else set()
    if not about:
        try:
            from game import places
            spot = places.current(world, state)
            if spot.town is not None:
                want.add(spot.town.id)
                want.add(spot.town.fields.get("region_ref") or "")
            if spot.building is not None:
                want.add(spot.building.id)
            d = spot.extra.get("dungeon") if spot.extra else None
            if d is not None:
                want.add(d.id)
        except Exception:  # noqa: BLE001
            pass
    if about and about in L["bestiary"] and label in LORE_SKILLS["Bestiary"]:
        return LORE_BONUS
    if label in ("History", "Religion", "Nature", "Survival") and topics & want:
        return LORE_BONUS
    return 0


def bestiary_lines(world, state, enemy_ids) -> list[str]:
    """What the party's reading says about the creatures in a fight."""
    L = lore(state)
    out = []
    for eid in dict.fromkeys(enemy_ids):
        if eid not in L["bestiary"]:
            continue
        e = world.entities.get(eid)
        if e is None:
            continue
        bits = []
        for key, word in (("vulnerabilities", "weak to"), ("resistances", "resists"), ("immunities", "immune to"),
                          ("condition_immunities", "can't be")):
            v = [str(x).lower() for x in e.fields.get(key) or []]
            if v:
                bits.append(f"{word} {', '.join(v)}")
        out.append(f"From your reading: {e.name}: " + ("; ".join(bits) if bits else "nothing special hurts or stops it") + ".")
    return out


# ----------------------------------------------------------------------------------------------------
# Libraries and borrowing
# ----------------------------------------------------------------------------------------------------
def library_kind(world, building) -> str:
    """"library", "archives" (a temple in a town or bigger) or ""."""
    if building is None:
        return ""
    k = building.fields.get("kind") or ""
    if k == "Library" or "Scribe's desk" in (building.fields.get("facilities") or []) and k == "Library":
        return "library"
    if k == "Temple" or "Archives" in (building.fields.get("facilities") or []):
        town = world.entities.get(building.fields.get("town") or "")
        if town is not None and (town.fields.get("kind") or "") not in ("Hamlet", "Village"):
            return "archives"
    if k == "College":
        return "library"
    return ""


def shelf(world, building) -> list:
    """The books held here: a library has everything but old letters; temple archives the faiths and the
    region's history."""
    ensure_library(world)
    kind = library_kind(world, building)
    if not kind:
        return []
    town = world.entities.get(building.fields.get("town") or "")
    reg = town.fields.get("region_ref") if town is not None else ""
    out = []
    for i in world.entities.all("item"):
        if not is_book(i) or "magic" in {str(t).lower() for t in i.tags or []}:
            continue
        k = kind_of(i)
        if kind == "library" and k != "Letters":
            out.append(i)
        elif kind == "archives" and (k == "Religion" or (k == "History" and reg in (i.fields.get("about") or []))):
            out.append(i)
    return sorted(out, key=lambda i: (BOOK_KINDS.index(kind_of(i)) if kind_of(i) in BOOK_KINDS else 99, i.name))


SHELF_WORDS = {"History": "Histories", "Religion": "Faiths", "Bestiary": "Bestiaries", "Map": "Maps",
               "Field guide": "Field guides", "Manual": "Manuals", "Letters": "Letters", "Other": "Odds and ends"}


def on_shelf(world, building, n: int, of: int) -> tuple[str, list]:
    """What one of a building's bookshelves holds (n of `of`): its books are shared out over the shelves by
    kind, each kind kept together where there are shelves enough. Returns (a label for it, the books)."""
    every = shelf(world, building)
    if of <= 1 or not every:
        kinds = list(dict.fromkeys(kind_of(i) for i in every))
        return ", ".join(SHELF_WORDS.get(k, k) for k in kinds) or "Empty", every
    groups: dict = {}
    for i in every:
        groups.setdefault(kind_of(i), []).append(i)
    chunks = []                                   # (kind, books): big kinds split over several shelves
    per = max(1, -(-len(every) // of))
    for k, lst in groups.items():
        for j in range(0, len(lst), per):
            chunks.append((k, lst[j:j + per]))
    mine = [c for idx, c in enumerate(chunks) if idx % of == n % of]
    got = [i for _k, lst in mine for i in lst]
    kinds = list(dict.fromkeys(k for k, _l in mine))
    return ", ".join(SHELF_WORDS.get(k, k) for k in kinds) or "Empty", got


def deposit(item) -> int:
    return max(500, int(round(float(item.fields.get("value") or 0) * BORROW_DEPOSIT * 100)))


def borrow(world, state, book_id: str) -> tuple[bool, str]:
    b = world.entities.get(book_id)
    if b is None:
        return False, "No such book."
    cost = deposit(b)
    if cost > state.copper:
        from game.state import money_text
        return False, f"The deposit is {money_text(cost)}. You can't afford it."
    state.add_copper(-cost, f"deposit on {b.name}")
    lore(state)["loans"][book_id] = cost
    state.add_item(book_id, 1, source="borrowed")
    return True, f"You borrow {b.name}. Bring it back for your deposit."


def give_back(world, state, book_id: str) -> tuple[bool, str]:
    L = lore(state)
    cost = L["loans"].get(book_id)
    if cost is None or state.count(book_id) <= 0:
        return False, "You haven't a book of theirs."
    state.remove_item(book_id, 1, reason="returned")
    state.add_copper(int(cost), "deposit back")
    del L["loans"][book_id]
    state.save()
    b = world.entities.get(book_id)
    return True, f"You return {b.name if b else 'the book'} and get your deposit back."


# ----------------------------------------------------------------------------------------------------
# Colleges
# ----------------------------------------------------------------------------------------------------
def is_college(building) -> bool:
    return building is not None and (building.fields.get("kind") or "") == "College"


def _standing(world, state, npc) -> str:
    if npc is None:
        return "Neutral"
    try:
        from game import factions
        f = factions.primary(world, npc)
        return factions.level(world, state, f.id) if f is not None else ""
    except Exception:  # noqa: BLE001
        return ""


def courses(world, state, member: dict, npc=None) -> list[dict]:
    """What a college teaches this member: [{"kind", "label", "what", "gp", "days" or "hours", "advanced",
    "open", "why"}]."""
    from game import character as CH
    standing = _standing(world, state, npc)
    cheaper = TUITION.get(standing, 1.0)
    advanced_ok = standing in ADVANCED or standing == ""          # no faction: anyone may sit them
    out = []
    known_langs = set(member.get("languages") or [])
    race = world.entities.get(member.get("race") or "")
    if race is not None:
        known_langs |= set(race.fields.get("languages") or [])
    langs = list(LANG_DEFAULT)
    for r in world.entities.all("race"):
        for lang in r.fields.get("languages") or []:
            if lang not in langs:
                langs.append(lang)
    gp, days = COURSE["language"]
    for lang in langs:
        if lang not in known_langs:
            out.append({"kind": "language", "label": f"The {lang} language", "what": lang,
                        "gp": int(gp * cheaper), "days": days, "advanced": False, "open": True, "why": ""})
    gp, days = COURSE["skill"]
    for sk in sorted(world.entities.all("skill"), key=lambda e: e.name):
        if (sk.fields.get("kind") or "Skill") != "Skill" or sk.id in (member.get("skills") or []):
            continue
        out.append({"kind": "skill", "label": f"Proficiency in {sk.name}", "what": sk.id, "gp": int(gp * cheaper),
                    "days": days, "advanced": True, "open": advanced_ok,
                    "why": "" if advanced_ok else "Only for those the college thinks highly of (Honored)."})
    for k, lv, _sub in CH.classes_of(world, member):
        if CH.casting_style(k) != "Spellbook":
            continue
        top = min(9, (lv + 1) // 2)
        have = set(member.get("spells") or [])
        for sid in k.fields.get("spells") or []:
            sp = world.entities.get(sid)
            if sp is None or sid in have:
                continue
            sl = int(sp.fields.get("level") or 0)
            if sl < 1 or sl > top:
                continue
            out.append({"kind": "spell", "label": f"Copy {sp.name} (level {sl}) into the spellbook", "what": sid,
                        "gp": int(50 * sl * cheaper), "hours": 2 * sl, "advanced": False, "open": True, "why": ""})
    from game import crafting
    rs = crafting.recipes(world)
    have = set(state.recipes or [])
    gp, days = COURSE["recipes"]
    groups: dict = {}
    for iid, r in rs.items():
        it = world.entities.get(iid)
        if it is None or iid in have or "magic" not in {str(t).lower() for t in it.tags or []}:
            continue
        rar = it.fields.get("rarity") or "Uncommon"
        if rar not in ("Common", "Uncommon", "Rare"):
            continue
        groups.setdefault((rar, r.get("kind") or "other"), []).append(iid)
    for (rar, k), ids in sorted(groups.items()):
        adv = rar == "Rare"
        mult = {"Common": 1, "Uncommon": 2, "Rare": 6}[rar]
        out.append({"kind": "recipes", "label": f"{rar} {k} enchantments ({len(ids[:6])} recipes)", "what": ids[:6],
                    "gp": int(gp * mult * cheaper), "days": days * (2 if adv else 1), "advanced": adv,
                    "open": advanced_ok or not adv, "why": "" if (advanced_ok or not adv) else
                    "Only for those the college thinks highly of (Honored)."})
    return out


def take_course(world, state, member: dict, course: dict, bus=None) -> tuple[bool, str]:
    """Pay and study (the clock moves on by the course's length). Returns (done, message)."""
    if not course.get("open"):
        return False, course.get("why") or "That course isn't open to you."
    cost = int(course["gp"]) * 100
    if cost > state.copper:
        from game.state import money_text
        return False, f"The fee is {money_text(cost)}. You can't afford it."
    state.add_copper(-cost, f"tuition: {course['label']}")
    minutes = int(course.get("days", 0)) * 1440 + int(course.get("hours", 0)) * 60
    state.advance(minutes, "studying")
    who = member.get("name") or "They"
    k = course["kind"]
    if k == "language":
        member.setdefault("languages", [])
        member["languages"].append(course["what"])
        text = f"{who} can now speak, read and write {course['what']}."
    elif k == "skill":
        member.setdefault("skills", [])
        member["skills"].append(course["what"])
        sk = world.entities.get(course["what"])
        text = f"{who} is now proficient in {sk.name if sk else course['what']}."
    elif k == "spell":
        member.setdefault("spells", [])
        member["spells"].append(course["what"])
        sp = world.entities.get(course["what"])
        text = f"{who} copies {sp.name if sp else 'the spell'} into their spellbook."
    else:
        state.recipes = list(state.recipes or []) + [i for i in course["what"] if i not in (state.recipes or [])]
        text = "You learn to make " + ", ".join(world.entities.get(i).name for i in course["what"]
                                                if world.entities.get(i) is not None) + "."
    state.save()
    if bus is not None:
        bus.emit("log", kind="loot", text=text)
        bus.emit("course.done", member=member.get("id"), course=course["label"])
    return True, text


__all__ = ["on_shelf", "SHELF_WORDS", "ensure_library", "read", "is_book", "kind_of", "pages", "read_minutes", "bonus", "bestiary_lines",
           "shelf", "library_kind", "borrow", "give_back", "deposit", "courses", "take_course", "is_college", "lore",
           "has_read", "gods", "BOOK_KINDS"]
