"""The map's close-up tiers drawn from the walking map itself: a town as it lies on the walking map, seen
from above (roofs, streets, walls, gardens), a building's floors square for square, and a dungeon's.

Each plan carries a picture (one pixel per 5-foot square) and, for clicking and labels, where each
street, building and room is on it, in squares from the picture's top-left corner.

town_view(world, town) -> {
    "walk": True, "image": (w, h, rgb), "level", "origin": (x, y) squares of the picture's corner on its level,
    "streets":   [{"name", "x1", "y1", "x2", "y2", "cx", "cy"}],     (cx, cy: the middle of the street)
    "buildings": [{"id", "name", "kind", "street", "x", "y", "w", "h"}],
    "houses": [], "gates": [{"direction", "street", "x", "y", "road_to"}],
    "zones": {(x, y): street name or building id}  (for what's under the mouse)
    "bounds": (0, 0, w, h)}
building_floor(world, building, floor) -> {"image", "rooms": [rows with x, y, w, h in squares], "door"} | None
dungeon_floor(world, dungeon, floor, shown) -> {"image", "rects": {room: (x, y, w, h)}, "floors": [...]}
"""
from __future__ import annotations

from game import area as A
from game import places


def _town_area(world, town):
    """(area, level, rect, gates) of the town's walking map: its site on the world's walking map (or its own
    map, when the world isn't walkable)."""
    from game import worldmap as WM
    if not town.fields.get("settlement") and WM.walkable(world):
        site = WM.peek_site(world, "town", town)
        if site is not None:
            gates = getattr(site, "gates", None)
            wa = getattr(world, "_world_area", None)
            if gates is None and wa is not None:
                gates = wa.town_gates.get(town.id)
            return site.area, site.base, site.rect, dict(gates or {})
    a = A.town_area(world, town)
    lv = a.base
    return a, lv, (lv.ox, lv.oy, lv.w, lv.h), dict(a.gates_of(town) or {})


def town_view(world, town) -> dict | None:
    from game import mapimage as MI
    try:
        a, lv, rect, gates = _town_area(world, town)
    except Exception:  # noqa: BLE001 - the old schematic plan does instead
        return None
    x0, y0, w, h = rect
    rgb = None
    if not town.fields.get("settlement"):
        from game import worldmap as WM
        if WM.walkable(world):
            pic = MI.site_picture(world, "town", town.id)
            if pic is not None and tuple(pic[0]) == tuple(rect):
                rgb = pic[1]
    if rgb is None:
        rgb = MI.area_picture(a, lv, rect, roofs=True)
    # where each street is
    names = {places.street_id(town.id, s["name"]): s["name"] for s in places.streets_of(town)}
    cells: dict[str, list] = {}
    zones: dict = {}
    for j in range(h):
        for i in range(w):
            loc = lv.loc_at(x0 + i, y0 + j)
            n = names.get(loc)
            if n is not None:
                cells.setdefault(n, []).append((i, j))
                zones[(i, j)] = n
    streets = []
    for n, cs in cells.items():
        xs, ys = [c[0] for c in cs], [c[1] for c in cs]
        mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
        mid = min(cs, key=lambda c: (c[0] - mx) ** 2 + (c[1] - my) ** 2)
        if max(xs) - min(xs) >= max(ys) - min(ys):
            x1, y1, x2, y2 = min(xs), mid[1] + 0.5, max(xs) + 1, mid[1] + 0.5
        else:
            x1, y1, x2, y2 = mid[0] + 0.5, min(ys), mid[0] + 0.5, max(ys) + 1
        streets.append({"name": n, "x1": x1, "y1": y1, "x2": x2, "y2": y2, "cx": mid[0] + 0.5, "cy": mid[1] + 0.5})
    buildings = []
    for bid, info in a.buildings.items():
        b = world.entities.get(bid)
        if b is None:
            continue
        bx, by, bw, bh = info["rect"]
        row = {"id": bid, "name": b.name, "kind": b.fields.get("kind") or "",
               "street": places.street_of_building(world, b), "x": bx - x0, "y": by - y0, "w": bw, "h": bh}
        buildings.append(row)
    for c, bid in a.cell_building.items():
        if bid in a.buildings and x0 <= c[0] < x0 + w and y0 <= c[1] < y0 + h:
            zones[(c[0] - x0, c[1] - y0)] = bid
    out_gates = []
    roads = {r.get("direction"): r for r in places.roads_of(town)}
    for direction, (gx, gy) in gates.items():
        near = min(streets, key=lambda s: (s["cx"] - (gx - x0)) ** 2 + (s["cy"] - (gy - y0)) ** 2, default=None)
        out_gates.append({"direction": direction, "street": near["name"] if near else "",
                          "x": gx - x0 + 0.5, "y": gy - y0 + 0.5, "from_x": gx - x0 + 0.5, "from_y": gy - y0 + 0.5,
                          "road_to": (roads.get(direction) or {}).get("leads_to") or ""})
    return {"walk": True, "image": (w, h, rgb), "level": lv, "area": a, "origin": (x0, y0), "streets": streets,
            "buildings": buildings, "houses": [], "gates": out_gates, "zones": zones, "bounds": (0, 0, w, h)}


def hidden_town_picture(plan: dict, hidden_streets: set) -> bytes:
    """The town picture with the streets not yet seen (and the buildings on them) in shadow."""
    w, h, rgb = plan["image"]
    if not hidden_streets:
        return rgb
    hidden_b = {b["id"] for b in plan["buildings"] if b["street"] in hidden_streets}
    buf = bytearray(rgb)
    for (i, j), z in plan["zones"].items():
        if z in hidden_streets or z in hidden_b:
            k = (j * w + i) * 3
            buf[k] = buf[k] // 3
            buf[k + 1] = buf[k + 1] // 3
            buf[k + 2] = buf[k + 2] // 3
    return bytes(buf)


# ======================================================================
# Buildings
# ======================================================================
def building_floor(world, b, floor: int) -> dict | None:
    """One floor of a building as the walking map has it: its picture, and each room's place on it."""
    from game import mapimage as MI
    from game import rooms as R
    town = world.entities.get(b.fields.get("town") or "")
    if town is None:
        return None
    try:
        a, _lv, _rect, _g = _town_area(world, town)
    except Exception:  # noqa: BLE001
        return None
    info = a.buildings.get(b.id)
    if info is None:
        return None
    key = (info.get("levels") or {}).get(floor)
    lv = a.base if floor == 0 and key is not None else a.levels.get(key) if key is not None else None
    if lv is None:
        return None
    bx, by, bw, bh = info["rect"]
    pad = 1
    rect = (bx - pad, by - pad, bw + 2 * pad, bh + 2 * pad)
    below = a.base if floor > 0 else None
    rgb = MI.area_picture(a, lv, rect, roofs=False, below=below)
    rows = R.ensure(world, b)
    out = []
    for row in rows:
        if int(row.get("floor") or 0) != floor:
            continue
        loc = A._room_loc(b.id, rows, row)
        cs = [(x - rect[0], y - rect[1]) for y in range(rect[1], rect[1] + rect[3])
              for x in range(rect[0], rect[0] + rect[2]) if lv.loc_at(x, y) == loc and
              lv.floor_at(x, y) not in A.SOLID and (x, y) not in lv.walls]
        if not cs:
            continue
        xs, ys = [c[0] for c in cs], [c[1] for c in cs]
        r = dict(row)
        r.update({"x": min(xs), "y": min(ys), "w": max(xs) - min(xs) + 1, "h": max(ys) - min(ys) + 1})
        out.append(r)
    door = info.get("door")
    return {"image": (rect[2], rect[3], rgb), "rooms": out, "rect": rect,
            "door": (door[0] - rect[0] + 0.5, door[1] - rect[1] + 0.5) if door and floor == 0 else None}


# ======================================================================
# Dungeons
# ======================================================================
def dungeon_floor(world, d, floor: int, shown: dict | None = None) -> dict | None:
    """One floor of a dungeon as its walking map has it. shown: room name -> 'here' / 'visited' / 'seen' / ''
    (rooms not shown are left dark, and the passages to them)."""
    from game import dungeons as DG
    from game import mapimage as MI
    try:
        a = A.dungeon_area(world, d)
    except Exception:  # noqa: BLE001
        return None
    lv = a.levels.get(f"f{floor}")
    if lv is None:
        return None
    rows = DG.rooms(d)
    locs = {DG.room_id(d.id, r["name"]): r["name"] for r in rows if int(r.get("floor") or 0) == floor}
    room_cells: dict[str, list] = {}
    open_cells = []
    for y in range(lv.h):
        for x in range(lv.w):
            f = lv.floor_at(x, y)
            if f in A.SOLID and (x, y) not in lv.walls:
                continue
            open_cells.append((x, y))
            n = locs.get(lv.loc_at(x, y))
            if n is not None and (x, y) not in lv.walls:
                room_cells.setdefault(n, []).append((x, y))
    if not open_cells:
        return None
    xs, ys = [c[0] for c in open_cells], [c[1] for c in open_cells]
    rect = (min(xs) - 1, min(ys) - 1, max(xs) - min(xs) + 3, max(ys) - min(ys) + 3)
    rgb = bytearray(MI.area_picture(a, lv, rect, roofs=False))
    rects = {}
    for n, cs in room_cells.items():
        cx, cy = [c[0] for c in cs], [c[1] for c in cs]
        rects[n] = (min(cx) - rect[0], min(cy) - rect[1], max(cx) - min(cx) + 1, max(cy) - min(cy) + 1)
    if shown is not None:
        _dungeon_fog(lv, rect, rgb, room_cells, shown, MI.palette()["earth"])
    return {"image": (rect[2], rect[3], bytes(rgb)), "rects": rects, "rect": rect}


def _dungeon_fog(lv, rect, rgb: bytearray, room_cells: dict, shown: dict, earth) -> None:
    """Rooms not known yet are solid rock on the picture; rooms only glimpsed are dim; a passage shows once a
    room it leads from has been seen."""
    x0, y0, w, h = rect
    visible = set()
    dim = set()
    for n, cs in room_cells.items():
        st = shown.get(n, "")
        if st in ("here", "visited"):
            visible.update(cs)
        elif st == "seen":
            dim.update(cs)
    in_room = {c for cs in room_cells.values() for c in cs}
    # walls round what's shown, and the passages leading out of it
    frontier = list(visible)
    seen = set(visible)
    while frontier:
        x, y = frontier.pop()
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                c = (x + dx, y + dy)
                if c in seen or c in in_room:
                    continue
                seen.add(c)
                if c in lv.walls or c in lv.doors:
                    visible.add(c)
                elif lv.inside(*c) and lv.floor_at(*c) not in A.SOLID and dx * dy == 0:
                    visible.add(c)
                    frontier.append(c)
    for c in list(dim):
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                n = (c[0] + dx, c[1] + dy)
                if n in lv.walls:
                    dim.add(n)
    for j in range(h):
        for i in range(w):
            c = (x0 + i, y0 + j)
            if c in visible:
                continue
            k = (j * w + i) * 3
            if c in dim:
                rgb[k], rgb[k + 1], rgb[k + 2] = rgb[k] // 3, rgb[k + 1] // 3, rgb[k + 2] // 3
            else:
                rgb[k], rgb[k + 1], rgb[k + 2] = earth[0] // 2, earth[1] // 2, earth[2] // 2


__all__ = ["town_view", "hidden_town_picture", "building_floor", "dungeon_floor"]
