"""The catch-up step: work out what happened while time passed, only when it's needed.

Nothing in the game runs every tick. Each system that changes over time (crafting, building, regrowth,
workers, income, taxes, loans, hunger...) registers a catch-up function here:

    ticker.register("regrowth", fn)          # fn(world, state, since_minute, now_minute)

When the clock moves forward (GameState.advance) or the party arrives somewhere (places.enter), every
registered function is called once with the minutes since it last ran, and works out everything that
happened in between in one go. The first time a function sees a save it only notes the time, so nothing
is back-dated onto old saves.

It also answers "what changed since the player last saw this?": mark_seen() notes when something was in
view, since_seen() says how long ago that was (the work bars over NPCs use it).
"""
from __future__ import annotations

from typing import Callable

CatchUp = Callable[[object, object, int, int], None]

_REGISTRY: dict[str, CatchUp] = {}


def register(name: str, fn: CatchUp) -> None:
    """Add (or replace) a catch-up function. Called in the order they were first registered."""
    _REGISTRY[name] = fn


def unregister(name: str) -> None:
    _REGISTRY.pop(name, None)


def registered() -> list[str]:
    return list(_REGISTRY)


def run(state, now: int | None = None) -> list[str]:
    """Catch every system up to `now` (default: the clock). Returns the names that did any work."""
    if state is None:
        return []
    now = int(state.minutes if now is None else now)
    ticks = state.ticks
    done = []
    for name, fn in list(_REGISTRY.items()):
        last = ticks.get(name)
        if last is None:                      # first sight of this save: start counting from now
            ticks[name] = now
            continue
        if now <= int(last):
            continue
        ticks[name] = now
        fn(state.world, state, int(last), now)
        done.append(name)
    return done


# ----------------------------------------------------------------------
# "Since you last saw it"
# ----------------------------------------------------------------------
def mark_seen(state, key: str, minute: int | None = None) -> None:
    state.npc_seen[key] = int(state.minutes if minute is None else minute)


def last_seen(state, key: str) -> int | None:
    v = state.npc_seen.get(key)
    return None if v is None else int(v)


def since_seen(state, key: str) -> int | None:
    """Minutes since this was last in view (None if never)."""
    v = last_seen(state, key)
    return None if v is None else max(0, int(state.minutes) - v)


__all__ = ["register", "unregister", "registered", "run", "mark_seen", "last_seen", "since_seen"]
