"""Tools and proficiency from use.

Each party member counts their own uses of each tool (member["tool_uses"]: {tool key: count}); a use is one
lock picked, one successful check with a tool, one successful gathering try (step 7), one day of crafting
(step 8), one game played with a gaming set (step 12)...

    100 uses      proficiency     the proficiency bonus
    1,000         expertise       2 x the proficiency bonus
    10,000        mastery         4 x the proficiency bonus

A tool key is a tool skill's id ("skill.smith-s-tools", "skill.thieves-tools") or, for work with no SRD tool
proficiency, "work:<kind>" (work:woodcutting, work:mining, work:fishing, work:foraging, work:harvesting).

Trainers (the NPCs with something in their "Trains" field) sell proficiency for a large sum: the world rule
"training_price" (gp) scaled by the tool, less for those whose faction thinks well of you. Expertise and
mastery only come from use.

Tool items name what they speed up with a tag, "tool: woodcutting"; work_of() reads it.
"""
from __future__ import annotations

LEVELS = [(10000, "Mastery", 4), (1000, "Expertise", 2), (100, "Proficient", 1)]
MILESTONES = [100, 1000, 10000]
WORK = {"woodcutting": "Woodcutting", "mining": "Mining", "fishing": "Fishing", "foraging": "Foraging",
        "harvesting": "Harvesting", "skinning": "Skinning", "trapping": "Trapping"}
PRICE_SCALE = {"skill.thieves-tools": 1.5, "skill.smith-s-tools": 1.25, "skill.alchemist-s-supplies": 1.5,
               "skill.jeweler-s-tools": 1.25, "skill.navigator-s-tools": 1.25, "skill.tinker-s-tools": 1.25}
CHEAPER = {"Friendly": 0.95, "Honored": 0.85, "Revered": 0.75}
# tool items -> what they're for (the tag every tool carries; these are the SRD's own, which the More pack tags)
SRD_WORK = {"item.pick-miner-s": "mining", "item.fishing-tackle": "fishing", "item.herbalism-kit": "foraging",
            "item.handaxe": "woodcutting"}


def label(world, key: str) -> str:
    if key.startswith("work:"):
        return WORK.get(key[5:], key[5:].title())
    e = world.entities.get(key)
    return e.name if e is not None else key


def uses(m: dict, key: str) -> int:
    return int((m.get("tool_uses") or {}).get(key, 0))


def level(world, m: dict, key: str) -> tuple[str, int]:
    """("", 0) untrained; ("Proficient", 1); ("Expertise", 2); ("Mastery", 4): the bonus is that times the
    proficiency bonus. Training, or proficiency from class, background or race, counts as Proficient."""
    n = uses(m, key)
    for need, name, mult in LEVELS:
        if n >= need:
            return name, mult
    trained = key in (m.get("trained") or []) or key in (m.get("skills") or [])
    if not trained and world is not None:
        race = world.entities.get(m.get("race") or "")
        trained = race is not None and key in (race.fields.get("skills") or [])
    return ("Proficient", 1) if trained else ("", 0)


def next_milestone(m: dict, key: str) -> int | None:
    n = uses(m, key)
    return next((x for x in MILESTONES if x > n), None)


def record_use(world, m: dict, key: str, n: int = 1, bus=None) -> str:
    """Count uses of a tool. Returns the level reached if this crossed a milestone ("" otherwise), and says so
    (a popup in the top right, and the log)."""
    if not key or n <= 0:
        return ""
    before = level(world, m, key)[0]
    tu = dict(m.get("tool_uses") or {})
    old = int(tu.get(key, 0))
    tu[key] = old + n
    m["tool_uses"] = tu
    crossed = [x for x in MILESTONES if old < x <= tu[key]]
    if not crossed:
        return ""
    after = level(world, m, key)[0]
    if after == before:
        return ""
    name = label(world, key)
    text = {"Proficient": f"{m.get('name')} is now proficient with {name}.",
            "Expertise": f"{m.get('name')} has expertise with {name} (twice the proficiency bonus).",
            "Mastery": f"{m.get('name')} has mastered {name} (four times the proficiency bonus)."}[after]
    if bus is not None:
        bus.emit("tool.milestone", member=m.get("id"), tool=key, level=after, text=text)
        bus.emit("log", kind="loot", text=text)
    return after


def work_of(item) -> str:
    """What a tool item speeds up ("woodcutting"...), from its "tool: ..." tag; "" for anything else."""
    if item is None:
        return ""
    for t in item.tags or []:
        t = str(t)
        if t.lower().startswith("tool:"):
            return t.split(":", 1)[1].strip().lower()
    return SRD_WORK.get(item.fields.get("base_item") or item.id, "")


def best_tool(world, m: dict, state, work: str):
    """The best item the member (or the party's pack) has for some work: (item, speed multiplier), or
    (None, 1.0) when they'd do it by hand."""
    best, mult = None, 0.0
    held = dict(state.inventory if state is not None else {})
    for k, v in (m.get("inventory") or {}).items():
        held[k] = held.get(k, 0) + v
    for item_id, n in held.items():
        if n <= 0:
            continue
        item = world.entities.get(item_id)
        if item is not None and work_of(item) == work:
            q = float(item.fields.get("tool_speed") or 1.0)
            if q > mult:
                best, mult = item, q
    return (best, mult) if best is not None else (None, 1.0)


# ----------------------------------------------------------------------------------------------------
# Training
# ----------------------------------------------------------------------------------------------------
def trains(world, npc) -> list[str]:
    """The tool keys an NPC teaches."""
    got = npc.fields.get("trains") if npc is not None else None
    if not got:
        return []
    return [got] if isinstance(got, str) else [k for k in got if k]


def price(world, state, key: str, npc=None) -> int:
    """Copper to be trained (proficiency only)."""
    gp = float(world.rules.get("training_price", 500) or 500) * PRICE_SCALE.get(key, 1.0)
    if npc is not None and state is not None:
        try:
            from game import factions
            f = factions.primary(world, npc)
            if f is not None:
                gp *= CHEAPER.get(factions.level(world, state, f.id), 1.0)
        except Exception:  # noqa: BLE001 - no factions: the full price
            pass
    return int(round(gp * 100))


def can_train(world, m: dict, key: str) -> tuple[bool, str]:
    lvl = level(world, m, key)[0]
    if lvl:
        return False, f"{m.get('name')} is already {lvl.lower()} with {label(world, key)}."
    return True, ""


def train(world, state, m: dict, key: str, npc=None, bus=None) -> tuple[bool, str]:
    """Pay to be made proficient with a tool."""
    ok, why = can_train(world, m, key)
    if not ok:
        return False, why
    cost = price(world, state, key, npc)
    if cost > state.copper:
        from game.state import money_text
        return False, f"That costs {money_text(cost)}. You can't afford it."
    state.add_copper(-cost, f"training in {label(world, key)}")
    tr = list(m.get("trained") or [])
    tr.append(key)
    m["trained"] = tr
    text = f"{m.get('name')} is now proficient with {label(world, key)}."
    if bus is not None:
        bus.emit("tool.milestone", member=m.get("id"), tool=key, level="Proficient", text=text)
        bus.emit("log", kind="loot", text=text)
    return True, text


def sheet_rows(world, m: dict) -> list[list[str]]:
    """For the character sheet: each tool used or known, its level and the next milestone."""
    keys = set((m.get("tool_uses") or {}).keys()) | set(m.get("trained") or [])
    for sid in m.get("skills") or []:
        e = world.entities.get(sid)
        if e is not None and (e.fields.get("kind") or "") == "Tool":
            keys.add(sid)
    rows = []
    for key in sorted(keys, key=lambda k: label(world, k)):
        lvl, _mult = level(world, m, key)
        n = uses(m, key)
        nxt = next_milestone(m, key)
        bits = [lvl or "Untrained", f"{n:,} uses"]
        if nxt:
            bits.append(f"next at {nxt:,}")
        rows.append([label(world, key), "  ·  ".join(bits)])
    return rows


__all__ = ["level", "uses", "record_use", "work_of", "best_tool", "trains", "price", "train", "can_train",
           "sheet_rows", "label", "LEVELS", "MILESTONES", "WORK"]
