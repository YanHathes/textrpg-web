"""Property and construction (build plan step 14): land, blueprints, building, workers and what they make.

Everything here belongs to one playthrough and lives in the save's holdings (game/holdings.py). The world only
holds the Blueprints (world data, editable in the Library like any other entity).

Land (holdings["claims"])
    Town lots      the empty lots with a "For sale" sign (game/townlayout.py), bought from the townsperson the
                   sign points to (lots.seller). The price goes by the town's tier (LOT_PRICE).
    Wild claims    any land outside a town that isn't water and lies at least MIN_TOWN_MILES from every town.
                   Since Hotfix 18 a claim is made in person: walk out onto the land and stake it there (it's
                   marked on the map, but it's not yours to build on yet), then take it to the town hall of the
                   nearest town that has one (registrar) and register it with the clerk, paying the price for the
                   right to build on it and develop it (register). Nothing can be built, and a settlement isn't
                   founded, until then. Every wild claim is one of:
                       Property             one map chunk (32 x 32 squares). Never grows. Can become a settlement
                                            later (not back).
                       Starter settlement   3 x 3 chunks, costs more, and you name it. It starts as a Camp
                                            (holdings["settlements"]: grown by step 15).

    {"id", "kind": "lot" | "property" | "settlement", "name", "town" (the lot's town, or for a wild claim the town
     whose town hall registers it), "lot" (lot number), "rect" [x, y, w, h] (a wild claim, in world squares),
     "paid" (registered), "price", "day", "settlement" (its settlement's id, once registered)}

Blueprints (entities of type "blueprint")
    What a building needs and gives: its footprint (squares, walls included), its rooms (or an open style: a farm,
    a pen, a yard, a well, a wall or a gate), materials, labor (gp of work), daily upkeep, how many may work
    there, and what it provides: a home, crafting stations, resources each day (base and rare), income, storage,
    a mooring, a stable, defence.

Building
    A building is placed on the walking map inside a claim (rotated a quarter turn at a time, never overlapping
    another), as a save-owned building entity (fields: claim, blueprint, place {x, y, rot} from the claim's corner,
    status planned / building / done). Starting work takes the materials. Work goes as crafting does:
    days = labor / (5 gp x workers), the party counting as one worker and every hired hand or automaton on the
    site as another (an automaton by its grade's speed), up to the footprint's cap.

Workers (holdings["workers"])
    {"id", "kind": "hired" | "automaton", "npc" (the NPC: a townsperson, or the automaton's own save-owned NPC),
     "skilled", "wage" (gp a day), "grade" (an automaton's), "building" (where they work)}
    Hired hands are paid SRD wages (2 gp a day skilled, 2 sp untrained: the world rules wage_skilled and
    wage_untrained) and walk to work on their daily schedule (WORK_HOURS). Skilled hands sometimes turn up
    something rare. Automatons, bought once from an automaton workshop, need no pay; in a resource building each
    makes twice a hand's output, at its grade's speed, but only ever the base resource.

The catch-up step ("estate", game/ticker.py) runs construction, production, income, upkeep and wages for the
time that passed. Farms follow the season. Output piles up in the building (STORE_CAP, more with a storehouse
on the same claim) until it's collected.
"""
from __future__ import annotations

import math
import random
import zlib

DAY = 1440
PACE = 5.0                                   # gp of work a worker does in a day (world rule craft_pace)
LOT_PRICE = {"Camp": 25, "Hamlet": 60, "Village": 120, "Town": 300, "City": 600, "Capital": 1200}
CLAIMS = {"property": {"label": "Property", "chunks": 1, "price": 150},
          "settlement": {"label": "Starter settlement", "chunks": 3, "price": 750}}
CHUNK = 32                                   # squares per side of a map chunk (game/worldmap.py)
MIN_TOWN_MILES = 1.0                         # how far a wild claim must be from any town
AUTOMATON = {"Poor": (150, 0.75), "Standard": (400, 1.0), "Fine": (900, 1.25), "Masterwork": (2500, 1.5),
             "Legendary": (7500, 2.0)}       # grade -> (price in gp, work speed)
AUTOMATON_OUTPUT = 2.0                       # an automaton makes twice a hand's output (base resource only)
SEASON_FACTOR = {"Spring": 0.5, "Summer": 1.0, "Autumn": 1.5, "Winter": 0.0}
INCOME_FACTOR = {"Camp": 0.5, "Hamlet": 0.6, "Village": 0.8, "Town": 1.0, "City": 1.4, "Capital": 1.8}
WILD_INCOME = 0.4                            # a shop in the wilds sees few customers
STORE_CAP = 500                              # of each building's output, before it's collected
RARE_CHANCE = 0.06                           # a skilled hand's chance a day of turning up something rare
WORK_HOURS = (8, 18)
NO_HIRE = {"Guard", "Noble", "Priest", "Merchant", "Innkeeper", "Banker", "Mercenary"}
STYLES = ["building", "farm", "pen", "yard", "well", "wall", "gate", "mine"]
PROVIDES = ["Home", "Workshop", "Resources", "Income", "Storage", "Water", "Stable", "Dock", "Defense"]
BLUEPRINTS_V = 2


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


# ======================================================================
# The starting blueprints
# ======================================================================
def _room(name, role, tile, x, y, w, h, connects=""):
    return {"name": name, "type": role, "tile": tile, "floor": 0, "x": x, "y": y, "w": w, "h": h,
            "connects": connects}


def _bp(name, kind, w, h, desc, materials, labor, upkeep, provides, style="building", rooms=(), stations=(),
        produces=(), rare=(), seasonal=False, income=0.0, storage=0, defense=0, workers=0, water=False, since=1):
    return {"name": name, "description": desc, "since": since, "fields": {
        "kind": kind, "style": style, "w": w, "h": h, "rooms": [dict(r) for r in rooms],
        "materials": [{"item": n, "count": c} for n, c in materials], "labor": labor, "upkeep": upkeep,
        "provides": provides, "stations": list(stations), "produces": [{"item": n, "per_day": d} for n, d in produces],
        "rare": [{"item": n, "weight": wt} for n, wt in rare], "seasonal": seasonal, "income": income,
        "storage": storage, "defense": defense, "workers": workers, "water": water}}


_WORKROOM = [_room("Workshop", "Work", "Workshop", 0, 0, 7, 6)]
_WORKSHOPS = [("Forge", "Smithy", "Forge", [("Stone Block", 20), ("Iron Ingot", 6), ("Timber Plank", 10)],
               "A stone-walled smithy with a forge and anvil."),
              ("Carpenter's Workshop", "Workshop", "Carpenter's bench", [("Timber Plank", 24), ("Iron Ingot", 2)],
               "Sawhorses, shavings and a carpenter's bench."),
              ("Tannery", "Workshop", "Tannery", [("Timber Plank", 18), ("Stone Block", 6)],
               "Racks and vats for curing hides (and a smell to go with them)."),
              ("Weaving Shed", "Workshop", "Loom", [("Timber Plank", 20)], "A bright shed round a big loom."),
              ("Alchemy Lab", "Workshop", "Alchemy lab", [("Stone Block", 16), ("Timber Plank", 10), ("Iron Ingot", 2)],
               "Glassware, burners and a fume hood."),
              ("Scriptorium", "Workshop", "Scribe's desk", [("Timber Plank", 18), ("Stone Block", 6)],
               "A quiet room with a scribe's desk under a good window."),
              ("Jeweler's Workshop", "Workshop", "Jeweler's bench", [("Stone Block", 14), ("Timber Plank", 10),
                                                                      ("Iron Ingot", 2)],
               "A jeweler's bench, lenses and a strongbox."),
              ("Cookhouse", "Workshop", "Kitchen", [("Stone Block", 12), ("Timber Plank", 14)],
               "A kitchen with a big stove for cooking in quantity.")]

BUILTIN: list[dict] = [
    _bp("House", "House", 8, 7, "A small timber house: a front room and a bedroom. Somewhere to sleep for free.",
        [("Timber Plank", 24), ("Stone Block", 8)], 120, 0.5, "Home",
        rooms=[_room("Front Room", "Entrance", "Front Room", 0, 0, 4, 6),
               _room("Bedroom", "Private", "Bedroom", 4, 0, 3, 6, "Front Room")], workers=2),
] + [
    _bp(n, kind, 8, 7, d, mats, 150, 1.0, "Workshop", rooms=_WORKROOM, stations=[st], workers=3)
    for n, kind, st, mats, d in _WORKSHOPS
] + [
    _bp("Farm", "Other", 16, 12, "Fenced fields of grain. Worked by hands or automatons, it gives a harvest every "
        "day, more in autumn and none in winter.", [("Timber Plank", 12)], 60, 0.5, "Resources", style="farm",
        produces=[("Wild Wheat", 4)], rare=[("Flax", 3), ("Wild Barley", 3), ("Sack of Apples", 1)], seasonal=True,
        workers=6),
    _bp("Lumber Camp", "Other", 12, 10, "A yard of sawhorses and log piles at the edge of the trees.",
        [("Timber Plank", 10), ("Iron Ingot", 2)], 80, 0.5, "Resources", style="yard",
        produces=[("Oak Log", 3)], rare=[("Ironwood Log", 1)], workers=4),
    _bp("Mine Shaft", "Other", 8, 8, "A timbered shaft head over a seam of ore.",
        [("Timber Plank", 20), ("Stone Block", 10), ("Iron Ingot", 4)], 200, 1.0, "Resources", style="mine",
        rooms=[_room("Shaft Head", "Work", "", 0, 0, 7, 7)],
        produces=[("Iron Ore", 2)], rare=[("Silver Ore", 4), ("Gold Nugget", 2), ("Sapphire", 1), ("Emerald", 1),
                                          ("Mithral Ore", 1)], workers=3),
    _bp("Stable", "Stable", 12, 8, "Stalls and a tack room: your mounts are kept here for free.",
        [("Timber Plank", 30)], 100, 0.5, "Stable", stations=["Stable yard"],
        rooms=[_room("Stable Yard", "Entrance", "Stable Yard", 0, 0, 7, 7),
               _room("Stalls", "Common", "Stalls", 7, 0, 4, 7, "Stable Yard")], workers=2),
    _bp("Dock", "Other", 8, 6, "A timber jetty on the water: moor a boat here. Hands on it fish.",
        [("Timber Plank", 30)], 100, 0.5, "Dock", style="yard", produces=[("Trout", 2)], workers=2, water=True,
        stations=["Dock"]),
    _bp("Livestock Pen", "Other", 10, 8, "A fenced pen of sheep and goats: wool and milk.",
        [("Timber Plank", 12)], 50, 0.5, "Resources", style="pen", produces=[("Wool Fleece", 1), ("Pail of Milk", 1)],
        workers=2),
    _bp("Shop", "Shop", 8, 7, "A shop front with a counter. Staffed, it sells and brings in money.",
        [("Timber Plank", 20), ("Stone Block", 8)], 150, 1.0, "Income",
        rooms=[_room("Shop Floor", "Entrance", "Shop Floor", 0, 0, 7, 6)], income=3.0, workers=2),
    _bp("Inn", "Inn", 14, 10, "A common room with a hearth and two guest rooms. Staffed, it brings in money.",
        [("Timber Plank", 50), ("Stone Block", 20)], 300, 2.0, "Income",
        rooms=[_room("Common Room", "Entrance", "Common Room", 0, 0, 8, 9),
               _room("Guest Room", "Private", "Guest Room", 8, 0, 5, 4, "Common Room"),
               _room("Second Guest Room", "Private", "Guest Room", 8, 4, 5, 5, "Common Room")],
        income=5.0, workers=4),
    _bp("Storehouse", "Warehouse", 10, 8, "Racks and crates: every building on this claim can keep far more of "
        "what it makes before it's collected.", [("Timber Plank", 20), ("Stone Block", 6)], 80, 0.5, "Storage",
        rooms=[_room("Warehouse Floor", "Entrance", "Warehouse Floor", 0, 0, 9, 7)], storage=2000, workers=1),
    _bp("Well", "Other", 3, 3, "A stone well: fresh water.", [("Stone Block", 8)], 20, 0.0, "Water", style="well"),
    _bp("Wall", "Other", 8, 1, "Eight squares of timber palisade.", [("Oak Log", 8)], 20, 0.0, "Defense",
        style="wall", defense=1),
    _bp("Gate", "Other", 6, 1, "A gateway in the palisade, with posts and a gap to walk through.",
        [("Oak Log", 4), ("Iron Ingot", 1)], 20, 0.0, "Defense", style="gate", defense=1),
    _bp("Watchtower", "Other", 5, 5, "A squat stone tower with a lookout room.", [("Stone Block", 30),
                                                                                    ("Timber Plank", 10)],
        120, 0.5, "Defense", rooms=[_room("Lookout", "Entrance", "", 0, 0, 4, 4)], defense=2, workers=1),
    # ---- what a growing settlement needs (step 15: game/colony.py; the tiers in game/settlements.py)
    _bp("Granary", "Granary", 10, 8, "A raised timber store for grain: a village needs one (or a mill). Food "
        "keeps through the winter.", [("Timber Plank", 30), ("Stone Block", 10)], 150, 0.5, "Storage",
        rooms=[_room("Granary Floor", "Entrance", "", 0, 0, 9, 7)], storage=1000, workers=1, since=2),
    _bp("Mill", "Mill", 8, 8, "A mill that grinds grain to flour (and counts as a granary).",
        [("Timber Plank", 30), ("Stone Block", 20), ("Iron Ingot", 2)], 200, 0.5, "Resources",
        rooms=[_room("Mill Floor", "Entrance", "", 0, 0, 7, 7)], produces=[("Sack of Flour", 1)], workers=2,
        since=2),
    _bp("Shrine", "Temple", 6, 6, "A small shrine to the gods. A village needs one.", [("Stone Block", 20)], 100,
        0.5, "Defense", rooms=[_room("Shrine", "Entrance", "Chapel", 0, 0, 5, 5)], workers=1, since=2),
    _bp("Temple", "Temple", 14, 12, "A proper temple with a nave and a sanctuary. A town needs one.",
        [("Stone Block", 80), ("Timber Plank", 30)], 600, 2.0, "Defense",
        rooms=[_room("Nave", "Entrance", "Nave", 0, 0, 9, 11),
               _room("Sanctuary", "Special", "Sanctuary", 9, 0, 4, 11, "Nave")], workers=2, since=2),
    _bp("Market", "Market", 14, 12, "A covered market hall with stalls. Staffed, it brings in money; a town "
        "needs one.", [("Timber Plank", 60), ("Stone Block", 30)], 500, 2.0, "Income",
        rooms=[_room("Market Hall", "Entrance", "Market Hall", 0, 0, 13, 11)], income=4.0, workers=4, since=2),
    _bp("Jail", "Jail", 10, 8, "A lockup and a watch-room. A town needs one.", [("Stone Block", 50),
                                                                              ("Iron Ingot", 8)],
        300, 1.0, "Defense", rooms=[_room("Watch Room", "Entrance", "", 0, 0, 5, 7),
                                    _room("Cells", "Special", "Jail Cell", 5, 0, 4, 7, "Watch Room")],
        defense=1, workers=2, since=2),
    _bp("Barracks", "Barracks", 12, 10, "Bunks and a mess for the settlement's guards.",
        [("Timber Plank", 40), ("Stone Block", 30)], 300, 1.0, "Defense",
        rooms=[_room("Mess Hall", "Entrance", "Mess Hall", 0, 0, 7, 9),
               _room("Bunk Room", "Private", "Bunk Room", 7, 0, 4, 9, "Mess Hall")], defense=2, workers=4,
        since=2),
    _bp("Bank", "Bank", 12, 10, "A counting house with a strongroom. A city needs one.",
        [("Stone Block", 80), ("Iron Ingot", 12)], 800, 2.0, "Income",
        rooms=[_room("Banking Hall", "Entrance", "Banking Hall", 0, 0, 7, 9),
               _room("Strongroom", "Storage", "Strongroom", 7, 0, 4, 9, "Banking Hall")], income=3.0, workers=2,
        since=2),
    _bp("Castle", "Castle", 24, 20, "A stone keep: the seat of a capital.", [("Stone Block", 400),
                                                                           ("Timber Plank", 120),
                                                                           ("Iron Ingot", 40)],
        5000, 10.0, "Defense", rooms=[_room("Great Hall", "Entrance", "Great Hall", 0, 0, 14, 19),
                                      _room("Throne Room", "Special", "Throne Room", 14, 0, 9, 10, "Great Hall"),
                                      _room("Armory", "Storage", "Armory", 14, 10, 9, 9, "Great Hall")],
        defense=6, workers=6, since=2),
]


def ensure(world) -> int:
    """Give a world the starting blueprints (once; editing or deleting them later is kept)."""
    old = int((world.meta or {}).get("blueprints_v") or 0)
    if old >= BLUEPRINTS_V:
        return 0
    store = world.entities
    made = 0
    for bp in BUILTIN:
        if int(bp.get("since") or 1) <= old or store.find_by_name("blueprint", bp["name"]) is not None:
            continue
        f = dict(bp["fields"])
        f["materials"] = [{"item": _item_ref(world, m["item"]), "count": m["count"]} for m in f["materials"]]
        f["produces"] = [{"item": _item_ref(world, m["item"]), "per_day": m["per_day"]} for m in f["produces"]]
        f["rare"] = [{"item": _item_ref(world, m["item"]), "weight": m["weight"]} for m in f["rare"]]
        store.create("blueprint", bp["name"], f, bp["description"], ["Blueprint"], save=False)
        made += 1
    if made:
        store.save("blueprint")
    world.meta["blueprints_v"] = BLUEPRINTS_V
    try:
        world.save_meta()
    except Exception:  # noqa: BLE001
        pass
    return made


def _item_ref(world, ref: str) -> str:
    """An item's id from its id or name ("" if the world has no such item)."""
    if not ref:
        return ""
    e = world.entities.get(ref)
    if e is not None and e.type == "item":
        return e.id
    e = world.entities.find_by_name("item", ref)
    return e.id if e is not None else ""


def _item_name(world, ref: str) -> str:
    e = world.entities.get(ref)
    return e.name if e is not None else str(ref)


# ======================================================================
# Blueprints
# ======================================================================
def blueprints(world) -> list:
    try:
        return sorted(world.entities.all("blueprint"), key=lambda e: e.name.lower())
    except (KeyError, ValueError):
        return []


def blueprint(world, ref: str):
    e = world.entities.get(ref or "")
    if e is not None and e.type == "blueprint":
        return e
    try:
        return world.entities.find_by_name("blueprint", ref or "")
    except (KeyError, ValueError):
        return None


def style(bp) -> str:
    return (bp.fields.get("style") or "building") if bp is not None else "building"


def is_open(bp) -> bool:
    return style(bp) not in ("building", "mine")


def rooms_of(bp) -> list[dict]:
    """The blueprint's rooms (laid out in its footprint). A roofed blueprint with none gets one big room."""
    rows = [dict(r, floor=0) for r in (bp.fields.get("rooms") or []) if str(r.get("name") or "").strip()]
    for r in rows:
        for k in ("x", "y", "w", "h"):
            r[k] = int(r.get(k) or 0)
        r.setdefault("type", r.pop("role", "") or "Room")
        r.setdefault("tile", "")
        r.setdefault("connects", "")
    if rows or is_open(bp):
        return rows
    w, h = footprint(bp)
    return [{"name": bp.name, "type": "Entrance", "tile": "", "floor": 0, "x": 0, "y": 0, "w": max(2, w - 1),
             "h": max(2, h - 1), "connects": ""}]


def footprint(bp, rot: int = 0) -> tuple[int, int]:
    """(width, height) in squares, walls included, turned `rot` quarter turns."""
    rows = [r for r in (bp.fields.get("rooms") or []) if str(r.get("name") or "").strip()]
    if rows and not is_open(bp):
        w = max(int(r.get("x") or 0) + int(r.get("w") or 0) for r in rows) - min(int(r.get("x") or 0) for r in rows) + 1
        h = max(int(r.get("y") or 0) + int(r.get("h") or 0) for r in rows) - min(int(r.get("y") or 0) for r in rows) + 1
    else:
        w, h = max(1, int(bp.fields.get("w") or 1)), max(1, int(bp.fields.get("h") or 1))
    return (h, w) if rot % 2 else (w, h)


def worker_cap(bp) -> int:
    """How many may work there (or on building it): the blueprint's own number, else from its footprint."""
    n = int(bp.fields.get("workers") or 0)
    if n > 0:
        return n
    w, h = footprint(bp)
    return max(1, (w * h) // 20)


def materials(world, bp) -> list[tuple[str, int]]:
    """[(item id, count)] the blueprint takes (items the world doesn't have are left out)."""
    out = []
    for m in bp.fields.get("materials") or []:
        iid = _item_ref(world, m.get("item") or "")
        if iid and int(m.get("count") or 0) > 0:
            out.append((iid, int(m["count"])))
    return out


def missing(world, state, bp) -> list[tuple[str, int]]:
    """[(item id, how many more)] the party still lacks to start it."""
    return [(iid, n - state.count(iid)) for iid, n in materials(world, bp) if state.count(iid) < n]


def produces(world, bp) -> list[tuple[str, float]]:
    out = []
    for m in bp.fields.get("produces") or []:
        iid = _item_ref(world, m.get("item") or "")
        if iid and float(m.get("per_day") or 0) > 0:
            out.append((iid, float(m["per_day"])))
    return out


def summary(world, bp) -> str:
    """One line: footprint, materials, labor, upkeep and what it gives."""
    w, h = footprint(bp)
    mats = ", ".join(f"{n} {_item_name(world, i)}" for i, n in materials(world, bp)) or "no materials"
    gives = []
    if produces(world, bp):
        gives.append(" and ".join(f"{d:g} {_item_name(world, i)}" for i, d in produces(world, bp)) + " a day each hand")
    if float(bp.fields.get("income") or 0):
        gives.append(f"{float(bp.fields['income']):g} gp a day each hand")
    if bp.fields.get("stations"):
        gives.append(", ".join(bp.fields["stations"]).lower())
    if bp.fields.get("provides") in ("Home", "Stable", "Dock", "Water", "Storage", "Defense") and not gives:
        gives.append(str(bp.fields["provides"]).lower())
    return (f"{w * 5}x{h * 5} ft  ·  {mats}  ·  {int(bp.fields.get('labor') or 0)} gp of work  ·  "
            f"upkeep {float(bp.fields.get('upkeep') or 0):g} gp/day" + (f"  ·  {'; '.join(gives)}" if gives else ""))


# ======================================================================
# Holdings
# ======================================================================
def _h(state) -> dict:
    h = getattr(state, "holdings", None)
    if h is None:
        state.holdings = h = {}
    for k in ("claims", "settlements", "jobs", "workers", "reports"):
        h.setdefault(k, [])
    h.setdefault("estate", {})
    return h


def data(state) -> dict:
    """{"output": {bid: {item: n}}, "acc": {bid: {item: frac}}, "income": {bid: frac gp}, "owed": gp, ...}"""
    d = _h(state)["estate"]
    for k in ("output", "acc", "till"):
        d.setdefault(k, {})
    d.setdefault("owed", 0.0)
    d.setdefault("unpaid_days", 0)
    return d


def _save(world, state) -> None:
    from game import holdings
    try:
        holdings.save(world, state)
    except Exception:  # noqa: BLE001 - never stop play over a save
        pass


def claims(state) -> list[dict]:
    return list(_h(state)["claims"]) if state is not None else []


def claim(state, cid: str) -> dict | None:
    return next((c for c in claims(state) if c.get("id") == cid), None)


def wild_claims(state) -> list[dict]:
    return [c for c in claims(state) if c.get("rect")] if state is not None else []


def buildings(world, claim_id: str | None = None) -> list:
    """The party's estate buildings (on claims), oldest first; for one claim if given."""
    out = [b for b in world.entities.overlay_entities() if b.type == "building" and b.fields.get("claim")
           and (claim_id is None or b.fields.get("claim") == claim_id)]
    return sorted(out, key=lambda b: (b.fields.get("built_at") or 0, b.id))


def finished(world, claim_id: str | None = None) -> list:
    return [b for b in buildings(world, claim_id) if b.fields.get("status") == "done"]


def bp_of(world, b):
    return blueprint(world, b.fields.get("blueprint") or "")


# ======================================================================
# Who sells land
# ======================================================================
def seller(world, town):
    """Who sells land in this town: the lot seller (the town hall's clerk in grown worlds), else someone at the
    town hall, else the town's first townsperson."""
    from game import lots, places
    if town is None or town.fields.get("settlement"):
        return None
    npc = lots.seller(world, town)
    if npc is not None:
        return npc
    halls = [b for b in places.buildings_in(world, town) if (b.fields.get("kind") or "") == "Town hall"]
    for b in halls + places.buildings_in(world, town):
        for nid in b.fields.get("npcs") or []:
            n = world.entities.get(nid)
            if n is not None and n.type == "npc":
                return n
        if not halls:
            break
    folk = world.entities.by_field("npc", "town", town.id)
    return sorted(folk, key=lambda n: n.id)[0] if folk else None


def sells_land(world, npc) -> bool:
    from game import neighborhood as NB
    if npc is None:
        return False
    town = world.entities.get(NB.npc_town(world, npc) or "")
    s = seller(world, town)
    return s is not None and s.id == npc.id


def town_tier(town) -> str:
    from game import settlements as ST
    return ST.tier_of(town)


def lot_price(world, town) -> int:
    return LOT_PRICE.get(town_tier(town), 300)


# ======================================================================
# Town lots
# ======================================================================
def lot_count(town) -> int:
    from game import settlements as ST
    return ST.lots_target(town) if town is not None else 0


def lots_free(world, state, town) -> list[int]:
    """The lot numbers still for sale in this town (that this save doesn't own, and that are on the map)."""
    if town is None:
        return []
    mine = {int(c.get("lot", -1)) for c in claims(state) if c.get("kind") == "lot" and c.get("town") == town.id}
    have = lots_on_map(world, town)
    return [i for i in sorted(have) if i not in mine]


def lots_on_map(world, town) -> dict:
    """{lot number: (x, y, w, h)} in the town's own map (none in the party's own settlements)."""
    from game import area as A
    if town is not None and town.fields.get("settlement"):
        return {}
    try:
        a = A.town_area(world, town)
    except Exception:  # noqa: BLE001
        return {}
    return dict(getattr(a, "sale_lots", {}) or {})


def lot_size() -> tuple[int, int]:
    from game import townlayout as TLY
    return TLY.LOT_SIZE


def buy_lot(world, state, town, lot: int, bus=None) -> tuple[bool, str, dict | None]:
    if lot not in lots_free(world, state, town):
        return False, "That lot isn't for sale.", None
    price = lot_price(world, town)
    if state.copper < price * 100:
        return False, f"The lot costs {price} gp.", None
    state.add_copper(-price * 100, f"a lot in {town.name}")
    c = {"id": state.next_id("claim"), "kind": "lot", "name": f"Lot {lot + 1}, {town.name}", "town": town.id,
         "lot": int(lot), "rect": None, "paid": True, "price": price, "day": state.day}
    _h(state)["claims"].append(c)
    _save(world, state)
    _changed(world, state, town=town.id)
    msg = f"You buy lot {lot + 1} in {town.name} for {price} gp. It's yours to build on."
    if bus is not None:
        bus.emit("log", kind="quest", text=msg)
        bus.emit("estate.changed", claim=c["id"])
    return True, msg, c


# ======================================================================
# Wild claims
# ======================================================================
def claim_size(kind: str) -> int:
    return CHUNK * CLAIMS.get(kind, CLAIMS["property"])["chunks"]


def claim_rect_at(kind: str, X: float, Y: float) -> list[int]:
    """The claim of this kind round the square (X, Y), lined up with the map's chunks."""
    n = CLAIMS.get(kind, CLAIMS["property"])["chunks"]
    cx, cy = int(X) // CHUNK, int(Y) // CHUNK
    off = n // 2
    return [(cx - off) * CHUNK, (cy - off) * CHUNK, n * CHUNK, n * CHUNK]


def _sq(world) -> int:
    from game.worldmap import SQ
    return SQ


def nearest_town(world, X: float, Y: float):
    from game import geography as G
    sq = _sq(world)
    best, bd = None, 1e18
    for tid, p in G.town_positions(world).items():
        d = (p[0] - X / sq) ** 2 + (p[1] - Y / sq) ** 2
        if d < bd:
            best, bd = tid, d
    return world.entities.get(best) if best else None, math.sqrt(bd) if best else 1e9


_HALLS: dict = {}


def hall_towns(world) -> set:
    """The towns with a town hall (where claims are registered)."""
    key = id(world)
    if key not in _HALLS:
        _HALLS.clear()
        _HALLS[key] = {b.fields.get("town") for b in world.entities.all("building")
                       if (b.fields.get("kind") or "") == "Town hall" and b.fields.get("town")}
    return _HALLS[key]


def registrar(world, X: float, Y: float):
    """(town, miles): the nearest town to (X, Y) squares that has a town hall, where a claim there is
    registered; (None, inf) in a world without one."""
    from game import geography as G
    sq = _sq(world)
    halls = hall_towns(world)
    best, bd = None, 1e18
    for tid, p in G.town_positions(world).items():
        if tid not in halls:
            continue
        d = (p[0] - X / sq) ** 2 + (p[1] - Y / sq) ** 2
        if d < bd:
            best, bd = tid, d
    return world.entities.get(best) if best else None, math.sqrt(bd) if best else 1e9


def registrar_of(world, c: dict):
    """Where this claim is registered: the town it names if that has a town hall, else the nearest that does
    (claims staked before Hotfix 18 named the nearest town of any size)."""
    t = world.entities.get(c.get("town") or "")
    if t is not None and t.id in hall_towns(world):
        return t
    if c.get("rect"):
        x, y, w, h = c["rect"]
        t2, _d = registrar(world, x + w / 2, y + h / 2)
        if t2 is not None:
            return t2
    return t


def clerk(world, town):
    """Who registers claims in this town: someone at its town hall."""
    from game import places
    if town is None or town.id not in hall_towns(world):
        return None
    for b in places.buildings_in(world, town):
        if (b.fields.get("kind") or "") != "Town hall":
            continue
        for nid in b.fields.get("npcs") or []:
            n = world.entities.get(nid)
            if n is not None and n.type == "npc":
                return n
    return seller(world, town)


def registering(world, state, npc) -> list[dict]:
    """The staked claims this person (a town hall's clerk) can register."""
    from game import neighborhood as NB
    if npc is None:
        return []
    town = world.entities.get(NB.npc_town(world, npc) or "")
    c0 = clerk(world, town)
    if c0 is None or c0.id != npc.id:
        return []
    return [c for c in due(state) if c.get("kind") != "lot" and (registrar_of(world, c) or town).id == town.id]


def unregistered_text(world, c: dict) -> str:
    t = registrar_of(world, c)
    return (f"Not registered yet: take it to the town hall in {t.name if t else 'the nearest town'} "
            f"({c.get('price')} gp) for the right to build on it.")


def can_claim(world, state, kind: str, X: float, Y: float) -> tuple[bool, str, list[int]]:
    """(allowed, why not, the claim's rect) for a wild claim round (X, Y) squares."""
    from game import geography as G
    rect = claim_rect_at(kind, X, Y)
    x0, y0, w, h = rect
    s = G.settings(world)
    sq = _sq(world)
    if x0 < 0 or y0 < 0 or x0 + w > s["width"] * sq or y0 + h > s["height"] * sq:
        return False, "That runs off the edge of the map.", rect
    # far enough from every town (from each corner as well as the middle)
    for px, py in ((x0, y0), (x0 + w, y0), (x0, y0 + h), (x0 + w, y0 + h), (x0 + w / 2, y0 + h / 2)):
        _t, d = nearest_town(world, px, py)
        if d < MIN_TOWN_MILES:
            return False, f"Too close to {_t.name}: claims must be at least {MIN_TOWN_MILES:g} mile from a town. " \
                          "(Buy a lot in town instead.)", rect
    for c in wild_claims(state):
        cx, cy, cw, ch = c["rect"]
        if cx < x0 + w and x0 < cx + cw and cy < y0 + h and y0 < cy + ch:
            return False, f"That overlaps your claim, {c['name']}.", rect
    # no water (sampled every few squares) and nothing else built there
    wet = 0
    step = 4
    total = 0
    for yy in range(y0, y0 + h, step):
        for xx in range(x0, x0 + w, step):
            total += 1
            if G.biome_at(world, (xx + 0.5) / sq, (yy + 0.5) / sq) in ("Ocean", "Lake"):
                wet += 1
    if wet:
        return False, "There's water on that land: claims must be on dry ground.", rect
    from game import worldmap
    if worldmap.walkable(world):
        wa = worldmap.world_area(world)
        for site in list(wa.sites.values()):
            if site.kind != "claim" and site.overlaps(x0, y0, w, h):
                return False, "Something already stands there.", rect
    return True, "", rect


def claim_price(kind: str) -> int:
    return CLAIMS.get(kind, CLAIMS["property"])["price"]


def make_claim(world, state, kind: str, X: float, Y: float, name: str = "", paid: bool = False, bus=None,
               town=None) -> tuple[bool, str, dict | None]:
    """Stake a wild claim, standing on it (not yet registered: that's done, and paid for, at the nearest town
    hall: register). paid=True makes it registered at once (tests, and the Create mode's own use)."""
    ok, why, rect = can_claim(world, state, kind, X, Y)
    if not ok:
        return False, why, None
    price = claim_price(kind)
    if town is None:
        town, _d = registrar(world, rect[0] + rect[2] / 2, rect[1] + rect[3] / 2)
        if town is None:
            town, _d = nearest_town(world, rect[0] + rect[2] / 2, rect[1] + rect[3] / 2)
    if paid:
        if state.copper < price * 100:
            return False, f"That claim costs {price} gp.", None
        state.add_copper(-price * 100, f"a claim near {town.name if town else 'the wilds'}")
    label = CLAIMS[kind]["label"]
    name = (name or "").strip() or (f"Claim near {town.name}" if town is not None else "Your claim")
    c = {"id": state.next_id("claim"), "kind": kind, "name": name, "town": town.id if town else "", "lot": None,
         "rect": rect, "paid": bool(paid), "price": price, "day": state.day}
    _h(state)["claims"].append(c)
    if kind == "settlement" and paid:
        c["settlement"] = _new_settlement(state, c, name)
    _save(world, state)
    _changed(world, state, claim=c["id"])
    if paid:
        msg = f"The {label.lower()} \"{name}\" is yours ({price} gp)."
    else:
        msg = (f"You drive in the stakes and mark out \"{name}\". To build on it, register it at the town hall in "
               f"{town.name if town else 'the nearest town'} and pay the {price} gp.")
    if bus is not None:
        bus.emit("log", kind="quest", text=msg)
        bus.emit("estate.changed", claim=c["id"])
    return True, msg, c


def _new_settlement(state, c: dict, name: str) -> str:
    sid = state.next_id("settlement")
    _h(state)["settlements"].append({"id": sid, "name": name, "tier": "Camp", "claim": c["id"], "households": 0,
                                     "settlers": [], "store": {}, "ledger": [], "founded": state.day})
    try:                                    # it becomes a town of the save's own (game/colony.py)
        from game import colony
        colony.found(state.world, state, sid)
    except Exception:  # noqa: BLE001
        import traceback
        traceback.print_exc()
    return sid


def settlement_of(state, c: dict) -> dict | None:
    sid = (c or {}).get("settlement")
    return next((s for s in _h(state)["settlements"] if s.get("id") == sid), None) if sid else None


def to_settlement(world, state, cid: str, name: str = "", bus=None) -> tuple[bool, str]:
    """Turn a property into a starter settlement (one way: it can't go back). The land grows to 3 x 3 chunks
    round it, so the bigger claim has to be free and dry; the difference in price is paid now."""
    c = claim(state, cid)
    if c is None or c.get("kind") != "property":
        return False, "Only a property can become a settlement."
    if not c.get("paid"):
        return False, unregistered_text(world, c)
    x, y, w, h = c["rect"]
    others = [o for o in wild_claims(state) if o is not c]
    _h(state)["claims"] = [o for o in _h(state)["claims"] if o is not c]          # don't trip over itself
    try:
        ok, why, rect = can_claim(world, state, "settlement", x + w / 2, y + h / 2)
    finally:
        _h(state)["claims"] = others + [c] if c not in _h(state)["claims"] else _h(state)["claims"]
    if not ok:
        return False, why
    cost = claim_price("settlement") - claim_price("property")
    if state.copper < cost * 100:
        return False, f"Making it a settlement costs {cost} gp more."
    state.add_copper(-cost * 100, "founding a settlement")
    dx, dy = x - rect[0], y - rect[1]
    for b in buildings(world, cid):                        # the buildings stay where they stand
        pl = dict(b.fields.get("place") or {})
        pl["x"] = int(pl.get("x", 0)) + dx
        pl["y"] = int(pl.get("y", 0)) + dy
        world.entities.update(b.id, fields={"place": pl})
    c["kind"], c["rect"] = "settlement", rect
    if name.strip():
        c["name"] = name.strip()
    c["settlement"] = _new_settlement(state, c, c["name"])
    st = settlement_of(state, c)
    if st is not None and st.get("town"):
        from game import colony
        for b in buildings(world, cid):                    # its buildings are the new settlement's
            world.entities.update(b.id, fields={"town": st["town"], "street": colony.street_name(world, st)})
    _save(world, state)
    _changed(world, state, claim=cid)
    msg = f"{c['name']} is a settlement now: a Camp, for the moment."
    if bus is not None:
        bus.emit("log", kind="quest", text=msg)
        bus.emit("estate.changed", claim=cid)
    return True, msg


def due(state, town_id: str | None = None) -> list[dict]:
    return [c for c in claims(state) if not c.get("paid") and (town_id is None or c.get("town") == town_id)]


def pay(world, state, cid: str, bus=None) -> tuple[bool, str]:
    """Register a staked claim (at the town hall: registering): pay the price, and the land's yours to build
    on and develop (a starter settlement is founded now)."""
    c = claim(state, cid)
    if c is None or c.get("paid"):
        return False, "Nothing's owed on that."
    price = int(c.get("price") or 0)
    if state.copper < price * 100:
        return False, f"Registering {c['name']} costs {price} gp, and you haven't got it."
    state.add_copper(-price * 100, f"registering the claim on {c['name']}")
    c["paid"] = True
    if c.get("kind") == "settlement" and not c.get("settlement"):
        c["settlement"] = _new_settlement(state, c, c["name"])
    _save(world, state)
    _changed(world, state, claim=cid)
    msg = (f"The clerk enters {c['name']} in the register and takes the {price} gp. The deed is yours: you may "
           "build on the land and develop it.")
    if bus is not None:
        bus.emit("log", kind="quest", text=msg)
        bus.emit("estate.changed", claim=cid)
    return True, msg


register = pay


def arrived(world, state, town, bus=None) -> list[str]:
    """On a visit to a town: nothing is paid by itself any more (Hotfix 18); a claim waiting to be registered
    here is only a reminder."""
    out = []
    for c in due(state):
        t = registrar_of(world, c)
        if c.get("kind") != "lot" and town is not None and t is not None and t.id == town.id:
            out.append(f"{c['name']} is waiting to be registered at the town hall here ({c['price']} gp).")
    return out


def claim_at(state, X: int, Y: int) -> dict | None:
    for c in wild_claims(state):
        x, y, w, h = c["rect"]
        if x <= X < x + w and y <= Y < y + h:
            return c
    return None


# ======================================================================
# Placing a building
# ======================================================================
def claim_bounds(world, c: dict, area=None) -> tuple[int, int, int, int] | None:
    """Where the claim is in this walking map (x, y, w, h): a wild claim in the open world; a lot in its town's
    map (standing alone, or laid into the open world)."""
    if c.get("rect"):
        return tuple(c["rect"]) if area is None or area.kind == "world" else None
    if area is None:
        return None
    lots = None
    if area.kind == "world":
        site = area.sites.get(c.get("town") or "")
        lots = getattr(site.area, "sale_lots", None) if site is not None else None
    elif area.kind == "town" and area.key == f"town:{c.get('town')}":
        lots = getattr(area, "sale_lots", None)
    if not lots or int(c.get("lot", -1)) not in lots:
        return None
    return tuple(lots[int(c["lot"])])


def claim_size_of(c: dict) -> tuple[int, int]:
    if c.get("rect"):
        return int(c["rect"][2]), int(c["rect"][3])
    return lot_size()


def taken_cells(world, cid: str, skip: str = "") -> set:
    """Squares (from the claim's corner) its buildings stand on."""
    out = set()
    for b in buildings(world, cid):
        if b.id == skip:
            continue
        bp = bp_of(world, b)
        if bp is None:
            continue
        pl = b.fields.get("place") or {}
        w, h = footprint(bp, int(pl.get("rot") or 0))
        rows = [r for r in (b.fields.get("rooms") or []) if str(r.get("name") or "").strip()]
        if rows and not is_open(bp):                        # a home out in the wilds may have grown rooms
            from game import area as A
            p = A.Plan(b, rows)
            p.q = int(pl.get("rot") or 0) % 4
            w, h = max(w, p.size()[0]), max(h, p.size()[1])
        for yy in range(int(pl.get("y", 0)), int(pl.get("y", 0)) + h):
            for xx in range(int(pl.get("x", 0)), int(pl.get("x", 0)) + w):
                out.add((xx, yy))
    return out


def can_place(world, state, c: dict, bp, x: int, y: int, rot: int, area=None) -> tuple[bool, str]:
    """Can this blueprint go here (x, y from the claim's corner, turned rot quarter turns)?"""
    if bp is None or c is None:
        return False, "Nothing to build."
    w, h = footprint(bp, rot)
    cw, ch = claim_size_of(c)
    if x < 0 or y < 0 or x + w > cw or y + h > ch:
        return False, "It has to fit inside your land."
    taken = taken_cells(world, c["id"])
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            if (xx, yy) in taken:
                return False, "It would stand on top of another of your buildings."
    bounds = claim_bounds(world, c, area) if area is not None else None
    if bounds is not None:
        bx, by = bounds[0], bounds[1]
        lv = area.layer(area.base_key, bx + x, by + y)
        wet = near_water = False
        for yy in range(y - 1, y + h + 1):
            for xx in range(x - 1, x + w + 1):
                X, Y = bx + xx, by + yy
                lv = area.layer(area.base_key, X, Y)
                water = (X, Y) in lv.water or lv.floor_at(X, Y) in ("water", "sea", "deep_water")
                inside = x <= xx < x + w and y <= yy < y + h
                if inside and water:
                    wet = True
                if water:
                    near_water = True
        if bp.fields.get("water"):
            if not near_water:
                return False, "A dock has to be built at the water's edge."
        elif wet:
            return False, "You can't build on water."
    elif bp.fields.get("water") and not c.get("rect"):
        return False, "A dock has to be built at the water's edge."
    return True, ""


def place(world, state, cid: str, bp, x: int, y: int, rot: int, area=None, name: str = "",
          bus=None) -> tuple[bool, str, object | None]:
    """Mark out a building on the claim (planned: nothing's taken until work starts). Not on land that hasn't
    been registered."""
    c = claim(state, cid)
    if c is not None and not c.get("paid") and c.get("kind") != "lot":
        return False, unregistered_text(world, c), None
    ok, why = can_place(world, state, c, bp, x, y, rot, area)
    if not ok:
        return False, why, None
    base = (name or "").strip() or (f"Your {bp.name}" if c.get("kind") != "settlement" else f"{c['name']} {bp.name}")
    nm, k = base, 2
    while world.entities.has_name("building", nm):
        nm, k = f"{base} {k}", k + 1
    town = c.get("town") if c.get("kind") == "lot" else ""
    street = ""
    st = settlement_of(state, c) if c.get("kind") == "settlement" else None
    if st is not None and st.get("town"):                # in a settlement of the party's own (game/colony.py)
        from game import colony
        town, street = st["town"], colony.street_name(world, st)
    elif town:
        from game import places
        t = world.entities.get(town)
        names = [s["name"] for s in places.streets_of(t)] if t is not None else []
        street = names[int(c.get("lot") or 0) % len(names)] if names else ""
    fields = {"kind": bp.fields.get("kind") or "Other", "town": town, "street": street, "owner": True,
              "generate": False, "open_hours": "always" if (st is None or bp.fields.get("provides") == "Home") else
              "07:00-19:00", "interior": "Stone" if bp.fields.get("kind") == "Smithy" else "Wooden",
              "size": "Small", "claim": cid, "lot": c.get("lot") if c.get("kind") == "lot" else None,
              "blueprint": bp.id, "place": {"x": int(x), "y": int(y), "rot": int(rot) % 4}, "status": "planned",
              "rooms": [], "open": is_open(bp), "npcs": [], "built_at": state.minutes,
              "facilities": [s for s in (bp.fields.get("stations") or [])], "income_day": state.day}
    b = world.entities.create("building", nm, fields, bp.description or f"Your {bp.name.lower()}.", overlay=True)
    _changed(world, state, claim=cid, town=town)
    msg = f"You mark out the ground for {nm}. Start the work when you have the materials."
    if bus is not None:
        bus.emit("log", kind="system", text=msg)
        bus.emit("estate.changed", claim=cid)
    return True, msg, world.entities.get(b.id)


def remove(world, state, bid: str, bus=None) -> tuple[bool, str]:
    """Take down a planned building (its materials come back if work had started and not finished)."""
    b = world.entities.get(bid)
    if b is None or not b.fields.get("claim"):
        return False, "That isn't yours to pull down."
    if b.fields.get("status") == "done":
        return False, "It's finished: it stays."
    job = job_for(state, bid)
    if job is not None:
        for iid, n in job.get("materials") or []:
            state.add_item(iid, int(n), "building called off")
        _h(state)["jobs"] = [j for j in _h(state)["jobs"] if j is not job]
    for w in workers(state):
        if w.get("building") == bid:
            w["building"] = ""
    cid, town = b.fields.get("claim"), b.fields.get("town") or ""
    world.entities.delete(bid)
    _save(world, state)
    _changed(world, state, claim=cid, town=town)
    return True, f"{b.name} is called off."


# ======================================================================
# Construction
# ======================================================================
def job_for(state, bid: str) -> dict | None:
    return next((j for j in _h(state)["jobs"] if j.get("kind") == "build" and j.get("building") == bid), None)


def build_jobs(state) -> list[dict]:
    return [j for j in _h(state)["jobs"] if j.get("kind") == "build"]


def pace(world) -> float:
    return float(world.rules.get("craft_pace", PACE) or PACE)


def crew(world, state, bid: str) -> float:
    """Workers on a building site: the party (one) plus everyone assigned there, an automaton by its speed,
    up to the blueprint's cap."""
    b = world.entities.get(bid)
    bp = bp_of(world, b) if b is not None else None
    cap = worker_cap(bp) if bp is not None else 1
    speeds = sorted((speed(w) for w in workers(state) if w.get("building") == bid), reverse=True)
    return 1.0 + sum(speeds[:max(0, cap - 1)])


def days_left(world, state, bid: str) -> float | None:
    job = job_for(state, bid)
    if job is None:
        return None
    rate = pace(world) * crew(world, state, bid)
    return max(0.0, (float(job["work"]) - float(job["done"])) / max(0.01, rate))


def start(world, state, bid: str, bus=None) -> tuple[bool, str]:
    """Begin building: the materials are taken now."""
    b = world.entities.get(bid)
    bp = bp_of(world, b) if b is not None else None
    if bp is None:
        return False, "There's no plan to build from."
    if b.fields.get("status") != "planned":
        return False, "Work has already begun." if b.fields.get("status") == "building" else "It's finished."
    lack = missing(world, state, bp)
    if lack:
        return False, "You still need " + ", ".join(f"{n} {_item_name(world, i)}" for i, n in lack) + "."
    c = claim(state, b.fields.get("claim") or "")
    if c is not None and not c.get("paid") and c.get("kind") != "lot":
        return False, unregistered_text(world, c)
    mats = materials(world, bp)
    for iid, n in mats:
        state.remove_item(iid, n, f"building {b.name}")
    labor = float(bp.fields.get("labor") or 0)
    job = {"id": state.next_id("build"), "kind": "build", "building": bid, "work": labor, "done": 0.0,
           "start": state.minutes, "materials": [[i, n] for i, n in mats]}
    _h(state)["jobs"].append(job)
    world.entities.update(bid, fields={"status": "building"})
    state.ticks.setdefault("estate", state.minutes)
    if labor <= 0:
        _finish(world, state, job, bus)
    _save(world, state)
    _changed(world, state, claim=b.fields.get("claim"), town=b.fields.get("town") or "")
    d = days_left(world, state, bid)
    msg = f"Work begins on {b.name}." + (f" At this pace it'll take about {math.ceil(d)} day"
                                          f"{'s' if math.ceil(d) != 1 else ''}." if d else "")
    if bus is not None:
        bus.emit("log", kind="system", text=msg)
    return True, msg


def _finish(world, state, job: dict, bus=None) -> None:
    b = world.entities.get(job["building"])
    _h(state)["jobs"] = [j for j in _h(state)["jobs"] if j is not job]
    if b is None:
        return
    bp = bp_of(world, b)
    rows = rooms_of(bp) if bp is not None else []
    world.entities.update(b.id, fields={"status": "done", "rooms": rows, "finished_day": state.day})
    _h(state)["reports"].append(f"{b.name} is finished.")
    _changed(world, state, claim=b.fields.get("claim"), town=b.fields.get("town") or "")
    if bus is not None:
        bus.emit("log", kind="quest", text=f"{b.name} is finished.")
    if getattr(state, "bus", None) is not None:
        state.bus.emit("estate.built", building=b.id, blueprint=b.fields.get("blueprint"))


def progress(world, state, bid: str) -> float | None:
    job = job_for(state, bid)
    if job is None:
        b = world.entities.get(bid)
        return 1.0 if b is not None and b.fields.get("status") == "done" else None
    return min(1.0, float(job["done"]) / max(0.01, float(job["work"])))


# ======================================================================
# Workers and automatons
# ======================================================================
def workers(state) -> list[dict]:
    return _h(state)["workers"] if state is not None else []


def worker(state, wid: str) -> dict | None:
    return next((w for w in workers(state) if w.get("id") == wid), None)


def worker_of_npc(state, npc_id: str) -> dict | None:
    return next((w for w in workers(state) if w.get("npc") == npc_id), None)


def speed(w: dict) -> float:
    if w.get("kind") == "automaton":
        return AUTOMATON.get(w.get("grade") or "Standard", (0, 1.0))[1]
    return 1.0


def wages(world) -> tuple[float, float]:
    r = world.rules
    return float(r.get("wage_skilled", 2) or 2), float(r.get("wage_untrained", 0.2) or 0.2)


def skilled(world, npc) -> bool:
    """A townsperson with a trade (a crafter, a farmer, a miner...) is a skilled hand."""
    from game import crafting, jobs
    occ = npc.fields.get("occupation") or ""
    if occ in crafting.TRADE_STATIONS or occ in ("Farmer", "Hunter", "Miner", "Sailor", "Scholar", "Arcanist"):
        return True
    try:
        return bool(jobs.employer_kinds(world, npc))
    except Exception:  # noqa: BLE001
        return False


def can_hire(world, state, npc) -> tuple[bool, str]:
    if npc is None or npc.type != "npc":
        return False, ""
    if worker_of_npc(state, npc.id) is not None:
        return False, "They already work for you."
    if npc.fields.get("settler") or npc.fields.get("visitor") or npc.fields.get("automaton"):
        return False, "They have their own work in the settlement."
    if (npc.fields.get("occupation") or "") in NO_HIRE or npc.fields.get("fights_as"):
        return False, "They have work of their own."
    if sells_land(world, npc):
        return False, "They have work of their own."
    from game import factions
    if factions.attitude(world, state, npc) == "Hostile":
        return False, "They won't work for you."
    return True, ""


def wage_for(world, npc) -> float:
    s, u = wages(world)
    return s if skilled(world, npc) else u


def hire(world, state, npc, building: str = "", bus=None) -> tuple[bool, str, dict | None]:
    ok, why = can_hire(world, state, npc)
    if not ok:
        return False, why or "They won't work for you.", None
    wage = wage_for(world, npc)
    w = {"id": state.next_id("worker"), "kind": "hired", "npc": npc.id, "name": npc.name,
         "skilled": skilled(world, npc), "wage": wage, "grade": "", "building": "", "hired": state.day}
    workers(state).append(w)
    state.ticks.setdefault("estate", state.minutes)
    if building:
        assign(world, state, w["id"], building)
    _save(world, state)
    msg = f"{npc.name} works for you now, for {_money(wage)} a day" + (" (a skilled hand)." if w["skilled"] else ".")
    if bus is not None:
        bus.emit("log", kind="quest", text=msg)
    return True, msg, w


def dismiss(world, state, wid: str, bus=None) -> tuple[bool, str]:
    w = worker(state, wid)
    if w is None:
        return False, "No such worker."
    _h(state)["workers"] = [x for x in workers(state) if x is not w]
    if w.get("kind") == "settler":                     # a settler stops working there, but stays
        n = world.entities.get(w.get("npc") or "")
        if n is not None:
            world.entities.update(n.id, fields={"building": ""})
        _save(world, state)
        return True, f"{w.get('name')} goes back to their own business."
    if w.get("kind") == "automaton":
        n = world.entities.get(w.get("npc") or "")
        if n is not None and world.entities.is_overlay(n.id):
            world.entities.delete(n.id)
    _save(world, state)
    msg = f"{w.get('name')} is let go." if w.get("kind") == "hired" else f"{w.get('name')} is sold for scrap."
    if bus is not None:
        bus.emit("log", kind="system", text=msg)
    return True, msg


def assign(world, state, wid: str, bid: str) -> tuple[bool, str]:
    w = worker(state, wid)
    if w is None:
        return False, "No such worker."
    if bid:
        b = world.entities.get(bid)
        bp = bp_of(world, b) if b is not None else None
        if b is None or bp is None:
            return False, "That isn't one of your buildings."
        there = [x for x in workers(state) if x.get("building") == bid and x is not w]
        if len(there) >= worker_cap(bp):
            return False, f"{b.name} has room for {worker_cap(bp)} at most."
    w["building"] = bid
    if w.get("kind") in ("automaton", "settler") and w.get("npc"):
        n = world.entities.get(w["npc"])
        if n is not None:
            world.entities.update(n.id, fields={"building": bid, "town": _town_of_building(world, bid)})
    _save(world, state)
    return True, ""


def _town_of_building(world, bid: str) -> str:
    b = world.entities.get(bid or "")
    return (b.fields.get("town") or "") if b is not None else ""


def automaton_maker(world, npc) -> bool:
    """Someone who sells automatons: an automaton maker, or the arcanist of a workshop."""
    if npc is None:
        return False
    title = str(npc.fields.get("title") or "").lower()
    if "automaton" in title:
        return True
    from game import places
    b = world.entities.get(places.building_of(world, npc) or "")
    return b is not None and (b.fields.get("kind") or "") == "Workshop" and \
        (npc.fields.get("occupation") or "") == "Arcanist" and not b.fields.get("claim")


def automaton_price(grade: str) -> int:
    return AUTOMATON.get(grade, AUTOMATON["Standard"])[0]


def buy_automaton(world, state, grade: str, maker=None, name: str = "", bus=None) -> tuple[bool, str, dict | None]:
    if grade not in AUTOMATON:
        return False, "No such grade.", None
    price = automaton_price(grade)
    if state.copper < price * 100:
        return False, f"A {grade.lower()} automaton costs {price} gp.", None
    state.add_copper(-price * 100, f"a {grade.lower()} automaton")
    rng = random.Random(state.minutes * 7 + len(workers(state)))
    nm = (name or "").strip() or f"{rng.choice(['Cog', 'Brass', 'Tock', 'Spindle', 'Gear', 'Rivet', 'Pewter', 'Clock'])}" \
                                 f"-{rng.randint(10, 99)}"
    race = world.entities.find_by_name("race", "Automaton")
    n = world.entities.create("npc", nm, {
        "race": race.id if race is not None else None, "occupation": "Laborer", "class": None, "level": 1,
        "disposition": "Friendly", "faction": None, "trains": [], "building": "", "town": "", "street": "",
        "home": None, "schedule": [], "greeting": "Ready for work. I am always ready for work.", "talk": None,
        "quest_cooldown_days": 0, "quests": [], "sells_tags": [], "shop_items": [], "gold": 0, "price_markup": 100,
        "passages": [], "relationships": [], "title": f"{grade.lower()} automaton",
        "appearance": {"base": "automaton", "sex": "", "clothes": "#6a5a3a"}, "equipment": {}, "fights_as": None,
        "automaton": grade}, f"A {grade.lower()} automaton, built to work.", ["Automaton"], overlay=True)
    w = {"id": state.next_id("worker"), "kind": "automaton", "npc": n.id, "name": nm, "skilled": False, "wage": 0.0,
         "grade": grade, "building": "", "hired": state.day, "maker": maker.id if maker is not None else ""}
    workers(state).append(w)
    state.ticks.setdefault("estate", state.minutes)
    _save(world, state)
    msg = f"You buy {nm}, a {grade.lower()} automaton, for {price} gp. It never sleeps and never asks for pay."
    if bus is not None:
        bus.emit("log", kind="quest", text=msg)
    return True, msg, w


def assigned_building(world, npc_id: str) -> str:
    """The building a hired hand of the running game works at ('' if none)."""
    st = getattr(world, "_state_for_places", None)
    h = getattr(st, "holdings", None) if st is not None else None
    if not h or not h.get("workers"):
        return ""
    for w in h["workers"]:
        if w.get("npc") == npc_id and w.get("kind") == "hired":
            return w.get("building") or ""
    return ""


def at_work(minute: int) -> bool:
    lo, hi = WORK_HOURS
    return lo * 60 <= minute % DAY < hi * 60


def hands_at(world, bid: str) -> list:
    """The hired hands who might be at this building (for who's there: game/places.py)."""
    st = getattr(world, "_state_for_places", None)
    h = getattr(st, "holdings", None) if st is not None else None
    if not h or not h.get("workers"):
        return []
    out = []
    for w in h["workers"]:
        if w.get("building") == bid and w.get("kind") == "hired":
            n = world.entities.get(w.get("npc") or "")
            if n is not None:
                out.append(n)
    return out


# ======================================================================
# Production, income, upkeep and wages
# ======================================================================
def storage_cap(world, b) -> int:
    extra = 0
    for o in finished(world, b.fields.get("claim")):
        bp = bp_of(world, o)
        if bp is not None:
            extra += int(bp.fields.get("storage") or 0)
    return STORE_CAP + extra


def output(state, bid: str) -> dict:
    """What's piled up at a building; in a settlement of the party's own, its shared storehouse."""
    w = getattr(state, "world", None)
    b = w.entities.get(bid) if w is not None else None
    if b is not None and b.fields.get("claim"):
        c = claim(state, b.fields["claim"])
        st = settlement_of(state, c) if c is not None and c.get("kind") == "settlement" else None
        if st is not None:
            return st.setdefault("store", {})
    return data(state)["output"].setdefault(bid, {})


def rates(world, state, b, minute: int | None = None) -> dict:
    """{item id: per day} this building makes now, with its workers (and the season, for a farm)."""
    bp = bp_of(world, b)
    if bp is None or b.fields.get("status") != "done":
        return {}
    prods = produces(world, bp)
    if not prods:
        return {}
    crew_ = [w for w in workers(state) if w.get("building") == b.id][:worker_cap(bp)]
    if not crew_:
        return {}
    mult = 0.0
    for w in crew_:
        mult += AUTOMATON_OUTPUT * speed(w) if w.get("kind") == "automaton" else 1.0
    if bp.fields.get("seasonal"):
        from game import calendar as CAL
        mult *= SEASON_FACTOR.get(CAL.season(world, state.minutes if minute is None else minute), 1.0)
        c = claim(state, b.fields.get("claim") or "")
        st = settlement_of(state, c) if c is not None else None
        if st is not None and int(st.get("bad_harvest_until") or 0) > (state.minutes if minute is None else minute):
            mult *= 0.5                                  # a bad harvest in the settlement (game/colony.py)
    return {iid: per * mult for iid, per in prods}


def income_rate(world, state, b) -> float:
    """gp a day a staffed shop or inn brings in."""
    bp = bp_of(world, b)
    if bp is None or b.fields.get("status") != "done":
        return 0.0
    per = float(bp.fields.get("income") or 0)
    if per <= 0:
        return 0.0
    crew_ = [w for w in workers(state) if w.get("building") == b.id][:worker_cap(bp)]
    if not crew_:
        return 0.0
    town = world.entities.get(b.fields.get("town") or "")
    factor = INCOME_FACTOR.get(town_tier(town), 1.0) if town is not None else WILD_INCOME
    return per * factor * sum(speed(w) for w in crew_)


def upkeep(world, state) -> float:
    total = 0.0
    for b in finished(world):
        bp = bp_of(world, b)
        if bp is not None:
            total += float(bp.fields.get("upkeep") or 0)
    return total


def wage_bill(state) -> float:
    return sum(float(w.get("wage") or 0) for w in workers(state) if w.get("kind") == "hired")


def _rare_item(world, bp, rng) -> str:
    rows = [(_item_ref(world, r.get("item") or ""), float(r.get("weight") or 1)) for r in bp.fields.get("rare") or []]
    rows = [(i, wt) for i, wt in rows if i and wt > 0]
    if not rows:
        return ""
    t = rng.random() * sum(wt for _i, wt in rows)
    for i, wt in rows:
        t -= wt
        if t <= 0:
            return i
    return rows[-1][0]


def _catch_up(world, state, since: int, now: int) -> None:
    h = getattr(state, "holdings", None)
    if not h or (not h.get("jobs") and not h.get("workers") and not h.get("claims")):
        return
    run(world, state, since, now)


def run(world, state, since: int, now: int) -> None:
    """Everything the estate did between two minutes, a day (or less) at a time."""
    if now <= since:
        return
    d = data(state)
    span = now - since
    step = DAY if span <= 400 * DAY else max(DAY, span // 400)
    t = since
    reports: list[str] = []
    made: dict[str, dict] = {}
    earned = 0.0
    while t < now:
        t2 = min(now, (t // DAY + 1) * DAY if step == DAY else t + step)
        frac = (t2 - t) / DAY
        _construction(world, state, frac, reports)
        earned += _production(world, state, t, frac, made)
        new_days = t2 // DAY - t // DAY
        if new_days > 0:
            _pay_day(world, state, new_days, reports)
        t = t2
    if earned >= 0.01:
        d["till_total"] = float(d.get("till_total", 0)) + earned
    for bid, got in made.items():
        b = world.entities.get(bid)
        if b is None:
            continue
        bits = ", ".join(f"{n} {_item_name(world, i)}" for i, n in sorted(got.items()) if n > 0)
        if bits:
            reports.append(f"{b.name}: {bits}.")
    if reports:
        _h(state)["reports"].extend(reports[-12:])


def _construction(world, state, frac: float, reports: list) -> None:
    for job in list(build_jobs(state)):
        rate = pace(world) * crew(world, state, job["building"])
        job["done"] = float(job["done"]) + rate * frac
        if job["done"] >= float(job["work"]) - 1e-6:
            _finish(world, state, job, getattr(state, "bus", None))


def _production(world, state, minute: int, frac: float, made: dict) -> float:
    d = data(state)
    earned = 0.0
    for b in finished(world):
        bp = bp_of(world, b)
        if bp is None:
            continue
        r = rates(world, state, b, minute)
        if r:
            acc = d["acc"].setdefault(b.id, {})
            out = output(state, b.id)
            cap = storage_cap(world, b)
            for iid, per in r.items():
                acc[iid] = float(acc.get(iid, 0.0)) + per * frac
                whole = int(acc[iid] + 1e-9)
                if whole:
                    acc[iid] -= whole
                    room = max(0, cap - int(out.get(iid, 0)))
                    put = min(room, whole)
                    if put:
                        out[iid] = int(out.get(iid, 0)) + put
                        made.setdefault(b.id, {})[iid] = made.setdefault(b.id, {}).get(iid, 0) + put
            # skilled hands sometimes turn up something rare (automatons never do)
            hands = [w for w in workers(state) if w.get("building") == b.id and w.get("kind") in ("hired", "settler")
                     and w.get("skilled")][:worker_cap(bp)]
            if hands and bp.fields.get("rare"):
                rng = _rng("rare", b.id, minute // DAY)
                for _w in hands:
                    if rng.random() < RARE_CHANCE * frac:
                        iid = _rare_item(world, bp, rng)
                        if iid and int(out.get(iid, 0)) < cap:
                            out[iid] = int(out.get(iid, 0)) + 1
                            made.setdefault(b.id, {})[iid] = made.setdefault(b.id, {}).get(iid, 0) + 1
        inc = income_rate(world, state, b)
        if inc > 0:
            till = d["till"]
            till[b.id] = float(till.get(b.id, 0.0)) + inc * frac
            whole = int(till[b.id] * 100)
            if whole:
                till[b.id] -= whole / 100
                state.copper += whole
                earned += whole / 100
    return earned


def _pay_day(world, state, days: int, reports: list) -> None:
    """Upkeep and wages for the days that began. What can't be paid is owed; hands unpaid three days quit."""
    d = data(state)
    bill = (upkeep(world, state) + wage_bill(state)) * days + float(d.get("owed") or 0)
    if bill <= 0:
        return
    cost = int(round(bill * 100))
    if state.copper >= cost:
        state.copper -= cost
        d["owed"] = 0.0
        d["unpaid_days"] = 0
        return
    paid = max(0, state.copper)
    state.copper -= paid
    d["owed"] = (cost - paid) / 100
    d["unpaid_days"] = int(d.get("unpaid_days") or 0) + days
    if d["unpaid_days"] >= 3:
        quit_ = [w for w in workers(state) if w.get("kind") == "hired"]
        if quit_:
            _h(state)["workers"] = [w for w in workers(state) if w.get("kind") != "hired"]
            reports.append("Unpaid, your hired hands have quit: " + ", ".join(w.get("name", "?") for w in quit_) + ".")
            d["owed"] = max(0.0, d["owed"] - sum(float(w.get("wage") or 0) for w in quit_) * d["unpaid_days"])
        d["unpaid_days"] = 0
    else:
        reports.append(f"Your estate couldn't pay its way: {d['owed']:.2f} gp is owed.")


def collect(world, state, bid: str, bus=None) -> dict:
    """Take what's piled up at a building into the pack."""
    out = output(state, bid)
    got = {}
    for iid, n in list(out.items()):
        if n > 0:
            state.add_item(iid, int(n), "collected")
            got[iid] = int(n)
    out.clear()
    data(state)["output"].pop(bid, None)
    _save(world, state)
    if got and bus is not None:
        b = world.entities.get(bid)
        bus.emit("log", kind="loot", text=f"You collect from {b.name if b else 'your building'}: " +
                 ", ".join(f"{n} {_item_name(world, i)}" for i, n in got.items()) + ".")
    return got


def bar(world, state, npc) -> float | None:
    """The work bar over someone working one of your buildings: how far along today's next piece is (or the
    building going up)."""
    w = worker_of_npc(state, npc.id)
    if w is None or not w.get("building"):
        return None
    bid = w["building"]
    p = progress(world, state, bid)
    b = world.entities.get(bid)
    if b is not None and b.fields.get("status") == "building":
        return p
    acc = data(state)["acc"].get(bid) or {}
    if acc:
        return max(0.0, min(1.0, max(acc.values())))
    return ((state.minutes % DAY) - WORK_HOURS[0] * 60) / ((WORK_HOURS[1] - WORK_HOURS[0]) * 60) \
        if at_work(state.minutes) else None


# ======================================================================
# Homes and rooms (game/homes.py, game/rooms.py)
# ======================================================================
def homes_of(world) -> list:
    """Every building the party owns that's somewhere to sleep: bought houses and finished estate homes."""
    from game import homes
    return [b for b in world.entities.overlay_entities() if b.type == "building" and b.fields.get("owner")
            and (not b.fields.get("claim") or b.fields.get("status") == "done") and homes.perks(world, b).get("Rest")]


def room_materials(world, t: dict) -> list[tuple[str, int]]:
    """What a room tile takes to build onto a home: its own list, else timber and stone by its cost."""
    rows = t.get("materials") or []
    out = []
    if rows:
        for m in rows:
            iid = _item_ref(world, m.get("item") or "")
            if iid and int(m.get("count") or 0) > 0:
                out.append((iid, int(m["count"])))
        return out
    cost = float(t.get("cost") or 0)
    if cost <= 0:
        return []
    for name, n in (("Timber Plank", max(2, int(round(cost / 10)))), ("Stone Block", int(round(cost / 25)))):
        iid = _item_ref(world, name)
        if iid and n > 0:
            out.append((iid, n))
    return out


# ======================================================================
# Keeping the maps in step
# ======================================================================
def _changed(world, state, claim: str | None = None, town: str | None = None) -> None:
    """Something on a claim changed: the walking maps that show it are made again."""
    try:
        from game import area as A
        from game import worldmap
        if town:
            A.forget(f"town:{town}")
        wa = getattr(world, "_world_area", None)
        if wa is not None:
            if claim:
                c = next((c for c in claims(state) if c.get("id") == claim), None)
                if c is not None and c.get("rect"):
                    wa.reload_claim(c)
                elif c is None:
                    wa.drop_claim(claim)
            if town:
                wa.reload_town_id(town)
        world._estate_stamp = getattr(world, "_estate_stamp", 0) + 1
        _ = worldmap
    except Exception:  # noqa: BLE001 - the map is never worth failing over
        pass


def stamp(world) -> int:
    """Goes up whenever the estate's buildings change (the walking view redraws)."""
    return int(getattr(world, "_estate_stamp", 0))


def town_sig(world, town) -> tuple:
    """This save's claims in a town (they change how the town's map looks)."""
    st = getattr(world, "_state_for_places", None)
    if st is None or not getattr(st, "holdings", None):
        return ()
    lots = tuple(sorted(int(c.get("lot", -1)) for c in claims(st) if c.get("kind") == "lot"
                        and c.get("town") == town.id))
    if not lots:
        return ()
    bs = tuple((b.id, b.fields.get("status"), str(b.fields.get("place")), b.fields.get("blueprint"),
                str(b.fields.get("rooms")), str(b.fields.get("facilities")))
               for b in buildings(world) if b.fields.get("town") == town.id)
    return (lots, bs)


def lot_claims(world, town) -> dict:
    """{lot number: claim} this save owns in the town."""
    st = getattr(world, "_state_for_places", None)
    if st is None:
        return {}
    return {int(c.get("lot", -1)): c for c in claims(st) if c.get("kind") == "lot" and c.get("town") == town.id}


def claim_sig(world, c: dict) -> str:
    bs = [(b.id, b.fields.get("status"), str(b.fields.get("place")), b.fields.get("blueprint"), b.name,
           str(b.fields.get("rooms")), b.fields.get("facilities")) for b in buildings(world, c["id"])]
    return repr((c.get("rect"), c.get("name"), bs))


# ======================================================================
# Laying buildings into a walking map
# ======================================================================
def stamp_into(world, a, lv, b, ox: int, oy: int) -> None:
    """Lay one estate building into a map level, its claim's corner at (ox, oy)."""
    from game import area as A
    bp = bp_of(world, b)
    if bp is None:
        return
    pl = b.fields.get("place") or {}
    rot = int(pl.get("rot") or 0) % 4
    x, y = ox + int(pl.get("x") or 0), oy + int(pl.get("y") or 0)
    w, h = footprint(bp, rot)
    rng = _rng("estate", b.id)
    for yy in range(y - 1, y + h + 1):                       # clear the ground (trees, rocks) round it
        for xx in range(x - 1, x + w + 1):
            p = lv.prop_cells.get((xx, yy))
            if p is not None:
                lv.remove_prop(p)
            if (x <= xx < x + w and y <= yy < y + h) and not bp.fields.get("water"):
                lv.water.pop((xx, yy), None)
                lv.walls.pop((xx, yy), None)
                if lv.floor_at(xx, yy) in A.SOLID or lv.floor_at(xx, yy) in ("water", "sea"):
                    lv.set_floor(xx, yy, "dirt")
    status = b.fields.get("status") or "planned"
    if status != "done":
        _site(lv, x, y, w, h, rng, status)
        return
    st = style(bp)
    if st in ("building", "mine"):
        rows = places_rows(b, bp)
        p = A.Plan(b, rows, world)
        p.q = rot
        p.px, p.py = x, y
        A._stamp_town_building(world, a, lv, p, {}, 0, 0, "path")
        A._spawns_for(a, p)
        if st == "mine":
            info = a.buildings.get(b.id) or {}
            rx, ry, rw, rh = p.rect_of(rows[0])
            c = A._nearest_free(lv, rx + rw // 2 - 1, ry + rh // 2 - 1,
                                lambda xx, yy: rx < xx < rx + rw - 2 and ry < yy < ry + rh - 2, 4)
            if c is not None:
                lv.add_prop("cave_mouth", c[0], c[1])
            _ = info
        return
    _open(world, a, lv, b, bp, st, x, y, w, h, rot, rng)


def places_rows(b, bp) -> list[dict]:
    rows = [r for r in (b.fields.get("rooms") or []) if str(r.get("name") or "").strip()]
    return rows or rooms_of(bp)


def _site(lv, x, y, w, h, rng, status: str) -> None:
    """A building site: pegs at the corners, and (once work's begun) timber, stone and a cart."""
    for c in ((x, y), (x + w - 1, y), (x, y + h - 1), (x + w - 1, y + h - 1)):
        if lv.free(*c):
            lv.add_prop("fence", *c)
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            if (xx + yy) % 3 == 0:
                lv.set_floor(xx, yy, "dirt")
    if status == "building":
        for pid in ("crate", "log", "rubble", "barrel", "crate"):
            for _ in range(6):
                cx, cy = rng.randrange(x + 1, max(x + 2, x + w - 1)), rng.randrange(y + 1, max(y + 2, y + h - 1))
                if lv.free(cx, cy) and (pid != "log" or lv.free(cx + 1, cy)):
                    lv.add_prop(pid, cx, cy, rng.randrange(3))
                    break


def _open(world, a, lv, b, bp, st, x, y, w, h, rot, rng) -> None:
    """The open styles: a farm, a pen, a yard, a well, a stretch of wall, a gate."""
    loc = ""
    if st == "farm" or st == "pen":
        crop = rng.randrange(3)
        gap = (x + w // 2, y + h - 1) if rot % 2 == 0 else (x + w - 1, y + h // 2)
        for yy in range(y, y + h):
            for xx in range(x, x + w):
                edge = xx in (x, x + w - 1) or yy in (y, y + h - 1)
                lv.set_floor(xx, yy, "dirt" if st == "farm" else "grass")
                if edge and (xx, yy) != gap and (abs(xx - gap[0]) + abs(yy - gap[1])) > 0:
                    lv.add_prop("fence", xx, yy)
                elif st == "farm" and not edge and (yy - y) % 2 == 1:
                    lv.add_prop("crops", xx, yy, crop)
        if st == "pen":
            for pid in ("haybale", "barrel", "haybale"):
                cx, cy = rng.randrange(x + 1, x + w - 1), rng.randrange(y + 1, y + h - 1)
                if lv.free(cx, cy):
                    lv.add_prop(pid, cx, cy)
        elif lv.free(x + w, y):
            lv.add_prop("haybale", x + w, y)
    elif st == "yard":
        for yy in range(y, y + h):
            for xx in range(x, x + w):
                lv.set_floor(xx, yy, "wood" if bp.fields.get("water") else "dirt")
        if not bp.fields.get("water"):
            for pid in ("log", "log", "stump", "workbench", "crate", "log"):
                for _ in range(8):
                    cx, cy = rng.randrange(x + 1, max(x + 2, x + w - 2)), rng.randrange(y + 1, max(y + 2, y + h - 1))
                    if lv.free(cx, cy) and lv.free(cx + 1, cy):
                        lv.add_prop(pid, cx, cy)
                        break
        else:
            for c in ((x, y), (x + w - 1, y), (x, y + h - 1), (x + w - 1, y + h - 1)):
                lv.add_prop("barrel", *c) if lv.free(*c) else None
    elif st == "well":
        lv.add_prop("well", x + (w - 2) // 2, y + (h - 2) // 2)
    elif st in ("wall", "gate"):
        cells = [(xx, yy) for yy in range(y, y + h) for xx in range(x, x + w)]
        cells.sort()
        n = len(cells)
        for i, c in enumerate(cells):
            if st == "gate" and n // 2 - 1 <= i <= n // 2:
                lv.set_floor(c[0], c[1], "path")
                continue
            lv.walls[c] = "wood_wall"
    if a is not None:
        a.roofs.pop(b.id, None)
        _ = loc


def build_claim_area(world, wa, c: dict):
    """The walking map of a wild claim: the land as it lies (from the world's own ground), with the party's
    buildings on it. Laid into the open world by game/worldmap.py as a site."""
    from game import area as A
    from game import landchanges
    from game import worldmap as WM
    x0, y0, w, h = (int(v) for v in c["rect"])
    a = A.Area(f"claim:{c['id']}", "site", w, h, c.get("name") or "Your land")
    lv = A.Level("0", 0, 0, w, h, "grass")
    a.levels["0"] = lv
    names = wa.zone_names
    st = settlement_of(_state_of(world), c) if c.get("kind") == "settlement" else None
    town_zone = 0
    if st is not None and st.get("town") and world.entities.get(st["town"]) is not None:
        from game import colony
        a.settlement_town = st["town"]                  # its open ground is the settlement's green
        town_zone = a.zone_id(colony.street_id(st))
    for cy in range(y0 // WM.CH, (y0 + h - 1) // WM.CH + 1):
        for cx in range(x0 // WM.CH, (x0 + w - 1) // WM.CH + 1):
            X0, Y0 = cx * WM.CH, cy * WM.CH
            ch = WM.Chunk(cx, cy)
            wa._terrain(ch, X0, Y0)
            wa._roads_in(ch, X0, Y0)
            wa._zones(ch, X0, Y0)
            changes = landchanges.for_chunk(world, cx, cy)
            if changes:
                landchanges.apply(ch, changes)
            zmap = {}
            for j in range(WM.CH):
                Y = Y0 + j
                if not (y0 <= Y < y0 + h):
                    continue
                for i in range(WM.CH):
                    X = X0 + i
                    if not (x0 <= X < x0 + w):
                        continue
                    lx, ly = X - x0, Y - y0
                    lv.set_floor(lx, ly, ch.floor[j][i])
                    z = ch.zone[j][i]
                    if z not in zmap:
                        loc = names[z] if 0 <= z < len(names) else ""
                        zmap[z] = town_zone or (a.zone_id(loc) if loc else 0)
                    lv.set_zone(lx, ly, zmap[z])
                    if (X, Y) in ch.water:
                        lv.water[(lx, ly)] = ch.water[(X, Y)]
                    if (X, Y) in ch.walls:
                        lv.walls[(lx, ly)] = ch.walls[(X, Y)]
            for p in ch.props:
                if all(x0 <= q[0] < x0 + w and y0 <= q[1] < y0 + h for q in p.cells()):
                    lv.add_prop(p.id, p.x - x0, p.y - y0, p.variant, force=True)
    # a marker post at each corner of the claim, and its name on a sign
    for (px, py) in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        if lv.free(px, py):
            lv.add_prop("fence", px, py)
    sign = A._nearest_free(lv, w // 2, 1, None, 6)
    if sign is not None:
        lv.add_prop("signpost", *sign)
        lv.stations[sign] = {"kind": "claim_sign", "room": "", "spot": None, "claim": c["id"]}
    for b in buildings(world, c["id"]):
        try:
            stamp_into(world, a, lv, b, 0, 0)
        except Exception:  # noqa: BLE001 - one bad building never spoils the claim
            continue
    if town_zone:                                       # where newcomers wait, and the party arrives
        from game import colony
        mid = A._nearest_free(lv, w // 2, h // 2, lambda xx, yy: lv.zone_at(xx, yy) == town_zone, 30)
        if mid is not None:
            a.spawns[colony.street_id(st)] = ("0", mid[0], mid[1])
            if lv.free(mid[0] + 1, mid[1] + 1) and not any(p.id == "campfire" for p in lv.props):
                lv.add_prop("campfire", mid[0] + 1, mid[1] + 1)
    a.finish()
    return a


def _state_of(world):
    return getattr(world, "_state_for_places", None)


def _money(gp: float) -> str:
    from game.state import money_text
    return money_text(int(round(gp * 100)))


# ======================================================================
# Quests: the Build objective (game/quests.py)
# ======================================================================
def built_count(world, ref: str) -> int:
    """How many finished buildings this save has of a blueprint (by id or name; "" counts any)."""
    bp = blueprint(world, ref) if ref else None
    n = 0
    for b in finished(world):
        if not ref or (bp is not None and b.fields.get("blueprint") == bp.id) or \
                (bp is None and (b.fields.get("kind") or "").lower() == str(ref).lower()):
            n += 1
    return n


# ======================================================================
# The catch-up step
# ======================================================================
def _register() -> None:
    from game import ticker
    ticker.register("estate", _catch_up)


_register()

__all__ = ["ensure", "blueprints", "blueprint", "footprint", "materials", "missing", "summary", "claims", "claim",
           "buy_lot", "make_claim", "can_claim", "to_settlement", "pay", "arrived", "place", "can_place", "start",
           "remove", "progress", "days_left", "hire", "dismiss", "assign", "buy_automaton", "workers", "collect",
           "output", "rates", "income_rate", "upkeep", "wage_bill", "built_count", "stamp_into", "build_claim_area",
           "BUILTIN", "AUTOMATON", "LOT_PRICE", "CLAIMS"]
