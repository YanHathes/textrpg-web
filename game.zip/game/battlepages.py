"""A fight's buttons, page by page (Actions, Bonus actions, Movement, End turn, and what's under each), worked
out from the battle and whoever's turn it is; and what a won fight gives. No Qt here: the app's battle
controller (ui/battle/controller.py) and the browser version (web/fight.py) both use it.

Each entry: {"title", "sub", "tip", "enabled", and "page" (another page to open) or "action" (name, payload)}.
"""
from __future__ import annotations

from game.combat import conditions as CND


# ======================================================================
# Button pages
# ======================================================================
def _sign(n: int) -> str:
    return f"+{n}" if n >= 0 else str(n)


def budget_text(c) -> str:
    if c.action_used and c.attacks_left:
        act = f"{c.attacks_left} attack{'s' if c.attacks_left > 1 else ''} left"
    else:
        act = "ready" if not c.action_used else "used"
    parts = [f"Action {act}", f"Bonus {'used' if c.bonus_used else 'ready'}",
             f"Move {c.movement_left() * 5} ft"]
    if c.mana_max:
        parts.append(f"{c.mana_name} {c.mana}/{c.mana_max}")
    elif c.slots:
        parts.append("Slots " + " ".join(f"{l}:{n}" for l, n in sorted(c.slots.items())))
    parts.append("Reaction used" if c.reaction_used else "Reaction ready")
    if c.conditions:
        parts.append(CND.summary(c))
    if c.concentration:
        parts.append(f"Concentrating: {c.concentration.get('name')}")
    return "   ·   ".join(parts)


def _spell_entries(b, c, timing: str, prefix: str, pages: dict, parent: str) -> list[dict]:
    entries = []
    for i, (spell, _lowest) in enumerate(b.castable(c, timing)):
        levels = b.slot_levels(c, spell)
        tag = "cantrip" if spell.level == 0 else f"level {spell.level}"
        what = spell.damage or (f"heals {spell.healing}" if spell.healing else "")
        sub = f"{tag}{'  ·  ' + what if what else ''}"
        if spell.level and b.uses_mana(c):
            sub += f"  ·  {b.mana_cost(spell.level)} {c.mana_name}"
        tip = spell.describe()
        if len(levels) > 1:
            name = f"{prefix}{i}"
            pages[name] = {"title": f"{spell.name}: cast at level", "parent": parent, "entries": [
                {"title": f"Level {lvl}", "sub": (f"{b.mana_cost(lvl)} {c.mana_name}" if b.uses_mana(c)
                                                    else f"{c.slots.get(lvl, 0)} left"), "tip": tip,
                 "action": ("cast", (spell, lvl))} for lvl in levels]}
            entries.append({"title": spell.name, "sub": sub, "tip": tip, "page": name})
        else:
            entries.append({"title": spell.name, "sub": sub, "tip": tip, "action": ("cast", (spell, levels[0]))})
    return entries


def _feature_entries(b, c, timing: str) -> list[dict]:
    entries = []
    for f in b.feature_options(c, timing):
        tip = f.description or f.name
        uses = f.uses_text()
        sub = (uses or ("free" if timing == "Free" else timing.lower()))
        opts = f.options()
        if len(opts) > 1:
            for o in opts:
                entries.append({"title": o, "sub": f.name, "tip": tip, "action": ("feature", (f, o))})
        else:
            entries.append({"title": f.name, "sub": sub, "tip": tip,
                            "action": ("feature", (f, opts[0] if opts else None))})
    return entries


def build_pages(b, c, mode: str, pending) -> dict:
    act = not c.action_used
    pages: dict[str, dict] = {}

    # ----- actions
    attack_entries = [{"title": a.name, "sub": f"{_sign(a.to_hit)}  ·  {a.damage} {a.damage_type}",
                       "tip": a.describe(), "action": ("attack", a)} for a in c.attacks]
    pages["attack"] = {"title": "Attack with", "parent": "actions", "entries": attack_entries}
    spell_entries = _spell_entries(b, c, "Action", "aslot", pages, "spells")
    pages["spells"] = {"title": "Cast a spell (action)", "parent": "actions", "entries": spell_entries}
    item_entries = [{"title": c.items[i].name, "sub": f"x{c.items[i].count}", "tip": f"Use {c.items[i].name}",
                     "action": ("item", i)} for i in b.usable_items(c, "Action")]
    pages["items"] = {"title": "Use an item (action)", "parent": "actions", "entries": item_entries}
    feat_entries = _feature_entries(b, c, "Action") + _feature_entries(b, c, "Free")
    pages["features"] = {"title": "Features", "parent": "actions", "entries": feat_entries}
    more = []
    can_hit = b.can_attack(c)
    for o in b.grapple_targets(c):
        more.append({"title": f"Grapple {o.name}", "sub": "Athletics contest", "enabled": can_hit,
                     "tip": "Replaces one attack. A grappled creature can't move.", "action": ("grapple", o)})
    for o in [o for o in b.enemies_of(c) if b.distance(c, o) <= 1 and o.size <= c.size + 1]:
        more.append({"title": f"Shove {o.name}", "sub": "knock prone", "enabled": can_hit,
                     "tip": "Replaces one attack: knock them prone (melee attacks against them get advantage).",
                     "action": ("shove", o)})
        more.append({"title": f"Push {o.name}", "sub": "5 ft away", "enabled": can_hit,
                     "tip": "Replaces one attack: push them 5 feet away.", "action": ("push", o)})
    for o in b.help_targets(c):
        more.append({"title": f"Help {o.name}", "sub": "advantage", "enabled": act,
                     "tip": f"{o.name}'s next attack roll has advantage.", "action": ("help", o)})
    if act and b.can_hide(c):
        more.append({"title": "Hide", "sub": "Stealth", "tip": "No enemy can see you here: hide. Your next attack "
                                                              "has advantage.", "action": ("hide", None)})
    if act and "Grappled" in c.conditions:
        more.append({"title": "Break free", "sub": "Athletics contest", "tip": "Escape the grapple.",
                     "action": ("escape", None)})
    pages["more"] = {"title": "More actions", "parent": "actions", "entries": more or [
        {"title": "Nothing", "sub": "", "enabled": False, "tip": "Get next to someone to grapple, shove or help."}]}
    if c.action_used and c.attacks_left:
        attack_sub = f"{c.attacks_left} left"
    elif c.attacks_per_action > 1:
        attack_sub = f"{c.attacks_per_action} attacks"
    else:
        attack_sub = "weapon or unarmed"
    pages["actions"] = {"title": "Actions", "parent": "main", "entries": [
        {"title": "Attack", "sub": attack_sub, "tip": "Attack with a weapon you're holding, or unarmed",
         "page": "attack", "enabled": bool(c.attacks) and b.can_attack(c)},
        {"title": "Spells", "sub": f"{len(spell_entries)} ready" if spell_entries else "none",
         "tip": "Spells that take an action to cast", "page": "spells", "enabled": bool(spell_entries)},
        {"title": "Items", "sub": f"{len(item_entries)} usable" if item_entries else "none",
         "tip": "Items you can use with your action", "page": "items", "enabled": bool(item_entries)},
        {"title": "Features", "sub": f"{len(feat_entries)} ready" if feat_entries else "none",
         "tip": "Class features and abilities used with an action (or free)", "page": "features",
         "enabled": bool(feat_entries)},
        {"title": "More", "sub": f"{len(more)} options" if more else "none",
         "tip": "Grapple, shove, help an ally, hide, break free", "page": "more", "enabled": bool(more)},
        {"title": "Dash", "sub": "double move", "tip": "Double your movement this turn", "action": ("dash", None),
         "enabled": act},
        {"title": "Dodge", "sub": "defend", "tip": "Attacks against you have disadvantage until your next turn",
         "action": ("dodge", None), "enabled": act},
        {"title": "Disengage", "sub": "slip away", "tip": "Move without provoking opportunity attacks",
         "action": ("disengage", None), "enabled": act},
        *[{"title": f"Stabilize {o.name}", "sub": "Medicine DC 10",
           "tip": f"{o.name} is dying. Use your action to try to stop it (Wisdom (Medicine), DC 10).",
           "action": ("stabilize", o), "enabled": act} for o in b.dying_allies(c)],
        {"title": "Flee", "sub": "map edge", "tip": "Leave the battle (stand at the edge of the map)",
         "action": ("flee", None), "enabled": act and b.at_edge(c)},
    ]}

    # ----- bonus actions
    bonus: list[dict] = []
    for a in c.bonus_attacks:
        ready = b.can_offhand(c)
        bonus.append({"title": a.name, "sub": f"{_sign(a.to_hit)}  ·  {a.damage}" if ready
                      else "attack with a light weapon first",
                      "tip": "Two-weapon fighting: after attacking with a light weapon, attack with the other one",
                      "action": ("attack", a), "enabled": ready})
    if not c.bonus_used:
        bonus += _spell_entries(b, c, "Bonus action", "bslot", pages, "bonus")
        bonus += [{"title": c.items[i].name, "sub": f"x{c.items[i].count}", "tip": f"Use {c.items[i].name}",
                   "action": ("item", i)} for i in b.usable_items(c, "Bonus action")]
        bonus += _feature_entries(b, c, "Bonus action")
    if not bonus:
        bonus = [{"title": "Nothing", "sub": "no bonus actions", "enabled": False,
                  "tip": "Nothing you have takes a bonus action right now"}]
    pages["bonus"] = {"title": "Bonus actions", "parent": "main", "entries": bonus}

    # ----- main
    any_action = (b.can_attack(c) and bool(c.attacks)) or act or bool(b.feature_options(c, "Free"))
    pages["main"] = {"title": "", "parent": None, "entries": [
        {"title": "Actions", "sub": budget_bit(c), "tip": "Attack, cast a spell, use an item...",
         "page": "actions", "enabled": any_action},
        {"title": "Bonus actions", "sub": "used" if c.bonus_used else "ready",
         "tip": "Quick extras: off-hand attacks, bonus-action spells, items and features",
         "page": "bonus", "enabled": not c.bonus_used and b.bonus_options(c)},
        {"title": "Movement", "sub": f"{c.movement_left() * 5} ft", "tip": "Show where you can move",
         "action": ("move", None), "enabled": c.movement_left() > 0},
        {"title": "End turn", "sub": "", "tip": "Finish your turn", "action": ("end", None), "id": "end"},
    ]}
    title = {"attack": f"Attacking with {pending.name}" if mode == "attack" and pending else "Choose a target",
             "spell": f"Casting {pending[0].name}" if mode == "spell" and pending else "Choose a target",
             "feature": f"Using {pending[0].name}" if mode == "feature" and pending else "Choose a target"}
    pages["target"] = {"title": title.get(mode, "Choose a target"), "parent": None, "entries": []}
    pages["move"] = {"title": "Movement", "parent": None, "entries": []}
    return pages


def budget_bit(c) -> str:
    if c.action_used and c.attacks_left:
        return f"{c.attacks_left} attack{'s' if c.attacks_left > 1 else ''} left"
    return "used" if c.action_used else "ready"


def describe_rewards(world, rewards: dict) -> list[str]:
    lines = []
    if rewards.get("xp"):
        lines.append(f"{rewards['xp']} experience")
    if rewards.get("gold"):
        lines.append(f"{rewards['gold']} gold")
    for item_id, n in (rewards.get("items") or {}).items():
        item = world.entities.get(item_id)
        lines.append(f"{item.name if item else item_id} x{n}")
    return lines


def condition_word(c) -> str:
    """How an enemy looks, without giving away its exact hit points, plus any conditions."""
    if not c.alive:
        return "Defeated"
    extra = ""
    if getattr(c, "conditions", None):
        from game.combat.conditions import summary
        extra = "  ·  " + summary(c)
    return _health_word(c) + extra


def _health_word(c) -> str:
    frac = c.hp / max(1, c.max_hp)
    if frac >= 1:
        return "Unhurt"
    if frac > 0.6:
        return "Scratched"
    if frac > 0.3:
        return "Wounded"
    if frac > 0.1:
        return "Badly wounded"
    return "Near death"


__all__ = ["condition_word", "build_pages", "budget_text", "budget_bit", "describe_rewards"]
