"""Changes to the open world's land made in one playthrough: a tree cut down, a vein dug out, a building
put up. The land itself is always made afresh from the world's seed; these are kept in the save
(state.world_changes) and laid on top of each map chunk as it's built.

    state.world_changes = {"cx,cy": {"x,y": {change}}}

A change can set any of:
    "floor":   the ground there ("dirt", "stone"...)
    "prop":    the object there ("stump"); "" takes away whatever stood there
    "variant": which picture of the object
    "wall":    a wall kind; "" takes a wall away
and it can carry "until": the minute it wears off (a stump grows back into a tree), plus "day", the day
it happened. A change with "then" (another change) doesn't wear off to nothing but turns into that one when
its time is up (ash, then saplings, then trees: game/fire.py). Recording a change forgets only that chunk's cached squares, so nothing else is rebuilt.

Towns, dungeons and the sites laid into the world are not made in chunks: their levels are built whole
(game/area.py). Their changes are kept under "lvl:<level's change key>" (set when the level is built: see
tag_area) with squares counted from the level's own corner, so they land in the same place whether the
town stands alone or is laid into the open world:

    state.world_changes["lvl:town:town.ashford/base"] = {"3,7": {"prop": "stump", "until": ..., ...}}

and are laid onto the level each time it's built (apply_level), and straight onto the levels already built
when they're made or wear off.
"""
from __future__ import annotations

import weakref

from game import ticker

CH = 32          # squares per chunk side (game/worldmap.py)


def chunk_key(cx: int, cy: int) -> str:
    return f"{cx},{cy}"


def _cell_key(x: int, y: int) -> str:
    return f"{x},{y}"


def _state(world):
    return getattr(world, "_state_for_places", None)


def for_chunk(world, cx: int, cy: int) -> dict:
    """{(x, y): change} for the changes in force in this chunk (the running game's)."""
    state = _state(world)
    if state is None:
        return {}
    got = state.world_changes.get(chunk_key(cx, cy))
    if not got:
        return {}
    now = state.minutes
    out = {}
    for k, chg in got.items():
        until = chg.get("until")
        if until is not None and now >= int(until):
            continue
        x, y = (int(v) for v in k.split(","))
        out[(x, y)] = chg
    return out


def apply(ch, changes: dict) -> None:
    """Lay the changes onto a freshly made chunk."""
    if not changes:
        return
    from game import area as A
    X0, Y0 = ch.cx * CH, ch.cy * CH
    for (x, y), chg in changes.items():
        c = (x, y)
        if "floor" in chg and chg["floor"]:
            ch.floor[y - Y0][x - X0] = chg["floor"]
        if "wall" in chg:
            if chg["wall"]:
                ch.walls[c] = chg["wall"]
            else:
                ch.walls.pop(c, None)
                ch.windows.discard(c)
        if "prop" in chg:
            old = ch.prop_cells.pop(c, None)
            if old is not None:
                for cc in old.cells():                     # all of a big thing's squares
                    if ch.prop_cells.get(cc) is old:
                        del ch.prop_cells[cc]
                try:
                    ch.props.remove(old)
                except ValueError:
                    pass
            if chg["prop"]:
                p = A.AProp(chg["prop"], x, y, int(chg.get("variant") or 0))
                ch.props.append(p)
                ch.prop_cells[c] = p


def forget_chunk(world, cx: int, cy: int, bus=None) -> None:
    """Drop the cached chunk so it's built again with the changes (and tell the map view)."""
    area = getattr(world, "_world_area", None)
    if area is not None:
        base = area.levels.get("0")
        if base is not None and getattr(base, "chunked", False):
            base.chunks.pop((cx, cy), None)
            base._last = None
    if bus is not None:
        bus.emit("land.changed", cx=cx, cy=cy)


def forget_all(world, state=None) -> None:
    """Another save was loaded: every cached chunk may be wrong (and every level built whole)."""
    try:
        refresh_levels(world, state)
    except Exception:  # noqa: BLE001 - never stop a load over scenery
        pass
    area = getattr(world, "_world_area", None)
    if area is not None:
        base = area.levels.get("0")
        if base is not None and getattr(base, "chunked", False):
            base.chunks.clear()
            base._last = None


def record(world, state, x: int, y: int, change: dict, bus=None, save: bool = True) -> dict:
    """Change one square of the land in this playthrough (save=False: many at once, saved after)."""
    x, y = int(x), int(y)
    cx, cy = x // CH, y // CH
    chg = dict(change)
    chg.setdefault("day", state.day)
    state.world_changes.setdefault(chunk_key(cx, cy), {})[_cell_key(x, y)] = chg
    if save:
        state.save()
    forget_chunk(world, cx, cy, bus)
    return chg


def undo(world, state, x: int, y: int, bus=None) -> bool:
    """Put one square back as the world made it."""
    x, y = int(x), int(y)
    cx, cy = x // CH, y // CH
    ck = chunk_key(cx, cy)
    cell = state.world_changes.get(ck, {})
    if cell.pop(_cell_key(x, y), None) is None:
        return False
    if not cell:
        state.world_changes.pop(ck, None)
    state.save()
    forget_chunk(world, cx, cy, bus)
    return True


def change_at(state, x: int, y: int) -> dict | None:
    if not getattr(state, "world_changes", None):
        return None
    chg = state.world_changes.get(chunk_key(int(x) // CH, int(y) // CH), {}).get(_cell_key(x, y))
    if chg is None:
        return None
    until = chg.get("until")
    if until is not None and state.minutes >= int(until):
        return None
    return chg


def _wear_off(world, state, since: int, now: int) -> None:
    """Catch-up: changes whose time is up are dropped (a stump has grown back)."""
    bus = getattr(state, "bus", None)
    for ck in list(state.world_changes):
        cells = state.world_changes[ck]
        gone = [k for k, chg in cells.items() if chg.get("until") is not None and now >= int(chg["until"])]
        if not gone:
            continue
        turned = {}
        for k in gone:
            then = cells[k].get("then")
            while then and then.get("until") is not None and now >= int(then["until"]):
                then = then.get("then")                         # (a long while away: on through the stages)
            if then:
                turned[k] = dict(then)
                cells[k] = turned[k]
            else:
                del cells[k]
        if not cells:
            del state.world_changes[ck]
        if ck.startswith(LVL):
            for lv in _live_levels(ck[len(LVL):]):
                for k in gone:
                    rx, ry = (int(v) for v in k.split(","))
                    _revert_one(lv, lv.ox + rx, lv.oy + ry)
                    if k in turned:
                        _apply_one(lv, lv.ox + rx, lv.oy + ry, turned[k])
                    if bus is not None:
                        bus.emit("land.changed", cx=(lv.ox + rx) // CH, cy=(lv.oy + ry) // CH)
            continue
        cx, cy = (int(v) for v in ck.split(","))
        forget_chunk(world, cx, cy, bus)


# ----------------------------------------------------------------------------------------------------
# Levels built whole (towns, dungeons, sites)
# ----------------------------------------------------------------------------------------------------
LVL = "lvl:"
_live: dict[str, list] = {}           # change key -> [weakref to each built level with it]


def tag_area(area, prefix: str) -> None:
    """Give each level of a freshly built area its change key ("town:<id>/base", "dungeon:<id>/f0"...)."""
    for k, lv in area.levels.items():
        lv.change_key = f"{prefix}/{'base' if k == area.base_key else k}"


def _live_levels(key: str) -> list:
    refs = _live.get(key) or []
    out = [r() for r in refs]
    out = [lv for lv in out if lv is not None]
    if len(out) != len(refs):
        _live[key] = [weakref.ref(lv) for lv in out]
    return out


def _apply_one(lv, x: int, y: int, chg: dict) -> None:
    from game import area as A
    c = (x, y)
    if ("wall" in chg or chg.get("floor")) and lv.inside(x, y):      # walls and ground (game/destruction.py)
        under = lv.__dict__.setdefault("_orig_ground", {})
        if c not in under:
            under[c] = (lv.walls.get(c), c in lv.windows, lv.floor_at(x, y))
        if "wall" in chg:
            if chg["wall"]:
                lv.walls[c] = chg["wall"]
            else:
                lv.walls.pop(c, None)
                lv.windows.discard(c)
        if chg.get("floor"):
            lv.set_floor(x, y, chg["floor"])
    if "prop" not in chg:
        return
    orig = lv.__dict__.setdefault("_orig", {})
    old = lv.prop_cells.get(c)
    if c not in orig:
        orig[c] = old
    if old is not None:
        lv.remove_prop(old)
    if chg["prop"]:
        p = A.AProp(chg["prop"], x, y, int(chg.get("variant") or 0))
        lv.props.append(p)
        lv.prop_cells[c] = p


def _revert_one(lv, x: int, y: int) -> None:
    c = (x, y)
    under = lv.__dict__.get("_orig_ground") or {}
    if c in under:
        wall, window, floor = under.pop(c)
        if wall:
            lv.walls[c] = wall
        else:
            lv.walls.pop(c, None)
        if window:
            lv.windows.add(c)
        lv.set_floor(x, y, floor)
    orig = lv.__dict__.get("_orig") or {}
    if c not in orig:
        return
    now = lv.prop_cells.get(c)
    if now is not None:
        lv.remove_prop(now)
    was = orig.pop(c)
    if was is not None:
        lv.props.append(was)
        for cc in was.cells():
            lv.prop_cells[cc] = was


def apply_level(world, lv, state=None) -> None:
    """Lay this playthrough's changes onto a level built whole (and keep track of it, for later changes)."""
    key = getattr(lv, "change_key", "")
    if not key:
        return
    refs = _live.setdefault(key, [])
    if not any(r() is lv for r in refs):
        refs.append(weakref.ref(lv))
    for c in list(set(lv.__dict__.get("_orig") or {}) | set(lv.__dict__.get("_orig_ground") or {})):
        _revert_one(lv, *c)                                     # another save's changes come off first
    state = state if state is not None else _state(world)
    if state is None:
        return
    got = state.world_changes.get(LVL + key)
    if not got:
        return
    now = state.minutes
    for k, chg in got.items():
        until = chg.get("until")
        if until is not None and now >= int(until):
            continue
        rx, ry = (int(v) for v in k.split(","))
        _apply_one(lv, lv.ox + rx, lv.oy + ry, chg)


def apply_area(world, area, state=None) -> None:
    for lv in area.levels.values():
        if not getattr(lv, "chunked", False):
            apply_level(world, lv, state)


def record_level(world, state, lv, x: int, y: int, change: dict, bus=None, save: bool = True) -> dict:
    """Change one square of a level built whole (a tree in town cut down, a vein in a mine dug out)."""
    key = getattr(lv, "change_key", "")
    chg = dict(change)
    chg.setdefault("day", state.day)
    x, y = int(x), int(y)
    if key:
        state.world_changes.setdefault(LVL + key, {})[_cell_key(x - lv.ox, y - lv.oy)] = chg
        if save:
            state.save()
        levels = _live_levels(key)
        if lv not in levels:
            levels.append(lv)
            _live[key].append(weakref.ref(lv))
        for other in levels:
            _apply_one(other, other.ox + x - lv.ox, other.oy + y - lv.oy, chg)
    else:
        _apply_one(lv, x, y, chg)                     # nowhere to keep it: just this once
    if bus is not None:
        bus.emit("land.changed", cx=x // CH, cy=y // CH)
    return chg


def undo_level(world, state, key: str, x: int, y: int, bus=None) -> bool:
    """Put one square of a level built whole back as the world made it (x, y: the map's own squares)."""
    for lv in _live_levels(key):
        cell = state.world_changes.get(LVL + key, {})
        k = _cell_key(int(x) - lv.ox, int(y) - lv.oy)
        if cell.pop(k, None) is not None:
            if not cell:
                state.world_changes.pop(LVL + key, None)
            for other in _live_levels(key):
                _revert_one(other, other.ox + int(x) - lv.ox, other.oy + int(y) - lv.oy)
            state.save()
            if bus is not None:
                bus.emit("land.changed", cx=int(x) // CH, cy=int(y) // CH)
            return True
        return False
    return False


def level_change_at(state, lv, x: int, y: int) -> dict | None:
    key = getattr(lv, "change_key", "")
    if not key:
        return None
    chg = state.world_changes.get(LVL + key, {}).get(_cell_key(int(x) - lv.ox, int(y) - lv.oy))
    if chg is None:
        return None
    until = chg.get("until")
    if until is not None and state.minutes >= int(until):
        return None
    return chg


def change_on(state, lv, x: int, y: int) -> dict | None:
    """The change in force on a square of any level (chunked or built whole)."""
    if getattr(lv, "chunked", False):
        return change_at(state, x, y)
    return level_change_at(state, lv, x, y)


def refresh_levels(world, state=None) -> None:
    """Another save was loaded: lay its changes on every level built whole (taking the last one's off)."""
    for key in list(_live):
        for lv in _live_levels(key):
            apply_level(world, lv, state)


ticker.register("land", _wear_off)

__all__ = ["for_chunk", "apply", "record", "undo", "change_at", "forget_chunk", "forget_all", "chunk_key",
           "tag_area", "apply_level", "apply_area", "record_level", "level_change_at", "change_on", "undo_level",
           "refresh_levels"]
