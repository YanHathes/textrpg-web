"""Brothels (Hotfix 21): a house in every capital, built like an inn but given over almost entirely to private
rooms, with a madam, a doorkeeper and its courtesans (game/worldfill.py, places version 5).

Hiring a courtesan (talk to one: "Shall we go upstairs?") costs their price. The one who goes:
    - makes a Constitution save (DC POX_DC) or catches the pox (game/survival.py "Lover's Pox"; only in a
      world with disease turned on, its "disease_curses" rule, as with every other disease),
    - and makes a Charisma (Performance) check: the screen cuts to black, a floorboard squeaks, and time moves
      on by an amount that grows with the roll (minutes_for). A natural 20: four hours, and the courtesan
      won't take your money (it's handed back).
Nothing is kept in the save beyond the time, the coin and the disease (state.survival).
"""
from __future__ import annotations

import random
import zlib

KIND = "Brothel"
WORKER = "Courtesan"
PRICE = (10, 30)                # gp, by the courtesan
POX = "Lover's Pox"
POX_DC = 12
NAT20_MINUTES = 4 * 60
MOST_MINUTES = 3 * 60 + 30      # (short of a natural 20's four hours)
LEAST_MINUTES = 10
BLACKOUT = {"seconds": 4.5, "sound": "squeak", "text": "Some time later..."}


def is_worker(world, npc) -> bool:
    if npc is None or (npc.fields.get("title") or "") != WORKER:
        return False
    b = world.entities.get(npc.fields.get("building") or "")
    return b is not None and (b.fields.get("kind") or "") == KIND


def price(npc) -> int:
    lo, hi = PRICE
    return lo + zlib.crc32(("brothel|" + npc.id).encode("utf-8")) % (hi - lo + 1)


def performance_option(world):
    """Charisma (Performance), or a plain Charisma check in a world without that skill."""
    from game import checks
    opts = checks.options(world)
    return next((o for o in opts if o["label"] == "Performance"), None) or \
        next((o for o in opts if o["label"] == "Charisma check"), None)


def bonus(world, member) -> int:
    from game import checks, condition
    c = condition.combatant(world, member)
    opt = performance_option(world)
    return checks.bonus(world, member, c, opt)[0] if opt else c.mod("cha")


def minutes_for(total: int, natural: int, rng=None) -> int:
    """How long it goes on: longer the better the roll. A natural 20 is four hours."""
    if natural == 20:
        return NAT20_MINUTES
    rng = rng or random.Random()
    base = max(1, int(total)) * 8 + rng.randint(-5, 5)
    return max(LEAST_MINUTES, min(MOST_MINUTES, base))


def visit(world, state, members, member_id: str, npc, rng=None, bus=None) -> dict:
    """The party member goes upstairs with the courtesan. Returns {"ok", "lines", "minutes", "refund",
    "natural", "caught", "blackout"}."""
    from game import checks, condition, survival
    from game.state import money_text
    rng = rng or random.Random()
    m = next((x for x in members if x["id"] == member_id and not x.get("dead")), None)
    if m is None or not is_worker(world, npc):
        return {"ok": False, "lines": ["That won't be possible."]}
    cost = price(npc) * 100
    if state.copper < cost:
        return {"ok": False, "lines": [f"\"{money_text(cost)}, love. Come back when you have it.\""]}
    state.add_copper(-cost, f"{npc.name}'s company")
    c = condition.combatant(world, m)
    lines = [f"{c.name} pays {money_text(cost)} and follows {npc.name} upstairs."]
    caught = False
    if survival.diseases_on(world):                      # the Constitution save (in the log)
        b = c.mod("con") + (c.prof if "con" in (c.saves or set()) else 0)
        d = rng.randint(1, 20)
        ok = d + b >= POX_DC
        text = f"{c.name}: Constitution save {d}{b:+d} = {d + b} vs DC {POX_DC}: " + ("saved" if ok else "failed")
        if bus is not None:
            bus.emit("log", kind="roll", text=text)
        if not ok:
            caught = survival.infect(world, state, m, POX, rng, source=f"{npc.name}, at the brothel", save=False)
    opt = performance_option(world)
    if opt is not None:
        r = checks.roll(world, m, c, opt, 0, rng=rng, bus=bus, target=npc.name)
        natural, total = int(r.get("roll") or 0), int(r.get("total") or 0)
    else:
        natural = rng.randint(1, 20)
        total = natural + c.mod("cha")
        if bus is not None:
            bus.emit("log", kind="roll", text=f"{c.name}: Performance {natural}{c.mod('cha'):+d} = {total}")
    minutes = minutes_for(total, natural, rng)
    state.advance(minutes, "the brothel")
    hours, mins = divmod(minutes, 60)
    took = (f"{hours} hour{'s' if hours != 1 else ''}" if hours else "") + \
        (" and " if hours and mins else "") + (f"{mins} minutes" if mins else "")
    refund = natural == 20
    if refund:
        state.add_copper(cost, f"{npc.name} won't take it")
        lines.append(f"Four hours later {npc.name} presses the coin back into {c.name}'s hand. \"Keep it. "
                     "I should be paying you.\"")
    elif total >= 20:
        lines.append(f"{took} later they come back down, {npc.name} looking rather pleased.")
    elif total >= 10:
        lines.append(f"{took} later they come back down.")
    else:
        lines.append(f"Barely {took} later they're back down. {npc.name} is very polite about it.")
    state.save()
    return {"ok": True, "lines": lines, "minutes": minutes, "refund": refund, "natural": natural,
            "total": total, "caught": caught, "blackout": dict(BLACKOUT)}


__all__ = ["visit", "is_worker", "price", "minutes_for", "bonus", "KIND", "WORKER", "POX"]
