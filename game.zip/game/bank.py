"""Banks: accounts, loans, and the vault.

Accounts: deposit and withdraw at any bank (a Bank building's people). Every bank in a realm keeps the same
account, so money left in one city can be drawn in another of the same realm. Money in the bank is safe:
a party that falls wakes up with a lighter purse (a quarter gone), but nothing is taken from the bank.

Loans: how much a realm's banks will lend, and at what interest, follows the party's standing with the
realm (game/factions.py):

    Standing     Most you can borrow   Interest (on the whole loan, over its 8 weeks)
    Neutral      100 gp                40%
    Friendly     500 gp                30%
    Honored      2,000 gp              20%
    Revered      10,000 gp             10%
    Unfriendly or worse: no loans.

One loan at a time in each realm. It's repaid weekly through the catch-up step (game/ticker.py): from the
account in that realm first, then the purse. A payment that can't be made is missed: it costs standing with
the realm (more each time) and a late fee is added; after three missed payments in a row the bank posts a
bounty for the whole debt (game/law.py), which the watch will collect. Paying the loan off clears it.

The vault: every bank holds a sum (by the size of the town) that refills over a month after it's taken.
Robbing it is game/law.py's "bank robbery", the biggest bounty there is.

Kept in the save's holdings (holdings["bank"]): {"accounts": {realm: copper}, "loans": {realm: {...}},
"vaults": {bank id: {"taken": copper, "day": n}}}.
"""
from __future__ import annotations

import math

WEEKS = 8
LIMITS = {"Neutral": (100, 0.40), "Friendly": (500, 0.30), "Honored": (2000, 0.20), "Revered": (10000, 0.10)}
MISSES_TO_BOUNTY = 3
LATE_FEE = 0.10
MISS_STANDING = 5                    # standing lost for a missed payment (times how many in a row)
VAULT_GP = {"Hamlet": 200, "Village": 500, "Town": 1500, "City": 4000, "Capital": 10000}
REFILL_DAYS = 30
FALL_SHARE = 0.25                    # of the purse lost when the party falls


def data(state) -> dict:
    d = state.holdings.setdefault("bank", {})
    if not isinstance(d, dict):
        state.holdings["bank"] = d = {}
    d.setdefault("accounts", {})
    d.setdefault("loans", {})
    d.setdefault("vaults", {})
    return d


def _save(world, state) -> None:
    try:
        from game import holdings
        holdings.save(world, state)
    except Exception:  # noqa: BLE001
        pass
    state.save()


def _money(c: int) -> str:
    from game.state import money_text
    return money_text(int(c))


def is_bank(building) -> bool:
    return building is not None and (building.fields.get("kind") or "") == "Bank"


def bank_of(world, npc):
    from game import places
    b = world.entities.get(places.building_of(world, npc) or "") if npc is not None else None
    return b if is_bank(b) else None


def realm_of(world, building) -> str:
    from game import law
    return law.realm_key(world, world.entities.get(building.fields.get("town") or "")) if building else ""


# ----------------------------------------------------------------------------------------------------
# Accounts
# ----------------------------------------------------------------------------------------------------
def balance(state, key: str) -> int:
    return int(data(state)["accounts"].get(key, 0))


def deposit(world, state, key: str, copper: int) -> tuple[bool, str]:
    copper = int(copper)
    if copper <= 0:
        return False, "How much?"
    if copper > state.copper:
        return False, "You haven't that much."
    state.add_copper(-copper, "deposited")
    acc = data(state)["accounts"]
    acc[key] = acc.get(key, 0) + copper
    _save(world, state)
    return True, f"Deposited {_money(copper)}. The account holds {_money(acc[key])}."


def withdraw(world, state, key: str, copper: int) -> tuple[bool, str]:
    copper = int(copper)
    acc = data(state)["accounts"]
    if copper <= 0:
        return False, "How much?"
    if copper > acc.get(key, 0):
        return False, f"The account only holds {_money(acc.get(key, 0))}."
    acc[key] -= copper
    state.add_copper(copper, "withdrawn")
    _save(world, state)
    return True, f"Withdrew {_money(copper)}. {_money(acc[key])} left in the account."


def fell(world, state, bus=None) -> int:
    """The party has fallen: some of the purse is gone (the bank's money is safe). Returns copper lost."""
    lost = int(state.copper * FALL_SHARE)
    if lost > 0:
        state.add_copper(-lost, "lost while you lay senseless")
        if bus is not None:
            bus.emit("log", kind="system", text=f"Your purse is lighter by {_money(lost)}. (Money in a bank is "
                                                 f"safe.)")
    return lost


# ----------------------------------------------------------------------------------------------------
# Loans
# ----------------------------------------------------------------------------------------------------
def terms(world, state, key: str) -> tuple[int, float, str]:
    """(the most they'll lend in gp, interest over the loan, the standing it's from). (0, 0, why) for none."""
    from game import factions
    if key.startswith("town:"):
        t = world.entities.get(key[5:])
        f = factions.town_faction(world, t)
    else:
        f = factions.get(world, key)
    lvl = factions.level(world, state, f.id) if f is not None else "Neutral"
    if lvl not in LIMITS:
        return 0, 0.0, lvl
    gp, rate = LIMITS[lvl]
    return gp, rate, lvl


def loan(state, key: str) -> dict | None:
    return data(state)["loans"].get(key)


def borrow(world, state, key: str, gp: int) -> tuple[bool, str]:
    gp = int(gp)
    most, rate, lvl = terms(world, state, key)
    if loan(state, key):
        return False, "You already owe this realm's banks. Pay that off first."
    if most <= 0:
        return False, f"The bank won't lend to someone {lvl.lower()} in these parts."
    if gp <= 0 or gp > most:
        return False, f"They'll lend you up to {most} gp."
    owed = int(round(gp * 100 * (1 + rate)))
    weekly = int(math.ceil(owed / WEEKS))
    days = int(world.rules.get("days_per_week", 7) or 7)
    data(state)["loans"][key] = {"principal": gp * 100, "owed": owed, "weekly": weekly, "rate": rate,
                                 "due_day": state.day + days, "missed": 0, "started": state.day, "posted": False}
    state.add_copper(gp * 100, "a loan")
    state.ticks.setdefault("loans", state.minutes)
    _save(world, state)
    return True, f"You borrow {gp} gp. You'll owe {_money(owed)}, {_money(weekly)} a week for {WEEKS} weeks."


def repay(world, state, key: str, copper: int) -> tuple[bool, str]:
    ln = loan(state, key)
    if ln is None:
        return False, "You owe nothing here."
    copper = min(int(copper), ln["owed"], state.copper)
    if copper <= 0:
        return False, "You haven't the money."
    state.add_copper(-copper, "repaid a loan")
    ln["owed"] -= copper
    text = f"You pay {_money(copper)}."
    if ln["owed"] <= 0:
        _close(world, state, key)
        text += " The loan is paid off."
    else:
        ln["missed"] = 0
        text += f" {_money(ln['owed'])} still owed."
    _save(world, state)
    return True, text


def _close(world, state, key: str) -> None:
    data(state)["loans"].pop(key, None)
    from game import law
    for c in law.data(state)["crimes"]:                  # the debt bounty goes with it
        if c.get("kind") == "debt" and c.get("realm") == key and not c.get("settled"):
            c["settled"] = "paid"


def debt_settled(world, state, key: str) -> None:
    """The watch collected (a fine paid, or jail served): the debt is cleared."""
    data(state)["loans"].pop(key, None)
    _save(world, state)


def _week_due(world, state, key: str, ln: dict, bus=None) -> None:
    from game import factions, law
    pay = min(ln["weekly"], ln["owed"])
    acc = data(state)["accounts"]
    have = acc.get(key, 0)
    from_acc = min(have, pay)
    from_purse = min(state.copper, pay - from_acc)
    if from_acc + from_purse >= pay:
        acc[key] = have - from_acc
        if from_purse:
            state.copper -= from_purse
        ln["owed"] -= pay
        ln["missed"] = 0
        if ln["owed"] <= 0:
            _close(world, state, key)
        return
    ln["missed"] += 1
    ln["owed"] += int(round(pay * LATE_FEE))
    f = factions.get(world, key) if not key.startswith("town:") else \
        factions.town_faction(world, world.entities.get(key[5:]))
    if f is not None:
        factions.change(world, state, f.id, -MISS_STANDING * ln["missed"], "for a missed payment", bus)
    if ln["missed"] >= MISSES_TO_BOUNTY and not ln.get("posted"):
        ln["posted"] = True
        town = world.entities.get(key[5:]) if key.startswith("town:") else _a_town_of(world, key)
        c = law.commit(world, state, "debt", town, [law.LEDGER], ln["owed"] / 100, "", bus)
        c["realm"] = key


def _a_town_of(world, key: str):
    from game import law
    for t in world.entities.all("town"):
        if law.realm_key(world, t) == key:
            return t
    return None


def _catch_up(world, state, since: int, now: int) -> None:
    """Weekly payments that came due."""
    days = int(world.rules.get("days_per_week", 7) or 7)
    today = now // 1440 + 1
    for key, ln in list(data(state)["loans"].items()):
        guard = 0
        while ln is not None and today >= int(ln["due_day"]) and guard < 520:
            guard += 1
            ln["due_day"] = int(ln["due_day"]) + days
            _week_due(world, state, key, ln, None)
            ln = loan(state, key)
    try:
        from game import holdings
        holdings.save(world, state)
    except Exception:  # noqa: BLE001
        pass


# ----------------------------------------------------------------------------------------------------
# The vault
# ----------------------------------------------------------------------------------------------------
def vault_full(world, building) -> int:
    town = world.entities.get(building.fields.get("town") or "")
    return VAULT_GP.get((town.fields.get("kind") if town is not None else "") or "Town", 1500) * 100


def vault_holds(world, state, building) -> int:
    """Copper in the vault now (refilling over a month after a robbery)."""
    full = vault_full(world, building)
    v = data(state)["vaults"].get(building.id)
    if not v:
        return full
    back = full * max(0, state.day - int(v.get("day", state.day))) / REFILL_DAYS
    return int(min(full, full - int(v.get("taken", 0)) + back))


def empty_vault(world, state, building) -> int:
    got = vault_holds(world, state, building)
    data(state)["vaults"][building.id] = {"taken": vault_full(world, building), "day": state.day}
    return got


def rob(world, state, members, building, rng=None, explorer=None, bus=None) -> dict:
    """Into the vault (thieves' tools against its lock), out with what it holds. Whoever sees it (the vault
    guard, the tellers, anyone about) raises the alarm and goes on the bounty."""
    import random
    from game import law
    rng = rng or random.Random()
    town = world.entities.get(building.fields.get("town") or "")
    tier = (town.fields.get("kind") if town is not None else "") or "Town"
    dc = {"Hamlet": 12, "Village": 14, "Town": 16, "City": 18, "Capital": 20}.get(tier, 16)
    ok, total, who = law._check(world, members, "Thieves' Tools", dc, rng, bus, "the vault's lock")
    if who is None:
        return {"ok": False, "text": "Nobody here can work a lock like that.", "seen": [], "alarm": False}
    staff = [x for x in building.fields.get("npcs") or [] if not state.npc_dead(x)]
    seen = law.witnesses(world, state, members, explorer, rng, sneak=total if ok else 0, bus=bus)
    if explorer is None:                             # without the map, the staff are at hand while it's open
        from game import places
        if places.is_open(building, state.minute_of_day):
            guards = [x for x in staff if (world.entities.get(x).fields.get("occupation") or "") == "Guard"]
            seen = list(dict.fromkeys(seen + [g for g in guards if law._passive(world, g) >= (total if ok else 0)]))
    state.advance(10, "the vault")
    if not ok:
        if seen:
            law.commit(world, state, "bank robbery", town, seen, 0, building.id, bus)
        return {"ok": False, "seen": seen, "alarm": bool(seen),
                "text": f"{who.get('name')} can't get the vault open" + (", and the alarm goes up!" if seen else ".")}
    got = empty_vault(world, state, building)
    state.add_copper(got, "the vault")
    law.commit(world, state, "bank robbery", town, seen, got / 100, building.id, bus)
    _save(world, state)
    return {"ok": True, "copper": got, "seen": seen, "alarm": bool(seen),
            "text": f"{who.get('name')} opens the vault: {_money(got)}" +
                    ("! The alarm goes up." if seen else ", and nobody knows.")}


def _register() -> None:
    from game import ticker
    ticker.register("loans", _catch_up)


_register()

__all__ = ["is_bank", "bank_of", "realm_of", "balance", "deposit", "withdraw", "terms", "loan", "borrow", "repay",
           "fell", "vault_holds", "rob", "debt_settled", "LIMITS", "WEEKS", "MISSES_TO_BOUNTY"]
