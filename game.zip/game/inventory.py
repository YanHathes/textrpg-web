"""What each character carries and wears, the shared party pack, and using things.

Equipped items are always part of the character's own inventory (equipping only says
which slot an item is in). The party pack (GameState.inventory) is shared; things move
between it and characters.

Encumbrance (world rule "encumbrance"):
  Off       weight doesn't matter
  Standard  carrying more than 15 x Strength in pounds drops speed to 5 feet
  Variant   over 5 x Strength: -10 ft speed; over 10 x Strength: -20 ft and disadvantage
            on attacks, saves and checks using Strength, Dexterity or Constitution
"""
from __future__ import annotations

import random

from game import dice

MAX_ATTUNED = 3            # the usual limit (world rule attunement_slots); features with "Attunement slots" add more
HAND_SLOTS = ("Main hand", "Off hand")


def count(m: dict, item_id: str) -> int:
    return int((m.get("inventory") or {}).get(item_id, 0))


def add(m: dict, item_id: str, n: int = 1) -> dict:
    inv = dict(m.get("inventory") or {})
    inv[item_id] = inv.get(item_id, 0) + max(0, n)
    m["inventory"] = inv
    return m


def remove(m: dict, item_id: str, n: int = 1) -> int:
    inv = dict(m.get("inventory") or {})
    have = inv.get(item_id, 0)
    take = min(have, max(0, n))
    if have - take > 0:
        inv[item_id] = have - take
    else:
        inv.pop(item_id, None)
        # whatever isn't carried any more can't stay equipped or attuned
        m["equipment"] = {s: i for s, i in (m.get("equipment") or {}).items() if i != item_id}
        m["attuned"] = [i for i in (m.get("attuned") or []) if i != item_id]
    m["inventory"] = inv
    return take


def equipped_count(m: dict, item_id: str) -> int:
    return sum(1 for i in (m.get("equipment") or {}).values() if i == item_id)


def to_pack(state, m: dict, item_id: str, n: int = 1) -> int:
    free = count(m, item_id) - equipped_count(m, item_id)
    moved = remove(m, item_id, min(n, max(0, free)) if free > 0 else 0)
    if moved:
        state.add_item(item_id, moved, source="from a character")
    return moved


def from_pack(state, m: dict, item_id: str, n: int = 1) -> int:
    moved = state.remove_item(item_id, n, reason="to a character")
    if moved:
        add(m, item_id, moved)
    return moved


def give(m_from: dict, m_to: dict, item_id: str, n: int = 1) -> int:
    free = count(m_from, item_id) - equipped_count(m_from, item_id)
    moved = remove(m_from, item_id, min(n, max(0, free)))
    if moved:
        add(m_to, item_id, moved)
    return moved


def slots_for(item) -> list[str]:
    f = item.fields
    cat = f.get("category")
    if cat == "Weapon":
        return ["Main hand", "Off hand"]
    if cat == "Shield":
        return ["Off hand"]
    if cat == "Armor":
        return ["Body"]
    slot = f.get("slot") or ""
    if slot in ("", "None"):
        return []
    if slot == "Two hands":
        return ["Main hand"]
    return [slot]


def equip(world, m: dict, item_id: str, slot: str | None = None) -> tuple[bool, str]:
    item = world.entities.get(item_id)
    if item is None or count(m, item_id) <= 0:
        return False, "Not carried."
    allowed = slots_for(item)
    if not allowed:
        return False, f"{item.name} can't be worn or held."
    slot = slot if slot in allowed else allowed[0]
    eq = dict(m.get("equipment") or {})
    if equipped_count(m, item_id) >= count(m, item_id) and eq.get(slot) != item_id:
        # only one of them: move it rather than wear two
        eq = {s: i for s, i in eq.items() if i != item_id}
    two = "two-handed" in (item.fields.get("properties") or []) or item.fields.get("slot") == "Two hands"
    if slot == "Main hand" and two:
        eq.pop("Off hand", None)
    if slot == "Off hand":
        main = world.entities.get(eq.get("Main hand"))
        if main is not None and ("two-handed" in (main.fields.get("properties") or [])
                                 or main.fields.get("slot") == "Two hands"):
            eq.pop("Main hand", None)
    if any(bound for s2, i2 in (m.get("equipment") or {}).items() if s2 == slot and i2 != item_id
           for bound in [i2 in (m.get("bound") or [])]):
        return False, "What's there is cursed: it won't come off."
    eq[slot] = item_id
    m["equipment"] = eq
    msg = f"{item.name} equipped ({slot.lower()})."
    if item.fields.get("cursed"):                       # a cursed item binds itself (game/survival.py)
        st = getattr(world, "_state_for_places", None)
        if st is not None:
            from game import survival
            msg = survival.equipped(world, st, m, item_id) or msg
    return True, msg


def unequip(m: dict, slot: str) -> bool:
    """Take off what's in a slot (not a cursed item that's bound itself on: game/survival.py)."""
    eq = dict(m.get("equipment") or {})
    if eq.get(slot) and eq[slot] in (m.get("bound") or []):
        return False
    eq.pop(slot, None)
    m["equipment"] = eq
    return True


def attune(world, m: dict, item_id: str, on: bool = True) -> tuple[bool, str]:
    item = world.entities.get(item_id)
    att = list(m.get("attuned") or [])
    if item is None or not item.fields.get("requires_attunement"):
        return False, "That item doesn't need attunement."
    if not on:
        m["attuned"] = [i for i in att if i != item_id]
        return True, f"No longer attuned to {item.name}."
    if item_id in att:
        return True, ""
    if count(m, item_id) <= 0:
        return False, "Not carried."
    from game.character import attunement_limit
    limit = attunement_limit(world, m)
    if len(att) >= limit:
        return False, f"Already attuned to {limit} items."
    m["attuned"] = att + [item_id]
    return True, f"Attuned to {item.name}."


def weight(world, m: dict) -> float:
    total = 0.0
    for item_id, n in (m.get("inventory") or {}).items():
        item = world.entities.get(item_id)
        if item is not None:
            total += float(item.fields.get("weight") or 0) * int(n)
    return round(total, 1)


def encumbrance(world, m: dict, strength: int) -> tuple[str, int]:
    """('', 0) / ('Encumbered', -10) / ('Heavily encumbered', -20) / ('Overloaded', ...)."""
    rule = world.rules.get("encumbrance") or "Off"
    w = weight(world, m)
    if rule == "Standard" and w > 15 * strength:
        return "Overloaded", -999
    if rule == "Variant":
        if w > 10 * strength:
            return "Heavily encumbered", -20
        if w > 5 * strength:
            return "Encumbered", -10
    return "", 0


def use_outside_combat(world, state, m: dict, item_id: str, rng: random.Random | None = None, bus=None) -> str:
    """Drink a potion, eat a meal... Healing goes to the member's saved hit points."""
    from game import condition
    item = world.entities.get(item_id)
    if item is None or count(m, item_id) <= 0:
        return ""
    f = item.fields
    from game import survival
    if survival.on(world) and survival.kind_of(item) in ("Meal", "Drink"):    # eating, drinking (game/survival.py)
        remove(m, item_id, 1)
        text = survival.eat(world, state, m, item)
        if bus is not None:
            bus.emit("log", kind="narration", text=text)
            bus.emit("item.used", member=m.get("id"), item=item_id)
        return text
    if f.get("category") != "Consumable":
        return f"{item.name} isn't something you can use up."
    remove(m, item_id, 1)
    effect = f.get("use_effect") or "Heal"
    text = f"{m.get('name')} uses {item.name}."
    if effect == "Heal":
        c = condition.combatant(world, m)
        condition.apply(state, m, c)
        gain = max(0, dice.roll(f.get("use_dice") or "1d4", rng or random.Random()).total)
        before = c.hp
        c.hp = min(c.max_hp, c.hp + gain)
        condition.store(state, m, c)
        text += f" They recover {c.hp - before} HP ({c.hp}/{c.max_hp})."
    elif f.get("use_text"):
        text += " " + f["use_text"]
    if f.get("cures"):
        text += survival.use_item(world, state, m, item)
    if bus is not None:
        bus.emit("log", kind="heal" if effect == "Heal" else "narration", text=text)
        bus.emit("item.used", member=m.get("id"), item=item_id)
    return text


def settle_used_up(world, state, m: dict) -> list[str]:
    """After a fight: items that crumble when their charges run out (spell scrolls) and are now empty
    are used up. The next one in the stack starts with full charges. Returns the names used up."""
    from game import condition
    rec = condition.record(state, m)
    charges = rec.get("charges") or {}
    gone = []
    for item_id, left in list(charges.items()):
        item = world.entities.get(item_id)
        if item is None or not item.fields.get("used_up") or int(left) > 0 or count(m, item_id) <= 0:
            continue
        remove(m, item_id, 1)
        charges.pop(item_id, None)
        gone.append(item.name)
    return gone


def settle_ammo(world, m: dict, used: dict[str, int]) -> dict[str, int]:
    """After a fight: half the ammunition fired can be found again (rounded down).
    Takes the rest out of the character's inventory. Returns what was lost per type."""
    lost = {}
    for kind, n in (used or {}).items():
        gone = n - n // 2
        lost[kind] = gone
        for item_id in list((m.get("inventory") or {})):
            if gone <= 0:
                break
            item = world.entities.get(item_id)
            if item is not None and item.fields.get("category") == "Ammunition" and \
                    (item.fields.get("ammo_type") or "Arrow") == kind:
                gone -= remove(m, item_id, gone)
    return lost
