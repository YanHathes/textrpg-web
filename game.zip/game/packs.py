"""Content packs: a bundle of entities (and any fields a world added to its templates) that can be
shared between worlds or installed in bulk.

A pack is a .rpgpack file (a zip holding pack.json and any custom sprites) or a plain pack.json:
    {"format": 1, "name", "version", "author", "description", "license", "attribution",
     "entities": [entity dicts as stored in a world],
     "templates": {type: [extra field definitions]},
     "sprites": [sprite file names inside the zip]}

Installing matches what the world already has by id, then by type and name:
    mode "skip"     keep the world's version (default)
    mode "replace"  overwrite the world's version with the pack's
    mode "copy"     add the pack's version alongside, under a new name
Links inside the pack are rewritten to whichever entity each one ended up as.
"""
from __future__ import annotations

import copy
import io
import json
import zipfile
from pathlib import Path

from game.entities import Entity, _now
from game.fields import FieldDef
from game.templates import TYPE_ORDER

PACK_FORMAT = 1


# ======================================================================
# Exporting
# ======================================================================
def linked_ids(world, entity) -> set[str]:
    """Ids of everything one entity links to (its template's link fields, tables, loadouts...)."""
    out = set()
    template = world.templates.get(entity.type)

    def walk(f: FieldDef, value):
        if f.type == "table":
            for row in value or []:
                for col in f.columns:
                    walk(col, row.get(col.key))
            return
        if f.type == "appearance" and isinstance(value, dict) and value.get("race"):
            out.add(value["race"])
            return
        out.update(i for i in f.link_ids(value) if i)

    for f in template.fields():
        walk(f, entity.fields.get(f.key))
    return {i for i in out if world.entities.get(i) is not None}


def collect(world, ids, with_links: bool = True, skip_types: tuple = ("stat",)) -> list:
    """The entities to export: the chosen ones plus (optionally) everything they link to,
    except basic types the other world will already have (stats)."""
    chosen: dict[str, Entity] = {}
    queue = list(ids)
    first = set(ids)
    while queue:
        eid = queue.pop()
        if eid in chosen:
            continue
        e = world.entities.get(eid)
        if e is None or (e.type in skip_types and eid not in first) or world.entities.is_overlay(eid):
            continue                          # (the party's own buildings belong to a save, not to content)
        chosen[eid] = e
        if with_links:
            queue.extend(linked_ids(world, e) - set(chosen))
    order = {t: i for i, t in enumerate(TYPE_ORDER)}
    return sorted(chosen.values(), key=lambda e: (order.get(e.type, 99), e.name.lower()))


def build_pack(world, ids, meta: dict | None = None, with_links: bool = True) -> dict:
    ents = collect(world, ids, with_links)
    types = {e.type for e in ents}
    templates = {t: world.templates._extension(t) for t in types if world.templates._extension(t)}
    meta = dict(meta or {})
    sprites = sorted({e.fields.get("sprite") or e.fields.get("unique_sprite") or "" for e in ents} - {""})
    sprites = [s for s in sprites if s.startswith("custom/")]
    return {"format": PACK_FORMAT, "name": meta.get("name") or "Content pack", "version": meta.get("version") or "1",
            "author": meta.get("author") or "", "description": meta.get("description") or "",
            "license": meta.get("license") or "", "attribution": meta.get("attribution") or "",
            "made": _now(), "entities": [e.to_dict() for e in ents], "templates": templates, "sprites": sprites}


def export_pack(world, ids, path, meta: dict | None = None, with_links: bool = True) -> dict:
    """Write a .rpgpack (zip) or, for a .json path, plain JSON. Returns the pack."""
    pack = build_pack(world, ids, meta, with_links)
    path = Path(path)
    if path.suffix.lower() == ".json":
        path.write_text(json.dumps(pack, indent=2, ensure_ascii=False), encoding="utf-8")
        return pack
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("pack.json", json.dumps(pack, indent=1, ensure_ascii=False))
        for sid in pack["sprites"]:
            f = Path(world.sprite_dir) / (sid.split("/", 1)[1] + ".json")
            if f.exists():
                z.write(f, f"sprites/{f.name}")
        sounds = Path(world.path) / "sounds"
        if (meta or {}).get("with_sounds", True) and sounds.is_dir():        # the world's own music and sounds
            for f in sorted(sounds.rglob("*")):
                if f.is_file() and f.suffix.lower() in SOUND_EXT:
                    z.write(f, "sounds/" + f.relative_to(sounds).as_posix())
    return pack


SOUND_EXT = (".wav", ".ogg", ".mp3", ".flac")


def read_pack_sounds(path) -> dict[str, bytes]:
    """{"music/<mood>/x.wav" | "ambience/x.wav" | "effects/x.wav": bytes} carried in a .rpgpack."""
    path = Path(path)
    if path.suffix.lower() == ".json":
        return {}
    out = {}
    with zipfile.ZipFile(path) as z:
        for n in z.namelist():
            rel = n[len("sounds/"):] if n.startswith("sounds/") else ""
            parts = rel.split("/")
            if rel and not n.endswith("/") and parts[0] in ("music", "ambience", "effects") and \
                    Path(rel).suffix.lower() in SOUND_EXT and ".." not in parts:
                out[rel] = z.read(n)
    return out


def install_sounds(world, files: dict[str, bytes]) -> int:
    """Put a pack's sounds into the world's sounds folder (game/soundscape.py looks there first)."""
    root = Path(world.path) / "sounds"
    n = 0
    for rel, data in files.items():
        target = (root / rel).resolve()
        if root.resolve() not in target.parents:
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        n += 1
    return n


# ======================================================================
# Installing
# ======================================================================
def read_pack(path) -> tuple[dict, dict[str, bytes]]:
    """(pack, {sprite file name: bytes})."""
    path = Path(path)
    if path.suffix.lower() == ".json":
        return json.loads(path.read_text(encoding="utf-8")), {}
    with zipfile.ZipFile(path) as z:
        pack = json.loads(z.read("pack.json").decode("utf-8"))
        sprites = {Path(n).name: z.read(n) for n in z.namelist() if n.startswith("sprites/") and not n.endswith("/")}
    return pack, sprites


def _remap(value, mapping: dict):
    if isinstance(value, str):
        return mapping.get(value, value)
    if isinstance(value, list):
        return [_remap(v, mapping) for v in value]
    if isinstance(value, dict):
        return {k: _remap(v, mapping) for k, v in value.items()}
    return value


def plan(world, pack: dict, mode: str = "skip", by_name: bool = True) -> list[dict]:
    """What installing would do: [{"entity", "action": create|replace|skip|copy, "target id"}]."""
    store = world.entities
    out = []
    taken: set[str] = set()
    for raw in pack.get("entities") or []:
        t = raw.get("type")
        if t not in TYPE_ORDER or not raw.get("name") or not raw.get("id"):
            out.append({"raw": raw, "action": "bad", "id": "", "why": "unknown type or missing name"})
            continue
        existing = store.get(raw["id"])
        if existing is not None and existing.type != t:
            existing = None
        if existing is None and by_name:
            existing = store.find_by_name(t, raw["name"])
        if existing is not None and mode != "copy":
            out.append({"raw": raw, "action": "replace" if mode == "replace" else "skip", "id": existing.id})
            continue
        new_id = raw["id"] if store.get(raw["id"]) is None and raw["id"] not in taken else store._new_id(t, raw["name"])
        while new_id in taken:
            new_id = new_id + "-x"
        taken.add(new_id)
        name = raw["name"]
        if existing is not None:
            n = 2
            while store.find_by_name(t, f"{raw['name']} ({n})"):
                n += 1
            name = f"{raw['name']} ({n})"
        out.append({"raw": raw, "action": "copy" if existing is not None else "create", "id": new_id, "name": name})
    return out


def install(world, pack: dict, mode: str = "skip", sprites: dict | None = None, by_name: bool = True) -> dict:
    """Install a pack. Returns {"created", "replaced", "skipped", "problems"}."""
    store = world.entities
    report = {"created": 0, "replaced": 0, "skipped": 0, "problems": []}
    # fields the pack's world added to templates
    for t, fields in (pack.get("templates") or {}).items():
        if t not in TYPE_ORDER:
            continue
        for fd in fields:
            try:
                if not world.templates.get(t).field(fd.get("key")):
                    world.templates.add_world_field(t, FieldDef.from_dict(fd))
            except (ValueError, TypeError, RuntimeError) as exc:
                report["problems"].append(f"Field {fd.get('key')} on {t}: {exc}")
    wrote = False
    for name, data in (sprites or {}).items():
        target = Path(world.sprite_dir) / name
        if not target.exists():
            target.write_bytes(data)
            wrote = True
    if wrote:
        from game.art.library import SpriteLibrary
        world.sprites = SpriteLibrary(world.sprite_dir)
    steps = plan(world, pack, mode, by_name)
    mapping = {s["raw"]["id"]: s["id"] for s in steps if s["id"]}
    touched = set()
    from game import progress
    for k, s in enumerate(steps):
        if k % 2000 == 0 and len(steps) > 4000:
            progress.report(k / len(steps), "Adding content")
        raw = s["raw"]
        if s["action"] == "bad":
            report["problems"].append(f"{raw.get('name') or raw.get('id') or '?'}: {s['why']}")
            continue
        if s["action"] == "skip":
            report["skipped"] += 1
            continue
        fields = _remap(raw.get("fields") or {}, mapping)          # (_remap makes fresh lists and dicts)
        custom = _remap(raw.get("custom") or [], mapping)
        if s["action"] == "replace":
            e = store.get(s["id"])
            cleaned, clean_custom, problems = store.clean(e.type, raw["name"], fields, raw.get("description", ""),
                                                          raw.get("tags") or [], custom, current_id=e.id)
            e.fields, e.custom = cleaned, clean_custom
            e.description = raw.get("description", "") or e.description
            e.tags = list(raw.get("tags") or e.tags)
            e.modified = _now()
            report["replaced"] += 1
        else:
            cleaned, clean_custom, problems = store.clean(raw["type"], s.get("name") or raw["name"], fields,
                                                          raw.get("description", ""), raw.get("tags") or [], custom)
            e = Entity(s["id"], raw["type"], s.get("name") or raw["name"], raw.get("description", ""),
                       list(raw.get("tags") or []), cleaned, clean_custom, raw.get("created") or _now(), _now())
            store.put(e)
            report["created"] += 1
        touched.add(raw["type"])
        for p in problems:
            report["problems"].append(f"{raw['name']}: {p}")
    store.touch()
    for t in touched:
        store.save(t)
    if report["created"] >= 500:                 # a big pack: work out each kind's defaults again (game/recordpack.py)
        store.compact_later(sorted(touched))
    return report


def apply_patches(world, patches: list[dict]) -> int:
    """Changes a pack makes to entities other packs put there: [{"id", "field", "was", "set"}]. Each is made
    only if the field still holds what it "was" (so anything a player changed is left alone)."""
    store = world.entities
    touched, n = set(), 0
    for p in patches or []:
        e = store.get(p.get("id") or "")
        key = p.get("field")
        if e is None or not key:
            continue
        cur = list(e.tags) if key == "tags" else e.fields.get(key)
        was = p.get("was")
        if json.dumps(cur, sort_keys=True) != json.dumps(was, sort_keys=True) and not (cur in (None, "", [], {})
                                                                                        and was in (None, "", [], {})):
            continue
        if key == "tags":                              # (the one patchable thing that isn't a field)
            e.tags = list(p.get("set") or [])
        else:
            e.fields[key] = copy.deepcopy(p.get("set"))
        touched.add(e.type)
        n += 1
    store.touch()
    for t in touched:
        store.save(t)
    return n


def summary(pack: dict) -> str:
    counts: dict[str, int] = {}
    for e in pack.get("entities") or []:
        counts[e.get("type", "?")] = counts.get(e.get("type", "?"), 0) + 1
    order = {t: i for i, t in enumerate(TYPE_ORDER)}
    parts = [f"{n} {t}{'s' if n != 1 else ''}" for t, n in sorted(counts.items(), key=lambda kv: order.get(kv[0], 99))]
    return ", ".join(parts) or "nothing"


def pack_bytes(pack: dict) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("pack.json", json.dumps(pack, ensure_ascii=False))
    return buf.getvalue()
