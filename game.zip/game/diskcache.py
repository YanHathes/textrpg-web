"""Results that take seconds to work out and only change when the world does (the land grid, the roads, the
towns' walking maps), kept in the world's folder (cache/cache.db) so the next start doesn't work them out again.

One SQLite file, an entry per thing (so reading one town's map reads just that), each squeezed with zlib and
stored with a fingerprint of what it was made from: a changed world simply makes a new one. Groups of many
(the towns) keep only the most recently used few. Delete the cache folder any time: it's all remade.

(Before step 18 each entry was its own .pickle file; those are read once, moved in, and deleted.)
"""
from __future__ import annotations

import hashlib
import pickle
import sqlite3
import threading
import time
import zlib
from pathlib import Path

VERSION = 1
FILE = "cache.db"
_lock = threading.Lock()
_conns: dict[str, sqlite3.Connection] = {}


def _folder(world) -> Path | None:
    root = getattr(world, "path", None)
    return None if root is None else Path(root) / "cache"


def _db(world) -> sqlite3.Connection | None:
    folder = _folder(world)
    if folder is None:
        return None
    key = str(folder)
    con = _conns.get(key)
    if con is not None:
        return con
    while len(_conns) >= 4:                                   # only the last few worlds' files stay open
        _conns.pop(next(iter(_conns))).close()
    try:
        folder.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(str(folder / FILE), check_same_thread=False, isolation_level=None)
        con.execute("PRAGMA synchronous=OFF")             # a cache: losing the last write costs only time
        con.execute("PRAGMA cache_size=-1000")
        con.execute("CREATE TABLE IF NOT EXISTS entries (name TEXT PRIMARY KEY, sig TEXT NOT NULL, "
                    "data BLOB NOT NULL, used REAL NOT NULL)")
    except sqlite3.Error:
        return None
    _conns[key] = con
    return con


def close(world) -> None:
    """Let go of a world's cache file (before its folder is deleted or copied)."""
    folder = _folder(world)
    if folder is not None:
        close_folder(folder.parent)


def close_folder(world_folder) -> None:
    con = _conns.pop(str(Path(world_folder) / "cache"), None)
    if con is not None:
        con.close()


def fingerprint(*parts) -> str:
    return hashlib.sha1(repr((VERSION,) + parts).encode("utf-8")).hexdigest()


def load(world, name: str, sig: str):
    con = _db(world)
    if con is None:
        return None
    _move_old(world, con, name)
    try:
        with _lock:
            row = con.execute("SELECT sig, data FROM entries WHERE name=?", (name,)).fetchone()
            if row is None or row[0] != sig:
                return None
            con.execute("UPDATE entries SET used=? WHERE name=?", (time.time(), name))
        return pickle.loads(zlib.decompress(row[1]))
    except Exception:          # noqa: BLE001 - a broken cache is just remade
        return None


def store(world, name: str, sig: str, value, keep: int = 0) -> None:
    """keep: for a group of entries named "<group>:<id>", how many of the group to keep (the most recently
    used); 0 keeps every one."""
    con = _db(world)
    if con is None:
        return
    try:
        data = zlib.compress(pickle.dumps(value, protocol=pickle.HIGHEST_PROTOCOL), 6)
        with _lock:
            con.execute("INSERT OR REPLACE INTO entries (name, sig, data, used) VALUES (?,?,?,?)",
                        (name, sig, data, time.time()))
            if keep and ":" in name:
                group = name.split(":", 1)[0] + ":"
                con.execute("DELETE FROM entries WHERE name IN (SELECT name FROM entries WHERE substr(name, 1, ?)=? "
                            "ORDER BY used DESC LIMIT -1 OFFSET ?)", (len(group), group, keep))
    except Exception:          # noqa: BLE001 - not being able to save it only costs time
        pass


# ---- a big dict kept in parts (the roads: only the ones near the party need be read)
class Parted:
    """A dict read back from the cache a part at a time: the part a key is in is read the first time that key
    (or any key in its part) is asked for. Its keys are all known from the start."""

    def __init__(self, world, name: str, sig: str, keys: list, part_of) -> None:
        self._world, self._name, self._sig, self._part_of = world, name, sig, part_of
        self._keys = set(keys)
        self._order = keys
        self._data: dict = {}
        self._read: set = set()

    def _need(self, key) -> None:
        part = self._part_of(key)
        if part in self._read:
            return
        self._read.add(part)
        got = load(self._world, f"{self._name}|{part}", self._sig)
        if got:
            self._data.update(got)

    def get(self, key, default=None):
        if key not in self._keys:
            return default
        self._need(key)
        return self._data.get(key, default)

    def __getitem__(self, key):
        if key not in self._keys:
            raise KeyError(key)
        self._need(key)
        return self._data[key]

    def __contains__(self, key) -> bool:
        return key in self._keys

    def __iter__(self):
        return iter(self._order)

    def __len__(self) -> int:
        return len(self._keys)

    def keys(self):
        return list(self._order)

    def items(self):
        for k in self._order:
            self._need(k)
        return [(k, self._data[k]) for k in self._order if k in self._data]

    def values(self):
        return [v for _k, v in self.items()]

    def __eq__(self, other) -> bool:
        return dict(self.items()) == (dict(other.items()) if hasattr(other, "items") else other)


def store_parted(world, name: str, sig: str, mapping: dict, part_of) -> None:
    parts: dict = {}
    for k, v in mapping.items():
        parts.setdefault(part_of(k), {})[k] = v
    for p, chunk in parts.items():
        store(world, f"{name}|{p}", sig, chunk)
    store(world, name, sig, {"keys": list(mapping)})


def load_parted(world, name: str, sig: str, part_of) -> Parted | None:
    head = load(world, name, sig)
    if not isinstance(head, dict) or "keys" not in head:
        return None
    return Parted(world, name, sig, head["keys"], part_of)


def drop(world, name: str) -> None:
    con = _db(world)
    if con is not None:
        _move_old(world, con, name)
        with _lock:
            con.execute("DELETE FROM entries WHERE name=?", (name,))


def names(world) -> list[str]:
    con = _db(world)
    return [r[0] for r in con.execute("SELECT name FROM entries ORDER BY name")] if con is not None else []


def _move_old(world, con, name: str) -> None:
    """An entry from before step 18, in its own pickle file: into the database, and the file deleted."""
    folder = _folder(world)
    path = folder / f"{name}.pickle"
    if not path.exists():
        return
    try:
        with path.open("rb") as f:
            sig, value = pickle.load(f)
        store(world, name, sig, value)
    except Exception:          # noqa: BLE001
        pass
    try:
        path.unlink()
    except OSError:
        pass


__all__ = ["load", "store", "fingerprint", "close", "names", "Parted", "store_parted", "load_parted"]
