"""What the game should sound like right now, and the cross-fading that gets it there (no Qt here: ui/audio.py
plays what this decides).

Music by where you are:
    towns and villages       calm (town_day; softer at night: town_night)
    wilderness, roads        upbeat, with a flavour for each land (wild_forest, wild_plains, wild_hills,
                             wild_mountains, wild_desert, wild_ice, wild_swamp, wild_coast); at sea: sea
    combat                   tense (combat), starting when a fight begins and fading back after
    dungeons and caves       tense and low (dungeon)
    taverns and inns         lively (tavern); festivals and casinos join later

Ambience loops under it: rain, heavy rain, wind, a strong wind; town crowds, a tavern's noise, the forest's
birds, night's crickets, waves, a cave's drips, a fire.

Sounds come from (first found wins): the world's own sounds folder (packs put theirs there), the player's
sounds folder (data/sounds), then the game's (game/sounds). Music: every file in a mood's folder is a
candidate, so dropping in a track adds one, and one with the same name as the game's replaces it.
"""
from __future__ import annotations

import zlib
from dataclasses import dataclass, field
from pathlib import Path

BUILT_IN = Path(__file__).resolve().parent / "sounds"
AUDIO_EXT = (".wav", ".ogg", ".mp3", ".flac")
MOODS = ["town_day", "town_night", "wild_plains", "wild_forest", "wild_hills", "wild_mountains", "wild_desert",
         "wild_ice", "wild_swamp", "wild_coast", "sea", "road", "combat", "dungeon", "tavern", "festival", "casino"]
FALLBACK = {"wild_jungle": "wild_forest", "road": "wild_plains", "festival": "tavern", "casino": "tavern",
            "town_night": "town_day", "wild_coast": "wild_plains", "sea": "wild_coast", "wild_swamp": "wild_forest",
            "wild_ice": "wild_mountains", "wild_hills": "wild_plains", "wild_desert": "wild_plains",
            "wild_mountains": "wild_hills", "wild_forest": "wild_plains", "dungeon": "combat"}
LAND_MOOD = {"Forest": "wild_forest", "Jungle": "wild_forest", "Taiga": "wild_forest", "Plains": "wild_plains",
             "Savanna": "wild_plains", "Hills": "wild_hills", "Mountains": "wild_mountains", "Desert": "wild_desert",
             "Badlands": "wild_desert", "Arctic": "wild_ice", "Tundra": "wild_ice", "Swamp": "wild_swamp",
             "Coast": "wild_coast", "Lake": "wild_coast", "Ocean": "sea"}
LIVELY = {"Tavern", "Inn"}
FADE_SECONDS = 2.5


# ----------------------------------------------------------------------------------------------------
# Finding the files
# ----------------------------------------------------------------------------------------------------
def folders(world=None, user_dir: Path | None = None) -> list[Path]:
    out = []
    if world is not None and getattr(world, "path", None):
        out.append(Path(world.path) / "sounds")
    if user_dir is not None:
        out.append(Path(user_dir))
    out.append(BUILT_IN)
    return out


def tracks(mood: str, roots: list[Path]) -> list[Path]:
    """Every track for a mood: the game's, with any of the same name replaced, plus any added."""
    by_name: dict[str, Path] = {}
    for root in reversed(roots):                           # built-in first, then overridden
        d = root / "music" / mood
        if d.is_dir():
            for f in sorted(d.iterdir()):
                if f.suffix.lower() in AUDIO_EXT:
                    by_name[f.stem] = f
    return [by_name[k] for k in sorted(by_name)]


def find(kind: str, name: str, roots: list[Path]) -> Path | None:
    """One ambience loop or effect by name (kind: "ambience" or "effects")."""
    for root in roots:
        for ext in (".wav",):                               # loops and effects play as .wav (QSoundEffect)
            f = root / kind / f"{name}{ext}"
            if f.exists():
                return f
    return None


def track_for(mood: str, roots: list[Path], salt: str = "") -> Path | None:
    """A track for the mood (falling back to a near mood when there are none), the same one for the same salt."""
    seen = set()
    m = mood
    while m and m not in seen:
        seen.add(m)
        got = tracks(m, roots)
        if got:
            return got[zlib.crc32(f"{m}|{salt}".encode()) % len(got)]
        m = FALLBACK.get(m, "")
    return None


# ----------------------------------------------------------------------------------------------------
# What fits right now
# ----------------------------------------------------------------------------------------------------
@dataclass
class Scene:
    """What decides the sound: worked out from the game (see from_game) or made by hand in tests."""
    kind: str = "town"           # town, wild, road, sea, dungeon, building, none
    land: str = "Plains"
    building_kind: str = ""
    night: bool = False
    weather: str = "Clear"
    combat: bool = False
    tier: str = ""
    festival: bool = False
    raid: bool = False


def mood_for(scene: Scene) -> str:
    if scene.combat or scene.raid:
        return "combat"
    if scene.festival and scene.kind == "town":
        return "festival"
    if scene.kind == "dungeon":
        return "dungeon"
    if scene.kind == "building" and scene.building_kind in LIVELY:
        return "tavern"
    if scene.kind in ("town", "building"):
        return "town_night" if scene.night else "town_day"
    if scene.kind == "sea":
        return "sea"
    return LAND_MOOD.get(scene.land, "wild_plains")


def ambience_for(scene: Scene) -> dict[str, float]:
    """Loops to play under the music, and how loud (0..1)."""
    out: dict[str, float] = {}
    if scene.kind == "dungeon":
        return {"cave": 0.8}
    indoors = scene.kind == "building"
    w = scene.weather
    if w in ("Rain",):
        out["rain"] = 0.5 if indoors else 0.8
    elif w in ("Heavy rain", "Storm"):
        out["rain_heavy"] = 0.5 if indoors else 0.9
    if w in ("Wind", "Gale", "Dust storm"):
        out["wind" if w == "Wind" else "wind_strong"] = 0.3 if indoors else 0.7
    elif w == "Blizzard":
        out["wind_strong"] = 0.4 if indoors else 0.9
    if indoors:
        if scene.building_kind in LIVELY:
            out["tavern"] = 0.7
        return out
    if scene.kind == "town":
        if scene.night:
            out["night"] = 0.35
        elif w not in ("Storm", "Heavy rain", "Blizzard"):
            out["town"] = 0.55 if scene.tier in ("City", "Capital") else 0.35
    elif scene.kind in ("wild", "road"):
        if scene.night:
            out["night"] = 0.5 if scene.land not in ("Arctic", "Tundra", "Desert") else 0.0
        elif scene.land in ("Forest", "Jungle", "Taiga", "Swamp") and w in ("Clear", "Overcast", "Humid haze"):
            out["forest"] = 0.6
        if scene.land in ("Coast", "Lake"):
            out["waves"] = 0.6
    elif scene.kind == "sea":
        out["waves"] = 0.8
    return {k: v for k, v in out.items() if v > 0}


def scene_from_game(world, state, explorer=None, combat: bool = False) -> Scene:
    from game import calendar as CAL
    from game import places
    from game import settlements as ST
    from game import weather as W
    spot = places.current(world, state)
    try:
        land, _x, _y = W.biome_here(world, state)
    except Exception:  # noqa: BLE001
        land = "Plains"
    try:
        wkind = (explorer.weather() if explorer is not None else W.here(world, state)).kind
    except Exception:  # noqa: BLE001
        wkind = "Clear"
    night = CAL.phase(state.minutes) == "Night"
    kind = {"street": "town", "building": "building", "wild": "wild", "hex": "wild", "road": "road",
            "landmark": "wild", "dungeon": "dungeon", "voyage": "sea"}.get(spot.kind, "town")
    if spot.kind == "voyage" and (state.journey or {}).get("method") not in ("ship", None, ""):
        kind = "road"
    bkind = (spot.building.fields.get("kind") or "") if spot.building is not None else ""
    if explorer is not None and explorer.area is not None and spot.kind == "building" and not explorer.inside_building():
        kind = "town"                                   # standing on the street in front
    tier = ST.tier_of(spot.town) if spot.town is not None else ""
    fest = raid = False
    try:
        from game import townevents as TE
        fest = spot.town is not None and TE.festival_at(world, spot.town, state.minutes) is not None
        raid = TE.raid_here(world, state) is not None
    except Exception:  # noqa: BLE001
        pass
    return Scene(kind=kind, land=land, building_kind=bkind, night=night, weather=wkind, combat=combat, tier=tier,
                 festival=fest, raid=raid)


# ----------------------------------------------------------------------------------------------------
# Cross-fading
# ----------------------------------------------------------------------------------------------------
@dataclass
class Channel:
    name: str = ""               # what's playing ("" silent)
    level: float = 0.0           # 0..1 of its full volume
    target: float = 0.0


@dataclass
class Mixer:
    """Two music channels (one fading in while the other fades out) and the ambience loops.

    want(track) asks for a track; tick(seconds) moves the fades along. Whatever's playing is in .music
    (the channels) and .loops (name -> Channel); the player reads levels off them."""
    fade: float = FADE_SECONDS
    music: list = field(default_factory=lambda: [Channel(), Channel()])
    loops: dict = field(default_factory=dict)
    current: int = 0
    paused_for: str = ""         # the track to go back to after a fight

    @property
    def playing(self) -> str:
        return self.music[self.current].name

    def want(self, track: str) -> bool:
        """Cross-fade to a track (no change if it's already the one playing). True if it changed."""
        if track == self.playing:
            self.music[self.current].target = 1.0
            return False
        old = self.music[self.current]
        old.target = 0.0
        self.current = 1 - self.current
        new = self.music[self.current]
        new.name, new.target = track, 1.0
        if new.level <= 0:
            new.level = 0.0
        return True

    def want_loops(self, levels: dict[str, float]) -> None:
        for name, ch in self.loops.items():
            if name not in levels:
                ch.target = 0.0
        for name, lv in levels.items():
            ch = self.loops.setdefault(name, Channel(name=name))
            ch.target = lv

    def tick(self, seconds: float) -> None:
        step = seconds / max(0.01, self.fade)
        for ch in self.music + list(self.loops.values()):
            if ch.level < ch.target:
                ch.level = min(ch.target, ch.level + step)
            elif ch.level > ch.target:
                ch.level = max(ch.target, ch.level - step)
        for ch in self.music:
            if ch.level <= 0 and ch.target <= 0:
                ch.name = ""
        for name in [n for n, ch in self.loops.items() if ch.level <= 0 and ch.target <= 0]:
            del self.loops[name]

    def busy(self) -> bool:
        return any(abs(ch.level - ch.target) > 1e-6 for ch in self.music + list(self.loops.values()))


__all__ = ["Scene", "Mixer", "Channel", "mood_for", "ambience_for", "scene_from_game", "tracks", "track_for", "find",
           "folders", "MOODS", "BUILT_IN"]
