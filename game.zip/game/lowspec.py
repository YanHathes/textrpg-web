"""The low-memory setting (step 18), for small computers and, later, phones: the game keeps less in memory
and does less work each second, at the cost of reading a little more from disk.

    on   NPCs and buildings kept read are let go of sooner (game/entities.py TRIM_AT); the walking map keeps
         fewer painted blocks (ui/explore_view.py) and fewer towns' maps; rain and snow move at 10 frames a
         second instead of 30; the art caches are emptied when a new area is entered.
    off  (the default) as before.

Nothing about the game itself changes: only what's kept around.
"""
from __future__ import annotations

LOW = False
TRIM = {False: {"npc": 6000, "building": 4000}, True: {"npc": 1200, "building": 800}}
BLOCKS = {False: 64, True: 16}          # painted map blocks kept (each about 2 MB)
ANIM_MS = {False: 33, True: 100}        # weather frames
SITES = {False: 24, True: 6}            # towns and sites laid into the open world kept at once


def configure(low: bool) -> None:
    global LOW
    LOW = bool(low)
    from game import entities
    entities.TRIM_AT.clear()
    entities.TRIM_AT.update(TRIM[LOW])


def blocks() -> int:
    return BLOCKS[LOW]


def anim_ms() -> int:
    return ANIM_MS[LOW]


def sites() -> int:
    return SITES[LOW]


def new_area() -> None:
    """A new area entered: in low-memory mode, the art drawn for the last one is let go of."""
    if not LOW:
        return
    from game.art import beasts, faces, folk, tiles   # noqa: F401
    folk._sprite.cache_clear()
    beasts._sprite.cache_clear()
    for name in ("floor_tile", "fringe_tile", "water_tile", "wall_tile", "prop_sprite", "roof_tile",
                 "ground_tile", "season_tile", "prop_sprite_in", "roof_tile_in"):
        fn = getattr(tiles, name, None)
        if fn is not None and hasattr(fn, "cache_clear"):
            fn.cache_clear()


__all__ = ["configure", "blocks", "anim_ms", "sites", "new_area", "LOW"]
