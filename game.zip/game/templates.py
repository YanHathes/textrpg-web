"""Templates: which fields each base type has, grouped into wizard steps.

Built-in templates live in game/template_data/<type>.json. Each world can extend
them with extra fields (stored in <world>/templates/<type>.json), which is
how "add this custom field to every future item" works, and how the SRD
rebuild adds any parameter it needs without code changes.
"""
from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from pathlib import Path

from game.constants import OPTION_LISTS
from game.fields import FieldDef

BUILTIN_DIR = Path(__file__).resolve().parent / "template_data"

# Display order everywhere (Create picker, Library).
TYPE_ORDER = ["item", "spell", "feature", "skill", "stat", "race", "class", "background", "npc", "enemy", "building",
              "town", "continent", "region", "landmark", "dungeon", "room", "quest", "faction", "dialogue", "mechanic", "recipe", "questline",
              "blueprint"]

BASIC_FIELDS = [
    FieldDef("name", "Name", "text", required=True),
    FieldDef("description", "Description", "longtext"),
    FieldDef("tags", "Tags", "textlist",
             help="Words used to find and group this, one per line. Shops use item tags to decide what they sell."),
]


@dataclass
class Step:
    id: str
    title: str
    fields: list[FieldDef]
    help: str = ""
    show_if: dict | None = None

    def visible(self, values: dict) -> bool:
        if not self.show_if:
            return True
        probe = FieldDef("_probe", "probe", "text", show_if=self.show_if)
        return probe.visible(values)


@dataclass
class Template:
    type: str
    label: str
    plural: str
    blurb: str
    announce: str
    steps: list[Step] = field(default_factory=list)

    def fields(self) -> list[FieldDef]:
        return [f for step in self.steps for f in step.fields]

    def field(self, key: str) -> FieldDef | None:
        for f in self.fields():
            if f.key == key:
                return f
        return None

    def defaults(self) -> dict:
        return {f.key: f.empty() for f in self.fields() if f.key not in ("name", "description", "tags")}


def _resolve_options(raw: dict) -> dict:
    data = copy.deepcopy(raw)
    opts = data.get("options")
    if isinstance(opts, str) and opts.startswith("@"):
        data["options"] = list(OPTION_LISTS[opts[1:]])
    if "columns" in data:
        data["columns"] = [_resolve_options(c) for c in data["columns"]]
    return data


def load_template_file(path: Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


class TemplateRegistry:
    def __init__(self, world_template_dir: Path | None = None) -> None:
        self.world_dir = Path(world_template_dir) if world_template_dir else None
        self.templates: dict[str, Template] = {}
        self.reload()

    def reload(self) -> None:
        self.templates.clear()
        for type_name in TYPE_ORDER:
            raw = load_template_file(BUILTIN_DIR / f"{type_name}.json")
            self.templates[type_name] = self._build(raw, self._extension(type_name))

    def get(self, type_name: str) -> Template:
        return self.templates[type_name]

    def all(self) -> list[Template]:
        return [self.templates[t] for t in TYPE_ORDER]

    # ---- world extensions -----------------------------------------------
    def _extension(self, type_name: str) -> list[dict]:
        if not self.world_dir:
            return []
        path = self.world_dir / f"{type_name}.json"
        if not path.exists():
            return []
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return []
        return list(data.get("fields", []))

    def add_world_field(self, type_name: str, field_def: FieldDef) -> None:
        """Add a field to this world's version of a template (e.g. a promoted custom field)."""
        if not self.world_dir:
            raise RuntimeError("No world is open")
        template = self.get(type_name)
        if template.field(field_def.key):
            raise ValueError(f"{template.label} already has a field called '{field_def.key}'")
        existing = self._extension(type_name)
        existing.append(field_def.to_dict())
        self.world_dir.mkdir(parents=True, exist_ok=True)
        (self.world_dir / f"{type_name}.json").write_text(json.dumps({"fields": existing}, indent=2), encoding="utf-8")
        self.reload()

    def remove_world_field(self, type_name: str, key: str) -> None:
        existing = [f for f in self._extension(type_name) if f.get("key") != key]
        (self.world_dir / f"{type_name}.json").write_text(json.dumps({"fields": existing}, indent=2), encoding="utf-8")
        self.reload()

    def world_fields(self, type_name: str) -> list[FieldDef]:
        return [FieldDef.from_dict(_resolve_options(f)) for f in self._extension(type_name)]

    # ---- building -----------------------------------------------------
    def _build(self, raw: dict, extra_fields: list[dict]) -> Template:
        steps = [Step("basics", "Basics", [copy.deepcopy(f) for f in BASIC_FIELDS],
                      help=raw.get("blurb", ""))]
        for s in raw.get("steps", []):
            fields = [FieldDef.from_dict(_resolve_options(f)) for f in s.get("fields", [])]
            steps.append(Step(s["id"], s["title"], fields, s.get("help", ""), s.get("show_if")))
        if extra_fields:
            fields = [FieldDef.from_dict(_resolve_options(f)) for f in extra_fields]
            steps.append(Step("world_fields", "World fields", fields,
                              "Fields added to this type in this world."))
        return Template(raw["type"], raw["label"], raw["plural"], raw.get("blurb", ""),
                        raw.get("announce", "{name} was created."), steps)
