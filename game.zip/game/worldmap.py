"""The whole world as one walkable map of 5-foot squares, made a chunk at a time as the party nears it.

A chunk is 32 x 32 squares. Its ground comes from the world map (game/geography.py): the biome under it
(with ragged, natural borders), noise for woods and clearings, rocky ridges, pools and patches of bare
earth, sand along every shore, and the roads that join the towns, bending a little as they go (with
bridges where they cross water). Nothing is saved: a chunk comes out the same every time it's made.

Towns, landmarks and dungeon entrances are "sites": small maps built by game/area.py (a town with all its
buildings, a ruin, a cave mouth) and laid into the world where they stand. The roads run into each town
and end at its streets, with a signpost at the edge of town for travelling the road quickly.

Squares: SQ per mile. World square (X, Y) is at (X / SQ, Y / SQ) miles on the world map.
Locations while walking: the hex under the party (hex|q|r), or the site's own places (streets, buildings,
landmark|id).
"""
from __future__ import annotations

import base64
import math
import struct
import zlib
from collections import OrderedDict, deque

from game import area as A
from game import gathering as GA
from game import landchanges
from game import geography as G
from game import hexes as H
from game import places

# road grades on the walking map: (width in squares, floor)
GRADES = {"highway": (5, "cobble"), "road": (3, "path"), "track": (2, "track")}
FLOOR_RANK = {"track": 0, "path": 1, "cobble": 2}
SQ = 1056                     # squares per mile (5280 ft / 5)
CH = 32                       # squares per side of a chunk
MAX_CHUNKS = 1500             # chunks kept in memory (older ones are made again when needed)
SITE_REACH = 700              # sites within this many squares of a new chunk are laid in first
BIN = 1024                    # squares per side of the lookup bins for roads and sites
WATER = {"Ocean": "sea", "Lake": "water"}
TREE = {"Forest": "tree", "Jungle": "tree", "Taiga": "pine", "Plains": "tree", "Savanna": "tree",
        "Hills": "tree", "Swamp": "tree", "Coast": "tree", "Arctic": "pine", "Tundra": "pine", "Mountains": "pine"}


# ======================================================================
# Small helpers
# ======================================================================
def _hash(x: int, y: int, seed: int) -> float:
    n = (x * 374761393 + y * 668265263 + seed * 2147483647) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65536.0


class _Field:
    """Smooth value noise over squares, worked out once for a block of squares (fast to read)."""

    def __init__(self, x0: int, y0: int, n: int, cell: int, seed: int) -> None:
        self.cell = cell
        self.ix0, self.iy0 = x0 // cell, y0 // cell
        ix1, iy1 = (x0 + n) // cell + 2, (y0 + n) // cell + 2
        self.vals = [[_hash(i, j, seed) for i in range(self.ix0, ix1)] for j in range(self.iy0, iy1)]

    def at(self, x: int, y: int) -> float:
        c = self.cell
        i, j = x // c - self.ix0, y // c - self.iy0
        fx, fy = (x % c) / c, (y % c) / c
        fx, fy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
        row0, row1 = self.vals[j], self.vals[j + 1]
        a, b, cc, d = row0[i], row0[i + 1], row1[i], row1[i + 1]
        return a + (b - a) * fx + (cc - a) * fy + (a - b - cc + d) * fx * fy


# ======================================================================
# Chunks
# ======================================================================
class Chunk:
    __slots__ = ("cx", "cy", "floor", "zone", "walls", "windows", "doors", "prop_cells", "water", "stairs",
                 "stations", "exits", "props", "sites")

    def __init__(self, cx: int, cy: int) -> None:
        self.cx, self.cy = cx, cy
        self.floor = [["grass"] * CH for _ in range(CH)]
        self.zone = [[0] * CH for _ in range(CH)]
        self.walls: dict = {}
        self.windows: set = set()
        self.doors: dict = {}
        self.prop_cells: dict = {}
        self.water: dict = {}
        self.stairs: dict = {}
        self.stations: dict = {}
        self.exits: dict = {}
        self.props: list = []
        self.sites: list = []


class CMap:
    """A level-wide view of one of the chunks' dictionaries (walls, doors...), as if it were one dict."""

    def __init__(self, level: "ChunkLevel", attr: str) -> None:
        self.level, self.attr = level, attr

    def _d(self, c):
        if not self.level.inside(c[0], c[1]):
            return {}
        return getattr(self.level.chunk(c[0] // CH, c[1] // CH), self.attr)

    def __contains__(self, c) -> bool:
        return c in self._d(c)

    def __getitem__(self, c):
        return self._d(c)[c]

    def get(self, c, default=None):
        d = self._d(c)
        return d.get(c, default) if isinstance(d, dict) else (c if c in d else default)

    def pop(self, c, default=None):
        d = self._d(c)
        return d.pop(c, default) if isinstance(d, dict) else default

    def __iter__(self):
        for ch in list(self.level.chunks.values()):
            yield from getattr(ch, self.attr)

    def items(self):
        for ch in list(self.level.chunks.values()):
            d = getattr(ch, self.attr)
            if isinstance(d, dict):
                yield from d.items()

    def keys(self):
        return set(iter(self))

    def __len__(self) -> int:
        return sum(len(getattr(ch, self.attr)) for ch in self.level.chunks.values())


class ChunkLevel:
    """The open world's ground level: endless, made in chunks as it's looked at."""

    overlay = False
    underground = False
    floor_no = 0
    bid = ""
    roof = ""
    dark = False
    chunked = True

    def __init__(self, area: "WorldArea", key: str = "0") -> None:
        self.area, self.key = area, key
        self.ox = self.oy = 0
        self.w, self.h = area.w, area.h
        self.chunks: OrderedDict = OrderedDict()
        self.names = area.zone_names
        for attr in ("walls", "windows", "doors", "prop_cells", "water", "stairs", "stations", "exits"):
            setattr(self, attr, CMap(self, attr))
        self.props: list = []
        self._last = None                              # (cx, cy, chunk) last read

    def chunk(self, cx: int, cy: int) -> Chunk:
        last = self._last
        if last is not None and last[0] == cx and last[1] == cy:   # most reads land in the same chunk
            return last[2]
        key = (cx, cy)
        ch = self.chunks.get(key)
        if ch is None:
            ch = self.area.make_chunk(cx, cy)
            self.chunks[key] = ch
            while len(self.chunks) > MAX_CHUNKS:
                self.chunks.popitem(last=False)
        else:
            self.chunks.move_to_end(key)
        self._last = (cx, cy, ch)
        return ch

    def has(self, cx: int, cy: int) -> bool:
        return (cx, cy) in self.chunks

    def inside(self, x: int, y: int) -> bool:
        return 0 <= x < self.w and 0 <= y < self.h

    def floor_at(self, x: int, y: int) -> str:
        if not self.inside(x, y):
            return A.VOID
        return self.chunk(x // CH, y // CH).floor[y % CH][x % CH]

    def set_floor(self, x: int, y: int, kind: str) -> None:
        if self.inside(x, y):
            self.chunk(x // CH, y // CH).floor[y % CH][x % CH] = kind

    def zone_at(self, x: int, y: int) -> int:
        if not self.inside(x, y):
            return 0
        return self.chunk(x // CH, y // CH).zone[y % CH][x % CH]

    def loc_at(self, x: int, y: int) -> str:
        z = self.zone_at(x, y)
        return self.names[z] if 0 <= z < len(self.names) else ""

    def free(self, x: int, y: int) -> bool:
        if not self.inside(x, y):
            return False
        ch = self.chunk(x // CH, y // CH)
        c = (x, y)
        return (ch.floor[y % CH][x % CH] not in A.SOLID and c not in ch.walls and c not in ch.doors
                and c not in ch.prop_cells and c not in ch.water and c not in ch.stairs)

    def blocks(self, x: int, y: int) -> bool:
        if not self.inside(x, y):
            return True
        ch = self.chunk(x // CH, y // CH)
        c = (x, y)
        if ch.floor[y % CH][x % CH] in A.SOLID or c in ch.walls or c in ch.water:
            return True
        p = ch.prop_cells.get(c)
        return bool(p and p.defn.blocks)

    def opaque(self, x: int, y: int) -> bool:
        if not self.inside(x, y):
            return True
        ch = self.chunk(x // CH, y // CH)
        c = (x, y)
        if c in ch.walls and c not in ch.windows:
            return True
        p = ch.prop_cells.get(c)
        return bool(p and p.id in ("tree", "pine") and _hash(x, y, 77) < 0.5)   # thick woods hide what's past

    def add_prop(self, pid: str, x: int, y: int, variant: int = 0, force: bool = False):
        ch = self.chunk(x // CH, y // CH)
        p = A.AProp(pid, x, y, variant)
        ch.props.append(p)
        ch.prop_cells[(x, y)] = p
        return p


# ======================================================================
# Sites (towns, landmarks, dungeon entrances laid into the world)
# ======================================================================
class Site:
    def __init__(self, key: str, kind: str, ent_id: str, area: A.Area) -> None:
        self.key, self.kind, self.ent_id, self.area = key, kind, ent_id, area
        lv = area.base
        self.base = lv
        self.rect = (lv.ox, lv.oy, lv.w, lv.h)

    def contains(self, x: int, y: int) -> bool:
        x0, y0, w, h = self.rect
        return x0 <= x < x0 + w and y0 <= y < y0 + h

    def overlaps(self, x0: int, y0: int, w: int, h: int) -> bool:
        sx, sy, sw, sh = self.rect
        return sx < x0 + w and x0 < sx + sw and sy < y0 + h and y0 < sy + sh


# ======================================================================
# The world
# ======================================================================
class WorldArea(A.Area):
    """The walking map of the world, or of one continent of it (continent: its id; "" for all of it).
    One continent at a time: the only way to another is by ship or airship, and its towns, roads and
    sites are laid in when the party lands there (load_continent)."""

    def __init__(self, world, continent: str = "") -> None:
        s = G.settings(world)
        super().__init__("world", "world", int(s["width"] * SQ), int(s["height"] * SQ), world.name)
        self.world = world
        self.grid = G.terrain(world)
        self.seed = int(s["seed"])
        self.world_sig = _world_sig(world)
        self.sig = self.world_sig + (":" + continent if continent else "")
        self.outdoor = True
        self.base_key = "0"
        base = ChunkLevel(self)
        self.levels["0"] = base
        self.sites: dict[str, Site] = {}
        self.town_gates: dict[str, dict] = {}
        self.continent = continent or ""
        if self.continent == SEA:                  # aboard: the ports at each end, and only the sea between
            ports = set(getattr(world, "_sea_ports", ()) or ())
            self._index = {k: [r for r in rows if r[1] in ports] for k, rows in _all_sites(world).items()}
            self._index = {k: v for k, v in self._index.items() if v}
        else:
            self._index = _site_index(world, self.continent)
        self._roads, self._road_bins = roads_for(world, self.continent)
        self.terrain = "Plains"

    # ---- levels
    def layer(self, key: str, x: int, y: int):
        lv = self.levels.get(key) or self.levels["0"]
        if lv.overlay:
            if lv.underground:
                return lv
            if lv.inside(x, y) and lv.floor_at(x, y) != A.PASS:
                return lv
        site = self.site_at(x, y)
        if site is not None:
            return site.base
        return self.levels["0"]

    def level(self, key: str):
        return self.levels.get(key) or self.levels["0"]

    def site_at(self, x: int, y: int) -> Site | None:
        base = self.levels["0"]
        if not base.inside(x, y):
            return None
        for s in base.chunk(x // CH, y // CH).sites:
            if s.contains(x, y):
                return s
        return None

    def all_levels(self) -> list:
        return [lv for lv in self.levels.values() if not getattr(lv, "chunked", False)] + \
            [s.base for s in self.sites.values() if s is not None]

    def gates_of(self, town) -> dict:
        if town is None:
            return {}
        self.load_town(town)
        return self.town_gates.get(town.id, {})

    # ---- sites
    def ensure_sites_near(self, X: float, Y: float) -> None:
        self._claims_near(X, Y)
        bx, by = int(X // BIN), int(Y // BIN)
        for j in range(by - 1, by + 2):
            for i in range(bx - 1, bx + 2):
                for kind, eid, sx, sy in self._index.get((i, j), ()):
                    if eid in self.sites:
                        continue
                    if abs(sx - X) <= SITE_REACH and abs(sy - Y) <= SITE_REACH:
                        self.load_site(kind, eid)

    # ---- the party's own land (game/estate.py): this save's claims, laid in like any other site
    def _claims_near(self, X: float, Y: float) -> None:
        st = getattr(self.world, "_state_for_places", None)
        h = getattr(st, "holdings", None) if st is not None else None
        if not h or not h.get("claims"):
            return
        for c in h["claims"]:
            r = c.get("rect")
            if not r or c.get("id") in self.sites:
                continue
            if abs(r[0] + r[2] / 2 - X) <= SITE_REACH + r[2] and abs(r[1] + r[3] / 2 - Y) <= SITE_REACH + r[3]:
                self.load_claim(c)

    def load_claim(self, c: dict) -> Site | None:
        from game import estate
        if c["id"] in self.sites:
            return self.sites[c["id"]]
        local = estate.build_claim_area(self.world, self, c)
        landchanges.tag_area(local, f"claim:{c['id']}")
        moved = A.shifted(local, int(c["rect"][0]), int(c["rect"][1]), f"site:{c['id']}")
        site = Site(f"site:{c['id']}", "claim", c["id"], moved)
        site.sig = estate.claim_sig(self.world, c)
        self._embed(site)
        tid = getattr(local, "settlement_town", "")
        if tid:                                         # a settlement's ways in: the middle of each edge
            x0, y0, w, h = site.rect
            cx, cy = x0 + w // 2, y0 + h // 2
            self.town_gates[tid] = {d: (int(cx + vx * (w // 2 - 1)), int(cy + vy * (h // 2 - 1)))
                                    for d, (vx, vy) in G.VECTORS.items()}
        return site

    def reload_claim(self, c: dict) -> None:
        """Make a claim's map again (a building was placed, begun or finished)."""
        old = self.sites.get(c["id"])
        if old is not None:
            self._unembed(old)
        self.load_claim(c)

    def drop_claim(self, cid: str) -> None:
        old = self.sites.get(cid)
        if old is not None:
            self._unembed(old)

    def drop_claims(self) -> None:
        for s in [s for s in self.sites.values() if s is not None and s.kind == "claim"]:
            self._unembed(s)

    def reload_town_id(self, tid: str) -> None:
        site = self.sites.get(tid)
        if site is not None:
            self._unembed(site)
            self.load_town(self.world.entities.get(tid))

    def refresh_towns(self) -> None:
        """Towns laid in for another save (its lots and buildings) are made again for this one."""
        for tid, site in list(self.sites.items()):
            if site is None or site.kind != "town":
                continue
            town = self.world.entities.get(tid)
            if town is None:
                continue
            if getattr(site, "sig", None) != A._town_sig(self.world, town):
                self._unembed(site)
                self.load_town(town)

    def _unembed(self, site: Site) -> None:
        self.sites.pop(site.ent_id, None)
        tid = getattr(site.area, "settlement_town", "")
        if tid:
            self.town_gates.pop(tid, None)
        base = self.levels["0"]
        x0, y0, w, h = site.rect
        for cy in range(y0 // CH, (y0 + h - 1) // CH + 1):
            for cx in range(x0 // CH, (x0 + w - 1) // CH + 1):
                ch = base.chunks.get((cx, cy))
                if ch is not None and site in ch.sites:
                    ch.sites.remove(site)
        a = site.area
        for k, lv in a.levels.items():
            if lv is not a.base and self.levels.get(k) is lv:
                del self.levels[k]
        for bid in a.roofs:
            self.roofs.pop(bid, None)
        for c, bid in a.cell_building.items():
            if self.cell_building.get(c) == bid:
                del self.cell_building[c]
        self.porch -= a.porch
        for bid in a.buildings:
            self.buildings.pop(bid, None)
        for k in a.spawns:
            self.spawns.pop(k, None)
        self.town_gates.pop(site.ent_id, None)
        base._last = None

    def load_site(self, kind: str, eid: str) -> Site | None:
        e = self.world.entities.get(eid)
        if e is None:
            return None
        if kind == "town":
            return self.load_town(e)
        return self._load_landmark(e, kind)

    def _embed(self, site: Site) -> None:
        self.sites[site.ent_id] = site
        a = site.area
        landchanges.apply_area(self.world, a)                   # trees cut in town, in this playthrough
        for k, lv in a.levels.items():
            if lv is not a.base:
                self.levels[k] = lv
        self.roofs.update(a.roofs)
        self.cell_building.update(a.cell_building)
        self.porch |= a.porch
        self.buildings.update(a.buildings)
        self.spawns.update(a.spawns)
        base = self.levels["0"]
        x0, y0, w, h = site.rect
        for (cx, cy), ch in base.chunks.items():                # chunks made before it arrived
            if site.overlaps(cx * CH, cy * CH, CH, CH):
                ch.sites.append(site)
        self._keep_few(site)

    def _keep_few(self, near: Site) -> None:
        """Towns and sites laid in long ago and far away are taken out again (they're quick to lay in again:
        their maps are in the world's cache). How many stay: game/lowspec.py."""
        from game import lowspec
        far = [s for s in self.sites.values() if s is not None and s is not near and s.kind in ("town", "landmark",
                                                                                               "dungeon")]
        extra = len(far) + 1 - lowspec.sites()
        if extra <= 0:
            return
        nx, ny = near.rect[0] + near.rect[2] / 2, near.rect[1] + near.rect[3] / 2
        def d2(s):
            return (s.rect[0] + s.rect[2] / 2 - nx) ** 2 + (s.rect[1] + s.rect[3] / 2 - ny) ** 2
        far = [s for s in far if d2(s) > KEEP_NEAR ** 2]           # nothing near where the party is goes
        far.sort(key=lambda s: -d2(s))
        for s in far[:extra]:
            self._unembed(s)

    def load_town(self, town) -> Site | None:
        if town is None:
            return None
        if town.fields.get("settlement"):              # the party's own (game/colony.py): its claim is its map
            st = getattr(self.world, "_state_for_places", None)
            c = next((c for c in ((getattr(st, "holdings", None) or {}).get("claims") or [])
                      if c.get("id") == town.fields.get("claim") and c.get("rect")), None)
            return self.load_claim(c) if c is not None else None
        if town.id in self.sites:
            return self.sites[town.id]
        site = _town_site(self.world, town, self._roads, self.town_gates.setdefault(town.id, {}))
        if site is None:
            return None
        self._embed(site)
        return site

    def _roads_into_town(self, site: Site, town, local: A.Area) -> None:
        _roads_into_town(self.world, site, town, local, self._roads, self.town_gates.setdefault(town.id, {}))

    def _load_landmark(self, e, kind: str) -> Site | None:
        if e.id in self.sites:
            return self.sites[e.id]
        site = _landmark_site(self.world, e, kind)
        if site is not None:
            self._embed(site)
        return site

    # ---- where the party goes for a place
    def cell_for(self, spot) -> tuple[str, int, int] | None:
        if spot.kind == "building" and spot.town is None and spot.building is not None and \
                spot.building.fields.get("claim"):                   # the party's own land (game/estate.py)
            st = getattr(self.world, "_state_for_places", None)
            c = next((c for c in ((getattr(st, "holdings", None) or {}).get("claims") or [])
                      if c.get("id") == spot.building.fields["claim"] and c.get("rect")), None)
            if c is not None:
                self.load_claim(c)
                return self.spawns.get(spot.id) or self.spawns.get(spot.building.id)
        if spot.kind in ("street", "building") and spot.town is not None:
            self.load_town(spot.town)
            got = self.spawns.get(spot.id)
            if got is None and spot.building is not None:
                got = self.spawns.get(spot.building.id)
            return got
        if spot.kind == "landmark":
            lm = spot.extra.get("landmark")
            if lm is not None:
                self._load_landmark(lm, "landmark")
                return self.spawns.get(spot.id)
        if spot.kind == "wild" and spot.town is not None:
            site = self.load_town(spot.town)
            g = self.town_gates.get(spot.town.id, {}).get(spot.direction)
            vx, vy = G.VECTORS.get(spot.direction, (0, 1))
            if g is None and site is not None:
                x0, y0, w, h = site.rect
                g = (int(x0 + w / 2 + vx * w / 2), int(y0 + h / 2 + vy * h / 2))
            if g is not None:
                c = self.nearest_walkable(int(g[0] + vx * 12), int(g[1] + vy * 12))
                return ("0",) + c if c else None
        if spot.kind == "hex":
            mx, my = H.center(self.world, spot.extra["q"], spot.extra["r"])
            c = self.nearest_walkable(int(mx * SQ), int(my * SQ))
            return ("0",) + c if c else None
        return None

    def dungeon_door(self, d_id: str) -> tuple[str, int, int] | None:
        """Just outside the door of a dungeon (for coming back out of it)."""
        lm = next(iter(self.world.entities.by_field("landmark", "dungeon", d_id)), None)
        site = self._load_landmark(lm, "landmark") if lm is not None else \
            self._load_landmark(self.world.entities.get(d_id), "dungeon") if self.world.entities.get(d_id) else None
        if site is None:
            return None
        for c, d in site.base.doors.items():
            if d.get("kind") == "dungeon" and d.get("bid") == d_id:
                for dx, dy in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                    n = (c[0] + dx, c[1] + dy)
                    lv = self.layer("0", *n)
                    if not lv.blocks(*n) and n not in lv.doors:
                        return ("0", n[0], n[1])
        return None

    def has_road(self, a_id: str, b_id: str) -> bool:
        return _road_key(a_id, b_id) in self._roads

    def road_route(self, from_town, to_town, direction: str = "") -> list[tuple[float, float]] | None:
        """The way along the road from one town's gate to the other's, as points (squares). None when the
        two aren't joined on the map."""
        if from_town is None or to_town is None:
            return None
        line = self._roads.get(_road_key(from_town.id, to_town.id))
        if not line:
            return None
        a_site, b_site = self.load_town(from_town), self.load_town(to_town)
        pts = line if _road_key(from_town.id, to_town.id)[0] == from_town.id else list(reversed(line))
        back = next((r["direction"] for r in places.roads_of(to_town) if r.get("leads_to") == from_town.id), "")
        start = self.gates_of(from_town).get(direction or next(
            (r["direction"] for r in places.roads_of(from_town) if r.get("leads_to") == to_town.id), ""))
        end = self.gates_of(to_town).get(back)
        out: list[tuple[float, float]] = [start] if start else []
        for p in _walk_line(pts, 6.0):
            if (a_site is not None and a_site.contains(int(p[0]), int(p[1]))) or \
                    (b_site is not None and b_site.contains(int(p[0]), int(p[1]))):
                continue
            out.append(p)
        if end:
            out.append(end)
        return out if len(out) >= 2 else None

    def voyage_route(self, from_town, to_town, method: str) -> list[tuple[float, float]] | None:
        """The way a ship (over open water, port to port), a caravan (overland, hex by hex) or an
        airship (as the crow flies) goes between two towns, as points (squares)."""
        from game import hexes as H
        pa, pb = G.town_position(self.world, from_town), G.town_position(self.world, to_town)
        if pa is None or pb is None:
            return None
        A_, B_ = (pa[0] * SQ, pa[1] * SQ), (pb[0] * SQ, pb[1] * SQ)
        if method == "Airship":
            return [A_, B_]
        key = (from_town.id, to_town.id, method)
        cache = self.__dict__.setdefault("_voyages", {})
        if key in cache:
            return cache[key]
        if method == "Boat":
            cells = _sea_cells(self.world, pa, pb)
            out = [A_] + [(x * SQ, y * SQ) for x, y in cells] + [B_] if cells else [A_, B_]
            cache[key] = out
            return out
        ha, hb = H.at(self.world, *pa), H.at(self.world, *pb)
        steps = H.quick_path(self.world, ha, hb, water=False)
        if not steps:
            out = [A_, B_]
        else:
            mid = [(H.center(self.world, *s)[0] * SQ, H.center(self.world, *s)[1] * SQ) for s in steps[:-1]]
            out = [A_] + mid + [B_]
        cache[key] = out
        return out

    def nearest_walkable(self, x: int, y: int, limit: int = 60) -> tuple[int, int] | None:
        for r in range(limit):
            ring = [(x + dx, y + dy) for dx in range(-r, r + 1) for dy in range(-r, r + 1) if max(abs(dx), abs(dy)) == r]
            for c in ring:
                lv = self.layer("0", *c)
                if lv.inside(*c) and not lv.blocks(*c) and c not in lv.doors and c not in lv.stations:
                    return c
        return None

    # ---- making chunks
    def make_chunk(self, cx: int, cy: int) -> Chunk:
        X0, Y0 = cx * CH, cy * CH
        self.ensure_sites_near(X0 + CH / 2, Y0 + CH / 2)
        ch = Chunk(cx, cy)
        ch.sites = [s for s in self.sites.values() if s is not None and s.overlaps(X0, Y0, CH, CH)]
        self._terrain(ch, X0, Y0)
        self._roads_in(ch, X0, Y0)
        self._zones(ch, X0, Y0)
        changes = landchanges.for_chunk(self.world, cx, cy)       # this playthrough's changes to the land
        if changes:
            landchanges.apply(ch, changes)
        return ch

    def _biome_blocks(self, X0: int, Y0: int) -> dict:
        """The biome of each 4 x 4 block in and around a chunk (with a margin of one block)."""
        out = {}
        g = self.grid
        seed = self.seed
        for by in range(-1, CH // 4 + 1):
            for bx in range(-1, CH // 4 + 1):
                X, Y = X0 + bx * 4 + 2, Y0 + by * 4 + 2
                mx, my = X / SQ, Y / SQ
                jx = (G.noise(mx, my, 3.0, seed + 101) - 0.5) * 5.0
                jy = (G.noise(mx, my, 3.0, seed + 102) - 0.5) * 5.0
                out[(bx, by)] = g.biome_at(mx + jx, my + jy)
        return out

    def _terrain(self, ch: Chunk, X0: int, Y0: int) -> None:
        seed = self.seed
        blocks = self._biome_blocks(X0, Y0)
        fa = _Field(X0 - 4, Y0 - 4, CH + 8, 7, seed + 1)
        fb = _Field(X0 - 4, Y0 - 4, CH + 8, 19, seed + 2)
        fc = _Field(X0 - 4, Y0 - 4, CH + 8, 53, seed + 3)
        top = CH // 4
        # the biome of every square (with a margin of two, for the shores), worked out once
        M = 2
        N = CH + 2 * M
        bio = [None] * (N * N)
        for y in range(Y0 - M, Y0 + CH + M):
            base = (y - Y0 + M) * N
            for x in range(X0 - M, X0 + CH + M):
                j = int(_hash(x, y, seed + 9) * 5) - 2             # ragged edges between biomes
                bx = (x - X0 + j) // 4
                by = (y - Y0 - j) // 4
                bx = -1 if bx < -1 else top if bx > top else bx
                by = -1 if by < -1 else top if by > top else by
                bio[base + x - X0 + M] = blocks[(bx, by)]
        # water first
        wet = {}
        for y in range(Y0 - M, Y0 + CH + M):
            base = (y - Y0 + M) * N
            for x in range(X0 - M, X0 + CH + M):
                b = bio[base + x - X0 + M]
                if b in WATER:
                    wet[(x, y)] = WATER[b]
                elif b == "Swamp":
                    if fb.at(x, y) > 0.64 and fa.at(x, y) > 0.35:
                        wet[(x, y)] = "swamp"
        shore_cells = set()                               # within two squares (straight) of open water
        for (x, y), kind in wet.items():
            if kind == "swamp":
                continue
            for d in (1, 2):
                shore_cells.update(((x + d, y), (x - d, y), (x, y + d), (x, y - d)))
        props, prop_cells, walls, water = ch.props, ch.prop_cells, ch.walls, ch.water
        for y in range(Y0, Y0 + CH):
            row = ch.floor[y - Y0]
            base = (y - Y0 + M) * N
            for x in range(X0, X0 + CH):
                c = (x, y)
                b = bio[base + x - X0 + M]
                w = wet.get(c)
                if w is not None:
                    water[c] = w
                    row[x - X0] = "sand" if w == "sea" else "dirt"
                    if _hash(x, y, seed + 5) < 0.004:                 # fish rising here (step 7)
                        pr = A.AProp("fishing_spot", x, y, 0)
                        props.append(pr)
                        prop_cells[c] = pr
                    continue
                r = _hash(x, y, seed + 4)
                shore = b != "Swamp" and c in shore_cells
                floor, wall, prop = _ground(b, fa.at(x, y), fb.at(x, y), fc.at(x, y), r, shore)
                row[x - X0] = floor
                if wall:
                    walls[c] = wall
                elif prop:
                    v = int(r * 997) % 6
                    if prop == "ore_vein":                          # its ore, by the region's danger (step 7)
                        v = GA.vein_variant(x, y, seed, self._danger_at(x, y))
                    pr = A.AProp(prop, x, y, v)
                    props.append(pr)
                    prop_cells[c] = pr

    def _danger_at(self, x: int, y: int) -> int:
        reg = G.region_at(self.world, x / SQ, y / SQ)
        return int((reg.fields.get("danger") if reg is not None else 0) or 0)

    def _roads_in(self, ch: Chunk, X0: int, Y0: int) -> None:
        seen = set()
        cells: dict = {}
        for key in (((X0) // BIN, (Y0) // BIN), ((X0 + CH) // BIN, (Y0 + CH) // BIN),
                    ((X0) // BIN, (Y0 + CH) // BIN), ((X0 + CH) // BIN, (Y0) // BIN)):
            for seg in self._road_bins.get(key, ()):
                if id(seg) in seen:
                    continue
                seen.add(id(seg))
                (ax, ay), (bx, by), width, floor = seg
                if max(ax, bx) < X0 - 3 or min(ax, bx) > X0 + CH + 3 or max(ay, by) < Y0 - 3 or \
                        min(ay, by) > Y0 + CH + 3:
                    continue
                rad = width / 2.0
                r2 = rad * rad
                vx, vy = bx - ax, by - ay
                ll = vx * vx + vy * vy or 1e-9
                x_lo, x_hi = max(X0, int(min(ax, bx) - rad - 1)), min(X0 + CH - 1, int(max(ax, bx) + rad + 1))
                y_lo, y_hi = max(Y0, int(min(ay, by) - rad - 1)), min(Y0 + CH - 1, int(max(ay, by) + rad + 1))
                for yy in range(y_lo, y_hi + 1):                # squares within the road's width of its line
                    cy = yy + 0.5 - ay
                    for xx in range(x_lo, x_hi + 1):
                        cx = xx + 0.5 - ax
                        t = (cx * vx + cy * vy) / ll
                        t = 0.0 if t < 0 else 1.0 if t > 1 else t
                        dx, dy = cx - vx * t, cy - vy * t
                        if dx * dx + dy * dy <= r2:
                            c = (xx, yy)
                            if FLOOR_RANK[floor] > FLOOR_RANK.get(cells.get(c, ""), -1):
                                cells[c] = floor            # where roads meet, the better one shows
        for c, floor in cells.items():
            x, y = c
            if c in ch.water:
                del ch.water[c]
                ch.floor[y - Y0][x - X0] = "ford" if floor == "track" else "wood"     # a ford, or a bridge
            else:
                ch.floor[y - Y0][x - X0] = floor                   # over the passes too: the rock's cut away
            ch.walls.pop(c, None)
            p = ch.prop_cells.pop(c, None)
            if p is not None and p in ch.props:
                ch.props.remove(p)

    def _zones(self, ch: Chunk, X0: int, Y0: int) -> None:
        w = self.world
        corners = [H.at(w, (X0 + dx) / SQ, (Y0 + dy) / SQ) for dx, dy in ((0, 0), (CH - 1, 0), (0, CH - 1),
                                                                             (CH - 1, CH - 1))]
        if all(c == corners[0] for c in corners):
            z = self.zone_id(H.hex_id(*corners[0]))
            for row in ch.zone:
                for i in range(CH):
                    row[i] = z
            return
        cache = {}
        for y in range(Y0, Y0 + CH):
            for x in range(X0, X0 + CH):
                qr = H.at(w, x / SQ, y / SQ)
                z = cache.get(qr)
                if z is None:
                    z = cache[qr] = self.zone_id(H.hex_id(*qr))
                ch.zone[y - Y0][x - X0] = z



def _town_site(world, town, roads: dict, gates: dict) -> Site | None:
    """A town's site as the walking map lays it in (not yet laid in). Kept in the world's cache once built
    (step 18): a town is only built again when it, its roads or the code that builds it change."""
    pos = G.town_position(world, town)
    if pos is None:
        return None
    from game import diskcache
    ways = [roads.get(_road_key(town.id, r.get("leads_to") or "")) for r in places.roads_of(town)]
    fp = diskcache.fingerprint("town-site", _code_sig(), A._town_sig(world, town), pos, repr(ways))
    hit = diskcache.load(world, f"town:{town.id}", fp)
    if hit is not None:
        site, made_gates = hit
        gates.update(made_gates)
        site.gates = gates
        return site
    site = _build_town_site(world, town, pos, roads, gates)
    # kept under the town as it is now: building it may have given its buildings their rooms
    fp = diskcache.fingerprint("town-site", _code_sig(), A._town_sig(world, town), pos, repr(ways))
    diskcache.store(world, f"town:{town.id}", fp, (site, dict(gates)), keep=TOWNS_KEPT)
    return site


KEEP_NEAR = 192               # squares: sites this close to the one just laid in are never taken out
TOWNS_KEPT = 48                # how many towns' walking maps the cache keeps (the most recently visited)
_code = []


def _code_sig() -> str:
    """The code that lays out a town, as a fingerprint: a new version builds towns afresh."""
    if not _code:
        import hashlib
        from pathlib import Path
        h = hashlib.sha1()
        here = Path(__file__).parent
        for name in ("area.py", "rooms.py", "townlayout.py", "townplan.py", "worldmap.py", "places.py",
                     "landchanges.py", "art/tiles.py", "art/props.py"):
            try:
                h.update((here / name).read_bytes())
            except OSError:
                h.update(name.encode())
        _code.append(h.hexdigest())
    return _code[0]


def _build_town_site(world, town, pos, roads: dict, gates: dict) -> Site:
    local = A.build_town(world, town, embedded=True)
    landchanges.tag_area(local, f"town:{town.id}")
    X, Y = int(pos[0] * SQ) - local.w // 2, int(pos[1] * SQ) - local.h // 2
    moved = A.shifted(local, X, Y, f"site:{town.id}")
    site = Site(f"site:{town.id}", "town", town.id, moved)
    site.sig = A._town_sig(world, town)
    site.gates = gates
    _roads_into_town(world, site, town, local, roads, gates)
    return site


def _landmark_site(world, e, kind: str) -> Site | None:
    pos = G.landmark_position(world, e) if kind == "landmark" else G.dungeon_position(world, e)
    if pos is None:
        return None
    from game import sites as SI
    local = SI.build(world, e, kind, G.terrain(world).biome_at(*pos))
    landchanges.tag_area(local, f"site:{e.id}")
    X, Y = int(pos[0] * SQ) - local.w // 2, int(pos[1] * SQ) - local.h // 2
    moved = A.shifted(local, X, Y, f"site:{e.id}")
    return Site(f"site:{e.id}", kind, e.id, moved)


def _roads_into_town(world, site: Site, town, local: A.Area, roads: dict, gates: dict) -> None:
    """Bring each road in from the edge of town to the nearest street, with a signpost."""
    if True:
        lv = site.base
        x0, y0, w, h = site.rect
        street_floor = getattr(local, "street_floor", "cobble")
        for r in places.roads_of(town):
            line = roads.get(_road_key(town.id, r.get("leads_to") or ""))
            if not line:
                continue
            pts = line if _road_key(town.id, r["leads_to"])[0] == town.id else list(reversed(line))
            entry = None
            for (px, py) in _walk_line(pts, 0.7):
                if not (x0 + 1 <= px < x0 + w - 1 and y0 + 1 <= py < y0 + h - 1):
                    break
                entry = (int(px), int(py))
            if entry is None:
                continue
            # where the road crosses the edge of the map of the town
            ex, ey = entry
            ex = min(max(ex, x0 + 1), x0 + w - 2)
            ey = min(max(ey, y0 + 1), y0 + h - 2)
            path = _path_to_street(lv, (ex, ey), site.rect)
            for c in path:
                if lv.floor_at(*c) != street_floor:
                    lv.set_floor(c[0], c[1], "path")
                p = lv.prop_cells.get(c)
                if p is not None:
                    lv.remove_prop(p)
                lv.walls.pop(c, None)
                lv.water.pop(c, None)
            gates[r["direction"]] = (ex, ey)
            # the signpost stands beside the road, not on it
            side_x = min(ex - x0, x0 + w - 1 - ex) <= min(ey - y0, y0 + h - 1 - ey)
            beside = ((0, 1), (0, -1), (0, 2), (0, -2)) if side_x else ((1, 0), (-1, 0), (2, 0), (-2, 0))
            out_dx = (1 if ex - x0 > w / 2 else -1) if side_x else 0
            out_dy = 0 if side_x else (1 if ey - y0 > h / 2 else -1)
            cx_, cy_ = ex, ey
            while x0 <= cx_ < x0 + w and y0 <= cy_ < y0 + h:       # out to the edge, to meet the road
                c = (cx_, cy_)
                p = lv.prop_cells.get(c)
                if p is not None:
                    lv.remove_prop(p)
                lv.walls.pop(c, None)
                if lv.floor_at(*c) != street_floor:
                    lv.set_floor(c[0], c[1], "path")
                cx_, cy_ = cx_ + out_dx, cy_ + out_dy
                if not (out_dx or out_dy):
                    break
            for dx, dy in beside:
                c = (ex + dx, ey + dy)
                if lv.free(*c) and c not in path:
                    lv.add_prop("signpost", c[0], c[1])
                    dest = world.entities.get(r["leads_to"])
                    lv.stations[c] = {"kind": "signpost", "room": "", "spot": None, "town": town.id,
                                      "direction": r["direction"], "to": dest.name if dest else ""}
                    break



def _ground(b: str, na: float, nb: float, nc: float, r: float, shore: bool):
    """(floor, wall, prop) for one square of open country."""
    tree = TREE.get(b, "tree")
    if shore:
        return "sand", None, ("rock" if r < 0.01 else None)
    if b in ("Plains", "Savanna", "Coast"):
        floor = "dirt" if nb > 0.74 and na > 0.5 else ("sand" if b == "Coast" and nb < 0.35 else "grass")
        copse = nc > 0.64
        if r < (0.11 if copse else 0.004 if b != "Savanna" else 0.006):
            return floor, None, tree
        if r < 0.02:
            return floor, None, "bush"
        if r < 0.024:
            return floor, None, "rock"
        if r < 0.028:                                              # (gathering: step 7)
            return floor, None, "wild_grain" if b != "Coast" else "herb_patch"
        if r < 0.030:
            return floor, None, "herb_patch"
        return floor, None, None
    if b in ("Forest", "Jungle", "Taiga"):
        floor = "snow" if b == "Taiga" and nc > 0.72 else ("dirt" if nb > 0.82 else "grass")
        dense = 0.07 + 0.3 * max(0.0, nc - 0.3)
        if nb < 0.26:
            dense *= 0.15                                          # a clearing
        if b == "Jungle":
            dense += 0.08
        if r < dense:
            return floor, None, tree if b != "Forest" or na < 0.8 else "pine"
        if r < dense + 0.03:
            return floor, None, "bush"
        if r < dense + 0.04:
            return floor, None, "mushrooms"
        if r < dense + 0.043:
            return floor, None, "stump"
        if r < dense + 0.049:
            return floor, None, "berry_bush"
        if r < dense + 0.053:
            return floor, None, "herb_patch"
        return floor, None, None
    if b == "Hills":
        floor = "dirt" if nb > 0.68 else "grass"
        if nc > 0.78 and nb > 0.62 and na > 0.45:
            return floor, "rock_wall", None
        if r < 0.03:
            return floor, None, "rock"
        if r < 0.05:
            return floor, None, tree
        if r < 0.06:
            return floor, None, "bush"
        if r < 0.066:
            return floor, None, "ore_vein"
        return floor, None, ("quarry_rock" if r < 0.072 else "herb_patch" if r < 0.075 else None)
    if b == "Mountains":
        floor = "snow" if nc > 0.7 else ("cave" if na > 0.62 else "dirt")
        if nb > 0.6 and na > 0.32:
            return floor, "rock_wall", None
        if r < 0.05:
            return floor, None, "rock"
        if r < 0.06:
            return floor, None, "pine"
        if r < 0.071:
            return floor, None, "ore_vein"
        return floor, None, ("quarry_rock" if r < 0.078 else None)
    if b in ("Desert", "Badlands"):
        floor = "sand" if b == "Desert" else ("sand" if nb < 0.3 else "dirt")
        if (b == "Badlands" and nb > 0.7 and na > 0.5) or (b == "Desert" and nc > 0.86 and nb > 0.74):
            return floor, "rock_wall", None
        if r < 0.007:
            return floor, None, "rock"
        if b == "Badlands" and r < 0.015:
            return floor, None, "rubble"
        if r < 0.004:
            return floor, None, "bush"
        if b == "Badlands" and r < 0.021:
            return floor, None, "ore_vein"
        return floor, None, ("herb_patch" if b == "Desert" and 0.007 <= r < 0.009 else None)
    if b in ("Arctic", "Tundra"):
        floor = "grass" if b == "Tundra" and nb > 0.62 else "snow"
        if nb > 0.86 and na > 0.5:
            return floor, "rock_wall", None
        if r < 0.012:
            return floor, None, "rock"
        if b == "Arctic" and r < 0.016:
            return floor, None, tree
        if r < 0.017:
            return floor, None, "bush"
        return floor, None, ("berry_bush" if b == "Tundra" and r < 0.02 else "ore_vein" if r < 0.0215 else None)
    if b == "Swamp":
        floor = "dirt" if na > 0.72 else "grass"
        if r < 0.06:
            return floor, None, tree
        if r < 0.1:
            return floor, None, "mushrooms"
        if r < 0.13:
            return floor, None, "bush"
        return floor, None, ("herb_patch" if r < 0.145 else None)
    return "grass", None, None


# ======================================================================
# Roads
# ======================================================================
def _sea_cells(world, pa, pb) -> list[tuple[float, float]]:
    """A ship's course between two ports (points in miles), over the open water of the world map's grid:
    out of port, across the sea, into port. [] if there's no way by water."""
    import heapq
    g = G.terrain(world)
    water = {i for i, b in enumerate(G.BIOMES) if b in ("Ocean", "Lake")}
    cols, rows, cell = g.cols, g.rows, g.cell
    bio = g.biome

    def idx(p):
        return min(rows - 1, max(0, int(p[1] // cell))) * cols + min(cols - 1, max(0, int(p[0] // cell)))
    start, goal = idx(pa), idx(pb)
    gx, gy = goal % cols, goal // cols
    best = {start: 0.0}
    came = {}
    heap = [(0.0, 0.0, start)]
    seen = 0
    steps = [(1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0), (1, 1, 1.414), (1, -1, 1.414), (-1, 1, 1.414),
             (-1, -1, 1.414)]
    while heap:
        _f, cost, cur = heapq.heappop(heap)
        if cur == goal:
            break
        if cost > best.get(cur, 1e18):
            continue
        seen += 1
        if seen > 300000:
            return []
        cx, cy = cur % cols, cur // cols
        for dx, dy, d in steps:
            nx, ny = cx + dx, cy + dy
            if not (0 <= nx < cols and 0 <= ny < rows):
                continue
            n = ny * cols + nx
            c = cost + d * (1.0 if bio[n] in water or n == goal else 40.0)
            if c < best.get(n, 1e18):
                best[n] = c
                came[n] = cur
                h = max(abs(nx - gx), abs(ny - gy)) + 0.414 * min(abs(nx - gx), abs(ny - gy))
                heapq.heappush(heap, (c + h, c, n))
    if goal not in came:
        return []
    out = []
    node = came[goal]
    while node != start:
        out.append(((node % cols + 0.5) * cell, (node // cols + 0.5) * cell))
        node = came[node]
    return list(reversed(out))[::2] or list(reversed(out))


def _road_key(a: str, b: str) -> tuple[str, str]:
    return (a, b) if a <= b else (b, a)


def _walk_line(pts: list, step: float):
    """Points every `step` squares along a polyline."""
    for (ax, ay), (bx, by) in zip(pts, pts[1:]):
        d = math.hypot(bx - ax, by - ay)
        n = max(1, int(d / step))
        for i in range(n + 1):
            t = i / n
            yield ax + (bx - ax) * t, ay + (by - ay) * t


def _road_index(world):
    """Every road as a bending line of squares (town to town), and bins of its pieces for quick lookup.
    Kept on the world object until the towns change."""
    pos = G.town_positions(world)
    own = [t for t in world.entities.all("town") if t.fields.get("settlement")]
    if own:                                             # the party's own settlements (game/colony.py): their
        base_lines, base_bins = _world_roads(world, pos)    # roads go on top of the world's, never cached
        if not any(t.fields.get("roads") for t in own):
            return base_lines, base_bins
        lines, bins = dict(base_lines), {k: list(v) for k, v in base_bins.items()}
        seed = int(G.settings(world)["seed"])
        for t in own:
            for r in t.fields.get("roads") or []:
                _lay_road(world, pos, seed, t, r, lines, bins)
        return lines, bins
    return _world_roads(world, pos)


def roads_for(world, continent: str | None = None):
    """(lines, bins) of the roads of the whole world, or of one continent (the roads from its towns)."""
    if continent == SEA:                       # aboard: only the sea and the coasts
        return {}, {}
    quick = _quick_sig(world)
    done = getattr(world, "_road_done", None)
    if done is not None and done[0] == quick and (continent or "") in done[1]:
        return done[1][continent or ""]
    if not continent:
        got = _road_index(world)
        if done is None or done[0] != quick:
            done = world._road_done = (quick, {})
        done[1][""] = got
        return got
    pos = G.town_positions(world)
    towns_all = [t for t in world.entities.all("town") if not t.fields.get("settlement")
                 and town_continent(world, t.id) == continent]
    sig = (continent, len([1 for t in towns_all if t.id in pos]),
           sum(len(t.fields.get("roads") or []) for t in towns_all))
    memo = getattr(world, "_road_conts", None)
    if memo is None or memo.get("_sig") != _world_sig(world):
        memo = world._road_conts = {"_sig": _world_sig(world)}
    got = memo.get(continent)
    if got is None or got[0] != sig:
        seed = int(G.settings(world)["seed"])
        from game import diskcache
        fp = diskcache.fingerprint("roads", seed, BIN, SQ, 2, continent, sorted(
            (t.id, pos.get(t.id), tuple(sorted((r.get("leads_to") or "", r.get("grade") or "")
                                               for r in t.fields.get("roads") or [])),
             G.settlement_kind(t)) for t in towns_all))
        hit = _roads_cached(world, f"roads-{continent}", fp)
        if hit is None:
            lines: dict = {}
            bins: dict = {}
            from game import progress
            for ti, t in enumerate(towns_all):
                if ti % 25 == 0:
                    progress.report(ti / max(1, len(towns_all)), "Laying the roads")
                for r in t.fields.get("roads") or []:
                    _lay_road(world, pos, seed, t, r, lines, bins)
            hit = (lines, bins)
            _roads_keep(world, f"roads-{continent}", fp, lines, bins)
        got = memo[continent] = (sig, hit[0], hit[1])
    lines, bins = got[1], got[2]
    own = [t for t in world.entities.all("town") if t.fields.get("settlement") and t.fields.get("roads")
           and town_continent(world, t.id) == continent]
    if own:                                       # the party's own settlements' roads go on top, never cached
        lines, bins = dict(lines), {k: list(v) for k, v in bins.items()}
        seed = int(G.settings(world)["seed"])
        for t in own:
            for r in t.fields.get("roads") or []:
                _lay_road(world, pos, seed, t, r, lines, bins)
    if done is None or done[0] != quick:
        done = world._road_done = (quick, {})
    done[1][continent] = (lines, bins)
    return lines, bins


def _world_roads(world, pos):
    towns_all = [t for t in world.entities.all("town") if not t.fields.get("settlement")]
    sig = (len([1 for t in towns_all if t.id in pos]), sum(len(t.fields.get("roads") or []) for t in towns_all))
    cached = getattr(world, "_road_cache", None)
    if cached is not None and cached[0] == sig:
        return cached[1], cached[2]
    seed = int(G.settings(world)["seed"])
    from game import diskcache
    fp = diskcache.fingerprint("roads", seed, BIN, SQ, 2, sorted(
        (t.id, pos.get(t.id), tuple(sorted((r.get("leads_to") or "", r.get("grade") or "")
                                           for r in t.fields.get("roads") or [])),
         G.settlement_kind(t)) for t in towns_all))
    hit = _roads_cached(world, "roads", fp)                      # worked out on an earlier run
    if hit is not None:
        world._road_cache = (sig, hit[0], hit[1])
        return hit[0], hit[1]
    lines: dict = {}
    bins: dict = {}
    from game import progress
    towns = towns_all
    for ti, t in enumerate(towns):
        if ti % 25 == 0:
            progress.report(ti / max(1, len(towns)), "Laying the roads")
        for r in t.fields.get("roads") or []:
            _lay_road(world, pos, seed, t, r, lines, bins)
    world._road_cache = (sig, lines, bins)
    _roads_keep(world, "roads", fp, lines, bins)
    return lines, bins


def _line_parter(world):
    """Roads are kept in parts by where their first town stands, so the roads near the party come together."""
    pos = G.town_positions(world)

    def part(key) -> str:
        p = pos.get(key[0])
        if p is None:
            return "x"
        return f"{int(p[0] * SQ) // (BIN * 8)},{int(p[1] * SQ) // (BIN * 8)}"
    return part


def _bin_part(key) -> str:
    return f"{key[0] // 8},{key[1] // 8}"


def _roads_cached(world, name: str, fp: str):
    """The roads from the cache, read a part at a time as the party gets near them (step 18)."""
    from game import diskcache
    lines = diskcache.load_parted(world, name + "/lines", fp, _line_parter(world))
    bins = diskcache.load_parted(world, name + "/bins", fp, _bin_part)
    if lines is None or bins is None:
        return None
    return lines, bins


def _roads_keep(world, name: str, fp: str, lines: dict, bins: dict) -> None:
    from game import diskcache
    diskcache.drop(world, name)                                  # kept whole before step 18
    diskcache.store_parted(world, name + "/lines", fp, lines, _line_parter(world))
    diskcache.store_parted(world, name + "/bins", fp, bins, _bin_part)


def _lay_road(world, pos, seed, t, r, lines, bins) -> None:
    """One road as a bending line of squares, and its pieces in the bins."""
    dest = r.get("leads_to")
    if not dest or dest not in pos or t.id not in pos:
        return
    key = _road_key(t.id, dest)
    if key in lines:
        return
    (ax, ay), (bx, by) = pos[key[0]], pos[key[1]]
    length = math.hypot(bx - ax, by - ay)
    if length <= 0:
        return
    nx, ny = -(by - ay) / length, (bx - ax) / length
    n = max(2, int(length / 1.5))
    amp = min(1.2, length * 0.06)
    salt = sum(ord(ch) for ch in key[0] + key[1])
    pts = []
    for i in range(n + 1):
        tt = i / n
        wob = (G.noise(tt * length, salt % 997, 4.0, seed + 31) - 0.5) * 2 * amp * math.sin(math.pi * tt)
        pts.append(((ax + (bx - ax) * tt + nx * wob) * SQ, (ay + (by - ay) * tt + ny * wob) * SQ))
    lines[key] = pts
    grade = r.get("grade") or ""
    if not grade:                                  # an older world: no grades, the old widths
        big = {"City", "Capital", "Town"}
        width = 4 if (G.settlement_kind(world.entities.get(key[0])) in big and
                      G.settlement_kind(world.entities.get(key[1])) in big) else 3
        floor = "path"
    else:
        width, floor = GRADES.get(grade, GRADES["road"])
    for p, q in zip(pts, pts[1:]):
        seg = (p, q, width, floor)
        for bx_ in range(int(min(p[0], q[0]) // BIN), int(max(p[0], q[0]) // BIN) + 1):
            for by_ in range(int(min(p[1], q[1]) // BIN), int(max(p[1], q[1]) // BIN) + 1):
                bins.setdefault((bx_, by_), []).append(seg)


def _path_to_street(lv, start: tuple, rect: tuple, limit: int = 60000) -> list:
    """Squares from the edge of a town to its nearest street, round walls and water."""
    x0, y0, w, h = rect
    todo = deque([start])
    prev = {start: None}
    end = None
    while todo and len(prev) < limit:
        c = todo.popleft()
        if lv.loc_at(*c).startswith("street|"):
            end = c
            break
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            n = (c[0] + dx, c[1] + dy)
            if n in prev or not (x0 <= n[0] < x0 + w and y0 <= n[1] < y0 + h):
                continue
            if n in lv.walls or n in lv.doors or lv.floor_at(*n) in A.SOLID:
                continue
            prev[n] = c
            todo.append(n)
    out = []
    while end is not None:
        out.append(end)
        end = prev[end]
    return out[::-1]


def _site_index(world, continent: str = "") -> dict:
    """bin -> [(kind, entity id, X, Y)] for every town, landmark and lone dungeon on the map (or on one
    continent of it)."""
    whole = _all_sites(world)
    if not continent:
        return whole
    out: dict = {}
    for key, rows in whole.items():
        for row in rows:
            if _site_continent(world, row) == continent:
                out.setdefault(key, []).append(row)
    return out


def _site_continent(world, row) -> str:
    kind, eid, X, Y = row
    if kind == "town":
        return town_continent(world, eid)
    c = G.continent_at(world, X / SQ, Y / SQ)
    return c.id if c is not None else ""


def town_continent(world, tid: str) -> str:
    """The id of the continent a town is on ("" for none)."""
    memo = _memo(world, "_town_conts", lambda: {})
    if tid not in memo:
        t = world.entities.get(tid)
        c = G.continent_of_town(world, t) if t is not None else None
        memo[tid] = c.id if c is not None else ""
    return memo[tid]


def _quick_sig(world) -> tuple:
    """Changes whenever anything in the world does (a cheap check for things worked out from it)."""
    return (id(world.entities), getattr(world.entities, "rev", 0), repr(world.meta.get("map")))


def _memo(world, name: str, make):
    """Something worked out from the towns and the land, kept on the world until either changes."""
    sig = _quick_sig(world)
    got = getattr(world, name, None)
    if got is None or got[0] != sig:
        got = (sig, make())
        setattr(world, name, got)
    return got[1]


def _all_sites(world) -> dict:
    return _memo(world, "_sites_memo", lambda: _make_site_index(world))


def sites_near(world, X0: float, Y0: float, X1: float, Y1: float, continent: str | None = None) -> list:
    """[(kind, entity id, X, Y)] for the sites whose middle is within reach of a stretch of squares."""
    index = _all_sites(world)
    out = []
    pad = SITE_REACH
    for bx in range(int((X0 - pad) // BIN), int((X1 + pad) // BIN) + 1):
        for by in range(int((Y0 - pad) // BIN), int((Y1 + pad) // BIN) + 1):
            for row in index.get((bx, by), ()):
                _k, _e, sx, sy = row
                if X0 - pad <= sx <= X1 + pad and Y0 - pad <= sy <= Y1 + pad:
                    if continent and _site_continent(world, row) != continent:
                        continue
                    out.append(row)
    return out


def site_sig(world, kind: str, e) -> str:
    """What a site's picture is made from: it changes when the site would."""
    if kind == "town":
        lines = roads_for(world, town_continent(world, e.id))[0]
        mine = sorted((k, len(v), tuple(v[0]), tuple(v[-1])) for k, v in lines.items() if e.id in k)
        return A._hash("town", A._town_sig(world, e), G.town_position(world, e), mine)
    pos = G.landmark_position(world, e) if kind == "landmark" else G.dungeon_position(world, e)
    return A._hash(kind, e.fields, pos)


def peek_site(world, kind: str, e) -> Site | None:
    """A site as the walking map lays it in, without laying it in (the one laid in, if it is)."""
    wa = getattr(world, "_world_area", None)
    if wa is not None and e.id in wa.sites:
        return wa.sites[e.id]
    sig = site_sig(world, kind, e)
    key = (id(world), e.id)
    got = _peeked.get(key)
    if got is not None and got[0] == sig:
        _peeked.move_to_end(key)
        return got[1]
    if kind == "town":
        site = _town_site(world, e, roads_for(world, town_continent(world, e.id))[0], {})
    else:
        site = _landmark_site(world, e, kind)
    _peeked[key] = (sig, site)
    while len(_peeked) > 6:
        _peeked.popitem(last=False)
    return site


_peeked: OrderedDict = OrderedDict()          # sites looked at (the map's town view) but not laid in


def _make_site_index(world) -> dict:
    out: dict = {}

    def add(kind, eid, p):
        if p is None:
            return
        X, Y = p[0] * SQ, p[1] * SQ
        out.setdefault((int(X // BIN), int(Y // BIN)), []).append((kind, eid, X, Y))
    for tid, p in G.town_positions(world).items():
        t = world.entities.get(tid)
        if t is not None and t.fields.get("settlement"):
            continue                                    # laid in as the party's claim (game/estate.py)
        add("town", tid, p)
    with_lm = set()
    for lm in world.entities.all("landmark"):
        add("landmark", lm.id, G.landmark_position(world, lm))
        if lm.fields.get("dungeon"):
            with_lm.add(lm.fields["dungeon"])
    for d in world.entities.all("dungeon"):
        if d.id not in with_lm:
            add("dungeon", d.id, G.dungeon_position(world, d))
    return out


def _world_sig(world) -> str:
    s = G.settings(world)
    return A._hash(round(s["width"], 1), round(s["height"], 1), s["seed"], len(G.town_positions(world)))


# ======================================================================
# Entry points
# ======================================================================
def walkable(world) -> bool:
    return bool(world.rules.get("walkable_world", True)) and bool(G.town_positions(world))


def world_area(world) -> WorldArea:
    cid = walk_continent(world)
    a = getattr(world, "_world_area", None)
    if a is None or a.world_sig != _world_sig(world) or a.continent != cid:
        a = WorldArea(world, cid)
        world._world_area = a
    return a


def forget(world) -> None:
    world._world_area = None


# ---- one continent at a time
SEA = "@sea"          # the walking map aboard a ship or airship between continents: the sea and the coasts


def uses_continents(world) -> bool:
    return bool(world.entities.all("continent"))


def party_continent_id(world, state) -> str:
    """The continent the party is on ("" when the world has none, or the party is at sea)."""
    if state is None or not uses_continents(world):
        return ""
    if (getattr(state, "journey", None) or {}).get("kind") == "voyage":
        return ""                                   # at sea
    spot = places.current(world, state)
    town = getattr(spot, "town", None) if spot is not None else None
    if town is not None and spot.kind in ("street", "building", "wild", "road"):
        cid = town_continent(world, town.id)            # a town's continent is the one its sites are laid in for
        if cid:
            return cid
    c = G.party_continent(world, state)
    return c.id if c is not None else ""


def walk_continent(world) -> str:
    """The continent the walking map is laid out for ("" for the whole world, the way tests and editors use
    it). Once a game has loaded a continent, the walking map follows the party: landing on another
    continent lays that one out instead (the game shows its loading screen first: continent_due)."""
    cur = getattr(world, "_walk_continent", None)
    if not cur:
        return ""
    st = getattr(world, "_state_for_places", None)
    loc = getattr(st, "location", None)
    memo = getattr(world, "_walk_memo", None)
    if memo is not None and memo[0] == loc and memo[1] == cur:
        return cur
    if cur == SEA and (getattr(st, "journey", None) or {}).get("kind") == "voyage":
        world._walk_memo = (loc, cur)
        return cur                                  # still aboard
    cid = party_continent_id(world, st) if st is not None else ""
    if cid and cid != cur:
        world._walk_continent = cur = cid
    world._walk_memo = (loc, cur)
    return cur


def continent_due(world, state):
    """The continent to load (its entity) when the party is on one the walking map isn't laid out for."""
    if not uses_continents(world) or state is None:
        return None
    cid = party_continent_id(world, state)
    if not cid:
        return None
    a = getattr(world, "_world_area", None)
    if a is not None and a.continent == cid and getattr(world, "_walk_continent", None) == cid:
        return None
    return world.entities.get(cid)


def load_continent(world, cid: str) -> WorldArea:
    """Lay out the walking map for one continent (or the whole world for ""), reporting progress: its
    roads, its sites, and the picture of it the map and loading screen show."""
    from game import progress
    unload(world)
    world._walk_continent = cid or ""
    world._walk_memo = None
    with progress.part(0.0, 0.55, "Laying the roads"):
        roads_for(world, cid or None)
    with progress.part(0.55, 0.75, "Finding the towns and ruins"):
        a = world_area(world)
        progress.report(1.0)
    c = world.entities.get(cid) if cid else None
    if c is not None:
        with progress.part(0.75, 1.0, "Drawing the map"):
            from game import bigmap
            bigmap.open_map(world).finish(f"continent:{c.id}")     # kept in the world once drawn
    return a


def board(world, ports: tuple = ()) -> WorldArea:
    """Aboard a ship or airship for another continent: the walking map lets go of the continent being left
    and lays out only the sea and the coasts (and the ports at each end: town ids) until the party lands."""
    from game import progress
    with progress.part(0.0, 0.6, "Leaving port"):
        unload(world)
        progress.report(1.0)
    world._sea_ports = tuple(ports)
    world._walk_continent = SEA
    world._walk_memo = None
    with progress.part(0.6, 1.0, "Making ready to sail"):
        a = world_area(world)
        progress.report(1.0)
    return a


def crosses(world, from_town, to_town) -> bool:
    """Whether a passage between two towns goes to another continent."""
    if from_town is None or to_town is None or not uses_continents(world):
        return False
    a, b = town_continent(world, from_town.id), town_continent(world, to_town.id)
    return bool(a and b and a != b)


def unload(world) -> None:
    """Let go of the walking map in memory (before a voyage to another continent)."""
    world._world_area = None
    A.forget()


# ======================================================================
# What's been seen, chunk by chunk (game/explore.py keeps these)
# ======================================================================
SEEN_BYTES = CH * CH // 8


def pack_seen(chunks: dict) -> str:
    raw = b"".join(struct.pack("<ii", cx, cy) + bytes(b) for (cx, cy), b in chunks.items())
    return base64.b64encode(zlib.compress(raw, 6)).decode("ascii")


def unpack_seen(text: str) -> dict:
    out = {}
    try:
        raw = zlib.decompress(base64.b64decode(text))
    except Exception:  # noqa: BLE001
        return out
    step = 8 + SEEN_BYTES
    for i in range(0, len(raw) - step + 1, step):
        cx, cy = struct.unpack_from("<ii", raw, i)
        out[(cx, cy)] = bytearray(raw[i + 8:i + step])
    return out


__all__ = ["WorldArea", "ChunkLevel", "Chunk", "Site", "world_area", "walkable", "SQ", "CH", "pack_seen",
           "unpack_seen", "roads_for", "sites_near", "peek_site", "load_continent", "continent_due", "unload",
           "party_continent_id", "town_continent", "board", "crosses", "SEA"]
