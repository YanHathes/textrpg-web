"""Townsfolk: the unnamed crowd on the streets of cities and capitals.

They aren't people in the world's records: nobody is saved, nothing remembers them. Each hour a fresh
crowd is worked out from the town and the hour (so it's the same if you look away and back), drawn from
the peoples who live there, dressed for a line of work. Speak to one and you get a line back: mostly
what you'd expect from someone of their trade or people, now and then a bad joke, and now and then a
mouthful for getting in their way.
"""
from __future__ import annotations

import random
import zlib

from game import settlements as ST

PER_TOWN = {"City": 12, "Capital": 20}
AUTOMATON_SHARE = 0.06            # the workshops of the great cities have sent some out into the streets

# (role, armor style, clothes colours, weight, accessory)
ROLES = [
    ("labourer", "tunic", ("#6a5038", "#5b6b4e", "#7a6a4a", "#5a4a3a"), 6),
    ("porter", "tunic", ("#7a6a4a", "#6a5a48", "#5b6b4e"), 3),
    ("merchant", "noble", ("#7a2a3a", "#2a3f6a", "#3f5a3f", "#6a4a2a"), 3),
    ("noble", "noble", ("#5a2a6a", "#7a1f2a", "#1f3a5a"), 1),
    ("guard", "chain_mail", ("#6a2a2a", "#2a3a6a"), 2),
    ("priest", "robe", ("#e8e0c8", "#4a3f5e", "#8a2a2a"), 1),
    ("scholar", "robe", ("#3b2f6a", "#2a3a4a", "#4a3a2a"), 1),
    ("sailor", "leather", ("#2a3a5a", "#4a4a5a"), 1),
    ("beggar", "tunic", ("#5a5048", "#4a4038"), 1),
    ("farmer", "tunic", ("#6f7f3a", "#7a6a4a"), 2),
]
ROLE_NAME = {"labourer": "labourer", "porter": "porter", "merchant": "merchant", "noble": "noble",
             "guard": "off-duty guard", "priest": "priest", "scholar": "scholar", "sailor": "sailor",
             "beggar": "beggar", "farmer": "farmer in town for market"}

BY_ROLE = {
    "labourer": ["Mind the cart.", "Twelve hours on the walls today. My back's done.",
                 "If you're hiring, I'm cheaper than a mule and I complain less.",
                 "They say the foreman's skimming our pay. They're right.",
                 "Rain's coming. Feel it in my knees."],
    "porter": ["Coming through! Heavy load!", "Two coppers and I'll carry that for you.",
               "Up the hill, down the hill. All day.", "Watch your feet, friend."],
    "merchant": ["Prices are up again. Blame the roads.", "Fine cloth, fair price. Come by the market.",
                 "If you're selling, I'm buying. Within reason.", "Bandits on the east road took a whole wagon.",
                 "Gold talks. Everything else just mutters."],
    "noble": ["Do I know you?", "Kindly step aside.", "The council is full of fools. Present company excluded.",
              "One doesn't simply *walk* in this weather."],
    "guard": ["Keep your blade sheathed inside the walls.", "Quiet day. Let's keep it that way.",
              "Seen anything odd, you tell the watch.", "Off duty. Ask someone in a helmet."],
    "priest": ["The gods see you, traveller.", "There's bread at the temple for anyone who needs it.",
               "Light a candle for the road ahead.", "Peace be with you."],
    "scholar": ["Fascinating. No, not you. This.", "The library closes at dusk. Barbaric.",
                "Do you know how old these walls are? Older than you'd think.",
                "I'm late for a lecture I'm giving."],
    "sailor": ["Ship's in for three days, then gone again.", "Never trust a calm sea.",
               "Smells better out on the water than in here.", "Got a thirst you could float a boat in."],
    "beggar": ["Spare a copper?", "Bless you, whatever you give.", "Cold nights lately.",
               "I wasn't always like this, you know."],
    "farmer": ["Good harvest this year, gods willing.", "City folk. Never seen a cow up close.",
               "Market's busy. Prices are worse.", "Long walk in. Longer walk home."],
}
BY_RACE = {
    "dwarf": ["Stone's honest. People, less so.", "Call this ale? Back home we'd wash with it."],
    "elf": ["You humans are always in such a hurry.", "I remember when this was all forest."],
    "halfling": ["Have you eaten? You look like you haven't eaten.", "Second breakfast won't eat itself."],
    "gnome": ["I've got a contraption that'd sort this traffic out.", "Mind the gears!"],
    "half_orc": ["Something to say?", "Don't stare. It's rude."],
    "tiefling": ["Yes, they're real horns.", "Stare all you like. I'm used to it."],
    "dragonborn": ["My clan would never stand for streets this crooked.", "Honour first. Then lunch."],
    "automaton": ["Good day. My mainspring is fully wound and so is my patience.",
                  "I was built for the docks. I prefer the library.",
                  "No, I don't need to eat. Yes, I'll keep you company while you do.",
                  "My maker said I'd last a hundred years. I intend to check."],
}
FUNNY = [
    "I used to be a banker, but I lost interest.",
    "Why did the scarecrow get a medal? He was outstanding in his field.",
    "I'd tell you a joke about the town wall, but you'd never get over it.",
    "My wife said I should do lunges to stay in shape. That'd be a big step forward.",
    "I bought a ladder at the market. Couldn't resist, it was a step up.",
    "What do you call a wizard who's lost his hat? Bald.",
    "The baker quit. Couldn't make enough dough.",
    "I'm reading a book on anti-gravity. Can't put it down.",
    "Never trust a dwarf's ladder. It's always a short story.",
    "Two goblins walk into a bar. The third one ducks.",
    "I asked the blacksmith for a joke. He said he'd forge one.",
    "The old well? Oh, it's not deep. It's just well-meaning.",
    "You know why skeletons don't fight? They don't have the guts.",
    "My dog's a terrible guard. He just sits there when the bard plays. He's a sit-fiddler.",
    "Did you hear about the cheese shop that blew up? De-brie everywhere.",
    "Don't trust stairs. They're always up to something.",
]
RUDE = [
    "Get out of my way, you daft bastard.",
    "Watch where you're bloody going!",
    "Piss off, I'm busy.",
    "Oi! Shove off, arsehole.",
    "Do I look like I want to talk to you? Bugger off.",
    "Gods' teeth, another bloody adventurer. Move!",
    "Step on my foot again and I'll break yours, you clumsy git.",
    "What the hell are you staring at?",
    "Out of the road, you great lump of shite.",
    "Damn tourists.",
]
LINE_ODDS = (0.75, 0.15, 0.10)    # serious, funny, rude


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


def per_town(town) -> int:
    return PER_TOWN.get(ST.tier_of(town), 0) if town is not None else 0


def line(rng: random.Random, race: str, role: str) -> str:
    r = rng.random()
    if r < LINE_ODDS[0]:
        pool = list(BY_ROLE.get(role, [])) + list(BY_RACE.get(race, [])) * 2
        return rng.choice(pool or BY_ROLE["labourer"])
    if r < LINE_ODDS[0] + LINE_ODDS[1]:
        return rng.choice(FUNNY)
    return rng.choice(RUDE)


def pool(world, town, limit: int = 60) -> list[dict]:
    """Looks of the town's own people (a sample), so the crowd matches who lives there."""
    from game import places
    out = []
    for b in places.buildings_in(world, town):
        for n in world.entities.by_field("npc", "building", b.id):
            try:
                out.append(world.sprites.resolve_look(n, world.entities))
            except Exception:  # noqa: BLE001 - someone without a look just isn't copied
                continue
            if len(out) >= limit:
                return out
    return out


def crowd(world, town, hour: int, looks: list[dict]) -> list[dict]:
    """The townsfolk out at this hour: [{"id", "name", "race", "role", "look", "armor", "tint", "line"}]."""
    from game.art.humanoid import BODY_BASES, HAIR_STYLES
    n = per_town(town)
    if not n:
        return []
    try:                                             # a festival brings everyone out (game/townevents.py)
        from game import townevents as TE
        st = getattr(world, "_state_for_places", None)
        if st is not None:
            n = int(n * TE.busy_factor(world, st, town))
    except Exception:  # noqa: BLE001
        pass
    rng = _rng("crowd", town.id, hour)
    coastal = (town.fields.get("terrain") or "") in ("Coast", "Lake")
    roles = [r for r in ROLES if r[0] != "sailor" or coastal]
    weights = [r[3] for r in roles]
    out = []
    for i in range(n):
        if rng.random() < AUTOMATON_SHARE:
            base = "automaton"
        else:
            base = (rng.choice(looks).get("base") if looks else "") or "human"
        b = BODY_BASES.get(base) or BODY_BASES["human"]
        role, armor, tints, _w, = rng.choices(roles, weights)[0]
        male = rng.random() < 0.5
        look = {"base": b.id, "skin": rng.choice(b.skin_options) if b.skin_options else b.skin,
                "hair": "none" if b.hair == "none" else rng.choice([h for h in HAIR_STYLES if h not in ("none", "mane",
                                                                                                    "ragged")]),
                "hair_color": rng.choice(b.hair_options) if b.hair_options else b.hair_color,
                "beard": (rng.choice(["none", "stubble", "short", "full"]) if male and "metal" not in b.features
                          and b.hair != "none" else "none"),
                "clothes": rng.choice(tints), "sex": "male" if male else "female"}
        if base == "dwarf" and male:
            look["beard"] = rng.choice(["full", "braided"])
        out.append({"id": f"crowd:{town.id}:{hour}:{i}", "name": f"{b.label} {ROLE_NAME.get(role, role)}",
                    "race": b.id, "role": role, "look": look, "armor": armor, "tint": look["clothes"],
                    "line": line(rng, b.id, role)})
    return out


def sprite_key(d: dict) -> str:
    lk = d["look"]
    return "crowd:" + "|".join(str(lk.get(k, "")) for k in ("base", "skin", "hair", "hair_color", "beard")) + \
        f"|{d['armor']}|{d['tint']}"


def sprite(d: dict):
    """The map sprite for one of the crowd."""
    from game.art import doll, folk
    from game.art.humanoid import Look
    lk = d["look"]
    return folk.sprite(Look(base=lk["base"], skin=lk["skin"], hair=lk["hair"], hair_color=lk["hair_color"],
                            beard=lk["beard"], clothes=lk["clothes"]),
                       doll.Gear(armor=d["armor"], armor_tint=d["tint"]))


__all__ = ["crowd", "pool", "line", "sprite", "sprite_key", "per_town", "BY_ROLE", "BY_RACE", "FUNNY", "RUDE"]
