"""Spreadsheet import and export: one row per entity, one column per field.

Files: .csv / .tsv, or .xlsx (needs the openpyxl package; each sheet named after a type, such as
"Spells" or "spell", is imported as that type).

Columns are matched to fields by key or label, ignoring case, spaces and punctuation ("Hit die",
"hit_die" and "HitDie" all work). "name" is required; "description" and "tags" are optional.
Unknown columns are reported and skipped.

How cells are read, by field type:
    number              12, 2.5             bool        yes / no / true / x / 1
    choice              one option, any case            multichoice  comma separated
    text list           lines, or  a | b | c
    link                a name (or id) of the linked type
    links               names, comma or semicolon separated
    table               rows separated by ";" or new lines, columns by "|" in the template's order:
                          features:  1 | Second Wind ; 2 | Action Surge
                        or key=value pairs:  level=1, feature=Second Wind ; level=2, feature=Action Surge
                        or a JSON list
    stat values         str 15, dex 12  or  15/12/14/10/8/8 (in stat order)
    loadout             Main hand=Longsword; Body=Chain Mail
    point               x, y (miles)
Links can point at rows of the same import: everything is created first, links are filled after.
"""
from __future__ import annotations

import csv
import io
import json
import re
from pathlib import Path

from game.fields import FieldDef
from game.templates import TYPE_ORDER

TRUE = {"1", "true", "yes", "y", "x", "on", "✓"}
SKIP_HEADERS = {"id", "type", "created", "modified"}


def _norm(text) -> str:
    return re.sub(r"[^0-9a-z]+", "", str(text or "").lower())


# ======================================================================
# Reading files
# ======================================================================
def read_file(path) -> dict[str, list[dict]]:
    """{sheet name: rows (dicts by header)}. CSV files have one sheet named after the file."""
    path = Path(path)
    ext = path.suffix.lower()
    if ext in (".csv", ".tsv", ".txt"):
        text = path.read_text(encoding="utf-8-sig")
        dialect = "excel-tab" if ext == ".tsv" or (text.count("\t") > text.count(",")) else "excel"
        reader = csv.DictReader(io.StringIO(text), dialect=dialect)
        return {path.stem: [dict(r) for r in reader]}
    if ext in (".xlsx", ".xlsm"):
        try:
            import openpyxl
        except ImportError as exc:
            raise RuntimeError("Reading .xlsx files needs the openpyxl package (pip install openpyxl). "
                               "You can also save the sheet as CSV.") from exc
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        out = {}
        for ws in wb.worksheets:
            rows = list(ws.iter_rows(values_only=True))
            if not rows:
                continue
            headers = [str(h or "").strip() for h in rows[0]]
            out[ws.title] = [{headers[i]: ("" if v is None else v) for i, v in enumerate(r) if i < len(headers)
                              and headers[i]} for r in rows[1:] if any(v not in (None, "") for v in r)]
        return out
    raise RuntimeError(f"Can't read {ext} files. Use .csv, .tsv or .xlsx.")


def guess_type(world, sheet_name: str) -> str:
    n = _norm(sheet_name)
    for t in world.templates.all():
        if n in (_norm(t.type), _norm(t.label), _norm(t.plural)):
            return t.type
    for t in world.templates.all():
        if _norm(t.plural) in n or _norm(t.label) in n:
            return t.type
    return ""


# ======================================================================
# Columns
# ======================================================================
def column_map(world, type_name: str, headers: list[str]) -> tuple[dict, list[str]]:
    """({header: field key}, unknown headers). name/description/tags map to themselves."""
    template = world.templates.get(type_name)
    by = {}
    for f in template.fields():
        by.setdefault(_norm(f.key), f.key)
        by.setdefault(_norm(f.label), f.key)
    for k in ("name", "description", "tags"):
        by[_norm(k)] = k
    mapping, unknown = {}, []
    for h in headers:
        if not str(h or "").strip() or _norm(h) in SKIP_HEADERS:
            continue
        key = by.get(_norm(h))
        if key:
            mapping[h] = key
        else:
            unknown.append(h)
    return mapping, unknown


# ======================================================================
# Cells
# ======================================================================
class Resolver:
    """Finds entities by name or id, including ones being imported in the same batch."""

    def __init__(self, world, pending: dict[tuple[str, str], str] | None = None) -> None:
        self.world = world
        self.pending = pending or {}        # (type, lower name) -> id
        self.missing: list[str] = []

    def find(self, text, targets: list[str]) -> str | None:
        text = str(text or "").strip()
        if not text:
            return None
        e = self.world.entities.get(text)
        if e is not None and (not targets or e.type in targets):
            return e.id
        for t in targets or TYPE_ORDER:
            hit = self.pending.get((t, text.lower()))
            if hit:
                return hit
            e = self.world.entities.find_by_name(t, text)
            if e is not None:
                return e.id
        self.missing.append(text)
        return None


def _split(text, seps=r"[,;]") -> list[str]:
    return [p.strip() for p in re.split(seps, str(text or "")) if p.strip()]


def parse_cell(world, f: FieldDef, raw, res: Resolver | None, links: bool = True):
    """A cell's text as the field's value (links resolved only when links=True)."""
    if raw is None:
        return None
    if isinstance(raw, (int, float)) and not isinstance(raw, bool) and f.type not in ("number", "bool"):
        raw = str(int(raw)) if float(raw).is_integer() else str(raw)
    text = raw if not isinstance(raw, str) else raw.strip()
    if text == "" or text is None:
        return None
    t = f.type
    if t == "number":
        return float(text) if not f.integer else int(round(float(text)))
    if t == "bool":
        return str(text).strip().lower() in TRUE
    if t == "choice":
        for o in f.options or []:
            if str(o).lower() == str(text).lower():
                return o
        return str(text)
    if t == "multichoice":
        out = []
        for part in _split(text):
            match = next((o for o in f.options or [] if str(o).lower() == part.lower()), part)
            out.append(match)
        return out
    if t == "textlist":
        parts = str(text).split("\n") if "\n" in str(text) else str(text).split("|")
        return [p.strip() for p in parts if p.strip()]
    if t == "link":
        return res.find(text, f.targets) if links and res else None
    if t == "links":
        if not links or res is None:
            return None
        return [i for i in (res.find(p, f.targets) for p in _split(text)) if i]
    if t == "table":
        return _parse_table(world, f, str(text), res, links)
    if t == "statvalues":
        return _parse_stats(world, str(text))
    if t == "loadout":
        if not links or res is None:
            return None
        out = {}
        for part in _split(text, r"[;\n]"):
            slot, _eq, item = part.partition("=")
            iid = res.find(item.strip(), ["item"])
            if iid:
                out[slot.strip()] = iid
        return out
    if t == "appearance":
        try:
            return json.loads(str(text))
        except ValueError:
            return None
    if t == "point":
        nums = re.findall(r"-?\d+(?:\.\d+)?", str(text))
        return {"x": float(nums[0]), "y": float(nums[1] if len(nums) > 1 else 0)} if nums else None
    return str(text)


def _parse_table(world, f: FieldDef, text: str, res, links: bool):
    if text.startswith("["):
        try:
            rows = json.loads(text)
        except ValueError:
            rows = []
        out = []
        for r in rows if isinstance(rows, list) else []:
            if isinstance(r, dict):
                out.append({c.key: (parse_cell(world, c, r.get(c.key), res, links)
                                    if c.type in ("link", "links") else r.get(c.key)) for c in f.columns})
        return out
    out = []
    for chunk in [c for c in re.split(r"[;\n]", text) if c.strip()]:
        row = {}
        if "=" in chunk and not chunk.strip().startswith("="):
            for part in re.split(r",(?=[^,=]*=)", chunk):
                k, _eq, v = part.partition("=")
                col = next((c for c in f.columns if _norm(c.key) == _norm(k) or _norm(c.label) == _norm(k)), None)
                if col is not None:
                    row[col.key] = v.strip()
        else:
            for col, v in zip(f.columns, chunk.split("|")):
                row[col.key] = v.strip()
        parsed = {}
        for col in f.columns:
            v = row.get(col.key)
            if col.type in ("link", "links") and not links:
                parsed[col.key] = None
            else:
                parsed[col.key] = parse_cell(world, col, v, res, links) if v not in (None, "") else None
        out.append(parsed)
    return out


def _parse_stats(world, text: str) -> dict:
    keys = [s.fields.get("key") for s in world.entities.stats()
            if s.fields.get("key") and (s.fields.get("group") or "Abilities") == "Abilities"]
    nums = re.findall(r"-?\d+", text)
    words = re.findall(r"([A-Za-z_]+)\s*[:=]?\s*(-?\d+)", text)
    if words:
        out = {}
        for w, n in words:
            k = w.lower()[:3] if w.lower()[:3] in keys else w.lower()
            out[k] = int(n)
        return out
    return {k: int(n) for k, n in zip(keys, nums)}


# ======================================================================
# Planning and applying
# ======================================================================
def plan(world, type_name: str, rows: list[dict], mode: str = "update") -> dict:
    """{"type", "rows": [{"name", "action", "values", "problems"}], "unknown": [headers], "mapping"}.
    mode: update (fill in existing entities with the same name), skip, or copy."""
    headers = list(rows[0].keys()) if rows else []
    mapping, unknown = column_map(world, type_name, headers)
    out = []
    seen = set()
    for i, r in enumerate(rows, start=2):
        name = str(next((r[h] for h, k in mapping.items() if k == "name"), "") or "").strip()
        if not name:
            if any(str(v or "").strip() for v in r.values()):
                out.append({"name": f"(row {i})", "action": "bad", "values": {}, "problems": ["no name"]})
            continue
        existing = world.entities.find_by_name(type_name, name)
        action = "create" if existing is None else {"update": "update", "skip": "skip", "copy": "copy"}[mode]
        if name.lower() in seen:
            action = "bad"
        seen.add(name.lower())
        out.append({"name": name, "action": action, "raw": {mapping[h]: r[h] for h in mapping if h in r},
                    "existing": existing.id if existing is not None else "", "problems": [] if action != "bad"
                    else ["the same name appears twice"], "row": i})
    return {"type": type_name, "rows": out, "unknown": unknown, "mapping": mapping}


def apply(world, the_plan: dict) -> dict:
    """Create / update the planned rows. Returns {"created", "updated", "skipped", "problems"}."""
    store = world.entities
    t = the_plan["type"]
    template = world.templates.get(t)
    fields = {f.key: f for f in template.fields()}
    report = {"created": 0, "updated": 0, "skipped": 0, "problems": []}
    pending: dict[tuple[str, str], str] = {}
    made = []
    # pass 1: everything but links
    for row in the_plan["rows"]:
        if row["action"] == "skip":
            report["skipped"] += 1
            continue
        if row["action"] == "bad":
            report["problems"].append(f"{row['name']}: {', '.join(row['problems'])}")
            continue
        raw = row["raw"]
        values = {}
        for key, cell in raw.items():
            if key in ("name", "description", "tags") or key not in fields:
                continue
            try:
                v = parse_cell(world, fields[key], cell, None, links=False)
            except (ValueError, TypeError):
                report["problems"].append(f"{row['name']}: {fields[key].label} '{cell}' can't be read")
                continue
            if v is not None and fields[key].type not in ("link", "links", "loadout"):
                values[key] = v
        desc = str(raw.get("description") or "")
        tags = _split(raw.get("tags") or "")
        if row["action"] == "update":
            e = store.get(row["existing"])
            merged = {**e.fields, **values}
            cleaned, custom, problems = store.clean(t, e.name, merged, desc or e.description, tags or e.tags,
                                                    e.custom, current_id=e.id)
            e.fields = cleaned
            if desc:
                e.description = desc
            if tags:
                e.tags = tags
            report["updated"] += 1
        else:
            name = row["name"]
            if row["action"] == "copy":
                n = 2
                while store.find_by_name(t, f"{name} ({n})"):
                    n += 1
                name = f"{name} ({n})"
            cleaned, custom, problems = store.clean(t, name, values, desc, tags, [])
            from game.entities import Entity, _now
            e = Entity(store._new_id(t, name), t, name, desc, tags, cleaned, [], _now(), _now())
            store.put(e)
            report["created"] += 1
        problems = [p for p in problems if "required" not in p or "Name" in p]
        report["problems"] += [f"{row['name']}: {p}" for p in problems]
        pending[(t, row["name"].lower())] = e.id
        made.append((row, e))
    # pass 2: links (they may point at rows created above)
    res = Resolver(world, pending)
    for row, e in made:
        for key, cell in row["raw"].items():
            f = fields.get(key)
            if f is None:
                continue
            if f.type in ("link", "links", "loadout") or (f.type == "table" and any(
                    c.type in ("link", "links") for c in f.columns)):
                res.missing = []
                try:
                    v = parse_cell(world, f, cell, res, links=True)
                except (ValueError, TypeError):
                    v = None
                if v is not None:
                    e.fields[key] = f.coerce(v)
                for m in res.missing:
                    report["problems"].append(f"{e.name}: {f.label}: nothing called '{m}'")
    store.touch(t)
    store.save(t)
    return report


def import_file(world, path, type_name: str = "", mode: str = "update") -> dict:
    """Import every sheet of a file (CSV: one sheet). Returns a combined report."""
    sheets = read_file(path)
    total = {"created": 0, "updated": 0, "skipped": 0, "problems": [], "sheets": []}
    for sheet, rows in sheets.items():
        t = type_name or guess_type(world, sheet)
        if not t:
            total["problems"].append(f"Sheet '{sheet}': which type is it? Name the sheet after a type (Spells, Items...).")
            continue
        p = plan(world, t, rows, mode)
        r = apply(world, p)
        for k in ("created", "updated", "skipped"):
            total[k] += r[k]
        total["problems"] += r["problems"]
        if p["unknown"]:
            total["problems"].append(f"Sheet '{sheet}': columns not used: {', '.join(p['unknown'])}")
        total["sheets"].append((sheet, t, len(rows)))
    return total


# ======================================================================
# Exporting
# ======================================================================
def cell_text(world, f: FieldDef, value) -> str:
    """The reverse of parse_cell: a value as spreadsheet text."""
    def name(i):
        e = world.entities.get(i)
        return e.name if e is not None else str(i)
    if value in (None, "", [], {}):
        return ""
    t = f.type
    if t == "bool":
        return "yes" if value else "no"
    if t in ("multichoice",):
        return ", ".join(str(v) for v in value)
    if t == "textlist":
        return " | ".join(str(v) for v in value)
    if t == "link":
        return name(value)
    if t == "links":
        return ", ".join(name(i) for i in value)
    if t == "table":
        rows = []
        for r in value:
            rows.append(" | ".join(cell_text(world, c, r.get(c.key)) for c in f.columns))
        return " ; ".join(rows)
    if t == "statvalues":
        return ", ".join(f"{k} {v}" for k, v in value.items())
    if t == "loadout":
        return "; ".join(f"{k}={name(v)}" for k, v in value.items())
    if t == "appearance":
        return json.dumps(value)
    if t == "point":
        return f"{value.get('x', 0)}, {value.get('y', 0)}"
    return str(value)


def headers_for(world, type_name: str) -> list[FieldDef]:
    template = world.templates.get(type_name)
    return [f for f in template.fields() if f.type not in ("sprite",)]


def write_csv(world, type_name: str, path, entities=None) -> int:
    """Write a type's entities (or a blank sheet when entities == []) as CSV. Returns rows written."""
    fields = [f for f in headers_for(world, type_name) if f.key not in ("name", "description", "tags")]
    ents = world.entities.all(type_name) if entities is None else list(entities)
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["name", "description", "tags"] + [f.key for f in fields])
        for e in ents:
            w.writerow([e.name, e.description, ", ".join(e.tags)] +
                       [cell_text(world, f, e.fields.get(f.key)) for f in fields])
    return len(ents)


def write_guide(world, type_name: str) -> str:
    """A short description of every column for a type (shown in the import window)."""
    lines = [f"Columns for {world.templates.get(type_name).plural}:", "  name (required), description, tags"]
    for f in headers_for(world, type_name):
        if f.key in ("name", "description", "tags"):
            continue
        what = f.type
        if f.type == "choice" and f.options:
            what = "one of: " + ", ".join(str(o) for o in f.options[:12]) + ("..." if len(f.options) > 12 else "")
        elif f.type in ("link", "links"):
            what = f"{'names' if f.type == 'links' else 'a name'} of {', '.join(f.targets) or 'anything'}"
        elif f.type == "table":
            what = "rows ; separated, columns | separated: " + " | ".join(c.key for c in f.columns)
        lines.append(f"  {f.key}  ({f.label}): {what}")
    return "\n".join(lines)
