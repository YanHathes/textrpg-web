"""Fire (Hotfix 23): things that burn, set alight by the party (a torch, a tinderbox, a fire cantrip, alchemist's
fire) or by fire in a fight, spreading to what's beside them and burning out.

What burns (fuel_of): trees, bushes, crops and hay, grass, timber walls and doors, wooden floors, furniture and
the like. Not stone, iron, water, bare earth or cobbles, nor snow-covered ground. Fires that are kept where they
belong (a campfire, a hearth, a brazier, a stove, a forge, a lamp: CONTAINED) never spread.

How it runs
    While the party can see any of it, it burns minute by minute (tick): each square burns for a while
    (FUEL: minutes) and each minute may catch the squares round it (FUEL: chance a minute; rain and snow
    damp it, a hot summer feeds it). When the party can't see it any more (walked off, or left the map), the
    rest is settled at once (resolve): what would burn, burns, out to RESOLVE_REACH squares from where the
    party stood when it lost sight of it; past that, it's safe. What's burned is kept in the save (as land
    changes, game/landchanges.py) for the party to find when it comes back.
Putting it out
    In a town the townsfolk form bucket lines from the nearest well or water, and any cleric among them casts
    Create or Destroy Water over the flames (DOUSE: a 30-foot cube). The party can do the same: cast the
    spell to douse the flames or to fill its buckets, throw water from a bucket, or beat at a small fire.
After
    A burned tree stands black in the ash; a burned wall or door is gone (game/destruction.py: the building
    may come down); burned furniture is ash and splinters. In the wilds the burned ground comes back thicker
    than it was: ash for ASH_DAYS, then a crowd of young trees (on the trees' squares and DENSE of the rest)
    for SAPLING_DAYS, then a young, dense forest. In town, ash is swept up after a while.
Crime
    Setting fire to what isn't yours in a town is arson (law.py), and so is a fire of yours spreading to a
    building that isn't yours.

Kept in the save, state.destruction["fires"]: {area key: {"last": minute, "cells": {"<level key>|x,y": {"at",
"fuel", "what", "party"}}, "town": town id, "arson": bool, "buckets": n}}.
"""
from __future__ import annotations

from game import destruction as D

CONTAINED = {"campfire", "brazier", "stove", "forge", "lamp", "fireplace", "hearth", "candle"}
# what -> (minutes it burns, chance a minute of catching each square beside it)
FUEL = {"tree": (40, 0.10), "big_tree": (60, 0.10), "pine": (35, 0.14), "bush": (8, 0.2), "berry_bush": (8, 0.2),
        "haybale": (10, 0.3), "crops": (5, 0.25), "rug": (6, 0.12), "fallen_trunk": (40, 0.05),
        "branches": (8, 0.2), "stump": (30, 0.02), "log": (40, 0.05), "sapling": (6, 0.2), "fence": (15, 0.1),
        "prop": (15, 0.08), "wall": (60, 0.06), "door": (20, 0.08), "grass": (3, 0.12), "wood": (20, 0.05),
        "carpet": (6, 0.1)}
FLOORS = {"grass", "wood", "carpet"}
WIDE = 0.5                         # catching aslant (diagonally): half as likely
RESOLVE_REACH = 50                 # squares from the party past which an unseen fire is safe
SIM_MAX = 60                       # minutes worked through one by one at most (the rest settled at once)
ASH_DAYS, SAPLING_DAYS, TOWN_ASH_DAYS = 12, 40, 6
DENSE = 0.45                       # of the burned open ground that comes back as young trees
DOUSE = 3                          # squares each way from the middle: Create or Destroy Water's 30-foot cube
SPELL = "spell.create-or-destroy-water"
CLERIC_CASTS = 2                   # a day, each cleric
BUCKET_LINE = 8                    # townsfolk in a bucket line, at most
BUCKET_PUT_OUT = 0.06              # a minute, each bucket hand, on a square they can reach
TOWN_RESOLVE = 0.35                # in town, with the bucket lines going: how much less likely it spreads
BURN_DAMAGE = "1d6"                # walking into it
SOURCES = ("Tinderbox", "Torch", "Alchemist's Fire", "Flask of Oil", "Oil (flask)", "Lantern")


def _fires(state) -> dict:
    return D.data(state).setdefault("fires", {})


def _rec(ex, make: bool = False) -> dict | None:
    if ex.area is None:
        return None
    f = _fires(ex.state)
    if make and ex.area.key not in f:
        from game import places
        town = places.current(ex.world, ex.state).town
        f[ex.area.key] = {"last": ex.state.minutes, "cells": {}, "town": town.id if town is not None else "",
                          "arson": False, "buckets": 0}
    return f.get(ex.area.key)


def _parse(k: str) -> tuple[str, int, int]:
    lk, xy = k.rsplit("|", 1)
    x, y = (int(v) for v in xy.split(","))
    return lk, x, y


def burning(ex) -> list[tuple[int, int, int]]:
    """[(x, y, size)] of the squares burning on this map (size 1 smouldering .. 3 roaring)."""
    r = _rec(ex)
    if not r:
        return []
    out = []
    now = ex.state.minutes
    for k, f in r["cells"].items():
        _lk, x, y = _parse(k)
        frac = (now - int(f["at"])) / max(1, int(f["fuel"]))
        out.append((x, y, 1 if frac > 0.8 else 3 if f["fuel"] >= 30 and frac < 0.6 else 2))
    return out


def burning_at(ex, x: int, y: int) -> bool:
    r = _rec(ex)
    if not r or not r["cells"]:
        return False
    return D.sq_key(ex.layer(x, y), x, y) in r["cells"]


# ----------------------------------------------------------------------------------------------------
# What burns
# ----------------------------------------------------------------------------------------------------
def fuel_of(ex, lv, x: int, y: int, snow: bool = False):
    """(what, minutes, chance a minute) if the square would burn, else None."""
    c = (x, y)
    if not lv.inside(x, y) or c in lv.water:
        return None
    if c in lv.walls:
        if lv.walls[c] == "wood_wall" and D.wall_breakable(lv, x, y):
            return ("wall",) + FUEL["wall"]
        return None
    d = lv.doors.get(c)
    if d is not None:
        wall = d.get("wall") or ""
        return ("door",) + FUEL["door"] if "wood" in wall or not wall else None
    p = lv.prop_cells.get(c)
    if p is not None:
        if p.id in CONTAINED:
            return None
        t = D.TOUGH.get(p.id)
        if t is not None and t[3]:
            return (p.id,) + FUEL.get(p.id, FUEL["prop"])
    f = lv.floor_at(x, y)
    if f in FLOORS and not (snow and f == "grass"):
        return (f,) + FUEL[f]
    return None


def source(world, state, members) -> tuple[str, str] | None:
    """Something to light a fire with: (kind, words), or None."""
    from game import condition
    for iid, n in (state.inventory or {}).items():
        e = world.entities.get(iid)
        if n > 0 and e is not None and e.name in SOURCES:
            return "item", e.name.lower()
    for m in members:
        if m.get("dead"):
            continue
        for iid, n in (m.get("inventory") or {}).items():
            e = world.entities.get(iid)
            if n > 0 and e is not None and e.name in SOURCES:
                return "item", f"{m.get('name')}'s {e.name.lower()}"
    for m in members:
        if m.get("dead"):
            continue
        try:
            c = condition.combatant(world, m)
        except Exception:  # noqa: BLE001 - no spells to speak of
            continue
        for s in c.spells:
            if s.level == 0 and (getattr(s, "damage_type", "") or "").lower() == "fire":
                return "spell", f"{m.get('name')}'s {s.name}"
    return None


# ----------------------------------------------------------------------------------------------------
# Lighting
# ----------------------------------------------------------------------------------------------------
def ignite(ex, lv, x: int, y: int, party: bool = False, at: int | None = None) -> bool:
    """Set a square alight (if it'll burn). Returns whether it caught."""
    try:
        w = ex.weather()
        snow = getattr(w, "ground", "") == "snow"
    except Exception:  # noqa: BLE001 - fair weather
        snow = False
    got = fuel_of(ex, lv, x, y, snow)
    if got is None:
        return False
    r = _rec(ex, make=True)
    k = D.sq_key(lv, x, y)
    if k in r["cells"]:
        return False
    what, minutes, _p = got
    r["cells"][k] = {"at": ex.state.minutes if at is None else at, "fuel": minutes, "what": what,
                     "party": bool(party)}
    return True


def light(ex, x: int, y: int) -> dict:
    """The party sets the thing at (x, y) alight."""
    src = source(ex.world, ex.state, ex.members())
    if src is None:
        return {"lines": ["You've nothing to light it with."]}
    lv = ex.layer(x, y)
    if not ignite(ex, lv, x, y, party=True):
        return {"lines": ["It won't catch."]}
    t = D.thing_at(ex, x, y)
    what = t["label"].lower() if t is not None else "it"
    lines = [f"You put {src[1]} to the {what}. It catches, and the flames climb."]
    ex.state.advance(1, "lighting a fire")
    _arson(ex, x, y, t)
    ex.state.save()
    D._redraw(ex)
    return {"lines": lines, "minutes": 1}


def _arson(ex, x: int, y: int, t) -> None:
    r = _rec(ex)
    if r is None or r.get("arson"):
        return
    if t is not None and not D._crime_here(ex, t):
        return
    if t is None:
        from game import places
        if places.current(ex.world, ex.state).town is None:
            return
    from game import law, places
    town = places.current(ex.world, ex.state).town
    if town is None:
        return
    r["arson"] = True
    seen = law.witnesses(ex.world, ex.state, ex.members(), ex, ex.rng, bus=ex.bus)
    law.commit(ex.world, ex.state, "arson", town, seen, 0, "", ex.bus)


# ----------------------------------------------------------------------------------------------------
# Burning
# ----------------------------------------------------------------------------------------------------
def _weather(ex) -> tuple[float, bool]:
    """(how much more or less it spreads, whether the ground is snowy)."""
    try:
        w = ex.weather()
    except Exception:  # noqa: BLE001 - fair weather
        return 1.0, False
    if w is None:
        return 1.0, False
    k = 1.0
    if getattr(w, "wet", False):
        k *= 0.25
    if getattr(w, "ground", "") == "snow":
        k *= 0.1
    elif getattr(w, "ground", "") in ("wet", "puddles"):
        k *= 0.6
    if getattr(w, "season", "") == "Summer" and int(getattr(w, "temperature", 60) or 60) >= 80:
        k *= 1.3
    return k, getattr(w, "ground", "") == "snow"


NEAR = [(-1, 0, 1.0), (1, 0, 1.0), (0, -1, 1.0), (0, 1, 1.0), (-1, -1, WIDE), (1, -1, WIDE), (-1, 1, WIDE),
        (1, 1, WIDE)]


def update(ex) -> list[str]:
    """Catch the fires on this map up with the clock: minute by minute while they're in sight, all at once
    when they're not. Returns lines worth telling."""
    r = _rec(ex)
    if not r:
        return []
    if not r["cells"]:
        _fires(ex.state).pop(ex.area.key, None)
        return []
    now = ex.state.minutes
    n = now - int(r.get("last", now))
    if n <= 0:
        return []
    vis = getattr(ex, "visible", None) or set()
    seen = any((x, y) in vis for _lk, x, y in (_parse(k) for k in r["cells"]))
    lines = []
    if not seen:
        lines += resolve(ex)
        return lines
    steps = min(n, SIM_MAX)
    start = now - n
    for i in range(steps):
        lines += tick(ex, start + i + 1)
        if not r["cells"]:
            break
    r["last"] = now
    if r["cells"] and n > SIM_MAX:
        lines += resolve(ex)
    if not r["cells"]:
        _fires(ex.state).pop(ex.area.key, None)
        lines.append("The fire is out.")
    ex.state.save()
    D._redraw(ex)
    return lines


def tick(ex, minute: int) -> list[str]:
    """One minute of the fire, in sight."""
    r = _rec(ex)
    rng = ex.rng
    k, snow = _weather(ex)
    lines = []
    cells = r["cells"]
    for key in list(cells):
        f = cells.get(key)
        if f is None:
            continue
        lk, x, y = _parse(key)
        lv = ex.layer(x, y)
        if minute - int(f["at"]) >= int(f["fuel"]):
            del cells[key]
            lines += burn_out(ex, lv, x, y, f)
            continue
        if k < 0.3 and rng.random() < 0.04:            # the rain puts it out
            del cells[key]
            continue
        p = FUEL.get(f["what"], FUEL["prop"])[1] * k
        for dx, dy, w in NEAR:
            nx, ny = x + dx, y + dy
            if rng.random() < p * w:
                l2 = ex.layer(nx, ny)
                if ignite(ex, l2, nx, ny, party=f.get("party", False), at=minute):
                    _spread_crime(ex, l2, nx, ny, f)
    if r.get("town") and cells:
        lines += _townsfolk(ex, r, minute)
    return lines


def _spread_crime(ex, lv, x: int, y: int, f: dict) -> None:
    """The party's fire reaching a building that isn't theirs: arson."""
    if not f.get("party"):
        return
    bid = D.building_at(ex, x, y)
    if not bid:
        return
    b = ex.world.entities.get(bid)
    if b is not None and not b.fields.get("owner"):
        _arson(ex, x, y, None)


def burn_out(ex, lv, x: int, y: int, f: dict, save: bool = True) -> list[str]:
    """A square's burned out: what's left of it."""
    st = ex.state
    what = f.get("what") or ""
    rng = ex.rng
    town = bool((_rec(ex) or {}).get("town"))
    now = st.minutes
    if what == "wall":
        t = D.thing_at(ex, x, y)
        if t is not None:
            return D.destroy(ex, t, rng=rng)
        return []
    if what == "door":
        ex.set_door(lv.key, (x, y), "broken")
        return []
    if what in D.TRUNK:                                  # a tree: black in the ash, then young growth
        if town:
            D._record(ex, lv, x, y, {"prop": "burnt_tree", "variant": rng.randrange(3), "floor": "ash",
                                     "until": now + TOWN_ASH_DAYS * 1440 * 3}, save=save)
        else:
            D._record(ex, lv, x, y, _regrowth(now, "burnt_tree", "tree", rng), merge=False, save=save)
        return []
    if what in FLOORS or what in ("bush", "berry_bush", "sapling", "crops", "haybale", "branches", "rug"):
        ground = lv.floor_at(x, y)
        if town or ground not in ("grass",):
            D._record(ex, lv, x, y, {"prop": "", "floor": "ash" if ground in ("grass", "wood", "carpet") else "",
                                     "until": now + TOWN_ASH_DAYS * 1440}, save=save)
        else:
            young = rng.random() < DENSE or what in ("bush", "berry_bush", "sapling")
            D._record(ex, lv, x, y, _regrowth(now, "", "tree" if young else "", rng), merge=False, save=save)
        return []
    D._record(ex, lv, x, y, {"prop": "debris" if what not in ("fallen_trunk", "stump", "log") else "",
                             "variant": rng.randrange(3), "floor": "ash" if lv.floor_at(x, y) in FLOORS else "",
                             "until": now + TOWN_ASH_DAYS * 1440 * 2}, save=save)
    return []


def _regrowth(now: int, standing: str, then: str, rng) -> dict:
    """Ash (with a burnt tree standing, maybe), then saplings, then trees: thicker than before."""
    ash = now + ASH_DAYS * 1440
    grown = ash + SAPLING_DAYS * 1440
    later = {"prop": then, "variant": rng.randrange(6)} if then else None
    young = {"prop": "sapling", "variant": rng.randrange(3), "until": grown, "then": later} if then else None
    chg = {"prop": standing, "variant": rng.randrange(3), "floor": "ash", "until": ash}
    if young is not None:
        if later is None:
            young.pop("then")
        chg["then"] = young
    return chg


def resolve(ex) -> list[str]:
    """The fire out of sight: settled at once. What would burn, burns, out to RESOLVE_REACH squares from
    where the party stands; in a town, the bucket lines hold it back."""
    r = _rec(ex)
    if not r or not r["cells"]:
        _fires(ex.state).pop(ex.area.key, None) if ex.area is not None else None
        return []
    rng = ex.rng
    k, snow = _weather(ex)
    town = bool(r.get("town"))
    if town:
        k *= TOWN_RESOLVE
    px, py = ex.x, ex.y
    queue = []
    for key, f in r["cells"].items():
        _lk, x, y = _parse(key)
        queue.append((x, y, f))
    done = set((x, y) for x, y, _f in queue)
    burned = 0
    i = 0
    cap = 4000 if not town else 600
    while i < len(queue) and burned < cap:
        x, y, f = queue[i]
        i += 1
        lv = ex.layer(x, y)
        got = FUEL.get(f.get("what") or "", FUEL["prop"])
        left = max(1, int(f["fuel"]) - max(0, ex.state.minutes - int(f["at"])))
        for dx, dy, w in NEAR:
            nx, ny = x + dx, y + dy
            if (nx, ny) in done or max(abs(nx - px), abs(ny - py)) > RESOLVE_REACH:
                continue
            p = 1 - (1 - min(0.95, got[1] * k * w)) ** left
            if rng.random() >= p:
                continue
            l2 = ex.layer(nx, ny)
            fu = fuel_of(ex, l2, nx, ny, snow)
            if fu is None:
                continue
            done.add((nx, ny))
            nf = {"at": 0, "fuel": fu[1], "what": fu[0], "party": f.get("party", False)}
            _spread_crime(ex, l2, nx, ny, nf)
            queue.append((nx, ny, nf))
        burn_out(ex, lv, x, y, f, save=False)
        burned += 1
    _fires(ex.state).pop(ex.area.key, None)
    ex.state.save()
    D._redraw(ex)
    if burned > 30:
        return [f"Behind you, the fire burns itself out: about {burned} squares of it."]
    return []


def leave(ex) -> None:
    """The party's leaving this map: whatever's burning on it is settled now."""
    if _rec(ex):
        resolve(ex)


# ----------------------------------------------------------------------------------------------------
# Putting it out
# ----------------------------------------------------------------------------------------------------
def put_out(ex, x: int, y: int, reach: int = 0) -> int:
    """Put out the fire at (x, y) (and `reach` squares round it). Returns how many squares went out."""
    r = _rec(ex)
    if not r:
        return 0
    n = 0
    for dy in range(-reach, reach + 1):
        for dx in range(-reach, reach + 1):
            k = D.sq_key(ex.layer(x + dx, y + dy), x + dx, y + dy)
            if r["cells"].pop(k, None) is not None:
                n += 1
    if not r["cells"]:
        _fires(ex.state).pop(ex.area.key, None)
    return n


def _knows(world, state, m: dict):
    """(Combatant, slot level) if this member can cast Create or Destroy Water now, else None."""
    from game import condition, jail
    if m.get("dead") or jail.antimagic(world, state):
        return None
    c = condition.combatant(world, m)
    condition.apply(state, m, c)
    s = next((s for s in c.spells if s.id == SPELL), None)
    if s is None:
        return None
    mana = (world.rules.get("magic_system") or "Mana") == "Mana" and c.mana_max
    per = int(world.rules.get("mana_per_spell_level", 10) or 10)
    if mana:
        return (c, 1) if c.mana >= per else None
    lv = min((lvl for lvl, n in c.slots.items() if lvl >= 1 and n > 0), default=None)
    return (c, lv) if lv is not None else None


def _spend(world, state, m: dict, c, level: int) -> None:
    from game import condition
    if (world.rules.get("magic_system") or "Mana") == "Mana" and c.mana_max:
        c.mana -= int(world.rules.get("mana_per_spell_level", 10) or 10) * level
    else:
        c.slots[level] = max(0, c.slots.get(level, 0) - 1)
    condition.store(state, m, c, save=False)


def caster(ex):
    for m in ex.members():
        got = _knows(ex.world, ex.state, m)
        if got is not None:
            return m, got[0], got[1]
    return None


def buckets(ex) -> int:
    """Buckets the party carries."""
    n = sum(int(v) for iid, v in (ex.state.inventory or {}).items() if _is_bucket(ex.world, iid))
    for m in ex.members():
        n += sum(int(v) for iid, v in (m.get("inventory") or {}).items() if _is_bucket(ex.world, iid))
    return n


def _is_bucket(world, iid: str) -> bool:
    e = world.entities.get(iid)
    return e is not None and "bucket" in e.name.lower()


def water_near(ex, x: int, y: int, reach: int = 25):
    """The nearest well, fountain or open water to (x, y), or None."""
    best = None
    for r in range(reach + 1):
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if max(abs(dx), abs(dy)) != r:
                    continue
                c = (x + dx, y + dy)
                lv = ex.layer(*c)
                p = lv.prop_cells.get(c)
                if c in lv.water or (p is not None and p.id in ("well", "fountain")):
                    best = c
                    return best
    return best


def prompt(ex, x: int, y: int):
    from game.explore import Prompt
    full = int((_rec(ex) or {}).get("buckets", 0))
    have = buckets(ex)
    cast = caster(ex)
    opts = []
    if cast is not None:
        m, _c, lvl = cast
        opts.append((f"Douse the flames: {m.get('name')} casts Create or Destroy Water (level {lvl})",
                     ("douse", x, y, "spell"), True))
        if have and full < have:
            opts.append((f"Fill your {have} bucket{'s' if have != 1 else ''} with Create or Destroy Water",
                         ("douse", x, y, "fill-spell"), True))
    if full:
        opts.append((f"Throw a bucket of water ({full} full)", ("douse", x, y, "bucket"), True))
    elif have and water_near(ex, x, y) is not None:
        opts.append(("Fill your buckets at the water and come back (2 minutes)", ("douse", x, y, "fill-water"),
                     True))
    fu = fuel_of(ex, ex.layer(x, y), x, y)
    small = fu is not None and fu[1] <= 15
    opts.append(("Beat at the flames" + ("" if small else " (it's too big for that)"), ("douse", x, y, "beat"),
                 small))
    opts.append(("Leave it", ("none",), True))
    town = (_rec(ex) or {}).get("town")
    text = "Flames, crackling and spreading." + (" Townsfolk are running for buckets." if town else "")
    return Prompt("Fire!", text, opts)


def douse(ex, x: int, y: int, how: str) -> dict:
    """The party fights the fire at (x, y)."""
    from game import checks, condition
    st = ex.state
    r = _rec(ex)
    if not r:
        return {"lines": ["There's no fire there now."]}
    lines = []
    if how in ("spell", "fill-spell"):
        cast = caster(ex)
        if cast is None:
            return {"lines": ["Nobody can cast that now."]}
        m, c, lvl = cast
        _spend(ex.world, st, m, c, lvl)
        if how == "spell":
            n = put_out(ex, x, y, DOUSE)
            lines.append(f"{m.get('name')} casts Create or Destroy Water: rain hisses down over the flames, and "
                         f"{n} square{'s' if n != 1 else ''} of fire go{'es' if n == 1 else ''} out.")
        else:
            r["buckets"] = buckets(ex)
            lines.append(f"{m.get('name')} casts Create or Destroy Water and fills every bucket to the brim.")
            try:
                from game import survival
                if ex.world.rules.get("survival"):
                    survival.refill(ex.world, st, ex.members(), True, None)
                    lines.append("And the waterskins too.")
            except Exception:  # noqa: BLE001 - buckets are enough
                pass
        st.advance(1, "casting")
    elif how == "bucket":
        r["buckets"] = max(0, int(r.get("buckets", 0)) - 1)
        n = put_out(ex, x, y, 0)
        lines.append("You throw the water: the flames hiss and die there." if n else "The water hisses on the ash.")
        st.advance(0, "")
    elif how == "fill-water":
        r["buckets"] = buckets(ex)
        st.advance(2, "fetching water")
        lines.append(f"You run for water and come back with {r['buckets']} full bucket"
                     f"{'s' if r['buckets'] != 1 else ''}.")
    elif how == "beat":
        best = None
        for m in ex.members():
            if m.get("dead"):
                continue
            c = condition.combatant(ex.world, m)
            if best is None or c.mod("str") > best[1].mod("str"):
                best = (m, c)
        if best is None:
            return {"lines": []}
        m, c = best
        opt = next((o for o in checks.options(ex.world) if o["label"] == "Athletics"), None)
        got = checks.roll(ex.world, m, c, opt, 12, rng=ex.rng, bus=ex.bus) if opt else {"success": True}
        st.advance(1, "fighting a fire")
        if got.get("success"):
            put_out(ex, x, y, 0)
            lines.append(f"{m.get('name')} beats the flames out with a cloak.")
        else:
            lines.append(f"{m.get('name')} beats at the flames, but they won't die.")
    st.save()
    D._redraw(ex)
    out = {"lines": lines, "minutes": 1}
    if burning_at(ex, x, y):
        out["prompt"] = prompt(ex, x, y)
    return out


# ----------------------------------------------------------------------------------------------------
# The townsfolk
# ----------------------------------------------------------------------------------------------------
def _clerics(ex, toks) -> list:
    out = []
    for t in toks:
        if t.kind != "npc":
            continue
        n = ex.world.entities.get(t.entity)
        if n is None:
            continue
        cls = str(n.fields.get("class") or "").lower()
        occ = str(n.fields.get("occupation") or "")
        if "cleric" in cls or occ in ("Priest", "Acolyte"):
            out.append((t, n))
    return out


def _townsfolk(ex, r: dict, minute: int) -> list[str]:
    """A minute of the town fighting the fire: a bucket line from the nearest water to the nearest flames, and
    any cleric about casting Create or Destroy Water."""
    lines = []
    rng = ex.rng
    cells = [(x, y) for _lk, x, y in (_parse(k) for k in r["cells"])]
    if not cells:
        return lines
    folk = [t for t in ex.tokens if t.kind in ("npc", "crowd") and t.level == ex.level and not t.id.startswith(
        "homeless:") and min(max(abs(t.x - x), abs(t.y - y)) for x, y in cells) <= 25]
    # the clerics first
    used = D.data(ex.state).setdefault("cleric_casts", {})
    for t, n in _clerics(ex, folk):
        k = f"{n.id}|{ex.state.day}"
        if used.get(k, 0) >= CLERIC_CASTS or rng.random() > 0.25:
            continue
        used[k] = used.get(k, 0) + 1
        cx, cy = min(cells, key=lambda c: abs(c[0] - t.x) + abs(c[1] - t.y))
        got = put_out(ex, cx, cy, DOUSE)
        if got:
            lines.append(f"{n.name} casts Create or Destroy Water: a cloudburst drowns {got} square"
                         f"{'s' if got != 1 else ''} of the fire.")
            cells = [(x, y) for _lk, x, y in (_parse(k) for k in r["cells"])]
            if not cells:
                return lines
    # the bucket line
    hands = [t for t in folk if t.kind == "crowd" or not any(t is c for c, _n in _clerics(ex, [t]))][:BUCKET_LINE]
    if not hands:
        return lines
    target = min(cells, key=lambda c: min(abs(c[0] - h.x) + abs(c[1] - h.y) for h in hands))
    water = water_near(ex, target[0], target[1])
    _line_up(ex, hands, water or (hands[0].x, hands[0].y), target)
    if water is None and not any(c for c, _n in _clerics(ex, folk)):
        return lines
    for x, y in cells:
        near = sum(1 for h in hands if max(abs(h.x - x), abs(h.y - y)) <= 1)
        if near and rng.random() < 1 - (1 - BUCKET_PUT_OUT * len(hands) / 2) ** near:
            put_out(ex, x, y, 0)
    return lines


def _line_up(ex, hands: list, frm, to) -> None:
    """Stand the bucket line from the water to the fire, a hand every couple of squares."""
    n = len(hands)
    steps = max(abs(to[0] - frm[0]), abs(to[1] - frm[1]))
    taken = {(t.x, t.y) for t in ex.tokens if t not in hands} | {(ex.x, ex.y)}
    for i, t in enumerate(hands):
        f = 1 - (i / max(1, n - 1)) if n > 1 else 1.0
        gx = round(frm[0] + (to[0] - frm[0]) * f)
        gy = round(frm[1] + (to[1] - frm[1]) * f)
        if i == 0 and steps:                               # the head of the line stands beside the flames
            dx = (to[0] > frm[0]) - (to[0] < frm[0])
            dy = (to[1] > frm[1]) - (to[1] < frm[1])
            gx, gy = to[0] - dx, to[1] - dy
        spot = None
        for rr in range(4):
            for yy in range(gy - rr, gy + rr + 1):
                for xx in range(gx - rr, gx + rr + 1):
                    if spot is None and (xx, yy) not in taken and ex.walkable(xx, yy) and not burning_at(ex, xx, yy):
                        spot = (xx, yy)
        if spot is not None:
            taken.add(spot)
            t.x, t.y = spot
            t.wander = 0
            dx, dy = to[0] - spot[0], to[1] - spot[1]
            t.facing = ("E" if dx > 0 else "W") if abs(dx) >= abs(dy) else ("S" if dy > 0 else "N")


def scorched(ex, rng=None) -> list[str]:
    """The party walks into the flames: each takes a little fire damage."""
    from game import condition, dice
    rng = rng or ex.rng
    out = []
    for m in ex.members():
        if m.get("dead"):
            continue
        c = condition.combatant(ex.world, m)
        condition.apply(ex.state, m, c)
        dmg = dice.roll(BURN_DAMAGE, rng).total
        c.hp = max(1, c.hp - dmg)
        condition.store(ex.state, m, c, save=False)
        out.append(f"{c.name} is burned ({dmg} fire damage).")
    ex.state.save()
    return out


__all__ = ["update", "tick", "resolve", "leave", "light", "ignite", "douse", "prompt", "burning", "burning_at",
           "fuel_of", "source", "put_out", "scorched", "CONTAINED"]
