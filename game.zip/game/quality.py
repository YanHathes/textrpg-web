"""Item quality and damage: Poor, Standard, Fine, Masterwork, Legendary; and found damaged.

An item of some quality is the same item under its own id: "item.longsword@fine", or "item.longsword@poor!"
when it's also damaged ("item.longsword@standard!" for a damaged standard one). A plain id is Standard
and whole, so everything saved before quality existed loads as Standard. Inventories count each variant
on its own, so two longswords of different quality are told apart and each stacks with its own kind.

world.entities.get() hands back a variant as an item of its own (made on the spot, never saved): its name
says what it is, its value is scaled, and its fields carry what the quality does:

    Quality      Value   Tools: speed and yield   Weapons and armor
    Poor         x0.5    x0.75                    -1 to attack, or -1 AC
    Standard     x1      x1                       none
    Fine         x2      x1.25                    none
    Masterwork   x5      x1.5                     +1 to attack (not magical)
    Legendary    x10     x2                       +1 to attack and damage (not magical)

A damaged item counts as one quality lower until it's restored (a service at a smith, tailor or jeweler).
"""
from __future__ import annotations

import copy
import random

QUALITIES = ["Poor", "Standard", "Fine", "Masterwork", "Legendary"]
VALUE = {"Poor": 0.5, "Standard": 1.0, "Fine": 2.0, "Masterwork": 5.0, "Legendary": 10.0}
TOOL = {"Poor": 0.75, "Standard": 1.0, "Fine": 1.25, "Masterwork": 1.5, "Legendary": 2.0}
ATTACK = {"Poor": -1, "Standard": 0, "Fine": 0, "Masterwork": 1, "Legendary": 1}
DAMAGE = {"Legendary": 1}
AC = {"Poor": -1}
GEAR = {"Weapon", "Armor", "Shield", "Tool", "Ammunition", "Gear"}
RESTORE_SHARE = 0.25                     # restoring costs a quarter of the item's standard value
MENDERS = {"Blacksmith": {"Weapon", "Armor", "Shield", "Tool", "Ammunition", "Gear"},
           "Armorer": {"Armor", "Shield"}, "Weaponsmith": {"Weapon", "Ammunition"},
           "Tailor": {"Armor", "Gear", "Clothing"}, "Leatherworker": {"Armor", "Gear"},
           "Jeweler": {"Jewelry", "Ring", "Wondrous", "Gear"}, "Tinker": {"Tool", "Gear"}}


STOLEN = "~"                             # the stolen mark (game/law.py): "item.longsword@standard~"


def parse(item_id: str) -> tuple[str, str, bool]:
    """(base id, quality, damaged)."""
    if not item_id or "@" not in item_id:
        return item_id or "", "Standard", False
    base, _a, rest = item_id.partition("@")
    rest = rest.rstrip(STOLEN)
    damaged = rest.endswith("!")
    q = rest.rstrip("!").capitalize()
    return base, (q if q in QUALITIES else "Standard"), damaged


def variant(base_id: str, quality: str = "Standard", damaged: bool = False) -> str:
    base = parse(base_id)[0]
    q = quality if quality in QUALITIES else "Standard"
    if q == "Standard" and not damaged:
        return base
    return f"{base}@{q.lower()}" + ("!" if damaged else "")


def base_of(item_id: str) -> str:
    return parse(item_id)[0]


def is_stolen(item_id: str) -> bool:
    return bool(item_id) and "@" in item_id and item_id.endswith(STOLEN)


def stolen(item_id: str) -> str:
    """The same thing (its quality and damage kept), marked stolen."""
    if is_stolen(item_id):
        return item_id
    base, q, damaged = parse(item_id)
    return f"{base}@{q.lower()}" + ("!" if damaged else "") + STOLEN


def unmarked(item_id: str) -> str:
    """The same thing without the stolen mark."""
    if not is_stolen(item_id):
        return item_id
    base, q, damaged = parse(item_id)
    return variant(base, q, damaged)


def effective(quality: str, damaged: bool) -> str:
    """What a damaged item counts as: one quality lower (Poor stays Poor)."""
    i = QUALITIES.index(quality) if quality in QUALITIES else 1
    return QUALITIES[max(0, i - 1)] if damaged else QUALITIES[i]


def label(quality: str, damaged: bool) -> str:
    bits = []
    if quality != "Standard":
        bits.append(quality)
    return " ".join(bits)


def make(store, item_id: str):
    """The variant as an entity of its own (not stored): the base item with its name, value and fields set
    for its quality. None if the base doesn't exist."""
    base_id, q, damaged = parse(item_id)
    base = store.get(base_id)
    if base is None or base.type != "item":
        return None
    eff = effective(q, damaged)
    e = copy.copy(base)
    e.__dict__ = dict(base.__dict__)
    e.id = item_id
    e.fields = dict(base.fields)
    hot = is_stolen(item_id)
    e.tags = list(base.tags) + [f"quality: {q.lower()}"] + (["damaged"] if damaged else []) + \
        (["stolen"] if hot else [])
    e.name = (f"{q} " if q != "Standard" else "") + base.name + (" (damaged)" if damaged else "") + \
        (" (stolen)" if hot else "")
    f = e.fields
    f["quality"] = q
    f["damaged"] = damaged
    f["stolen"] = hot
    f["base_item"] = base_id
    try:
        f["value"] = round(float(base.fields.get("value") or 0) * VALUE[eff], 2)
    except (TypeError, ValueError):
        pass
    cat = base.fields.get("category") or ""
    if cat == "Weapon" or cat == "Ammunition":
        f["quality_attack"] = ATTACK.get(eff, 0)
        f["quality_damage"] = DAMAGE.get(eff, 0)
    if cat in ("Armor", "Shield"):
        f["quality_ac"] = AC.get(eff, 0)
    f["tool_speed"] = TOOL[eff]
    f["tool_yield"] = TOOL[eff]
    return e


def of(item) -> tuple[str, bool]:
    """(quality, damaged) of an item entity (Standard and whole for a plain one)."""
    if item is None:
        return "Standard", False
    return item.fields.get("quality") or "Standard", bool(item.fields.get("damaged"))


def can_vary(item) -> bool:
    """Gear can come in qualities; potions, food and the like can't."""
    return item is not None and (item.fields.get("category") or "") in GEAR and not item.fields.get("used_up")


def roll_found(world, item_id: str, rng: random.Random, damaged_chance: float = 0.2) -> str:
    """Something found in a dungeon or on the dead: now and then damaged, now and then better or worse made."""
    item = world.entities.get(item_id)
    if not can_vary(item) or "@" in item_id:
        return item_id
    r = rng.random()
    q = "Masterwork" if r > 0.985 else "Fine" if r > 0.93 else "Poor" if r < 0.12 else "Standard"
    return variant(item_id, q, rng.random() < damaged_chance)


def restore_cost(world, item_id: str) -> int:
    """Copper to restore a damaged item (a quarter of what it's worth whole)."""
    base_id, q, damaged = parse(item_id)
    if not damaged:
        return 0
    base = world.entities.get(base_id)
    value = float((base.fields.get("value") if base else 0) or 0) * VALUE[q]
    return max(100, int(round(value * 100 * RESTORE_SHARE)))


def mender_takes(occupation: str, item) -> bool:
    cats = MENDERS.get(occupation or "")
    return bool(cats) and (item.fields.get("category") or "") in cats


def damaged_held(world, state, members) -> list[tuple[str, str, int]]:
    """Every damaged thing the party holds: [(where, item id, count)] where is "pack" or a member id."""
    out = []
    for i, n in (state.inventory or {}).items():
        if parse(i)[2] and n > 0:
            out.append(("pack", i, n))
    for m in members or []:
        for i, n in (m.get("inventory") or {}).items():
            if parse(i)[2] and n > 0:
                out.append((m.get("id"), i, n))
    return out


def restore(world, state, members, where: str, item_id: str, n: int = 1) -> tuple[bool, str, str]:
    """Mend damaged items (paying for them). Returns (done, message, the mended item's id)."""
    base_id, q, damaged = parse(item_id)
    if not damaged:
        return False, "That isn't damaged.", item_id
    whole = variant(base_id, q, False)
    cost = restore_cost(world, item_id) * n
    if cost > state.copper:
        return False, "You can't afford that.", item_id
    from game import inventory
    if where == "pack":
        got = state.remove_item(item_id, n, reason="restored")
        if not got:
            return False, "You don't have that.", item_id
        state.add_item(whole, got, source="restored")
    else:
        m = next((x for x in members if x.get("id") == where), None)
        if m is None:
            return False, "Nobody has that.", item_id
        worn = [s for s, i in (m.get("equipment") or {}).items() if i == item_id]
        got = inventory.remove(m, item_id, n)
        if not got:
            return False, "You don't have that.", item_id
        inventory.add(m, whole, got)
        for s in worn[:got]:
            m.setdefault("equipment", {})[s] = whole
    state.add_copper(-cost, "restoring gear")
    from game.state import money_text
    item = world.entities.get(whole)
    return True, f"{item.name if item else whole} is as good as new ({money_text(cost)}).", whole


__all__ = ["QUALITIES", "parse", "variant", "base_of", "effective", "make", "of", "can_vary", "roll_found",
           "restore_cost", "restore", "damaged_held", "mender_takes", "VALUE", "TOOL"]
