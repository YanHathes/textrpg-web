"""Town events: festivals and raids (the event system the party's own settlements reuse in step 15).

Nothing is simulated in the background. When the party arrives in a town, and each day it stays, check()
looks at the calendar (game/calendar.py) and the region: a festival on today's date, or a raid. Only the
town the party is in ever has an event: leaving a raid ends it (the guard sees the raiders off), and a
festival is only "on" for a town while you're there to see it.

Festivals (villages and up) fall on set dates, so rumors (game/rumors.py) can tell of them ahead:

    Spring fair        a third of the way into spring, 3 days   traveling merchants, flower stalls, footraces
    Midsummer          the middle of summer, 2 days             bonfires, music, an archery contest
    Harvest festival   two thirds into autumn, 2 days           feasts, an eating contest, farm goods for sale
    Midwinter          the middle of winter, 2 days             lanterns, a gift market, arm wrestling
    Feast days         each god's own day, 1 day, in towns      processions, the temple's blessing, holy goods
                       with that god's temple

A festival runs three or four contests that fit its season (game/contests.py: minigames, or rolled as checks
with minigames off), with prizes; taking part gains a little standing with the town, winning more. The town
changes: bunting and lanterns on the streets, festival music, more people about, and the traders bring out
festival goods.

Raids: raiders from the region's own kind of trouble (bandits, orc and gnoll war bands, hobgoblins; pirates on
the coast, sky raiders where airships put in) come in waves, through the gates (or over the walls of a town that
has none). The town's guard turns out to fight them. The party can fight alongside the guard (the guards fight
too, as allies) for gold, standing and the raiders' loot. A raid on a town the party doesn't own can't be lost:
if the party stays out of it, the guard drives each wave off after a while. Smoke and damage linger a day or
two, and are only for show. A raid can be made winnable (step 15's settlements), when the defence it meets is
what decides.

Kept in the save (state.events): {"checked": {town id: day}, "festival": {...} | None, "raid": {...} | None,
"scars": {town id: minute}, "contests": {festival key: [contest ids entered]}, "blessed": [festival keys],
"raids_seen": n, "festivals_seen": [keys]}.
"""
from __future__ import annotations

import random
import zlib
from dataclasses import dataclass, field

DAY = 1440
FESTIVAL_TIERS = ("Village", "Town", "City", "Capital")
# name, season, where in it (0..1), days, highlights, contests it can run
FESTIVALS = [
    ("Spring fair", "Spring", 1 / 3, 3, "traveling merchants, flower stalls and footraces",
     ["footrace", "greased_pig", "dance", "horse_race", "knife_throwing", "riddles"]),
    ("Midsummer", "Summer", 1 / 2, 2, "bonfires, music and an archery contest",
     ["archery", "dance", "bards", "log_toss", "joust", "fishing_derby"]),
    ("Harvest festival", "Autumn", 2 / 3, 2, "feasts, an eating contest and farm goods for sale",
     ["eating", "apple_bobbing", "tug_of_war", "log_toss", "greased_pig", "horse_race"]),
    ("Midwinter", "Winter", 1 / 2, 2, "lanterns, a gift market and arm wrestling",
     ["arm_wrestling", "snowball", "bards", "riddles", "eating", "tug_of_war"]),
]
FEAST_CONTESTS = ["riddles", "bards", "dance", "footrace"]
FESTIVAL_GOODS = {"Spring fair": {"food", "clothing", "gear", "tool", "herb"},
                  "Midsummer": {"drink", "food", "instrument", "ammunition", "bow"},
                  "Harvest festival": {"food", "farm", "grain", "drink"},
                  "Midwinter": {"jewelry", "clothing", "trinket", "treasure", "gem"}}
TAKE_PART = 2                      # standing with the town for entering a contest
WIN = 3                            # more for winning it
# raids
RAID_CHANCE = {"Village": 0.03, "Town": 0.025, "City": 0.02, "Capital": 0.015}
WAVES = (2, 3)
WAVE_MINUTES = 45                  # how long the guard takes to drive a wave off without you
SCAR_DAYS = (1, 2)
RAIDERS = {"land": ["Bandit", "Bandit Captain", "Thug", "Orc", "Orc War Chief", "Gnoll", "Gnoll Pack Lord",
                    "Hobgoblin", "Hobgoblin Captain", "Bugbear", "Goblin", "Goblin Boss"],
           "coast": ["Bandit", "Bandit Captain", "Thug", "Veteran"],
           "sky": ["Bandit", "Bandit Captain", "Veteran", "Thug"]}
RAID_NAMES = {"land": "raiders", "coast": "pirates", "sky": "sky raiders"}
REWARD_GP = 10                     # a wave beaten with the guard: times the party's level
RAID_STANDING = 5


def data(state) -> dict:
    d = state.events
    d.setdefault("checked", {})
    d.setdefault("scars", {})
    d.setdefault("contests", {})
    d.setdefault("blessed", [])
    return d


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


# ----------------------------------------------------------------------------------------------------
# The calendar of festivals
# ----------------------------------------------------------------------------------------------------
@dataclass
class Festival:
    key: str                       # "name|year" (or "feast:<god>|year")
    name: str
    season: str
    start: int                     # day index (0 = day 1) it starts
    days: int
    highlights: str
    contests: list = field(default_factory=list)
    god: str = ""

    def on(self, day_index: int) -> bool:
        return self.start <= day_index < self.start + self.days


def _season_start(world, season: str, year: int) -> int:
    from game import calendar as CAL
    n = CAL.season_days(world)
    first = (world.rules or {}).get("season_start") or "Spring"
    k0 = CAL.SEASONS.index(first) if first in CAL.SEASONS else 0
    k = (CAL.SEASONS.index(season) - k0) % 4
    return year * CAL.year_days(world) + k * n


def festivals_of_year(world, year: int) -> list[Festival]:
    """The four seasonal festivals and the gods' feast days, in a year (from day 0)."""
    from game import calendar as CAL
    n = CAL.season_days(world)
    out = []
    for name, season, where, days, high, contests in FESTIVALS:
        start = _season_start(world, season, year) + min(n - days, max(0, int(round(n * where)) - 1))
        out.append(Festival(f"{name}|{year}", name, season, start, days, high, list(contests)))
    taken = {f.start + d for f in out for d in range(f.days)}
    for god in gods(world):
        k = zlib.crc32(god.lower().encode()) % CAL.year_days(world)
        while (year * CAL.year_days(world) + k) in taken:
            k = (k + 1) % CAL.year_days(world)
        start = year * CAL.year_days(world) + k
        taken.add(start)
        season = CAL.season(world, start * DAY)
        out.append(Festival(f"feast:{god}|{year}", f"The Feast of {god}", season, start, 1,
                            "processions, the temple's blessings and holy goods for sale", list(FEAST_CONTESTS), god))
    return sorted(out, key=lambda f: f.start)


def gods(world) -> list[str]:
    from game import factions
    cache = world.__dict__.get("_feast_gods")
    key = world.entities.count("building")
    if cache is None or cache[0] != key:
        names = sorted({factions.temple_god(b) for b in world.entities.by_field("building", "kind", "Temple")
                        if factions.temple_god(b)})
        cache = (key, names)
        world.__dict__["_feast_gods"] = cache
    return list(cache[1])


def _temple_gods(world, town) -> set[str]:
    from game import factions, places
    return {factions.temple_god(b) for b in places.buildings_in(world, town)
            if (b.fields.get("kind") or "") == "Temple" and factions.temple_god(b)}


def festival_at(world, town, minutes: int) -> Festival | None:
    """The festival in this town on this day (none in hamlets; a feast day only where that god has a temple)."""
    from game import calendar as CAL
    from game import settlements as ST
    if town is None or ST.tier_of(town) not in FESTIVAL_TIERS:
        return None
    day = int(minutes) // DAY
    year = day // CAL.year_days(world)
    temple = None
    for f in festivals_of_year(world, year):
        if not f.on(day):
            continue
        if f.god:
            if temple is None:
                temple = _temple_gods(world, town)
            if f.god not in temple:
                continue
        return _with_contests(world, town, f)
    return None


def upcoming(world, town, minutes: int, within: int = 14) -> tuple[Festival, int] | None:
    """The next festival this town keeps, and in how many days (within that many)."""
    day = int(minutes) // DAY
    for d in range(1, within + 1):
        f = festival_at(world, town, (day + d) * DAY)
        if f is not None and f.start == day + d:
            return f, d
    return None


def _with_contests(world, town, f: Festival) -> Festival:
    """Three or four of the festival's contests, by the town."""
    rng = _rng("contests", town.id, f.key)
    pool = list(f.contests)
    rng.shuffle(pool)
    f.contests = pool[: rng.choice((3, 4))]
    return f


def festival_here(world, state) -> Festival | None:
    """The festival where the party is, if there is one today."""
    from game import places
    spot = places.current(world, state)
    if spot.kind not in ("street", "building") or spot.town is None:
        return None
    return festival_at(world, spot.town, state.minutes)


# ----------------------------------------------------------------------------------------------------
# Checking: on arrival, and each day
# ----------------------------------------------------------------------------------------------------
def check(world, state, town, rng: random.Random | None = None, bus=None, levels=None) -> list[str]:
    """Once a day for the town the party is in: a festival to announce, or a raid. Returns what happened."""
    from game import places
    d = data(state)
    here = places.current(world, state)
    if town is None or here.town is None or here.town.id != town.id:
        return []                                     # only the town you're in
    state.ticks.setdefault("town_events", state.minutes)
    out = []
    today = state.day
    f = festival_at(world, town, state.minutes)
    if f is not None:
        seen = d.setdefault("festivals_seen", [])
        tag = f"{town.id}|{f.key}"
        if tag not in seen:
            seen.append(tag)
            del seen[:-40]
            text = f"{f.name} in {town.name}! " + f.highlights[:1].upper() + f.highlights[1:] + \
                f". Contests today: {', '.join(contest_name(c) for c in f.contests)}."
            out.append(text)
            if bus is not None:
                bus.emit("log", kind="quest", text=text)
                bus.emit("festival.started", town=town.id, festival=f.name)
    if d["checked"].get(town.id) == today:
        return out
    d["checked"][town.id] = today
    if f is None and d.get("raid") is None:
        r = _raid_roll(world, state, town, rng or _rng("raid", town.id, today), levels)
        if r is not None:
            out.append(r["text"])
            if bus is not None:
                bus.emit("log", kind="damage", text=r["text"])
                bus.emit("raid.started", town=town.id, raid=dict(r))
    state.save()
    return out


def _catch_up(world, state, since: int, now: int) -> None:
    """The ticker: a new day in town is checked; a raid moves on as time passes; a raid you've left is over."""
    from game import places
    try:
        spot = places.current(world, state)
    except Exception:  # noqa: BLE001
        return
    bus = getattr(state, "bus", None)
    raid = data(state).get("raid")
    if raid is not None:
        if spot.town is None or spot.town.id != raid["town"]:
            end_raid(world, state, "left")
        else:
            advance_raid(world, state, now, bus)
    if spot.kind in ("street", "building") and spot.town is not None and since // DAY != now // DAY:
        check(world, state, spot.town, bus=bus)


# ----------------------------------------------------------------------------------------------------
# Raids
# ----------------------------------------------------------------------------------------------------
def raid_kind(world, town) -> str:
    from game import animals, places
    if any((n.fields.get("occupation") or "") == "Airship pilot"
           for b in places.buildings_in(world, town) for n in (world.entities.get(x) for x in b.fields.get("npcs") or [])
           if n is not None):
        return "sky"
    try:
        if animals.coastal(world, town):
            return "coast"
    except Exception:  # noqa: BLE001
        pass
    return "land"


def raiders(world, town, levels, rng: random.Random, kind: str = "") -> list[dict]:
    """One wave: enemy rows from the region's sort of raiders, Medium for a party of these levels."""
    from game import quests as Q
    kind = kind or raid_kind(world, town)
    names = {n.lower() for n in RAIDERS[kind]}
    opts = [o for o in Q.encounter_options(world, levels or [1], "Medium") if o[0].name.lower() in names]
    if not opts:
        opts = [o for o in Q.encounter_options(world, levels or [1], "Hard") if o[0].name.lower() in names]
    if not opts:
        e = next((world.entities.find_by_name("enemy", n) for n in RAIDERS[kind]
                  if world.entities.find_by_name("enemy", n) is not None), None)
        return [{"id": e.id, "count": 3}] if e is not None else []
    e, n, _adj, _s = rng.choice(opts[:5])
    rows = [{"id": e.id, "count": n}]
    if kind != "land":
        rows[0]["name"] = "Pirate" if kind == "coast" else "Sky raider"
    return rows


def _raid_roll(world, state, town, rng, levels=None) -> dict | None:
    from game import settlements as ST
    if town.fields.get("settlement"):
        return None                                   # the party's own: game/colony.py rolls for those
    tier = ST.tier_of(town)
    chance = RAID_CHANCE.get(tier, 0.0)
    if chance <= 0 or rng.random() >= chance:
        return None
    return start_raid(world, state, town, rng, levels)


def start_raid(world, state, town, rng: random.Random | None = None, levels=None, winnable: bool = False,
               defense: int = 0) -> dict:
    """Raiders at the gates. winnable: whether they can take the place (only a party's own settlement:
    step 15), with `defense` the strength (adjusted XP) of what stands against them."""
    from game import places
    from game import settlements as ST
    rng = rng or random.Random()
    kind = raid_kind(world, town)
    n = rng.randint(*WAVES)
    waves = [raiders(world, town, levels or [2], rng, kind) for _ in range(n)]
    exits = places.town_exits(town) if hasattr(places, "town_exits") else {}
    gate = rng.choice(sorted(exits)) if exits else ""
    walled = ST.walled(town)
    street = exits.get(gate) if exits else places.first_street(town)
    raid = {"town": town.id, "kind": kind, "waves": waves, "wave": 0, "started": state.minutes,
            "wave_at": state.minutes, "status": "on", "winnable": bool(winnable), "defense": int(defense),
            "gate": gate, "walled": walled, "at": places.street_id(town.id, street) if street else "",
            "beaten_by": [], "rewards": 0}
    data(state)["raid"] = raid
    data(state)["raids_seen"] = int(data(state).get("raids_seen", 0)) + 1
    state.ticks.setdefault("town_events", state.minutes)       # the catch-up moves it along from now
    way = (f"through the {gate.lower()} gate" if walled else f"from the {gate.lower()}") if gate else "into the streets"
    raid["text"] = (f"Raiders! {RAID_NAMES[kind].capitalize()} are coming {way}" +
                    (" and over the walls by the towers" if walled and rng.random() < 0.3 else "") +
                    f" of {town.name}. The guard turns out to meet them.")
    state.save()
    return raid


def raid_here(world, state) -> dict | None:
    from game import places
    raid = data(state).get("raid")
    if raid is None or raid.get("status") != "on":
        return None
    spot = places.current(world, state)
    return raid if spot.town is not None and spot.town.id == raid["town"] else None


def wave_rows(raid: dict) -> list[dict]:
    return raid["waves"][raid["wave"]] if raid and raid["wave"] < len(raid["waves"]) else []


def _strength(world, rows) -> int:
    from game import arena
    return arena.adjusted_xp(world, rows)


def advance_raid(world, state, now: int | None = None, bus=None) -> dict | None:
    """Time passes: each wave the party leaves to the guard is driven off after a while (or, for a winnable
    raid, the defence and the raiders' strength decide)."""
    raid = data(state).get("raid")
    if raid is None or raid.get("status") != "on":
        return raid
    now = state.minutes if now is None else now
    guard = 0
    while raid["status"] == "on" and now - int(raid["wave_at"]) >= WAVE_MINUTES and guard < 10:
        guard += 1
        rows = wave_rows(raid)
        if raid.get("winnable") and _strength(world, rows) > int(raid.get("defense") or 0):
            raid["status"] = "lost"
            _scar(world, state, raid)
            if bus is not None:
                bus.emit("raid.lost", town=raid["town"])
            _settlement_over(world, state, raid, bus)
            break
        raid["beaten_by"].append("guard")
        _next_wave(world, state, raid, int(raid["wave_at"]) + WAVE_MINUTES, bus)
    state.save()
    return raid


def _next_wave(world, state, raid: dict, at: int, bus=None) -> None:
    raid["wave"] += 1
    raid["wave_at"] = at
    if raid["wave"] >= len(raid["waves"]):
        raid["status"] = "beaten"
        _scar(world, state, raid)
        town = world.entities.get(raid["town"])
        if bus is not None:
            bus.emit("log", kind="quest", text=f"The last of the raiders flee {town.name if town else 'the town'}.")
            bus.emit("raid.ended", town=raid["town"], status="beaten")
        _settlement_over(world, state, raid, bus)


def _settlement_over(world, state, raid: dict, bus=None) -> None:
    """A raid on one of the party's own settlements has ended: its gains and losses (game/colony.py)."""
    if not raid.get("winnable"):
        return
    try:
        from game import colony
        colony.raid_over(world, state, raid, bus)
    except Exception:  # noqa: BLE001
        pass


def _scar(world, state, raid: dict) -> None:
    rng = _rng("scars", raid["town"], raid["started"])
    data(state)["scars"][raid["town"]] = state.minutes + rng.randint(*SCAR_DAYS) * DAY


def scarred(state, town_id: str) -> bool:
    """Smoke and damage still showing (only for looks)."""
    return int(data(state)["scars"].get(town_id, 0)) > state.minutes


def wave_won(world, state, members, bus=None) -> dict:
    """The party (and the guard with it) beat the current wave: gold, standing, and the next wave or the end."""
    from game import factions
    from game.state import money_text
    raid = data(state).get("raid")
    if raid is None or raid.get("status") != "on":
        return {}
    town = world.entities.get(raid["town"])
    lv = [max(1, int(m.get("level") or 1)) for m in members or [] if not m.get("dead")] or [1]
    pay = REWARD_GP * max(1, round(sum(lv) / len(lv))) * 100
    state.add_copper(pay, "the town's thanks")
    raid["rewards"] += pay
    raid["beaten_by"].append("party")
    tf = factions.town_faction(world, town) if town is not None else None
    if tf is not None:
        factions.change(world, state, tf.id, RAID_STANDING, "for standing with the guard", bus)
    _next_wave(world, state, raid, state.minutes, bus)
    text = f"The wave breaks. The captain of the guard presses {money_text(pay)} into your hand." + \
        (" More are coming!" if raid["status"] == "on" else "")
    if bus is not None:
        bus.emit("log", kind="loot", text=text)
    state.save()
    return {"text": text, "pay": pay, "status": raid["status"]}


def end_raid(world, state, why: str = "") -> None:
    """The party has gone: whatever's left, the guard sees off (nothing is lost in a town you're not in)."""
    raid = data(state).get("raid")
    if raid is None:
        return
    if raid.get("status") == "on":
        raid["status"] = "beaten" if not raid.get("winnable") else "abandoned"
        raid["beaten_by"].append("guard")
        _scar(world, state, raid)
        if raid["status"] == "abandoned":
            _settlement_over(world, state, raid, getattr(state, "bus", None))
    data(state)["raid"] = None
    state.save()


def clear_finished(state) -> None:
    raid = data(state).get("raid")
    if raid is not None and raid.get("status") != "on":
        data(state)["raid"] = None


# ----------------------------------------------------------------------------------------------------
# At a festival: contests, blessings, stalls
# ----------------------------------------------------------------------------------------------------
def contest_name(cid: str) -> str:
    from game import contests
    return contests.CONTESTS.get(cid, {}).get("name", cid.replace("_", " ").capitalize())


def entered(state, f: Festival) -> list[str]:
    return list(data(state)["contests"].get(f.key + "|" + _town_key(state), []))


def _town_key(state) -> str:
    from game import places
    t = places.current(state.world, state).town
    return t.id if t is not None else ""


def enter_contest(world, state, f: Festival, cid: str) -> bool:
    k = f.key + "|" + _town_key(state)
    lst = data(state)["contests"].setdefault(k, [])
    if cid in lst:
        return False
    lst.append(cid)
    return True


def took_part(world, state, town, won: bool, bus=None) -> None:
    from game import factions
    tf = factions.town_faction(world, town) if town is not None else None
    if tf is not None:
        factions.change(world, state, tf.id, TAKE_PART + (WIN if won else 0),
                        "for joining in the festival" + (" (and winning)" if won else ""), bus)


def bless(world, state, members, f: Festival, bus=None) -> str:
    """A feast day's blessing at the god's temple: the party is healed and its ills lifted (once a feast)."""
    from game import condition
    k = f.key + "|" + _town_key(state)
    if k in data(state)["blessed"]:
        return "You've had the temple's blessing this feast."
    data(state)["blessed"].append(k)
    for m in members or []:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        condition.store(state, m, c, save=False)
    state.save()
    text = f"The priests of {f.god} bless you in the procession. You feel whole again."
    if bus is not None:
        bus.emit("log", kind="heal", text=text)
    return text


def festival_stock(world, state, npc) -> dict[str, int]:
    """What a trader brings out for the festival in their town: goods that fit it (holy goods on a feast day)."""
    from game import neighborhood as NB
    from game import trade
    town = world.entities.get(NB.npc_town(world, npc))
    f = festival_at(world, town, state.minutes) if town is not None else None
    if f is None or not trade.is_merchant(world, npc):
        return {}
    want = {"holy", "potion"} if f.god else FESTIVAL_GOODS.get(f.name, set())
    rng = _rng("stalls", npc.id, f.key)
    items = [i for i in world.entities.all("item") if trade.item_tags(i) & want
             and (i.fields.get("rarity") or "Common") in ("", "Common", "Uncommon")]
    rng.shuffle(items)
    return {i.id: rng.randint(1, 4) for i in items[:6]}


def busy_factor(world, state, town) -> float:
    """How many more people are out in the streets (a festival doubles the crowd)."""
    return 2.0 if town is not None and festival_at(world, town, state.minutes) is not None else 1.0


def _register() -> None:
    from game import ticker
    ticker.register("town_events", _catch_up)


_register()

__all__ = ["Festival", "festivals_of_year", "festival_at", "festival_here", "upcoming", "check", "start_raid",
           "raid_here", "wave_rows", "advance_raid", "wave_won", "end_raid", "scarred", "bless", "festival_stock",
           "contest_name", "enter_contest", "entered", "took_part", "raiders", "busy_factor", "data", "FESTIVALS"]
