"""Places a world gains when it's opened (once per world; a later version adds what's new):

    Colleges     every capital and about half the cities: courses (game/books.py) and a library of their own
    Libraries    a reading room in every town that hasn't one (the cities and capitals have theirs)
    Boatwrights  a boatyard in towns on the water (game/animals.py: buy a boat, and moor it there)
    Arenas       every capital (game/arena.py: tournaments and bets)            (version 2)
    Casinos      every capital (game/tablegames: hold'em, craps, roulette)      (version 2)
    Automaton    every capital and city that has no workshop: an automaton maker sells automatons to work the
    works        party's buildings (game/estate.py)                             (version 3)
    Ways across  every town on a continent can reach every other: a group of towns with no road to the rest
                 gets a track to the nearest town of the rest when the land joins them, and a ferry (a
                 landing and its captain on each side) when it's an island     (version 4)
    Brothels     every capital: a madam, a doorkeeper and courtesans (game/brothel.py)   (version 5)

Each comes with its staff, named the way the town's own people are. They're world data (saved with the world),
not the save's.
"""
from __future__ import annotations

import random
import zlib
from collections import Counter

PLACES_V = 5
COLLEGE_SHARE = 0.5                   # of the cities (every capital has one)
BOATYARD_TIERS = ("Village", "Town", "City", "Capital")
SKIN = ["#f1d3b3", "#e0b48c", "#c68a5e", "#a0663e", "#7a4c30", "#5a3824"]
HAIR = ["#2b2220", "#4a3020", "#7a5230", "#b08040", "#d8c080", "#8a8a8a", "#e8e8e0", "#a03a20"]
STYLES = ["short", "long", "bun", "cropped", "braid", "bald"]
CLOTHES = ["#4a3f5e", "#3e5a4a", "#5e4a3a", "#2e4a6a", "#6a2e2e", "#5a5a5a", "#7a6a3a"]


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


def _hash01(*key) -> float:
    return zlib.crc32("|".join(map(str, key)).encode("utf-8")) / 0xFFFFFFFF


def ensure(world, force: bool = False) -> int:
    """Add the places this version brings. Returns how many buildings were made."""
    if not force and int((world.meta or {}).get("places_v") or 0) >= PLACES_V:
        return 0
    from game import animals
    store = world.entities
    made = 0
    people: list = []
    folk = _by_town(world)
    kinds: dict = {}
    on_street: dict = {}
    for b in store.all("building"):
        tid = b.fields.get("town") or ""
        kinds.setdefault(tid, Counter())[b.fields.get("kind") or ""] += 1
        on_street.setdefault(tid, Counter())[b.fields.get("street") or ""] += 1
    ctx = (folk, on_street, {b.name for b in store.all("building")})
    from game import geography as G
    grid = G.terrain(world)
    for t in sorted(store.all("town"), key=lambda e: e.id):
        if t.fields.get("settlement"):
            continue                                 # the party's own settlements (game/colony.py)
        tier = t.fields.get("kind") or "Village"
        have = kinds.get(t.id, Counter())
        if tier == "Capital" or (tier == "City" and _hash01("college", t.id) < COLLEGE_SHARE):
            if not have["College"]:
                made += _add(world, t, "College", people, ctx)
        if tier == "Town" and not have["Library"] and not have["College"]:
            made += _add(world, t, "Library", people, ctx)
        if tier == "Capital":
            for kind in ("Arena", "Casino", "Brothel"):
                if not have[kind]:
                    made += _add(world, t, kind, people, ctx)
        if tier in ("Capital", "City") and not have["Workshop"]:
            made += _add(world, t, "Workshop", people, ctx)
        if tier in BOATYARD_TIERS and not have["Boatwright"] and animals.coastal(world, t, grid):
            if tier != "Village" or _hash01("boatyard", t.id) < 0.5:
                made += _add(world, t, "Boatwright", people, ctx)
    made += connect(world, people, ctx)
    if made:
        store.save("building")
        store.save("npc")
        store.save("town")
    world.meta["places_v"] = PLACES_V
    try:
        world.save_meta()
    except Exception:  # noqa: BLE001
        pass
    return made


# ======================================================================
# Ways across (version 4): no town cut off from the rest of its continent
# ======================================================================
FERRY_MPD = 40                        # miles a ferry makes in a day
DIRS = ["East", "South-east", "South", "South-west", "West", "North-west", "North", "North-east"]


def _land_masses(world) -> tuple[list, object]:
    """Which land mass each cell of the world grid is on (0: water)."""
    from collections import deque

    from game import geography as G
    g = G.terrain(world)
    wet = {i for i, b in enumerate(G.BIOMES) if b in ("Ocean", "Lake")}
    lab = [0] * (g.cols * g.rows)
    k = 0
    for i in range(len(lab)):
        if lab[i] or g.biome[i] in wet:
            continue
        k += 1
        lab[i] = k
        q = deque([i])
        while q:
            j = q.popleft()
            c, r = j % g.cols, j // g.cols
            for dc, dr in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                cc, rr = c + dc, r + dr
                if 0 <= cc < g.cols and 0 <= rr < g.rows:
                    jj = rr * g.cols + cc
                    if not lab[jj] and g.biome[jj] not in wet:
                        lab[jj] = k
                        q.append(jj)
    return lab, g


def road_groups(world, ferries: bool = False) -> dict:
    """continent id -> its towns in groups joined by roads (and, with ferries, by the ferries this fill
    put in), the biggest group first."""
    from game import geography as G
    from game import places
    towns = [t for t in world.entities.all("town") if not t.fields.get("settlement")
             and G.town_position(world, t) is not None]
    adj: dict = {t.id: set() for t in towns}
    for t in towns:
        for r in places.roads_of(t):
            d = r.get("leads_to")
            if d in adj:
                adj[t.id].add(d)
                adj[d].add(t.id)
    if ferries:
        for n in world.entities.by_field("npc", "title", "Ferry captain"):
            if n.fields.get("title") != "Ferry captain" or n.fields.get("town") not in adj:
                continue
            for row in n.fields.get("passages") or []:
                if row.get("to") in adj:
                    adj[n.fields["town"]].add(row["to"])
                    adj[row["to"]].add(n.fields["town"])
    by_cont: dict = {}
    for t in towns:
        c = G.continent_of_town(world, t)
        by_cont.setdefault(c.id if c is not None else "", []).append(t.id)
    out = {}
    for cid, ids in by_cont.items():
        inside, seen, groups = set(ids), set(), []
        for i in sorted(ids):
            if i in seen:
                continue
            comp, stack = {i}, [i]
            seen.add(i)
            while stack:
                x = stack.pop()
                for y in adj[x]:
                    if y in inside and y not in seen:
                        seen.add(y)
                        comp.add(y)
                        stack.append(y)
            groups.append(sorted(comp))
        groups.sort(key=lambda g: (-len(g), g[0]))
        out[cid] = groups
    return out


def connect(world, people: list | None = None, ctx=None) -> int:
    """Join every cut-off group of towns to the rest of its continent: a track overland, or a ferry to an
    island. Returns how many ferry landings were built (roads are added to the towns)."""
    from game import geography as G
    people = people if people is not None else []
    if ctx is None:
        folk = _by_town(world)
        on_street: dict = {}
        for b in world.entities.all("building"):
            on_street.setdefault(b.fields.get("town") or "", Counter())[b.fields.get("street") or ""] += 1
        ctx = (folk, on_street, {b.name for b in world.entities.all("building")})
    groups = road_groups(world, ferries=True)
    lab, g = _land_masses(world)
    made = 0

    def land(tid):
        i = g.index(*G.town_position(world, world.entities.get(tid)))
        return lab[i] if i is not None else -1

    def pos(tid):
        return G.town_position(world, world.entities.get(tid))
    for cid, gs in sorted(groups.items()):
        if not cid or len(gs) < 2:
            continue
        joined = list(gs[0])
        for grp in gs[1:]:
            pairs = sorted(((G.distance(pos(a), pos(b)), a, b) for a in grp for b in joined), key=lambda x: x[0])
            mine = {land(t) for t in joined}
            by_land = [x for x in pairs if land(x[1]) in mine and land(x[1]) == land(x[2])]
            if by_land:                                  # the land joins them: a track
                _d, a, b = by_land[0]
                _road(world, a, b)
            else:                                        # an island: a ferry between the nearest ports
                ports = [x for x in pairs if _near_water(world, x[1], g) and _near_water(world, x[2], g)]
                _d, a, b = (ports or pairs)[0]
                made += _ferry(world, a, b, people, ctx)
            joined += grp
    return made


def _near_water(world, tid: str, g, reach: int = 3) -> bool:
    """A town within a few cells of the world grid of open water (a ferry can put in near it)."""
    from game import geography as G
    p = G.town_position(world, world.entities.get(tid))
    if p is None:
        return False
    for dy in range(-reach, reach + 1):
        for dx in range(-reach, reach + 1):
            if g.biome_at(p[0] + dx * g.cell, p[1] + dy * g.cell) in ("Ocean", "Lake"):
                return True
    return False


def _free_direction(town, dx: float, dy: float) -> str:
    """The way out of town toward (dx, dy): its compass point, or the nearest one no road uses yet."""
    import math
    from game import places
    used = {r.get("direction") for r in places.roads_of(town)}
    ang = math.degrees(math.atan2(dy, dx)) % 360
    first = int(((ang + 22.5) % 360) // 45)
    for k in (0, 1, -1, 2, -2, 3, -3, 4):
        d = DIRS[(first + k) % 8]
        if d not in used:
            return d
    return DIRS[first]


def _road(world, a_id: str, b_id: str) -> None:
    """A track between two towns (both ways)."""
    from game import geography as G
    a, b = world.entities.get(a_id), world.entities.get(b_id)
    pa, pb = G.town_position(world, a), G.town_position(world, b)
    miles = G.distance(pa, pb)
    hours = max(1, round(miles / G.mph(world)))
    for t, o, d in ((a, b, _free_direction(a, pb[0] - pa[0], pb[1] - pa[1])),
                    (b, a, _free_direction(b, pa[0] - pb[0], pa[1] - pb[1]))):
        roads = list(t.fields.get("roads") or [])
        if any(r.get("leads_to") == o.id for r in roads):
            continue
        roads.append({"direction": d, "leads_to": o.id, "hours": hours, "danger": 25, "grade": "track"})
        world.entities.update(t.id, fields={"roads": roads}, save=False)


def _ferry(world, a_id: str, b_id: str, people: list, ctx) -> int:
    """A ferry landing in each of two towns, each with a captain who'll take you across."""
    from game import geography as G
    a, b = world.entities.get(a_id), world.entities.get(b_id)
    miles = G.distance(G.town_position(world, a), G.town_position(world, b))
    days = max(1, round(miles / FERRY_MPD))
    price = max(2, round(miles / 12))
    made = 0
    for here, there in ((a, b), (b, a)):
        before = len(people)
        made += _add(world, here, "Ferry", people, ctx)
        for nid in people[before:]:
            n = world.entities.get(nid)
            if n is not None and n.fields.get("occupation") == "Ship captain":
                world.entities.update(nid, fields={"passages": [
                    {"to": there.id, "method": "Boat", "price": price, "days": days, "danger": 15,
                     "note": f"the ferry to {there.name}"}]}, save=False)
    return made


NAMES = {"College": ["The College of {town}", "{town} Academy", "The {town} Collegium", "The Lyceum of {town}"],
         "Library": ["{town} Reading Room", "The {town} Library", "The Book House"],
         "Boatwright": ["{family}'s Boatyard", "The {town} Boatyard", "{family} and Sons, Boatwrights"],
         "Arena": ["The {town} Arena", "The Pit of {town}", "The Grand Arena"],
         "Casino": ["The Golden Wheel", "The {town} Gaming House", "{family}'s Palace of Chance"],
         "Workshop": ["The {town} Automaton Works", "{family}'s Clockwork Shop", "The Brass Cog"],
         "Ferry": ["The {town} Ferry Landing", "{family}'s Ferry", "The Ferry House"],
         "Brothel": ["The Velvet Lantern", "The Red Door", "{family}'s House of Comfort", "The Silk Purse",
                     "The {town} Rose", "The Gilded Garter", "The Scarlet Lamp", "The House of {family}"]}
TEXT = {"College": "Lecture halls, a porter who knows every face, and a library the masters guard jealously.",
        "Library": "A quiet room of shelves and reading tables, and a keeper who hushes the loud.",
        "Boatwright": "A hull on the stocks, shavings underfoot, and boats for sale along the slip.",
        "Arena": "Tiers of stone benches round a ring of sand, and a crowd that comes for blood.",
        "Casino": "Green cloth, lamplight, the rattle of dice and the whirr of the wheel.",
        "Workshop": "A workshop of brass and timber where automatons are built to order.",
        "Ferry": "A landing stage, a tarred ferry boat riding at its moorings, and a board of sailing times.",
        "Brothel": "Red lamps in the windows, perfume on the stair, and more doors upstairs than any inn needs."}
STAFF = {"College": [("Scholar", "Master of the college", "Knowledge is bought with time. We sell the shortcut."),
                     ("Arcanist", "Lecturer in the arcane", "Mind the sigils on the floor. Some of them are live."),
                     ("Scholar", "Librarian", "Hands clean? Then the stacks are yours.")],
         "Library": [("Scholar", "Keeper of books", "Quietly, please. Read what you like.")],
         "Boatwright": [("Commoner", "Boatwright", "She'll float. They all float. Some of them stay up."),
                        ("Commoner", "Shipwright's hand", "Mind the pitch, it's still warm.")],
         "Arena": [("Mercenary", "Arena master", "Fighters sign with me. Watchers bet with him."),
                   ("Commoner", "Bookmaker", "Odds on every bout, friend."),
                   ("Mercenary", "Champion of the arena", "You want the sand? Earn it.")],
         "Casino": [("Merchant", "Master of the house", "The house always welcomes a player."),
                    ("Commoner", "Croupier", "Place your bets."),
                    ("Guard", "Doorkeeper", "Keep your hands where the dealer can see them.")],
         "Workshop": [("Arcanist", "Automaton maker", "Every one of them is built to last. Most of them do."),
                      ("Commoner", "Tinkerer", "Mind the springs. They bite.")],
         "Ferry": [("Ship captain", "Ferry captain", "Over the water? She sails with the tide. Climb aboard."),
                   ("Commoner", "Ferryhand", "Mind the gap between the boat and the landing.")],
         "Brothel": [("Merchant", "Madam of the house", "Welcome, welcome. Take a seat, have a glass, look around."),
                     ("Guard", "Doorkeeper", "Coin first, manners always, and nobody gets hurt."),
                     ("Commoner", "Courtesan", "Well, hello there. Looking for company?"),
                     ("Commoner", "Courtesan", "You look like you could use a soft bed and good company."),
                     ("Commoner", "Courtesan", "New in town? I'll show you the sights. Upstairs."),
                     ("Commoner", "Courtesan", "Don't be shy. Sit with me a while.")]}
ALL_STAFF = {"Brothel"}                 # kinds whose whole staff comes (not just two or three)
HOURS = {"Ferry": "06:00-20:00", "Brothel": "18:00-06:00",
         "College": "08:00-20:00", "Library": "09:00-18:00", "Boatwright": "07:00-19:00", "Arena": "10:00-22:00",
         "Casino": "16:00-04:00", "Workshop": "09:00-19:00"}
SIZE = {"Ferry": "Small", "Brothel": "Large",
        "College": "Large", "Library": "Medium", "Boatwright": "Medium", "Arena": "Large", "Casino": "Large",
        "Workshop": "Medium"}
INTERIOR = {"Ferry": "Wooden", "Brothel": "Rich",
            "College": "Stone", "Library": "Stone", "Boatwright": "Wooden", "Arena": "Stone", "Casino": "Rich",
            "Workshop": "Stone"}


BUILDING_KIND = {"Ferry": "Other"}      # what the building is, when the fill's own name isn't a kind


def _by_town(world) -> dict:
    """Everyone, by the town they live in (worked out once: the towns' new staff don't need to be in it)."""
    from game import neighborhood as NB
    out: dict = {}
    for n in world.entities.all("npc"):
        out.setdefault(NB.npc_town(world, n), []).append(n)
    return out


def _name_like(rng: random.Random, folk: list, used: set) -> tuple[str, str, str]:
    """A name that sounds like the town's people: one person's given name, another's family name."""
    givens = [(n.name.split(" ", 1)[0], (n.fields.get("appearance") or {}).get("sex") or "") for n in folk]
    families = [n.name.split(" ", 1)[1] for n in folk if " " in n.name]
    for _ in range(30):
        g, sex = rng.choice(givens) if givens else (rng.choice(["Aldo", "Mira", "Teo", "Vesna", "Oren"]), "")
        f = rng.choice(families) if families else rng.choice(["Hale", "Brook", "Marrow", "Thane"])
        name = f"{g} {f}"
        if name not in used:
            return name, f.split()[-1], sex
    return f"{g} {f} the Younger", f.split()[-1], sex


def _add(world, town, kind: str, people: list, ctx) -> int:
    """One building of this kind, on the quietest street, with its staff."""
    from game import places
    store = world.entities
    by_town, on_street, taken = ctx
    rng = _rng("fill", kind, town.id)
    streets = [s["name"] for s in places.streets_of(town)]
    if not streets:
        return 0
    count = on_street.setdefault(town.id, Counter())
    street = min(streets, key=lambda s: (count.get(s, 0), s))
    count[street] += 1
    folk = by_town.get(town.id, [])
    used = {n.name for n in folk}
    family = _name_like(rng, folk, used)[1]
    names = [n.format(town=town.name, family=family) for n in NAMES[kind]]
    rng.shuffle(names)
    name = next((n for n in names if n not in taken), names[0])          # (a name not taken, if there is one)
    k = 2
    base = name
    while name in taken:
        name = f"{base} {k}"
        k += 1
    taken.add(name)
    races = Counter(n.fields.get("race") for n in folk if n.fields.get("race"))
    race = races.most_common(1)[0][0] if races else "race.human"
    b = store.create("building", name, {
        "kind": BUILDING_KIND.get(kind, kind), "town": town.id, "street": street, "npcs": [], "interior": INTERIOR[kind],
        "open_hours": HOURS[kind], "inn_price": 0, "size": SIZE[kind], "generate": True, "owner": False,
        "faction": town.fields.get("faction"), "facilities": ["Dock"] if kind in ("Boatwright", "Ferry") else [], "jobs": []},
        TEXT[kind], ["World"], save=False)
    staff = []
    crew = STAFF[kind] if kind in ALL_STAFF else STAFF[kind][: (3 if town.fields.get("kind") == "Capital" else 2)]
    for occ, title, greet in crew:
        nm, _fam, sex = _name_like(rng, folk, used)
        used.add(nm)
        sex = sex or rng.choice(["male", "female"])
        n = store.create("npc", nm, {
            "race": race, "occupation": occ, "class": None, "level": 1, "disposition": "Neutral",
            "faction": town.fields.get("faction"), "trains": [], "building": b.id, "town": town.id, "street": street,
            "home": None, "schedule": [], "greeting": greet, "talk": None, "quest_cooldown_days": 0, "quests": [],
            "sells_tags": [], "shop_items": [], "gold": rng.randint(40, 400), "price_markup": 100, "passages": [],
            "relationships": [], "title": title,
            "appearance": {"sex": sex, "skin": rng.choice(SKIN), "hair_color": rng.choice(HAIR),
                           "hair": rng.choice(STYLES), "clothes": rng.choice(CLOTHES)},
            "equipment": {}, "fights_as": None}, f"{title} at {name}.", ["World", "Staff"], save=False)
        staff.append(n.id)
        people.append(n.id)
    store.update(b.id, fields={"npcs": staff}, save=False)
    return 1


__all__ = ["ensure", "connect", "road_groups", "PLACES_V"]
