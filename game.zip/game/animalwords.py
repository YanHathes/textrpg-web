"""An animal, cart or boat of the party's in a line (what it is, what it's for, where it is): shared by the app's
animals window (ui/animals_dialog.py) and the browser version."""
from __future__ import annotations

KIND_WORD = {"animal": "Animal", "vehicle": "Vehicle", "boat": "Boat"}


def animal_line(world, state, members, v: dict) -> str:
    from game import animals
    bits = [KIND_WORD.get(v["kind"], v["kind"]) + (f" ({v['type']})" if v["type"] != v["name"] else "")]
    if v["kind"] == "animal":
        bits.append(animals.ROLE_WORDS.get(v.get("role"), "").capitalize())
        rider = next((m.get("name") for m in members or [] if m.get("id") == v.get("rider")), "")
        if rider:
            bits.append(f"ridden by {rider}")
        pulls = animals.get(state, v.get("pulls") or "")
        if pulls is not None:
            bits.append(f"pulls the {pulls['name'].lower()}")
        sp = animals.speed_ft(world, v)
        if sp:
            bits.append(f"{sp} ft")
    cap = animals.capacity(world, v)
    if cap and (v["kind"] != "animal" or v.get("role") in ("mount", "pack")):
        bits.append(f"carries {animals.load(world, v):g} of {cap} lb")
    w = animals.where(world, state, v)
    if w.startswith("stable:") or w.startswith("dock:"):
        t = world.entities.get(w.split(":", 1)[1])
        bits.append(("at the stable" if w.startswith("stable:") else "moored") + (f" in {t.name}" if t else ""))
    elif w == "aboard":
        bits.append("in the ship's hold")
    elif w == "away":
        bits.append("out on a trade route")
    elif w == "parked":
        bits.append("left where you got down")
    else:
        bits.append("with you")
    return "  ·  ".join(b for b in bits if b)
