"""Walkable maps: towns, the buildings in them and dungeons, laid out square by square (5 ft each)
with the same tiles the battle maps use.

A map is an Area made of Levels. A town has one base level (streets, yards, every building's ground
floor) plus an overlay level for each upper floor and cellar of each building, laid over that
building's footprint in the same coordinates: going upstairs swaps the building's squares for the
floor above while the street around it stays where it is (a doll's house with the roof lifted off).
A dungeon has one full level per floor.

Nothing here is saved: an area is worked out from the town's (or dungeon's) own data and comes out the
same every time; it only changes when the place does. What the party has seen and which doors are open
is kept in the game state (game/explore.py).

Area pieces, per Level (all in absolute squares):
    floor[y][x]   floor kind ("cobble", "wood"...; "roof" / "earth" / "void" can't be stood on)
    walls         {(x, y): wall kind};  windows: set of wall squares you can see through
    doors         {(x, y): {"kind": "door"|"street"|"exit", "bid", "room", "lock", "horizontal", ...}}
    props         [AProp]  (furniture, trees, stairs...)
    zone[y][x]    index into Area.zone_names: the location (street or room) a square belongs to
    stairs        {(x, y): (level key, x, y)}
    stations      {(x, y): {"kind": "bar"|"counter"|..., "room": location, "spot": (x, y)}}
    exits         {(x, y): {"direction", "road", "street"}}    (town edges)
"""
from __future__ import annotations

import hashlib
import json
import math
import random
import zlib
from collections import deque
from dataclasses import dataclass

from game import places
from game import rooms as R
from game.art import tiles as TL

VOID, ROOF, EARTH, PASS = "void", "roof", "earth", "pass"
SOLID = {VOID, ROOF, EARTH, PASS}           # floors nobody stands on (PASS: an upper floor shows the street here)
OPAQUE = {VOID, EARTH}                      # floors nobody sees through

SIDES = {"N": (0, -1), "S": (0, 1), "E": (1, 0), "W": (-1, 0)}
TURN = {0: "S", 1: "W", 2: "N", 3: "E"}      # which way a building's front faces after q quarter turns

WALL_FOR_STYLE = {"Wooden": "wood_wall", "Rustic": "wood_wall", "Stone": "stone_wall", "Rich": "stone_wall",
                  "Brick": "brick_wall"}
STONE_KINDS = {"Temple", "Castle", "Barracks", "Town hall", "Smithy", "Guild hall", "Library", "Mansion"}
TERRAIN_FLOOR = {"Plains": "grass", "Forest": "grass", "Hills": "grass", "Mountains": "dirt", "Coast": "grass",
                 "Swamp": "grass", "Desert": "sand", "Arctic": "snow", "Taiga": "grass", "Tundra": "snow",
                 "Savanna": "grass", "Jungle": "grass", "Badlands": "dirt"}
LOCK_DC = {"House": 12, "Shop": 14, "Tavern": 13, "Inn": 13, "Smithy": 14, "Market": 13, "Warehouse": 15,
           "Stable": 12, "Temple": 15, "Library": 15, "Guild hall": 16, "Town hall": 16, "Mansion": 17,
           "Barracks": 18, "Castle": 19, "Bank": 18, "Jail": 18,
           "Casino": 16, "Arena": 15, "Brothel": 14}
_cache: dict[str, "Area"] = {}


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(str(k) for k in key).encode("utf-8")))


# ======================================================================
# The pieces
# ======================================================================
@dataclass
class AProp:
    id: str
    x: int
    y: int
    variant: int = 0

    @property
    def defn(self) -> TL.PropDef:
        return TL.prop_def(self.id)

    def cells(self) -> list[tuple[int, int]]:
        d = self.defn
        return [(self.x + dx, self.y + dy) for dy in range(d.h) for dx in range(d.w)]


class Level:
    def __init__(self, key: str, ox: int, oy: int, w: int, h: int, fill: str = "grass", bid: str = "",
                 floor_no: int = 0, overlay: bool = False, roof: str = "") -> None:
        self.key, self.ox, self.oy, self.w, self.h = key, ox, oy, w, h
        self.floor = [[fill] * w for _ in range(h)]
        self.walls: dict[tuple[int, int], str] = {}
        self.windows: set[tuple[int, int]] = set()
        self.doors: dict[tuple[int, int], dict] = {}
        self.props: list[AProp] = []
        self.prop_cells: dict[tuple[int, int], AProp] = {}
        self.water: dict[tuple[int, int], str] = {}
        self.zone = [[0] * w for _ in range(h)]
        self.stairs: dict[tuple[int, int], tuple[str, int, int]] = {}
        self.stations: dict[tuple[int, int], dict] = {}
        self.exits: dict[tuple[int, int], dict] = {}
        self.bid, self.floor_no, self.overlay, self.roof = bid, floor_no, overlay, roof
        self.dark = False
        self.names: list[str] | None = None        # what zone numbers mean (the area's list)
        self.traps: dict[tuple[int, int], dict] = {}   # a dungeon's: square -> {"dungeon", "name"} (game/traps.py)

    def loc_at(self, x: int, y: int) -> str:
        z = self.zone_at(x, y)
        names = self.names or [""]
        return names[z] if 0 <= z < len(names) else ""

    # ---- squares
    def inside(self, x: int, y: int) -> bool:
        return self.ox <= x < self.ox + self.w and self.oy <= y < self.oy + self.h

    def floor_at(self, x: int, y: int) -> str:
        if self.inside(x, y):
            return self.floor[y - self.oy][x - self.ox]
        return EARTH if self.underground else VOID

    @property
    def underground(self) -> bool:
        return self.overlay and self.floor_no < 0

    def set_floor(self, x: int, y: int, kind: str) -> None:
        if self.inside(x, y):
            self.floor[y - self.oy][x - self.ox] = kind

    def zone_at(self, x: int, y: int) -> int:
        return self.zone[y - self.oy][x - self.ox] if self.inside(x, y) else 0

    def set_zone(self, x: int, y: int, z: int) -> None:
        if self.inside(x, y):
            self.zone[y - self.oy][x - self.ox] = z

    # ---- things
    def free(self, x: int, y: int) -> bool:
        """Open floor with nothing on it (for putting things down)."""
        return (self.inside(x, y) and self.floor_at(x, y) not in SOLID and (x, y) not in self.walls
                and (x, y) not in self.doors and (x, y) not in self.prop_cells and (x, y) not in self.water
                and (x, y) not in self.stairs)

    def add_prop(self, pid: str, x: int, y: int, variant: int = 0, force: bool = False) -> AProp | None:
        p = AProp(pid, x, y, variant)
        cells = p.cells()
        if not force and not all(self.free(cx, cy) for cx, cy in cells):
            return None
        self.props.append(p)
        for c in cells:
            self.prop_cells[c] = p
        return p

    def remove_prop(self, p: AProp) -> None:
        if p in self.props:
            self.props.remove(p)
        for c in p.cells():
            if self.prop_cells.get(c) is p:
                del self.prop_cells[c]

    def blocks(self, x: int, y: int) -> bool:
        """Can't be walked into (doors aside: whether they're shut is the game's business)."""
        if not self.inside(x, y) or self.floor_at(x, y) in SOLID or (x, y) in self.walls or (x, y) in self.water:
            return True
        p = self.prop_cells.get((x, y))
        return bool(p and p.defn.blocks)

    def opaque(self, x: int, y: int) -> bool:
        if not self.inside(x, y) or self.floor_at(x, y) in OPAQUE:
            return True
        return (x, y) in self.walls and (x, y) not in self.windows


class Area:
    def __init__(self, key: str, kind: str, w: int, h: int, title: str = "") -> None:
        self.key, self.kind, self.w, self.h, self.title = key, kind, w, h, title
        self.levels: dict[str, Level] = {}
        self.base_key = "0"
        self.zone_names = [""]
        self._zone_ix: dict[str, int] = {}
        self.roofs: dict[str, dict] = {}         # building id -> {"cells", "style", "name", "filler"}
        self.cell_building: dict[tuple[int, int], str] = {}
        self.porch: set[tuple[int, int]] = set()      # under a building's upper floor, but outdoors
        self.buildings: dict[str, dict] = {}     # building id -> {"rect", "levels": {floor: key}, "door"}
        self.spawns: dict[str, tuple[str, int, int]] = {}
        self.gates: dict[str, tuple[int, int]] = {}
        self.outdoor = kind == "town"
        self.sig = ""
        self.terrain = "Plains"

    def finish(self) -> None:
        """Give every level the area's zone names (levels can end up in another area: see shifted())."""
        for lv in self.levels.values():
            lv.names = self.zone_names

    def all_levels(self) -> list:
        """Every level with things on it (for a world: each laid-in site's ground and upper floors)."""
        return list(self.levels.values())

    def gates_of(self, town) -> dict:
        return self.gates

    def zone_id(self, loc: str) -> int:
        if loc not in self._zone_ix:
            self._zone_ix[loc] = len(self.zone_names)
            self.zone_names.append(loc)
        return self._zone_ix[loc]

    @property
    def base(self) -> Level:
        return self.levels[self.base_key]

    def level(self, key: str) -> Level:
        return self.levels.get(key) or self.base

    def layer(self, key: str, x: int, y: int) -> Level:
        """The level that owns a square when standing on level `key`: a building's upper floor covers
        its own footprint, the street shows everywhere else."""
        lv = self.levels.get(key) or self.base
        if lv.overlay and not lv.underground and (not lv.inside(x, y) or lv.floor_at(x, y) == PASS):
            return self.base
        return lv

# ======================================================================
# Public entry points
# ======================================================================
def for_spot(world, spot) -> Area | None:
    """The walkable map for where the party is (None where there isn't one yet: the wilds, roads...)."""
    if spot is None:
        return None
    if spot.kind in ("street", "building") and spot.town is not None:
        return town_area(world, spot.town)
    if spot.kind == "dungeon":
        return dungeon_area(world, spot.extra["dungeon"])
    return None


def town_area(world, town) -> Area:
    if town.fields.get("settlement"):                # the party's own: its walking map is its claim
        from game import worldmap as WM
        site = WM.world_area(world).load_town(town)
        if site is not None:
            return site.area
    sig = _town_sig(world, town)
    key = f"town:{town.id}"
    a = _cache.get(key)
    if a is not None and a.sig == sig:
        return a
    a = build_town(world, town)
    a.sig = _town_sig(world, town)              # rooms made on the way may have changed it
    _tag(world, a, f"town:{town.id}")
    _cache[key] = a
    return a


def dungeon_area(world, d) -> Area:
    from game import dungeons as DG
    DG.ensure_rooms(world, d)
    d = world.entities.get(d.id)
    sig = _hash(d.fields.get("rooms") or [], d.fields.get("kind"))
    key = f"dungeon:{d.id}"
    a = _cache.get(key)
    if a is not None and a.sig == sig:
        return a
    a = build_dungeon(world, d)
    a.sig = sig
    _tag(world, a, f"dungeon:{d.id}")
    _cache[key] = a
    return a


def _tag(world, a: Area, prefix: str) -> None:
    """Give the levels their change keys and lay this playthrough's changes on (game/landchanges.py)."""
    from game import landchanges
    landchanges.tag_area(a, prefix)
    landchanges.apply_area(world, a)


def forget(key: str | None = None) -> None:
    if key is None:
        _cache.clear()
    else:
        _cache.pop(key, None)


def _hash(*parts) -> str:
    return hashlib.md5(json.dumps(parts, sort_keys=True, default=str).encode("utf-8")).hexdigest()[:16]


def _town_sig(world, town) -> str:
    bs = [(b.id, b.fields.get("kind"), b.fields.get("street"), b.fields.get("rooms") or [],
           b.fields.get("interior"), b.fields.get("owner"), b.fields.get("facilities") if b.fields.get("owner") else None)
          for b in places.buildings_in(world, town)]
    from game import estate
    return _hash(town.fields.get("streets"), town.fields.get("roads"), town.fields.get("population"),
                 town.fields.get("terrain"), town.fields.get("kind"), town.fields.get("defenses"), bs,
                 estate.town_sig(world, town))


# ======================================================================
# Building geometry
# ======================================================================
def _rot_rect(x, y, w, h, W, H, q):
    """Turn a rectangle inside a W x H box clockwise q quarter turns. Returns (x, y, w, h), new W, H."""
    for _ in range(q % 4):
        x, y, w, h = H - (y + h), x, h, w
        W, H = H, W
    return (x, y, w, h), W, H


class Plan:
    """One building's rooms, turned to face its street and placed in the town."""

    def __init__(self, b, rows: list[dict], world=None) -> None:
        self.b, self.rows, self.world = b, rows, world
        self.id = b.id if b is not None else ""
        ground = [r for r in rows if int(r.get("floor") or 0) == 0] or rows
        self.x0 = min(int(r["x"]) for r in ground)
        self.y0 = min(int(r["y"]) for r in ground)
        self.W = max(int(r["x"]) + int(r["w"]) for r in ground) - self.x0
        self.H = max(int(r["y"]) + int(r["h"]) for r in ground) - self.y0
        self.q = 0
        self.px = self.py = 0                    # top-left of the footprint in the town

    @property
    def along(self) -> int:                      # width of the front (squares, walls included)
        return self.W + 1

    @property
    def depth(self) -> int:
        return self.H + 1

    def size(self) -> tuple[int, int]:
        return (self.depth, self.along) if self.q % 2 else (self.along, self.depth)

    def rect_of(self, row: dict) -> tuple[int, int, int, int]:
        (x, y, w, h), _W, _H = _rot_rect(int(row["x"]) - self.x0, int(row["y"]) - self.y0, int(row["w"]),
                                         int(row["h"]), self.W, self.H, self.q)
        return x + self.px, y + self.py, w, h

    def facing(self) -> str:
        return TURN[self.q % 4]


def _fake_rows(kind: str) -> list[dict]:
    return [{"name": "Main room", "type": "Entrance", "tile": "", "floor": 0, "x": 0, "y": 0, "w": 9, "h": 7,
             "connects": ""}]


def _wall_kind(b) -> str:
    style = (b.fields.get("interior") or "") if b is not None else ""
    if style in WALL_FOR_STYLE:
        return WALL_FOR_STYLE[style]
    return "stone_wall" if (b.fields.get("kind") if b is not None else "") in STONE_KINDS else "wood_wall"


def _roof_style(b) -> str:
    style = (b.fields.get("interior") or "") if b is not None else ""
    if style in TL.ROOF_STYLES:
        return style
    kind = (b.fields.get("kind") or "") if b is not None else ""
    return "Stone" if kind in STONE_KINDS else "Wooden"


def _room_floor(b, row: dict, category: str = "building") -> str:
    tile = (row.get("tile") or "").lower()
    kind = (b.fields.get("kind") or "") if b is not None else ""
    if category == "dungeon":
        return "cave" if kind in ("Cave", "Lair", "Mine") else "dungeon"
    if int(row.get("floor") or 0) < 0:
        return "stone" if kind in STONE_KINDS else "dirt"
    if any(w in tile for w in ("kitchen", "forge", "smithy", "stable", "yard", "bath", "vault", "cell")):
        return "stone"
    if kind in ("Temple", "Castle", "Town hall", "Barracks", "Guild hall", "Smithy"):
        return "stone"
    if row.get("type") == "Private" and kind in ("Mansion", "Castle"):
        return "carpet"
    return "wood"


def _room_loc(bid: str, rows: list[dict], row: dict, dungeon: bool = False) -> str:
    if dungeon:
        from game import dungeons as DG
        return DG.room_id(bid, row["name"])
    return bid if row is rows[0] else places.room_id(bid, row["name"])


def _shared_door(a, b) -> tuple[tuple[int, int], bool] | None:
    """The doorway square between two touching rooms (x, y, w, h), and whether the wall it's in runs
    left to right."""
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    for (p, q) in ((a, b), (b, a)):
        px, py, pw, ph = p
        qx, qy, qw, qh = q
        if px + pw == qx:                            # q is right of p: the wall is the column x = qx
            lo, hi = max(py, qy) + 1, min(py + ph, qy + qh) - 1
            if lo <= hi:
                return (qx, (lo + hi) // 2), False
        if py + ph == qy:                            # q is below p: the wall is the row y = qy
            lo, hi = max(px, qx) + 1, min(px + pw, qx + qw) - 1
            if lo <= hi:
                return ((lo + hi) // 2, qy), True
    return None


def stamp_rooms(area: Area, lv: Level, rects: list[tuple[dict, tuple]], bid: str, rows: list[dict],
                wall: str, floor_for, dungeon: bool = False) -> set[tuple[int, int]]:
    """Lay rooms into a level: floors, walls around each, doors between linked rooms. Returns the
    building's squares (walls and floors) on this level."""
    cells = set()
    names = {row["name"]: (row, rect) for row, rect in rects}
    for row, (x, y, w, h) in rects:
        z = area.zone_id(_room_loc(bid, rows, row, dungeon))
        fl = floor_for(row)
        for yy in range(y + 1, y + h):
            for xx in range(x + 1, x + w):
                lv.set_floor(xx, yy, fl)
                lv.set_zone(xx, yy, z)
                lv.walls.pop((xx, yy), None)
                cells.add((xx, yy))
    interior = set(cells)
    for row, (x, y, w, h) in rects:
        fl = floor_for(row)
        edge = [(xx, yy) for xx in range(x, x + w + 1) for yy in (y, y + h)] + \
               [(xx, yy) for yy in range(y, y + h + 1) for xx in (x, x + w)]
        for c in edge:
            if c not in interior:
                lv.walls[c] = wall
                if lv.floor_at(*c) in SOLID:
                    lv.set_floor(c[0], c[1], fl)
                cells.add(c)
    for row, rect in rects:
        for other in R.links(rows, row["name"]):
            if other not in names or other < row["name"]:
                continue
            orow, orect = names[other]
            if int(orow.get("floor") or 0) != int(row.get("floor") or 0):
                continue
            got = _shared_door(rect, orect)
            if got is None:
                continue
            (dx, dy), horizontal = got
            lv.walls.pop((dx, dy), None)
            lv.set_floor(dx, dy, floor_for(row))
            secret = bool(orow.get("secret") or row.get("secret"))
            lv.doors[(dx, dy)] = {"kind": "door", "bid": bid, "horizontal": horizontal, "wall": wall,
                                  "rooms": (_room_loc(bid, rows, row, dungeon), _room_loc(bid, rows, orow, dungeon)),
                                  "names": (row["name"], other), "lock": 0, "room": "", "secret": secret}
    return cells


def _windows(lv: Level, cells: set, doors: set, every: int = 3) -> None:
    """Glaze some of the outside walls (never corners, never right by a door)."""
    for (x, y) in [c for c in cells if c in lv.walls]:
        horiz = (x - 1, y) in lv.walls and (x + 1, y) in lv.walls
        vert = (x, y - 1) in lv.walls and (x, y + 1) in lv.walls
        if horiz == vert:
            continue
        out = [(x, y - 1), (x, y + 1)] if horiz else [(x - 1, y), (x + 1, y)]
        if not any(c not in cells for c in out):
            continue                                 # an inside wall
        if any(c in doors for c in ((x, y), (x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1))):
            continue
        if (x + y) % every == 0:
            lv.windows.add((x, y))


# ======================================================================
# Furniture
# ======================================================================
def _room_doors(lv: Level, x: int, y: int, w: int, h: int) -> dict[str, list[tuple[int, int]]]:
    out = {"N": [], "S": [], "E": [], "W": []}
    for (dx, dy) in list(lv.doors) + list(lv.stairs):
        if dy == y and x < dx < x + w:
            out["N"].append((dx, dy))
        elif dy == y + h and x < dx < x + w:
            out["S"].append((dx, dy))
        elif dx == x and y < dy < y + h:
            out["W"].append((dx, dy))
        elif dx == x + w and y < dy < y + h:
            out["E"].append((dx, dy))
    return out


def _connected(lv: Level, room: tuple, must: list[tuple[int, int]]) -> bool:
    x, y, w, h = room
    must = [c for c in must if x < c[0] < x + w and y < c[1] < y + h]
    if len(must) <= 1:
        return True
    start = must[0]
    seen = {start}
    todo = deque([start])
    while todo:
        cx, cy = todo.popleft()
        for dx, dy in SIDES.values():
            n = (cx + dx, cy + dy)
            if n in seen or not (x < n[0] < x + w and y < n[1] < y + h) or lv.blocks(*n):
                continue
            seen.add(n)
            todo.append(n)
    return all(c in seen for c in must)


def furnish(lv: Level, rect: tuple, feats: list[str], rng: random.Random, room_loc: str, kind: str = "",
            role: str = "", dungeon: bool = False, dkind: str = "", extra=()) -> None:
    """Put a room's furniture in: what its tile's features call for, kept clear of its doors."""
    x, y, w, h = rect
    ix0, iy0, ix1, iy1 = x + 1, y + 1, x + w - 1, y + h - 1        # inside squares: ix0..ix1-1
    iw, ih = ix1 - ix0, iy1 - iy0
    if iw < 1 or ih < 1:
        return
    doors = _room_doors(lv, x, y, w, h)
    inside_of = []
    for side, lst in doors.items():
        for dx, dy in lst:
            sx, sy = SIDES[side]
            inside_of.append((dx - sx, dy - sy))
    keep = set()
    for cx, cy in inside_of:
        for ddx in (-1, 0, 1):
            for ddy in (-1, 0, 1):
                keep.add((cx + ddx, cy + ddy))
    keep |= set(lv.stairs)
    must = list(inside_of) + [c for c in lv.stairs if ix0 <= c[0] < ix1 and iy0 <= c[1] < iy1]

    def put(pid, px, py, var=0, station: str = "") -> AProp | None:
        d = TL.prop_def(pid)
        cells = [(px + a, py + b) for b in range(d.h) for a in range(d.w)]
        if any(not (ix0 <= cx < ix1 and iy0 <= cy < iy1) or c in keep for c in cells for cx, cy in [c]):
            return None
        p = lv.add_prop(pid, px, py, var)
        if p is None:
            return None
        if d.blocks and not _connected(lv, rect, must + reserved):
            lv.remove_prop(p)
            return None
        if station:
            for c in cells:
                lv.stations[c] = {"kind": station, "room": room_loc, "spot": None}
        return p

    reserved: list[tuple[int, int]] = []

    def quiet_wall() -> str:
        order = sorted(("N", "S"), key=lambda s: (len(doors[s]), 0 if s == "N" else 1))
        return order[0]

    def along_wall(pid, side, count=1, gap=0, start=None, station="", var=0) -> list[AProp]:
        d = TL.prop_def(pid)
        placed = []
        row_y = iy0 if side == "N" else iy1 - d.h
        if side in ("E", "W"):
            col_x = ix0 if side == "W" else ix1 - d.w
            ys = list(range(iy0, iy1 - d.h + 1, d.h + gap))
            rng.shuffle(ys) if start is None else None
            for yy in ys:
                if len(placed) >= count:
                    break
                p = put(pid, col_x, yy, var, station)
                if p:
                    placed.append(p)
            return placed
        xs = list(range(ix0 if start is None else start, ix1 - d.w + 1, d.w + gap))
        for xx in xs:
            if len(placed) >= count:
                break
            p = put(pid, xx, row_y, var, station)
            if p:
                placed.append(p)
        return placed

    def worker_spot(props: list[AProp], side: str) -> None:
        """Where someone working at this station stands: behind it, between it and the wall."""
        for p in props:
            for cx, cy in p.cells():
                for dx, dy in ((0, -1) if side == "S" else (0, 1), (0, 1) if side == "S" else (0, -1),
                               (1, 0), (-1, 0)):
                    s = (cx + dx, cy + dy)
                    if ix0 <= s[0] < ix1 and iy0 <= s[1] < iy1 and lv.free(*s):
                        for c in p.cells():
                            lv.stations[c]["spot"] = s
                        return

    def wall_spots(first: tuple, pw: int = 1) -> list[tuple[int, int]]:
        """Where a piece goes: its usual square first, then anywhere along the walls (for furniture the
        party adds to a room that's already got its own)."""
        out = [first]
        for yy in (iy0, iy1 - 1):
            out += [(xx, yy) for xx in range(ix0, ix1 - pw + 1)]
        for xx in (ix0, ix1 - pw):
            out += [(xx, yy) for yy in range(iy0, iy1)]
        return out

    def put_somewhere(pid, first: tuple, station: str = "", var: int = 0, pw: int = 1) -> AProp | None:
        for cx, cy in wall_spots(first, pw):
            p = put(pid, cx, cy, var, station)
            if p is not None:
                return p
        return None

    area_sq = iw * ih
    feats = list(feats or [])
    if dungeon:
        feats = feats or _dungeon_feats(role, dkind, rng)
    for f in feats:
        if f in ("bar", "counter"):
            side = quiet_wall()
            n = 2 if (f == "bar" and iw >= 6) else 1
            start = ix0 + max(0, (iw - n * 2) // 2) if f == "counter" else ix0 + 1
            if side == "N" and ih >= 3:
                row = iy0 + 1                                 # a strip behind for whoever serves
                ps = []
                for k in range(n):
                    p = put("counter", start + k * 2, row, 0, f)
                    if p:
                        ps.append(p)
                if ps:
                    worker_spot(ps, "N")
                    if f == "bar":
                        put("barrel", ix0, iy0)
                        put("barrel", ix0 + 1, iy0) if iw > 6 else None
                    else:
                        along_wall("bookshelf", "N", 1, start=start)
            else:
                ps = along_wall("counter", side, n, start=start, station=f)
                worker_spot(ps, side)
        elif f == "forge":
            for cx, cy in ((ix1 - 2, iy0), (ix0, iy0), (ix1 - 2, iy1 - 2), (ix0, iy1 - 2)):
                p = put("forge", cx, cy, 0, "forge")
                if p:
                    worker_spot([p], "N")
                    for ax, ay in ((cx - 1, cy + 2), (cx + 2, cy + 2), (cx, cy + 2), (cx - 1, cy)):
                        if put("anvil", ax, ay, 0, "forge"):
                            break
                    break
        elif f == "altar":
            side = quiet_wall()
            ax = ix0 + (iw - 2) // 2
            ay = iy0 if side == "N" else iy1 - 1
            p = put_somewhere("altar", (ax, ay), "altar", 0, 2)
            if p:
                ax, ay = p.x, p.y
                worker_spot([p], side)
                put("brazier", ax - 1, ay)
                put("brazier", ax + 2, ay)
        elif f == "beds":
            n = max(1, min(4, area_sq // 10))
            ps = along_wall("bed", "N", n, gap=1, start=ix0 + (0 if iw % 2 else 0), station="beds")
            if len(ps) < n:
                along_wall("bed", "S", n - len(ps), gap=1, station="beds")
            put("chest", ix1 - 1, iy1 - 1)
        elif f == "hearth":
            side = "W" if not doors["W"] else "E"
            col = ix0 if side == "W" else ix1 - 1
            put_somewhere("brazier", (col, iy0 + ih // 2), "hearth")
        elif f == "tables":
            n = max(1, min(4, area_sq // 14))
            spots = []
            for ty in range(iy0 + 1, iy1 - 1, 3):
                for tx in range(ix0 + 1, ix1 - 2, 4):
                    spots.append((tx, ty))
            rng.shuffle(spots)
            for tx, ty in spots[:n + 2]:
                if n <= 0:
                    break
                if put("table", tx, ty, rng.randrange(3), "tables"):
                    n -= 1
                    for cx in (tx, tx + 1):
                        if rng.random() < 0.7:
                            put("chair", cx, ty - 1)
                        if rng.random() < 0.7:
                            put("chair", cx, ty + 1)
        elif f == "shelves":
            for side in ("N", "S"):
                along_wall("bookshelf", side, max(1, iw // 3), gap=0, var=rng.randrange(3))
        elif f == "crates":
            for cx, cy in ((ix0, iy0), (ix1 - 1, iy1 - 1), (ix1 - 1, iy0), (ix0, iy1 - 1)):
                if rng.random() < 0.75:
                    put(rng.choice(["crate", "barrel", "crate"]), cx, cy)
        elif f == "pews":
            for ty in range(iy0 + 2, iy1 - 1, 2):
                for tx in (ix0 + 1, ix1 - 3):
                    if tx >= ix0 and tx + 2 <= ix1 and abs((tx + 1) - (ix0 + iw / 2)) > 1:
                        put("pew", tx, ty)
        elif f == "stalls":
            for cx in range(ix0, ix1, 3):
                put("fence", cx, iy0 + min(2, ih - 1))
                put("haybale", cx, iy0)
        elif f == "racks":
            along_wall("rack", quiet_wall(), max(1, iw // 4), gap=1, var=rng.randrange(3))
        elif f == "desk":
            tx, ty = ix0 + max(0, (iw - 2) // 2), iy0 + 1
            if put("table", tx, ty, 0, "desk"):
                put("chair", tx, ty - 1)
                for c in ((tx, ty), (tx + 1, ty)):
                    lv.stations[c]["spot"] = (tx, ty - 1) if lv.free(tx, ty - 1) or (tx, ty - 1) in lv.prop_cells \
                        else None
        elif f == "bath":
            put_somewhere("tub", (ix0 + max(0, (iw - 2) // 2), iy0), "", 0, 2)
        elif f == "throne":
            side = quiet_wall()
            tx = ix0 + iw // 2
            ty = iy0 if side == "N" else iy1 - 1
            if put("throne", tx, ty, 0, "throne"):
                put("rug", tx - 1, ty + 1 if side == "N" else ty - 2)
        elif f == "cot":                                   # a jail cell's (game/jail.py): against the back wall
            for cx in (ix0, ix1 - 1, ix0 + 1):
                if put("bed", cx, iy0, 0, "cot"):
                    break
        elif f == "evidence":                              # the jail's evidence box (game/jail.py)
            for cx, cy in ((ix1 - 1, iy0), (ix0 + iw // 2, iy0), (ix1 - 1, iy1 - 1), (ix0, iy0)):
                if put("chest", cx, cy, 0, "evidence"):
                    break
        elif f == "chest":
            for cx, cy in ((ix0 + iw // 2, iy0), (ix1 - 1, iy0), (ix0, iy0)):
                if put("chest", cx, cy, 0, "chest"):
                    break
        elif f == "vault":                                 # a bank's strongboxes (game/bank.py)
            for cx, cy in ((ix0 + iw // 2, iy0), (ix1 - 1, iy0), (ix0, iy0), (ix0, iy1 - 1)):
                if put("chest", cx, cy, 0, "vault"):
                    break
        elif f == "pillars":
            if iw >= 6 and ih >= 6:
                for cx in (ix0 + 1, ix1 - 2):
                    for cy in (iy0 + 1, iy1 - 2):
                        put("pillar", cx, cy)
        elif f == "rubble":
            for _ in range(max(1, area_sq // 12)):
                put(rng.choice(["rubble", "bones", "rubble"]), rng.randrange(ix0, ix1), rng.randrange(iy0, iy1),
                    rng.randrange(3))
        elif f == "cave":
            for _ in range(max(1, area_sq // 10)):
                put(rng.choice(["rock", "mushrooms", "rubble", "mushrooms"]), rng.randrange(ix0, ix1),
                    rng.randrange(iy0, iy1), rng.randrange(4))
        elif f == "statue":
            put("statue", ix0 + iw // 2, iy0 + ih // 2, 0, "special")
        elif f == "special":
            p = put("altar", ix0 + max(0, (iw - 2) // 2), iy0 + max(0, ih // 2 - 1), 0, "special")
            if p is None:
                put("statue", ix0 + iw // 2, iy0 + ih // 2, 0, "special")
        elif f == "braziers":
            for cx, cy in ((ix0, iy0), (ix1 - 1, iy0)):
                put("brazier", cx, cy)
        elif f == "graves":
            for cx in range(ix0 + 1, ix1 - 1, 2):
                for cy in range(iy0 + 1, iy1 - 1, 3):
                    if rng.random() < 0.6:
                        put("grave", cx, cy)


def _dungeon_feats(role: str, dkind: str, rng: random.Random) -> list[str]:
    cave = dkind in ("Cave", "Lair", "Mine")
    if role in ("Treasure", "Treasure room"):
        return ["chest", "crates"]
    if role == "Boss":
        return ["pillars", "braziers"] + (["cave"] if cave else ["throne"] if dkind in ("Fortress", "Tower") else [])
    if role == "Special":
        return ["special"]
    if role == "Entrance":
        return ["cave"] if cave else []
    if role in ("Hallway", "Stairs"):
        return []
    feats = ["cave"] if cave else [rng.choice(["rubble", "pillars", "crates", "rubble"])]
    if dkind == "Crypt" and rng.random() < 0.5:
        feats.append("graves")
    return feats


def _stairs_between(area: Area, levels: dict[int, Level], rects_by_floor: dict[int, list], rows: list[dict],
                    rng: random.Random) -> None:
    """Join linked rooms on different floors with a flight of stairs at each end."""
    where = {}
    for fl, lst in rects_by_floor.items():
        for row, rect in lst:
            where[row["name"]] = (fl, rect)
    done = set()
    for name, (fl, rect) in where.items():
        for other in R.links(rows, name):
            if other not in where or (other, name) in done:
                continue
            ofl, orect = where[other]
            if ofl == fl:
                continue
            done.add((name, other))
            a, b = levels[fl], levels[ofl]
            ca = _stair_cell(a, rect, orect, rng)
            cb = _stair_cell(b, orect, rect, rng, prefer=ca)
            if ca is None or cb is None:
                continue
            a.stairs[ca] = (b.key, cb[0], cb[1])
            b.stairs[cb] = (a.key, ca[0], ca[1])
            a.add_prop("stairs_up" if ofl > fl else "stairs_down", ca[0], ca[1], force=True)
            b.add_prop("stairs_up" if fl > ofl else "stairs_down", cb[0], cb[1], force=True)


def _stair_cell(lv: Level, rect, other, rng, prefer=None) -> tuple[int, int] | None:
    x, y, w, h = rect
    cand = [(cx, cy) for cy in range(y + 1, y + h) for cx in range(x + 1, x + w)]
    if not cand:
        return None
    ox, oy, ow, oh = other
    both = [c for c in cand if ox < c[0] < ox + ow and oy < c[1] < oy + oh]
    pool = both or cand
    if prefer is not None and prefer in pool:
        return prefer

    def score(c):
        cx, cy = c
        edge = min(cx - x, x + w - cx, cy - y, y + h - cy)         # near a wall, in a corner
        near_door = any(abs(cx - dx) + abs(cy - dy) <= 1 for dx, dy in lv.doors)
        return (near_door, edge, (cx * 7 + cy * 13) % 5)
    for c in sorted(pool, key=score):
        if lv.free(*c):
            return c
    return pool[0]


# ======================================================================
# Towns
# ======================================================================
def _street_width(town) -> int:
    pop = int(town.fields.get("population") or 0)
    kind = town.fields.get("kind") or ""
    if kind in ("City", "Capital") or pop >= 3000:
        return 5
    if kind == "Town" or pop >= 400:
        return 4
    return 3


def build_town(world, town, embedded: bool = False) -> Area:
    """A town's map. embedded: for laying into the walkable world (game/worldmap.py), which brings its
    own roads in and has no map edge to leave by."""
    from game.townplan import _links
    rng = _rng("townmap", town.id)
    streets = places.streets_of(town)
    names = [s["name"] for s in streets]
    links = _links(streets)
    SW = _street_width(town)
    street_floor = "cobble" if SW >= 4 else "path"
    terrain = town.fields.get("terrain") or "Plains"
    ground = TERRAIN_FLOOR.get(terrain, "grass")
    pop = int(town.fields.get("population") or 0)

    # ---- the buildings, each turned to face its street ------------------
    plans: list[Plan] = []
    by_street: dict[str, list[Plan]] = {n: [] for n in names}
    made_rooms = False
    on_lots: list = []                                # the party's buildings on lots it bought (game/estate.py)
    for b in places.buildings_in(world, town):
        if b.fields.get("claim") and b.fields.get("lot") is not None:
            on_lots.append(b)
            continue
        had = places.building_rooms(b)
        rows = R.building_rows(world, b, save=False)
        made_rooms = made_rooms or (bool(rows) and rows != had)          # (new, or a jail laid out again)
        rows = rows or _fake_rows(b.fields.get("kind") or "")
        p = Plan(b, rows, world)
        plans.append(p)
        st = places.street_of_building(world, b)
        by_street.setdefault(st if st in by_street else names[0], []).append(p)
    if made_rooms:
        if embedded:                                  # walking past in the open world: write it later
            world._unsaved_rooms = True               # (Explorer.save), not mid-stride
        else:
            world.entities.save("building")
    per_street = {"Capital": 30, "City": 22}.get(town.fields.get("kind") or "", 12)
    houses_total = max(3, min(per_street * len(names), pop // 25))
    if plans and pop < 200:
        houses_total = max(2, houses_total - len(plans))
    fillers: dict[str, int] = {n: houses_total // len(names) + (1 if i < houses_total % len(names) else 0)
                               for i, n in enumerate(names)}

    def need_len(n: str) -> int:
        lots = sum(p.along + 2 for p in by_street.get(n, []))
        lots += fillers.get(n, 0) * 11
        return max(18, lots // 2 + 8)

    # ---- streets ---------------------------------------------------------
    placed: dict[str, dict] = {}
    first = names[0]
    L = need_len(first)
    placed[first] = {"name": first, "x1": 0, "y1": 0, "x2": L, "y2": 0, "h": True, "parent": ""}
    queue, turn = [first], {}
    while queue:
        cur = queue.pop(0)
        seg = placed[cur]
        kids = [k for k in links.get(cur, []) if k not in placed]
        for i, k in enumerate(kids):
            t = (i + 1) / (len(kids) + 1)
            kl = need_len(k)
            flip = 1 if turn.get(cur, 0) % 2 == 0 else -1
            turn[cur] = turn.get(cur, 0) + 1
            if seg["h"]:
                x = round(seg["x1"] + (seg["x2"] - seg["x1"]) * t)
                placed[k] = {"name": k, "x1": x, "y1": seg["y1"], "x2": x, "y2": seg["y1"] + flip * kl, "h": False,
                             "parent": cur}
            else:
                y = round(seg["y1"] + (seg["y2"] - seg["y1"]) * t)
                placed[k] = {"name": k, "x1": seg["x1"], "y1": y, "x2": seg["x1"] + flip * kl, "y2": y, "h": True,
                             "parent": cur}
            queue.append(k)
    for n in names:
        if n not in placed:
            y = 30 * (len(placed) + 1)
            placed[n] = {"name": n, "x1": 0, "y1": y, "x2": need_len(n), "y2": y, "h": True, "parent": first}

    def street_cells(seg) -> set:
        out = set()
        lo = -(SW // 2)
        if seg["h"]:
            a, b = sorted((seg["x1"], seg["x2"]))
            for x in range(a - SW // 2, b + SW - SW // 2):
                for d in range(SW):
                    out.add((x, seg["y1"] + lo + d))
        else:
            a, b = sorted((seg["y1"], seg["y2"]))
            for y in range(a - SW // 2, b + SW - SW // 2):
                for d in range(SW):
                    out.add((seg["x1"] + lo + d, y))
        return out

    street_of: dict[tuple, str] = {}
    for n in names:                                   # parents first: they keep the crossings
        for c in street_cells(placed[n]):
            street_of.setdefault(c, n)
    plaza = None
    if SW >= 4:                                       # a market square in the middle of the main street
        seg = placed[first]
        cx = (seg["x1"] + seg["x2"]) // 2
        size = 9 if SW >= 5 else 7
        plaza = (cx - size // 2, -size // 2, size, size)
        for yy in range(plaza[1], plaza[1] + size):
            for xx in range(plaza[0], plaza[0] + size):
                street_of.setdefault((xx, yy), first)

    taken: list[tuple[int, int, int, int]] = []

    def free_rect(x, y, w, h, pad=1) -> bool:
        for yy in range(y - pad, y + h + pad):
            for xx in range(x - pad, x + w + pad):
                if (xx, yy) in street_of:
                    return False
        for (ax, ay, aw, ah) in taken:
            if x - pad < ax + aw and ax < x + w + pad and y - pad < ay + ah and ay < y + h + pad:
                return False
        return True

    def lot_along(seg, p: Plan, side: int, pos: int) -> tuple[int, int] | None:
        """Top-left for a building at `pos` along the street on one side (-1 above/left, 1 below/right)."""
        half_lo = SW // 2
        half_hi = SW - SW // 2
        if seg["h"]:
            p.q = 0 if side < 0 else 2
            w, h = p.size()
            y = seg["y1"] - half_lo - 1 - h if side < 0 else seg["y1"] + half_hi + 1
            return pos, y
        p.q = 3 if side < 0 else 1
        w, h = p.size()
        x = seg["x1"] - half_lo - 1 - w if side < 0 else seg["x1"] + half_hi + 1
        return x, pos

    cursor: dict[tuple, int] = {}                  # (street, side): lots before here are all taken

    def place_on(seg, p: Plan, prefer: int, allow_grow: bool = True) -> bool:
        for attempt in range(4):
            if seg["h"]:
                lo, hi = sorted((seg["x1"], seg["x2"]))
            else:
                lo, hi = sorted((seg["y1"], seg["y2"]))
            best = None
            for side in (prefer, -prefer):
                pos = max(lo + 1, cursor.get((seg["name"], side), lo + 1))
                while pos + p.along <= hi and (best is None or pos < best[0]):
                    at = lot_along(seg, p, side, pos)
                    w, h = p.size()
                    if at and free_rect(at[0], at[1], w, h):
                        best = (pos, side)
                        break
                    pos += 1
            if best is not None:
                pos, side = best
                at = lot_along(seg, p, side, pos)
                w, h = p.size()
                p.px, p.py = at
                taken.append((at[0], at[1], w, h))
                key = (seg["name"], side)
                cursor[key] = max(cursor.get(key, lo + 1), pos + p.along)
                return True
            if not allow_grow:
                return False
            grow = p.along + 3                       # lengthen the street at its free end
            key2 = "x2" if seg["h"] else "y2"
            sign = 1 if seg[key2] >= (seg["x1"] if seg["h"] else seg["y1"]) else -1
            old = dict(seg)
            seg[key2] += sign * grow
            new = street_cells(seg) - street_cells(old)
            if any(_hits(c, taken) for c in new):
                seg.update(old)
                return False
            for c in new:
                street_of.setdefault(c, seg["name"])
        return False

    def place_anywhere(p: Plan, seg) -> bool:
        mx, my = (seg["x1"] + seg["x2"]) // 2, (seg["y1"] + seg["y2"]) // 2
        p.q = rng.randrange(4)
        w, h = p.size()
        for r in range(4, 160, 2):
            for k in range(0, 360, 15):
                x = int(mx + r * math.cos(math.radians(k))) - w // 2
                y = int(my + r * math.sin(math.radians(k))) - h // 2
                if free_rect(x, y, w, h, pad=2):
                    p.px, p.py = x, y
                    taken.append((x, y, w, h))
                    return True
        return False

    loose: list[Plan] = []
    for n in names:
        seg = placed[n]
        for i, p in enumerate(sorted(by_street.get(n, []), key=lambda p: p.b.name)):
            if not place_on(seg, p, -1 if i % 2 == 0 else 1):
                if place_anywhere(p, seg):
                    loose.append(p)
    filler_plans: list[Plan] = []
    for n in names:
        seg = placed[n]
        for i in range(fillers.get(n, 0)):
            hr = _rng("house", town.id, n, i)
            w, h = hr.randint(7, 11), hr.randint(6, 9)
            rows = [{"name": "House", "type": "Entrance", "tile": "", "floor": 0, "x": 0, "y": 0, "w": w - 1,
                     "h": h - 1, "connects": ""}]
            if hr.random() < 0.35:                    # an L-shaped house
                rows.append({"name": "Wing", "type": "Room", "tile": "", "floor": 0, "x": 0, "y": h - 1,
                             "w": max(4, (w - 1) // 2), "h": hr.randint(3, 4), "connects": "House"})
            p = Plan(None, rows)
            p.id = f"house:{n}:{i}"
            if place_on(seg, p, -1 if i % 2 else 1, allow_grow=False):
                filler_plans.append(p)
    from game import settlements as ST
    from game import townlayout as TLY
    sale_plans: list[Plan] = []                        # empty lots with a "For sale" sign
    for i in range(ST.lots_target(town)):
        seg = placed[names[i % len(names)]]
        p = Plan(None, TLY.lot_rows())
        p.id = f"lot:{i}"
        if place_on(seg, p, 1 if i % 2 else -1):
            sale_plans.append(p)

    # ---- the map's extent ------------------------------------------------
    xs = [c[0] for c in street_of] + [t[0] for t in taken] + [t[0] + t[2] for t in taken]
    ys = [c[1] for c in street_of] + [t[1] for t in taken] + [t[1] + t[3] for t in taken]
    foot = (min(xs), min(ys), max(xs), max(ys))
    margin = (8 if embedded else 14) + TLY.margin(town)
    x0, y0 = min(xs) - margin, min(ys) - margin
    W, H = max(xs) - x0 + margin, max(ys) - y0 + margin
    a = Area(f"town:{town.id}", "town", W, H, town.name)
    a.terrain = terrain
    base = Level("0", 0, 0, W, H, ground)
    a.levels["0"] = base

    def sh(c):
        return c[0] - x0, c[1] - y0

    for p in plans + filler_plans + sale_plans:
        p.px -= x0
        p.py -= y0
    for n in names:
        s = placed[n]
        s["x1"] -= x0
        s["x2"] -= x0
        s["y1"] -= y0
        s["y2"] -= y0
    # ground variety, then streets
    zone_of_street = {n: a.zone_id(places.street_id(town.id, n)) for n in names}
    for c, n in street_of.items():
        x, y = sh(c)
        base.set_floor(x, y, street_floor)
        base.set_zone(x, y, zone_of_street[n])
    lots = [(t[0] - x0, t[1] - y0, t[2], t[3]) for t in taken]

    # ---- buildings -------------------------------------------------------
    for p in plans:
        _stamp_town_building(world, a, base, p, street_of, x0, y0, street_floor)
    for p in filler_plans:
        _stamp_filler(a, base, p, rng, street_floor)
    a.sale_lots = {int(p.id[4:]): (p.px, p.py) + p.size() for p in sale_plans}
    from game import estate
    owned_lots = estate.lot_claims(world, town)
    for b in on_lots:
        rect = a.sale_lots.get(int(b.fields.get("lot")))
        if rect is not None and int(b.fields.get("lot")) in owned_lots:
            try:
                estate.stamp_into(world, a, base, b, rect[0], rect[1])
            except Exception:  # noqa: BLE001 - a bad building never spoils the town
                pass
    sale_plans = [p for p in sale_plans if int(p.id[4:]) not in owned_lots]      # no sign on a sold lot

    # ---- the gates and roads out ------------------------------------------
    from game import geography as G
    foot = (foot[0] - x0, foot[1] - y0, foot[2] - x0, foot[3] - y0)
    street_sq = {sh(c) for c in street_of}
    plaza_sq = (plaza[0] - x0, plaza[1] - y0, plaza[2], plaza[3]) if plaza is not None else None
    sale_sq = [(p.px, p.py) + p.size() + (int(p.id[4:]),) for p in sale_plans]
    if embedded:
        lots_sq = [(t[0] - x0, t[1] - y0, t[2], t[3]) for t in taken]
        _decorate_town(a, base, rng, terrain, street_of, x0, y0, lots_sq, {}, plaza)
        lots_sq += TLY.dress(a, base, town, rng, foot, street_sq, lots_sq, plaza_sq, {}, sale_sq, True)
        for n in names:
            s_ = placed[n]
            mx, my = (s_["x1"] + s_["x2"]) // 2, (s_["y1"] + s_["y2"]) // 2
            spot = _nearest_free(base, mx, my, lambda x, y: base.zone_at(x, y) == zone_of_street[n])
            if spot:
                a.spawns[places.street_id(town.id, n)] = ("0", spot[0], spot[1])
        for p in plans:
            _spawns_for(a, p)
        a.streets = placed
        a.street_floor = street_floor
        a.finish()
        return a
    exits = places.town_exits(town)
    roads = {r["direction"]: r for r in places.roads_of(town)}
    blocked = set()
    for (lx, ly, lw, lh) in lots:
        for yy in range(ly, ly + lh):
            for xx in range(lx, lx + lw):
                blocked.add((xx, yy))
    road_cells: dict[tuple, str] = {}
    for direction, st in exits.items():
        seg = placed.get(st) or placed[first]
        vx, vy = G.VECTORS.get(direction, (0, 1))
        ends = [(seg["x1"], seg["y1"]), (seg["x2"], seg["y2"])]
        sx, sy = max(ends, key=lambda q: q[0] * vx + q[1] * vy)
        tx = W - 1 if vx > 0.3 else 0 if vx < -0.3 else sx
        ty = H - 1 if vy > 0.3 else 0 if vy < -0.3 else sy
        path = _find_path((sx, sy), (tx, ty), W, H, blocked)
        if not path:
            continue
        width = 3 if direction in roads else 2
        for (px, py) in path:
            for d in range(-(width // 2), width - width // 2):
                for c in ((px + d, py), (px, py + d)):
                    if 0 <= c[0] < W and 0 <= c[1] < H and c not in blocked and base.floor_at(*c) != street_floor:
                        base.set_floor(c[0], c[1], "path" if direction in roads else "dirt")
                        road_cells[c] = direction
        ex, ey = path[-1]
        a.gates[direction] = (ex, ey)
    # every walkable square on the edge of the map leads out of town
    cx, cy = W / 2, H / 2
    for yy in range(H):
        for xx in range(W):
            if xx not in (0, W - 1) and yy not in (0, H - 1):
                continue
            d = road_cells.get((xx, yy)) or _direction_of(xx - cx, yy - cy)
            base.exits[(xx, yy)] = {"direction": d, "road": d in roads and (xx, yy) in road_cells,
                                    "street": exits.get(d, first)}

    # ---- greenery and odds and ends ----------------------------------------
    _decorate_town(a, base, rng, terrain, street_of, x0, y0, lots, road_cells, plaza)
    TLY.dress(a, base, town, rng, foot, street_sq, lots, plaza_sq, road_cells, sale_sq, False)

    # ---- where to put the party for each place -------------------------------
    for n in names:
        s = placed[n]
        mx, my = (s["x1"] + s["x2"]) // 2, (s["y1"] + s["y2"]) // 2
        spot = _nearest_free(base, mx, my, lambda x, y: base.zone_at(x, y) == zone_of_street[n])
        if spot:
            a.spawns[places.street_id(town.id, n)] = ("0", spot[0], spot[1])
    for p in plans:
        _spawns_for(a, p)
    a.streets = placed                                     # for the town overview
    a.finish()
    return a


def _hits(c, taken) -> bool:
    x, y = c
    return any(ax <= x < ax + aw and ay <= y < ay + ah for ax, ay, aw, ah in taken)


def _direction_of(dx: float, dy: float) -> str:
    ang = math.degrees(math.atan2(dy, dx)) % 360
    names = ["East", "South-east", "South", "South-west", "West", "North-west", "North", "North-east"]
    return names[int(((ang + 22.5) % 360) // 45)]


def _find_path(start, goal, W, H, blocked) -> list[tuple[int, int]]:
    """A* over the grid avoiding blocked squares; ends on the goal row/column at the map's edge."""
    import heapq
    gx, gy = goal

    def h(c):
        return abs(c[0] - gx) + abs(c[1] - gy)
    edge_goal = gx in (0, W - 1) or gy in (0, H - 1)

    def done(c):
        if c == goal:
            return True
        if not edge_goal:
            return False
        if gx in (0, W - 1) and c[0] == gx and abs(c[1] - gy) <= 6:
            return True
        return gy in (0, H - 1) and c[1] == gy and abs(c[0] - gx) <= 6
    openl = [(h(start), 0, start)]
    came = {start: None}
    cost = {start: 0}
    while openl:
        _f, g, c = heapq.heappop(openl)
        if done(c):
            out = []
            while c is not None:
                out.append(c)
                c = came[c]
            return out[::-1]
        if g > cost.get(c, 1e9):
            continue
        for dx, dy in SIDES.values():
            n = (c[0] + dx, c[1] + dy)
            if not (0 <= n[0] < W and 0 <= n[1] < H) or n in blocked:
                continue
            ng = g + 1
            if ng < cost.get(n, 1e9):
                cost[n] = ng
                came[n] = c
                heapq.heappush(openl, (ng + h(n), ng, n))
        if len(cost) > 60000:
            break
    return []


def _nearest_free(lv: Level, x: int, y: int, ok=None, limit: int = 30) -> tuple[int, int] | None:
    for r in range(limit):
        ring = [(x + dx, y + dy) for dx in range(-r, r + 1) for dy in range(-r, r + 1) if max(abs(dx), abs(dy)) == r]
        for c in ring:
            if lv.inside(*c) and not lv.blocks(*c) and c not in lv.doors and c not in lv.stairs and \
                    (ok is None or ok(*c)):
                return c
    return None


def _stamp_town_building(world, a: Area, base: Level, p: Plan, street_of: dict, x0: int, y0: int,
                         street_floor: str) -> None:
    b, rows = p.b, p.rows
    bid = b.id
    wall = _wall_kind(b)
    roof = _roof_style(b)
    kind = b.fields.get("kind") or "House"
    rng = _rng("furnish", bid)
    by_floor: dict[int, list] = {}
    for row in rows:
        by_floor.setdefault(int(row.get("floor") or 0), []).append((row, p.rect_of(row)))
    fx, fy = p.size()
    levels: dict[int, Level] = {}
    cells_by_floor = {}
    for fl in sorted(by_floor, key=lambda f: (f != 0, abs(f))):
        if fl == 0:
            lv = base
        else:
            lv = Level(f"{bid}:{fl}", p.px, p.py, fx, fy, PASS if fl > 0 else EARTH, bid, fl, True, roof)
            lv.dark = fl < 0
            a.levels[lv.key] = lv
        levels[fl] = lv
        cells_by_floor[fl] = stamp_rooms(a, lv, by_floor[fl], bid, rows, wall,
                                         lambda row: _room_floor(b, row))
    for fl, lv in levels.items():                   # an upper floor looks down on the roof below it
        if fl > 0:
            below = set().union(*(cells_by_floor[f] for f in cells_by_floor if 0 <= f < fl))
            for c in below:
                if lv.inside(*c) and lv.floor_at(*c) == PASS:
                    lv.set_floor(c[0], c[1], ROOF)
    _stairs_between(a, levels, by_floor, rows, rng)
    # the street door
    ent_row = rows[0]
    ent = p.rect_of(ent_row)
    facing = p.facing()
    door = _street_door(base, ent, facing, cells_by_floor[0], [r for _row, r in by_floor.get(0, [])],
                        (p.px, p.py, fx, fy))
    if door is not None:
        (dx, dy), side = door
        base.walls.pop((dx, dy), None)
        base.set_floor(dx, dy, _room_floor(b, ent_row))
        base.doors[(dx, dy)] = {"kind": "street", "bid": bid, "horizontal": side in "NS", "wall": wall,
                                "rooms": (bid, ""), "names": (ent_row["name"], ""), "lock": 0, "room": bid}
        sx, sy = SIDES[side]
        cx, cy = dx + sx, dy + sy
        for _ in range(8):                           # a path out to the street
            if (cx + x0, cy + y0) in street_of or not base.inside(cx, cy):
                break
            if (cx, cy) in cells_by_floor[0] or base.walls.get((cx, cy)):
                break
            base.set_floor(cx, cy, street_floor if street_floor == "cobble" else "path")
            cx, cy = cx + sx, cy + sy
        a.buildings[bid] = {"rect": (p.px, p.py, fx, fy), "levels": {fl: lv.key for fl, lv in levels.items()},
                            "door": (dx, dy), "facing": side}
    else:
        a.buildings[bid] = {"rect": (p.px, p.py, fx, fy), "levels": {fl: lv.key for fl, lv in levels.items()},
                            "door": None, "facing": facing}
    all_doors = set(base.doors)
    for fl, lv in levels.items():
        if fl >= 0:
            _windows(lv, cells_by_floor[fl], set(lv.doors) | all_doors)
    # locks on private rooms
    dc = LOCK_DC.get(kind, 13)
    owned = bool(b.fields.get("owner"))
    for fl, lv in levels.items():
        for c, d in lv.doors.items():
            if d.get("kind") != "door" or d.get("bid") != bid:
                continue
            types = [(R.room_row(rows, n) or {}).get("type") for n in d["names"]]
            for i, t in enumerate(types):
                other = types[1 - i]
                if t in ("Private", "Storage") and other not in ("Private", "Storage") and not owned:
                    d["lock"] = dc if t == "Private" else dc - 1
                    d["room"] = d["rooms"][i]
                    if kind == "Jail" and (R.room_row(rows, d["names"][i]) or {}).get("tile") == "Cell":
                        d["cell"] = True                  # locked from both sides (game/jail.py)
                    break
    # furniture
    for fl, lst in by_floor.items():
        lv = levels[fl]
        for row, rect in lst:
            feats = R.tile_features(world, row)
            if row is rows[0] and kind in ("Inn", "Tavern", "Brothel") and "bar" not in feats and \
                    not any("bar" in R.tile_features(world, r) for r in rows):
                feats = feats + ["bar"]
            furnish(lv, rect, feats, rng, _room_loc(bid, rows, row), kind, row.get("type") or "",
                    extra=tuple(row.get("furnished") or ()))
    _craft_benches(world, b, rows, levels, by_floor)
    _bookshelves(world, b, rows, levels, by_floor)
    if kind == "Bank":
        _vault(world, b, rows, levels, by_floor)
    # the roof: over the ground floor and anything built out above it (a covered porch underneath)
    roof_cells = set(cells_by_floor.get(0, set()))
    for fl, cs in cells_by_floor.items():
        if fl > 0:
            for c in cs:
                if c not in roof_cells:
                    roof_cells.add(c)
                    if c not in base.walls and c not in base.doors and base.floor_at(*c) not in SOLID:
                        base.set_floor(c[0], c[1], "stone")
                        a.porch.add(c)
    a.roofs[bid] = {"cells": roof_cells, "style": roof, "name": b.name, "filler": False, "kind": kind}
    for c in roof_cells:
        a.cell_building[c] = bid


def _craft_benches(world, b, rows: list, levels: dict, by_floor: dict) -> None:
    """The crafting stations a building has (game/crafting.py) that its rooms' furniture didn't bring: a
    loom at the tailor's, an alchemy table at the alchemist's, a stove in the inn's kitchen... Placed with
    their own dice against a wall of the room where the work is done, so the rest of the layout is as it was."""
    from game import crafting
    try:
        want = crafting.building_stations(world, b)
    except Exception:  # noqa: BLE001 - no crafting data: nothing to add
        return
    if not want:
        return
    lv = levels.get(0)
    if lv is None:
        return
    def ours(loc) -> bool:
        return loc == b.id or str(loc or "").startswith(f"room|{b.id}|")
    have = {"forge"} if any(st.get("kind") == "forge" and ours(st.get("room")) for st in lv.stations.values()) \
        else set()
    have |= {st.get("station") for st in lv.stations.values() if st.get("kind") == "craft" and ours(st.get("room"))}
    rng = _rng("benches", b.id)
    ground = by_floor.get(0) or []
    if not ground:
        return
    work_rooms = [(row, rect) for row, rect in ground
                  if any(st.get("room") == _room_loc(b.id, rows, row) for st in lv.stations.values())]
    order = work_rooms + [x for x in ground if x not in work_rooms]
    for name in want:
        if name in have:
            continue
        pid = crafting.station_info(world, name).get("prop") or "table"
        d = TL.prop_def(pid)
        for row, rect in order:
            loc = _room_loc(b.id, rows, row)
            x, y, w, h = rect
            ix0, iy0, ix1, iy1 = x + 1, y + 1, x + w - 1, y + h - 1
            doors = _room_doors(lv, x, y, w, h)
            near, must = set(), []
            for side, cl in doors.items():
                for dx, dy in cl:
                    sx, sy = SIDES[side]
                    must.append((dx - sx, dy - sy))
                    for ax in (-1, 0, 1):
                        for ay in (-1, 0, 1):
                            near.add((dx - sx + ax, dy - sy + ay))
            spots = [(cx, cy) for cy in (iy0, iy1 - d.h) for cx in range(ix0, ix1 - d.w + 1)] + \
                    [(cx, cy) for cx in (ix0, ix1 - d.w) for cy in range(iy0, iy1 - d.h + 1)]
            rng.shuffle(spots)
            placed = None
            for cx, cy in spots:
                cells = [(cx + a, cy + bb) for bb in range(d.h) for a in range(d.w)]
                if any(c in near or c in lv.stairs or not (ix0 <= c[0] < ix1 and iy0 <= c[1] < iy1) for c in cells):
                    continue
                p = lv.add_prop(pid, cx, cy, 0)
                if p is None:
                    continue
                spawn = [sp for sp in (lv.stations.get(c, {}).get("spot") for c in lv.stations) if sp]
                if not _connected(lv, rect, must + [c for c in spawn if x < c[0] < x + w and y < c[1] < y + h]):
                    lv.remove_prop(p)
                    continue
                for c in cells:
                    lv.stations[c] = {"kind": "craft", "station": name, "room": loc, "spot": None, "bid": b.id}
                placed = p
                break
            if placed is not None:
                have.add(name)
                break


def _bookshelves(world, b, rows: list, levels: dict, by_floor: dict) -> None:
    """In a library, a college or a temple's archives, the shelves hold the books (game/books.py): each
    bookshelf becomes something to browse, numbered through the building (a building made before its rooms
    had any gets two along a wall). The books are shared out over the shelves by kind."""
    from game import books
    try:
        if not books.library_kind(world, b):
            return
    except Exception:  # noqa: BLE001
        return
    found = []
    for fl in sorted(levels):
        lv = levels[fl]
        for row, rect in by_floor.get(fl, []):
            x, y, w, h = rect
            loc = _room_loc(b.id, rows, row)
            for prop in lv.props:
                if prop.id == "bookshelf" and x < prop.x < x + w and y < prop.y < y + h:
                    found.append((lv, prop, loc))
    want = 4 if books.library_kind(world, b) == "library" else 2
    lv = levels.get(0)
    ground = sorted(by_floor.get(0) or [], key=lambda rr: -rr[1][2] * rr[1][3])
    for row, rect in ground if lv is not None else []:     # too few: more along the walls (out of the way)
        if len(found) >= want:
            break
        x, y, w, h = rect
        loc = _room_loc(b.id, rows, row)
        doors = _room_doors(lv, x, y, w, h)
        must = [(dx - SIDES[side][0], dy - SIDES[side][1]) for side, cl in doors.items() for dx, dy in cl]
        near = {(mx + ax, my + ay) for mx, my in must for ax in (-1, 0, 1) for ay in (-1, 0, 1)}
        spawn = [sp for sp in (st.get("spot") for st in lv.stations.values()) if sp]
        keep = must + [c for c in spawn if x < c[0] < x + w and y < c[1] < y + h]
        for cy in (y + 1, y + h - 2):
            for cx in range(x + 1, x + w - 1):
                if len(found) >= want:
                    break
                if (cx, cy) in near or (cx, cy) in lv.stairs or (cx, cy) in lv.stations:
                    continue
                p = lv.add_prop("bookshelf", cx, cy, 0)
                if p is None:
                    continue
                if not _connected(lv, rect, keep):
                    lv.remove_prop(p)
                    continue
                found.append((lv, p, loc))
    seen = set()
    shelves = []
    for lv, prop, loc in found:
        if id(prop) not in seen:
            seen.add(id(prop))
            shelves.append((lv, prop, loc))
    for n, (lv, prop, loc) in enumerate(shelves):
        for c in prop.cells():
            lv.stations[c] = {"kind": "shelf", "room": loc, "spot": None, "bid": b.id, "n": n, "of": len(shelves)}


def _vault(world, b, rows: list, levels: dict, by_floor: dict) -> None:
    """A bank's strongboxes (game/bank.py): its strongroom has them; a bank whose rooms were made before
    there were strongrooms gets them in its innermost ground-floor room."""
    lv = levels.get(0)
    if lv is None:
        return
    mine = [st for st in lv.stations.values() if st.get("kind") == "vault" and
            (st.get("room") == b.id or str(st.get("room") or "").startswith(f"room|{b.id}|"))]
    if mine:
        for st in mine:
            st["bid"] = b.id
        return
    ground = by_floor.get(0) or []
    for row, rect in list(reversed(ground[1:] or ground)):
        x, y, w, h = rect
        loc = _room_loc(b.id, rows, row)
        doors = _room_doors(lv, x, y, w, h)
        must = [(dx - SIDES[side][0], dy - SIDES[side][1]) for side, cl in doors.items() for dx, dy in cl]
        near = {(mx + ax, my + ay) for mx, my in must for ax in (-1, 0, 1) for ay in (-1, 0, 1)}
        for cx, cy in ((x + w - 2, y + 1), (x + 1, y + 1), (x + w - 2, y + h - 2), (x + 1, y + h - 2)):
            if (cx, cy) in near or (cx, cy) in lv.stairs or (cx, cy) in lv.stations:
                continue
            p = lv.add_prop("chest", cx, cy, 0)
            if p is None:
                continue
            if not _connected(lv, rect, must):
                lv.remove_prop(p)
                continue
            for c in p.cells():
                lv.stations[c] = {"kind": "vault", "room": loc, "spot": None, "bid": b.id}
            return


def _street_door(lv: Level, ent: tuple, facing: str, cells: set, rects: list, box: tuple | None = None) -> tuple | None:
    """A wall square for the front door: on the entrance room's front if it can be, opening onto
    ground that leads away from the building. Failing that, the next nearest room's outside wall."""
    order = [facing] + [s for s in ("S", "E", "W", "N") if s != facing]
    others = sorted(rects, key=lambda r: abs(r[0] + r[2] / 2 - ent[0] - ent[2] / 2) +
                    abs(r[1] + r[3] / 2 - ent[1] - ent[3] / 2))
    for room in [ent] + [r for r in others if r != ent]:
        x, y, w, h = room
        for side in order:
            sx, sy = SIDES[side]
            if side in "NS":
                line = [(xx, y if side == "N" else y + h) for xx in range(x + 1, x + w)]
            else:
                line = [(x if side == "W" else x + w, yy) for yy in range(y + 1, y + h)]
            mid = len(line) // 2
            line = [c for _i, c in sorted(enumerate(line), key=lambda ic: abs(ic[0] - mid))]
            for (cx, cy) in line:
                out = (cx + sx, cy + sy)
                inside = (cx - sx, cy - sy)
                if out in cells or not lv.inside(*out) or inside not in cells or (cx, cy) in lv.doors:
                    continue
                if (cx, cy) not in lv.walls:
                    continue
                if box is not None and not _leads_out(out, cells, box):
                    continue
                return (cx, cy), side
    return None


def _leads_out(start, cells: set, box: tuple) -> bool:
    """Does the ground outside this door lead out past the building (not into a closed courtyard)?"""
    bx, by, bw, bh = box
    seen = {start}
    todo = deque([start])
    while todo:
        x, y = todo.popleft()
        if not (bx <= x < bx + bw and by <= y < by + bh):
            return True
        for dx, dy in SIDES.values():
            n = (x + dx, y + dy)
            if n not in seen and n not in cells:
                seen.add(n)
                todo.append(n)
    return False


def _stamp_filler(a: Area, base: Level, p: Plan, rng: random.Random, street_floor: str) -> None:
    """Someone else's house: walls and a roof, and a front door that stays shut."""
    rects = [(row, p.rect_of(row)) for row in p.rows]
    wall = rng.choice(["wood_wall", "wood_wall", "stone_wall", "brick_wall"])
    cells = set()
    for row, (x, y, w, h) in rects:
        for yy in range(y, y + h + 1):
            for xx in range(x, x + w + 1):
                cells.add((xx, yy))
    for c in cells:
        base.walls[c] = wall
    door = _street_door_filler(base, rects[0][1], p.facing(), cells)
    if door:
        (dx, dy), side = door
        base.doors[(dx, dy)] = {"kind": "house", "bid": "", "horizontal": side in "NS", "wall": wall,
                                "rooms": ("", ""), "names": ("", ""), "lock": 0, "room": "", "barred": True}
        base.walls.pop((dx, dy), None)
        sx, sy = SIDES[side]
        cx, cy = dx + sx, dy + sy
        for _ in range(6):
            if base.floor_at(cx, cy) in ("cobble", "path") or (cx, cy) in base.walls or not base.inside(cx, cy):
                break
            base.set_floor(cx, cy, "path")
            cx, cy = cx + sx, cy + sy
    style = rng.choice(["Wooden", "Wooden", "Rustic", "Stone", "Brick"])
    a.roofs[p.id] = {"cells": cells, "style": style, "name": "A house", "filler": True, "kind": "House"}
    for c in cells:
        a.cell_building[c] = p.id


def _street_door_filler(lv: Level, ent: tuple, facing: str, cells: set) -> tuple | None:
    x, y, w, h = ent
    sx, sy = SIDES[facing]
    if facing in "NS":
        c = (x + w // 2, y if facing == "N" else y + h)
    else:
        c = (x if facing == "W" else x + w, y + h // 2)
    if (c[0] + sx, c[1] + sy) in cells:
        return None
    return c, facing


def _decorate_town(a: Area, base: Level, rng, terrain: str, street_of: dict, x0: int, y0: int, lots: list,
                   road_cells: dict, plaza) -> None:
    W, H = a.w, a.h
    near = set()
    for (lx, ly, lw, lh) in lots:
        for yy in range(ly - 1, ly + lh + 1):
            for xx in range(lx - 1, lx + lw + 1):
                near.add((xx, yy))
    core = set()
    for (sx, sy) in street_of:
        core.add((sx - x0, sy - y0))
    if plaza is not None:
        px, py, ps, _ = plaza
        base.add_prop("well", px - x0 + ps // 2 - 1, py - y0 + ps // 2 - 1)
        for c in ((px - x0, py - y0), (px - x0 + ps - 1, py - y0 + ps - 1)):
            base.add_prop("cart", c[0] + 1, c[1], rng.randrange(1)) if rng.random() < 0.5 else None

    def far_from_town(x, y, d):
        for dy in range(-d, d + 1):
            for dx in range(-d, d + 1):
                c = (x + dx, y + dy)
                if c in core or c in near or c in road_cells:
                    return False
        return True
    tree = {"Forest": 0.16, "Taiga": 0.14, "Jungle": 0.2, "Swamp": 0.06, "Plains": 0.025, "Hills": 0.03,
            "Coast": 0.02, "Savanna": 0.015}.get(terrain, 0.0)
    rocks = {"Hills": 0.03, "Mountains": 0.06, "Desert": 0.015, "Arctic": 0.02, "Tundra": 0.02,
             "Badlands": 0.04}.get(terrain, 0.008)
    pine = terrain in ("Taiga", "Arctic", "Mountains", "Tundra")
    busy = max(tree + rocks + 0.01, 0.02)
    # only the squares that would get something are visited: as many as a roll per square would pick
    for _k in range(int(max(0, W - 2) * max(0, H - 2) * busy)):
        xx, yy = rng.randrange(1, max(2, W - 1)), rng.randrange(1, max(2, H - 1))
        r = rng.random() * busy
        if (xx, yy) in base.walls or (xx, yy) in base.prop_cells or base.floor_at(xx, yy) in ("cobble", "path"):
            continue
        if (xx, yy) in near or (xx, yy) in core or (xx, yy) in road_cells:
            continue
        if far_from_town(xx, yy, 2):
            if r < tree:
                base.add_prop("pine" if pine else rng.choice(["tree", "tree", "bush"]), xx, yy, rng.randrange(6))
            elif r < tree + rocks:
                base.add_prop("rock", xx, yy, rng.randrange(4))
            elif r < tree + rocks + 0.01:
                base.add_prop("bush", xx, yy, rng.randrange(4))
        elif r < 0.02:
            base.add_prop(rng.choice(["bush", "barrel", "crate", "haybale"]), xx, yy, rng.randrange(4))
    if terrain == "Swamp":
        for _ in range(6):
            cx, cy = rng.randrange(W), rng.randrange(H)
            for dy in range(-2, 3):
                for dx in range(-3, 4):
                    c = (cx + dx, cy + dy)
                    if base.inside(*c) and far_from_town(c[0], c[1], 1) and dx * dx / 9 + dy * dy / 4 <= 1 \
                            and c not in base.prop_cells:
                        base.water[c] = "swamp"


def _spawns_for(a: Area, p: Plan) -> None:
    b, rows = p.b, p.rows
    info = a.buildings.get(b.id) or {}
    for row in rows:
        loc = _room_loc(b.id, rows, row)
        fl = int(row.get("floor") or 0)
        key = (info.get("levels") or {}).get(fl, "0")
        lv = a.levels.get(key) or a.base
        x, y, w, h = p.rect_of(row)
        if row is rows[0] and info.get("door"):
            dx, dy = info["door"]
            sx, sy = SIDES[info.get("facing") or "S"]
            spot = _nearest_free(lv, dx - sx, dy - sy, lambda xx, yy: x < xx < x + w and y < yy < y + h, 6) or \
                _nearest_free(lv, x + w // 2, y + h // 2, lambda xx, yy: x < xx < x + w and y < yy < y + h, 8)
        else:
            spot = _nearest_free(lv, x + w // 2, y + h // 2, lambda xx, yy: x < xx < x + w and y < yy < y + h, 8)
        if spot:
            a.spawns[loc] = (lv.key, spot[0], spot[1])


# ======================================================================
# Dungeons
# ======================================================================
def build_dungeon(world, d) -> Area:
    from game import dungeons as DG
    rows = [dict(r) for r in DG.rooms(d)]
    hand_made = _place_hand_made(d, rows)
    kind = d.fields.get("kind") or "Other"
    cave = kind in ("Cave", "Lair", "Mine")
    wall = "rock_wall" if cave else "stone_wall"
    rng = _rng("dungeonmap", d.id)
    pad = 3
    x0 = min(int(r.get("x") or 0) for r in rows) - pad
    y0 = min(int(r.get("y") or 0) for r in rows) - pad
    W = max(int(r.get("x") or 0) + int(r.get("w") or 6) for r in rows) - x0 + pad + 1
    H = max(int(r.get("y") or 0) + int(r.get("h") or 6) for r in rows) - y0 + pad + 1
    a = Area(f"dungeon:{d.id}", "dungeon", W, H, d.name)
    a.outdoor = False
    by_floor: dict[int, list] = {}
    for row in rows:
        rect = (int(row.get("x") or 0) - x0, int(row.get("y") or 0) - y0, int(row.get("w") or 6),
                int(row.get("h") or 6))
        by_floor.setdefault(int(row.get("floor") or 0), []).append((row, rect))
    levels: dict[int, Level] = {}
    cells = {}
    ent_floor = int(rows[0].get("floor") or 0)
    for fl in sorted(by_floor):
        lv = Level(f"f{fl}", 0, 0, W, H, EARTH, d.id, fl)
        lv.dark = True
        a.levels[lv.key] = lv
        levels[fl] = lv
        cells[fl] = stamp_rooms(a, lv, by_floor[fl], d.id, rows, wall, lambda row: _room_floor(d, row, "dungeon"),
                                dungeon=True)
    a.base_key = f"f{ent_floor}"
    if hand_made:
        _corridors(a, levels, by_floor, rows, d, wall)
    _stairs_between(a, levels, by_floor, rows, rng)
    # the way out: a door in the entrance room's south wall (or wherever its outside wall is)
    ent_row, ent = by_floor[ent_floor][0]
    lv = levels[ent_floor]
    door = _street_door(lv, ent, "S", cells[ent_floor], [])
    if door:
        (dx, dy), side = door
        lv.walls.pop((dx, dy), None)
        lv.set_floor(dx, dy, _room_floor(d, ent_row, "dungeon"))
        lv.doors[(dx, dy)] = {"kind": "exit", "bid": d.id, "horizontal": side in "NS", "wall": wall,
                              "rooms": (DG.room_id(d.id, ent_row["name"]), ""), "names": (ent_row["name"], ""),
                              "lock": 0, "room": ""}
        a.gates["out"] = (dx, dy)
    # locks: treasure rooms are kept locked
    level_no = int(d.fields.get("level") or 1)
    for fl, lst in by_floor.items():
        for c, dd in levels[fl].doors.items():
            if dd.get("kind") != "door":
                continue
            types = [DG.room_type(R.room_row(rows, n) or {}) for n in dd["names"]]
            for i, t in enumerate(types):
                if t in ("Treasure", "Treasure room") and types[1 - i] not in ("Treasure", "Treasure room"):
                    dd["lock"] = 12 + min(8, level_no // 2)
                    dd["room"] = dd["rooms"][i]
    for fl, lst in by_floor.items():
        for row, rect in lst:
            furnish(levels[fl], rect, R.tile_features(world, row), rng, DG.room_id(d.id, row["name"]), kind,
                    DG.room_type(row), dungeon=True, dkind=kind)
            loc = DG.room_id(d.id, row["name"])
            x, y, w, h = rect
            spot = _nearest_free(levels[fl], x + w // 2, y + h // 2, lambda xx, yy: x < xx < x + w and y < yy < y + h, 8)
            if spot:
                a.spawns[loc] = (levels[fl].key, spot[0], spot[1])
    if door:
        (dx, dy), side = door
        sx, sy = SIDES[side]
        ex, ey, ew, eh = ent
        spot = _nearest_free(lv, dx - sx, dy - sy, lambda xx, yy: ex < xx < ex + ew and ey < yy < ey + eh, 6)
        if spot:
            a.spawns[DG.room_id(d.id, ent_row["name"])] = (lv.key, spot[0], spot[1])
    if kind in ORE_DUNGEONS:
        _ore_veins(a, levels, by_floor, kind, d.id, int(d.fields.get("level") or 1) * 5)
    _trap_squares(a, levels, by_floor, d)
    a.finish()
    return a


def _trap_squares(a: Area, levels: dict, by_floor: dict, d) -> None:
    """Each trapped room's trap on one square (game/traps.py), in the way between its doors (or a little in
    from its only one), never on a doorway, the stairs or where the party comes in."""
    from game import dungeons as DG
    taken = {(x, y) for (_k, x, y) in a.spawns.values()}
    for fl, lst in by_floor.items():
        lv = levels[fl]
        for row, rect in lst:
            if not (int(row.get("trap_dc") or 0) and row.get("trap_damage")):
                continue
            x, y, w, h = rect
            inner = []
            for side, cl in _room_doors(lv, x, y, w, h).items():
                sx, sy = SIDES[side]
                inner += [(dx - sx, dy - sy) for dx, dy in cl]
            if len(inner) >= 2:
                tx, ty = (inner[0][0] + inner[1][0]) / 2, (inner[0][1] + inner[1][1]) / 2
            elif inner:
                cx, cy = x + w / 2, y + h / 2
                tx, ty = inner[0][0] + (cx - inner[0][0]) * 0.5, inner[0][1] + (cy - inner[0][1]) * 0.5
            else:
                tx, ty = x + w / 2, y + h / 2
            near = {(ix + ddx, iy + ddy) for ix, iy in inner for ddx in (-1, 0, 1) for ddy in (-1, 0, 1)}
            spots = [(cx, cy) for cy in range(y + 1, y + h) for cx in range(x + 1, x + w)
                     if lv.free(cx, cy) and (cx, cy) not in taken and (cx, cy) not in lv.stations
                     and ((cx, cy) not in near or w * h <= 12)]
            if not spots:
                continue
            c = min(spots, key=lambda q: ((q[0] - tx) ** 2 + (q[1] - ty) ** 2, q))
            lv.traps[c] = {"dungeon": d.id, "name": row["name"], "room": DG.room_id(d.id, row["name"])}


ORE_DUNGEONS = {"Mine": (1, 3), "Cave": (0, 1)}       # ore veins along the walls of each room (game/gathering.py)


def _ore_veins(a: Area, levels: dict, by_floor: dict, kind: str, d_id: str, danger: int = 0) -> None:
    """Veins of ore in a mine's rooms (fewer in a cave), against the walls and out of the way. Their own
    dice, so the rest of the map is as it always was."""
    from game import dungeons as DG
    from game import gathering as GA
    rng = _rng("ore", d_id)
    lo, hi = ORE_DUNGEONS[kind]
    taken = {(x, y) for (_k, x, y) in a.spawns.values()}
    for fl, lst in by_floor.items():
        lv = levels[fl]
        for row, rect in lst:
            if DG.room_type(row) in ("Treasure", "Treasure room", "Boss", "Special", "Entrance", "Hallway", "Stairs"):
                continue
            x, y, w, h = rect
            doors = _room_doors(lv, x, y, w, h)
            near = set()
            must = []
            for side, cl in doors.items():
                for dx, dy in cl:
                    sx, sy = SIDES[side]
                    must.append((dx - sx, dy - sy))
                    for ddx in (-1, 0, 1):
                        for ddy in (-1, 0, 1):
                            near.add((dx - sx + ddx, dy - sy + ddy))
            spots = [(cx, cy) for cy in range(y + 1, y + h - 1) for cx in range(x + 1, x + w - 1)
                     if (cx in (x + 1, x + w - 2) or cy in (y + 1, y + h - 2)) and lv.free(cx, cy)
                     and (cx, cy) not in near and (cx, cy) not in taken and (cx, cy) not in lv.stairs]
            rng.shuffle(spots)
            for c in spots[:rng.randint(lo, hi)]:
                p = lv.add_prop("ore_vein", c[0], c[1], GA.vein_variant(c[0], c[1], zlib.crc32(d_id.encode()),
                                                                        danger + 10))
                if p is not None and not _connected(lv, rect, must + [t for t in taken if lv.inside(*t)]):
                    lv.remove_prop(p)


# ======================================================================
# Moving a whole area (a town into the walkable world)
# ======================================================================
def _shift_level(lv: Level, dx: int, dy: int, key: str, keymap: dict) -> Level:
    n = Level.__new__(Level)
    n.__dict__.update(lv.__dict__)
    n.key = key
    n.ox, n.oy = lv.ox + dx, lv.oy + dy
    sh = lambda c: (c[0] + dx, c[1] + dy)  # noqa: E731
    n.walls = {sh(c): v for c, v in lv.walls.items()}
    n.windows = {sh(c) for c in lv.windows}
    n.doors = {sh(c): dict(v) for c, v in lv.doors.items()}
    n.water = {sh(c): v for c, v in lv.water.items()}
    n.stairs = {sh(c): (keymap.get(t[0], t[0]), t[1] + dx, t[2] + dy) for c, t in lv.stairs.items()}
    n.stations = {sh(c): dict(v, spot=sh(v["spot"]) if v.get("spot") else None) for c, v in lv.stations.items()}
    n.exits = {}
    n.props = [AProp(p.id, p.x + dx, p.y + dy, p.variant) for p in lv.props]
    n.prop_cells = {}
    for p in n.props:
        for c in p.cells():
            n.prop_cells[c] = p
    return n


def shifted(a: Area, dx: int, dy: int, base_key: str, world_base: str = "0") -> Area:
    """The same area moved by (dx, dy). Its ground level gets its own key (base_key, for remembering what's
    been seen) but everything that leads to it (stairs, where people stand) points at world_base, the level
    the party walks on outside."""
    b = Area(a.key, a.kind, a.w, a.h, a.title)
    b.__dict__.update({k: v for k, v in a.__dict__.items() if k not in ("levels",)})
    keymap = {a.base_key: world_base}
    b.levels = {}
    for k, lv in a.levels.items():
        nk = base_key if k == a.base_key else k
        b.levels[nk] = _shift_level(lv, dx, dy, nk, keymap)
    b.base_key = base_key
    sh = lambda c: (c[0] + dx, c[1] + dy)  # noqa: E731
    b.roofs = {bid: dict(r, cells={sh(c) for c in r["cells"]}) for bid, r in a.roofs.items()}
    b.cell_building = {sh(c): v for c, v in a.cell_building.items()}
    b.porch = {sh(c) for c in a.porch}
    b.buildings = {bid: dict(info, rect=(info["rect"][0] + dx, info["rect"][1] + dy, info["rect"][2],
                                         info["rect"][3]),
                             door=sh(info["door"]) if info.get("door") else None,
                             levels={f: keymap.get(k, k) for f, k in info["levels"].items()})
                   for bid, info in a.buildings.items()}
    b.spawns = {loc: (keymap.get(k, k), x + dx, y + dy) for loc, (k, x, y) in a.spawns.items()}
    b.gates = {d: sh(c) for d, c in a.gates.items()}
    if getattr(a, "sale_lots", None):
        b.sale_lots = {i: (r[0] + dx, r[1] + dy, r[2], r[3]) for i, r in a.sale_lots.items()}
    b.ox, b.oy = dx, dy
    for lv in b.levels.values():
        lv.names = a.zone_names
    return b


HAND_SIZE = {"Hallway": (4, 9), "Chamber": (9, 8), "Boss": (11, 9), "Treasure": (7, 6), "Special": (7, 7),
             "Entrance": (8, 7), "Stairs": (6, 6)}


def _place_hand_made(d, rows: list[dict]) -> bool:
    """Rooms written by hand have no shape or place: lay them out by how far each is from the
    entrance, a column per step, joined later by corridors."""
    from game import dungeons as DG
    if all(r.get("w") and r.get("h") for r in rows):
        return False
    depth = {rows[0]["name"]: 0}
    queue = [rows[0]["name"]]
    while queue:
        cur = queue.pop(0)
        for n in R.links(rows, cur):
            if n not in depth:
                depth[n] = depth[cur] + 1
                queue.append(n)
    col: dict[int, int] = {}
    for r in rows:
        if r.get("w") and r.get("h"):
            continue
        dd = depth.get(r["name"], max(depth.values(), default=0) + 1)
        k = col.get(dd, 0)
        col[dd] = k + 1
        w, h = HAND_SIZE.get(DG.room_type(r), (8, 7))
        r.update({"x": dd * 16, "y": k * 13, "w": w, "h": h, "floor": int(r.get("floor") or 0)})
    return True


def _corridors(a: Area, levels: dict, by_floor: dict, rows: list[dict], d, wall: str) -> None:
    """Passages between linked rooms that don't touch."""
    from game import dungeons as DG
    where = {row["name"]: (fl, rect) for fl, lst in by_floor.items() for row, rect in lst}
    done = set()
    for name, (fl, ra) in where.items():
        for other in R.links(rows, name):
            if other not in where or (other, name) in done or where[other][0] != fl:
                continue
            done.add((name, other))
            rb = where[other][1]
            if _shared_door(ra, rb) is not None:
                continue
            lv = levels[fl]
            fl_kind = _room_floor(d, {}, "dungeon")
            ax, ay = ra[0] + ra[2] // 2, ra[1] + ra[3] // 2
            bx, by = rb[0] + rb[2] // 2, rb[1] + rb[3] // 2
            if abs(bx - ax) >= abs(by - ay):
                da = (ra[0] + ra[2], ay) if bx > ax else (ra[0], ay)
                db = (rb[0], by) if bx > ax else (rb[0] + rb[2], by)
                mid = (da[0] + db[0]) // 2
                path = _line(da, (mid, da[1])) + _line((mid, da[1]), (mid, db[1])) + _line((mid, db[1]), db)
                horiz = False
            else:
                da = (ax, ra[1] + ra[3]) if by > ay else (ax, ra[1])
                db = (bx, rb[1]) if by > ay else (bx, rb[1] + rb[3])
                mid = (da[1] + db[1]) // 2
                path = _line(da, (da[0], mid)) + _line((da[0], mid), (db[0], mid)) + _line((db[0], mid), db)
                horiz = True
            rowa, rowb = R.room_row(rows, name), R.room_row(rows, other)
            for c in path:
                if c in (da, db):
                    continue
                if lv.floor_at(*c) in SOLID or c in lv.walls:
                    lv.walls.pop(c, None)
                    lv.set_floor(c[0], c[1], fl_kind)
            for c in path:
                for ddx in (-1, 0, 1):
                    for ddy in (-1, 0, 1):
                        n = (c[0] + ddx, c[1] + ddy)
                        if lv.floor_at(*n) == EARTH:
                            lv.set_floor(n[0], n[1], fl_kind)
                            lv.walls[n] = wall
            for c, row, other_row in ((da, rowa, rowb), (db, rowb, rowa)):
                lv.walls.pop(c, None)
                lv.set_floor(c[0], c[1], fl_kind)
                lv.doors[c] = {"kind": "door", "bid": d.id, "horizontal": horiz, "wall": wall,
                               "rooms": (DG.room_id(d.id, row["name"]), ""), "names": (row["name"], ""),
                               "lock": 0, "room": "", "secret": bool(row.get("secret"))}


def _line(a, b) -> list[tuple[int, int]]:
    (x0, y0), (x1, y1) = a, b
    out = []
    if x0 == x1:
        step = 1 if y1 >= y0 else -1
        out = [(x0, y) for y in range(y0, y1 + step, step)]
    else:
        step = 1 if x1 >= x0 else -1
        out = [(x, y0) for x in range(x0, x1 + step, step)]
    return out


__all__ = ["Area", "Level", "AProp", "for_spot", "town_area", "dungeon_area", "build_town", "build_dungeon",
           "furnish", "stamp_rooms", "forget", "SOLID", "OPAQUE"]
