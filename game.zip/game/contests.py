"""Festival contests (game/townevents.py): each a minigame on the step 6 framework (game/minigames.py), or rolled
as a check when minigames are off, against the town's own entrants, for prizes.

    Contest            Minigame                                     Helps
    Archery            aim against the wind's drift                 Dexterity, proficiency with a bow
    Knife throwing     hit a moving target                          Dexterity
    Log toss           a power bar, then the release angle          Strength (Athletics)
    Tug-of-war         heave in time with your team                 Strength (Athletics)
    Footrace           pace your wind to the line                   Dexterity or Constitution
    Horse race         pace your mount (you need one: step 10)      Animal Handling
    Joust              aim the lance as the mounts close (a mount)  Strength and Animal Handling
    Greased pig chase  chase it round the pen and grab              Dexterity (Acrobatics)
    Eating contest     eat fast without filling up                  Constitution
    Apple bobbing      hold your breath and bite                    Constitution
    Snowball fight     throw, and dodge what comes back             Dexterity
    Dance              a rhythm game                                Performance
    Bard's competition play the melody in time                      Performance, an instrument's proficiency
    Riddle contest     answer the riddles                           Intelligence; books you've read help
    Fishing derby      the fishing minigame; biggest catch wins     Survival

How a contest is won: the other entrants each make their mark (a d20 and their skill); you need to beat the best
of them. The minigame is set so that a middling performance just beats them (its "need" is that mark less your
bonus), and what you do counts as a roll as every minigame does. First place wins the purse (and sometimes a
prize); second gets a third of it.
"""
from __future__ import annotations

import math
import random
import zlib

from game.minigames import ACCENT, BAD, BG2, DIM, GOOD, INK, GAMES, Game, _clamp, _Sweep

PURSE = {"Village": 10, "Town": 25, "City": 50, "Capital": 100}
RIVAL_BONUS = {"Village": 2, "Town": 3, "City": 4, "Capital": 5}
INSTRUMENTS = ("bagpipes", "drum", "dulcimer", "flute", "lute", "lyre", "horn", "pan flute", "shawm", "viol")


# ======================================================================================================
# The new minigames
# ======================================================================================================
class _Graded(Game):
    """These games score how well it went (0..1); the harder the contest (the need), the better it has to be."""

    def graded(self, q: float) -> float:
        req = 0.3 + 0.62 * self.d
        q = _clamp(q)
        return 0.5 + 0.5 * (q - req) / max(0.01, 1 - req) if q >= req else 0.5 * q / req

    def finish(self, perf: float, message: str = "") -> None:
        super().finish(self.graded(perf), message)


class Archery(_Graded):
    id, title = "archery", "Archery"
    help = "Up and down to aim; the wind pushes your arrow. Loose (space) three arrows."
    pad = "ud"
    pad_hit = True
    limit = 30.0
    holds = True

    def setup(self):
        self.aim = 0.0                      # -1..1, where you're pointing (up is negative)
        self.wind = self.rng.uniform(-1, 1) * (0.15 + 0.45 * self.d)
        self.sway = 0.03 + 0.4 * self.d
        self.shots: list[float] = []
        self.marks: list[float] = []

    def step(self, dt):
        if "up" in self.held:
            self.aim -= 0.8 * dt
        if "down" in self.held:
            self.aim += 0.8 * dt
        self.aim = max(-1.0, min(1.0, self.aim))
        self.wobble = self.sway * math.sin(self.t * 2.7)

    def landing(self) -> float:
        return self.aim + getattr(self, "wobble", 0.0) + self.wind

    def on(self, action):
        if action != "hit":
            return
        y = self.landing()
        self.marks.append(y)
        self.shots.append(_clamp(1 - abs(y) / 0.45))
        self.wind = self.rng.uniform(-1, 1) * (0.15 + 0.45 * self.d)
        if len(self.shots) >= 3:
            self.finish(sum(self.shots) / 3)

    def timeout(self):
        self.finish(sum(self.shots) / 3 * 0.6, "Too slow.")

    def bot(self, rng, skill):
        want = -self.wind + rng.gauss(0, 0.02 + 0.2 * (1 - skill))
        out = [("release", "up"), ("release", "down")]
        if abs(self.aim - want) > 0.03:
            out = [("press", "down" if self.aim < want else "up")]
        elif self._bot_at is None:
            self._bot_at = self.t + 0.2
        elif self.t >= self._bot_at:
            self._bot_at = None
            out += [("press", "hit"), ("release", "hit")]
        return out

    def draw(self):
        out = [("rect", 500, 60, 30, 240, BG2)]
        for r, col in ((0.6, "#c8b890"), (0.35, "#2c2c2c"), (0.15, "#a02a2a")):
            out.append(("rect", 500, 180 - r * 120, 30, r * 240, col))
        out.append(("rect", 480, 178 + self.landing() * 120, 70, 4, ACCENT))
        for y in self.marks:
            out.append(("circle", 515, 180 + y * 120, 4, INK))
        arrow = "→" if self.wind > 0.05 else "←" if self.wind < -0.05 else "·"
        out += [("text", 200, 120, f"Wind {arrow} {abs(self.wind):.2f}", 16, DIM, "center"),
                ("text", 200, 180, f"Arrow {len(self.shots) + 1} of 3", 14, INK, "center")]
        return out


class Knives(_Sweep):
    id, title = "knives", "Knife throwing"
    help = "Throw (space) when the moving target crosses the green: three knives."
    rounds = 3
    limit = 15.0

    def setup(self):
        super().setup()
        self.speed *= 1.3


class LogToss(_Graded):
    id, title = "logtoss", "Log toss"
    help = "Lock the power (space) at the top of the bar, then the angle (space) near the mark."
    limit = 14.0

    def setup(self):
        self.stage, self.power, self.angle = 0, 0.0, 0.0
        self.p, self.a = 0.0, 0.0
        self.speed = 0.9 + 2.6 * self.d

    def step(self, dt):
        if self.stage == 0:
            self.p = (math.sin(self.t * self.sp(self.speed) * math.pi) + 1) / 2
        elif self.stage == 1:
            self.a = (math.sin((self.t - self.t0) * self.sp(self.speed) * 1.2 * math.pi) + 1) / 2

    def on(self, action):
        if action != "hit":
            return
        if self.stage == 0:
            self.power, self.stage, self.t0 = self.p, 1, self.t
        elif self.stage == 1:
            self.angle, self.stage = self.a, 2
            self.finish(self.power ** 1.5 * _clamp(1 - abs(self.angle - 0.5) / 0.5) ** 0.7)

    def bot(self, rng, skill):
        target = 1.0 if self.stage == 0 else 0.5
        v = self.p if self.stage == 0 else self.a
        if abs(v - target) < 0.04 + 0.25 * (1 - skill) * rng.random():
            return [("press", "hit"), ("release", "hit")]
        return []

    def draw(self):
        out = self.bar(120, 160, 400, 24, self.p if self.stage == 0 else self.power, ACCENT)
        if self.stage >= 1:
            ang = self.a if self.stage == 1 else self.angle
            a = math.radians(10 + ang * 70)
            out.append(("line", 160, 300, 160 + math.cos(a) * 120, 300 - math.sin(a) * 120, INK, 4))
            out.append(("text", 360, 280, "aim for the middle mark", 12, DIM, "center"))
        return out


class Tug(_Graded):
    id, title = "tug", "Tug-of-war"
    help = "Heave (space) when the call comes (the light). Drag the marker to your side."
    limit = 25.0

    def setup(self):
        self.pos = 0.0                      # +1 your win
        self.cue_at = 1.0
        self.window = 0.45 - 0.2 * self.d
        self.pull = 0.06 + 0.05 * self.d
        self.heaved = False

    def cue(self) -> bool:
        return 0 <= self.t - self.cue_at <= self.window

    def step(self, dt):
        self.pos -= self.sp(self.pull) * dt
        if self.t - self.cue_at > self.window:
            self.cue_at += self.rng.uniform(0.9, 1.6)
            self.heaved = False
        if self.pos >= 1:
            self.finish(0.5 + 0.5 * self.time_left)
        elif self.pos <= -1:
            self.finish(0.25 * (1 - self.time_left))

    def on(self, action):
        if action != "hit":
            return
        if self.cue() and not self.heaved:
            self.pos += 0.2
            self.heaved = True
        else:
            self.pos -= 0.05

    def timeout(self):
        self.finish(0.5 + 0.25 * self.pos)

    def bot(self, rng, skill):
        if self.cue() and not self.heaved and self.t - self.cue_at > 0.08 + 0.3 * (1 - skill) * rng.random():
            return [("press", "hit"), ("release", "hit")]
        return []

    def draw(self):
        return [("rect", 120, 170, 400, 8, "#8a6a42"), ("rect", 318, 160, 4, 28, DIM),
                ("circle", 320 + self.pos * 190, 174, 12, ACCENT),
                ("circle", 320, 110, 18, GOOD if self.cue() else BG2),
                ("text", 320, 70, "HEAVE!" if self.cue() else "...", 16, INK, "center")]


class Footrace(Game):
    id, title = "footrace", "Footrace"
    help = "Hold space to sprint (it spends your wind); let go to catch your breath. Beat the pace to the line."
    limit = 30.0
    holds = True
    mount = False

    def setup(self):
        self.dist, self.wind = 0.0, 1.0
        self.goal = 1.0
        self.pace = (0.045 + 0.02 * self.d) * (1.25 if self.mount else 1.0)      # the rival's speed
        self.rival = 0.0

    def step(self, dt):
        sprint = "hit" in self.held and self.wind > 0.02
        speed = (0.075 if sprint else 0.04) * (1.25 if self.mount else 1.0)
        if self.wind <= 0.05:
            speed *= 0.5
        self.dist += self.sp(speed) * dt
        self.wind = max(0.0, min(1.0, self.wind + (-0.28 if sprint else 0.12) * dt))
        self.rival += self.sp(self.pace) * dt
        if self.dist >= self.goal:
            self.finish(0.5 + 0.5 * _clamp((self.goal - self.rival) / 0.4))
        elif self.rival >= self.goal:
            self.finish(0.5 * _clamp(self.dist / self.goal))

    def bot(self, rng, skill):
        want = self.wind > 0.15 + 0.4 * (1 - skill) * rng.random() or self.goal - self.dist < 0.1
        return [("press" if want else "release", "hit")]

    def draw(self):
        return [("rect", 60, 140, 520, 6, BG2), ("rect", 578, 120, 4, 46, INK),
                ("circle", 60 + 520 * min(1, self.dist), 130, 10, ACCENT),
                ("circle", 60 + 520 * min(1, self.rival), 160, 10, BAD)] + self.bar(200, 230, 240, 14, self.wind, GOOD) + \
            [("text", 320, 270, "wind", 11, DIM, "center")]


class HorseRace(Footrace):
    id, title = "horserace", "Horse race"
    help = "Hold space to urge your mount on (it tires); ease off to let it breathe. Beat the field home."
    mount = True


class Joust(_Graded):
    id, title = "joust", "The joust"
    help = "Up and down to steady the lance on the shield as the horses close; it strikes when they meet."
    pad = "ud"
    limit = 30.0
    holds = True

    def setup(self):
        self.passes: list[float] = []
        self.new_pass()

    def new_pass(self):
        self.gap = 1.0
        self.tip = self.rng.uniform(-0.6, 0.6)
        self.drift = self.rng.choice((-1, 1)) * (0.2 + 1.4 * self.d)

    def step(self, dt):
        self.gap -= self.sp(0.35) * dt
        self.tip += (self.drift * math.sin(self.t * 3.1) - (0.8 if "up" in self.held else 0)
                     + (0.8 if "down" in self.held else 0)) * dt
        self.tip = max(-1.0, min(1.0, self.tip))
        if self.gap <= 0:
            self.passes.append(_clamp(1 - abs(self.tip) / 0.5))
            if len(self.passes) >= 3:
                self.finish(sum(self.passes) / 3)
            else:
                self.new_pass()

    def bot(self, rng, skill):
        if abs(self.tip) < 0.05 + 0.3 * (1 - skill):
            return [("release", "up"), ("release", "down")]
        return [("press", "up" if self.tip > 0 else "down"), ("release", "down" if self.tip > 0 else "up")]

    def draw(self):
        return [("rect", 60 + 200 * (1 - self.gap), 200, 40, 30, "#8a5a34"),
                ("rect", 540 - 200 * (1 - self.gap), 200, 40, 30, "#5a4a7a"),
                ("circle", 500, 160, 30, "#a8a8a8"), ("circle", 500, 160, 8, "#a02a2a"),
                ("line", 100 + 200 * (1 - self.gap), 210, 500, 160 + self.tip * 60, ACCENT, 3),
                ("text", 320, 300, f"Pass {len(self.passes) + 1} of 3", 13, INK, "center")]


class Pig(_Graded):
    id, title = "pig", "Greased pig chase"
    help = "Chase the pig round the pen (arrows) and grab it (space) when you're on it."
    pad = "arrows"
    pad_hit = True
    limit = 25.0
    holds = True

    def setup(self):
        self.x, self.y = 0.2, 0.5
        self.px, self.py = 0.7, 0.5
        self.vx, self.vy = 0.0, 0.0
        self.slip = 0.25 + 0.9 * self.d
        self.tries = 0
        self.limit = 25.0 - 12.0 * self.d

    def step(self, dt):
        sp = 0.45
        self.x += ((1 if "right" in self.held else 0) - (1 if "left" in self.held else 0)) * sp * dt
        self.y += ((1 if "down" in self.held else 0) - (1 if "up" in self.held else 0)) * sp * dt
        if self.rng.random() < 2 * dt:
            a = self.rng.uniform(0, 2 * math.pi)
            self.vx, self.vy = math.cos(a) * self.slip, math.sin(a) * self.slip
        dx, dy = self.px - self.x, self.py - self.y
        if math.hypot(dx, dy) < 0.2:                   # it runs from you
            self.vx += dx * 2 * dt
            self.vy += dy * 2 * dt
        self.px = min(0.95, max(0.05, self.px + self.sp(self.vx) * dt))
        self.py = min(0.95, max(0.05, self.py + self.sp(self.vy) * dt))
        self.x, self.y = min(0.95, max(0.05, self.x)), min(0.95, max(0.05, self.y))

    def on(self, action):
        if action != "hit":
            return
        self.tries += 1
        if math.hypot(self.px - self.x, self.py - self.y) < 0.07 and self.rng.random() > self.slip * 0.75:
            self.finish(self.time_left - 0.03 * self.tries)

    def timeout(self):
        self.finish(0.3 - min(0.25, 0.02 * self.tries))

    def bot(self, rng, skill):
        out = []
        for k, cond in (("right", self.px > self.x + 0.02), ("left", self.px < self.x - 0.02),
                        ("down", self.py > self.y + 0.02), ("up", self.py < self.y - 0.02)):
            out.append(("press" if cond and rng.random() < 0.6 + 0.4 * skill else "release", k))
        if math.hypot(self.px - self.x, self.py - self.y) < 0.06 and (self._bot_at is None or self.t >= self._bot_at):
            self._bot_at = self.t + 0.4
            out += [("press", "hit"), ("release", "hit")]
        return out

    def draw(self):
        return [("frame", 120, 40, 400, 280, DIM), ("circle", 120 + self.px * 400, 40 + self.py * 280, 12, "#e8a0a0"),
                ("circle", 120 + self.x * 400, 40 + self.y * 280, 10, ACCENT)]


class Eating(_Graded):
    id, title = "eating", "Eating contest"
    help = "Eat (space) as fast as you can, but let your belly settle: burst and you're out."
    limit = 20.0

    def setup(self):
        self.eaten, self.belly = 0, 0.0
        self.goal = 10 + int(10 * self.d)
        self.bite = 0.12 + 0.06 * self.d

    def step(self, dt):
        self.belly = max(0.0, self.belly - self.sp(0.18) * dt)

    def on(self, action):
        if action != "hit":
            return
        self.eaten += 1
        self.belly += self.bite
        if self.belly >= 1.0:
            self.finish(0.5 * self.eaten / self.goal, "You can't eat another bite.")
        elif self.eaten >= self.goal:
            self.finish(0.5 + 0.5 * self.time_left)

    def timeout(self):
        self.finish(0.5 * self.eaten / self.goal)

    def bot(self, rng, skill):
        if self.belly < 0.75 - 0.3 * (1 - skill) * rng.random() and rng.random() < 0.4:
            return [("press", "hit"), ("release", "hit")]
        return []

    def draw(self):
        return self.bar(170, 200, 300, 20, self.belly, BAD if self.belly > 0.75 else GOOD) + [
            ("text", 320, 150, f"Pies eaten: {self.eaten} of {self.goal}", 16, INK, "center"),
            ("text", 320, 250, "belly", 11, DIM, "center")]


class Apples(_Graded):
    id, title = "apples", "Apple bobbing"
    help = "Hold space to duck under (it costs breath); let go to bite when the apple's at the centre."
    limit = 25.0
    holds = True

    def setup(self):
        self.breath, self.under, self.got = 1.0, False, 0
        self.goal = 2 + int(4 * self.d)
        self.apple = 0.0
        self.speed = 1.2 + 3.0 * self.d
        self.limit = 30.0 - 10.0 * self.d

    def step(self, dt):
        self.apple = math.sin(self.t * self.sp(self.speed))
        down = "hit" in self.held
        if down and not self.under:
            self.under = True
            self.dipped = self.t
        if self.under:
            self.breath -= 0.35 * dt
            if self.breath <= 0:
                self.finish(0.4 * self.got / self.goal, "You come up spluttering.")
            if not down:
                self.under = False
                deep = self.t - getattr(self, "dipped", self.t) >= 0.5 + 1.0 * self.d    # got your face in
                if deep and abs(self.apple) < 0.25 - 0.17 * self.d:
                    self.got += 1
                    if self.got >= self.goal:
                        self.finish(self.time_left)
        else:
            self.breath = min(1.0, self.breath + 0.25 * dt)

    def timeout(self):
        self.finish(0.5 * self.got / self.goal)

    def bot(self, rng, skill):
        if not self.under:
            return [("press", "hit")] if self.breath > 0.6 else []
        if self.t - getattr(self, "dipped", self.t) >= 0.5 + 1.0 * self.d and \
                abs(self.apple) < 0.06 + 0.25 * (1 - skill) * rng.random():
            return [("release", "hit")]
        return []

    def draw(self):
        return [("rect", 160, 180, 320, 120, "#3a5a7a"), ("circle", 320 + self.apple * 140, 190, 14, BAD),
                ("rect", 318, 150, 4, 40, ACCENT if self.under else DIM)] + self.bar(220, 320, 200, 12, self.breath, GOOD) + \
            [("text", 320, 120, f"Apples: {self.got} of {self.goal}", 15, INK, "center")]


class Snowball(_Graded):
    id, title = "snowball", "Snowball fight"
    help = "Dodge (left and right) out of the lane they're throwing at; throw (space) when they stick their head up."
    pad = "lr"
    pad_hit = True
    limit = 25.0

    def setup(self):
        self.lane, self.hits, self.hit_by = 1, 0, 0
        self.foe_lane = 1
        self.incoming, self.at = None, 1.2
        self.up_at = 0.8
        self.warn = 0.9 - 0.8 * self.d

    def step(self, dt):
        if self.incoming is None and self.t >= self.at:
            lanes = {self.rng.randrange(3)}
            if self.rng.random() < self.d:                    # two at once: only one lane is safe
                lanes.add(self.rng.randrange(3))
            self.incoming = (lanes, self.t + self.warn, self.t)
        if self.incoming is not None and self.t >= self.incoming[1]:
            if self.lane in self.incoming[0]:
                self.hit_by += 1
            self.incoming = None
            self.at = self.t + self.rng.uniform(0.6, 1.4)
        if self.t > self.up_at + 0.6:
            self.up_at = self.t + self.rng.uniform(0.5, 1.5)
            self.foe_lane = self.rng.randrange(3)
        if self.hits >= 5:
            self.finish(_clamp(self.hits / (self.hits + self.hit_by)))
        elif self.hit_by >= 5:
            self.finish(_clamp(0.08 * self.hits))

    def exposed(self) -> bool:
        return self.up_at <= self.t <= self.up_at + 0.6 - 0.35 * self.d

    def on(self, action):
        if action == "left":
            self.lane = max(0, self.lane - 1)
        elif action == "right":
            self.lane = min(2, self.lane + 1)
        elif action == "hit" and self.exposed() and self.lane == self.foe_lane:   # in line with them
            self.hits += 1
            self.up_at = self.t + self.rng.uniform(0.5, 1.5)
            self.foe_lane = self.rng.randrange(3)

    def timeout(self):
        self.finish(_clamp(0.5 + 0.08 * (self.hits - self.hit_by)))

    def bot(self, rng, skill):
        out = []
        react = 0.18 + 0.3 * (1 - skill)
        if self.incoming is not None and self.lane in self.incoming[0] and self.t - self.incoming[2] >= react:
            safe = [k for k in range(3) if k not in self.incoming[0]]
            if safe:
                out.append(("press", "left" if safe[0] < self.lane else "right"))
            return out
        if self.exposed() and self.lane != self.foe_lane and rng.random() < 0.15 + 0.4 * skill:
            out.append(("press", "left" if self.foe_lane < self.lane else "right"))
            return out
        if self.exposed() and rng.random() < 0.1 + 0.3 * skill:
            out.append(("press", "hit"))
        return out

    def draw(self):
        out = [("rect", 140 + i * 130, 260, 100, 20, BG2) for i in range(3)]
        out.append(("circle", 190 + self.lane * 130, 250, 14, ACCENT))
        if self.incoming is not None:
            for k in self.incoming[0]:
                out.append(("circle", 190 + k * 130, 150, 10, INK))
        out.append(("circle", 190 + self.foe_lane * 130, 70, 16, GOOD if self.exposed() else BG2))
        out.append(("text", 320, 320, f"Hits {self.hits}   Hit by {self.hit_by}", 13, INK, "center"))
        return out


NEW = (Archery, Knives, LogToss, Tug, Footrace, HorseRace, Joust, Pig, Eating, Apples, Snowball)
for _g in NEW:
    GAMES[_g.id] = _g


# ======================================================================================================
# The contests
# ======================================================================================================
CONTESTS = {
    "archery": {"name": "Archery", "game": "archery", "help": ("dex", "bow")},
    "knife_throwing": {"name": "Knife throwing", "game": "knives", "help": ("dex",)},
    "log_toss": {"name": "Log toss", "game": "logtoss", "help": ("Athletics",)},
    "tug_of_war": {"name": "Tug-of-war", "game": "tug", "help": ("Athletics",)},
    "footrace": {"name": "Footrace", "game": "footrace", "help": ("dex", "con")},
    "horse_race": {"name": "Horse race", "game": "horserace", "help": ("Animal Handling",), "mount": True},
    "joust": {"name": "The joust", "game": "joust", "help": ("Athletics", "Animal Handling"), "mount": True,
              "both": True},
    "greased_pig": {"name": "Greased pig chase", "game": "pig", "help": ("Acrobatics",)},
    "eating": {"name": "Eating contest", "game": "eating", "help": ("con",)},
    "apple_bobbing": {"name": "Apple bobbing", "game": "apples", "help": ("con",)},
    "snowball": {"name": "Snowball fight", "game": "snowball", "help": ("dex",)},
    "dance": {"name": "Dance", "game": "rhythm", "help": ("Performance",)},
    "bards": {"name": "Bard's competition", "game": "rhythm", "help": ("Performance", "instrument")},
    "riddles": {"name": "Riddle contest", "game": "lore", "help": ("int", "books")},
    "fishing_derby": {"name": "Fishing derby", "game": "tension", "help": ("Survival",)},
    "arm_wrestling": {"name": "Arm wrestling", "game": "power", "help": ("Athletics",)},
}


CATEGORY = {"dance": "social", "bards": "social", "riddles": "knowledge", "fishing_derby": "tools"}


def category(cid: str) -> str:
    """Which Settings > Checks kind decides whether it's played as a minigame."""
    return CATEGORY.get(cid, "physical")


def roll(world, state, members, town, festival_key: str, cid: str, perf: float | None = None,
         rng: random.Random | None = None, bus=None) -> dict:
    """Do the contest: a minigame's performance (perf), or else a d20, then settle() it."""
    from game import minigames as M
    who, b = entrant(world, state, members, cid)
    need = need_for(town, festival_key, cid, b)
    if perf is None:
        nat = (rng or random.Random()).randint(1, 20)
        if bus is not None:
            bus.emit("log", kind="roll", text=f"{who.get('name')}: {CONTESTS[cid]['name']}: d20 {nat} "
                                              f"{'+' if b >= 0 else '-'} {abs(b)} = {nat + b}")
    else:
        nat = M.natural_for(perf, need)
    return settle(world, state, members, town, festival_key, cid, nat, bus)


def bonus(world, state, member, cid: str) -> int:
    """What a member brings to a contest: the stat or skill it leans on, and what else helps."""
    from game import books, checks, condition
    c = condition.combatant(world, member)
    opts = {o["label"]: o for o in checks.options(world)}
    info = CONTESTS[cid]
    parts = []
    extra = 0
    for h in info["help"]:
        if h in ("dex", "con", "str", "int", "wis", "cha"):
            parts.append(c.mods.get(h, 0))
        elif h in opts:
            parts.append(checks.bonus(world, member, c, opts[h])[0])
        elif h == "bow":
            items = list((member.get("equipment") or {}).values()) + list((member.get("inventory") or {}).keys())
            if any("bow" in (world.entities.get(i).name.lower() if world.entities.get(i) else "") for i in items):
                extra += c.prof
        elif h == "instrument":
            if any(o["kind"] == "Tool" and o["label"].lower() in INSTRUMENTS and checks.proficient(world, member, o)
                   for o in opts.values()):
                extra += c.prof
        elif h == "books":
            extra += min(5, len(books.lore(state).get("read") or []) // 5)
    if not parts:
        parts = [0]
    base = round(sum(parts) / len(parts)) if info.get("both") else max(parts)
    return int(base + extra)


def needs_mount(cid: str) -> bool:
    return bool(CONTESTS[cid].get("mount"))


def has_mount(world, state, members) -> bool:
    from game import animals
    return any(animals.mount_of(world, state, m.get("id")) for m in members or [] if not m.get("dead")) or \
        any(v.get("role") == "mount" for v in animals.owned(state))


def entrant(world, state, members, cid: str):
    """Who goes in for the party: whoever's best at it."""
    best = None
    for m in members or []:
        if m.get("dead"):
            continue
        b = bonus(world, state, m, cid)
        if best is None or b > best[1]:
            best = (m, b)
    return best


def rivals(town, festival_key: str, cid: str, n: int = 4) -> list[tuple[str, int]]:
    """The town's entrants and their marks (d20 + skill), the same for anyone who asks."""
    from game import settlements as ST
    tier = ST.tier_of(town) if town is not None else "Town"
    rng = random.Random(zlib.crc32(f"{town.id if town else ''}|{festival_key}|{cid}".encode()))
    names = ["Big Hal", "Wren", "Old Tam", "Marisol", "the smith's boy", "Brisk Kettle", "Ysolde", "Fennick",
             "the miller's daughter", "Doran the Red", "Lark", "Bors"]
    rng.shuffle(names)
    b = RIVAL_BONUS.get(tier, 3)
    return sorted(((names[i], rng.randint(1, 20) + b + rng.randint(-1, 2)) for i in range(n)), key=lambda x: -x[1])


def need_for(town, festival_key: str, cid: str, bonus_: int) -> int:
    """The natural roll (and so the minigame's difficulty) it takes to beat the best of them."""
    top = rivals(town, festival_key, cid)[0][1]
    return max(2, min(20, top + 1 - bonus_))


def settle(world, state, members, town, festival_key: str, cid: str, natural: int, bus=None) -> dict:
    """The result: first, second, or out of the running, with the prizes. natural: the d20 (or what the
    minigame counts as)."""
    from game import settlements as ST
    from game import townevents as TE
    from game.state import money_text
    who, b = entrant(world, state, members, cid)
    total = int(natural) + b
    field = rivals(town, festival_key, cid)
    better = sum(1 for _n, mark in field if mark >= total)
    place = better + 1
    purse = PURSE.get(ST.tier_of(town) if town is not None else "Town", 25) * 100
    prize = ""
    pay = 0
    if place == 1:
        pay = purse
        rng = random.Random(zlib.crc32(f"{festival_key}|{cid}|prize".encode()))
        pool = [i for i in world.entities.all("item") if (i.fields.get("rarity") or "") == "Uncommon"
                and (i.fields.get("category") or "") not in ("Book",)]
        if pool and rng.random() < 0.5:
            prize = rng.choice(sorted(pool, key=lambda i: i.id)).id
            state.add_item(prize, 1, source="a festival prize")
    elif place == 2:
        pay = purse // 3
    if pay:
        state.add_copper(pay, f"{CONTESTS[cid]['name']} prize")
    TE.took_part(world, state, town, place == 1, bus)
    name = CONTESTS[cid]["name"]
    if place == 1:
        text = f"{who.get('name')} wins the {name.lower()} ({total} against {field[0][0]}'s {field[0][1]})! " \
               f"The purse is {money_text(pay)}" + (f", and {world.entities.get(prize).name}" if prize else "") + "."
    elif place == 2:
        text = f"{who.get('name')} comes second in the {name.lower()}, behind {field[0][0]}: {money_text(pay)}."
    else:
        text = f"{who.get('name')} finishes {place}{'th' if place > 3 else 'rd'} in the {name.lower()}. " \
               f"{field[0][0]} takes it."
    if bus is not None:
        bus.emit("log", kind="loot" if place <= 2 else "narration", text=text)
    state.save()
    return {"place": place, "total": total, "pay": pay, "prize": prize, "text": text, "rivals": field,
            "who": who.get("id")}


__all__ = ["CONTESTS", "category", "roll", "bonus", "entrant", "rivals", "need_for", "settle", "needs_mount", "has_mount", "NEW"]
