"""Game controllers: reading them, and turning sticks and buttons into the game's actions.

Two ways of reading a controller, tried in this order:
  * XInput (Windows' own controller library, nothing to install): Xbox controllers and anything that
    presents itself as one (most PC pads, and PlayStation pads through Steam or DS4Windows).
  * SDL through pygame (pygame-ce or pygame, installed by run.bat if it can): PlayStation, Switch and
    most other pads, on any system, laid out like an Xbox pad.

Every controller is described in Xbox terms: A B X Y, LB RB, LT RT, Back Start, the D-pad, and the two
sticks. No Qt in here: the window polls a Pad with a timer (ui/gamepad.py) and hands what comes out of
Mapper.update() to the screen.
"""
from __future__ import annotations

import math
import os
import sys
import time

BUTTONS = ["A", "B", "X", "Y", "LB", "RB", "BACK", "START", "LS", "RS", "UP", "DOWN", "LEFT", "RIGHT", "LT", "RT"]
DEADZONE = 0.45               # how far a stick must lean before it counts
TRIGGER = 0.5
STICK_MIN = 0.22              # a stick leaning less than this is left alone (cursors and pointer)
REPEAT_DELAY = 0.38           # seconds before a held direction repeats (menus)
REPEAT_RATE = 0.12


class PadState:
    """One reading: buttons held (a set of names) and the left stick (x right, y down, -1..1)."""

    def __init__(self, buttons=(), lx: float = 0.0, ly: float = 0.0, rx: float = 0.0, ry: float = 0.0,
                 lt: float = 0.0, rt: float = 0.0, name: str = "") -> None:
        self.buttons = set(buttons)
        self.lx, self.ly, self.rx, self.ry, self.lt, self.rt = lx, ly, rx, ry, lt, rt
        self.name = name
        if lt >= TRIGGER:
            self.buttons.add("LT")
        if rt >= TRIGGER:
            self.buttons.add("RT")

    def direction(self) -> str:
        """Which way the D-pad or left stick points: '', N, NE, E ... (eight ways)."""
        dx = (1 if "RIGHT" in self.buttons else 0) - (1 if "LEFT" in self.buttons else 0)
        dy = (1 if "DOWN" in self.buttons else 0) - (1 if "UP" in self.buttons else 0)
        if not dx and not dy and math.hypot(self.lx, self.ly) >= DEADZONE:
            ang = math.degrees(math.atan2(self.ly, self.lx)) % 360          # 0 = right, 90 = down
            sector = int(((ang + 22.5) % 360) // 45)
            dx, dy = [(1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1), (0, -1), (1, -1)][sector]
        return (("N" if dy < 0 else "S" if dy > 0 else "") + ("E" if dx > 0 else "W" if dx < 0 else ""))


class Mapper:
    """Turns readings into events: ('press', button), ('release', button), ('dir', direction held,
    '' when let go), and ('nav', direction) for menus, repeating while held."""

    def __init__(self) -> None:
        self.prev = PadState()
        self.dir = ""
        self._nav_next = 0.0

    def update(self, st: PadState | None, now: float | None = None) -> list[tuple]:
        now = time.monotonic() if now is None else now
        st = st or PadState()
        out = []
        for b in BUTTONS:
            if b in ("UP", "DOWN", "LEFT", "RIGHT"):
                continue
            if b in st.buttons and b not in self.prev.buttons:
                out.append(("press", b))
            elif b not in st.buttons and b in self.prev.buttons:
                out.append(("release", b))
        d = st.direction()
        if d != self.dir:
            self.dir = d
            out.append(("dir", d))
            if d:
                out.append(("nav", d))
                self._nav_next = now + REPEAT_DELAY
        elif d and now >= self._nav_next:
            out.append(("nav", d))
            self._nav_next = now + REPEAT_RATE
        # the sticks as they lean, every reading (for cursors and the pointer)
        lx, ly = st.lx, st.ly
        dpx = (1 if "RIGHT" in st.buttons else 0) - (1 if "LEFT" in st.buttons else 0)
        dpy = (1 if "DOWN" in st.buttons else 0) - (1 if "UP" in st.buttons else 0)
        if dpx or dpy:
            n = math.hypot(dpx, dpy)
            lx, ly = dpx / n * 0.7, dpy / n * 0.7
        if math.hypot(lx, ly) >= STICK_MIN:
            out.append(("lstick", lx, ly))
        if math.hypot(st.rx, st.ry) >= STICK_MIN:
            out.append(("rstick", st.rx, st.ry))
        self.prev = st
        return out


def pick_nearest(here: tuple, points: list[tuple], direction: str) -> int | None:
    """Which of `points` (x, y; y down) is the nearest one from `here` in a direction (N, SE...):
    straight ahead counts for more than off to the side. None when there's nothing that way."""
    dx = (1 if "E" in direction else 0) - (1 if "W" in direction else 0)
    dy = (1 if "S" in direction else 0) - (1 if "N" in direction else 0)
    if not dx and not dy:
        return None
    best, bd = None, 1e18
    for i, (px, py) in enumerate(points):
        vx, vy = px - here[0], py - here[1]
        along = vx * dx + vy * dy
        if along <= 4:
            continue
        side = abs(vx * dy - vy * dx)
        d = along + side * 2.2
        if d < bd:
            best, bd = i, d
    return best


# ======================================================================
# Reading controllers
# ======================================================================
class Pad:
    """Whatever controller is plugged in. read() gives a PadState, or None with nothing connected."""

    def __init__(self) -> None:
        self.backends = []
        self.name = ""
        if sys.platform.startswith("win"):
            try:
                self.backends.append(XInput())
            except OSError:
                pass
        try:
            self.backends.append(SDL())
        except Exception:  # noqa: BLE001 - pygame missing or broken: XInput (or nothing) it is
            pass

    @property
    def available(self) -> bool:
        return bool(self.backends)

    def describe(self) -> str:
        return ", ".join(b.label for b in self.backends) or "none"

    def read(self) -> PadState | None:
        for b in self.backends:
            try:
                st = b.read()
            except Exception:  # noqa: BLE001 - a flaky driver mustn't take the game down
                st = None
            if st is not None:
                self.name = st.name
                return st
        self.name = ""
        return None

    def close(self) -> None:
        for b in self.backends:
            try:
                b.close()
            except Exception:  # noqa: BLE001
                pass


class XInput:
    """Windows' XInput: up to four Xbox-style controllers."""

    label = "XInput"
    BITS = {0x0001: "UP", 0x0002: "DOWN", 0x0004: "LEFT", 0x0008: "RIGHT", 0x0010: "START", 0x0020: "BACK",
            0x0040: "LS", 0x0080: "RS", 0x0100: "LB", 0x0200: "RB", 0x1000: "A", 0x2000: "B", 0x4000: "X",
            0x8000: "Y"}

    def __init__(self) -> None:
        import ctypes
        from ctypes import wintypes

        class Gamepad(ctypes.Structure):
            _fields_ = [("wButtons", wintypes.WORD), ("bLeftTrigger", ctypes.c_ubyte),
                        ("bRightTrigger", ctypes.c_ubyte), ("sThumbLX", ctypes.c_short),
                        ("sThumbLY", ctypes.c_short), ("sThumbRX", ctypes.c_short), ("sThumbRY", ctypes.c_short)]

        class State(ctypes.Structure):
            _fields_ = [("dwPacketNumber", wintypes.DWORD), ("Gamepad", Gamepad)]

        self._ct = ctypes
        self._State = State
        dll = None
        for name in ("xinput1_4", "xinput1_3", "xinput9_1_0"):
            try:
                dll = ctypes.WinDLL(name)
                break
            except OSError:
                continue
        if dll is None:
            raise OSError("no XInput library")
        self._get = dll.XInputGetState
        self._get.argtypes = [wintypes.DWORD, ctypes.POINTER(State)]
        self._get.restype = wintypes.DWORD
        self.slot = -1
        self._next_scan = 0.0

    def read(self) -> PadState | None:
        st = self._State()
        if self.slot >= 0:
            if self._get(self.slot, self._ct.byref(st)) == 0:
                return self._state(st)
            self.slot = -1
        now = time.monotonic()
        if now < self._next_scan:                 # asking empty slots is slow: only now and then
            return None
        self._next_scan = now + 1.5
        for i in range(4):
            if self._get(i, self._ct.byref(st)) == 0:
                self.slot = i
                return self._state(st)
        return None

    def _state(self, st) -> PadState:
        g = st.Gamepad
        buttons = {name for bit, name in self.BITS.items() if g.wButtons & bit}
        return PadState(buttons, g.sThumbLX / 32768.0, -g.sThumbLY / 32768.0, g.sThumbRX / 32768.0,
                        -g.sThumbRY / 32768.0, g.bLeftTrigger / 255.0, g.bRightTrigger / 255.0,
                        f"Controller {self.slot + 1} (XInput)")

    def close(self) -> None:
        pass


class SDL:
    """pygame's SDL: the game-controller layer when there is one (any pad laid out like an Xbox pad),
    else a plain joystick read in the usual Xbox order."""

    label = "SDL"
    RAW = ["A", "B", "X", "Y", "LB", "RB", "BACK", "START", "LS", "RS"]

    def __init__(self) -> None:
        os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
        os.environ.setdefault("SDL_JOYSTICK_ALLOW_BACKGROUND_EVENTS", "1")
        import pygame
        self.pg = pygame
        pygame.display.init()                     # events need it; no window is opened
        pygame.joystick.init()
        try:
            from pygame._sdl2 import controller
            controller.init()
            self.ctl = controller
        except Exception:  # noqa: BLE001 - older pygame: plain joysticks only
            self.ctl = None
        self.dev = None
        self.kind = ""
        self._next_scan = 0.0

    def _open(self) -> None:
        pg = self.pg
        now = time.monotonic()
        if now < self._next_scan:
            return
        self._next_scan = now + 1.5
        for i in range(pg.joystick.get_count()):
            if self.ctl is not None and self.ctl.is_controller(i):
                self.dev, self.kind = self.ctl.Controller(i), "controller"
                self.dev_name = self._name_for(i)
                return
        if pg.joystick.get_count():
            self.dev, self.kind = pg.joystick.Joystick(0), "joystick"
            self.dev.init()
            self.dev_name = self._name_for(0)

    def _name_for(self, i: int) -> str:
        try:
            if self.ctl is not None and hasattr(self.ctl, "name_forindex"):
                n = self.ctl.name_forindex(i)
                if n:
                    return str(n)
        except Exception:  # noqa: BLE001
            pass
        try:
            return str(self.pg.joystick.Joystick(i).get_name())
        except Exception:  # noqa: BLE001
            return "Controller"

    def read(self) -> PadState | None:
        pg = self.pg
        for e in pg.event.get():
            if e.type in (getattr(pg, "JOYDEVICEREMOVED", -1), getattr(pg, "CONTROLLERDEVICEREMOVED", -2)):
                self.dev = None
                self._next_scan = 0.0
            elif e.type in (getattr(pg, "JOYDEVICEADDED", -1), getattr(pg, "CONTROLLERDEVICEADDED", -2)):
                self._next_scan = 0.0
        if self.dev is None:
            self._open()
            if self.dev is None:
                return None
        try:
            if self.kind == "controller":
                return self._from_controller()
            return self._from_joystick()
        except pg.error:
            self.dev = None
            return None

    def _from_controller(self) -> PadState:
        pg, d = self.pg, self.dev
        if hasattr(d, "attached") and not d.attached():
            self.dev = None
            return None
        b = {}
        for name, const in (("A", "CONTROLLER_BUTTON_A"), ("B", "CONTROLLER_BUTTON_B"),
                            ("X", "CONTROLLER_BUTTON_X"), ("Y", "CONTROLLER_BUTTON_Y"),
                            ("LB", "CONTROLLER_BUTTON_LEFTSHOULDER"), ("RB", "CONTROLLER_BUTTON_RIGHTSHOULDER"),
                            ("BACK", "CONTROLLER_BUTTON_BACK"), ("START", "CONTROLLER_BUTTON_START"),
                            ("LS", "CONTROLLER_BUTTON_LEFTSTICK"), ("RS", "CONTROLLER_BUTTON_RIGHTSTICK"),
                            ("UP", "CONTROLLER_BUTTON_DPAD_UP"), ("DOWN", "CONTROLLER_BUTTON_DPAD_DOWN"),
                            ("LEFT", "CONTROLLER_BUTTON_DPAD_LEFT"), ("RIGHT", "CONTROLLER_BUTTON_DPAD_RIGHT")):
            c = getattr(pg, const, None)
            if c is not None and d.get_button(c):
                b[name] = True

        def axis(const):
            c = getattr(pg, const, None)
            return d.get_axis(c) / 32768.0 if c is not None else 0.0
        return PadState(b, axis("CONTROLLER_AXIS_LEFTX"), axis("CONTROLLER_AXIS_LEFTY"),
                        axis("CONTROLLER_AXIS_RIGHTX"), axis("CONTROLLER_AXIS_RIGHTY"),
                        max(0.0, axis("CONTROLLER_AXIS_TRIGGERLEFT")),
                        max(0.0, axis("CONTROLLER_AXIS_TRIGGERRIGHT")), self._name())

    def _from_joystick(self) -> PadState:
        d = self.dev
        b = {self.RAW[i] for i in range(min(d.get_numbuttons(), len(self.RAW))) if d.get_button(i)}
        if d.get_numhats():
            hx, hy = d.get_hat(0)
            if hx < 0:
                b.add("LEFT")
            elif hx > 0:
                b.add("RIGHT")
            if hy > 0:
                b.add("UP")
            elif hy < 0:
                b.add("DOWN")
        n = d.get_numaxes()
        ax = [d.get_axis(i) for i in range(n)]
        lt = (ax[4] + 1) / 2 if n > 5 else 0.0
        rt = (ax[5] + 1) / 2 if n > 5 else 0.0
        return PadState(b, ax[0] if n > 0 else 0.0, ax[1] if n > 1 else 0.0, ax[2] if n > 2 else 0.0,
                        ax[3] if n > 3 else 0.0, lt, rt, self._name())

    def _name(self) -> str:
        return getattr(self, "dev_name", "") or "Controller"

    def close(self) -> None:
        try:
            self.pg.joystick.quit()
        except Exception:  # noqa: BLE001
            pass


__all__ = ["pick_nearest", "Pad", "PadState", "Mapper", "XInput", "SDL", "BUTTONS"]
