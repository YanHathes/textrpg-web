"""Central event channel. (Town events, festivals and raids, are game/townevents.py: they announce themselves
here as "festival.started", "raid.started", "raid.ended" and "raid.lost".)

Every system announces what it does here ("action.chat", "combat.attack",
"player.moved", ...). Other systems listen without the announcer needing to
know about them. The Mechanics rule engine (a later stage) will plug in by
listening to these same events, so nothing has to be rewired later.

Patterns:
    "combat.attack"  exact name
    "combat.*"       everything starting with "combat."
    "*"              everything
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class Event:
    name: str
    data: dict[str, Any] = field(default_factory=dict)
    cancelled: bool = False

    def cancel(self) -> None:
        """Stop later listeners from receiving this event."""
        self.cancelled = True

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, default)


Listener = Callable[[Event], None]


class EventBus:
    def __init__(self, history_limit: int = 300) -> None:
        self._listeners: dict[str, list[Listener]] = defaultdict(list)
        self.history: list[Event] = []
        self.history_limit = history_limit

    def on(self, pattern: str, listener: Listener) -> Callable[[], None]:
        """Subscribe. Returns a function that unsubscribes."""
        self._listeners[pattern].append(listener)

        def off() -> None:
            if listener in self._listeners.get(pattern, []):
                self._listeners[pattern].remove(listener)

        return off

    def emit(self, name: str, **data: Any) -> Event:
        event = Event(name, data)
        self.history.append(event)
        if len(self.history) > self.history_limit:
            del self.history[: len(self.history) - self.history_limit]
        for pattern, listeners in list(self._listeners.items()):
            if not self._matches(pattern, name):
                continue
            for listener in list(listeners):
                listener(event)
                if event.cancelled:
                    return event
        return event

    @staticmethod
    def _matches(pattern: str, name: str) -> bool:
        if pattern == "*" or pattern == name:
            return True
        if pattern.endswith(".*"):
            return name.startswith(pattern[:-1])
        return False
