"""Upgrades worlds saved by older versions of the program.

Formats 2 -> 3 -> 4: test-pack top-ups for quests and the wider world (see migrate()).
Format 4 -> 5: mechanics get their new layout (see _to_v5), and test-pack worlds get the examples.
Format 5 -> 6: characters (backgrounds, feats, Stamina skills, starting gear...). Older party members
are filled in when the party loads (game.character.normalize); test-pack worlds get the new content.
Format 6 -> 7: regions, landmarks, dungeons, NPC schedules (new types and fields need nothing converted);
test-pack worlds get examples of each.
Format 7 -> 8: continents, hex travel, tiered maps, room-kind dungeons and passages (ships, airships,
caravans). Nothing to convert; test-pack worlds get three continents and the ways between them.

Format 1 -> 2: Spells and features used to be kinds of Skill. They are now
their own types:
  * Skill entities of kind "Spell" become Spell entities.
  * Skill entities of kind "Ability" or "Feat" become Feature entities.
  * Class feature rows that were only text become Feature entities (with the
    text kept as a Note), and the class links to them.
  * Race trait rows (text) become Feature entities the race links to.
Every link anywhere in the world is rewritten to the new ids. If the world has
the test pack, its new working features are added too.
"""
from __future__ import annotations

from game.entities import Entity, _now

SPELL_KEYS = {"level", "school", "casting_time", "range_ft", "effect", "save_stat", "on_save", "damage",
              "damage_type", "healing", "missiles", "area", "area_ft", "upcast", "concentration", "duration",
              "components", "material", "ritual", "classes"}
USES = {"Per short rest": "Per short rest", "Per long rest": "Per long rest", "Per day": "Per long rest",
        "Recharge 5-6": "Recharge 5-6", "Recharge 6": "Recharge 6"}


def migrate(world) -> bool:
    """Bring world up to date. Returns True if anything changed."""
    fmt = int(world.meta.get("format", 1) or 1)
    from game.world import WORLD_FORMAT
    if fmt >= WORLD_FORMAT:
        return False
    if fmt < 2:
        _to_v2(world)
    if fmt < 5:
        _to_v5(world)
    # Formats 3 and 4 (quests, the wider world): test-pack worlds get place descriptions, goblins that
    # carry ore, goods to trade, a second town, roads, opening hours and street NPCs.
    if any("test pack" in e.tags for e in world.entities.everything()):
        from game.starter import install_test_features
        install_test_features(world)
    world.meta["format"] = WORLD_FORMAT
    world.save_meta()
    return True


def _to_v2(world) -> None:
    s = world.entities
    remap: dict[str, str] = {}

    def add(type_name: str, name: str, fields: dict, description: str = "", tags=(), created="") -> Entity:
        e = Entity(id=s._new_id(type_name, name), type=type_name, name=name, description=description,
                   tags=list(tags), fields=fields, created=created or _now(), modified=_now())
        s.put(e)
        return e

    # 1. Spell and ability "skills" become their own types.
    for old in list(s.all("skill")):
        kind = old.fields.get("kind", "Skill")
        if kind == "Spell":
            fields = {k: v for k, v in old.fields.items() if k in SPELL_KEYS}
            new = add("spell", old.name, fields, old.description, old.tags, old.created)
        elif kind in ("Ability", "Feat"):
            f = old.fields
            act = f.get("action") if f.get("action") in ("Action", "Bonus action", "Reaction", "Free") else "Passive"
            effects = []
            text = f.get("ability_effect") or ""
            if text or f.get("ability_dice"):
                effects.append({"effect": "Note", "amount": f.get("ability_dice") or "", "detail": text,
                                "only_when": "Always"})
            fields = {"kind": "Feat" if kind == "Feat" else "Monster ability", "activation": act,
                      "uses": USES.get(f.get("uses") or f.get("recharge") or "", "Unlimited"),
                      "uses_count": "1", "effects": effects}
            new = add("feature", old.name, fields, old.description, old.tags, old.created)
        else:
            continue
        new.custom = list(old.custom)
        s.remove(old.id)
        remap[old.id] = new.id

    # 2. Rewrite every link.
    def fix(value):
        if isinstance(value, str):
            return remap.get(value, value)
        if isinstance(value, list):
            return [fix(v) for v in value]
        if isinstance(value, dict):
            return {k: fix(v) for k, v in value.items()}
        return value

    if remap:
        for e in s.everything():
            e.fields = fix(e.fields)
            for c in e.custom:
                c["value"] = fix(c.get("value"))

    # 3. Text-only class features and race traits become Feature entities.
    def text_feature(name: str, description: str, kind: str, tags) -> str:
        existing = s.find_by_name("feature", name)
        if existing:
            return existing.id
        fields = {"kind": kind, "activation": "Passive",
                  "effects": [{"effect": "Note", "amount": "", "detail": description, "only_when": "Always"}]
                  if description else []}
        return add("feature", name, fields, description, tags).id

    for klass in s.all("class"):
        rows = klass.fields.get("features") or []
        if any(isinstance(r, dict) and "name" in r and "feature" not in r for r in rows):
            new_rows = []
            for r in rows:
                if not isinstance(r, dict):
                    continue
                if r.get("feature"):
                    new_rows.append({"level": r.get("level", 1), "feature": r["feature"]})
                elif r.get("name"):
                    fid = text_feature(r["name"], r.get("description", ""), "Class feature", klass.tags)
                    new_rows.append({"level": r.get("level", 1), "feature": fid})
            klass.fields["features"] = new_rows
    for race in s.all("race"):
        rows = race.fields.pop("traits", None) or []
        ids = list(race.fields.get("features") or [])
        for r in rows:
            if isinstance(r, dict) and r.get("name"):
                ids.append(text_feature(r["name"], r.get("description", ""), "Racial trait", race.tags))
        if ids:
            race.fields["features"] = ids

    # 4. Old test-pack fixes: the breath "spell" is a recharge feature now.
    test_pack = any("test pack" in e.tags for e in s.everything())
    if test_pack:
        breath = s.find_by_name("spell", "Fire Breath")
        if breath:
            for e in s.everything():
                if isinstance(e.fields.get("spells"), list) and breath.id in e.fields["spells"]:
                    e.fields["spells"] = [i for i in e.fields["spells"] if i != breath.id]
            s.remove(breath.id)
        old_wind = s.find_by_name("feature", "Second Wind")
        if old_wind and old_wind.fields.get("activation", "Passive") == "Passive":
            # the old text-only version: replaced by the working one below
            for klass in s.all("class"):
                klass.fields["features"] = [r for r in klass.fields.get("features") or []
                                            if r.get("feature") != old_wind.id]
            s.remove(old_wind.id)
    s.save()


APPLIES = {"Player": "Party members", "Allies": "Party members", "Everyone": "Anyone",
           "Specific entity": "Specific thing"}
ACTIONS = {"Change stat": "Change value", "Set stat": "Set value", "Log message": "Message",
           "Roll check": "Check (stop if failed)"}


def _to_v5(world) -> None:
    """Mechanics got a new layout: who it's for, where, how often, and clearer effect columns."""
    s = world.entities
    for m in s.all("mechanic"):
        f = m.fields
        if f.get("applies_to") in APPLIES:
            f["applies_to"] = APPLIES[f["applies_to"]]
        if f.get("trigger") in ("Item equipped", "Level up"):
            f["custom_event"] = f["trigger"].lower().replace(" ", "_")
            f["trigger"] = "Custom event"
        rows = []
        for r in f.get("effects") or []:
            if "to" in r:
                rows.append(r)
                continue
            target = str(r.get("target") or "")
            rows.append({"action": ACTIONS.get(r.get("action"), r.get("action") or "Message"),
                         "to": "Who it happened to", "amount": str(r.get("value") or ""),
                         "detail": target.split(".")[-1] if target else "", "thing": None,
                         "message": r.get("text") or ""})
        f["effects"] = rows
        f.setdefault("where", "Anywhere")
        f.setdefault("limit", "No limit")
    s.save()
