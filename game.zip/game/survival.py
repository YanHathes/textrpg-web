"""Survival (build plan step 16): hunger, thirst and sleep, and (a box of their own) disease and curses.

Everything is off until the world's rules turn it on (Settings > Survival). Off, nothing here does anything.

Needs (world rule "survival"; the sliders are world rules too):
    meals_per_day     1-10 (3)    each meal keeps a member fed for a day / this many
    drinks_per_day    1-10 (2)    each drink keeps a member watered for a day / this many
    hunger_hours      2-72 (24)   hours past being fed (or watered) before each level of exhaustion
    sleep_hours       2-72 (24)   hours without a long rest before each level of exhaustion
and three boxes: food_spoils (fresh food goes off in the pack), forage_less (foraging, harvesting and fishing
give half), cold_heat (the SRD's extreme cold and heat, from the season and the weather: warm clothing, water
and shade help).

The party eats and drinks on its own as the time comes, from the party pack and then its members' own bags:
anything marked a meal or a drink (item field "nourishes", set from the items' tags the first time: rations,
bread, cheese, jerky, ale, wine...). In a town there's always water at the wells; out of town it's the
waterskins (4 drinks each: refill them at a well, a river or a lake) or a drink from the pack. Cooked meals
(the kitchen's Consumable foods) leave a member some temporary hit points. Mounts and pack animals graze in
green country and are fed in town; elsewhere they eat Animal Feed, and go hungry (and slow) without it.
Exhaustion is the SRD's (game/combat/conditions.py): six levels is death. A long rest takes one level away, but
only for someone who has eaten and drunk. A journey stops when the food or water runs out.

Disease and curses (world rule "disease_curses"), kept per member in state.survival[member]["afflictions"]:
    diseases   the SRD's (cackle fever, sewer plague, sight rot) and the world's own (marsh ague, rat fever,
               bloody flux, grave chill, lover's pox): caught in swamps and sewers, from rats and some monsters' bites, bad
               water and spoiled food; a save to resist, then a save every day: failing worsens it, succeeding
               (enough times) shakes it off.
    curses     cursed items (they won't come off), lycanthropy and mummy rot from bites and touches, the curse
               of a sealed tomb (a crypt's treasure) and the wrath of a shrine (a shrine's offerings taken).
Cures: lesser restoration (a disease), greater restoration and remove curse (curses), a temple's priest for
gold, and remedies made at an alchemy lab (the Herbal Remedy cures an ordinary disease; Eyebright Salve, sight
rot).
"""
from __future__ import annotations

import random
import zlib

DAY = 1440
HOUR = 60
DEFAULTS = {"survival": False, "meals_per_day": 3, "drinks_per_day": 2, "hunger_hours": 24, "sleep_hours": 24,
            "food_spoils": False, "forage_less": False, "cold_heat": False, "disease_curses": False}
LIMITS = {"meals_per_day": (1, 10), "drinks_per_day": (1, 10), "hunger_hours": (2, 72), "sleep_hours": (2, 72)}
WATERSKIN_DRINKS = 4
SPOIL_DAYS = 5                  # fresh food in the pack: half of it goes off every this many days
FEED_DAYS = 2                   # an animal without feed or grazing this long goes hungry
GRAZING = {"Plains", "Forest", "Hills", "Savanna", "Swamp", "Taiga", "Jungle", "Coast"}
EXHAUSTION_DEATH = 6
PRESERVED_WORDS = ("ration", "dried", "jerky", "hardtack", "salt", "pickled", "smoked", "travel loaf", "rice cakes",
                   "sack of rice", "tea", "wheel of cheese", "honey cakes", "biscuit")
SURVIVAL_V = 1

# name -> (kind, stat, dc, incubation hours, effect, cure successes, how it's caught, remedy item)
#   effect: "exhaustion" (a level at onset; each failed day another, each good day one less, gone at 0),
#           "penalty" (-1 to attacks and checks a failed day; blind at -5), "max_hp" (loses 1d6 max HP a failed
#           day, dies at 0), "flux" (needs twice the water), "fits" (cackle fever: exhaustion, and laughing fits)
DISEASES = {
    "Cackle Fever": ("disease", "con", 13, 3, "fits", 3, "a ghoul's or a swarm's touch", "Herbal Remedy"),
    "Sewer Plague": ("disease", "con", 11, 48, "exhaustion", 0, "sewers and rats", "Herbal Remedy"),
    "Sight Rot": ("disease", "con", 15, 24, "penalty", 0, "bad water", "Eyebright Salve"),
    "Marsh Ague": ("disease", "con", 12, 24, "exhaustion", 0, "the swamps", "Herbal Remedy"),
    "Rat Fever": ("disease", "con", 11, 12, "exhaustion", 0, "rats' bites", "Herbal Remedy"),
    "Bloody Flux": ("disease", "con", 12, 12, "flux", 2, "bad water and spoiled food", "Herbal Remedy"),
    "Grave Chill": ("disease", "con", 13, 24, "max_hp", 3, "the cold touch of the restless dead", "Herbal Remedy"),
    "Lover's Pox": ("disease", "con", 12, 48, "exhaustion", 3, "a brothel's back rooms", "Herbal Remedy"),
}
CURSES = {
    "Lycanthropy": ("curse", "con", 12, 0, "moon", 0, "a werebeast's bite", ""),
    "Mummy Rot": ("curse", "con", 12, 0, "max_hp", 0, "a mummy's touch", ""),
    "Curse of the Sealed Tomb": ("curse", "wis", 13, 0, "penalty2", 0, "a sealed tomb's treasure", ""),
    "Wrath of the Shrine": ("curse", "wis", 13, 0, "penalty2", 0, "a shrine's offerings", ""),
    "Cursed Item": ("curse", "", 0, 0, "bound", 0, "a cursed item", ""),
}
AFFLICTIONS = {**DISEASES, **CURSES}
# monsters whose bite or touch carries something (by name, lower case, contains)
CARRIERS = [("swarm of rats", "Rat Fever", 0.5), ("giant rat", "Rat Fever", 0.4), ("rat", "Rat Fever", 0.3),
            ("otyugh", "Sewer Plague", 0.6), ("ghoul", "Cackle Fever", 0.3), ("ghast", "Cackle Fever", 0.4),
            ("mummy", "Mummy Rot", 0.6), ("werewolf", "Lycanthropy", 0.4), ("wererat", "Lycanthropy", 0.4),
            ("wereboar", "Lycanthropy", 0.4), ("weretiger", "Lycanthropy", 0.4), ("werebear", "Lycanthropy", 0.4),
            ("wight", "Grave Chill", 0.4), ("wraith", "Grave Chill", 0.5), ("zombie", "Grave Chill", 0.15)]
CURE_SPELLS = {"Lesser Restoration": "disease", "Greater Restoration": "curse", "Remove Curse": "curse",
               "Heal": "disease"}
PRIEST_PRICE = {"disease": 50, "curse": 150, "Lycanthropy": 300, "Mummy Rot": 250}
CURSED_ITEMS = ("Armor of Vulnerability", "Berserker Axe", "Demon Armor", "Shield of Missile Attraction")


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


# ======================================================================
# The rules
# ======================================================================
def rule(world, key: str):
    v = world.rules.get(key, DEFAULTS[key])
    if key in LIMITS:
        lo, hi = LIMITS[key]
        try:
            v = int(v)
        except (TypeError, ValueError):
            v = DEFAULTS[key]
        return max(lo, min(hi, v))
    return bool(v)


def on(world) -> bool:
    return bool(world.rules.get("survival", False))


def diseases_on(world) -> bool:
    return bool(world.rules.get("disease_curses", False))


def meal_minutes(world) -> float:
    return DAY / rule(world, "meals_per_day")


def drink_minutes(world) -> float:
    return DAY / rule(world, "drinks_per_day")


def hunger_minutes(world) -> int:
    return rule(world, "hunger_hours") * HOUR


def sleep_minutes(world) -> int:
    return rule(world, "sleep_hours") * HOUR


# ======================================================================
# The save's records
# ======================================================================
def data(state) -> dict:
    d = getattr(state, "survival", None)
    if d is None:
        state.survival = d = {}
    return d


def party_data(state) -> dict:
    p = data(state).setdefault("_party", {})
    p.setdefault("water", 0)
    p.setdefault("clean", True)
    return p


def rec(state, mid: str, minute: int | None = None) -> dict:
    """A member's needs (made fed, watered and rested as of `minute` the first time)."""
    d = data(state)
    r = d.get(mid)
    if r is None:
        now = int(state.minutes if minute is None else minute)
        r = d[mid] = {"food_until": now, "water_until": now, "hunger_levels": 0, "thirst_levels": 0,
                      "sleep_from": now, "sleep_levels": 0, "rest_seen": int(state.last_long_rest),
                      "afflictions": [], "heat_hours": 0}
    r.setdefault("afflictions", [])
    return r


def reset(state, m: dict, minute: int | None = None, fed: bool = True) -> dict:
    """Start a member's needs afresh: fed, watered and rested as of `minute` (for a new game, and tests)."""
    now = int(state.minutes if minute is None else minute)
    old = data(state).pop(m["id"], None) or {}
    r = rec(state, m["id"], now)
    r["afflictions"] = old.get("afflictions") or []
    if not fed:
        r["food_until"] = r["water_until"] = now
    return r


def afflictions(state, mid: str) -> list[dict]:
    r = data(state).get(mid)
    return list(r.get("afflictions") or []) if r else []


# ======================================================================
# Food and drink in the pack
# ======================================================================
def kind_of(item) -> str:
    """"Meal", "Drink", "Feed" or ""."""
    if item is None:
        return ""
    k = item.fields.get("nourishes") or ""
    if k:
        return k
    return _guess(item)


def _guess(item) -> str:
    tags = {str(t).lower() for t in item.tags}
    name = item.name.lower()
    cat = item.fields.get("category") or ""
    if cat in ("Weapon", "Armor", "Shield", "Ammunition") or "magic" in tags or "treasure" in tags:
        return ""
    if "feed" in tags or name in ("animal feed", "feed (per day)"):
        return "Feed"
    if "drink" in tags:
        return "Drink"
    if "food" in tags and "material" not in tags:
        return "Meal"
    if "ration" in name:
        return "Meal"
    return ""


def preserved(item) -> bool:
    if item is None:
        return True
    if item.fields.get("preserved"):
        return True
    n = item.name.lower()
    return any(w in n for w in PRESERVED_WORDS)


def _bags(world, state, members):
    """Where food can come from: the pack first, then each member's own bag."""
    return [("pack", None)] + [("member", m) for m in members]


def _items_in(world, state, where, m) -> dict:
    return state.inventory if where == "pack" else (m.get("inventory") or {})


def _take_one(world, state, members, kind: str, prefer_fresh: bool = True):
    """Take one meal (or drink, or feed) from the bags. Returns (item, from member or None) or (None, None)."""
    for where, m in _bags(world, state, members):
        inv = _items_in(world, state, where, m)
        cands = []
        for iid, n in list(inv.items()):
            if int(n) <= 0:
                continue
            e = world.entities.get(iid.split("@")[0] if "@" in iid else iid) or world.entities.get(iid)
            if kind_of(e) == kind:
                cands.append((not preserved(e) if prefer_fresh else preserved(e), e.name, iid, e))
        if not cands:
            continue
        cands.sort(key=lambda c: (not c[0], c[1]))        # fresh food first (before it spoils)
        _f, _n, iid, e = cands[0]
        if where == "pack":
            state.inventory[iid] = int(state.inventory[iid]) - 1
            if state.inventory[iid] <= 0:
                state.inventory.pop(iid, None)
        else:
            from game import inventory as INV
            INV.remove(m, iid, 1)
        return e, m
    return None, None


def count(world, state, members, kind: str) -> int:
    n = 0
    for where, m in _bags(world, state, members):
        for iid, k in _items_in(world, state, where, m).items():
            e = world.entities.get(iid.split("@")[0]) or world.entities.get(iid)
            if kind_of(e) == kind:
                n += int(k)
    return n


def waterskins(world, state, members) -> int:
    n = 0
    for where, m in _bags(world, state, members):
        for iid, k in _items_in(world, state, where, m).items():
            e = world.entities.get(iid.split("@")[0]) or world.entities.get(iid)
            if e is not None and e.name.lower().startswith("waterskin"):
                n += int(k)
    return n


def capacity(world, state, members) -> int:
    return WATERSKIN_DRINKS * waterskins(world, state, members)


def refill(world, state, members, clean: bool = True, bus=None) -> str:
    """Fill the waterskins (at a well: clean; a river, a lake or a pool: maybe not)."""
    cap = capacity(world, state, members)
    if cap <= 0:
        return "You've nothing to carry water in: buy a waterskin."
    p = party_data(state)
    p["water"] = cap
    p["clean"] = bool(clean)
    text = f"You fill your waterskin{'s' if cap > WATERSKIN_DRINKS else ''}: {cap} drinks of water."
    if not clean:
        text += " It doesn't look entirely clean."
    if bus is not None:
        bus.emit("log", kind="narration", text=text)
    state.save()
    return text


def in_town(world, state) -> bool:
    from game import places
    spot = places.current(world, state)
    return spot.kind in ("street", "building") and spot.town is not None


def sheltered(world, state) -> bool:
    """Out of the weather: in a building, a town, a dungeon."""
    from game import places
    spot = places.current(world, state)
    return spot.kind in ("street", "building", "dungeon")


# ======================================================================
# The catch-up step
# ======================================================================
def _catch_up(world, state, since: int, now: int) -> None:
    if not on(world) and not diseases_on(world):
        return
    d = data(state)
    if now < int(d.get("_next", 0)) and not d.get("_dirty"):
        return
    d.pop("_dirty", None)
    run(world, state, since, now)


def run(world, state, since: int, now: int, members: list | None = None) -> None:
    """Everything the party's needs (and ailments) did between two minutes."""
    from game import party as P
    if members is None:
        members = P.load(world, defaults=False)
    alive = [m for m in members if not m.get("dead")]
    bus = getattr(state, "bus", None)
    changed = False
    nexts = [now + DAY]
    if on(world):
        if rule(world, "food_spoils"):
            changed |= _spoil(world, state, members, since, now, bus)
        changed |= _feed(world, state, alive, members, since, now)
        for m in alive:
            changed |= _needs(world, state, m, members, since, now, bus, nexts)
        _animals(world, state, members, since, now, bus)
        if rule(world, "cold_heat") and not sheltered(world, state):
            for m in alive:
                _weather(world, state, m, members, since, now, bus)
            nexts.append((now // HOUR + 1) * HOUR)
    if diseases_on(world):
        for m in alive:
            changed |= _ailments(world, state, m, since, now, bus, nexts)
        _exposure(world, state, alive, since, now, bus)
    for m in alive:
        if _exhaustion(state, m) >= EXHAUSTION_DEATH and not m.get("dead"):
            m["dead"] = True
            m["died_at"] = now
            changed = True
            if bus is not None:
                bus.emit("log", kind="damage", text=f"{m.get('name')} dies of exhaustion.")
                bus.emit("party.died", member=m.get("id"))
    data(state)["_next"] = max(now + 1, min(nexts))
    if changed:
        P.save(world, members)
        if bus is not None:
            bus.emit("survival.changed")
    state.save()


def _say(state, text: str, kind: str = "system") -> None:
    bus = getattr(state, "bus", None)
    if bus is not None:
        bus.emit("log", kind=kind, text=text)


def _exhaustion(state, m: dict) -> int:
    from game import condition
    return int((condition.record(state, m).get("conditions") or {}).get("Exhaustion", 0))


def add_exhaustion(state, m: dict, n: int, why: str = "") -> int:
    from game import condition
    if n <= 0:
        return _exhaustion(state, m)
    r = condition.record(state, m)
    conds = dict(r.get("conditions") or {})
    conds["Exhaustion"] = min(EXHAUSTION_DEATH, int(conds.get("Exhaustion", 0)) + int(n))
    r["conditions"] = conds
    if why:
        _say(state, f"{m.get('name')} {why}: exhaustion {conds['Exhaustion']}.", "damage")
    return conds["Exhaustion"]


def _feed(world, state, alive, members, since, now) -> bool:
    """Meals and drinks as the times come round, in time order, so everyone shares what there is."""
    changed = False
    meal = meal_minutes(world)
    town = in_town(world, state)
    p = party_data(state)
    recs = {m["id"]: rec(state, m["id"], since) for m in alive}

    def drink_of(m) -> float:
        r = recs[m["id"]]
        flux = any(a.get("name") == "Bloody Flux" and a.get("started") for a in r["afflictions"])
        return drink_minutes(world) / (2 if flux else 1)        # the flux: twice the water
    out_food = out_drink = False
    for _guard in range(100000):
        hungry = [] if out_food else [m for m in alive if recs[m["id"]]["food_until"] <= now]
        thirsty = [] if out_drink else [m for m in alive if recs[m["id"]]["water_until"] <= now]
        if not hungry and not thirsty:
            break
        fm = min(hungry, key=lambda m: recs[m["id"]]["food_until"]) if hungry else None
        dm = min(thirsty, key=lambda m: recs[m["id"]]["water_until"]) if thirsty else None
        if fm is not None and (dm is None or recs[fm["id"]]["food_until"] <= recs[dm["id"]]["water_until"]):
            r = recs[fm["id"]]
            e, who = _take_one(world, state, members, "Meal")
            if e is None:
                out_food = True
                continue
            at = max(r["food_until"], since)
            r["food_until"] = at + meal
            r["hunger_levels"] = 0
            changed = changed or who is not None
            if e.fields.get("category") == "Consumable" or e.fields.get("meal_bonus"):
                from game import condition
                cr = condition.record(state, fm)
                cr["temp_hp"] = max(int(cr.get("temp_hp") or 0), _meal_hp(e, fm))
            if rule(world, "food_spoils") and not preserved(e) and diseases_on(world) and \
                    _rng("spoiled", fm["id"], at).random() < 0.03:
                infect(world, state, fm, "Bloody Flux", _rng("flux", fm["id"], at), "something that had gone off")
            continue
        r = recs[dm["id"]]
        at = max(r["water_until"], since)
        if town:                                              # the wells: as much as anyone wants
            r["water_until"] = max(now, at) + drink_of(dm)
            r["thirst_levels"] = 0
            continue
        if p["water"] > 0:
            p["water"] -= 1
            if not p.get("clean", True) and diseases_on(world) and _rng("water", dm["id"], at).random() < 0.04:
                infect(world, state, dm, _rng("which", at).choice(["Bloody Flux", "Sight Rot"]),
                       _rng("dirty", dm["id"], at), "bad water")
        else:
            e, who = _take_one(world, state, members, "Drink")
            if e is None:
                out_drink = True
                continue
            changed = changed or who is not None
        r["water_until"] = at + drink_of(dm)
        r["thirst_levels"] = 0
    return changed


def _needs(world, state, m, members, since, now, bus, nexts) -> bool:
    """The exhaustion of going without food, water or sleep (after _feed has fed whoever it could)."""
    r = rec(state, m["id"], since)
    hunger = hunger_minutes(world)
    for key, lv_key, why in (("food_until", "hunger_levels", "goes hungry"),
                             ("water_until", "thirst_levels", "goes thirsty")):
        if r[key] < now:
            due = int((now - r[key]) // hunger)
            if due > r[lv_key]:
                add_exhaustion(state, m, due - r[lv_key], why)
                r[lv_key] = due
            nexts.append(int(r[key] + (r[lv_key] + 1) * hunger))
        else:
            nexts.append(int(r[key]))
    # sleep
    if int(state.last_long_rest) > int(r.get("rest_seen", -10 ** 9)):
        r["rest_seen"] = int(state.last_long_rest)
        r["sleep_from"] = max(int(r.get("sleep_from", since)), int(state.last_long_rest))
        r["sleep_levels"] = 0
    sleep = sleep_minutes(world)
    due = int((now - int(r["sleep_from"])) // sleep)
    if due > r["sleep_levels"]:
        add_exhaustion(state, m, due - r["sleep_levels"], "needs sleep")
        r["sleep_levels"] = due
    nexts.append(int(r["sleep_from"] + (r["sleep_levels"] + 1) * sleep))
    return False


def _meal_hp(e, m) -> int:
    from game import dice
    expr = e.fields.get("meal_bonus") or "1d4"
    try:
        return max(1, dice.roll(str(expr), _rng("meal", m["id"], e.id)).total)
    except Exception:  # noqa: BLE001
        return 2


def _spoil(world, state, members, since, now, bus) -> bool:
    """Every SPOIL_DAYS, half the fresh food in the bags goes off."""
    p = party_data(state)
    last = int(p.get("spoiled_at") or since)
    periods = (now - last) // (SPOIL_DAYS * DAY)
    if periods <= 0:
        p.setdefault("spoiled_at", last)
        return False
    p["spoiled_at"] = last + periods * SPOIL_DAYS * DAY
    gone = 0
    changed = False
    for where, m in _bags(world, state, members):
        inv = _items_in(world, state, where, m)
        for iid in list(inv):
            e = world.entities.get(iid.split("@")[0]) or world.entities.get(iid)
            if kind_of(e) != "Meal" or preserved(e):
                continue
            n = int(inv[iid])
            keep = n
            for _ in range(int(min(periods, 8))):
                keep //= 2
            if keep < n:
                gone += n - keep
                if keep:
                    inv[iid] = keep
                else:
                    inv.pop(iid, None)
                changed = changed or where == "member"
    if gone and bus is not None:
        bus.emit("log", kind="system", text=f"Some of your food has gone off ({gone} thrown away).")
    return changed


def _animals(world, state, members, since, now, bus) -> None:
    """Mounts and pack animals: grazing in green country, fed in town, otherwise Animal Feed from the pack."""
    from game import animals
    beasts = [v for v in animals.owned(state) if v["kind"] == "animal" and animals.where(world, state, v) == "with"]
    if not beasts:
        return
    a = data(state).setdefault("_animals", {})
    days = now // DAY - since // DAY
    if days <= 0:
        return
    graze = in_town(world, state)
    if not graze:
        try:
            from game import weather as W
            graze = W.biome_here(world, state)[0] in GRAZING
        except Exception:  # noqa: BLE001
            graze = True
    for v in beasts:
        r = a.setdefault(v["id"], {"unfed": 0})
        for _ in range(min(days, 30)):
            if graze:
                r["unfed"] = 0
                continue
            e, _who = _take_one(world, state, members, "Feed")
            r["unfed"] = 0 if e is not None else int(r["unfed"]) + 1
        if int(r["unfed"]) == FEED_DAYS and bus is not None:
            bus.emit("log", kind="system", text=f"{v.get('name')} is going hungry: buy Animal Feed, or find grass.")


def hungry_animal(state, vid: str) -> bool:
    return int(((data(state).get("_animals") or {}).get(vid) or {}).get("unfed", 0)) >= FEED_DAYS


# ----------------------------------------------------------------------------------------------------
# Cold and heat (the SRD's extreme cold and extreme heat)
# ----------------------------------------------------------------------------------------------------
def temperature_here(world, state, minute: int) -> int:
    from game import calendar as CAL
    from game import weather as W
    b, x, y = W.biome_here(world, state)
    kind = W.at(world, minute, b, x, y).kind
    return CAL.temperature(world, minute, b, kind)


def warm(world, m: dict) -> bool:
    for iid in (m.get("equipment") or {}).values():
        e = world.entities.get(iid)
        if e is not None and (e.fields.get("warm") or "cold weather" in [str(t).lower() for t in e.tags]
                              or "fur" in e.name.lower()):
            return True
    return False


def heavy(world, m: dict) -> bool:
    for iid in (m.get("equipment") or {}).values():
        e = world.entities.get(iid)
        if e is not None and e.fields.get("category") == "Armor" and \
                (e.fields.get("armor_type") or "") in ("Medium", "Heavy"):
            return True
    return False


def _save_roll(world, m, stat: str, dc: int, rng, mode: str = "normal") -> bool:
    """A save rolled in the background (never a minigame)."""
    from game import condition
    try:
        c = condition.combatant(world, m)
        b = c.mod(stat) + (c.prof if stat in (c.saves or set()) else 0)
    except Exception:  # noqa: BLE001
        b = 0
    d = rng.randint(1, 20)
    if mode == "disadvantage":
        d = min(d, rng.randint(1, 20))
    elif mode == "advantage":
        d = max(d, rng.randint(1, 20))
    return d + b >= dc


def _weather(world, state, m, members, since, now, bus) -> None:
    r = rec(state, m["id"], since)
    start = max(since, int(r.get("weather_at", since)))
    hours = (now - start) // HOUR
    if hours <= 0:
        return
    r["weather_at"] = start + hours * HOUR
    for h in range(int(min(hours, 72))):
        minute = start + (h + 1) * HOUR
        t = temperature_here(world, state, minute)
        rng = _rng("weather", m["id"], minute)
        if t <= 0:
            if warm(world, m):
                continue
            if not _save_roll(world, m, "con", 10, rng):
                add_exhaustion(state, m, 1, "suffers in the bitter cold")
        elif t >= 100:
            if r["water_until"] > minute or party_data(state)["water"] > 0:
                r["heat_hours"] = 0
                continue
            r["heat_hours"] = int(r.get("heat_hours", 0)) + 1
            mode = "disadvantage" if heavy(world, m) else "normal"
            if not _save_roll(world, m, "con", 5 + r["heat_hours"] - 1, rng, mode):
                add_exhaustion(state, m, 1, "wilts in the heat")
        else:
            r["heat_hours"] = 0


# ======================================================================
# A long rest, the sheet, a journey
# ======================================================================
def resting(state, members) -> None:
    """A long rest begins: the time without sleep stops counting now."""
    for m in members:
        if m.get("dead"):
            continue
        r = rec(state, m["id"])
        r["sleep_from"] = max(int(r.get("sleep_from", state.minutes)), state.minutes)
        r["sleep_levels"] = 0


def fed(world, state, m: dict) -> bool:
    if not on(world):
        return True
    r = rec(state, m["id"])
    return r["food_until"] >= state.minutes - 60 and r["water_until"] >= state.minutes - 60


def after_long_rest(world, state, m: dict, before: int) -> int:
    """The exhaustion a member keeps after a long rest: one less, if they've eaten and drunk; and never less
    than their diseases give them."""
    keep = before - 1 if fed(world, state, m) else before
    floor = sum(int(a.get("level") or 0) for a in afflictions(state, m["id"]) if a.get("effect") in
                ("exhaustion", "fits")) if diseases_on(world) else 0
    return max(0, floor, keep)


def view(world, state, m: dict) -> dict:
    """What the sheet shows: hours of food, water and rest left (negative: overdue)."""
    if not on(world):
        return {}
    r = rec(state, m["id"])
    now = state.minutes
    return {"food": round((r["food_until"] - now) / 60, 1), "meal_hours": round(meal_minutes(world) / 60, 1),
            "water": round((r["water_until"] - now) / 60, 1), "drink_hours": round(drink_minutes(world) / 60, 1),
            "rest": round((int(r["sleep_from"]) + sleep_minutes(world) * (int(r["sleep_levels"]) + 1) - now) / 60, 1),
            "sleep_hours": rule(world, "sleep_hours")}


MEAL_PRICE_SP = 3


def hot_meal(world, state, members, bus=None) -> tuple[bool, str]:
    """An inn's hot meal for everyone: fed for a meal's time, and a few temporary hit points."""
    from game import condition
    alive = [m for m in members if not m.get("dead")]
    cost = MEAL_PRICE_SP * 10 * len(alive)
    if state.copper < cost:
        return False, "You can't afford a meal for everyone."
    state.add_copper(-cost, "a hot meal")
    now = state.minutes
    for m in alive:
        r = rec(state, m["id"])
        r["food_until"] = max(r["food_until"], now) + meal_minutes(world)
        r["water_until"] = max(r["water_until"], now) + drink_minutes(world)
        r["hunger_levels"] = r["thirst_levels"] = 0
        hp = _rng("inn", m["id"], now).randint(1, 4) + 1
        cr = condition.record(state, m)
        cr["temp_hp"] = max(int(cr.get("temp_hp") or 0), hp)
    state.save()
    text = "Stew, bread and ale all round. Everyone's fed, and in better spirits for it."
    if bus is not None:
        bus.emit("log", kind="heal", text=text)
    return True, text


def supplies(world, state, members) -> dict:
    return {"meals": count(world, state, members, "Meal"), "drinks": count(world, state, members, "Drink"),
            "water": party_data(state)["water"], "capacity": capacity(world, state, members)}


def out_of_supplies(world, state, members) -> str:
    """'' while the party can go on; a warning once someone's hungry or thirsty with nothing left."""
    if not on(world) or in_town(world, state):
        return ""
    alive = [m for m in members or [] if not m.get("dead")]
    s = supplies(world, state, members)
    now = state.minutes
    if s["meals"] <= 0 and any(rec(state, m["id"])["food_until"] <= now for m in alive):
        return "Your food has run out. You stop to think again before you starve on the road."
    if s["drinks"] <= 0 and s["water"] <= 0 and any(rec(state, m["id"])["water_until"] <= now for m in alive):
        return "Your water has run out. You stop: find water (a well, a river, a lake) before going on."
    return ""


def eat(world, state, m: dict, e) -> str:
    """A member eats or drinks something by hand (from the inventory screen)."""
    k = kind_of(e)
    if k not in ("Meal", "Drink") or not on(world):
        return ""
    r = rec(state, m["id"])
    now = state.minutes
    if k == "Meal":
        r["food_until"] = max(r["food_until"], now) + meal_minutes(world)
        r["hunger_levels"] = 0
        bonus = ""
        if e.fields.get("category") == "Consumable" or e.fields.get("meal_bonus"):
            from game import condition
            hp = _meal_hp(e, m)
            condition.record(state, m)["temp_hp"] = max(int(condition.record(state, m).get("temp_hp") or 0), hp)
            bonus = f" A good hot meal: {hp} temporary hit points."
        return f"{m.get('name')} eats the {e.name.lower()}.{bonus}"
    r["water_until"] = max(r["water_until"], now) + drink_minutes(world)
    r["thirst_levels"] = 0
    return f"{m.get('name')} drinks the {e.name.lower()}."


# ======================================================================
# Disease and curses
# ======================================================================
def info(name: str) -> dict:
    kind, stat, dc, inc, effect, need, source, remedy = AFFLICTIONS[name]
    return {"name": name, "kind": kind, "stat": stat, "dc": dc, "incubation": inc, "effect": effect,
            "successes": need, "source": source, "remedy": remedy}


def has(state, mid: str, name: str) -> bool:
    return any(a.get("name") == name for a in afflictions(state, mid))


def infect(world, state, m: dict, name: str, rng=None, source: str = "", save: bool = True,
           item: str = "") -> bool:
    """Exposure to a disease or a curse: a save to resist it (unless save=False). Returns whether it took."""
    if not diseases_on(world) or name not in AFFLICTIONS or m.get("dead"):
        return False
    rng = rng or random.Random()
    if has(state, m["id"], name) and name != "Cursed Item":
        return False
    i = info(name)
    if save and i["stat"] and _save_roll(world, m, i["stat"], i["dc"], rng):
        _say(state, f"{m.get('name')} shrugs off {('the ' + name.lower()) if i['kind'] == 'disease' else name}"
                    + (f" ({source})" if source else "") + ".", "roll")
        return False
    r = rec(state, m["id"])
    now = state.minutes
    a = {"name": name, "kind": i["kind"], "effect": i["effect"], "caught": now,
         "onset": now + int(i["incubation"] * HOUR), "next": now + int(i["incubation"] * HOUR) + DAY,
         "level": 0, "penalty": 0, "hp_loss": 0, "successes": 0, "source": source, "item": item, "dc": i["dc"]}
    if i["incubation"] <= 0:
        _onset(world, state, m, a)
    r["afflictions"].append(a)
    if i["kind"] == "curse":
        _say(state, f"{m.get('name')} is cursed: {name}" + (f" ({source})" if source else "") + ".", "damage")
    elif i["incubation"] <= 0:
        _say(state, f"{m.get('name')} has caught {name.lower()}.", "damage")
    state.save()
    return True


def _onset(world, state, m, a) -> None:
    a["onset"] = min(int(a.get("onset", state.minutes)), state.minutes)
    a["started"] = True
    if a["effect"] in ("exhaustion", "fits"):
        a["level"] = 1
        add_exhaustion(state, m, 1)
    elif a["effect"] in ("penalty", "penalty2"):
        a["penalty"] = 2 if a["effect"] == "penalty2" else 1
    elif a["effect"] == "max_hp":
        a["hp_loss"] = 3


def _ailments(world, state, m, since, now, bus, nexts) -> bool:
    """Each disease (and curse) takes its course: onset after it incubates, then a save every day."""
    r = rec(state, m["id"], since)
    for a in list(r["afflictions"]):
        if not a.get("started") and int(a["onset"]) <= now:
            _onset(world, state, m, a)
            _say(state, f"{m.get('name')} comes down with {a['name'].lower()}.", "damage")
        if not a.get("started"):
            nexts.append(int(a["onset"]))
            continue
        guard = 0
        while int(a["next"]) <= now and guard < 60 and a in r["afflictions"]:
            guard += 1
            day_at = int(a["next"])
            a["next"] = day_at + DAY
            _course(world, state, m, r, a, _rng("course", m["id"], a["name"], day_at), day_at)
        if a in r["afflictions"]:
            nexts.append(int(a["next"]))
    return False


def _course(world, state, m, r, a, rng, minute) -> None:
    eff = a["effect"]
    if a["kind"] == "curse":
        if eff == "max_hp":                                     # mummy rot: the body withers every day
            a["hp_loss"] = int(a.get("hp_loss", 0)) + rng.randint(1, 6) + rng.randint(1, 6) + rng.randint(1, 6)
            _check_wither(world, state, m, a)
        elif eff == "moon":
            from game import calendar as CAL
            if CAL.moon_name(minute) == "Full moon":
                a["changed"] = a.get("changed", 0) + 1
                add_exhaustion(state, m, 1, "spent the full-moon night running wild")
        return
    ok = _save_roll(world, m, info(a["name"])["stat"], int(a.get("dc") or 10), rng)
    if eff in ("exhaustion", "fits"):
        if ok:
            a["level"] = max(0, int(a["level"]) - 1)
            a["successes"] = int(a.get("successes", 0)) + 1
            from game import condition
            rr = condition.record(state, m)
            conds = dict(rr.get("conditions") or {})
            if int(conds.get("Exhaustion", 0)) > 0:
                conds["Exhaustion"] = int(conds["Exhaustion"]) - 1
                if conds["Exhaustion"] <= 0:
                    conds.pop("Exhaustion")
                rr["conditions"] = conds
        else:
            a["level"] = int(a["level"]) + 1
            add_exhaustion(state, m, 1, f"worsens with {a['name'].lower()}")
        need = int(info(a["name"])["successes"]) or 0
        if a["level"] <= 0 or (need and a["successes"] >= need):
            _cured(state, m, a, "shakes it off")
    elif eff == "penalty":
        if ok:
            a["successes"] = int(a.get("successes", 0)) + 1
        else:
            a["penalty"] = min(5, int(a["penalty"]) + 1)
            _say(state, f"{m.get('name')}'s sight grows worse ({a['name'].lower()}).", "damage")
    elif eff == "max_hp":
        if ok:
            a["successes"] = int(a.get("successes", 0)) + 1
            if a["successes"] >= int(info(a["name"])["successes"] or 3):
                _cured(state, m, a, "shakes it off")
        else:
            a["hp_loss"] = int(a.get("hp_loss", 0)) + rng.randint(1, 6)
            _check_wither(world, state, m, a)
    elif eff == "flux":
        if ok:
            a["successes"] = int(a.get("successes", 0)) + 1
            if a["successes"] >= int(info(a["name"])["successes"] or 2):
                _cured(state, m, a, "shakes it off")
        else:
            add_exhaustion(state, m, 1, "is wrung out by the flux")


def _check_wither(world, state, m, a) -> None:
    from game import condition
    try:
        c = condition.combatant(world, m)
        top = c.base_max_hp
    except Exception:  # noqa: BLE001
        top = 10
    if int(a["hp_loss"]) >= top:
        m["dead"] = True
        m["died_at"] = state.minutes
        _say(state, f"{m.get('name')} withers away ({a['name'].lower()}).", "damage")


def _cured(state, m, a, how: str) -> None:
    r = rec(state, m["id"])
    r["afflictions"] = [x for x in r["afflictions"] if x is not a]
    _say(state, f"{m.get('name')} {how}: {a['name'].lower()} is gone.", "heal")


def cure(world, state, m: dict, what: str = "disease", name: str = "") -> list[str]:
    """Lift diseases ("disease"), curses ("curse"), or one by name. Returns what was cured."""
    from game import condition
    r = rec(state, m["id"])
    gone = [a for a in r["afflictions"] if (name and a["name"] == name) or (not name and a["kind"] == what)]
    if not gone:
        return []
    r["afflictions"] = [a for a in r["afflictions"] if a not in gone]
    lv = sum(int(a.get("level") or 0) for a in gone if a["effect"] in ("exhaustion", "fits"))
    if lv:
        rr = condition.record(state, m)
        conds = dict(rr.get("conditions") or {})
        left = max(0, int(conds.get("Exhaustion", 0)) - lv)
        if left:
            conds["Exhaustion"] = left
        else:
            conds.pop("Exhaustion", None)
        rr["conditions"] = conds
    if any(a["name"] == "Cursed Item" for a in gone):
        m["bound"] = []
    state.save()
    return [a["name"] for a in gone]


def cure_spell(world, state, target_m: dict, spell_name: str) -> str:
    what = CURE_SPELLS.get(spell_name)
    if not what or not diseases_on(world):
        return ""
    if what == "disease":
        dis = [a for a in afflictions(state, target_m["id"]) if a["kind"] == "disease"]
        if not dis:
            return ""
        got = cure(world, state, target_m, name=dis[0]["name"])           # one disease
    else:
        got = cure(world, state, target_m, "curse")
    return f" {target_m.get('name')} is free of {', '.join(g.lower() for g in got)}." if got else ""


def use_item(world, state, m: dict, e) -> str:
    """A remedy (an item with "cures"): an ordinary disease, or the one it names."""
    what = (e.fields.get("cures") or "") if e is not None else ""
    if not what or not diseases_on(world):
        return ""
    dis = [a for a in afflictions(state, m["id"]) if a["kind"] == "disease"]
    if what in AFFLICTIONS:
        got = cure(world, state, m, name=what) if any(a["name"] == what for a in dis) else []
    else:
        ordinary = [a for a in dis if info(a["name"])["remedy"] == e.name] or \
            [a for a in dis if info(a["name"])["remedy"] == "Herbal Remedy"]
        got = cure(world, state, m, name=ordinary[0]["name"]) if ordinary else []
    return f" {m.get('name')} is free of {', '.join(g.lower() for g in got)}." if got else \
        " It does nothing for what ails them."


def priest_price(a: dict) -> int:
    return PRIEST_PRICE.get(a["name"], PRIEST_PRICE.get(a["kind"], 100))


def priest_offer(state, members) -> list[tuple[dict, dict, int]]:
    """[(member, affliction, gp)] a temple can lift."""
    out = []
    for m in members:
        if m.get("dead"):
            continue
        for a in afflictions(state, m["id"]):
            out.append((m, a, priest_price(a)))
    return out


def priest_cure(world, state, m: dict, name: str, bus=None) -> tuple[bool, str]:
    a = next((x for x in afflictions(state, m["id"]) if x["name"] == name), None)
    if a is None:
        return False, "There's nothing to lift."
    gp = priest_price(a)
    if state.copper < gp * 100:
        return False, f"The temple asks {gp} gp for that."
    state.add_copper(-gp * 100, "the temple's healing")
    cure(world, state, m, name=name)
    text = f"The priest lays hands on {m.get('name')} and prays. The {name.lower()} is lifted ({gp} gp)."
    if bus is not None:
        bus.emit("log", kind="heal", text=text)
    return True, text


# ----------------------------------------------------------------------------------------------------
# What they do to a member (applied to their fighting numbers: game/condition.py)
# ----------------------------------------------------------------------------------------------------
def apply(state, m: dict, c) -> None:
    """Penalties, lost maximum hit points and blindness from what afflicts a member (and temporary hit
    points from a good meal)."""
    from game import condition
    temp = int(condition.record(state, m).get("temp_hp") or 0)
    if temp and hasattr(c, "temp_hp"):
        c.temp_hp = max(int(c.temp_hp or 0), temp)
    aff = afflictions(state, m.get("id", ""))
    if not aff:
        return
    pen = sum(int(a.get("penalty") or 0) for a in aff if a.get("started"))
    if pen:
        for atk in getattr(c, "attacks", []) or []:
            atk.to_hit -= pen
        if any(a["effect"] == "penalty" and int(a.get("penalty") or 0) >= 5 for a in aff):
            c.conditions["Blinded"] = {"rounds": -1, "source": "", "save": None, "lasting": True}
    loss = sum(int(a.get("hp_loss") or 0) for a in aff if a.get("started"))
    if loss:
        c.max_hp = max(1, c.max_hp - loss)
        c.hp = min(c.hp, c.max_hp)
    for a in aff:
        if a.get("started") or a["kind"] == "curse":
            c.conditions[a["name"]] = {"rounds": -1, "source": "", "save": None, "lasting": True}


def bound(m: dict, item_id: str) -> bool:
    """A cursed item that won't come off."""
    return item_id in (m.get("bound") or [])


def equipped(world, state, m: dict, item_id: str) -> str:
    """Putting on a cursed item binds it (and curses its wearer). Returns what to tell them."""
    e = world.entities.get(item_id)
    if e is None or not e.fields.get("cursed") or not diseases_on(world):
        return ""
    if item_id not in (m.get("bound") or []):
        m["bound"] = list(m.get("bound") or []) + [item_id]
        infect(world, state, m, "Cursed Item", source=e.name, save=False, item=item_id)
    return f"The {e.name.lower()} tightens on {m.get('name')}: it's cursed, and it won't come off."


# ----------------------------------------------------------------------------------------------------
# Where they're caught
# ----------------------------------------------------------------------------------------------------
def after_battle(world, state, hurt: list[dict], enemies: list[str], rng=None) -> list[str]:
    """Members hurt in a fight with something that carries a disease or a curse: a save for each."""
    if not diseases_on(world) or not hurt:
        return []
    rng = rng or random.Random()
    out = []
    names = [str(n).lower() for n in enemies]
    for key, what, chance in CARRIERS:
        if not any(key in n for n in names):
            continue
        for m in hurt:
            if rng.random() < chance and infect(world, state, m, what, rng, f"from the {key}'s bite"):
                out.append(f"{m.get('name')}: {what}")
        names = [n for n in names if key not in n]
    return out


def _exposure(world, state, alive, since, now, bus) -> None:
    """A day in a swamp or a sewer: a chance of catching something."""
    days = now // DAY - since // DAY
    if days <= 0 or not alive:
        return
    from game import places
    spot = places.current(world, state)
    what = ""
    if spot.kind == "dungeon" and (spot.extra.get("dungeon").fields.get("kind") or "") == "Sewer":
        what = "Sewer Plague"
    else:
        try:
            from game import weather as W
            if W.biome_here(world, state)[0] == "Swamp" and spot.kind in ("hex", "wild", "road", "landmark"):
                what = "Marsh Ague"
        except Exception:  # noqa: BLE001
            what = ""
    if not what:
        return
    for k in range(min(days, 10)):
        rng = _rng("exposure", what, now // DAY - k)
        if rng.random() < 0.15:
            infect(world, state, rng.choice(alive), what, rng, "the bad air")


def after_loot(world, state, owner, members, rng=None) -> str:
    """Taking a sealed tomb's treasure, or a shrine's offerings, can bring a curse down on the taker."""
    if not diseases_on(world) or owner is None:
        return ""
    rng = rng or random.Random()
    kind = owner.fields.get("kind") or ""
    what = "Curse of the Sealed Tomb" if (owner.type == "dungeon" and kind in ("Crypt", "Tomb")) else \
        "Wrath of the Shrine" if (owner.type == "landmark" and kind == "Shrine") else ""
    alive = [m for m in members if not m.get("dead")]
    if not what or not alive or rng.random() > 0.5:
        return ""
    m = rng.choice(alive)
    if infect(world, state, m, what, rng, "for what was taken"):
        return f"{m.get('name')} feels something cold settle on them: {what.lower()}."
    return ""


# ======================================================================
# The world's items: meals and drinks marked; the new goods
# ======================================================================
NEW_ITEMS = [
    ("Animal Feed", {"category": "Gear", "value": 0.05, "weight": 10, "stackable": True, "nourishes": "Feed",
                     "preserved": True}, "A sack of oats and hay: a day's feed for a mount or a pack animal.",
     ["Goods", "feed", "farm"], None),
    ("Herbal Remedy", {"category": "Consumable", "value": 25, "weight": 0.5, "stackable": True,
                       "use_effect": "Custom", "use_text": "A bitter draught against ordinary sickness.",
                       "cures": "disease"},
     "A bitter herbal draught: it cures an ordinary disease (sewer plague, marsh ague, rat fever, the flux, "
     "cackle fever, grave chill).", ["Goods", "alchemical", "herb"],
     {"station": "alchemy lab", "materials": [("Yarrow", 2), ("Willow Bark", 1), ("Silverleaf", 1)], "work": 10}),
    ("Eyebright Salve", {"category": "Consumable", "value": 30, "weight": 0.2, "stackable": True,
                         "use_effect": "Custom", "use_text": "A cool salve for the eyes.", "cures": "Sight Rot"},
     "An ointment of eyebright and silverleaf: it cures sight rot.", ["Goods", "alchemical", "herb"],
     {"station": "alchemy lab", "materials": [("Silverleaf", 2), ("Moonpetal", 1)], "work": 12}),
    ("Winter Furs", {"category": "Gear", "value": 15, "weight": 6, "stackable": False, "slot": "Cloak",
                     "warm": True}, "A heavy fur cloak and hood: proof against the worst cold.",
     ["Goods", "clothing", "cold weather"], None),
]


def ensure(world) -> int:
    """Mark the world's meals and drinks (once), and make the new goods it lacks: Animal Feed, the remedies, warm
    furs, a waterskin."""
    if int((world.meta or {}).get("survival_v") or 0) >= SURVIVAL_V:
        return 0
    store = world.entities
    n = 0
    try:
        items = store.all("item")
    except (KeyError, ValueError):
        return 0
    for e in items:
        k = _guess(e)
        fields = {}
        if k and not e.fields.get("nourishes"):
            fields["nourishes"] = k
            if k == "Meal" and preserved(e):
                fields["preserved"] = True
            if k == "Meal" and e.fields.get("category") == "Consumable":
                fields["meal_bonus"] = "1d4+1"
        if e.name in CURSED_ITEMS and not e.fields.get("cursed"):
            fields["cursed"] = True
        if fields and not store.is_overlay(e.id):
            store.update(e.id, fields=fields, save=False)
            n += 1
    names = {e.name for e in items}
    for name, fields, desc, tags, recipe in NEW_ITEMS:
        if name in names:
            continue
        f = dict(fields)
        if recipe is not None:
            mats = [{"item": store.find_by_name("item", nm).id, "count": c} for nm, c in recipe["materials"]
                    if store.find_by_name("item", nm) is not None]
            if mats:
                f["recipe"] = {"station": recipe["station"], "materials": mats, "work": recipe["work"], "makes": 1}
        store.create("item", name, f, desc, tags, save=False)
        n += 1
    if "Waterskin" not in names:
        store.create("item", "Waterskin", {"category": "Gear", "value": 0.2, "weight": 5, "stackable": True},
                     "A leather skin that holds four good drinks of water.", ["Goods", "gear"], save=False)
        n += 1
    if n:
        store.save("item")
    world.meta["survival_v"] = SURVIVAL_V
    try:
        world.save_meta()
    except Exception:  # noqa: BLE001
        pass
    return n


def _register() -> None:
    from game import ticker
    ticker.register("survival", _catch_up)


_register()

__all__ = ["DEFAULTS", "LIMITS", "on", "diseases_on", "rule", "rec", "reset", "kind_of", "preserved", "run",
           "refill", "eat", "fed", "after_long_rest", "view", "supplies", "out_of_supplies", "infect", "cure",
           "cure_spell", "use_item", "priest_offer", "priest_cure", "apply", "after_battle", "after_loot",
           "afflictions", "DISEASES", "CURSES", "ensure", "equipped", "bound", "add_exhaustion"]
