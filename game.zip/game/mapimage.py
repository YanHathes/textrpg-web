"""Pictures of the walking map, seen from higher up: every tier of the map is drawn from it.

The walking map (game/worldmap.py) is made a chunk at a time from fixed rules (the biome under each
square, noise for woods, ridges and pools, the roads' bending lines, the towns laid in where they stand),
so any square of it can be worked out on its own without making its chunk. This module does exactly
that, for many squares at once, and turns each square into a colour taken from the walking map's own
tile art. Far out, one pixel stands for many squares (an average of a few of them); close in, one
square is one pixel, trees and all. Roads are the walking map's own lines, at their own widths (never
thinner than a pixel), and towns, landmarks and lone dungeons are their walking-map sites seen from above:
roofs, streets, walls, gardens.

    render(world, x0, y0, stride, w, h)        -> RGB bytes: w x h pixels from square (x0, y0), stride squares each
                                                  (the world's and continents' pictures: game/bigmap.py)
    area_picture(level, rect, roofs=...)       -> RGB bytes of part of a site, a town or a dungeon, square for square
    town_picture(world, town)                  -> (rect, RGB bytes) of a town as it lies on the walking map

numpy makes all of this fast; without it the same pictures are worked out square by square (slower,
so a little smaller).
"""
from __future__ import annotations

import math
from functools import lru_cache

try:                                     # optional: makes the map pictures many times faster
    import numpy as np
except Exception:  # noqa: BLE001
    np = None

from game import geography as G
from game.constants import BIOMES

VERSION = 2                 # 2: the walking map's new art (its colours are taken from the tiles)
FAR_SITES = 24          # squares per pixel: closer than this, towns and other sites are drawn square by square
FAR = 64                # squares per pixel: further out than this, each biome is drawn as its average look

FLOORS = ["grass", "dirt", "sand", "snow", "cave", "path", "track", "cobble", "ford", "wood", "stone", "dungeon",
          "carpet"]
F = {n: i for i, n in enumerate(FLOORS)}
PROPS = ["", "tree", "pine", "bush", "rock", "wild_grain", "herb_patch", "mushrooms", "stump", "berry_bush",
         "ore_vein", "quarry_rock", "rubble"]
P = {n: i for i, n in enumerate(PROPS)}
WATERS = ["", "sea", "water", "swamp"]
W_ = {n: i for i, n in enumerate(WATERS)}
B = {n: i for i, n in enumerate(BIOMES)}
ROAD_FLOORS = {"track": 0, "path": 1, "cobble": 2}


# ======================================================================
# Colours, from the walking map's own art
# ======================================================================
def _avg(canvas) -> tuple[tuple[int, int, int], float]:
    """Average colour of a sprite's drawn pixels, and how much of its tile it covers."""
    r = g = b = n = 0
    for px in canvas.px:
        if px is None or px[3] < 40:
            continue
        r += px[0]
        g += px[1]
        b += px[2]
        n += 1
    if not n:
        return (128, 128, 128), 0.0
    return (r // n, g // n, b // n), n / float(len(canvas.px))


@lru_cache(maxsize=1)
def palette() -> dict:
    from game.art import tiles as TL
    floors = {}
    for k in list(TL.FLOORS):
        cols = [_avg(TL.floor_tile(k, v))[0] for v in range(3)]
        floors[k] = tuple(sum(c[i] for c in cols) // len(cols) for i in range(3))
    floors.setdefault("stone", (110, 110, 106))
    waters = {k: _avg(TL.water_tile(15, 0, k))[0] for k in ("sea", "water", "swamp")}
    walls = {k: _avg(TL.wall_tile(k, 15))[0] for k in TL.WALLS}
    roofs = {k: _avg(TL.roof_tile(k, 15, 0))[0] for k in TL.ROOF_STYLES}
    props = {}
    for pid in TL.PROPS:
        try:
            col, cover = _avg(TL.prop_sprite(pid, 0))
            d = TL.prop_def(pid)
            cover = min(1.0, cover / max(1, d.w * d.h) * (d.w * d.h))
        except Exception:  # noqa: BLE001
            col, cover = (128, 128, 128), 0.3
        props[pid] = (col, max(0.25, min(0.9, cover * 1.4)))
    earth = _avg(TL.earth_tile(0))[0]
    return {"floors": floors, "waters": waters, "walls": walls, "roofs": roofs, "props": props, "earth": earth,
            "door": (150, 110, 60), "window": (150, 190, 210), "void": (12, 12, 16)}


def _mix(a, b, t: float) -> tuple[int, int, int]:
    return (int(a[0] + (b[0] - a[0]) * t), int(a[1] + (b[1] - a[1]) * t), int(a[2] + (b[2] - a[2]) * t))


@lru_cache(maxsize=1)
def _tables():
    """Colour tables by id: floors, props (with how much of the square each covers), waters, walls."""
    pal = palette()
    floor = [pal["floors"].get(n, (110, 110, 106)) for n in FLOORS]
    prop_col = [(0, 0, 0)] + [pal["props"].get(n, ((128, 128, 128), 0.4))[0] for n in PROPS[1:]]
    prop_cov = [0.0] + [pal["props"].get(n, ((128, 128, 128), 0.4))[1] for n in PROPS[1:]]
    water = [(0, 0, 0)] + [pal["waters"][n] for n in WATERS[1:]]
    return floor, prop_col, prop_cov, water, pal["walls"].get("rock_wall", (122, 112, 100))


# ======================================================================
# The ground: one square at a time (the same rules as worldmap's chunks)
# ======================================================================
def _ground_ids(b: str, na: float, nb: float, nc: float, r: float, shore: bool) -> tuple[int, bool, int]:
    from game import worldmap as WM
    floor, wall, prop = WM._ground(b, na, nb, nc, r, shore)
    return F.get(floor, 0), bool(wall), P.get(prop or "", 0)


class _Scalar:
    """Square-by-square sampling (no numpy)."""

    def __init__(self, world) -> None:
        from game import worldmap as WM
        s = G.settings(world)
        self.seed = int(s["seed"])
        self.grid = G.terrain(world)
        self.WM = WM

    def biome(self, x: int, y: int) -> str:
        WM, seed = self.WM, self.seed
        j = int(WM._hash(x, y, seed + 9) * 5) - 2
        X, Y = ((x + j) // 4) * 4 + 2, ((y - j) // 4) * 4 + 2
        mx, my = X / WM.SQ, Y / WM.SQ
        jx = (G.noise(mx, my, 3.0, seed + 101) - 0.5) * 5.0
        jy = (G.noise(mx, my, 3.0, seed + 102) - 0.5) * 5.0
        return self.grid.biome_at(mx + jx, my + jy)

    def field(self, x: int, y: int, c: int, seed: int) -> float:
        h = self.WM._hash
        i, j = x // c, y // c
        fx, fy = (x % c) / c, (y % c) / c
        fx, fy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
        a, b, cc, d = h(i, j, seed), h(i + 1, j, seed), h(i, j + 1, seed), h(i + 1, j + 1, seed)
        return a + (b - a) * fx + (cc - a) * fy + (a - b - cc + d) * fx * fy

    def water(self, x: int, y: int, b: str | None = None) -> str:
        b = b or self.biome(x, y)
        if b == "Ocean":
            return "sea"
        if b == "Lake":
            return "water"
        if b == "Swamp" and self.field(x, y, 19, self.seed + 2) > 0.64 and self.field(x, y, 7, self.seed + 1) > 0.35:
            return "swamp"
        return ""

    def look(self, x: int, y: int, shores: bool = True, b: str | None = None) -> tuple[int, bool, int, int]:
        """(floor id, wall, prop id, water id) of one square of open country (roads and sites aside)."""
        b = b or self.biome(x, y)
        w = self.water(x, y, b)
        if w:
            return (F["sand"] if w == "sea" else F["dirt"]), False, 0, W_[w]
        shore = False
        if shores and b != "Swamp":
            for d in (1, 2):
                for nx, ny in ((x + d, y), (x - d, y), (x, y + d), (x, y - d)):
                    if self.water(nx, ny) in ("sea", "water"):
                        shore = True
                        break
                if shore:
                    break
        seed = self.seed
        na, nb, nc = self.field(x, y, 7, seed + 1), self.field(x, y, 19, seed + 2), self.field(x, y, 53, seed + 3)
        r = self.WM._hash(x, y, seed + 4)
        f, wall, p = _ground_ids(b, na, nb, nc, r, shore)
        return f, wall, p, 0


# ======================================================================
# The ground: many squares at once (numpy)
# ======================================================================
def _vh(x, y, seed: int):
    """worldmap._hash / geography._hash before the division: an int array in 0..65535."""
    u = np.uint32
    n = x.astype(u) * u(374761393) + y.astype(u) * u(668265263) + u((seed * 2147483647) & 0xFFFFFFFF)
    n = (n ^ (n >> u(13))) * u(1274126177)            # uint32 wraps round: the same as "& 0xFFFFFFFF"
    return ((n ^ (n >> u(16))) & u(0xFFFF)).astype(np.int64)


def _vnoise(x, y, scale: float, seed: int):
    """geography.noise for arrays."""
    total = np.zeros(x.shape)
    norm, amp = 0.0, 1.0
    for octave in range(2):
        s = scale / (2 ** octave)
        gx, gy = x / s, y / s
        ix, iy = np.floor(gx).astype(np.int64), np.floor(gy).astype(np.int64)
        fx, fy = gx - ix, gy - iy
        fx, fy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
        sd = seed + octave
        a, b = _vh(ix, iy, sd) / 65535.0, _vh(ix + 1, iy, sd) / 65535.0
        c, d = _vh(ix, iy + 1, sd) / 65535.0, _vh(ix + 1, iy + 1, sd) / 65535.0
        total = total + amp * (a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy)
        norm += amp
        amp *= 0.5
    return total / norm


def _vfield(x, y, c: int, seed: int):
    i, j = x // c, y // c
    fx, fy = (x % c) / c, (y % c) / c
    fx, fy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
    a, b = _vh(i, j, seed) / 65536.0, _vh(i + 1, j, seed) / 65536.0
    cc, d = _vh(i, j + 1, seed) / 65536.0, _vh(i + 1, j + 1, seed) / 65536.0
    return a + (b - a) * fx + (cc - a) * fy + (a - b - cc + d) * fx * fy


class _Vector:
    """numpy sampling: the same answers as _Scalar (and as the chunks), for arrays of squares."""

    def __init__(self, world) -> None:
        from game import worldmap as WM
        s = G.settings(world)
        self.seed = int(s["seed"])
        g = G.terrain(world)
        self.grid = g
        self.bio = np.frombuffer(bytes(g.biome), dtype=np.uint8)
        self.SQ = WM.SQ

    def biome(self, x, y):
        seed, SQ = self.seed, self.SQ
        j = ((_vh(x, y, seed + 9) / 65536.0) * 5).astype(np.int64) - 2
        X, Y = ((x + j) // 4) * 4 + 2, ((y - j) // 4) * 4 + 2
        mx, my = X / SQ, Y / SQ
        jx = (_vnoise(mx, my, 3.0, seed + 101) - 0.5) * 5.0
        jy = (_vnoise(mx, my, 3.0, seed + 102) - 0.5) * 5.0
        g = self.grid
        c = np.floor((mx + jx) / g.cell).astype(np.int64)
        r = np.floor((my + jy) / g.cell).astype(np.int64)
        ok = (c >= 0) & (c < g.cols) & (r >= 0) & (r < g.rows)
        idx = np.where(ok, r * g.cols + c, 0)
        return np.where(ok, self.bio[idx], B["Ocean"]).astype(np.int16)

    def water(self, x, y, b=None):
        b = self.biome(x, y) if b is None else b
        out = np.zeros(x.shape, dtype=np.int8)
        out[b == B["Ocean"]] = W_["sea"]
        out[b == B["Lake"]] = W_["water"]
        sw = b == B["Swamp"]
        if sw.any():
            seed = self.seed
            wet = sw & (_vfield(x, y, 19, seed + 2) > 0.64) & (_vfield(x, y, 7, seed + 1) > 0.35)
            out[wet] = W_["swamp"]
        return out

    def look(self, x, y, shores: bool = True, b=None):
        """(floor ids, walls, prop ids, water ids) for arrays of squares (roads and sites aside)."""
        seed = self.seed
        b = self.biome(x, y) if b is None else b
        wat = self.water(x, y, b)
        shore = np.zeros(x.shape, dtype=bool)
        if shores:
            cand = (wat == 0) & (b != B["Swamp"])
            if cand.any():
                xs, ys = x[cand], y[cand]
                hit = np.zeros(xs.shape, dtype=bool)
                for d in (1, 2):
                    for dx, dy in ((d, 0), (-d, 0), (0, d), (0, -d)):
                        w = self.water(xs + dx, ys + dy)
                        hit |= (w == W_["sea"]) | (w == W_["water"])
                shore[cand] = hit
        na, nb, nc = _vfield(x, y, 7, seed + 1), _vfield(x, y, 19, seed + 2), _vfield(x, y, 53, seed + 3)
        r = _vh(x, y, seed + 4) / 65536.0
        floor = np.full(x.shape, F["grass"], dtype=np.int8)
        wall = np.zeros(x.shape, dtype=bool)
        prop = np.zeros(x.shape, dtype=np.int8)
        _vground(b, na, nb, nc, r, shore, floor, wall, prop)
        dry = wat == 0
        floor = np.where(dry, floor, np.where(wat == W_["sea"], F["sand"], F["dirt"])).astype(np.int8)
        wall &= dry
        prop = np.where(dry, prop, 0).astype(np.int8)
        return floor, wall, prop, wat


def _sel(prop, m, r, steps) -> None:
    """Props by thresholds on r, first match wins: steps = [(limit or (lo, hi) mask, prop name)]."""
    left = m.copy()
    for cond, name in steps:
        hit = left & cond
        if name:
            prop[hit] = P[name]
        left &= ~hit


def _vground(b, na, nb, nc, r, shore, floor, wall, prop) -> None:
    """worldmap._ground for arrays (writes floor, wall, prop in place)."""
    # shores
    m = shore
    floor[m] = F["sand"]
    prop[m & (r < 0.01)] = P["rock"]
    rest = ~shore
    # open lands
    for name in ("Plains", "Savanna", "Coast"):
        m = rest & (b == B[name])
        if not m.any():
            continue
        fl = np.where((nb > 0.74) & (na > 0.5), F["dirt"],
                      np.where((nb < 0.35) & (name == "Coast"), F["sand"], F["grass"]))
        floor[m] = fl[m]
        thr = np.where(nc > 0.64, 0.11, 0.004 if name != "Savanna" else 0.006)
        _sel(prop, m, r, [(r < thr, "tree"), (r < 0.02, "bush"), (r < 0.024, "rock"),
                          (r < 0.028, "wild_grain" if name != "Coast" else "herb_patch"), (r < 0.030, "herb_patch")])
    for name in ("Forest", "Jungle", "Taiga"):
        m = rest & (b == B[name])
        if not m.any():
            continue
        fl = np.where((nc > 0.72) & (name == "Taiga"), F["snow"], np.where(nb > 0.82, F["dirt"], F["grass"]))
        floor[m] = fl[m]
        dense = 0.07 + 0.3 * np.maximum(0.0, nc - 0.3)
        dense = np.where(nb < 0.26, dense * 0.15, dense)
        if name == "Jungle":
            dense = dense + 0.08
        tree = "pine" if name == "Taiga" else "tree"
        trees = m & (r < dense)
        if name == "Forest":
            prop[trees & (na < 0.8)] = P["tree"]
            prop[trees & ~(na < 0.8)] = P["pine"]
        else:
            prop[trees] = P[tree]
        _sel(prop, m & ~trees, r, [(r < dense + 0.03, "bush"), (r < dense + 0.04, "mushrooms"),
                                   (r < dense + 0.043, "stump"), (r < dense + 0.049, "berry_bush"),
                                   (r < dense + 0.053, "herb_patch")])
    m = rest & (b == B["Hills"])
    if m.any():
        floor[m & (nb > 0.68)] = F["dirt"]
        ridge = m & (nc > 0.78) & (nb > 0.62) & (na > 0.45)
        wall[ridge] = True
        _sel(prop, m & ~ridge, r, [(r < 0.03, "rock"), (r < 0.05, "tree"), (r < 0.06, "bush"),
                                   (r < 0.066, "ore_vein"), (r < 0.072, "quarry_rock"), (r < 0.075, "herb_patch")])
    m = rest & (b == B["Mountains"])
    if m.any():
        fl = np.where(nc > 0.7, F["snow"], np.where(na > 0.62, F["cave"], F["dirt"]))
        floor[m] = fl[m]
        ridge = m & (nb > 0.6) & (na > 0.32)
        wall[ridge] = True
        _sel(prop, m & ~ridge, r, [(r < 0.05, "rock"), (r < 0.06, "pine"), (r < 0.071, "ore_vein"),
                                   (r < 0.078, "quarry_rock")])
    for name in ("Desert", "Badlands"):
        m = rest & (b == B[name])
        if not m.any():
            continue
        if name == "Desert":
            floor[m] = F["sand"]
            ridge = m & (nc > 0.86) & (nb > 0.74)
        else:
            fl = np.where(nb < 0.3, F["sand"], F["dirt"])
            floor[m] = fl[m]
            ridge = m & (nb > 0.7) & (na > 0.5)
        wall[ridge] = True
        mm = m & ~ridge
        if name == "Desert":
            _sel(prop, mm, r, [(r < 0.007, "rock"), (r < 0.009, "herb_patch")])
        else:
            _sel(prop, mm, r, [(r < 0.007, "rock"), (r < 0.015, "rubble"), (r < 0.021, "ore_vein")])
    for name in ("Arctic", "Tundra"):
        m = rest & (b == B[name])
        if not m.any():
            continue
        fl = np.where((nb > 0.62) & (name == "Tundra"), F["grass"], F["snow"])
        floor[m] = fl[m]
        ridge = m & (nb > 0.86) & (na > 0.5)
        wall[ridge] = True
        steps = [(r < 0.012, "rock")]
        if name == "Arctic":
            steps.append((r < 0.016, "pine"))
        steps.append((r < 0.017, "bush"))
        if name == "Tundra":
            steps.append((r < 0.02, "berry_bush"))
        steps.append((r < 0.0215, "ore_vein"))
        _sel(prop, m & ~ridge, r, steps)
    m = rest & (b == B["Swamp"])
    if m.any():
        floor[m & (na > 0.72)] = F["dirt"]
        _sel(prop, m, r, [(r < 0.06, "tree"), (r < 0.1, "mushrooms"), (r < 0.13, "bush"), (r < 0.145, "herb_patch")])


def biome_means(s) -> list:
    """The average colour of each biome's open country on the walking map (trees, clearings, ridges, pools
    and all): what a pixel standing for hundreds of squares of it looks like."""
    got = getattr(s, "_means", None)
    if got is not None:
        return got
    import random as _r
    rng = _r.Random(s.seed)
    out = []
    n = 1500
    pts = [(rng.randrange(10 ** 6), rng.randrange(10 ** 6)) for _ in range(n)]
    for bi, name in enumerate(BIOMES):
        if np is not None:
            x = np.array([p[0] for p in pts], dtype=np.int64)
            y = np.array([p[1] for p in pts], dtype=np.int64)
            rgb = _colorize_v(*s.look(x, y, shores=False, b=np.full(n, bi, dtype=np.int16)))
            out.append(tuple(float(v) for v in rgb.mean(axis=0)))
        else:
            acc = [0.0, 0.0, 0.0]
            for (x, y) in pts[:300]:
                c = _colorize_s(*s.look(x, y, shores=False, b=name))
                for i in range(3):
                    acc[i] += c[i]
            out.append(tuple(v / 300 for v in acc))
    s._means = out
    return out


def sampler(world):
    """The fast sampler when numpy is here, else the square-by-square one (kept on the world)."""
    key = (int(G.settings(world)["seed"]), id(G.terrain(world)), np is not None)
    got = getattr(world, "_map_sampler", None)
    if got is not None and got[0] == key:
        return got[1]
    s = _Vector(world) if np is not None else _Scalar(world)
    world._map_sampler = (key, s)
    return s


# ======================================================================
# Rendering
# ======================================================================
def _colorize_v(floor, wall, prop, wat):
    ft, pc, pv, wt, wall_col = _tables()
    ft, pc, pv, wt = np.array(ft, dtype=np.float32), np.array(pc, dtype=np.float32), \
        np.array(pv, dtype=np.float32), np.array(wt, dtype=np.float32)
    rgb = ft[floor]
    cov = pv[prop][..., None]
    rgb = rgb * (1 - cov) + pc[prop] * cov
    rgb = np.where(wall[..., None], np.array(wall_col, dtype=np.float32), rgb)
    rgb = np.where((wat > 0)[..., None], wt[wat], rgb)
    return rgb


def _colorize_s(f, wall, p, w) -> tuple[int, int, int]:
    ft, pc, pv, wt, wall_col = _tables()
    if w:
        return wt[w]
    if wall:
        return wall_col
    c = ft[f]
    return _mix(c, pc[p], pv[p]) if p else c


def render(world, x0: float, y0: float, stride: float, w: int, h: int, sites: bool = True, roads: bool = True,
           fog=None, continent: str | None = None) -> bytes:
    """w x h pixels of the walking map from square (x0, y0), `stride` squares to a pixel, as RGB bytes.
    fog: the party's seen-cells bits (geography.seen_cells) to hide what hasn't been seen."""
    s = sampler(world)
    far = stride >= FAR                                 # far out: each biome's average look
    sub = 2 if 3 <= stride and not far else 1           # nearer, each pixel is the average of a few squares
    exact_shore = stride < 8
    if np is not None:
        px = np.arange(w, dtype=np.float64)
        py = np.arange(h, dtype=np.float64)
        cx = np.floor(x0 + (px + 0.5) * stride).astype(np.int64)
        cy = np.floor(y0 + (py + 0.5) * stride).astype(np.int64)
        if far:
            CX, CY = np.meshgrid(cx, cy)
            b = s.biome(CX, CY)
            img = np.array(biome_means(s), dtype=np.float32)[b]
            wet = (b == B["Ocean"]) | (b == B["Lake"])
        else:
            acc = np.zeros((h, w, 3), dtype=np.float32)
            for sy in range(sub):
                for sx in range(sub):
                    xs = np.floor(x0 + (px + (sx + 0.5) / sub) * stride).astype(np.int64)
                    ys = np.floor(y0 + (py + (sy + 0.5) / sub) * stride).astype(np.int64)
                    X, Y = np.meshgrid(xs, ys)
                    fl, wl, pr, wt = s.look(X, Y, shores=exact_shore)
                    acc += _colorize_v(fl, wl, pr, wt)
            img = acc / (sub * sub)
            if sub > 1 or not exact_shore:          # the pixel's own square decides water under a road
                CX, CY = np.meshgrid(cx, cy)
                wet = s.water(CX, CY) > 0
            else:
                wet = wt > 0
        if roads:
            _roads_v(world, img, cx, cy, stride, wet, continent)
        if sites and stride <= FAR_SITES:
            _sites_v(world, img, cx, cy, continent)
        out = np.clip(img, 0, 255).astype(np.uint8)
        if fog is not None:
            out = _fog_v(world, out, cx, cy, fog)
        return out.tobytes()
    # square by square
    buf = bytearray(w * h * 3)
    means = biome_means(s) if far else None
    for j in range(h):
        y = int(math.floor(y0 + (j + 0.5) * stride))
        for i in range(w):
            x = int(math.floor(x0 + (i + 0.5) * stride))
            if far:
                c = tuple(int(v) for v in means[B[s.biome(x, y)]])
            else:
                c = _colorize_s(*s.look(x, y, shores=exact_shore))
            k = (j * w + i) * 3
            buf[k], buf[k + 1], buf[k + 2] = c
    if roads:
        _roads_s(world, buf, x0, y0, stride, w, h, s, continent)
    if sites and stride <= FAR_SITES:
        _sites_s(world, buf, x0, y0, stride, w, h, continent)
    if fog is not None:
        _fog_s(world, buf, x0, y0, stride, w, h, fog)
    return bytes(buf)


# ---- roads
def _road_lines(world, continent):
    from game import worldmap as WM
    return WM.roads_for(world, continent)


def _segments(world, continent, X0, Y0, X1, Y1, pad):
    lines, bins = _road_lines(world, continent)
    from game import worldmap as WM
    seen, out = set(), []
    bx0, bx1 = int((X0 - pad) // WM.BIN), int((X1 + pad) // WM.BIN)
    by0, by1 = int((Y0 - pad) // WM.BIN), int((Y1 + pad) // WM.BIN)
    if (bx1 - bx0 + 1) * (by1 - by0 + 1) > len(bins):            # a big stretch: go through the bins there are
        keys = [k for k in bins if bx0 <= k[0] <= bx1 and by0 <= k[1] <= by1]
    else:
        keys = [(bx, by) for bx in range(bx0, bx1 + 1) for by in range(by0, by1 + 1)]
    for key in keys:
        if True:
            for seg in bins.get(key, ()):
                if id(seg) in seen:
                    continue
                seen.add(id(seg))
                (ax, ay), (bx_, by_), width, floor = seg
                if max(ax, bx_) < X0 - pad or min(ax, bx_) > X1 + pad or max(ay, by_) < Y0 - pad or \
                        min(ay, by_) > Y1 + pad:
                    continue
                out.append(seg)
    out.sort(key=lambda sg: ROAD_FLOORS.get(sg[3], 0))          # where roads meet, the better one shows
    return out


def _roads_v(world, img, cx, cy, stride, wet, continent) -> None:
    w, h = len(cx), len(cy)
    if not w or not h:
        return
    X0, X1, Y0, Y1 = int(cx[0]), int(cx[-1]), int(cy[0]), int(cy[-1])
    pal = palette()
    segs = _segments(world, continent, X0, Y0, X1, Y1, 6 + stride)
    if stride >= 8:                    # far out a road is a line a pixel wide: all of them at once
        _road_lines_v(img, segs, cx[0] - 0.5 * stride + 0.5, cy[0] - 0.5 * stride + 0.5, stride, wet, pal)
        return
    for seg in segs:
        (ax, ay), (bx, by), width, floor = seg
        rad = max(width / 2.0, stride * 0.55)
        i0 = max(0, int(np.searchsorted(cx, min(ax, bx) - rad - 1)))
        i1 = min(w, int(np.searchsorted(cx, max(ax, bx) + rad + 1, side="right")))
        j0 = max(0, int(np.searchsorted(cy, min(ay, by) - rad - 1)))
        j1 = min(h, int(np.searchsorted(cy, max(ay, by) + rad + 1, side="right")))
        if i0 >= i1 or j0 >= j1:
            continue
        X, Y = np.meshgrid(cx[i0:i1] + 0.5 - ax, cy[j0:j1] + 0.5 - ay)
        vx, vy = bx - ax, by - ay
        ll = vx * vx + vy * vy or 1e-9
        t = np.clip((X * vx + Y * vy) / ll, 0.0, 1.0)
        dx, dy = X - vx * t, Y - vy * t
        on = dx * dx + dy * dy <= rad * rad
        if not on.any():
            continue
        dry = np.array(pal["floors"][floor], dtype=np.float32)
        bridge = np.array(pal["floors"]["ford" if floor == "track" else "wood"], dtype=np.float32)
        wsub = wet[j0:j1, i0:i1]
        col = np.where(wsub[..., None], bridge, dry)
        block = img[j0:j1, i0:i1]
        block[on] = col[on]


def _road_lines_v(img, segs, ox, oy, stride, wet, pal) -> None:
    """Roads as lines of pixels (each road's own bends), the better road on top where they meet."""
    if not segs:
        return
    h, w = img.shape[0], img.shape[1]
    a = np.array([sg[0] for sg in segs], dtype=np.float64)
    b = np.array([sg[1] for sg in segs], dtype=np.float64)
    rank = np.array([ROAD_FLOORS.get(sg[3], 0) for sg in segs], dtype=np.int64)
    widths = np.array([sg[2] for sg in segs], dtype=np.float64)
    length = np.hypot(b[:, 0] - a[:, 0], b[:, 1] - a[:, 1])
    n = np.maximum(1, np.ceil(length / (0.5 * stride)).astype(np.int64))
    seg_of = np.repeat(np.arange(len(segs)), n + 1)
    start = np.repeat(np.cumsum(n + 1) - (n + 1), n + 1)
    t = (np.arange(len(seg_of)) - start) / np.repeat(n, n + 1)
    x = a[seg_of, 0] + (b[seg_of, 0] - a[seg_of, 0]) * t
    y = a[seg_of, 1] + (b[seg_of, 1] - a[seg_of, 1]) * t
    px = np.floor((x - ox) / stride).astype(np.int64)
    py = np.floor((y - oy) / stride).astype(np.int64)
    pts = [(px, py)]
    wide = widths[seg_of] / stride >= 1.5               # a highway wider than a pixel: a little thicker
    if wide.any():
        pts += [(px[wide] + 1, py[wide]), (px[wide], py[wide] + 1)]
        seg_w = np.concatenate([seg_of, seg_of[wide], seg_of[wide]])
    else:
        seg_w = seg_of
    px = np.concatenate([p[0] for p in pts])
    py = np.concatenate([p[1] for p in pts])
    ok = (px >= 0) & (px < w) & (py >= 0) & (py < h)
    px, py, sg = px[ok], py[ok], seg_w[ok]
    order = np.argsort(rank[sg], kind="stable")          # the better road drawn last
    px, py, sg = px[order], py[order], sg[order]
    names = sorted(ROAD_FLOORS, key=ROAD_FLOORS.get)
    dry = np.array([pal["floors"][f] for f in names], dtype=np.float32)
    bridge = np.array([pal["floors"]["ford" if f == "track" else "wood"] for f in names], dtype=np.float32)
    r = rank[sg]
    col = np.where(wet[py, px][:, None], bridge[r], dry[r])
    img[py, px] = col


def _roads_s(world, buf, x0, y0, stride, w, h, s, continent) -> None:
    pal = palette()
    X1, Y1 = x0 + w * stride, y0 + h * stride
    for seg in _segments(world, continent, x0, y0, X1, Y1, 6 + stride):
        (ax, ay), (bx, by), width, floor = seg
        rad = max(width / 2.0, stride * 0.55)
        vx, vy = bx - ax, by - ay
        ll = vx * vx + vy * vy or 1e-9
        i0 = max(0, int((min(ax, bx) - rad - x0) / stride) - 1)
        i1 = min(w, int((max(ax, bx) + rad - x0) / stride) + 2)
        j0 = max(0, int((min(ay, by) - rad - y0) / stride) - 1)
        j1 = min(h, int((max(ay, by) + rad - y0) / stride) + 2)
        for j in range(j0, j1):
            yy = int(math.floor(y0 + (j + 0.5) * stride))
            cyv = yy + 0.5 - ay
            for i in range(i0, i1):
                xx = int(math.floor(x0 + (i + 0.5) * stride))
                cxv = xx + 0.5 - ax
                t = max(0.0, min(1.0, (cxv * vx + cyv * vy) / ll))
                dx, dy = cxv - vx * t, cyv - vy * t
                if dx * dx + dy * dy <= rad * rad:
                    k = (j * w + i) * 3
                    c = pal["floors"]["ford" if floor == "track" else "wood"] if s.water(xx, yy) else \
                        pal["floors"][floor]
                    buf[k], buf[k + 1], buf[k + 2] = c


# ---- sites (towns, landmarks, lone dungeons, the party's claims)
def _sites_in(world, X0, Y0, X1, Y1, continent):
    """[(rect, rgb bytes)] for the sites that touch this stretch of squares."""
    from game import worldmap as WM
    out = []
    for kind, eid, sx, sy in WM.sites_near(world, X0, Y0, X1, Y1, continent):
        pic = site_picture(world, kind, eid)
        if pic is None:
            continue
        rect, rgb = pic
        x, y, w, h = rect
        if x < X1 and X0 < x + w and y < Y1 and Y0 < y + h:
            out.append(pic)
    return out


def _sites_v(world, img, cx, cy, continent) -> None:
    if not len(cx) or not len(cy):
        return
    for (x, y, w, h), rgb in _sites_in(world, int(cx[0]), int(cy[0]), int(cx[-1]) + 1, int(cy[-1]) + 1, continent):
        i0, i1 = int(np.searchsorted(cx, x)), int(np.searchsorted(cx, x + w))
        j0, j1 = int(np.searchsorted(cy, y)), int(np.searchsorted(cy, y + h))
        if i0 >= i1 or j0 >= j1:
            continue
        pic = np.frombuffer(rgb, dtype=np.uint8).reshape(h, w, 3)
        sub = pic[np.ix_(cy[j0:j1] - y, cx[i0:i1] - x)]
        img[j0:j1, i0:i1] = sub


def _sites_s(world, buf, x0, y0, stride, w, h, continent) -> None:
    for (x, y, sw, sh), rgb in _sites_in(world, x0, y0, x0 + w * stride, y0 + h * stride, continent):
        for j in range(h):
            yy = int(math.floor(y0 + (j + 0.5) * stride)) - y
            if not 0 <= yy < sh:
                continue
            for i in range(w):
                xx = int(math.floor(x0 + (i + 0.5) * stride)) - x
                if 0 <= xx < sw:
                    k, q = (j * w + i) * 3, (yy * sw + xx) * 3
                    buf[k:k + 3] = rgb[q:q + 3]


# ---- fog (the overland map's: by cells of the world grid)
FOG_LAND, FOG_SEA, FOG_COAST = (58, 58, 48), (14, 22, 32), (122, 116, 96)


def _fog_v(world, out, cx, cy, fog):
    g = G.terrain(world)
    from game import worldmap as WM
    c = np.clip((cx / WM.SQ / g.cell).astype(np.int64), 0, g.cols - 1)
    r = np.clip((cy / WM.SQ / g.cell).astype(np.int64), 0, g.rows - 1)
    C, R = np.meshgrid(c, r)
    i = R * g.cols + C
    bits = np.frombuffer(bytes(fog), dtype=np.uint8)
    seen = (bits[i >> 3] >> (i & 7).astype(np.uint8)) & 1
    hide = seen == 0
    if not hide.any():
        return out
    land = _land_cells(world)[i]
    col = np.where(land[..., None], np.array(FOG_LAND, dtype=np.uint8), np.array(FOG_SEA, dtype=np.uint8))
    out = out.copy()
    out[hide] = col[hide]
    return out


def _fog_s(world, buf, x0, y0, stride, w, h, fog) -> None:
    g = G.terrain(world)
    from game import worldmap as WM
    land = _land_cells(world)
    for j in range(h):
        r = min(g.rows - 1, max(0, int((y0 + (j + 0.5) * stride) / WM.SQ / g.cell)))
        for i in range(w):
            c = min(g.cols - 1, max(0, int((x0 + (i + 0.5) * stride) / WM.SQ / g.cell)))
            n = r * g.cols + c
            if not fog[n >> 3] & (1 << (n & 7)):
                k = (j * w + i) * 3
                buf[k:k + 3] = bytes(FOG_LAND if land[n] else FOG_SEA)


def fog_rgba(world, fog) -> bytes:
    """RGBA bytes, one pixel per cell of the world grid: what hasn't been seen (uncharted land, dark sea),
    clear where it has."""
    g = G.terrain(world)
    n = g.cols * g.rows
    land = _land_cells(world)
    if np is not None:
        idx = np.arange(n)
        bits = np.frombuffer(bytes(fog), dtype=np.uint8)
        seen = ((bits[idx >> 3] >> (idx & 7).astype(np.uint8)) & 1).astype(bool)
        out = np.zeros((n, 4), dtype=np.uint8)
        out[:, :3] = np.where(land[:, None], np.array(FOG_LAND, dtype=np.uint8), np.array(FOG_SEA, dtype=np.uint8))
        out[:, 3] = np.where(seen, 0, 255)
        return out.tobytes()
    buf = bytearray(n * 4)
    for i in range(n):
        if not fog[i >> 3] & (1 << (i & 7)):
            buf[i * 4:i * 4 + 4] = bytes(FOG_LAND if land[i] else FOG_SEA) + b"\xff"
    return bytes(buf)


def _land_cells(world):
    g = G.terrain(world)
    got = getattr(world, "_map_land", None)
    if got is not None and got[0] == id(g):
        return got[1]
    cont = g.continent or []
    if cont:
        land = [bool(c) for c in cont]
    else:
        land = [BIOMES[b] not in ("Ocean", "Lake") for b in g.biome]
    if np is not None:
        land = np.array(land, dtype=bool)
    world._map_land = (id(g), land)
    return land


# ======================================================================
# Sites and areas, square for square
# ======================================================================
def area_picture(a, lv, rect: tuple, roofs: bool = True, below=None) -> bytes:
    """RGB bytes for the squares of `rect` (x, y, w, h in the level's squares) of level `lv` of area `a`:
    roofs over buildings (the town from above) or, without, what's inside them. `below`: a level to
    show (dimmed) where this one is open (an upper floor over the ground)."""
    from game import area as A
    pal = palette()
    fl, wa, ro, pr = pal["floors"], pal["walls"], pal["roofs"], pal["props"]
    x0, y0, w, h = rect
    buf = bytearray(w * h * 3)
    cb = a.cell_building if roofs else {}
    roof_of = {bid: ro.get((r or {}).get("style") or "Wooden", ro["Wooden"]) for bid, r in a.roofs.items()} \
        if roofs else {}
    water_c = pal["waters"]
    for j in range(h):
        y = y0 + j
        for i in range(w):
            x = x0 + i
            c = (x, y)
            bid = cb.get(c) if cb else None
            if bid is not None and bid in roof_of:
                col = roof_of[bid]
                if (x + y) % 2:
                    col = _mix(col, (0, 0, 0), 0.08)
            else:
                use = lv
                f = lv.floor_at(x, y) if lv.inside(x, y) else A.VOID
                if f == A.PASS and below is not None:
                    use = below
                    f = below.floor_at(x, y) if below.inside(x, y) else A.VOID
                if f == A.ROOF:
                    col = _mix(ro.get(getattr(use, "roof", "") or "Wooden", ro["Wooden"]), (0, 0, 0), 0.35)
                elif c in use.walls:
                    col = pal["window"] if c in use.windows else wa.get(use.walls[c], wa.get("stone_wall"))
                elif c in use.doors:
                    col = pal["door"]
                elif c in use.water:
                    col = water_c.get(use.water[c], water_c["water"])
                elif f in (A.EARTH,):
                    col = pal["earth"]
                elif f in (A.VOID, A.PASS):
                    col = pal["void"]
                else:
                    col = fl.get(f, fl["grass"])
                    p = use.prop_cells.get(c)
                    if p is not None:
                        pc, cov = pr.get(p.id, ((128, 128, 128), 0.4))
                        col = _mix(col, pc, cov)
                if use is not lv:
                    col = _mix(col, (0, 0, 0), 0.55)
            k = (j * w + i) * 3
            buf[k], buf[k + 1], buf[k + 2] = col
    return bytes(buf)


_site_mem: dict = {}


def site_picture(world, kind: str, eid: str):
    """((x, y, w, h) in world squares, RGB bytes) of a site as the walking map lays it in; None if it has
    no place. Kept in memory and in the world's cache folder."""
    from game import diskcache
    from game import worldmap as WM
    e = world.entities.get(eid)
    if e is None:
        return None
    sig = WM.site_sig(world, kind, e)
    key = (getattr(world, "path", None), kind, eid)
    got = _site_mem.get(key)
    if got is not None and got[0] == sig:
        return got[1]
    fp = diskcache.fingerprint("site-picture", VERSION, sig)
    name = f"sitepic-{eid}"
    hit = diskcache.load(world, name, fp)
    if hit is None:
        site = WM.peek_site(world, kind, e)
        if site is None:
            return None
        x, y, w, h = site.rect
        hit = ((x, y, w, h), area_picture(site.area, site.base, site.rect, roofs=True))
        diskcache.store(world, name, fp, hit)
    if len(_site_mem) > 400:
        _site_mem.clear()
    _site_mem[key] = (sig, hit)
    return hit


def town_picture(world, town):
    """The town as it lies on the walking map: (rect in world squares, RGB bytes)."""
    return site_picture(world, "town", town.id)


__all__ = ["render", "fog_rgba", "area_picture", "site_picture", "town_picture", "palette", "sampler", "FAR_SITES"]
