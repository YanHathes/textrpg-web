"""Arenas: tournaments, and bets on other fighters' bouts.

Where: the arenas of the big world (some cities, and every capital: game/worldfill.py adds any a capital lacks).

Tournaments run on a schedule: one every week at each arena, on its own day (`next_day`), open to sign up all
that day while the arena's open. A tournament is a bracket of 3 to 5 fights, one after another.

No level limits: anyone can enter. The challengers are built for the party that signs up (its members' levels)
and every fight is Hard or Deadly by the encounter rules (game/quests.py XP thresholds), never Easy or Medium:
the early fights Hard, the last Deadly. Signing up shows every challenger in the bracket with their stat
blocks, and those are the ones fought: the bracket is fixed in the save the moment the party signs.

No deaths: a fighter who drops to 0 hit points is out of that fight, not dead (they're back on their feet, at
1 hit point, for the next), and the whole party is healed when the tournament's over, won or lost.

Rewards for winning it all: a purse (by the party's level, the number of fights and the size of the city), a
rare item, a title ("Champion of Highcrown"), and standing with the city.

Bets: between tournaments the arena's fighters fight each other. Watch a bout and bet on one of the two: the
odds come from how the two match up (less the house's tenth), and the bout is fought out blow by blow.

Kept in the save (state.arena): {"entries": {arena id: {"t", "fights", "won", "status", "levels"}},
"titles": [..], "record": {"tournaments", "won", "bouts", "bets_won"}}.
"""
from __future__ import annotations

import random
import zlib

WEEK = 7
FIGHTS = (3, 5)
ENTRY_GP = 10                      # times the party's level
PURSE_GP = 60                      # times the party's level, times fights
TIER_PURSE = {"Town": 0.75, "City": 1.0, "Capital": 1.5}
STANDING = 10
HOUSE_CUT = 0.10
BET_MAX_GP = {"Town": 100, "City": 500, "Capital": 2000}
NAMES = ["the Red Brothers", "Old Iron", "the Widowmaker", "the Sand Dancers", "the Butcher's Boys", "Grimtooth",
         "the Bone Choir", "the Northern Pack", "the Gilded Twins", "Mad Orla", "the Pit Kings", "Ash and Ember"]


def data(state) -> dict:
    d = state.arena
    d.setdefault("entries", {})
    d.setdefault("titles", [])
    d.setdefault("record", {})
    return d


def is_arena(building) -> bool:
    return building is not None and (building.fields.get("kind") or "") == "Arena"


def arena_of(world, npc):
    from game import places
    b = world.entities.get(places.building_of(world, npc) or "") if npc is not None else None
    return b if is_arena(b) else None


def _town(world, arena):
    return world.entities.get(arena.fields.get("town") or "")


def _offset(arena) -> int:
    return zlib.crc32(arena.id.encode("utf-8")) % WEEK


def is_tournament_day(arena, day: int) -> bool:
    return (day + _offset(arena)) % WEEK == 0


def next_day(arena, day: int) -> int:
    """The next tournament day (today if today is one)."""
    for d in range(day, day + WEEK):
        if is_tournament_day(arena, d):
            return d
    return day


def tournament_no(arena, day: int) -> int:
    return (day + _offset(arena)) // WEEK


# ----------------------------------------------------------------------------------------------------
# How hard
# ----------------------------------------------------------------------------------------------------
def adjusted_xp(world, rows) -> int:
    from game import quests as Q
    n = sum(max(1, int(r.get("count") or 1)) for r in rows)
    xp = 0
    for r in rows:
        e = world.entities.get(r.get("id") or "")
        if e is not None:
            xp += Q.enemy_xp(e) * max(1, int(r.get("count") or 1))
    return int(xp * Q.group_multiplier(n))


def difficulty_of(world, rows, levels) -> str:
    """Easy, Medium, Hard or Deadly for this party (the encounter XP thresholds)."""
    from game import quests as Q
    adj = adjusted_xp(world, rows)
    lv = [max(1, min(20, int(x))) for x in levels] or [1]
    th = [sum(Q.XP_THRESHOLDS[x][i] for x in lv) for i in range(4)]
    for i in (3, 2, 1):
        if adj >= th[i]:
            return Q.DIFFICULTIES[i]
    return "Easy"


def _choices(world, levels, difficulty: str) -> list:
    """Groups that come out at least Hard (Deadly ones for the last fight), not past twice a Deadly fight."""
    from game import quests as Q
    lv = [max(1, min(20, int(x))) for x in levels] or [1]
    hard = sum(Q.XP_THRESHOLDS[x][2] for x in lv)
    deadly = sum(Q.XP_THRESHOLDS[x][3] for x in lv)
    lo, hi = (hard, deadly) if difficulty == "Hard" else (deadly, deadly * 2)
    out = []
    for e in world.entities.all("enemy"):
        if "summon" in (e.tags or []) or "unique" in (e.tags or []) or e.fields.get("lair"):
            continue
        xp = Q.enemy_xp(e)
        if xp <= 0:
            continue
        for n in range(1, 7):
            adj = xp * n * Q.group_multiplier(n)
            if adj > hi:
                break
            if adj >= lo:
                out.append((e, n, int(adj)))
    if not out and difficulty == "Hard":
        return _choices(world, levels, "Deadly")
    if not out:                                    # the strongest things there are, as many as it takes
        top = sorted(world.entities.all("enemy"), key=lambda e: -Q.enemy_xp(e))[:5]
        for e in top:
            for n in range(1, 16):
                if Q.enemy_xp(e) * n * Q.group_multiplier(n) >= lo:
                    out.append((e, n, int(Q.enemy_xp(e) * n * Q.group_multiplier(n))))
                    break
    return out


def bracket(world, arena, levels, tno: int) -> list[dict]:
    """The fights of a tournament for this party: [{"name", "rows", "difficulty", "xp"}]."""
    rng = random.Random(zlib.crc32(f"{arena.id}|{tno}|{sorted(levels)}".encode()))
    n = rng.randint(*FIGHTS)
    fights = []
    used = set()
    for i in range(n):
        diff = "Deadly" if i == n - 1 or (i >= 2 and rng.random() < 0.4) else "Hard"
        opts = [o for o in _choices(world, levels, diff) if o[0].id not in used] or _choices(world, levels, diff)
        opts.sort(key=lambda o: (o[1], o[2]))
        pool = opts[: max(6, len(opts) // 3)]
        e, count, adj = rng.choice(pool)
        used.add(e.id)
        rows = [{"id": e.id, "count": count}]
        fights.append({"name": rng.choice(NAMES) if count > 1 else e.name, "rows": rows,
                       "difficulty": difficulty_of(world, rows, levels), "xp": adj})
    return fights


def statblock(world, enemy) -> str:
    """A challenger's stat block, to read before signing up."""
    f = enemy.fields
    st = f.get("stats") or {}
    stats = "  ".join(f"{k.upper()} {v}" for k, v in st.items())
    atts = "; ".join(f"{a.get('name')} {int(a.get('to_hit') or 0):+d} ({a.get('damage')} {a.get('damage_type') or ''})"
                     for a in f.get("attacks") or [] if a.get("name"))
    extra = []
    for key, label in (("resistances", "Resists"), ("immunities", "Immune"), ("vulnerabilities", "Vulnerable")):
        v = f.get(key)
        if v:
            extra.append(f"{label}: {', '.join(v) if isinstance(v, list) else v}")
    return (f"{enemy.name} ({f.get('size') or 'Medium'}, CR {f.get('cr', '?')})  ·  AC {f.get('ac', '?')}  ·  "
            f"HP {f.get('hp', '?')}  ·  Speed {f.get('speed', 30)} ft\n{stats}\n{atts}" +
            ("\n" + "  ·  ".join(extra) if extra else ""))


# ----------------------------------------------------------------------------------------------------
# Signing up, fighting, winning
# ----------------------------------------------------------------------------------------------------
def party_levels(members) -> list[int]:
    return [max(1, int(m.get("level") or 1)) for m in members or [] if not m.get("dead")] or [1]


def entry_fee(members) -> int:
    lv = party_levels(members)
    return ENTRY_GP * max(1, round(sum(lv) / len(lv))) * 100


def can_sign(world, state, arena) -> tuple[bool, str]:
    from game import places
    e = data(state)["entries"].get(arena.id)
    if e and e.get("status") in ("signed", "fighting"):
        return True, "You're in this tournament."
    if not is_tournament_day(arena, state.day):
        return False, f"The next tournament is on day {next_day(arena, state.day)}."
    if e and e.get("t") == tournament_no(arena, state.day):
        return False, "You've had your tournament this week."
    if not places.is_open(arena, state.minute_of_day):
        return False, "The arena's shut."
    return True, ""


def preview(world, state, arena, members) -> list[dict]:
    """The bracket you'd fight if you signed up now (the same one you then get)."""
    e = data(state)["entries"].get(arena.id)
    if e and e.get("status") in ("signed", "fighting"):
        return e["fights"]
    return bracket(world, arena, party_levels(members), tournament_no(arena, state.day))


def sign_up(world, state, arena, members, bus=None) -> tuple[bool, str]:
    ok, why = can_sign(world, state, arena)
    if not ok:
        return False, why
    e = data(state)["entries"].get(arena.id)
    if e and e.get("status") in ("signed", "fighting"):
        return True, why
    fee = entry_fee(members)
    if state.copper < fee:
        from game.state import money_text
        return False, f"The entry fee is {money_text(fee)}."
    state.add_copper(-fee, "the arena's entry fee")
    fights = preview(world, state, arena, members)
    data(state)["entries"][arena.id] = {"t": tournament_no(arena, state.day), "fights": fights, "won": 0,
                                        "status": "signed", "levels": party_levels(members)}
    state.save()
    return True, f"You're signed up: {len(fights)} fights. The first is against {fights[0]['name']}."


def entry(state, arena) -> dict | None:
    e = data(state)["entries"].get(arena.id)
    return e if e and e.get("status") in ("signed", "fighting") else None


def next_fight(state, arena) -> dict | None:
    e = entry(state, arena)
    if e is None or e["won"] >= len(e["fights"]):
        return None
    e["status"] = "fighting"
    return e["fights"][e["won"]]


def revive(world, state, members) -> None:
    """No deaths in the arena: anyone who fell gets up (at 1 hit point)."""
    from game import condition
    for m in members or []:
        if m.get("dead"):
            m["dead"] = False
            m.pop("died_at", None)
            c = condition.combatant(world, m)
            condition.apply(state, m, c)
            c.hp = max(1, 1)
            c.dead = False
            condition.store(state, m, c, save=False)


def heal(world, state, members) -> None:
    from game import condition
    for m in members or []:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        condition.store(state, m, c, save=False)
    state.save()


def bout_done(world, state, arena, members, won: bool, rng: random.Random | None = None, bus=None) -> dict:
    """A tournament fight is over. {"status": "next" | "won" | "lost", "text", "rewards"}."""
    rng = rng or random.Random()
    e = entry(state, arena)
    rec = data(state)["record"]
    revive(world, state, members)
    if e is None:
        return {"status": "lost", "text": ""}
    if not won:
        e["status"] = "lost"
        rec["tournaments"] = int(rec.get("tournaments", 0)) + 1
        heal(world, state, members)
        return {"status": "lost", "text": f"You're beaten after {e['won']} win{'s' if e['won'] != 1 else ''}. The healers "
                                          f"patch you up."}
    e["won"] += 1
    if e["won"] < len(e["fights"]):
        nxt = e["fights"][e["won"]]
        state.save()
        return {"status": "next", "text": f"The crowd roars. Next: {nxt['name']} ({nxt['difficulty']})."}
    e["status"] = "won"
    rec["tournaments"] = int(rec.get("tournaments", 0)) + 1
    rec["won"] = int(rec.get("won", 0)) + 1
    rewards = _reward(world, state, arena, members, e, rng, bus)
    heal(world, state, members)
    return {"status": "won", "rewards": rewards,
            "text": f"Champion! {rewards['text']}"}


def _reward(world, state, arena, members, e, rng, bus=None) -> dict:
    from game import factions
    from game.state import money_text
    town = _town(world, arena)
    tier = (town.fields.get("kind") if town is not None else "") or "City"
    lv = e["levels"]
    avg = max(1, round(sum(lv) / len(lv)))
    purse = int(PURSE_GP * avg * len(e["fights"]) * TIER_PURSE.get(tier, 1.0)) * 100
    state.add_copper(purse, "the arena's purse")
    rare = [i for i in world.entities.all("item") if (i.fields.get("rarity") or "") in ("Rare", "Very Rare")
            and (i.fields.get("category") or "") not in ("Book",)]
    item = None
    if rare:
        pool = [i for i in rare if (i.fields.get("rarity") == "Very Rare") == (avg >= 11)] or rare
        item = rng.choice(sorted(pool, key=lambda i: i.id))
        state.add_item(item.id, 1, source="the arena")
    title = f"Champion of {town.name if town else 'the Arena'}"
    if title not in data(state)["titles"]:
        data(state)["titles"].append(title)
    tf = factions.town_faction(world, town) if town is not None else None
    if tf is not None:
        factions.change(world, state, tf.id, STANDING, "for winning the tournament", bus)
    state.save()
    return {"purse": purse, "item": item.id if item else "", "title": title,
            "text": f"A purse of {money_text(purse)}" + (f", {item.name}" if item else "") +
                    f", and the title {title}."}


# ----------------------------------------------------------------------------------------------------
# Bets on other bouts
# ----------------------------------------------------------------------------------------------------
def _power(world, enemy) -> float:
    """A rough measure of how a fighter stands up: hit points times the damage it deals a round."""
    from game import dice
    f = enemy.fields
    hp = float(f.get("hp") or 1)
    dpr = 0.0
    for a in f.get("attacks") or []:
        try:
            dpr = max(dpr, float(dice.average(a.get("damage") or "1")) * (0.5 + 0.05 * int(a.get("to_hit") or 0)))
        except Exception:  # noqa: BLE001
            continue
    return max(1.0, hp * max(1.0, dpr))


def card(world, state, arena, rng: random.Random | None = None) -> dict:
    """The bout on now: two of the arena's fighters, with the odds on each (decimal: what a 1 gp bet returns)."""
    rng = rng or random.Random(zlib.crc32(f"{arena.id}|{state.day}|{state.minutes // 120}".encode()))
    from game.constants import cr_value
    pool = [e for e in world.entities.all("enemy") if e.fields.get("attacks") and 0.5 <= cr_value(e.fields.get("cr", "0")) <= 8
            and "summon" not in (e.tags or [])]
    if len(pool) < 2:
        pool = [e for e in world.entities.all("enemy") if e.fields.get("attacks")]
    a = rng.choice(pool)
    near = [e for e in pool if e.id != a.id and abs(cr_value(e.fields.get("cr", "0")) - cr_value(a.fields.get("cr", "0"))) <= 1]
    b = rng.choice(near or [e for e in pool if e.id != a.id])
    pa, pb = _power(world, a), _power(world, b)
    p = pa / (pa + pb)
    p = min(0.9, max(0.1, p))
    return {"a": a.id, "b": b.id, "p": p, "odds_a": round((1 - HOUSE_CUT) / p, 2), "odds_b": round((1 - HOUSE_CUT) / (1 - p), 2),
            "key": f"{arena.id}|{state.day}|{state.minutes // 120}"}


def fight_bout(world, a, b, rng: random.Random) -> tuple[str, list[str]]:
    """Fight it out, blow by blow (each side's best attack against the other's armor). Returns (winner id, lines)."""
    from game import dice
    hp = {a.id: int(a.fields.get("hp") or 1), b.id: int(b.fields.get("hp") or 1)}
    lines = []

    def best(e):
        atts = [x for x in e.fields.get("attacks") or [] if x.get("damage")]
        return max(atts, key=lambda x: dice.average(x.get("damage") or "1")) if atts else \
            {"name": "strike", "to_hit": 2, "damage": "1d4"}
    for rnd in range(1, 60):
        for me, foe in ((a, b), (b, a)):
            att = best(me)
            roll = rng.randint(1, 20)
            if roll == 20 or (roll != 1 and roll + int(att.get("to_hit") or 0) >= int(foe.fields.get("ac") or 10)):
                dmg = max(1, dice.roll(att["damage"], rng).total * (2 if roll == 20 else 1))
                hp[foe.id] -= dmg
                if rnd <= 3 or hp[foe.id] <= 0:
                    lines.append(f"{me.name} hits {foe.name} with its {att.get('name', 'attack').lower()} for {dmg}.")
                if hp[foe.id] <= 0:
                    lines.append(f"{foe.name} goes down!")
                    return me.id, lines
    win = a.id if hp[a.id] >= hp[b.id] else b.id
    lines.append("The bout goes the distance; the judges call it.")
    return win, lines


def bet(world, state, arena, side: str, gp: int, rng: random.Random | None = None, bus=None) -> dict:
    """Bet on "a" or "b" in the bout on now; it's fought out and settled. {"won", "pay", "lines", "winner"}."""
    from game.state import money_text
    rng = rng or random.Random()
    town = _town(world, arena)
    cap = BET_MAX_GP.get((town.fields.get("kind") if town is not None else "") or "City", 500)
    gp = max(1, min(int(gp), cap))
    if state.copper < gp * 100:
        return {"won": False, "pay": 0, "lines": ["You haven't the money for that bet."], "winner": ""}
    c = card(world, state, arena)
    a, b = world.entities.get(c["a"]), world.entities.get(c["b"])
    state.add_copper(-gp * 100, "a bet at the arena")
    winner, lines = fight_bout(world, a, b, rng)
    mine = c["a"] if side == "a" else c["b"]
    won = winner == mine
    pay = int(gp * 100 * (c["odds_a"] if side == "a" else c["odds_b"])) if won else 0
    if pay:
        state.add_copper(pay, "winnings at the arena")
    rec = data(state)["record"]
    rec["bouts"] = int(rec.get("bouts", 0)) + 1
    rec["bets_won"] = int(rec.get("bets_won", 0)) + (1 if won else 0)
    state.advance(20, "watching a bout")
    w = world.entities.get(winner)
    lines.append(f"{w.name} wins. " + (f"You collect {money_text(pay)}." if won else "Your money's gone."))
    if bus is not None:
        for line in lines:
            bus.emit("log", kind="loot" if won and line is lines[-1] else "narration", text=line)
    return {"won": won, "pay": pay, "lines": lines, "winner": winner}


def titles(state) -> list[str]:
    return list(data(state)["titles"])


__all__ = ["is_arena", "arena_of", "is_tournament_day", "next_day", "tournament_no", "bracket", "difficulty_of",
           "preview", "sign_up", "entry", "next_fight", "bout_done", "revive", "heal", "statblock", "card", "bet",
           "fight_bout", "can_sign", "entry_fee", "titles", "adjusted_xp"]
