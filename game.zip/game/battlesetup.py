"""Building the sides of a fight: party members from arena settings, enemies from
the world, and the sprites for all of them. (No Qt here: the app's ui/battle/setup.py and the browser version
both use it.)"""
from __future__ import annotations

import random

from game.art.doll import Gear
from game.art.library import render_look
from game.combat import builders as B
from game.combat.battlemap import generate
from game.combat.engine import ENEMY, PLAYER, Battle
from game.constants import SIZES


def character_sprite(world, race_id: str, look: dict | None, equipment: dict | None):
    race = world.entities.get(race_id)
    merged: dict = {}
    if race:
        merged.update(race.fields.get("appearance") or {})
    merged.update({k: v for k, v in (look or {}).items() if v})
    merged.setdefault("base", "human")
    gear = Gear()
    for slot, item_id in (equipment or {}).items():
        item = world.entities.get(item_id)
        if item:
            world.sprites.apply_item(gear, item, slot)
    tiles = SIZES.get((race.fields.get("size") if race else "Medium") or "Medium", 1)
    return render_look(merged, gear, tiles)


from game.party import default_member  # noqa: E402, F401  (kept here for older imports)


def member_combatant(world, m: dict, team: str = PLAYER):
    from game.condition import combatant
    return combatant(world, m, team=team)


def build_party(world, members: list[dict]):
    out = []
    for m in members:
        if m.get("dead"):
            continue
        c = member_combatant(world, m)
        out.append((c, character_sprite(world, m.get("race") or "", m.get("look"), m.get("equipment") or {})))
    return out


def build_enemies(world, rows: list[dict], rng: random.Random):
    out = []
    for row in rows:
        e = world.entities.get(row.get("id"))
        if not e:
            continue
        count = max(1, int(row.get("count") or 1))
        art = world.sprites.render_entity(e, world.entities) if e.type in ("enemy", "npc") else None
        for i in range(count):
            base_name = row.get("name") or e.name
            if e.type == "npc":
                c = B.from_npc(world, e, rng, ENEMY)
            else:
                c = B.from_enemy(world, e, rng, ENEMY, name=base_name if count == 1 else f"{base_name} {i + 1}")
            out.append((c, art))
    return out


def map_size_for(view_w: int, view_h: int, choice: str = "fit") -> tuple[int, int]:
    presets = {"small": (12, 9), "medium": (16, 11), "large": (20, 14)}
    if choice in presets:
        return presets[choice]
    # Fit the panel at 2x zoom (64 pixels per square) where possible.
    w = max(10, min(22, view_w // 64))
    h = max(8, min(15, view_h // 64))
    return w, h


def make_battle(world, party, enemies, environment: str, size: tuple[int, int], seed: int | None = None,
                on_event=None, style: str = "", time: str = "Day", bmap=None):
    """bmap: a ready battle map (cut from the walking map where the fight broke out); otherwise one is made
    up for the environment."""
    rng = random.Random(seed)
    biggest = max([c.size for c, _ in party + enemies] + [1])
    w, h = size
    w, h = max(w, 6 + biggest * 3), max(h, 4 + biggest * 2)
    if bmap is None:
        bmap = generate(environment, w, h, seed=rng.randrange(1 << 30), style=style)
    combatants = [c for c, _ in party + enemies]
    sprites = {c.id: art for c, art in party + enemies}
    battle = Battle(bmap, combatants, rng, world.rules, on_event, time=time)
    battle.summon_factory = summoner(world)
    return battle, sprites


def summoner(world):
    """What a battle calls to bring a summoned creature in: (Combatant, sprite) for a stat block."""
    def make(entity_id: str, team: str, rng):
        e = world.entities.get(entity_id)
        if e is None or e.type not in ("enemy", "npc"):
            return None
        c = B.from_npc(world, e, rng, team) if e.type == "npc" else B.from_enemy(world, e, rng, team)
        try:
            art = world.sprites.render_entity(e, world.entities)
        except Exception:      # noqa: BLE001
            art = None
        return c, art
    return make
