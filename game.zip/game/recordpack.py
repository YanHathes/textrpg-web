"""Records stored as their differences (step 18): most of an NPC is what every NPC of their trade has (the
same hours, the same kind of shop, the same empty lists...), so the world's file keeps, for each kind of
thing, what's usual for it (its archetype), and for each entity only what's unlike that.

    archetypes   one per type and kind: NPCs by occupation, buildings by kind, every other type as a whole.
                 A key is in it when at least half of that kind (and at least MIN_GROUP of them) share
                 one value for it.
    a record     {"g": its kind, "d": {key: value differing from the archetype}, "x": [archetype keys it
                 hasn't got at all]}, keys being "description", "tags", "custom", "created", "modified" and
                 "f:<field>" for each field. Exact: reading it back gives the entity as it was.

NPCs and buildings, the many, are then squeezed with zlib against a dictionary of what their records say most
(the usual descriptions, lines of dialogue and looks), kept in the file beside the archetypes: about a third
the size, and a few microseconds to read back. A record that's text is plain; one that's bytes is squeezed.

The archetypes and the dictionaries are a snapshot, kept in the file: they change only when compact() works them out again (after
a pack adds thousands of entities, or when an old world is upgraded), and compact() rewrites every record of
those types against the new ones in the same go. Editing a template never changes how a record reads back.
"""
from __future__ import annotations

import json
import zlib
from collections import Counter

GROUP_KEY = {"npc": "occupation", "building": "kind"}
MIN_GROUP = 8                 # kinds with fewer members than this share the type-wide archetype
SHARE = 0.5                   # how many of a kind must agree on a value for it to be the kind's
VARIED = 48                   # how many different values of a key are tallied at once (the rarest are let go)
IMMUTABLE = (str, int, float, bool, type(None))
_PLAIN = {str: "s", int: "i", float: "f", bool: "b", type(None): "n"}
_EMPTY = {list: list, dict: dict}
_NEVER = ("created", "modified")     # when each was made: never shared
TALLY = 12000                 # archetypes are worked out from at most this many of a type (every n-th)
CHECK_AT = 200                # after this many of a kind, a key nowhere near shared stops being tallied
SQUEEZED = ("npc", "building")   # the types kept squeezed against a dictionary (when there are ZMIN of them)
ZMIN = 200
ZSAMPLE = 3000                # how many records the dictionary is worked out from
ZSIZE = 32000                 # zlib's preset dictionaries go up to 32 KB


def _dumps(v) -> str:
    return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


class Packer:
    """Turns entities into stored records and back, against the archetypes in the file."""

    def __init__(self, db) -> None:
        self.db = db
        self.reload()

    def reload(self) -> None:
        self._arch: dict[tuple[str, str], dict] = {}
        self._fresh: dict[tuple[str, str], list] = {}
        self._zd: dict[str, bytes] = {t: bytes(d) for t, d in self.db.execute("SELECT type, data FROM dicts")}
        # a compressor per type with its dictionary already taken in: each record's is a copy (quicker)
        self._zc = {t: zlib.compressobj(6, zlib.DEFLATED, -15, 8, zlib.Z_DEFAULT_STRATEGY, zd)
                    for t, zd in self._zd.items() if zd}
        for t, kind, data in self.db.execute("SELECT type, kind, data FROM archetypes"):
            base = json.loads(data)
            self._arch[(t, kind)] = base
            self._fresh[(t, kind)] = [(k, v, None if isinstance(v, IMMUTABLE) else _dumps(v)) for k, v in base.items()]

    def _key(self, type_name: str, kind: str) -> tuple[str, str]:
        k = (type_name, kind)
        if k in self._arch:
            return k
        return (type_name, "")

    # ---- out
    def pack(self, e) -> str:
        kind = str(e.fields.get(GROUP_KEY[e.type]) or "") if e.type in GROUP_KEY else ""
        return _record(self._arch.get(self._key(e.type, kind), {}), flat(e), kind)

    # ---- squeezing
    def store(self, type_name: str, text: str):
        """What goes in the file for a record: squeezed when its type has a dictionary."""
        zc = self._zc.get(type_name)
        if zc is None:
            return text
        co = zc.copy()
        return co.compress(text.encode("utf-8")) + co.flush()

    def text(self, type_name: str, data) -> str:
        """A record from the file as its text."""
        if isinstance(data, str):
            return data
        return zlib.decompressobj(-15, self._zd[type_name]).decompress(bytes(data)).decode("utf-8")

    def fields(self, type_name: str, data, wanted: dict) -> dict:
        """Just some of a stored record's fields (those its index rows come from: `wanted` as in
        entities.INDEXED), without making the whole entity. Read only: values may be the archetype's own."""
        names = {how[0] if isinstance(how, tuple) else how for how in wanted.values()}
        rec = json.loads(self.text(type_name, data))
        if "d" not in rec:
            return {k[2:]: v for k, v in rec.items() if k.startswith("f:") and k[2:] in names}
        diff, absent = rec["d"], set(rec.get("x") or ())
        base = self._arch.get(self._key(type_name, rec.get("g", "")), {})
        out = {}
        for n in names:
            k = "f:" + n
            if k in diff:
                out[n] = diff[k]
            elif k in base and k not in absent:
                out[n] = base[k]
        return out

    # ---- in
    def unpack(self, type_name: str, entity_id: str, name: str, data: str):
        from game.entities import Entity
        full = self.full(type_name, data)
        e = Entity.__new__(Entity)
        d = e.__dict__
        d["id"] = entity_id
        d["type"] = type_name
        d["name"] = name
        d["description"] = full.pop("description", "") or ""
        d["tags"] = full.pop("tags", None) or []
        d["custom"] = full.pop("custom", None) or []
        d["created"] = full.pop("created", "") or ""
        d["modified"] = full.pop("modified", "") or ""
        d["fields"] = {k[2:]: v for k, v in full.items() if k.startswith("f:")}
        return e

    def full(self, type_name: str, data) -> dict:
        """A stored record (text or squeezed) as the flat dict of every key it has."""
        rec = json.loads(self.text(type_name, data))
        if "d" not in rec:                               # not packed yet (straight from an old world's file)
            return rec
        diff = rec["d"]
        absent = set(rec.get("x") or ())
        out = {}
        for k, v, text in self._fresh.get(self._key(type_name, rec.get("g", "")), ()):
            if k in diff or k in absent:
                continue
            out[k] = v if text is None else json.loads(text)       # a fresh copy of anything mutable
        out.update(diff)
        if "modified" not in out and "created" in out:
            out["modified"] = out["created"]             # not stored when it's the same as when it was made
        return out


def flat(e) -> dict:
    """An entity as the flat dict a record is made from."""
    full = {"description": e.description, "tags": e.tags, "custom": e.custom, "created": e.created,
            "modified": e.modified}
    for k, v in e.fields.items():
        full["f:" + k] = v
    return full


def work_out(t: str, fulls) -> dict[tuple[str, str], dict]:
    """The archetypes of a type, from its entities as flat dicts: each kind's values that at least half of it
    (and MIN_GROUP of them) share. A key whose values are plainly all different (a look, a line of dialogue)
    stops being tallied after the first few hundred."""
    group = GROUP_KEY.get(t)
    counts: dict[str, dict[str, Counter]] = {}
    seen: dict[str, Counter] = {}
    sizes: Counter = Counter()
    for full in fulls:
        kinds = [""]
        if group:
            g = str(full.get("f:" + group) or "")
            if g:
                kinds.append(g)
        for kind in kinds:
            size = sizes[kind] = sizes[kind] + 1
            c = counts.setdefault(kind, {})
            for k, v in full.items():
                if k in _NEVER:
                    continue
                cc = c.get(k)
                if cc is None:
                    if k in c:                           # given up on: too varied to share
                        continue
                    cc = c[k] = Counter()
                if v.__class__ in _PLAIN:
                    key = (_PLAIN[v.__class__], v)       # plain values tallied as they are (quicker)
                elif not v and v.__class__ in _EMPTY:
                    key = ("e", v.__class__)
                else:
                    key = ("j", _dumps(v))
                cc[key] += 1
                if size == CHECK_AT and cc.most_common(1)[0][1] < SHARE * 0.6 * size:
                    c[k] = None                          # nowhere near half agree: stop tallying it
                elif len(cc) > 4 * VARIED:               # many different values: forget the rarest
                    floor = 1
                    while len(cc) > 2 * VARIED:
                        for x in [x for x, hits in cc.items() if hits <= floor]:
                            del cc[x]
                        floor += 1
    out = {}
    for kind, size in sizes.items():
        if size < MIN_GROUP:
            continue
        base = {}
        for k, cc in counts.get(kind, {}).items():
            if not cc:
                continue
            (how, text), hits = cc.most_common(1)[0]
            if hits >= max(MIN_GROUP, SHARE * size):
                base[k] = text if how in "sifbn" else json.loads(text) if how == "j" else _EMPTY[text]()
        if base:
            out[(t, kind)] = base
    return out


def plan(store, types: list[str]) -> None:
    """A new world's archetypes and dictionaries, worked out from the entities in memory before anything's
    been written (so each record is written once, already packed)."""
    db = store._conn()
    new_arch: dict[tuple[str, str], dict] = {}
    for t in types:
        mine = [e for eid, e in sorted(store._by_type.get(t, {}).items()) if eid not in store._overlay]
        step = max(1, len(mine) // TALLY)
        new_arch.update(work_out(t, (flat(e) for e in mine[::step])))
    db.execute("BEGIN")
    try:
        _write_plan(db, types, new_arch, lambda t, packer: [
            packer.pack(e) for e in _every(sorted(store._by_type.get(t, {}).items()))])
        db.execute("COMMIT")
    except BaseException:
        db.execute("ROLLBACK")
        raise
    store.packer.reload()


def _every(items: list) -> list:
    if len(items) < ZMIN:
        return []
    step = max(1, len(items) // ZSAMPLE)
    return [e for i, (_k, e) in enumerate(items) if i % step == 0]


def _write_plan(db, types, new_arch, samples) -> None:
    """Archetypes, then the dictionaries (from samples(t, packer) packed against them). In a transaction."""
    marks = ",".join("?" * len(types))
    db.execute(f"DELETE FROM archetypes WHERE type IN ({marks})", types)
    db.execute(f"DELETE FROM dicts WHERE type IN ({marks})", types)
    db.executemany("INSERT INTO archetypes (type, kind, data) VALUES (?,?,?)",
                   [(t, kind, _dumps(base)) for (t, kind), base in new_arch.items()])
    packer = Packer(db)
    for t in types:
        if t in SQUEEZED:
            zd = _make_dict(samples(t, packer))
            if zd:
                db.execute("INSERT INTO dicts (type, data) VALUES (?, ?)", (t, zd))


def compact_rows(db, types: list[str]) -> None:
    """Work out the archetypes of these types from what's stored, and rewrite their records against them."""
    from game import progress
    packer = Packer(db)
    new_arch: dict[tuple[str, str], dict] = {}
    for n, t in enumerate(types):
        progress.report(n / max(1, len(types)), "Packing the world's records")
        n_rows = db.execute("SELECT COUNT(*) FROM entities WHERE type=?", (t,)).fetchone()[0]
        step = max(1, n_rows // TALLY)
        new_arch.update(work_out(t, (packer.full(t, data) for i, (data,) in enumerate(
            db.execute("SELECT data FROM entities WHERE type=? ORDER BY id", (t,))) if i % step == 0)))
    # rewrite each record against the new archetypes (and dictionaries)
    old = Packer(db)
    db.execute("BEGIN")
    try:
        def samples(t, packer):
            rows = db.execute("SELECT id, data FROM entities WHERE type=? ORDER BY id", (t,)).fetchall()
            return [_pack_flat(packer, t, old.full(t, data)) for data in _every(rows)]
        _write_plan(db, types, new_arch, samples)
        packer = Packer(db)
        for t in types:
            batch = []
            for eid, data in db.execute("SELECT id, data FROM entities WHERE type=?", (t,)).fetchall():
                full = old.full(t, data)
                batch.append((packer.store(t, _pack_flat(packer, t, full)), eid))
                if len(batch) >= 5000:
                    db.executemany("UPDATE entities SET data=? WHERE id=?", batch)
                    batch = []
            if batch:
                db.executemany("UPDATE entities SET data=? WHERE id=?", batch)
        db.execute("COMMIT")
    except BaseException:
        db.execute("ROLLBACK")
        raise


def _make_dict(texts: list[str]) -> bytes:
    """A zlib preset dictionary from sample records: the pieces they share most (by how much they'd save),
    the most useful last (zlib reaches the end of it soonest)."""
    c: Counter = Counter()
    for text in texts:
        rec = json.loads(text)
        if rec.get("g"):
            c['"g":' + _dumps(rec["g"])] += 1
        for k, v in (rec.get("d") or {}).items():
            c[f'"{k}":' + _dumps(v)] += 1
            if isinstance(v, list):
                for x in v:
                    c[_dumps(x)] += 1
            elif isinstance(v, dict):
                for kk, x in v.items():
                    c[f'"{kk}":' + _dumps(x)] += 1
    parts, size = [], 0
    for piece, hits in sorted(c.items(), key=lambda kv: (-kv[1] * len(kv[0]), kv[0])):
        if hits < 3:
            continue
        b = piece.encode("utf-8")
        if size + len(b) > ZSIZE:
            continue
        parts.append(b)
        size += len(b)
    return b"".join(reversed(parts))


def _pack_flat(packer: Packer, t: str, full: dict) -> str:
    kind = str(full.get("f:" + GROUP_KEY[t]) or "") if t in GROUP_KEY else ""
    return _record(packer._arch.get(packer._key(t, kind), {}), full, kind)


def _same(a, b) -> bool:
    """Equal and of the same kind, all the way down (1, 1.0 and True are all equal to Python)."""
    if a.__class__ is not b.__class__ or a != b:
        return False
    if a.__class__ in (list, dict) and a:
        return _dumps(a) == _dumps(b)
    return True


def _record(base: dict, full: dict, kind: str) -> str:
    diff = {k: v for k, v in full.items() if k not in base or not _same(base[k], v)}
    if "modified" in diff and diff.get("modified") == full.get("created") and "modified" not in base:
        del diff["modified"]                             # read back as the same as "created"
    rec: dict = {"d": diff}
    if kind:
        rec["g"] = kind
    absent = [k for k in base if k not in full]
    if absent:
        rec["x"] = absent
    return _dumps(rec)


def compact(store, types: list[str]) -> None:
    """compact_rows on a store's file, then the store's memory brought into line (nothing is reloaded: the
    entities in memory stay the very same objects)."""
    db = store._conn()
    compact_rows(db, types)
    store.packer.reload()
    for t in types:
        for eid, e in store._by_type.get(t, {}).items():
            if eid in store._sig:
                store._sig[eid] = store.packer.pack(e)


__all__ = ["Packer", "compact", "compact_rows", "GROUP_KEY"]
