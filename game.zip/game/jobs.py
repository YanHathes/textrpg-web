"""Paid work: a shift for an employer, for wages.

Ask someone whose workplace offers work ("Is there a shift going?" in conversation). They offer a shift of
4 or 8 hours and what it pays; take it and the screen goes dark with the sound of the work, the hours pass
(everything that runs on the clock catches up: hunger, crafting jobs, weather), and you come back paid.

    Job            Sound                       Paid in                          Matching skill or tool
    Smithy         hammer on anvil             coin, or an ingot                smith's tools
    Farm           scythe and birdsong         coin, and grain or produce       harvesting
    Tavern         chatter and clinking mugs   coin, and a meal                 Performance
    Docks          waves and creaking ropes    coin                             Athletics
    Market stall   crowd and coins             coin                             Persuasion
    Lumber camp    chopping                    coin, or a share of the logs     woodcutting
    Mine           picks                       coin, or a share of the ore      mining

Where the work is: a building's Jobs field (the big world's taverns, smithies, markets, farms, mills,
granaries and harbours have theirs), and in towns among forests or hills the town hall hires for the
lumber camp or the mine.

Pay: every living party member works and is paid for their own hours, at the world's daily wage (rules
wage_untrained and wage_skilled, gp for a day's work: 8 hours) by how good they are at the job's skill or
tool: untrained, proficient (the skilled wage), expertise (one and a half times), mastery (two and a half).
Each hour is a use of that tool or skill (game/tools.py), and a shift earns a little standing with the
employer's faction.
"""
from __future__ import annotations

DAY_HOURS = 8
SHIFTS = (4, 8)
STANDING_PER_SHIFT = 1
MULT = {"": 1.0, "Proficient": 1.0, "Expertise": 1.5, "Mastery": 2.5}
# kind -> sound, the skill or tool it uses (label or key), what else it pays, and how it's said
KINDS = {
    "Smithy": {"sound": "anvil", "skill": "skill.smith-s-tools", "alt": ("Iron Ingot", "Steel Ingot"),
               "extra": (), "verb": "work the bellows and the hammer", "label": "the forge"},
    "Farm": {"sound": "scythe", "skill": "work:harvesting", "alt": (), "extra": ("Wild Wheat", "Pail of Milk",
                                                                               "Wild Barley"),
             "verb": "bring in the harvest", "label": "the fields"},
    "Tavern": {"sound": "mugs", "skill": "Performance", "alt": (), "extra": ("Bowl of Stew", "Meat Pie",
                                                                            "Travel Loaf"),
               "verb": "carry plates and pour ale", "label": "the taproom"},
    "Docks": {"sound": "ropes", "skill": "Athletics", "alt": (), "extra": (), "verb": "load and unload the boats",
              "label": "the docks"},
    "Market stall": {"sound": "market", "skill": "Persuasion", "alt": (), "extra": (),
                     "verb": "cry the wares at a stall", "label": "the market"},
    "Lumber camp": {"sound": "chop", "skill": "work:woodcutting", "alt": ("Pine Log", "Oak Log"), "extra": (),
                    "verb": "fell and trim timber", "label": "the lumber camp"},
    "Mine": {"sound": "pick", "skill": "work:mining", "alt": ("Iron Ore", "Copper Ore"), "extra": (),
             "verb": "swing a pick in the mine", "label": "the mine"},
}
FOREST = ("Forest", "Taiga", "Jungle")
HILLS = ("Mountains", "Hills", "Badlands")
TOWN_HALLS = ("Town hall", "Guild hall")


def kinds_at(world, building) -> list[str]:
    """The work a building offers."""
    if building is None:
        return []
    out = [k for k in (building.fields.get("jobs") or []) if k in KINDS]
    if (building.fields.get("kind") or "") in TOWN_HALLS:
        town = world.entities.get(building.fields.get("town") or "")
        land = (town.fields.get("terrain") or "") if town is not None else ""
        if land in FOREST:
            out.append("Lumber camp")
        if land in HILLS:
            out.append("Mine")
    if (building.fields.get("kind") or "") == "Boatwright" and "Docks" not in out:
        out.append("Docks")
    return list(dict.fromkeys(out))


def employer_kinds(world, npc) -> list[str]:
    from game import places
    if npc is None:
        return []
    return kinds_at(world, world.entities.get(places.building_of(world, npc) or ""))


def _skill_key(world, kind: str) -> str:
    key = KINDS[kind]["skill"]
    if key.startswith("work:") or key.startswith("skill."):
        return key
    sk = world.entities.find_by_name("skill", key)
    return sk.id if sk is not None else ""


def _label(world, kind: str) -> str:
    from game import tools
    key = _skill_key(world, kind)
    return tools.label(world, key) if key else KINDS[kind]["skill"]


def rate(world, member: dict, kind: str) -> int:
    """Copper an hour for this member at this work."""
    from game import tools
    key = _skill_key(world, kind)
    lvl = tools.level(world, member, key)[0] if key else ""
    daily = float(world.rules.get("wage_skilled", 2) if lvl else world.rules.get("wage_untrained", 0.2))
    return max(1, int(round(daily * 100 * MULT.get(lvl, 1.0) / DAY_HOURS)))


def _item(world, names) -> object | None:
    for n in names:
        it = world.entities.find_by_name("item", n)
        if it is not None:
            return it
    return None


def offers(world, state, npc, members) -> list[dict]:
    """The shifts this employer offers: [{"kind", "hours", "pay": copper, "members": [(id, name, rate)],
    "alt": (item id, n) instead of coin, "extra": [(item id, n)], "sound", "text"}]."""
    from game import factions
    out = []
    if npc is None or factions.attitude(world, state, npc) == "Hostile":
        return out
    workers = [m for m in members or [] if not m.get("dead")]
    if not workers:
        return out
    for kind in employer_kinds(world, npc):
        info = KINDS[kind]
        for hours in SHIFTS:
            rows = [(m.get("id"), m.get("name"), rate(world, m, kind)) for m in workers]
            pay = sum(r for _i, _n, r in rows) * hours
            alt = None
            it = _item(world, info["alt"])
            if it is not None:
                each = max(1, int(round(float(it.fields.get("value") or 0) * 100)))
                alt = (it.id, max(1, int(round(pay * 1.25 / each))))
            extra = []
            e = _item(world, info["extra"])
            if e is not None:
                extra.append((e.id, max(1, len(workers) * hours // 4)))
            out.append({"kind": kind, "hours": hours, "pay": pay, "members": rows, "alt": alt, "extra": extra,
                        "sound": info["sound"], "skill": _label(world, kind), "npc": npc.id,
                        "text": f"{hours} hours at {info['label']}: {_money(pay)}" +
                                (f" (or {alt[1]} x {world.entities.get(alt[0]).name})" if alt else "") +
                                (", and " + ", ".join(f"{n} x {world.entities.get(i).name}" for i, n in extra)
                                 if extra else "")})
    return out


def _money(c: int) -> str:
    from game.state import money_text
    return money_text(c)


def work(world, state, members, offer: dict, in_goods: bool = False, bus=None) -> dict:
    """Work the shift: the hours pass, and the party is paid. Returns {"text", "pay", "items", "sound"}."""
    from game import factions, tools
    npc = world.entities.get(offer.get("npc") or "")
    hours = int(offer["hours"])
    state.advance(hours * 60, "working a shift")
    items = []
    pay = 0
    if in_goods and offer.get("alt"):
        iid, n = offer["alt"]
        state.add_item(iid, n, source="wages")
        items.append((iid, n))
    else:
        pay = int(offer["pay"])
        state.add_copper(pay, f"a shift at {KINDS[offer['kind']]['label']}")
    for iid, n in offer.get("extra") or []:
        state.add_item(iid, n, source="wages")
        items.append((iid, n))
    key = _skill_key(world, offer["kind"])
    by_id = {m.get("id"): m for m in members or []}
    for mid, _name, _r in offer.get("members") or []:
        m = by_id.get(mid)
        if m is not None and key:
            tools.record_use(world, m, key, hours, bus)
    f = factions.primary(world, npc) if npc is not None else None
    if f is not None:
        factions.change(world, state, f.id, STANDING_PER_SHIFT, "for an honest day's work", bus)
    mem = state.npc(npc.id) if npc is not None else {}
    mem["shifts"] = int(mem.get("shifts", 0)) + 1
    got = [_money(pay)] if pay else []
    got += [f"{n} x {world.entities.get(i).name}" for i, n in items if world.entities.get(i) is not None]
    text = f"You {KINDS[offer['kind']]['verb']} for {hours} hours. " + \
        (f"{npc.name} pays you: " if npc is not None else "You're paid: ") + ", ".join(got) + "."
    state.save()
    if bus is not None:
        bus.emit("log", kind="loot", text=text)
        bus.emit("job.done", kind=offer["kind"], hours=hours, pay=pay)
    return {"text": text, "pay": pay, "items": items, "sound": offer["sound"]}


__all__ = ["KINDS", "kinds_at", "employer_kinds", "rate", "offers", "work", "SHIFTS"]
