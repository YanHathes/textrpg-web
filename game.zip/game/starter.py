"""Starter content for new worlds.

"test": a small pack for trying things out (six stats, a few items, races,
classes, enemies of different sizes, a town with people in it). Everything is
tagged "test pack" so it's easy to find and delete. The full 5e SRD rebuild
is a later stage and replaces this.
"""
from __future__ import annotations

TAG = "test pack"

DESCRIPTIONS = [
    ("town", "Briarwell", "A market town of slate roofs and muddy lanes, where the west road meets the river. "
                          "Rain is never far away."),
    ("building", "Holt's Forge", "Heat rolls off the forge in waves. Racks of half-finished blades line the walls, "
                                 "and the air tastes of coal and iron."),
    ("building", "The Copper Kettle", "A low-beamed common room, loud and warm. Something with onions has been "
                                      "simmering in the big copper pot since dawn."),
]


def install_starter(world, kind: str = "test") -> None:
    """kind 'test': the small test pack. 'srd': the test pack's places and people, with the SRD 5.1
    (classes, races, spells, items, monsters) installed over its rules content."""
    if kind == "srd":
        install_starter(world, "test")
        from game import srd
        if srd.available():
            srd.install(world, "replace")
        return
    if kind != "test":
        return
    s = world.entities

    def make(type_name, name, fields=None, description="", tags=()):
        return s.create(type_name, name, fields or {}, description, [TAG, *tags], save=False)

    # ---------------------------------------------------------------- stats
    stats = {}
    for name, abbr in (("Strength", "STR"), ("Dexterity", "DEX"), ("Constitution", "CON"),
                       ("Intelligence", "INT"), ("Wisdom", "WIS"), ("Charisma", "CHA")):
        stats[abbr] = make("stat", name, {"key": abbr.lower(), "abbreviation": abbr, "group": "Abilities"})

    # ---------------------------------------------------------------- skills (proficiencies)
    make("skill", "Athletics", {"kind": "Skill", "stat": stats["STR"].id})
    make("skill", "Acrobatics", {"kind": "Skill", "stat": stats["DEX"].id})
    make("skill", "Stealth", {"kind": "Skill", "stat": stats["DEX"].id})
    make("skill", "Perception", {"kind": "Skill", "stat": stats["WIS"].id})
    make("skill", "Persuasion", {"kind": "Skill", "stat": stats["CHA"].id})
    make("skill", "Thieves' Tools", {"kind": "Tool", "stat": stats["DEX"].id, "untrained": False})

    # ---------------------------------------------------------------- spells
    fire_bolt = make("spell", "Fire Bolt", {"level": 0, "school": "Evocation", "range_ft": 120,
                                             "effect": "Spell attack (ranged)", "damage": "1d10",
                                             "damage_type": "fire", "components": ["V", "S"]},
                     "A mote of fire streaks toward a creature.")
    missile = make("spell", "Magic Missile", {"level": 1, "school": "Evocation", "range_ft": 120,
                                               "effect": "Automatic hit", "damage": "1d4+1", "damage_type": "force",
                                               "missiles": 3, "components": ["V", "S"]},
                   "Three glowing darts of force, each striking unerringly.")
    hands = make("spell", "Burning Hands", {"level": 1, "school": "Evocation", "range_ft": 15,
                                             "effect": "Saving throw", "save_stat": stats["DEX"].id,
                                             "on_save": "Half damage", "damage": "3d6", "damage_type": "fire",
                                             "area": "Cone", "area_ft": 15, "upcast": "1d6",
                                             "components": ["V", "S"]},
                 "A thin sheet of flames shoots from your outstretched fingertips.")
    make("spell", "Cure Wounds", {"level": 1, "school": "Evocation", "range_ft": 5, "effect": "Healing",
                                  "healing": "1d8", "upcast": "1d8", "components": ["V", "S"]})
    make("spell", "Healing Word", {"level": 1, "school": "Evocation", "range_ft": 60, "casting_time": "Bonus action",
                                   "effect": "Healing", "healing": "1d4", "upcast": "1d4", "components": ["V"]},
         "A word of power that mends a creature you can see.")

    # ---------------------------------------------------------------- items
    def weapon(name, sprite, dmg, dtype, kind, props=(), value=10, rng=(0, 0), versatile=""):
        return make("item", name, {"category": "Weapon", "weapon_kind": kind, "damage": dmg, "damage_type": dtype,
                                   "properties": list(props), "versatile_damage": versatile, "range_ft": rng[0],
                                   "long_range_ft": rng[1], "value": value, "slot": "Two hands" if "two-handed" in props
                                   else "Main hand", "sprite": f"weapon/{sprite}"},
                    tags=("weapon", "metal" if dtype != "bludgeoning" else "wood"))

    longsword = weapon("Longsword", "longsword", "1d8", "slashing", "Martial melee", ["versatile"], 15, versatile="1d10")
    shortsword = weapon("Shortsword", "shortsword", "1d6", "piercing", "Martial melee", ["finesse", "light"], 10)
    dagger = weapon("Dagger", "dagger", "1d4", "piercing", "Simple melee", ["finesse", "light", "thrown"], 2, (20, 60))
    scimitar = weapon("Scimitar", "scimitar", "1d6", "slashing", "Martial melee", ["finesse", "light"], 25)
    greataxe = weapon("Greataxe", "greataxe", "1d12", "slashing", "Martial melee", ["heavy", "two-handed"], 30)
    greatclub = weapon("Greatclub", "greatclub", "1d8", "bludgeoning", "Simple melee", ["two-handed"], 1)
    staff = weapon("Quarterstaff", "quarterstaff", "1d6", "bludgeoning", "Simple melee", ["versatile"], 1, versatile="1d8")
    shortbow = weapon("Shortbow", "shortbow", "1d6", "piercing", "Simple ranged", ["ammunition", "two-handed"], 25, (80, 320))
    spear = weapon("Spear", "spear", "1d6", "piercing", "Simple melee", ["thrown", "versatile"], 1, (20, 60), "1d8")

    def armor(name, sprite, ac, atype, dex_cap, value, strength=0, stealth=False):
        return make("item", name, {"category": "Armor", "armor_type": atype, "armor_class": ac, "dex_cap": dex_cap,
                                   "strength_req": strength, "stealth_disadvantage": stealth, "value": value,
                                   "slot": "Body", "sprite": f"armor/{sprite}"}, tags=("armor",))

    leather = armor("Leather Armor", "leather", 11, "Light", -1, 10)
    chain = armor("Chain Mail", "chain_mail", 16, "Heavy", 0, 75, 13, True)
    plate = armor("Plate Armor", "plate", 18, "Heavy", 0, 1500, 15, True)
    hide = armor("Hide Armor", "hide", 12, "Medium", 2, 10)
    robe = make("item", "Wizard Robe", {"category": "Clothing", "slot": "Body", "sprite": "armor/robe", "value": 5},
                tags=("clothing",))
    shield = make("item", "Shield", {"category": "Shield", "armor_class": 2, "slot": "Off hand", "value": 10,
                                     "sprite": "shield/round"}, tags=("shield", "armor"))
    potion = make("item", "Healing Potion", {"category": "Consumable", "use_effect": "Heal", "use_dice": "2d4+2",
                                             "use_action": "Action", "value": 50, "stackable": True,
                                             "sprite": "icon/potion_red"},
                  "A red liquid that glimmers when shaken.", tags=("potion",))
    ore = make("item", "Iron Ore", {"category": "Material", "value": 1, "stackable": True, "sprite": "icon/ore_iron"},
               tags=("metal",))
    pelt = make("item", "Wolf Pelt", {"category": "Material", "value": 2, "sprite": "icon/bag"}, tags=("hide",))
    make("item", "Torch", {"category": "Gear", "value": 0.01, "weight": 1, "slot": "Off hand",
                           "sprite": "weapon/torch", "light_bright_ft": 20, "light_dim_ft": 20},
         "Burns for an hour, shedding bright light in a 20-foot radius and dim light 20 feet beyond.",
         tags=("gear", "light"))
    ring = make("item", "Ember Ring", {"category": "Trinket", "rarity": "Uncommon", "value": 120, "slot": "Ring",
                                       "sprite": "icon/ring_gold",
                                       "stat_bonuses": [{"stat": stats["CON"].id, "amount": 1}]},
                tags=("jewelry",))

    # ---------------------------------------------------------------- races
    def race(name, base, size="Medium", speed=30, mods=(), playable=True, extra=None, look=None):
        app = {"base": base, **(look or {})}
        fields = {"appearance": app, "size": size, "speed": speed, "playable": playable,
                  "stat_modifiers": [{"stat": stats[a].id, "amount": n} for a, n in mods]}
        fields.update(extra or {})
        return make("race", name, fields)

    human = race("Human", "human", mods=[(a, 1) for a in stats])
    elf = race("Elf", "elf", mods=[("DEX", 2)], extra={"darkvision": 60})
    dwarf = race("Dwarf", "dwarf", speed=25, mods=[("CON", 2)], extra={"darkvision": 60})
    goblin_r = race("Goblin", "goblin", "Small", mods=[("DEX", 2)], playable=False, extra={"darkvision": 60})
    wolf_r = race("Wolf", "canine", speed=40, playable=False)
    skel_r = race("Skeleton", "skeleton", playable=False, extra={"darkvision": 60})
    ogre_r = race("Ogre", "ogre", "Large", 40, playable=False, extra={"darkvision": 60})
    dragon_r = race("Red Dragon", "dragon", "Large", 40, playable=False,
                    extra={"fly_speed": 80, "resistances": [], "darkvision": 120},
                    look={"skin": "#b8322a", "accent": "#e8b860"})

    # ---------------------------------------------------------------- classes
    fighter = make("class", "Fighter", {
        "hit_die": "d10", "primary_stat": stats["STR"].id, "saving_throws": [stats["STR"].id, stats["CON"].id],
        "armor_proficiency": ["Light", "Medium", "Heavy", "Shields"],
        "weapon_proficiency": ["Simple melee", "Martial melee", "Simple ranged", "Martial ranged"],
        "starting_equipment": [longsword.id, chain.id, shield.id], "starting_gold": "5d4",
        "extra_attacks": 5})
    wizard = make("class", "Wizard", {
        "hit_die": "d6", "primary_stat": stats["INT"].id, "saving_throws": [stats["INT"].id, stats["WIS"].id],
        "weapon_proficiency": ["Simple melee"], "starting_equipment": [staff.id, robe.id], "starting_gold": "4d4",
        "spellcasting": True, "casting_stat": stats["INT"].id, "spells": [fire_bolt.id, missile.id, hands.id],
        "slots": [{"level": 1, "slots": "2"}, {"level": 2, "slots": "3"}, {"level": 3, "slots": "4,2"},
                  {"level": 4, "slots": "4,3"}, {"level": 5, "slots": "4,3,2"}]})

    # ---------------------------------------------------------------- enemies
    def stat_block(*vals):
        return {k: v for k, v in zip(("str", "dex", "con", "int", "wis", "cha"), vals)}

    make("enemy", "Bandit", {
        "race": human.id, "appearance": {"hair": "short", "hair_color": "#2b2220"},
        "equipment": {"Body": leather.id, "Main hand": scimitar.id},
        "cr": "1/8", "hp": 11, "hp_dice": "2d8+2", "ac": 0, "speed": 30, "stats": stat_block(11, 12, 12, 10, 10, 10),
        "loot": [{"item": dagger.id, "chance": 30, "quantity": "1"}], "gold": "2d6",
        "environments": ["Urban", "Forest", "Plains"]}, "A desperate cutthroat looking for easy coin.")
    make("enemy", "Wolf", {
        "race": wolf_r.id, "cr": "1/4", "hp": 11, "hp_dice": "2d8+2", "ac": 13, "speed": 40,
        "stats": stat_block(12, 15, 12, 3, 12, 6),
        "attacks": [{"name": "Bite", "kind": "Melee", "to_hit": 4, "damage": "2d4+2", "damage_type": "piercing",
                     "reach_ft": 5}],
        "loot": [{"item": pelt.id, "chance": 60, "quantity": "1"}], "environments": ["Forest", "Plains", "Hills"]})
    make("enemy", "Dire Wolf", {
        "race": wolf_r.id, "appearance": {"skin": "#4a4440", "accent": "#8a8278", "eyes": "#f05030"},
        "size": "Large", "cr": "1", "hp": 37, "hp_dice": "5d10+10", "ac": 14, "speed": 50,
        "stats": stat_block(17, 15, 15, 3, 12, 7),
        "attacks": [{"name": "Bite", "kind": "Melee", "to_hit": 5, "damage": "2d6+3", "damage_type": "piercing",
                     "reach_ft": 5}],
        "loot": [{"item": pelt.id, "chance": 80, "quantity": "1d2"}], "environments": ["Forest", "Hills", "Arctic"]})
    make("enemy", "Goblin", {
        "race": goblin_r.id, "size": "Small", "equipment": {"Main hand": scimitar.id, "Body": leather.id,
                                                            "Off hand": shield.id},
        "cr": "1/4", "hp": 7, "hp_dice": "2d6", "ac": 0, "speed": 30, "stats": stat_block(8, 14, 10, 10, 8, 8),
        "behavior": "Cowardly", "gold": "1d6", "loot": [{"item": ore.id, "chance": 50, "quantity": "1d2"}],
        "environments": ["Forest", "Cave", "Hills"]})
    make("enemy", "Skeleton", {
        "race": skel_r.id, "equipment": {"Main hand": shortsword.id}, "cr": "1/4", "hp": 13, "hp_dice": "2d8+4",
        "ac": 13, "speed": 30, "stats": stat_block(10, 14, 15, 6, 8, 5), "vulnerabilities": ["bludgeoning"],
        "immunities": ["poison"], "condition_immunities": ["Poisoned"], "environments": ["Dungeon", "Cave"]})
    make("enemy", "Ogre", {
        "race": ogre_r.id, "size": "Large", "equipment": {"Main hand": greatclub.id, "Body": hide.id},
        "cr": "2", "hp": 59, "hp_dice": "7d10+21", "ac": 11, "speed": 40, "stats": stat_block(19, 8, 16, 5, 7, 7),
        "gold": "3d10", "environments": ["Hills", "Forest", "Cave"]})
    make("enemy", "Young Red Dragon", {
        "race": dragon_r.id, "size": "Large", "cr": "10", "hp": 178, "hp_dice": "17d10+85", "ac": 18,
        "speed": 40, "fly_speed": 80, "proficiency": 4, "stats": stat_block(23, 10, 21, 14, 11, 19),
        "saving_throws": [stats["DEX"].id, stats["CON"].id, stats["WIS"].id, stats["CHA"].id],
        "immunities": ["fire"],
        "attacks": [{"name": "Bite", "kind": "Melee", "to_hit": 10, "damage": "2d10+6", "damage_type": "piercing",
                     "reach_ft": 10},
                    {"name": "Claw", "kind": "Melee", "to_hit": 10, "damage": "2d6+6", "damage_type": "slashing",
                     "reach_ft": 5}],
        "multiattack": 3, "gold": "10d20",
        "environments": ["Mountains", "Hills", "Cave"]})

    # ---------------------------------------------------------------- town, buildings, people
    town = make("town", "Briarwell", {
        "region": "Westmarch", "terrain": "Plains", "population": 640,
        "streets": [{"name": "Anvil Street", "connects": "Market Square", "exit": "West"},
                    {"name": "Market Square", "connects": "Anvil Street, Mill Lane", "exit": "East"},
                    {"name": "Mill Lane", "connects": "Market Square", "exit": "North"}]})
    forge = make("building", "Holt's Forge", {"kind": "Smithy", "town": town.id, "street": "Anvil Street",
                                              "interior": "Stone"})
    tavern = make("building", "The Copper Kettle", {"kind": "Tavern", "town": town.id, "street": "Market Square",
                                                    "interior": "Wooden", "inn_price": 5})
    mara = make("npc", "Mara Holt", {
        "race": human.id, "occupation": "Blacksmith", "level": 3, "building": forge.id,
        "greeting": "Mind the anvil. What do you need?",
        "dialogue": ["Ore won't smelt itself.", "Good steel takes patience. Bad steel takes less.",
                     "If you see the quarry foreman, tell him he owes me."],
        "appearance": {"hair": "ponytail", "hair_color": "#8c3b1f", "clothes": "#6a4a32"},
        "equipment": {"Body": leather.id, "Main hand": shortsword.id}})
    tobin = make("npc", "Tobin", {
        "race": human.id, "occupation": "Merchant", "building": forge.id,
        "dialogue": ["I'm not supposed to talk while I'm working.", "Mara says I'll make a blade worth selling by spring."],
        "appearance": {"hair": "curly", "hair_color": "#d9c27a", "skin": "#f3cfb0"}})
    bess = make("npc", "Bess Underhill", {
        "race": dwarf.id, "occupation": "Innkeeper", "building": tavern.id,
        "dialogue": ["Room's five gold. Stew's free if you don't complain about it.", "Rain's been heavy this week."],
        "appearance": {"hair": "bun", "hair_color": "#cfcac0", "beard": "none"}})
    s.update(forge.id, fields={"npcs": [mara.id, tobin.id]}, save=False)
    s.update(tavern.id, fields={"npcs": [bess.id]}, save=False)
    quest = make("quest", "Ore for the Forge", {
        "kind": "Fetch", "giver": mara.id, "level": 1,
        "objectives": [{"text": "Bring 3 Iron Ore to Mara Holt", "kind": "Fetch", "target": ore.id, "count": 3}],
        "reward_gold": 60, "reward_xp": 150})
    s.update(mara.id, fields={"quests": [quest.id]}, save=False)



    s.save()
    install_test_features(world)


# ----------------------------------------------------------------------
# Features for the test pack. Safe to run again: anything already there is
# left alone, so older worlds can be topped up when they're upgraded.
# ----------------------------------------------------------------------
def install_test_features(world) -> None:
    s = world.entities
    stat = {k: (s.stat_by_key(k).id if s.stat_by_key(k) else "") for k in ("str", "dex", "con", "int", "wis", "cha")}

    def feat(name, fields, description=""):
        found = s.find_by_name("feature", name)
        if found:
            return found
        return s.create("feature", name, fields, description, [TAG], save=False)

    def fx(effect, amount="", detail="", only_when="Always"):
        return {"effect": effect, "amount": amount, "detail": detail, "only_when": only_when}

    second_wind = feat("Second Wind", {"kind": "Class feature", "activation": "Bonus action", "uses": "Per short rest",
                                       "uses_count": "1", "effects": [fx("Heal self", "1d10 + level")]},
                       "A limited well of stamina: regain 1d10 + your fighter level hit points.")
    action_surge = feat("Action Surge", {"kind": "Class feature", "activation": "Free", "uses": "Per short rest",
                                         "uses_count": "1", "effects": [fx("Extra action")]},
                        "Push yourself beyond your normal limits for a moment: take one additional action.")
    improved_crit = feat("Improved Critical", {"kind": "Class feature", "activation": "Passive",
                                               "effects": [fx("Critical hit range", "19")]},
                         "Your weapon attacks score a critical hit on a roll of 19 or 20.")
    sneak = feat("Sneak Attack", {
        "kind": "Class feature", "activation": "Passive", "uses": "Once per turn",
        "effects": [fx("Extra damage", "{scale}d6", "",
                       "Finesse or ranged, with advantage or ally next to target")],
        "scale": [{"level": lvl, "value": (lvl + 1) // 2} for lvl in range(1, 20, 2)]},
        "Once per turn, extra damage when you hit with a finesse or ranged weapon and have advantage, "
        "or another enemy of the target is next to it.")
    cunning = feat("Cunning Action", {"kind": "Class feature", "activation": "Bonus action",
                                      "effects": [fx("Dash, Disengage or Dodge", "", "Dash, Disengage")]},
                   "Dash or Disengage as a bonus action. (Hide comes with the exploration rules.)")
    rage = feat("Rage", {
        "kind": "Class feature", "activation": "Bonus action", "uses": "Per long rest",
        "uses_count": "2 if level < 3 else 3 if level < 6 else 4", "duration": "1 minute",
        "requires": ["Not in heavy armor"],
        "effects": [fx("Bonus to damage", "2 if level < 9 else 3 if level < 16 else 4", "", "Strength attacks"),
                    fx("Resistance", "", "bludgeoning, piercing, slashing")]},
        "Fight with primal ferocity: extra damage with Strength melee attacks and resistance to physical damage.")
    unarmored = feat("Unarmored Defense", {"kind": "Class feature", "activation": "Passive",
                                           "requires": ["Wearing no armor"],
                                           "effects": [fx("Armor formula", "", "10 + dex_mod + con_mod")]},
                     "Without armor, your AC is 10 + DEX modifier + CON modifier (a shield still counts).")
    reckless = feat("Reckless Attack", {
        "kind": "Class feature", "activation": "Free", "duration": "Until your next turn",
        "effects": [fx("Advantage on attacks", "", "", "Strength attacks"), fx("Attacks against you have advantage")]},
        "Throw aside all concern for defense: advantage on Strength melee attacks, but attacks against you "
        "have advantage until your next turn.")
    fey = feat("Fey Ancestry", {"kind": "Racial trait", "activation": "Passive", "effects": [
        fx("Condition immunity", "", "Sleep"), fx("Note", "", "Advantage on saves against being charmed.")]},
        "Advantage on saving throws against being charmed, and magic can't put you to sleep.")
    resilience = feat("Dwarven Resilience", {"kind": "Racial trait", "activation": "Passive",
                                             "effects": [fx("Resistance", "", "poison")]},
                      "Resistance against poison damage (and advantage on saves against poison).")
    breath = feat("Fire Breath", {
        "kind": "Monster ability", "activation": "Action", "uses": "Recharge 5-6", "deals_damage": True,
        "target": "Area (save)", "damage": "16d6", "damage_type": "fire", "save_stat": stat["dex"],
        "save_dc": "8 + prof + con_mod", "on_save": "Half damage", "area": "Cone", "area_ft": 30, "range_ft": 30},
        "The dragon exhales fire in a 30-foot cone.")
    pack = feat("Pack Tactics", {"kind": "Monster ability", "activation": "Passive",
                                 "effects": [fx("Advantage on attacks", "", "", "Ally next to target")]},
                "Advantage on attack rolls against a creature if an ally is next to it.")
    nimble = feat("Nimble Escape", {"kind": "Monster ability", "activation": "Bonus action",
                                    "effects": [fx("Dash, Disengage or Dodge", "", "Disengage")]},
                  "The goblin can Disengage as a bonus action. (Hide comes later.)")

    def item(name):
        e = s.find_by_name("item", name)
        return [e.id] if e else []

    if not s.find_by_name("class", "Rogue"):
        s.create("class", "Rogue", {
            "hit_die": "d8", "primary_stat": stat["dex"], "saving_throws": [stat["dex"], stat["int"]],
            "armor_proficiency": ["Light"], "weapon_proficiency": ["Simple melee", "Simple ranged"],
            "starting_equipment": item("Shortsword") + item("Dagger") + item("Leather Armor"),
            "starting_gold": "4d4"}, "", [TAG], save=False)
    if not s.find_by_name("class", "Barbarian"):
        s.create("class", "Barbarian", {
            "hit_die": "d12", "primary_stat": stat["str"], "saving_throws": [stat["str"], stat["con"]],
            "armor_proficiency": ["Light", "Medium", "Shields"],
            "weapon_proficiency": ["Simple melee", "Martial melee", "Simple ranged", "Martial ranged"],
            "starting_equipment": item("Greataxe"), "starting_gold": "2d4", "extra_attacks": 5}, "", [TAG],
            save=False)

    def give_class(name, rows):
        klass = s.find_by_name("class", name)
        if not klass:
            return
        have = {r.get("feature") for r in klass.fields.get("features") or [] if isinstance(r, dict)}
        add = [{"level": lvl, "feature": f.id} for lvl, f in rows if f.id not in have]
        if add:
            keep = [r for r in klass.fields.get("features") or [] if isinstance(r, dict) and r.get("feature")]
            s.update(klass.id, fields={"features": keep + add}, save=False)

    def give(type_name, name, feats):
        e = s.find_by_name(type_name, name)
        if not e:
            return
        have = list(e.fields.get("features") or [])
        add = [f.id for f in feats if f.id not in have]
        if add:
            s.update(e.id, fields={"features": have + add}, save=False)

    # Goblins raid the quarry: they carry the ore Mara's quest asks for.
    goblin, ore = s.find_by_name("enemy", "Goblin"), s.find_by_name("item", "Iron Ore")
    if goblin and ore and not any(r.get("item") == ore.id for r in goblin.fields.get("loot") or []):
        s.update(goblin.id, fields={"loot": list(goblin.fields.get("loot") or [])
                                    + [{"item": ore.id, "chance": 50, "quantity": "1d2"}]}, save=False)

    # Places get a few words of description (older test-pack worlds had none).
    for type_name, name, text in DESCRIPTIONS:
        e = s.find_by_name(type_name, name)
        if e and not e.description:
            s.update(e.id, description=text, save=False)

    give_class("Fighter", [(1, second_wind), (2, action_surge), (3, improved_crit)])
    give_class("Rogue", [(1, sneak), (2, cunning)])
    give_class("Barbarian", [(1, rage), (1, unarmored), (2, reckless)])
    give("race", "Elf", [fey])
    give("race", "Dwarf", [resilience])
    give("enemy", "Young Red Dragon", [breath])
    give("enemy", "Wolf", [pack])
    give("enemy", "Dire Wolf", [pack])
    give("enemy", "Goblin", [nimble])
    s.save()
    install_world(world)


# ----------------------------------------------------------------------
# The wider test world: goods to trade, a second town down the east road,
# opening hours, and people out on the streets. Also safe to run again.
# ----------------------------------------------------------------------
def install_world(world) -> None:
    s = world.entities

    def get_or(type_name, name, fields, description="", tags=()):
        found = s.find_by_name(type_name, name)
        if found:
            return found
        return s.create(type_name, name, fields, description, [TAG, *tags], save=False)

    def item(name, fields, description="", tags=()):
        return get_or("item", name, fields, description, tags)

    item("Rations (1 day)", {"category": "Gear", "value": 0.5, "weight": 2, "stackable": True,
                             "sprite": "icon/bread"}, "Dried meat, hard bread and a little cheese.", ("food",))
    item("Mug of Ale", {"category": "Gear", "value": 0.04, "stackable": True, "sprite": "icon/bottle"},
         "Brown, bitter, and not quite cold.", ("drink",))
    item("Rope (50 ft)", {"category": "Gear", "value": 1, "weight": 10, "sprite": "icon/rope"},
         "Hempen rope, fifty feet of it.", ("gear",))
    item("Bedroll", {"category": "Gear", "value": 1, "weight": 7, "sprite": "icon/bag"}, "", ("gear",))
    item("Arrows (20)", {"category": "Ammunition", "value": 1, "weight": 1, "stackable": True,
                         "sprite": "icon/arrows"}, "", ("ammunition", "bow"))
    item("Hooded Lantern", {"category": "Gear", "value": 5, "weight": 2, "slot": "Off hand", "sprite": "weapon/torch",
                            "light_bright_ft": 30, "light_dim_ft": 30},
         "Bright light in a 30-foot radius and dim light for another 30 feet.", ("gear", "light"))
    item("Healing Herbs", {"category": "Material", "value": 0.2, "stackable": True, "sprite": "icon/herb"},
         "A bundle of yarrow and feverfew.", ("herb",))
    potion = s.find_by_name("item", "Healing Potion")
    shortbow = s.find_by_name("item", "Shortbow")

    briar = s.find_by_name("town", "Briarwell")
    thorn = get_or("town", "Thornmere", {
        "region": "Westmarch", "terrain": "Coast", "population": 380,
        "streets": [{"name": "Harbor Row", "connects": "Lantern Lane", "exit": "West"},
                    {"name": "Lantern Lane", "connects": "Harbor Row", "exit": "North"}]},
        "A fishing town of tarred boats and salt-grey houses, huddled against the wind off the sea.")
    if briar is not None and not briar.fields.get("roads"):
        s.update(briar.id, fields={"roads": [{"direction": "East", "leads_to": thorn.id, "hours": 6, "danger": 25}]},
                 save=False)
    if briar is not None and not thorn.fields.get("roads"):
        s.update(thorn.id, fields={"roads": [{"direction": "West", "leads_to": briar.id, "hours": 6, "danger": 25}]},
                 save=False)

    inn = get_or("building", "The Drowned Lantern", {
        "kind": "Inn", "town": thorn.id, "street": "Harbor Row", "interior": "Rustic", "open_hours": "always",
        "inn_price": 5}, "Nets hang from the rafters and the fire never quite goes out. Rooms upstairs.")
    shop = get_or("building", "Fenn's Harbor Goods", {
        "kind": "Shop", "town": thorn.id, "street": "Harbor Row", "interior": "Wooden",
        "open_hours": "07:00-19:00"}, "Crates of rope, oil, salt fish and lamp wicks, stacked to the ceiling.")
    shrine = get_or("building", "Shrine of the Tides", {
        "kind": "Temple", "town": thorn.id, "street": "Lantern Lane", "interior": "Stone",
        "open_hours": "05:00-21:00"}, "A small stone shrine, its floor worn smooth by kneeling fishers.")
    human = s.find_by_name("race", "Human")
    elf = s.find_by_name("race", "Elf")

    def npc(name, fields, building=None):
        found = s.find_by_name("npc", name)
        if found:
            return found
        e = s.create("npc", name, fields, "", [TAG], save=False)
        if building is not None:
            s.update(building.id, fields={"npcs": list(building.fields.get("npcs") or []) + [e.id]}, save=False)
        return e

    npc("Wynn Tallow", {"race": human.id if human else None, "occupation": "Innkeeper", "building": inn.id,
                        "greeting": "Wind's up tonight. Come in, come in.",
                        "dialogue": ["Room's five gold, breakfast included, such as it is.",
                                     "Boats didn't go out today. Too much swell.",
                                     "Road to Briarwell's been rough lately. Wolves, they say."],
                        "appearance": {"hair": "bald", "beard": "full", "hair_color": "#6a5a4a"}}, inn)
    npc("Odo Fenn", {"race": human.id if human else None, "occupation": "Merchant", "building": shop.id,
                     "greeting": "Looking or buying? Both are fine. Buying's better.",
                     "dialogue": ["Prices go up when the road's bad. The road's bad.",
                                  "Lantern oil, rope, rations: everything a sensible person needs."],
                     "shop_items": [i.id for i in (s.find_by_name("item", "Hooded Lantern"),
                                                   s.find_by_name("item", "Rope (50 ft)")) if i],
                     "gold": 250, "price_markup": 110,
                     "appearance": {"hair": "short", "hair_color": "#3a2a20", "clothes": "#4a5a3a"}}, shop)
    npc("Sister Maren", {"race": elf.id if elf else None, "occupation": "Priest", "building": shrine.id,
                         "disposition": "Friendly", "greeting": "The tide brings everyone here eventually.",
                         "dialogue": ["Pray for calm seas, and for the ones who didn't come back.",
                                      "I keep a few potions for travelers. Take care on the road."],
                         "shop_items": [potion.id] if potion else [], "sells_tags": ["potion", "holy", "herb"],
                         "gold": 150, "appearance": {"hair": "long", "hair_color": "#e8e0c8"}}, shrine)
    npc("Captain Iver", {"race": human.id if human else None, "occupation": "Guard", "town": thorn.id,
                         "street": "Harbor Row", "greeting": "Keep your weapons sheathed in town.",
                         "dialogue": ["Something's been taking sheep in the hills north of here.",
                                      "Thornmere's quiet. I'd like it to stay that way."],
                         "appearance": {"hair": "short", "hair_color": "#8a8a8a", "beard": "short"},
                         "equipment": {slot: e.id for slot, e in (("Main hand", s.find_by_name("item", "Spear")),
                                                                  ("Body", s.find_by_name("item", "Chain Mail")))
                                       if e is not None}})
    if briar is not None:
        npc("Watchman Ruck", {"race": human.id if human else None, "occupation": "Guard", "town": briar.id,
                              "street": "Market Square", "greeting": "Move along. Or don't, I'm not fussed.",
                              "dialogue": ["Goblins have been raiding the old quarry west of town.",
                                           "Market day's the third of every week. Don't ask me why."]})
        forge = s.find_by_name("building", "Holt's Forge")
        if forge is not None and not forge.fields.get("open_hours"):
            s.update(forge.id, fields={"open_hours": "06:00-20:00"}, save=False)
        kettle = s.find_by_name("building", "The Copper Kettle")
        if kettle is not None:
            s.update(kettle.id, fields={"open_hours": "always"}, save=False)
        bess = s.find_by_name("npc", "Bess Underhill")
        if bess is not None and not bess.fields.get("shop_items"):
            s.update(bess.id, fields={"shop_items": [i.id for i in (s.find_by_name("item", "Rations (1 day)"),
                                                                    s.find_by_name("item", "Mug of Ale")) if i]},
                     save=False)
        mara = s.find_by_name("npc", "Mara Holt")
        if mara is not None and not mara.fields.get("gold"):
            s.update(mara.id, fields={"gold": 300}, save=False)
    install_mechanics(world)
    install_characters(world)
    install_exploration(world)
    install_continents(world)
    forge = s.find_by_name("building", "Holt's Forge")
    if forge is not None and not world.meta.get("rules", {}).get("start_location"):
        world.set_rule("start_location", forge.id)
    if shortbow is not None:
        bandit = s.find_by_name("enemy", "Bandit")
        if bandit is not None and not any(r.get("item") == potion.id for r in bandit.fields.get("loot") or [] if potion):
            loot = list(bandit.fields.get("loot") or [])
            if potion:
                loot.append({"item": potion.id, "chance": 15, "quantity": "1"})
            s.update(bandit.id, fields={"loot": loot}, save=False)
    s.save()


# ----------------------------------------------------------------------
# Conditions, reactions and mechanics for the test pack. Safe to run again.
# ----------------------------------------------------------------------
def install_mechanics(world) -> None:
    s = world.entities
    stat = {k: (s.stat_by_key(k).id if s.stat_by_key(k) else "") for k in ("str", "dex", "con", "int", "wis", "cha")}

    def get_or(type_name, name, fields, description="", custom=None):
        found = s.find_by_name(type_name, name)
        if found:
            return found
        return s.create(type_name, name, fields, description, [TAG], custom=custom, save=False)

    def fx(effect, amount="", detail="", only_when="Always"):
        return {"effect": effect, "amount": amount, "detail": detail, "only_when": only_when}

    hold = get_or("spell", "Hold Person", {
        "level": 2, "school": "Enchantment", "range_ft": 60, "components": ["V", "S", "M"], "concentration": True,
        "duration": "Concentration, up to 1 minute", "effect": "Saving throw", "save_stat": stat["wis"],
        "on_save": "No effect", "condition": "Paralyzed", "condition_rounds": 10, "condition_save_each_turn": True},
        "A humanoid must succeed on a Wisdom saving throw or be paralyzed. It repeats the save at the end of each "
        "of its turns.")
    shield = get_or("spell", "Shield", {
        "level": 1, "school": "Abjuration", "casting_time": "Reaction",
        "reaction_trigger": "When you are hit by an attack", "range_ft": 0, "components": ["V", "S"],
        "duration": "1 round", "effect": "Effect blocks", "buff_target": "Self",
        "buff_effects": [fx("Bonus to AC", "5")]},
        "An invisible barrier of magical force: +5 AC until the start of your next turn, including against the "
        "triggering attack.")
    wizard = s.find_by_name("class", "Wizard")
    if wizard is not None:
        spells = list(wizard.fields.get("spells") or [])
        add = [x.id for x in (shield, hold) if x.id not in spells]
        if add:
            s.update(wizard.id, fields={"spells": spells + add}, save=False)

    dodge = get_or("feature", "Uncanny Dodge", {
        "kind": "Class feature", "activation": "Reaction", "reaction_trigger": "When you are hit by an attack",
        "effects": [fx("Reduce damage", "half")]},
        "When an attacker you can see hits you with an attack, halve the attack's damage against you.")
    parry = get_or("feature", "Parry", {
        "kind": "Monster ability", "activation": "Reaction", "reaction_trigger": "When you are hit by an attack",
        "effects": [fx("Bonus to AC", "2")]},
        "Adds 2 to its AC against one melee attack that would hit it.")
    rogue = s.find_by_name("class", "Rogue")
    if rogue is not None:
        rows = list(rogue.fields.get("features") or [])
        if not any(r.get("feature") == dodge.id for r in rows):
            s.update(rogue.id, fields={"features": rows + [{"level": 5, "feature": dodge.id}]}, save=False)

    # Wolves knock you down
    for name, dc in (("Wolf", 11), ("Dire Wolf", 13)):
        wolf = s.find_by_name("enemy", name)
        if wolf is None:
            continue
        attacks = [dict(a) for a in wolf.fields.get("attacks") or []]
        changed = False
        for a in attacks:
            if a.get("name") == "Bite" and not a.get("condition"):
                a.update(condition="Prone", save_stat=stat["str"], save_dc=dc)
                changed = True
        if changed:
            s.update(wolf.id, fields={"attacks": attacks}, save=False)

    human = s.find_by_name("race", "Human")
    scimitar, leather = s.find_by_name("item", "Scimitar"), s.find_by_name("item", "Leather Armor")
    get_or("enemy", "Bandit Captain", {
        "race": human.id if human else None, "appearance": {"hair": "short", "hair_color": "#4a2a1a", "beard": "short"},
        "equipment": {k: v.id for k, v in (("Main hand", scimitar), ("Body", leather)) if v},
        "cr": "2", "hp": 65, "hp_dice": "10d8+20", "ac": 15, "speed": 30,
        "stats": {"str": 15, "dex": 16, "con": 14, "int": 14, "wis": 11, "cha": 14},
        "saving_throws": [stat["str"], stat["dex"], stat["wis"]], "multiattack": 3, "features": [parry.id],
        "gold": "4d10", "environments": ["Urban", "Forest", "Plains", "Hills"]},
        "A bandit leader with a quick blade and quicker reflexes.")

    shortsword = s.find_by_name("item", "Shortsword")
    get_or("item", "Ember Blade", {
        "category": "Weapon", "weapon_kind": "Martial melee", "damage": "1d6", "damage_type": "slashing",
        "properties": ["finesse", "light"], "value": 150, "rarity": "Uncommon", "slot": "Main hand",
        "sprite": "weapon/shortsword", "tint": "#e0602a"},
        "A short blade that never quite stops glowing. Hits sometimes set the target alight (see the Fiery "
        "Weapons mechanic).", custom=[{"key": "burn_chance", "label": "Burn Chance", "type": "number", "value": 25}])
    thorn = s.find_by_name("town", "Thornmere")

    def mech(name, fields, description=""):
        return get_or("mechanic", name, fields, description)

    mech("Fiery Weapons", {
        "trigger": "Attack hit", "applies_to": "Anyone", "where": "In combat", "enabled": True,
        "condition": "weapon.burn_chance > 0 and roll('1d100') <= weapon.burn_chance", "chance": 100,
        "limit": "No limit",
        "effects": [{"action": "Deal damage", "to": "The other one", "amount": "1d4", "detail": "fire",
                     "message": "Flames lick from the blade: {other} is burned!"}]},
        "Any weapon with a Burn Chance value (a custom field) can set what it hits on fire. Try the Ember Blade.")
    mech("Bleeding Wounds", {
        "trigger": "Damage taken", "applies_to": "Party members", "where": "In combat", "enabled": False,
        "condition": "damage >= 8 and (damage_type == 'slashing' or damage_type == 'piercing')", "chance": 25, "limit": "No limit",
        "effects": [{"action": "Saving throw (stop if passed)", "to": "Who it happened to", "amount": "12",
                     "detail": "con"},
                    {"action": "Deal damage", "to": "Who it happened to", "amount": "1d4",
                     "message": "{me} is bleeding badly."}]},
        "Example: a deep cut can make you bleed. Turned off; switch on 'Active' to try it.")
    mech("Road-Weary", {
        "trigger": "Time passed", "applies_to": "Party members", "where": "Outside combat", "enabled": False,
        "condition": "minutes >= 120", "chance": 10, "limit": "Once per day",
        "effects": [{"action": "Saving throw (stop if passed)", "to": "Who it happened to", "amount": "10",
                     "detail": "con"},
                    {"action": "Apply condition", "to": "Who it happened to", "detail": "Exhaustion",
                     "message": "{me} is worn out by the road."}]},
        "Example: long travel can exhaust you until you rest. Turned off.")
    if thorn is not None:
        mech("A Welcome in Thornmere", {
            "trigger": "Location entered", "applies_to": "Specific thing", "entity": thorn.id, "enabled": True,
            "limit": "Once ever", "chance": 100,
            "effects": [{"action": "Give XP", "to": "The world", "amount": "25",
                         "message": "Gulls wheel over the harbor. You've reached Thornmere for the first time."},
                        {"action": "Change value", "to": "The world", "amount": "1", "detail": "towns_found"}]},
            "Example: the first visit to Thornmere is worth a little experience, and counts toward world.towns_found.")
    s.save()


# ----------------------------------------------------------------------
# Character creation and levelling for the test pack: more skills, backgrounds, subraces,
# subclasses, class progression, starting gear choices, feats, Stamina techniques and
# ammunition. Safe to run again.
# ----------------------------------------------------------------------
def install_characters(world) -> None:
    s = world.entities
    stat = {k: (s.stat_by_key(k).id if s.stat_by_key(k) else "") for k in ("str", "dex", "con", "int", "wis", "cha")}

    def get_or(type_name, name, fields, description=""):
        found = s.find_by_name(type_name, name)
        if found:
            return found
        return s.create(type_name, name, fields, description, [TAG], save=False)

    def fx(effect, amount="", detail="", only_when="Always"):
        return {"effect": effect, "amount": amount, "detail": detail, "only_when": only_when}

    def ids(type_name, *names):
        return [e.id for e in (s.find_by_name(type_name, n) for n in names) if e]

    def item(name):
        e = s.find_by_name("item", name)
        return e.id if e else None

    for name, key in (("Insight", "wis"), ("Medicine", "wis"), ("Survival", "wis"), ("Religion", "int"),
                      ("Arcana", "int"), ("History", "int"), ("Intimidation", "cha"), ("Sleight of Hand", "dex")):
        get_or("skill", name, {"kind": "Skill", "stat": stat[key]})

    # ammunition: single arrows, and bows that fire them
    old_arrows = s.find_by_name("item", "Arrows (20)")
    if old_arrows is not None and not s.find_by_name("item", "Arrow"):
        s.update(old_arrows.id, name="Arrow", fields={"value": 0.05, "weight": 0.05, "ammo_type": "Arrow",
                                                      "stackable": True}, save=False)
    get_or("item", "Arrow", {"category": "Ammunition", "ammo_type": "Arrow", "value": 0.05, "weight": 0.05,
                             "stackable": True, "sprite": "icon/arrows"}, "A single arrow.")
    bow = s.find_by_name("item", "Shortbow")
    if bow is not None and not bow.fields.get("uses_ammo"):
        s.update(bow.id, fields={"uses_ammo": "Arrow"}, save=False)
    ring = s.find_by_name("item", "Ember Ring")
    if ring is not None and not ring.fields.get("requires_attunement"):
        s.update(ring.id, fields={"requires_attunement": True}, save=False)

    # backgrounds
    shelter = get_or("feature", "Shelter of the Faithful", {
        "kind": "Background feature", "activation": "Passive",
        "effects": [fx("Note", "", "Temples of your faith will shelter and heal you and your companions.")]})
    road = get_or("feature", "Road Wisdom", {
        "kind": "Background feature", "activation": "Passive",
        "effects": [fx("Note", "", "You know the roads, the inns along them and who keeps them honest.")]})
    get_or("background", "Acolyte", {"skills": ids("skill", "Insight", "Religion"), "extra_languages": 2,
                                     "feature": shelter.id, "gold": 15,
                                     "traits": ["I quote holy words in almost every situation."],
                                     "ideals": ["Faith: I trust that my deity will guide my actions."]},
           "You have spent your life in the service of a temple.")
    get_or("background", "Caravan Guard", {"skills": ids("skill", "Athletics", "Survival"),
                                           "languages": ["Common"], "feature": road.id,
                                           "equipment": [i for i in (item("Rope (50 ft)"), item("Bedroll")) if i],
                                           "gold": 10, "traits": ["I sleep with one eye open."]},
           "You walked beside wagons for years, keeping bandits and worse at bay.")

    # subraces
    tough = get_or("feature", "Dwarven Toughness", {"kind": "Racial trait", "activation": "Passive",
                                                    "effects": [fx("Bonus hit points", "level")]},
                   "Your hit point maximum increases by 1, and by 1 again whenever you gain a level.")
    dwarf, elf = s.find_by_name("race", "Dwarf"), s.find_by_name("race", "Elf")
    if dwarf is not None:
        get_or("race", "Hill Dwarf", {"subrace_of": dwarf.id, "appearance": {"base": "dwarf"},
                                      "stat_modifiers": [{"stat": stat["wis"], "amount": 1}],
                                      "features": [tough.id], "speed": 30, "size": "Medium"})
    if elf is not None:
        get_or("race", "High Elf", {"subrace_of": elf.id, "appearance": {"base": "elf"},
                                    "stat_modifiers": [{"stat": stat["int"], "amount": 1}], "speed": 30})

    # Stamina techniques (original): martial characters spend Stamina on these
    power = get_or("feature", "Power Strike", {
        "kind": "Class feature", "activation": "Free", "uses": "Costs Mana/Stamina", "cost": "15",
        "duration": "Until end of your turn", "requires": ["Holding a melee weapon"],
        "effects": [fx("Extra damage", "1d8", "", "Melee attacks")]},
        "Put your whole body behind your blows: +1d8 damage on melee hits this turn. Costs 15 Stamina.")
    feint = get_or("feature", "Feint", {
        "kind": "Class feature", "activation": "Bonus action", "uses": "Costs Mana/Stamina", "cost": "10",
        "duration": "Until end of your turn", "effects": [fx("Advantage on attacks")]},
        "A false opening draws their guard: advantage on your attacks this turn. Costs 10 Stamina.")
    roar = get_or("feature", "Bloodied Roar", {
        "kind": "Class feature", "activation": "Bonus action", "uses": "Costs Mana/Stamina", "cost": "20",
        "effects": [fx("Temporary hit points", "1d10 + level")]},
        "Shrug off pain with a roar: gain 1d10 + your level temporary hit points. Costs 20 Stamina.")

    # subclasses (SRD) and class progression
    def subclass(name, parent, rows, description=""):
        if parent is None:
            return None
        return get_or("class", name, {"subclass_of": parent.id, "features": rows}, description)

    def note(name, text, kind="Class feature"):
        return get_or("feature", name, {"kind": kind, "activation": "Passive", "effects": [fx("Note", "", text)]})

    fighter, rogue = s.find_by_name("class", "Fighter"), s.find_by_name("class", "Rogue")
    wizard, barb = s.find_by_name("class", "Wizard"), s.find_by_name("class", "Barbarian")
    crit = s.find_by_name("feature", "Improved Critical")
    if fighter is not None and crit is not None:
        rows = [r for r in fighter.fields.get("features") or [] if r.get("feature") != crit.id]
        if not any(r.get("feature") == power.id for r in rows):
            rows.append({"level": 1, "feature": power.id})
        if not fighter.fields.get("subclass_title"):
            s.update(fighter.id, fields={
                "features": rows, "subclass_level": 3, "subclass_title": "Martial Archetype",
                "skill_choices": ids("skill", "Acrobatics", "Athletics", "History", "Insight", "Intimidation",
                                     "Perception", "Survival"), "skill_count": 2,
                "multiclass_requirement": "str >= 13 or dex >= 13", "asi_levels": "4, 6, 8, 12, 14, 16, 19",
                "starting_equipment": [],
                "equipment_choices": [
                    {"group": 1, "items": [i for i in (item("Chain Mail"),) if i], "count": 1},
                    {"group": 1, "items": [i for i in (item("Leather Armor"), item("Shortbow")) if i], "count": 1},
                    {"group": 2, "items": [i for i in (item("Longsword"), item("Shield")) if i], "count": 1},
                    {"group": 2, "items": [i for i in (item("Greataxe"),) if i], "count": 1},
                    {"group": 3, "items": [i for i in (item("Arrow"),) if i], "count": 20}]}, save=False)
        subclass("Champion", fighter, [{"level": 3, "feature": crit.id},
                                       {"level": 7, "feature": note("Remarkable Athlete",
                                                                    "Half proficiency on Strength, Dexterity and "
                                                                    "Constitution checks you aren't proficient in.").id}],
                 "A warrior who hones raw physical power to deadly perfection.")
    if rogue is not None and not rogue.fields.get("subclass_title"):
        rows = list(rogue.fields.get("features") or [])
        if not any(r.get("feature") == feint.id for r in rows):
            rows.append({"level": 1, "feature": feint.id})
        s.update(rogue.id, fields={
            "features": rows, "subclass_level": 3, "subclass_title": "Roguish Archetype",
            "skill_choices": ids("skill", "Acrobatics", "Athletics", "Insight", "Intimidation", "Perception",
                                 "Persuasion", "Sleight of Hand", "Stealth"), "skill_count": 4,
            "multiclass_requirement": "dex >= 13", "asi_levels": "4, 8, 10, 12, 16, 19",
            "starting_equipment": [i for i in (item("Leather Armor"), item("Dagger")) if i],
            "equipment_choices": [
                {"group": 1, "items": [i for i in (item("Shortsword"),) if i], "count": 1},
                {"group": 1, "items": [i for i in (item("Shortbow"), item("Arrow")) if i], "count": 1}]}, save=False)
        subclass("Thief", rogue, [{"level": 3, "feature": note("Fast Hands", "Use an object or Sleight of Hand "
                                                                           "as a bonus action.").id}],
                 "You hone your skills in the larcenous arts.")
    if wizard is not None and not wizard.fields.get("subclass_title"):
        s.update(wizard.id, fields={
            "subclass_level": 2, "subclass_title": "Arcane Tradition", "caster_type": "Full",
            "skill_choices": ids("skill", "Arcana", "History", "Insight", "Medicine", "Religion"), "skill_count": 2,
            "multiclass_requirement": "int >= 13",
            "cantrips_known": [{"level": 1, "count": 3}, {"level": 4, "count": 4}, {"level": 10, "count": 5}],
            "spells_known": [{"level": 1, "count": 3}, {"level": 3, "count": 4}, {"level": 5, "count": 5}]},
            save=False)
        subclass("School of Evocation", wizard, [{"level": 2, "feature": note(
            "Sculpt Spells", "Your evocation spells can leave chosen allies unharmed.").id}],
                 "You focus your study on magic that creates powerful elemental effects.")
    if barb is not None and not barb.fields.get("subclass_title"):
        rows = list(barb.fields.get("features") or [])
        if not any(r.get("feature") == roar.id for r in rows):
            rows.append({"level": 1, "feature": roar.id})
        s.update(barb.id, fields={
            "features": rows, "subclass_level": 3, "subclass_title": "Primal Path",
            "skill_choices": ids("skill", "Athletics", "Intimidation", "Perception", "Survival"), "skill_count": 2,
            "multiclass_requirement": "str >= 13"}, save=False)
        subclass("Path of the Berserker", barb, [{"level": 3, "feature": note(
            "Frenzy", "While raging you can make a single melee weapon attack as a bonus action.").id}],
                 "For some barbarians, rage is a means to an end, and that end is violence.")

    # feats
    get_or("feature", "Grappler", {"kind": "Feat", "activation": "Passive", "effects": [fx(
        "Note", "", "Advantage on attack rolls against a creature you are grappling.")]},
           "Prerequisite: Strength 13 or higher.")
    get_or("feature", "Hardy", {"kind": "Feat", "activation": "Passive",
                                "effects": [fx("Bonus hit points", "2 * level")]},
           "Your hit point maximum increases by twice your level.")
    get_or("feature", "Battle Focus", {
        "kind": "Feat", "activation": "Bonus action", "uses": "Costs Mana/Stamina", "cost": "20",
        "duration": "Until end of your turn", "effects": [fx("Bonus to attack rolls", "1d4")]},
        "Narrow the world to the next swing: +1d4 to attack rolls this turn. Costs 20 Mana or Stamina.")
    s.save()


# ----------------------------------------------------------------------
# 9b examples: regions, a landmark, a dungeon, an NPC's day, family ties and a wand with charges.
# Safe to run again.
# ----------------------------------------------------------------------
def install_exploration(world) -> None:
    s = world.entities

    def get_or(type_name, name, fields, description=""):
        found = s.find_by_name(type_name, name)
        if found:
            return found
        return s.create(type_name, name, fields, description, [TAG], save=False)

    briar = s.find_by_name("town", "Briarwell")
    thorn = s.find_by_name("town", "Thornmere")
    if briar is None:
        return
    E = lambda t, n: s.find_by_name(t, n)          # noqa: E731

    # regions around the two towns (the map colours the land by these)
    west = get_or("region", "Westmarch", {
        "biome": "Plains", "realm": "Kingdom of Aster", "climate": "Mild and rainy",
        "center": {"x": 68, "y": 58}, "size_miles": 40, "stretch": 1.4, "level_min": 1, "level_max": 4,
        "danger": 25, "enemies": [e.id for e in (E("enemy", "Wolf"), E("enemy", "Bandit"), E("enemy", "Goblin")) if e]},
        "Rolling farmland and hedgerows between the river and the sea. Bandits work the roads in bad years.")
    get_or("region", "Hollowpine Wood", {
        "biome": "Forest", "realm": "Kingdom of Aster", "center": {"x": 52, "y": 34}, "size_miles": 22,
        "stretch": 1.2, "level_min": 2, "level_max": 5, "danger": 40,
        "enemies": [e.id for e in (E("enemy", "Wolf"), E("enemy", "Dire Wolf")) if e]},
        "Old pines so close together that noon looks like dusk. Wolves den here.")
    get_or("region", "Greyfen", {
        "biome": "Swamp", "realm": "", "center": {"x": 74, "y": 88}, "size_miles": 20, "stretch": 1.6,
        "level_min": 2, "level_max": 6, "danger": 45,
        "enemies": [e.id for e in (E("enemy", "Skeleton"), E("enemy", "Goblin")) if e]},
        "Reed beds and black water south of the towns. The old barrows are slowly sinking into it.")
    for town in (briar, thorn):
        if town is not None and not town.fields.get("region_ref"):
            s.update(town.id, fields={"region_ref": west.id}, save=False)

    # a dungeon under a hidden landmark, and a ruined tower anyone can find
    skel, goblin = E("enemy", "Skeleton"), E("enemy", "Goblin")
    potion, ring = E("item", "Healing Potion"), E("item", "Ember Ring")
    barrow = get_or("dungeon", "Sunken Barrow", {
        "kind": "Crypt", "level": 2, "restock_days": 30, "town": (thorn or briar).id, "direction": "South",
        "rooms": [
            {"name": "Mud Stair", "description": "Stone steps slick with fen mud lead down into the dark.",
             "connects": ""},
            {"name": "Hall of Bones", "description": "Niches in the walls, each with a skull that seems to watch you.",
             "connects": "Mud Stair", "enemy": skel.id if skel else None, "count": "2",
             "trap_dc": 12, "trap_damage": "1d6", "trap_type": "piercing"},
            {"name": "Flooded Ossuary", "description": "Knee-deep black water. Bones knock against your legs.",
             "connects": "Hall of Bones", "enemy": goblin.id if goblin else None, "count": "3", "gold": "12"},
            {"name": "Burial Chamber", "description": "A stone bier, and something on it that sits up.",
             "connects": "Hall of Bones", "enemy": skel.id if skel else None, "count": "3", "boss": True,
             "loot": [potion.id] if potion else [], "gold": "40"},
            {"name": "Hidden Niche", "description": "A gap behind a loose slab, dry and forgotten.",
             "connects": "Burial Chamber", "secret": True, "gold": "60",
             "loot": [ring.id] if ring else []},
        ]}, "The tomb of a forgotten fen-lord, half swallowed by the marsh.")
    get_or("landmark", "Barrow Mound", {
        "kind": "Ruins", "near_town": (thorn or briar).id, "direction": "South", "hidden": True,
        "travel_minutes": 60, "dungeon": barrow.id},
        "A grassy hump in the reeds, ringed by tilted standing stones. A dark opening yawns on its north side.")
    get_or("landmark", "Old Watchtower", {
        "kind": "Tower", "near_town": briar.id, "direction": "North", "hidden": False, "travel_minutes": 45,
        "enemies": [E("enemy", "Wolf").id] if E("enemy", "Wolf") else [],
        "loot": [potion.id] if potion else [], "gold": 15},
        "A broken stone tower on a hill. Wolves have made the ground floor their den.")

    # an NPC's day and family
    forge, kettle = E("building", "Holt's Forge"), E("building", "The Copper Kettle")
    house = get_or("building", "Holt House", {"kind": "House", "town": briar.id,
                                              "street": (forge.fields.get("street") if forge else "") or "",
                                              "interior": "Wooden", "open_hours": "always"},
                   "A narrow two-storey house that smells of soot and bread.")
    mara, tobin = E("npc", "Mara Holt"), E("npc", "Tobin")
    if mara is not None and not mara.fields.get("schedule"):
        sched = [{"from": "20:00", "to": "23:00", "place": kettle.id, "activity": "having a drink"}] if kettle else []
        rel = [{"npc": tobin.id, "kind": "Child", "note": "Tobin is her son"}] if tobin else []
        s.update(mara.id, fields={"home": house.id, "schedule": sched, "relationships": rel}, save=False)
    if tobin is not None and not tobin.fields.get("home"):
        s.update(tobin.id, fields={"home": house.id}, save=False)
    bess, wynn = E("npc", "Bess Underhill"), E("npc", "Wynn Tallow")
    if bess is not None and wynn is not None and not bess.fields.get("relationships"):
        s.update(bess.id, fields={"relationships": [{"npc": wynn.id, "kind": "Rival",
                                                     "note": "they both claim the best ale in the west"}]},
                 save=False)

    # a magic item with charges that casts a spell
    missile = E("spell", "Magic Missile")
    if missile is not None and E("item", "Wand of Missiles") is None:
        zap = get_or("feature", "Wand of Missiles: Zap", {
            "kind": "Other", "activation": "Action", "uses": "Item charges", "cost": "1",
            "casts_spell": missile.id},
            "Spend 1 charge to cast Magic Missile.")
        get_or("item", "Wand of Missiles", {
            "category": "Trinket", "slot": "Main hand", "rarity": "Uncommon", "value": 500, "weight": 1,
            "features": [zap.id], "charges": 7, "charges_regain": "1d6+1"},
            "This wand has 7 charges. Spend 1 to cast Magic Missile. It regains 1d6 + 1 charges each dawn.")
    s.save()


# ----------------------------------------------------------------------
# Continents, and the ship, airship and caravan between them. Safe to run again.
# ----------------------------------------------------------------------
def install_continents(world) -> None:
    s = world.entities

    def get_or(type_name, name, fields, description=""):
        found = s.find_by_name(type_name, name)
        if found:
            return found
        return s.create(type_name, name, fields, description, [TAG], save=False)

    briar = s.find_by_name("town", "Briarwell")
    thorn = s.find_by_name("town", "Thornmere")
    if briar is None or thorn is None:
        return
    if not briar.fields.get("position"):              # pin the home towns, so the new ones don't move them
        s.update(briar.id, fields={"position": {"x": 60, "y": 60}}, save=False)
    human = s.find_by_name("race", "Human")
    dwarf = s.find_by_name("race", "Dwarf") or human
    hid = human.id if human else ""
    ardellan = get_or("continent", "Ardellan", {
        "biome": "Plains", "climate": "Mild and rainy", "center": {"x": 72, "y": 64}, "size_miles": 50,
        "stretch": 1.2, "ragged": 40},
        "Green, rain-soaked lands of farms, forests and old kingdoms. Home.")
    sarrow = get_or("continent", "Sarrowmere", {
        "biome": "Desert", "climate": "Hot and dry", "center": {"x": 250, "y": 80}, "size_miles": 45,
        "stretch": 1.2, "ragged": 60},
        "A sun-scorched land of dunes, salt flats and walled trading cities, across the sea to the east.")
    varn = get_or("continent", "Varnholt", {
        "biome": "Arctic", "climate": "Bitterly cold", "center": {"x": 185, "y": 215}, "size_miles": 40,
        "stretch": 1.5, "ragged": 55},
        "Ice fields and black mountains in the far south. Few go there, and fewer come back.")
    for r in s.all("region"):
        if not r.fields.get("continent"):
            s.update(r.id, fields={"continent": ardellan.id}, save=False)

    dun = get_or("town", "Dunmarket", {
        "terrain": "Desert", "population": 2400, "kind": "Town", "position": {"x": 250, "y": 80},
        "streets": [{"name": "Caravan Square", "connects": "Wharf Road", "exit": "East"},
                    {"name": "Wharf Road", "connects": "Caravan Square", "exit": "West"}]},
        "A walled trading town of white stone, where the desert caravans meet the sea.")
    frost = get_or("town", "Frosthaven", {
        "terrain": "Arctic", "population": 300, "kind": "Village", "position": {"x": 185, "y": 215},
        "streets": [{"name": "Ice Street", "connects": "", "exit": "North"}]},
        "A huddle of turf-roofed halls around a smoking hot spring, at the edge of the ice.")
    wharf = get_or("building", "Sandgate Wharf", {"kind": "Warehouse", "town": dun.id, "street": "Wharf Road",
                                                  "interior": "Wooden", "open_hours": "05:00-22:00"},
                   "Piers, ropes and stacked bales. Ships from across the sea tie up here, and an airship mast "
                   "rises over the roof.")
    camel = get_or("building", "The Thirsty Camel", {"kind": "Tavern", "town": dun.id, "street": "Caravan Square",
                                                    "interior": "Stone", "inn_price": 4, "open_hours": "always"},
                   "Cool stone, low cushions and strong mint tea.")
    lodge = get_or("building", "Frosthaven Lodge", {"kind": "Inn", "town": frost.id, "street": "Ice Street",
                                                   "interior": "Rustic", "inn_price": 3, "open_hours": "always"},
                   "A long hall with a fire at each end, steamy from the hot spring next door.")
    harbor = s.find_by_name("building", "Fenn's Harbor Goods")

    get_or("npc", "Captain Hesk", {
        "race": hid, "occupation": "Ship captain", "building": harbor.id if harbor else "", "town": thorn.id,
        "greeting": "The Gull leaves on the tide. You coming?",
        "dialogue": ["Pirates are thick in the strait this year.", "Dunmarket's three days, if the wind holds."],
        "passages": [{"to": dun.id, "method": "Boat", "price": 20, "days": 3, "danger": 35,
                      "note": "on the Gull"}]})
    get_or("npc", "Captain Ysolde", {
        "race": hid, "occupation": "Ship captain", "building": wharf.id,
        "greeting": "West to Thornmere? Pay up and get aboard.",
        "passages": [{"to": thorn.id, "method": "Boat", "price": 20, "days": 3, "danger": 35}]})
    get_or("npc", "Pilot Arn Vell", {
        "race": hid, "occupation": "Airship pilot", "building": wharf.id,
        "greeting": "Ever flown? Don't look down, and don't touch the burners.",
        "dialogue": ["The winds south are wild, but she's never dropped anyone. Yet."],
        "passages": [{"to": frost.id, "method": "Airship", "price": 60, "days": 2, "danger": 30}]})
    get_or("npc", "Oren Dask", {
        "race": hid, "occupation": "Innkeeper", "building": camel.id,
        "greeting": "Sit, drink, cool off.", "shop_items": [i.id for i in (s.find_by_name("item", "Mug of Ale"),
                                                                          s.find_by_name("item", "Rations (1 day)"))
                                                           if i]})
    get_or("npc", "Brannoc", {
        "race": dwarf.id if dwarf else hid, "occupation": "Caravan master", "building": lodge.id,
        "greeting": "The ice road north is long and cold. My sledges make it most years.",
        "passages": [{"to": briar.id, "method": "Caravan", "price": 35, "days": 5, "danger": 30,
                      "note": "sledges across the ice bridge"}]})
    get_or("npc", "Sigrun", {"race": hid, "occupation": "Innkeeper", "building": lodge.id,
                             "greeting": "Close the door! You're letting the warm out."})
    s.save()
