"""Conversations: dialogue trees, and talking through them.

A tree (the "tree" field of a Dialogue entity) is a set of nodes. A node is what the NPC says (one of
several ways of saying it, picked so it doesn't repeat) and the answers the party can pick:

    {"start": "start",
     "openers": [{"if": [condition...], "node": "hostile"}],     # first match picks where it begins
     "nodes": [{"id": "start", "say": ["{greeting}"], "options": [option...]}, ...],
     "layout": {"start": [x, y]}}                                  # where the editor drew each node

    option = {"text": "Let's trade.",
              "to": "end" | "hub" | "" (stay; a node with no answers of its own goes back to the topics) | node id,
              "if": [condition...], "hide": True (hidden when not met; otherwise shown greyed out),
              "check": {"skill": "Persuasion", "dc": 12, "fail": node id},    # success goes "to"
              "do": [action...],
              "each": "ready_quests" | "active_quests" | "choices"}   # one answer per quest ({quest} in the text)

Conditions:  {"type": ..., "not": True to turn it round}
    attitude   op (>=, <=, ==) value (Hostile < Wary < Neutral < Friendly): how the NPC treats the party
    reputation faction ("" = the NPC's own) op value (Hated ... Revered)
    quest      quest (a Quest id) state (none, active, ready, completed, failed, any)
    item       item count            gold  op amount (gp)
    time       times [Morning, Day, Dusk, Night]
    race race / class class / tool skill: someone in the party is one, or is proficient with it
    flag       flag scope (npc, game) value
    can        what: trade, work, hand_in, about, passage, revive, in_town, train (they teach a tool),
               restore (they mend gear, and the party has something damaged), drink (a barkeep: a round
               buys a rumor), library (they keep a library or temple archives), college (they teach courses)
Actions:
    give_item / take_item item count;  give_gold / take_gold amount (gp);  xp amount
    reputation faction ("" = the NPC's own) amount;  attitude value
    quest quest do (offer, complete);  flag flag scope value
    open what: trade, work, hand_in, about, passage, revive, train, restore, choose (a quest's decision),
               drink, library, college, bank, jobs, hire, settle
    fight;  end

Text can use {name} {fullname} {occupation} {workplace} {town} {realm} {player} {greeting} {time_greeting}
{small_talk} {rumor} {town_info} {god} {faction} {standing} {creatures} {roads} {quest}.

Who says what: every NPC talks through the shared "Everyday talk" tree (made for each world, editable in
the Library), with any trees for their occupation or for them alone added on, or replacing it.
The NPC's old greeting and small-talk lines are what Everyday talk says, so nothing written before is lost.
"""
from __future__ import annotations

import copy
import random
import re

VERSION = 8
SPECIAL_TO = ("end", "hub", "")
ATTITUDES = ["Hostile", "Wary", "Neutral", "Friendly"]
TIMES = ["Morning", "Day", "Dusk", "Night"]
QUEST_STATES = ["none", "active", "ready", "completed", "failed", "any"]
CAN = ["trade", "work", "hand_in", "about", "passage", "revive", "in_town", "train", "restore", "drink", "library",
       "college", "jobs", "bank", "fence", "bounty", "games", "arena", "land", "claim_due", "hire", "automatons", "settler", "cure",
       "guild", "brothel"]
OPEN = ["trade", "work", "hand_in", "about", "passage", "revive", "train", "restore", "choose", "drink", "library",
        "college", "bank", "jobs", "fence", "bounty", "games", "arena", "hire", "settle", "land", "claim_due",
        "automatons", "cure", "guild", "brothel"]
LATER: dict[str, str] = {}               # what = "comes in a later update" (none left)

CONDITION_TYPES = {
    "attitude": "Their attitude", "reputation": "Standing with a faction", "quest": "A quest is...",
    "item": "The party has an item", "gold": "The party's gold", "time": "Time of day",
    "race": "Someone in the party is a race", "class": "Someone in the party is a class",
    "tool": "Someone in the party is proficient", "flag": "A flag is set", "can": "They can...",
}
ACTION_TYPES = {
    "give_item": "Give the party an item", "take_item": "Take an item", "give_gold": "Give gold",
    "take_gold": "Take gold", "xp": "Give experience", "reputation": "Change standing",
    "attitude": "Change their attitude", "quest": "Offer or complete a quest", "flag": "Set a flag",
    "open": "Open a screen", "fight": "Start a fight", "end": "End the conversation",
}


# What each condition and action asks for (the editor builds its forms from these):
#   (key, kind, extra) with kind: choice (extra = options), multi (options), link (entity type),
#   number, text, bool
OPS = [">=", "<=", "=="]
CONDITION_FIELDS = {
    "attitude": [("op", "choice", OPS), ("value", "choice", ATTITUDES)],
    "reputation": [("faction", "link", "faction"), ("op", "choice", OPS), ("value", "choice", "@levels")],
    "quest": [("quest", "link", "quest"), ("state", "choice", QUEST_STATES)],
    "item": [("item", "link", "item"), ("count", "number", None)],
    "gold": [("op", "choice", [">=", "<="]), ("amount", "number", None)],
    "time": [("times", "multi", TIMES)],
    "race": [("race", "link", "race")],
    "class": [("class", "link", "class")],
    "tool": [("skill", "link", "skill")],
    "flag": [("flag", "text", None), ("scope", "choice", ["npc", "game"]), ("value", "bool", None)],
    "can": [("what", "choice", CAN)],
}
ACTION_FIELDS = {
    "give_item": [("item", "link", "item"), ("count", "number", None)],
    "take_item": [("item", "link", "item"), ("count", "number", None)],
    "give_gold": [("amount", "number", None)],
    "take_gold": [("amount", "number", None)],
    "xp": [("amount", "number", None)],
    "reputation": [("faction", "link", "faction"), ("amount", "number", None)],
    "attitude": [("value", "choice", ATTITUDES)],
    "quest": [("quest", "link", "quest"), ("do", "choice", ["offer", "complete"])],
    "flag": [("flag", "text", None), ("scope", "choice", ["npc", "game"]), ("value", "bool", None)],
    "open": [("what", "choice", OPEN)],
    "fight": [],
    "end": [],
}
DEFAULTS = {"op": ">=", "count": 1, "amount": 10, "scope": "npc", "value": True, "state": "active",
            "do": "offer", "what": "trade", "times": ["Night"]}


def blank(kind: str, type_name: str) -> dict:
    """A new condition or action of this type, filled with sensible values."""
    spec = (CONDITION_FIELDS if kind == "condition" else ACTION_FIELDS).get(type_name, [])
    out = {"type": type_name}
    for key, k, extra in spec:
        if key in DEFAULTS and not (key == "value" and k == "choice"):
            out[key] = copy.deepcopy(DEFAULTS[key])
        elif k == "choice":
            opts = extra if isinstance(extra, list) else ["Friendly"]
            out[key] = opts[0]
        elif k == "link":
            out[key] = ""
        elif k == "number":
            out[key] = 1
        elif k == "text":
            out[key] = ""
        elif k == "multi":
            out[key] = []
    if type_name == "reputation" and kind == "condition":
        out["value"] = "Friendly"
    if type_name == "attitude":
        if kind == "condition":
            out["op"], out["value"] = ">=", "Neutral"
        else:
            out["value"] = "Friendly"
    return out


def summary(world, item: dict, kind: str = "condition") -> str:
    """One line describing a condition or an action, for lists."""
    t = item.get("type") or ""

    def name(eid, fallback="their own"):
        if not eid:
            return fallback
        e = world.entities.get(eid) if world is not None else None
        return e.name if e is not None else eid
    neg = "NOT " if item.get("not") else ""
    if kind == "condition":
        if t == "attitude":
            return f"{neg}their attitude {item.get('op', '>=')} {item.get('value', '')}"
        if t == "reputation":
            return f"{neg}standing with {name(item.get('faction'), 'their faction')} {item.get('op', '>=')} " \
                   f"{item.get('value', '')}"
        if t == "quest":
            return f"{neg}quest {name(item.get('quest'), '?')} is {item.get('state', 'any')}"
        if t == "item":
            return f"{neg}the party has {item.get('count', 1)} x {name(item.get('item'), '?')}"
        if t == "gold":
            return f"{neg}gold {item.get('op', '>=')} {item.get('amount', 0)} gp"
        if t == "time":
            return f"{neg}it's {' or '.join(item.get('times') or []) or 'any time'}"
        if t in ("race", "class"):
            return f"{neg}someone is a {name(item.get(t), '?')}"
        if t == "tool":
            return f"{neg}someone is proficient in {name(item.get('skill'), '?')}"
        if t == "flag":
            return f"{neg}flag '{item.get('flag', '')}' ({item.get('scope', 'npc')}) is {item.get('value', True)}"
        if t == "can":
            return f"{neg}they can: {item.get('what', '')}"
        return t
    if t in ("give_item", "take_item"):
        return f"{'give' if t == 'give_item' else 'take'} {item.get('count', 1)} x {name(item.get('item'), '?')}"
    if t in ("give_gold", "take_gold"):
        return f"{'give' if t == 'give_gold' else 'take'} {item.get('amount', 0)} gp"
    if t == "xp":
        return f"give {item.get('amount', 0)} experience"
    if t == "reputation":
        return f"standing with {name(item.get('faction'), 'their faction')} {int(item.get('amount') or 0):+d}"
    if t == "attitude":
        return f"they become {item.get('value', '')}"
    if t == "quest":
        return f"{item.get('do', 'offer')} quest {name(item.get('quest'), '?')}"
    if t == "flag":
        return f"set flag '{item.get('flag', '')}' ({item.get('scope', 'npc')}) to {item.get('value', True)}"
    if t == "open":
        return f"open {item.get('what', '')}"
    return {"fight": "start a fight", "end": "end the conversation"}.get(t, t)


# ======================================================================
# The trees that ship with every world
# ======================================================================
def _opt(text, to="", **kw):
    o = {"text": text, "to": to}
    o.update(kw)
    return o


EVERYDAY = {
    "start": "start",
    "openers": [{"if": [{"type": "attitude", "op": "==", "value": "Hostile"}], "node": "hostile"}],
    "nodes": [
        {"id": "start", "say": ["{greeting}"], "options": [
            _opt("It's done: {quest}.", "", each="ready_quests", do=[{"type": "open", "what": "hand_in"}]),
            _opt("About {quest}...", "", each="active_quests", do=[{"type": "open", "what": "about"}]),
            _opt("Anything new?", "news"),
            _opt("Heard any rumors?", "rumors"),
            _opt("Tell me about {town}.", "town", **{"if": [{"type": "can", "what": "in_town"}], "hide": True}),
            _opt("Let's trade.", "", **{"if": [{"type": "can", "what": "trade"}], "hide": True,
                                        "do": [{"type": "open", "what": "trade"}]}),
            _opt("Any work going?", "", do=[{"type": "open", "what": "work"}]),
            _opt("Can you take us somewhere?", "", **{"if": [{"type": "can", "what": "passage"}], "hide": True,
                                                      "do": [{"type": "open", "what": "passage"}]}),
            _opt("Can you bring back our fallen?", "", **{"if": [{"type": "can", "what": "revive"}], "hide": True,
                                                          "do": [{"type": "open", "what": "revive"}]}),
            _opt("Goodbye.", "end"),
        ]},
        {"id": "news", "say": ["{small_talk}"], "options": []},
        {"id": "rumors", "say": ["{rumor}"], "options": []},
        {"id": "town", "say": ["{town_info}"], "options": []},
        {"id": "hostile", "say": ["Get lost.", "I've nothing to say to you.", "Walk away while you can."],
         "options": [_opt("Leave them be.", "end")]},
    ],
}


def _topic(text, node, say, **kw):
    return (_opt(text, node, **kw), {"id": node, "say": say, "options": []})


OCCUPATION_TREES = [
    ("Innkeeper's talk", ["Innkeeper"], [
        _topic("What's good to eat?", "food",
               ["Stew's been on since dawn. Bread's fresh, ale's cold. Can't ask for more.",
                "Whatever's in the pot. Nobody's died of it yet.",
                "Try the pie. My own recipe, and I'm not telling you what's in it."]),
        _topic("Heard anything from travellers?", "travellers",
               ["{rumor}", "Folk come through from {roads}. They talk, I listen. {rumor}"]),
    ]),
    ("Smith's talk", ["Blacksmith", "Armorer", "Weaponsmith"], [
        _topic("How's work at the forge?", "forge",
               ["Busy. Horseshoes, nails, the odd blade. Steel doesn't care who swings it.",
                "Hot. Always hot. Bring me good ore and I'll make you something worth carrying.",
                "Slow, if I'm honest. A few mended pots. I'd like a real commission."]),
        _topic("What makes a good blade?", "blade",
               ["Good iron, patience, and a smith who doesn't rush the quench.",
                "Balance. A heavy blade tires the arm; a light one breaks. Somewhere between lives the craft."]),
    ]),
    ("Priest's talk", ["Priest"], [
        _topic("Tell me about {god}.", "god",
               ["We keep the old rites here. {god} watches over this place, and over you, if you let them.",
                "{god} asks little: honesty, a kind hand, a coin for the poor box now and then."]),
        _topic("Will you bless us?", "bless",
               ["Go with grace. May the road be kind to you.",
                "Kneel, then. ...There. Mind you live up to it."]),
    ]),
    ("Guard's talk", ["Guard", "Mercenary"], [
        _topic("Any trouble lately?", "trouble",
               ["Some. {creatures} have been seen out past the fields. Keep to the roads after dark.",
                "Nothing we can't handle. Mostly drunks. Out in the wilds, though... {creatures}, they say."]),
        _topic("Who keeps the peace here?", "peace",
               ["We do, in the name of {realm}. Break the law in {town} and you'll answer to us.",
                "The watch, and the law of {realm}. Mind it."]),
    ]),
    ("Trader's talk", ["Merchant", "Caravan master"], [
        _topic("Where do your goods come from?", "goods",
               ["All over. The roads from here run to {roads}, and something good comes down every one of them.",
                "Here and there. Mostly there. Prices being what they are."]),
        _topic("Could you do me a better price?", "price",
               ["Ha. I like you. A little off, then, but don't tell anyone."],
               check={"skill": "Persuasion", "dc": 13, "fail": "no_deal"},
               do=[{"type": "flag", "flag": "good_customer", "scope": "npc", "value": True},
                   {"type": "attitude", "value": "Friendly"}],
               **{"if": [{"type": "flag", "flag": "good_customer", "scope": "npc", "value": True, "not": True}],
                  "hide": True}),
    ], [{"id": "no_deal", "say": ["Nice try. My prices are my prices."], "options": []}]),
    ("Farmer's talk", ["Farmer"], [
        _topic("How are the crops?", "crops",
               ["Could be worse. Could be better. That's farming.",
                "The rain came when we needed it, for once. Don't tell the sky I said so.",
                "Something's been at the fences at night. I keep the dog close."]),
    ]),
    ("Hunter's talk", ["Hunter"], [
        _topic("What's out in the wilds?", "wilds",
               ["{creatures}, mostly. Some worth the hunting, some best left alone.",
                "Tracks I don't like. {creatures}. Keep your eyes open out there."]),
    ]),
    ("Scholar's talk", ["Scholar", "Arcanist"], [
        _topic("What are you studying?", "study",
               ["The old histories of {realm}. Dull to most. Not to me.",
                "Nothing you'd find interesting. Unless you like ancient grammar. No? I thought not.",
                "Old ruins and the people who built them. {rumor}"]),
    ]),
    ("Noble's talk", ["Noble"], [
        _topic("Who rules here?", "rule",
               ["{realm} holds these lands, and my family holds its seat in {town}.",
                "We all answer to {realm}. Some of us more gracefully than others."]),
        _topic("Could you put in a good word for us?", "word",
               ["...Very well. I'll mention you favourably at court. Don't make a liar of me."],
               check={"skill": "Persuasion", "dc": 15, "fail": "no_word"},
               do=[{"type": "reputation", "faction": "", "amount": 5},
                   {"type": "flag", "flag": "good_word", "scope": "npc", "value": True}],
               **{"if": [{"type": "flag", "flag": "good_word", "scope": "npc", "value": True, "not": True},
                         {"type": "attitude", "op": ">=", "value": "Neutral"}], "hide": True}),
    ], [{"id": "no_word", "say": ["I don't know you well enough for that. Perhaps one day."], "options": []}]),
]


def occupation_tree(topics, extra_nodes=()) -> dict:
    """An add-on tree: its first node's answers become extra topics."""
    start = {"id": "start", "say": [], "options": [t[0] for t in topics]}
    return {"start": "start", "nodes": [start] + [t[1] for t in topics] + list(extra_nodes)}


TRAINING_TREE = {"start": "start", "nodes": [{"id": "start", "say": [], "options": [
    _opt("Could you teach us your trade?", "", **{"if": [{"type": "can", "what": "train"}], "hide": True,
                                                  "do": [{"type": "open", "what": "train"}]}),
    _opt("Can you mend our gear?", "", **{"if": [{"type": "can", "what": "restore"}], "hide": True,
                                          "do": [{"type": "open", "what": "restore"}]}),
]}]}


STORIES_TREE = {"start": "start", "nodes": [{"id": "start", "say": [], "options": [
    _opt("About {quest}: here's what I've decided.", "", each="choices", do=[{"type": "open", "what": "choose"}]),
    _opt("Buy a round, and listen. (2 sp)", "", **{"if": [{"type": "can", "what": "drink"}], "hide": True,
                                                   "do": [{"type": "open", "what": "drink"}]}),
    _opt("May we use your books?", "", **{"if": [{"type": "can", "what": "library"}], "hide": True,
                                          "do": [{"type": "open", "what": "library"}]}),
    _opt("What do you teach here?", "", **{"if": [{"type": "can", "what": "college"}], "hide": True,
                                           "do": [{"type": "open", "what": "college"}]}),
]}]}


MONEY_TREE = {"start": "start", "nodes": [{"id": "start", "say": [], "options": [
    _opt("Is there a shift I could work?", "", **{"if": [{"type": "can", "what": "jobs"}], "hide": True,
                                                  "do": [{"type": "open", "what": "jobs"}]}),
    _opt("I'd like to see to our account.", "", **{"if": [{"type": "can", "what": "bank"}], "hide": True,
                                                   "do": [{"type": "open", "what": "bank"}]}),
    _opt("I've a few things to sell. No questions asked?", "", **{"if": [{"type": "can", "what": "fence"}],
                                                                  "hide": True,
                                                                  "do": [{"type": "open", "what": "fence"}]}),
    _opt("Any work going for quick hands?", "", **{"if": [{"type": "can", "what": "guild"}], "hide": True,
                                                   "do": [{"type": "open", "what": "guild"}]}),
    _opt("Shall we go upstairs?", "", **{"if": [{"type": "can", "what": "brothel"}], "hide": True,
                                         "do": [{"type": "open", "what": "brothel"}]}),
    _opt("I'd settle what I owe the law.", "", **{"if": [{"type": "can", "what": "bounty"}], "hide": True,
                                                  "do": [{"type": "open", "what": "bounty"}]}),
]}]}


GAMES_TREE = {"start": "start", "nodes": [{"id": "start", "say": [], "options": [
    _opt("Is there a game going?", "", **{"if": [{"type": "can", "what": "games"}], "hide": True,
                                          "do": [{"type": "open", "what": "games"}]}),
    _opt("About the tournaments, and the bouts...", "", **{"if": [{"type": "can", "what": "arena"}], "hide": True,
                                                            "do": [{"type": "open", "what": "arena"}]}),
]}]}


LAND_TREE = {"start": "start", "nodes": [{"id": "start", "say": [], "options": [
    _opt("I'd like to buy land.", "", **{"if": [{"type": "can", "what": "land"}], "hide": True,
                                         "do": [{"type": "open", "what": "land"}]}),
    _opt("I've come to register a claim.", "", **{"if": [{"type": "can", "what": "claim_due"}], "hide": True,
                                                   "do": [{"type": "open", "what": "claim_due"}]}),
    _opt("Would you work for us? We pay a fair wage.", "", **{"if": [{"type": "can", "what": "hire"}], "hide": True,
                                                              "do": [{"type": "open", "what": "hire"}]}),
    _opt("We're looking to buy an automaton.", "", **{"if": [{"type": "can", "what": "automatons"}], "hide": True,
                                                      "do": [{"type": "open", "what": "automatons"}]}),
]}]}


SETTLER_TREE = {"start": "start", "nodes": [{"id": "start", "say": [], "options": [
    _opt("So, you'd like to settle here?", "", **{"if": [{"type": "can", "what": "settler"}], "hide": True,
                                                  "do": [{"type": "open", "what": "settle"}]}),
]}]}


CURE_TREE = {"start": "start", "nodes": [{"id": "start", "say": [], "options": [
    _opt("Can you lift what ails us?", "", **{"if": [{"type": "can", "what": "cure"}], "hide": True,
                                              "do": [{"type": "open", "what": "cure"}]}),
]}]}


def ensure(world) -> int:
    """Give a world its Everyday talk and occupation trees (once; edits and deletions are kept). Trees added
    in a later version are given to older worlds once too."""
    old = int(world.meta.get("dialogue_v") or 0)
    if old >= VERSION:
        return 0
    store = world.entities
    made = 0
    if old < 2 and store.find_by_name("dialogue", "Training and mending") is None:
        store.create("dialogue", "Training and mending", {"mode": "Add to everyday talk", "tree": copy.deepcopy(TRAINING_TREE)},
                     "Anyone who teaches a tool offers to train you; smiths, tailors, jewelers and the like offer to "
                     "mend damaged gear.", ["Dialogue"], save=False)
        made += 1
    if old < 3 and store.find_by_name("dialogue", "Stories, rumors and books") is None:
        store.create("dialogue", "Stories, rumors and books", {"mode": "Add to everyday talk",
                                                               "tree": copy.deepcopy(STORIES_TREE)},
                     "Decisions in a quest (game/chains.py), a round for the barkeep's rumors, libraries and "
                     "colleges.", ["Dialogue"], save=False)
        made += 1
    if old < 4 and store.find_by_name("dialogue", "Work, money and the law") is None:
        store.create("dialogue", "Work, money and the law", {"mode": "Add to everyday talk",
                                                             "tree": copy.deepcopy(MONEY_TREE)},
                     "Shifts of paid work (game/jobs.py), banking (game/bank.py), the fences of the thieves' guilds "
                     "and paying a bounty to the watch (game/law.py).", ["Dialogue"], save=False)
        made += 1
    if old < 5 and store.find_by_name("dialogue", "Games and the arena") is None:
        store.create("dialogue", "Games and the arena", {"mode": "Add to everyday talk",
                                                         "tree": copy.deepcopy(GAMES_TREE)},
                     "The tables of taverns and casinos (game/tablegames) and the arena's tournaments and bouts "
                     "(game/arena.py).", ["Dialogue"], save=False)
        made += 1
    if old < 6 and store.find_by_name("dialogue", "Land, hands and automatons") is None:
        store.create("dialogue", "Land, hands and automatons", {"mode": "Add to everyday talk",
                                                               "tree": copy.deepcopy(LAND_TREE)},
                     "Buying land from a town's land seller, paying for a staked claim, hiring hands for your "
                     "buildings and buying automatons (game/estate.py).", ["Dialogue"], save=False)
        made += 1
    if old < 7 and store.find_by_name("dialogue", "Settlers") is None:
        store.create("dialogue", "Settlers", {"mode": "Add to everyday talk", "tree": copy.deepcopy(SETTLER_TREE)},
                     "A newcomer to one of your own settlements asks to settle there (game/colony.py).",
                     ["Dialogue"], save=False)
        made += 1
    if old < 8 and store.find_by_name("dialogue", "Healing body and soul") is None:
        store.create("dialogue", "Healing body and soul", {"mode": "Add to everyday talk",
                                                          "tree": copy.deepcopy(CURE_TREE)},
                     "A temple's priests lift diseases and curses, for gold (game/survival.py).", ["Dialogue"],
                     save=False)
        made += 1
    if old >= 1:
        if made:
            store.save("dialogue")
        world.meta["dialogue_v"] = VERSION
        world.save_meta()
        return made
    if store.find_by_name("dialogue", "Everyday talk") is None:
        store.create("dialogue", "Everyday talk", {"mode": "Replace everyday talk", "tree": copy.deepcopy(EVERYDAY)},
                     "What everyone says: greetings, news, rumors, their town, trade, work and goodbye. "
                     "Edit it to change how every NPC talks.", ["Dialogue"], save=False)
        made += 1
    for entry in OCCUPATION_TREES:
        name, occs, topics = entry[0], entry[1], entry[2]
        extra = entry[3] if len(entry) > 3 else ()
        if store.find_by_name("dialogue", name) is None:
            store.create("dialogue", name, {"mode": "Add to everyday talk", "occupations": occs,
                                            "tree": occupation_tree(topics, extra)},
                         f"Extra topics for {', '.join(o.lower() for o in occs)}s.", ["Dialogue"], save=False)
            made += 1
    if made:
        store.save("dialogue")
    world.meta["dialogue_v"] = VERSION
    world.save_meta()
    return made


# ======================================================================
# Putting together what one NPC can say
# ======================================================================
def trees_for(world, npc, exclude: str = "") -> tuple[dict, list[dict]]:
    """(the tree they talk through, the add-on trees joined to it). `exclude`: a Dialogue left out."""
    store = world.entities
    occ = npc.fields.get("occupation") or ""
    own = store.get(npc.fields.get("talk") or "")
    ranked = []                                  # (specificity, priority, entity)
    for d in store.all("dialogue"):
        if d.id == exclude:
            continue
        f = d.fields
        if own is not None and d.id == own.id:
            spec = 3
        elif npc.id in (f.get("npcs") or []):
            spec = 3
        elif occ and occ in (f.get("occupations") or []):
            spec = 2
        elif not (f.get("occupations") or []) and not (f.get("npcs") or []) and d.id != (own.id if own else ""):
            spec = 1
        else:
            continue
        ranked.append((spec, float(f.get("priority") or 0), d))
    replace = [r for r in ranked if (r[2].fields.get("mode") or "") == "Replace everyday talk"]
    best = max(replace, key=lambda r: (r[0], r[1])) if replace else None
    base_e = best[2] if best is not None else None
    base = copy.deepcopy(base_e.fields.get("tree")) if base_e is not None else copy.deepcopy(EVERYDAY)
    if not base or not base.get("nodes"):
        base = copy.deepcopy(EVERYDAY)
    # a tree that replaces everyday talk for an occupation or one person isn't topped up with the
    # topics meant for wider groups (it's all they say), only with add-ons at least as particular
    floor = best[0] if best is not None else 0
    adds = [r for r in ranked if (r[2].fields.get("mode") or "") != "Replace everyday talk" and r[0] >= floor]
    adds.sort(key=lambda r: (r[0], -r[1], r[2].name))
    return base, [copy.deepcopy(r[2].fields.get("tree") or {}) for r in adds if (r[2].fields.get("tree") or {}).get("nodes")]


def merge(base: dict, adds: list[dict]) -> dict:
    """Join add-on trees onto a base: their nodes come in (renamed so they can't clash), and their first
    node's answers become topics on the base's first node, just before Goodbye."""
    tree = copy.deepcopy(base)
    nodes = tree.setdefault("nodes", [])
    start_id = tree.get("start") or (nodes[0]["id"] if nodes else "start")
    start = next((n for n in nodes if n["id"] == start_id), None)
    if start is None:
        return tree
    for k, add in enumerate(adds):
        prefix = f"+{k}~"
        a_start = add.get("start") or (add["nodes"][0]["id"] if add.get("nodes") else "")

        def ren(to):
            return to if to in SPECIAL_TO or not to else prefix + to
        for n in add.get("nodes") or []:
            if n.get("id") == a_start:
                continue
            m = copy.deepcopy(n)
            m["id"] = prefix + m["id"]
            for o in m.get("options") or []:
                o["to"] = ren(o.get("to") or "")
                if o.get("check"):
                    o["check"]["fail"] = ren(o["check"].get("fail") or "")
            nodes.append(m)
        first = next((n for n in add.get("nodes") or [] if n.get("id") == a_start), None)
        if first is None:
            continue
        new_opts = []
        for o in first.get("options") or []:
            o = copy.deepcopy(o)
            o["to"] = ren(o.get("to") or "")
            if o.get("check"):
                o["check"]["fail"] = ren(o["check"].get("fail") or "")
            new_opts.append(o)
        opts = start.setdefault("options", [])
        at = next((i for i in range(len(opts) - 1, -1, -1) if opts[i].get("to") == "end"), len(opts))
        opts[at:at] = new_opts
    return tree


def tree_for(world, npc) -> dict:
    base, adds = trees_for(world, npc)
    return merge(base, adds)


def problems(tree: dict) -> list[str]:
    """What's wrong with a tree (answers leading nowhere, a missing start)."""
    out = []
    ids = [n.get("id") for n in tree.get("nodes") or []]
    if not ids:
        return ["The conversation has no nodes."]
    if len(set(ids)) != len(ids):
        out.append("Two nodes have the same name.")
    start = tree.get("start") or ids[0]
    if start not in ids:
        out.append(f"The first node '{start}' doesn't exist.")
    for n in tree.get("nodes") or []:
        for o in n.get("options") or []:
            to = o.get("to") or ""
            if to not in SPECIAL_TO and to not in ids:
                out.append(f"'{o.get('text', '')}' (in {n['id']}) leads to '{to}', which doesn't exist.")
            fail = (o.get("check") or {}).get("fail") or ""
            if fail and fail not in SPECIAL_TO and fail not in ids:
                out.append(f"'{o.get('text', '')}' (in {n['id']}) fails to '{fail}', which doesn't exist.")
    for o in tree.get("openers") or []:
        if o.get("node") not in ids:
            out.append(f"An opener leads to '{o.get('node')}', which doesn't exist.")
    return out


# ======================================================================
# Talking
# ======================================================================
class Choice:
    """One answer as the party sees it."""

    def __init__(self, index: int, text: str, enabled: bool, why: str, opt: dict, extra: dict) -> None:
        self.index, self.text, self.enabled, self.why, self.opt, self.extra = index, text, enabled, why, opt, extra

    @property
    def check_text(self) -> str:
        c = self.opt.get("check") or {}
        return f"{c.get('skill', 'Check')} DC {int(c.get('dc') or 10)}" if c else ""

    def __repr__(self) -> str:
        return f"Choice({self.text!r}, enabled={self.enabled})"


class Result:
    """What came of picking an answer."""

    def __init__(self, said: str) -> None:
        self.said = said
        self.check: dict | None = None
        self.line = ""
        self.notes: list[str] = []
        self.open = ""
        self.open_arg: dict = {}
        self.quest: dict | None = None
        self.fight = False
        self.end = False


class Conversation:
    def __init__(self, world, state, npc, book=None, members=None, rng=None, bus=None, roller=None,
                 tree: dict | None = None) -> None:
        self.world, self.state, self.npc, self.book, self.bus = world, state, npc, book, bus
        self.members = members if members is not None else []
        self.rng = rng or random.Random()
        self.roller = roller                       # roller(skill, dc) -> {"success", "text"} for tests
        self.tree = tree if tree is not None else tree_for(world, npc)
        self.nodes = {n["id"]: n for n in self.tree.get("nodes") or []}
        self.hub = self.tree.get("start") if self.tree.get("start") in self.nodes else \
            next(iter(self.nodes), "start")
        self.node = self._opening()
        self._vars: dict = {}

    # ----- where things stand
    @property
    def data(self) -> dict:
        d = self.state.dialogue
        d.setdefault("flags", {})
        d.setdefault("npc", {})
        d.setdefault("lines", {})
        return d

    def _opening(self) -> str:
        for o in self.tree.get("openers") or []:
            if o.get("node") in self.nodes and all(self.met(c)[0] for c in o.get("if") or []):
                return o["node"]
        return self.hub

    def line(self) -> str:
        """What the NPC says at this node (a different way each time, when there's a choice)."""
        node = self.nodes.get(self.node) or {}
        says = [s for s in node.get("say") or [] if str(s).strip()]
        if not says:
            return ""
        mem = self.data["lines"].setdefault(self.npc.id, {})
        last = mem.get(self.node)
        pool = [i for i in range(len(says)) if i != last] or [0]
        i = self.rng.choice(pool)
        mem[self.node] = i
        self._vars = {}
        return self.fill(says[i])

    def options(self) -> list[Choice]:
        node = self.nodes.get(self.node) or {}
        opts = node.get("options") or []
        if not opts and self.node != self.hub:
            opts = (self.nodes.get(self.hub) or {}).get("options") or []
        out = []
        for k, o in enumerate(opts):
            for extra in self._expand(o):
                ok, why = True, ""
                for c in o.get("if") or []:
                    good, reason = self.met(c)
                    if not good:
                        ok, why = False, reason
                        break
                if not ok and o.get("hide"):
                    continue
                out.append(Choice(k, self.fill(o.get("text") or "...", extra), ok, why, o, extra))
        return out

    def _expand(self, o: dict) -> list[dict]:
        each = o.get("each") or ""
        if not each:
            return [{}]
        if self.book is None:
            return []
        if each == "ready_quests":
            qs = self.book.ready_for(self.npc)
        elif each == "active_quests":
            qs = [q for q in self.book.from_npc_active(self.npc) if q.get("status") == "active"]
        elif each == "choices":
            return [{"quest": q.get("title", ""), "quest_id": q.get("id", ""), "objective": i}
                    for q, i, _o in self.book.choices_with(self.npc.id)]
        else:
            return []
        return [{"quest": q.get("title", ""), "quest_id": q.get("id", "")} for q in qs]

    def choose(self, choice: Choice) -> Result:
        o = choice.opt
        r = Result(choice.text)
        if not choice.enabled:
            r.notes.append(choice.why or "You can't say that.")
            return r
        go = o.get("to") or ""
        chk = o.get("check") or {}
        passed = True
        if chk:
            got = self._roll(chk.get("skill") or "Persuasion", int(chk.get("dc") or 10))
            r.check = got
            passed = bool(got.get("success"))
            if not passed:
                go = chk.get("fail") or ""
        if passed:
            for a in o.get("do") or []:
                self.act(a, r, choice.extra)
        if r.end or go == "end":
            r.end = True
            self.state.save()
            return r
        if go == "hub":
            self.node = self.hub
        elif go and go in self.nodes:
            self.node = go
        elif not go:
            here = self.nodes.get(self.node) or {}
            if not (here.get("options") or []):          # a topic answered: back to the topics
                self.node = self.hub
            r.line = ""
            self.state.save()
            return r
        r.line = self.line()
        self.state.save()
        return r

    # ----- checks
    def _roll(self, skill: str, dc: int) -> dict:
        if self.roller is not None:
            return self.roller(skill, dc)
        from game import checks, condition
        opts = checks.options(self.world)
        want = skill.lower()
        opt = next((o for o in opts if o["id"] == skill or o["label"].lower() == want), None) or \
            next((o for o in opts if o["stat"] == "cha"), None)
        best = None
        for m in self.members:
            if m.get("dead") or opt is None:
                continue
            c = condition.combatant(self.world, m)
            b, _p = checks.bonus(self.world, m, c, opt)
            if best is None or b > best[0]:
                best = (b, m, c)
        if best is None:
            return {"success": False, "text": "Nobody can try that.", "total": 0, "dc": dc}
        _b, m, c = best
        return checks.roll(self.world, m, c, opt, dc, rng=self.rng, bus=self.bus, target=self.npc.name)

    # ----- conditions
    def met(self, c: dict) -> tuple[bool, str]:
        fn = _CONDITIONS.get(c.get("type") or "")
        if fn is None:
            return True, ""
        ok, why = fn(self, c)
        if c.get("not"):
            return (not ok), (_negated(c) if ok else "")
        return ok, why

    # ----- actions
    def act(self, a: dict, r: Result, extra: dict) -> None:
        fn = _ACTIONS.get(a.get("type") or "")
        if fn is not None:
            fn(self, a, r, extra)

    # ----- the words
    def fill(self, text: str, extra: dict | None = None) -> str:
        extra = extra or {}

        def sub(m):
            key = m.group(1)
            if key in extra:
                return str(extra[key])
            if key not in self._vars:
                fn = _VARS.get(key)
                if fn is None:
                    return m.group(0)
                try:
                    self._vars[key] = fn(self)
                except Exception:          # noqa: BLE001 - a missing word is never worth breaking a chat
                    self._vars[key] = ""
            return str(self._vars[key])
        out = re.sub(r"\{(\w+)\}", sub, str(text))
        return out[:1].upper() + out[1:] if out[:1].islower() and str(text).startswith("{") else out

    # ----- helpers
    def flag(self, name: str, scope: str = "npc"):
        if scope == "game":
            return self.data["flags"].get(name)
        return self.data["npc"].get(self.npc.id, {}).get(name)

    def set_flag(self, name: str, value, scope: str = "npc") -> None:
        if scope == "game":
            self.data["flags"][name] = value
        else:
            self.data["npc"].setdefault(self.npc.id, {})[name] = value

    def town(self):
        from game import places
        store = self.world.entities
        b = store.get(places.building_of(self.world, self.npc) or "")
        t = store.get(self.npc.fields.get("town") or "") or (store.get(b.fields.get("town") or "") if b else None)
        if t is None and self.state is not None:
            spot = places.current(self.world, self.state)
            t = spot.town
        return t


def _negated(c: dict) -> str:
    return "Not now." if c.get("type") == "flag" else "That's not possible here."


# ======================================================================
# Conditions
# ======================================================================
def _cmp(a, op: str, b) -> bool:
    return {">=": a >= b, "<=": a <= b, ">": a > b, "<": a < b, "!=": a != b}.get(op, a == b)


def _c_attitude(cv, c):
    from game import factions
    now = factions.attitude(cv.world, cv.state, cv.npc)
    want = c.get("value") or "Neutral"
    ok = _cmp(ATTITUDES.index(now) if now in ATTITUDES else 2, c.get("op") or "==",
              ATTITUDES.index(want) if want in ATTITUDES else 2)
    return ok, f"They're {now.lower()} towards you."


def _c_reputation(cv, c):
    from game import factions
    fid = c.get("faction") or ""
    f = factions.get(cv.world, fid) if fid else factions.primary(cv.world, cv.npc)
    if f is None:
        return True, ""
    lvl = factions.level(cv.world, cv.state, f.id)
    want = c.get("value") or "Neutral"
    names = factions.LEVEL_NAMES
    ok = _cmp(names.index(lvl), c.get("op") or ">=", names.index(want) if want in names else 3)
    return ok, f"Needs {want} standing with {f.name} (you're {lvl})."


def _c_quest(cv, c):
    qid = c.get("quest") or ""
    want = c.get("state") or "any"
    mine = [q for q in cv.state.quests if q.get("source") == qid or q.get("id") == qid]
    have = {q.get("status") for q in mine}
    if want == "none":
        ok = not mine
    elif want == "any":
        ok = bool(mine)
    else:
        ok = want in have
    e = cv.world.entities.get(qid)
    return ok, f"Needs the quest {e.name if e else qid} to be {want}."


def _c_item(cv, c):
    item = c.get("item") or ""
    n = max(1, int(c.get("count") or 1))
    e = cv.world.entities.get(item)
    return cv.state.count(item) >= n, f"Needs {n} x {e.name if e else item}."


def _c_gold(cv, c):
    amount = float(c.get("amount") or 0)
    return _cmp(cv.state.copper / 100.0, c.get("op") or ">=", amount), f"Needs {amount:g} gp."


def _c_time(cv, c):
    times = c.get("times") or ([c["value"]] if c.get("value") else [])
    return (cv.state.time_of_day in times) if times else True, f"Only at {', '.join(t.lower() for t in times)}."


def _members(cv):
    return [m for m in cv.members if not m.get("dead")]


def _c_race(cv, c):
    rid = c.get("race") or ""
    e = cv.world.entities.get(rid)
    return any(m.get("race") == rid for m in _members(cv)), f"Needs someone who is {e.name if e else rid}."


def _c_class(cv, c):
    from game import character as CH
    cid = c.get("class") or ""
    e = cv.world.entities.get(cid)
    for m in _members(cv):
        try:
            if any(k.id == cid for k, _lv, _s in CH.classes_of(cv.world, m)):
                return True, ""
        except Exception:          # noqa: BLE001
            continue
    return False, f"Needs a {e.name if e else cid}."


def _c_tool(cv, c):
    from game import checks
    sid = c.get("skill") or ""
    opt = next((o for o in checks.options(cv.world) if o["id"] == sid), None)
    if opt is None:
        return False, "Needs a skill nobody knows."
    return any(checks.proficient(cv.world, m, opt) for m in _members(cv)), f"Needs someone proficient in {opt['label']}."


def _c_flag(cv, c):
    cur = cv.flag(c.get("flag") or "", c.get("scope") or "npc")
    want = c.get("value", True)
    return (bool(cur) if want is True else cur == want), "Not yet."


def _c_can(cv, c):
    what = c.get("what") or ""
    from game import factions, places, trade
    if what == "trade":
        from game import destruction
        if destruction.is_ruin(cv.npc.fields.get("building") or "", cv.state):
            return False, "Their shop's in ruins: there's nothing to sell till it's rebuilt."
        return trade.is_merchant(cv.world, cv.npc) and trade.will_trade(cv.npc, cv.state), "They don't sell."
    if what == "work":
        return factions.attitude(cv.world, cv.state, cv.npc) != "Hostile", "They won't work with you."
    if what == "hand_in":
        return bool(cv.book and cv.book.ready_for(cv.npc)), "Nothing to hand in."
    if what == "about":
        return bool(cv.book and cv.book.from_npc_active(cv.npc)), "You're not on their job."
    if what == "passage":
        from game import passage
        return bool(passage.offers(cv.world, cv.npc)), "They don't carry passengers."
    if what == "revive":
        home = cv.world.entities.get(places.building_of(cv.world, cv.npc) or "")
        healer = (cv.npc.fields.get("occupation") or "") == "Priest" or \
            (home is not None and home.fields.get("kind") == "Temple")
        return healer and any(m.get("dead") for m in cv.members), "Nobody needs raising."
    if what == "in_town":
        return cv.town() is not None, "They're not from a town."
    if what == "drink":
        return (cv.npc.fields.get("occupation") or "") == "Innkeeper" and cv.town() is not None, "They don't serve."
    if what in ("library", "college"):
        from game import books
        b = cv.world.entities.get(places.building_of(cv.world, cv.npc) or "")
        if what == "library":
            return bool(books.library_kind(cv.world, b)), "They keep no books."
        return books.is_college(b), "They don't teach."
    if what == "train":
        from game import tools
        return bool(tools.trains(cv.world, cv.npc)), "They don't teach."
    if what == "jobs":
        from game import factions, jobs
        return bool(jobs.employer_kinds(cv.world, cv.npc)) and \
            factions.attitude(cv.world, cv.state, cv.npc) != "Hostile", "They've no work going."
    if what == "bank":
        from game import bank
        return bank.bank_of(cv.world, cv.npc) is not None, "They're no banker."
    if what == "fence":
        from game import law
        return law.is_fence(cv.world, cv.npc), "They're an honest trader."
    if what == "brothel":
        from game import brothel
        return brothel.is_worker(cv.world, cv.npc), "They're not that kind of company."
    if what == "guild":
        from game import thieves
        return thieves.guild_npc(cv.world, cv.npc) and thieves.guild_of(cv.world, thieves._npc_town(cv.world, cv.npc)) \
            is not None, "They don't know what you mean."
    if what == "games":
        from game import places, tablegames
        b = cv.world.entities.get(places.building_of(cv.world, cv.npc) or "")
        return bool(tablegames.games_at(cv.world, b)), "There's no game here."
    if what == "arena":
        from game import arena
        return arena.arena_of(cv.world, cv.npc) is not None, "They've nothing to do with the arena."
    if what == "land":
        from game import estate
        return estate.sells_land(cv.world, cv.npc), "They've no land to sell."
    if what == "claim_due":
        from game import estate
        return bool(estate.registering(cv.world, cv.state, cv.npc)), "There's no claim of yours to register here."
    if what == "hire":
        from game import estate
        ok, why = estate.can_hire(cv.world, cv.state, cv.npc)
        return ok and not cv.npc.fields.get("automaton"), why or "They won't work for you."
    if what == "automatons":
        from game import estate
        return estate.automaton_maker(cv.world, cv.npc), "They don't make automatons."
    if what == "cure":
        from game import survival
        home = cv.world.entities.get(places.building_of(cv.world, cv.npc) or "")
        healer = (cv.npc.fields.get("occupation") or "") == "Priest" or \
            (home is not None and home.fields.get("kind") == "Temple")
        return healer and survival.diseases_on(cv.world) and bool(survival.priest_offer(cv.state, cv.members)), \
            "Nobody here needs that."
    if what == "settler":
        return bool((cv.npc.fields.get("settler") or {}).get("pending")), "They've settled already."
    if what == "bounty":
        from game import law
        guard = (cv.npc.fields.get("occupation") or "") == "Guard"
        return guard and law.wanted_here(cv.world, cv.state)[1] > 0, "You're not wanted here."
    if what == "restore":
        from game import quality
        occ = cv.npc.fields.get("occupation") or ""
        if occ not in quality.MENDERS:
            return False, "They don't mend gear."
        held = quality.damaged_held(cv.world, cv.state, cv.members)
        return any(quality.mender_takes(occ, cv.world.entities.get(i)) for _w, i, _n in held), \
            "You've nothing they could mend."
    return True, ""


_CONDITIONS = {"attitude": _c_attitude, "reputation": _c_reputation, "quest": _c_quest, "item": _c_item,
               "gold": _c_gold, "time": _c_time, "race": _c_race, "class": _c_class, "tool": _c_tool,
               "flag": _c_flag, "can": _c_can}


# ======================================================================
# Actions
# ======================================================================
def _a_give_item(cv, a, r, extra):
    item, n = a.get("item") or "", max(1, int(a.get("count") or 1))
    e = cv.world.entities.get(item)
    if e is not None:
        cv.state.add_item(item, n, source=f"given by {cv.npc.name}")
        r.notes.append(f"You receive {e.name}" + (f" x{n}" if n > 1 else "") + ".")


def _a_take_item(cv, a, r, extra):
    item, n = a.get("item") or "", max(1, int(a.get("count") or 1))
    e = cv.world.entities.get(item)
    got = cv.state.remove_item(item, n, reason=f"given to {cv.npc.name}")
    if got and e is not None:
        r.notes.append(f"You hand over {e.name}" + (f" x{got}" if got > 1 else "") + ".")


def _a_give_gold(cv, a, r, extra):
    gp = float(a.get("amount") or 0)
    if gp > 0:
        cv.state.add_gold(gp, f"from {cv.npc.name}")
        r.notes.append(f"You receive {gp:g} gp.")


def _a_take_gold(cv, a, r, extra):
    gp = float(a.get("amount") or 0)
    take = min(cv.state.copper, int(round(gp * 100)))
    if take > 0:
        cv.state.add_copper(-take, f"paid to {cv.npc.name}")
        from game.state import money_text
        r.notes.append(f"You pay {money_text(take)}.")


def _a_xp(cv, a, r, extra):
    n = int(a.get("amount") or 0)
    if n > 0:
        cv.state.add_xp(n, f"talking with {cv.npc.name}")
        r.notes.append(f"{n} experience.")


def _a_reputation(cv, a, r, extra):
    from game import factions
    fid = a.get("faction") or ""
    f = factions.get(cv.world, fid) if fid else factions.primary(cv.world, cv.npc)
    if f is not None:
        factions.change(cv.world, cv.state, f.id, int(a.get("amount") or 0), f"after talking with {cv.npc.name}",
                        cv.bus)


def _a_attitude(cv, a, r, extra):
    v = a.get("value") or "Neutral"
    if v in ATTITUDES:
        cv.state.npc(cv.npc.id)["disposition"] = v


def _a_quest(cv, a, r, extra):
    from game import quests
    qid = a.get("quest") or ""
    e = cv.world.entities.get(qid)
    if e is None or e.type != "quest":
        return
    if (a.get("do") or "offer") == "complete":
        for q in cv.state.quests:
            if q.get("source") == qid and q.get("status") in ("active", "ready") and cv.book is not None:
                lines = cv.book.complete(q)
                if lines:
                    r.notes.append("You receive: " + ", ".join(lines))
                return
        return
    if any(q.get("source") == qid and q.get("status") in ("active", "ready", "completed") for q in cv.state.quests):
        return
    q = quests.from_entity(cv.world, e, cv.npc)
    q["id"] = "offer"
    r.quest = q


def _a_flag(cv, a, r, extra):
    cv.set_flag(a.get("flag") or "", a.get("value", True), a.get("scope") or "npc")


def _a_open(cv, a, r, extra):
    what = a.get("what") or ""
    if what in LATER:
        r.notes.append(f"{LATER[what]} comes in a later update.")
        return
    r.open = what
    r.open_arg = dict(extra)


def _a_fight(cv, a, r, extra):
    r.fight = True
    r.end = True


def _a_end(cv, a, r, extra):
    r.end = True


_ACTIONS = {"give_item": _a_give_item, "take_item": _a_take_item, "give_gold": _a_give_gold,
            "take_gold": _a_take_gold, "xp": _a_xp, "reputation": _a_reputation, "attitude": _a_attitude,
            "quest": _a_quest, "flag": _a_flag, "open": _a_open, "fight": _a_fight, "end": _a_end}


# ======================================================================
# The words that fill in
# ======================================================================
def _first(name: str) -> str:
    from game.quests import first_name
    return first_name(name)


def _v_greeting(cv):
    g = cv.npc.fields.get("greeting")
    if g:
        return g
    hello = {"Morning": "Morning.", "Day": "Hello there.", "Dusk": "Evening.", "Night": "It's late. What is it?"}
    return cv.rng.choice(["Hm? What is it?", "Can I help you?", hello.get(cv.state.time_of_day, "Hello.")])


def _v_time_greeting(cv):
    return {"Morning": "Good morning.", "Day": "Good day.", "Dusk": "Good evening.",
            "Night": "You're up late."}.get(cv.state.time_of_day, "Hello.")


def _v_workplace(cv):
    from game import places
    b = cv.world.entities.get(places.building_of(cv.world, cv.npc) or "")
    return b.name if b is not None else "around here"


def _v_town(cv):
    t = cv.town()
    return t.name if t is not None else "these parts"


def _the(name: str) -> str:
    return name if name[:4].lower() == "the " else f"the {name}"


def _v_realm(cv):
    from game import factions
    f = factions.realm_of_town(cv.world, cv.town())
    return _the(f.name) if f is not None else "nobody in particular"


def _v_player(cv):
    alive = _members(cv)
    return alive[0].get("name") if alive else "friend"


def _v_god(cv):
    from game import factions
    for f, _w in factions.npc_factions(cv.world, cv.npc):
        if (f.fields.get("kind") or "") == "Temple" and f.fields.get("god"):
            return f.fields["god"]
    return "the gods"


def _v_faction(cv):
    from game import factions
    f = factions.primary(cv.world, cv.npc)
    return f.name if f is not None else "folk around here"


def _v_standing(cv):
    from game import factions
    f = factions.primary(cv.world, cv.npc)
    return factions.level(cv.world, cv.state, f.id).lower() if f is not None else "neutral"


def _v_roads(cv):
    t = cv.town()
    if t is None:
        return "everywhere"
    names = []
    for r in t.fields.get("roads") or []:
        d = cv.world.entities.get(r.get("leads_to") or "")
        if d is not None and d.name not in names:
            names.append(d.name)
    if not names:
        return "nowhere much"
    return names[0] if len(names) == 1 else ", ".join(names[:-1][:3]) + " and " + names[-1]


def _v_creatures(cv):
    from game import encounters
    t = cv.town()
    biome = (t.fields.get("terrain") if t is not None else "") or "Plains"
    try:
        names = encounters.roamers(cv.world, biome, [1, 1, 1], 3)
    except Exception:          # noqa: BLE001
        names = []
    if not names:
        return "Wolves"
    from game.quests import plural
    words = [plural(n) for n in names[:2]]
    text = " and ".join(words)
    return text[:1].upper() + text[1:]


def _v_town_info(cv):
    from game import factions, geography as G
    t = cv.town()
    if t is None:
        return "Not much to tell. It's a quiet stretch of country."
    kind = G.settlement_kind(t).lower() or "town"
    pop = int(t.fields.get("population") or 0)
    bits = [f"{t.name}? It's a {kind}" + (f" of about {pop:,} souls" if pop >= 50 else "")]
    realm = factions.realm_of_town(cv.world, t)
    bits[0] += f", in {_the(realm.name)}." if realm is not None else "."
    from game import homeless
    rough = homeless.count(t)
    if rough >= 5:
        bits[0] += f" Maybe {rough:,} of them sleep rough."
    if t.description:
        first = t.description.split(". ")[0].rstrip(".")
        bits.append(first + ".")
    roads = _v_roads(cv)
    if roads not in ("everywhere", "nowhere much"):
        bits.append(f"The roads out of here go to {roads}.")
    return " ".join(bits)


def _v_rumor(cv):
    t = cv.town()
    store = cv.world.entities
    if t is not None and cv.state is not None and cv.rng.random() < _rumor_chance():
        from game import rumors
        r = rumors.hear(cv.world, cv.state, t, cv.rng, source=cv.npc.name)
        if r is not None:
            return r["text"]
    if t is not None:
        near = store.by_field("landmark", "near_town", t.id) + store.by_field("dungeon", "town", t.id)
        if near:
            e = cv.rng.choice(near)
            d = (e.fields.get("direction") or "").lower()
            where = f" to the {d}" if d else " not far from here"
            return cv.rng.choice([
                f"They say there's something at {e.name}{where}. Folk who go looking don't always come back.",
                f"Have you heard of {e.name}? It's{where}. Strange lights there some nights.",
                f"{e.name}, {where.strip()}. My cousin swears there's treasure in it. My cousin swears a lot.",
            ])
    lines = [ln for ln in cv.npc.fields.get("dialogue") or []
             if any(w in ln.lower() for w in ("ruin", "cave", "they say", "heard", "rumor", "road", "beast"))]
    if lines:
        return cv.rng.choice(lines)
    return cv.rng.choice(["Nothing worth repeating.", "I keep my ears shut and my mouth shut. Works for me.",
                          "Only the usual. Prices up, rain down."])


def _rumor_chance() -> float:
    from game import rumors
    return rumors.FREE_CHANCE


def sandbox(state):
    """A throwaway copy of the running game for trying a conversation out: nothing it does is kept."""
    s2 = copy.copy(state)
    for key in ("inventory", "npcs", "quests", "reputation", "dialogue", "party", "explore", "ticks"):
        setattr(s2, key, copy.deepcopy(getattr(state, key)))
    s2.save = lambda: None
    s2.bus = None
    return s2


def test_tree(world, entity_fields: dict, npc, entity_id: str = "") -> dict:
    """The tree an NPC would talk through if this Dialogue (being edited) applied to them."""
    tree = copy.deepcopy(entity_fields.get("tree") or {})
    if (entity_fields.get("mode") or "") == "Replace everyday talk":
        return tree
    base, adds = trees_for(world, npc, exclude=entity_id)
    return merge(base, adds + [tree])


def small_talk(world, state, npc, rng: random.Random) -> str:
    """What someone says when asked for news: their own lines, or something about the people they know."""
    from game import places, schedules
    lines = list(npc.fields.get("dialogue") or [])
    rels = schedules.relations(world, npc)
    known = [r for r in rels if not state.npc_dead(r[0].id)]
    lost = [r for r in rels if state.npc_dead(r[0].id)]
    if lost and rng.random() < 0.5:
        other, kind, _note = rng.choice(lost)
        return f"My {schedules.word_for(kind, other)} {_first(other.name)} is gone. I still can't believe it."
    if known and (not lines or rng.random() < 0.3):
        other, kind, note = rng.choice(known)
        where = world.entities.get(places.building_of(world, other))
        word = schedules.word_for(kind, other)
        bits = [f"My {word}, {_first(other.name)}" if kind not in ("Rival", "Enemy") else
                f"{_first(other.name)}, my {word}"]
        if where is not None:
            bits.append(f"can usually be found at {where.name}")
        text = " ".join(bits) + "." + (f" {note[:1].upper()}{note[1:]}." if note else "")
        if kind in ("Rival", "Enemy"):
            text += " Don't trust a word they say."
        return text
    if not lines:
        return rng.choice(["Not much to tell.", "Quiet, mostly.", "Same as ever."])
    mem = state.npc(npc.id)
    last = mem.get("line")
    choices = [i for i in range(len(lines)) if i != last] or [0]
    i = rng.choice(choices)
    mem["line"] = i
    return lines[i]


_VARS = {
    "name": lambda cv: _first(cv.npc.name), "fullname": lambda cv: cv.npc.name,
    "occupation": lambda cv: (cv.npc.fields.get("occupation") or "townsfolk").lower(),
    "workplace": _v_workplace, "town": _v_town, "realm": _v_realm, "player": _v_player,
    "greeting": _v_greeting, "time_greeting": _v_time_greeting,
    "small_talk": lambda cv: small_talk(cv.world, cv.state, cv.npc, cv.rng), "rumor": _v_rumor,
    "town_info": _v_town_info, "god": _v_god, "faction": _v_faction, "standing": _v_standing,
    "creatures": _v_creatures, "roads": _v_roads,
}
VARIABLES = sorted(list(_VARS) + ["quest"])


__all__ = ["Conversation", "Choice", "Result", "tree_for", "trees_for", "merge", "ensure", "problems",
           "blank", "summary", "sandbox", "test_tree", "CONDITION_FIELDS", "ACTION_FIELDS",
           "small_talk", "EVERYDAY", "CONDITION_TYPES", "ACTION_TYPES", "VARIABLES", "ATTITUDES", "TIMES",
           "QUEST_STATES", "CAN", "OPEN"]
