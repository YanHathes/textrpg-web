"""Fights where they happen: a battle map cut straight out of the walking map around the party.

Whatever is there comes along: the street and the houses beside it, the tavern's tables, the trees and
rocks of the open country, a dungeon room's pillars. The party stands where it stood and the enemy where
it was seen. Doors become open doorways (so nobody is shut out of the fight); anything that can't be
stood on (solid rock, the roof below an upper window) becomes wall.
"""
from __future__ import annotations

from game import area as A
from game.art import tiles as TL
from game.combat.battlemap import BattleMap, Prop

MIN_W, MIN_H = 18, 13
MAX_W, MAX_H = 30, 22
WATER_KIND = {"sea": "sea", "swamp": "swamp", "water": "water", "sky": "sky"}
ENV_FOR_BIOME = {"Forest": "forest", "Jungle": "forest", "Taiga": "forest", "Plains": "plains", "Savanna": "plains",
                 "Hills": "hills", "Mountains": "hills", "Desert": "desert", "Badlands": "desert", "Arctic": "arctic",
                 "Tundra": "arctic", "Swamp": "swamp", "Coast": "coast"}


def environment_here(ex) -> str:
    a = ex.area
    if a is None:
        return "plains"
    if a.kind == "dungeon":
        return "dungeon_room"
    if ex.inside_building():
        return "interior"
    loc = ex.zone_loc()
    if loc.startswith("street|") or a.kind == "town":
        return "street"
    if a.kind == "world":
        from game import worldmap as WM
        b = a.grid.biome_at(ex.x / WM.SQ, ex.y / WM.SQ)
        return ENV_FOR_BIOME.get(b, "plains")
    return "plains"


def battle_map_here(ex, foe_cells: list[tuple[int, int]] | None = None) -> BattleMap:
    """A battle map of the squares round the party (and round `foe_cells`, where the enemy stands)."""
    px, py = ex.x, ex.y
    foes = [c for c in (foe_cells or []) if abs(c[0] - px) < MAX_W - 4 and abs(c[1] - py) < MAX_H - 4]
    if not foes:
        foes = [_ahead(ex)]
    xs = [px] + [c[0] for c in foes]
    ys = [py] + [c[1] for c in foes]
    w = max(MIN_W, min(MAX_W, max(xs) - min(xs) + 9))
    h = max(MIN_H, min(MAX_H, max(ys) - min(ys) + 7))
    x0 = (min(xs) + max(xs)) // 2 - w // 2
    y0 = (min(ys) + max(ys)) // 2 - h // 2
    m = BattleMap(w, h, environment_here(ex))
    m.floor = [[("grass", 0)] * w for _ in range(h)]
    wall_default = "rock_wall" if ex.area.kind == "dungeon" else "stone_wall"
    props_seen = set()
    for y in range(h):
        for x in range(w):
            X, Y = x0 + x, y0 + y
            lv = ex.layer(X, Y)
            f = lv.floor_at(X, Y)
            v = (X * 7 + Y * 13) % 4
            if f in A.SOLID:
                m.floor[y][x] = ("dungeon" if ex.area.kind == "dungeon" else "dirt", v)
                m.walls[(x, y)] = "rock_wall" if f == A.EARTH else wall_default
                continue
            m.floor[y][x] = (f if f in TL.FLOORS else "dirt", v)
            c = (X, Y)
            d = lv.doors.get(c)
            if d is not None:
                if ex.secret_hidden(lv, c):
                    m.walls[(x, y)] = d.get("wall") or wall_default
                continue
            if c in lv.walls:
                m.walls[(x, y)] = lv.walls[c] if lv.walls[c] in TL.WALLS else wall_default
                continue
            if c in lv.water:
                m.water[(x, y)] = WATER_KIND.get(lv.water[c], "water")
                continue
            p = lv.prop_cells.get(c)
            if p is not None and id(p) not in props_seen:
                props_seen.add(id(p))
                cells = p.cells()
                if all(0 <= cx - x0 < w and 0 <= cy - y0 < h for cx, cy in cells) and p.id in TL.PROPS:
                    m.props.append(Prop(p.id, p.x - x0, p.y - y0, p.variant))
    m.invalidate()
    m.origin = (x0, y0)                              # (where it was cut from: game/combat/wreck.py writes back)
    m.underground = ex.area.kind == "dungeon"
    m.player_zone = _zone(m, px - x0, py - y0)
    enemy = []
    for fx, fy in foes:
        enemy += [c for c in _zone(m, fx - x0, fy - y0) if c not in enemy]
    m.enemy_zone = [c for c in enemy if c not in m.player_zone[:4]] or enemy
    return m


def _ahead(ex) -> tuple[int, int]:
    """Somewhere a few squares in front of the party (for a foe that came from nowhere in particular)."""
    from game.explore import DIRS
    dx, dy = DIRS.get(ex.facing, (0, 1))
    for d in (5, 4, 6, 3, 7):
        c = (ex.x + dx * d, ex.y + dy * d)
        if ex.walkable(*c):
            return c
    return (ex.x + 5, ex.y)


def _zone(m: BattleMap, cx: int, cy: int, want: int = 10) -> list[tuple[int, int]]:
    """Open squares nearest a point (a few to place a side on)."""
    out = []
    for r in range(0, max(m.w, m.h)):
        for y in range(cy - r, cy + r + 1):
            for x in range(cx - r, cx + r + 1):
                if max(abs(x - cx), abs(y - cy)) != r:
                    continue
                if m.walkable(x, y):
                    out.append((x, y))
        if len(out) >= want:
            break
    return out


__all__ = ["battle_map_here", "environment_here"]
