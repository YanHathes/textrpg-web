"""The handheld layout's controls as plain data (step 19; the screens are ui/handheld.py).

On a phone the game is laid out like a two-screen handheld: the map on top, and on the bottom six tabs
(Walk, Bag, Party, Quests, Map, Settings). The Walk tab has a D-pad and six commands, two across and three down:

    Interact   Check
    Action     Back
    Rest       Map

Interact, Check, Action and Rest open a *menu*: the choices two across, like picking a move, six to a page
(left and right turn the pages), with a line about whichever is picked and a button to do it. In a fight
the tabs become Action, Move, Bonus and End turn, and the battle's pages (ui/battle/controller.py) are shown
the same way.

Everything here is worked out without Qt, so it can be tested on its own.
"""
from __future__ import annotations

from dataclasses import dataclass, field

TABS = [("walk", "Walk"), ("bag", "Bag"), ("party", "Party"), ("quests", "Quests"), ("map", "Map"),
        ("settings", "Settings")]
COMMANDS = [("interact", "Interact"), ("check", "Check"), ("action", "Action"), ("back", "Back"),
            ("rest", "Rest"), ("map", "Map")]
COMBAT_TABS = [("action", "Action"), ("move", "Move"), ("bonus", "Bonus"), ("end", "End turn")]
PER_PAGE = 6


@dataclass
class Choice:
    label: str
    note: str = ""                 # the small line under it (a bonus, a cost, why it can't be done)
    desc: str = ""                 # shown when it's picked
    action: object = None          # what doing it means (handed back to whoever asked)
    enabled: bool = True
    group: str = ""                # for menus split into groups (Skills / Abilities / Tools)


@dataclass
class Menu:
    title: str
    context: str = ""
    choices: list[Choice] = field(default_factory=list)
    go: str = ""                   # the confirm button's word ("Check", "Rest"...); "" uses the choice's label
    groups: list[str] = field(default_factory=list)
    group: str = ""                # the group shown ("" = all)
    page: int = 0
    picked: int = 0                # index into visible()

    def visible(self) -> list[Choice]:
        return [c for c in self.choices if not self.group or c.group == self.group]

    def pages(self) -> int:
        return max(1, -(-len(self.visible()) // PER_PAGE))

    def shown(self) -> list[Choice]:
        """The choices on the page showing."""
        self.page = max(0, min(self.page, self.pages() - 1))
        return self.visible()[self.page * PER_PAGE:(self.page + 1) * PER_PAGE]

    def turn(self, d: int) -> None:
        """Another page (wrapping round); the first choice on it is picked."""
        n = self.pages()
        self.page = (self.page + d) % n
        self.picked = min(self.page * PER_PAGE, max(0, len(self.visible()) - 1))

    def pick(self, i_on_page: int) -> Choice | None:
        i = self.page * PER_PAGE + i_on_page
        if 0 <= i_on_page < PER_PAGE and 0 <= i < len(self.visible()):
            self.picked = i
            return self.visible()[i]
        return None

    def move(self, d: str) -> None:
        """The D-pad in a menu: up and down a row, left and right a column (off the edge turns the page)."""
        vis = self.visible()
        if not vis:
            return
        i = self.picked
        col, on = i % 2, i - self.page * PER_PAGE
        if d == "N" and on >= 2:
            i -= 2
        elif d == "S" and on + 2 < PER_PAGE and i + 2 < len(vis):
            i += 2
        elif d == "W":
            if col == 1:
                i -= 1
            else:
                self.turn(-1)
                return
        elif d == "E":
            if col == 0 and i + 1 < len(vis):
                i += 1
            else:
                self.turn(1)
                return
        self.picked = i

    def set_group(self, g: str) -> None:
        self.group = g if g in self.groups else ""
        self.page = self.picked = 0

    def current(self) -> Choice | None:
        vis = self.visible()
        if not vis:
            return None
        self.picked = max(0, min(self.picked, len(vis) - 1))
        if not (self.page * PER_PAGE <= self.picked < (self.page + 1) * PER_PAGE):
            self.page = self.picked // PER_PAGE
        return vis[self.picked]

    def go_label(self) -> str:
        c = self.current()
        if c is None or not c.enabled:
            return ""
        return self.go or c.label


# ---------------------------------------------------------------- checks
WHAT_FOR = {
    "acrobatics": "Keep your feet: tumble, balance, slip free.",
    "animal handling": "Calm a beast, steady a mount, read an animal's mood.",
    "arcana": "Recall lore of spells, magic items and the planes.",
    "athletics": "Climb, jump, swim, force something open.",
    "deception": "Lie convincingly, or keep a straight face.",
    "history": "Recall lore of kingdoms, wars and people of note.",
    "insight": "Read whoever you're facing: are they telling the truth?",
    "intimidation": "Get your way by threats and a hard stare.",
    "investigation": "Search carefully and work out what happened.",
    "medicine": "Tend the hurt and tell what ails someone.",
    "nature": "Recall lore of plants, beasts and the weather.",
    "perception": "Look and listen for anything out of place.",
    "performance": "Sing, play, act or tell a tale to a crowd.",
    "persuasion": "Win someone round with charm and good sense.",
    "religion": "Recall lore of gods, rites and holy symbols.",
    "sleight of hand": "Palm, plant or lift something unseen.",
    "stealth": "Move without being seen or heard.",
    "survival": "Track, hunt, find the way and the weather.",
    "thieves' tools": "Pick a lock or disarm a trap.",
}
FIRST = {
    "npc": ["insight", "persuasion", "deception", "intimidation", "performance"],
    "lock": ["thieves' tools", "athletics", "sleight of hand", "investigation"],
    "wild": ["survival", "perception", "nature", "animal handling"],
    "water": ["athletics", "survival", "nature"],
    "": ["perception", "investigation", "insight", "stealth"],
}
GROUP_OF = {"Skill": "Skills", "Ability": "Abilities", "Tool": "Tools"}


def check_menu(options: list[dict], bonuses: dict[str, int], facing: str = "", who: str = "") -> Menu:
    """Every check there is (game/checks.py options), those that fit what's in front first.
    bonuses: option id -> the roller's total bonus."""
    first = FIRST.get(facing, FIRST[""])
    rank = {name: i for i, name in enumerate(first)}
    kinds = {"Skill": 1, "Ability": 2, "Tool": 3}

    def order(o):
        name = str(o["label"]).lower()
        return (0, rank[name], "") if name in rank else (kinds.get(o["kind"], 4), 0, name)
    choices = []
    for o in sorted(options, key=order):
        b = int(bonuses.get(o["id"], 0))
        name = str(o["label"])
        sign = "+" if b >= 0 else "-"
        desc = WHAT_FOR.get(name.lower(), "") or f"Test your {o.get('short') or 'ability'}."
        choices.append(Choice(name, f"{sign}{abs(b)} · {o.get('short') or ''}".strip(" ·"),
                              f"{desc} Roll d20 {sign} {abs(b)}.", ("check", o["id"]),
                              group=GROUP_OF.get(o["kind"], "Skills")))
    groups = [g for g in ("Skills", "Abilities", "Tools") if any(c.group == g for c in choices)]
    ctx = {"npc": "Facing someone", "lock": "Facing a lock", "wild": "Out in the wild", "water": "By the water"}
    return Menu("Check", (f"{who} · " if who else "") + ctx.get(facing, "Roll, or play the minigame"),
                choices, go="Check", groups=groups if len(groups) > 1 else [])


# ---------------------------------------------------------------- actions and rest
def action_menu(where: str, outdoors: bool, in_dungeon: bool) -> Menu:
    """What the party can do where it stands. where: the place's name."""
    c = [
        Choice("Look around", "Where you are", "Hear again where you are and what's about.", ("look",)),
        Choice("Search", "For hidden things", "Search the squares about you for secret doors and anything hidden.",
               ("activity", "search")),
        Choice("Search the land", "Veins, rare herbs" if outdoors else "Out of doors only",
               "Search the land about for what's hidden: a rich vein, rare herbs. Takes a while.",
               ("activity", "search:land"), outdoors and not in_dungeon),
        Choice("Explore", "See what's out here" if outdoors else "Out in the wild only",
               "Wander the area: you may find something, or something may find you.",
               ("activity", "explore"), outdoors and not in_dungeon),
        Choice("Look for animals", "To tame" if outdoors else "Out in the wild only",
               "Look for beasts you could tame and keep.", ("activity", "tame:look"), outdoors and not in_dungeon),
        Choice("Cook a meal", "Food and a fire", "Cook a hot meal for everyone: better than trail rations.",
               ("activity", "survival:meal")),
        Choice("Refill water", "Skins and flasks", "Fill everyone's waterskins.",
               ("activity", "survival:refill" if not outdoors else "survival:refill-wild")),
    ]
    return Menu("Action", where, c)


def rest_menu(minute_of_day: int, long_rest: tuple | None, why_not: str = "", clock: str = "") -> Menu:
    """Waiting, and resting. long_rest: the action for a long rest here (camp, home, inn) or None."""
    c = [
        Choice("An hour", "Wait", "Let an hour pass here.", ("wait", 60)),
        Choice("Four hours", "Wait", "Let four hours pass here.", ("wait", 240)),
        Choice("Until evening", "Wait", "Wait here until the evening.", ("wait", "evening")),
        Choice("Until morning", "Wait", "Wait here until morning.", ("wait", "morning")),
        Choice("Short rest", "1 hour · Hit Dice", "An hour's rest: spend Hit Dice to heal, and get some stamina "
               "and mana back.", ("activity", "rest:short")),
        Choice("Long rest", "8 hours" if long_rest else (why_not or "Not here"),
               "Sleep eight hours: hit points, mana and spell slots come back." if long_rest else
               (why_not or "You need a bed, a room at an inn, or a camp out of town."), long_rest, bool(long_rest)),
    ]
    return Menu("Rest", clock, c)


def long_rest_here(spot) -> tuple[tuple | None, str]:
    """The long-rest action where the party stands (game/places.py Spot), or why not."""
    kind = getattr(spot, "kind", "")
    b = getattr(spot, "building", None)
    if kind in ("wild", "road"):
        return ("activity", "rest:camp"), ""
    if b is not None and b.fields.get("owner"):
        return ("activity", "rest:home"), ""
    if b is not None and float(b.fields.get("inn_price") or 0) > 0:
        return ("activity", "rest:inn"), ""
    if kind == "street":
        return None, "Find an inn, or go home"
    return None, "No bed here"


def prompt_menu(prompt) -> Menu:
    """A walking-map prompt (game/explore.py Prompt: title, text, [(label, action, enabled)]) as a menu."""
    c = []
    for row in prompt.options:
        label, action, enabled = row[0], row[1], (row[2] if len(row) > 2 else True)
        if action and action[0] == "none":
            continue                                   # "Never mind": that's what Back is for
        c.append(Choice(label, "", prompt.text or "", action, bool(enabled)))
    return Menu(prompt.title or "Interact", "", c)


# ---------------------------------------------------------------- fights
def combat_tabs(pages: dict, page: str, mine: bool) -> list[dict]:
    """The four tabs in a fight from the battle's pages: Action, Move, Bonus and End turn."""
    main = {"action": None, "move": None, "bonus": None, "end": None}
    for e in (pages.get("main") or {}).get("entries") or []:
        if e.get("page") == "actions":
            main["action"] = e
        elif e.get("page") == "bonus":
            main["bonus"] = e
        elif e.get("id") == "end":
            main["end"] = e
        elif (e.get("action") or (None,))[0] == "move":
            main["move"] = e
    on = tab_of(pages, page)
    out = []
    for key, label in COMBAT_TABS:
        e = main[key] or {}
        out.append({"id": key, "label": label, "sub": e.get("sub") or "", "entry": e,
                    "enabled": bool(mine and e and e.get("enabled", True)), "selected": on == key})
    return out


def tab_of(pages: dict, page: str) -> str:
    """Which of the four tabs a battle page belongs to."""
    seen = set()
    while page and page not in seen:
        seen.add(page)
        if page in ("actions", "target"):
            return "action"
        if page == "bonus":
            return "bonus"
        if page == "move":
            return "move"
        if page == "end":
            return "end"
        page = (pages.get(page) or {}).get("parent") or ""
    return "action"


def combat_menu(pages: dict, page: str, mine: bool) -> Menu:
    """A battle page's buttons as a menu (each choice's action is the page's own entry)."""
    p = pages.get(page) or {}
    c = [Choice(e.get("title") or "", e.get("sub") or "", e.get("tip") or "", e,
                bool(mine and e.get("enabled", True))) for e in p.get("entries") or []]
    title = p.get("title") or {"actions": "Action", "bonus": "Bonus action", "target": "Choose a target"}.get(page, "")
    return Menu(title, "", c)


__all__ = ["TABS", "COMMANDS", "COMBAT_TABS", "PER_PAGE", "Choice", "Menu", "check_menu", "action_menu",
           "rest_menu", "long_rest_here", "prompt_menu", "combat_tabs", "combat_menu", "tab_of"]


def pad_square(width: int, height: int) -> int:
    """The side of each of the D-pad's squares when it has width x height to fill (three across, three
    down), never so small it's hard to press nor bigger than it needs to be."""
    return max(34, min(96, min(width, height) // 3))
