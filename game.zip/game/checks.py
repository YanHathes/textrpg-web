"""Ability checks and skill checks (5e): d20 + the stat's modifier, plus the
proficiency bonus when the character is proficient in the skill.

A party member is proficient in a skill if it's ticked for them in Party, or
their race grants it.
"""
from __future__ import annotations

import random

from game import dice

DCS = [("No DC (just roll)", 0), ("Very easy (5)", 5), ("Easy (10)", 10), ("Medium (15)", 15), ("Hard (20)", 20),
       ("Very hard (25)", 25), ("Nearly impossible (30)", 30)]


def options(world) -> list[dict]:
    """Every check that can be made: the ability stats, then skills and tools."""
    out = []
    for s in world.entities.stats():
        key = s.fields.get("key")
        if key and (s.fields.get("group") or "Abilities") == "Abilities":
            out.append({"id": f"stat:{key}", "label": f"{s.name} check", "stat": key, "kind": "Ability",
                        "short": s.fields.get("abbreviation") or key.upper()})
    for sk in sorted(world.entities.all("skill"), key=lambda e: e.name):
        if (sk.fields.get("kind") or "Skill") not in ("Skill", "Tool"):
            continue
        stat = world.entities.get(sk.fields.get("stat"))
        key = stat.fields.get("key") if stat else ""
        out.append({"id": sk.id, "label": sk.name, "stat": key, "kind": sk.fields.get("kind") or "Skill",
                    "short": (stat.fields.get("abbreviation") if stat else "") or key.upper(),
                    "untrained": bool(sk.fields.get("untrained", True))})
    return out


def proficient(world, member: dict, option: dict) -> bool:
    if option["kind"] == "Ability":
        return False
    if option["id"] in (member.get("skills") or []):
        return True
    race = world.entities.get(member.get("race"))
    return bool(race) and option["id"] in (race.fields.get("skills") or [])


def bonus(world, member: dict, combatant, option: dict) -> tuple[int, bool]:
    """Ability modifier, plus proficiency (doubled with expertise), plus any 'Bonus to skill checks'
    effects (detail: a skill name, 'all', or 'untrained' for Jack of All Trades). A tool's proficiency also
    comes from training and from use: expertise doubles the bonus and mastery makes it four times
    (game/tools.py)."""
    from game import tools
    from game.combat import features as F
    prof = proficient(world, member, option)
    name = str(option.get("label") or "").lower()
    if not prof and name in (getattr(combatant, "skill_profs", set()) or set()):
        prof = True
    total = combatant.mods.get(option["stat"], 0)
    mult = 2 if name in (getattr(combatant, "expertise", set()) or set()) else 1
    if option.get("kind") == "Tool" or tools.uses(member, option["id"]):   # a skill used often (taming, step 10)
        _lvl, used = tools.level(world, member, option["id"])
        if used:
            prof = True
            mult = max(mult if proficient(world, member, option) else 1, used)
    if prof:
        total += combatant.prof * mult
    for f in getattr(combatant, "features", []) or []:
        if not f.is_on:
            continue
        for e in f.effects:
            if e.kind != "Bonus to skill checks":
                continue
            what = {w.strip().lower() for w in (e.detail or "all").split(",") if w.strip()}
            if "all" in what or name in what or ("untrained" in what and not prof):
                total += F.fixed(combatant, f, e.amount or "1")
    return total, prof


def roll(world, member: dict, combatant, option: dict, dc: int = 0, mode: str = "normal",
         rng: random.Random | None = None, bus=None, target: str = "", context: str = "", extra: int = 0,
         about: str = "") -> dict:
    """Roll it, report it in the log and on the event bus, and return the result. extra: a bonus on top
    (proficiency with some work, from game/tools.py, when gathering)."""
    rng = rng or random.Random()
    b, prof = bonus(world, member, combatant, option)
    b += int(extra or 0)
    try:                                           # what the party has read about it, or about where it is
        from game import books
        b += books.bonus(world, getattr(world, "_state_for_places", None), str(option.get("label") or ""), about)
    except Exception:  # noqa: BLE001
        pass
    if option["kind"] == "Tool" and not prof and not option.get("untrained", True):
        text = f"{combatant.name} doesn't know how to use {option['label']}."
        if bus is not None:
            bus.emit("log", kind="system", text=text)
        return {"total": None, "success": False, "text": text}
    d = None
    if minigame is not None:                       # Settings > Checks: played as a minigame instead
        try:
            d = minigame(world, member, combatant, option, dc, b, mode, context)
        except Exception:  # noqa: BLE001 - a game that goes wrong falls back on the dice
            d = None
    if d is None:
        d, detail = dice.d20(rng, mode)
    else:
        detail = f"(played: {d})"
    total = d + b
    ok = (total >= dc) if dc else None
    sign = "+" if b >= 0 else "-"
    what = option["label"] if option["kind"] == "Ability" else f"{option['label']} check"
    vs = f" vs DC {dc}  ·  {'Success' if ok else 'Failure'}" if dc else ""
    against = f" ({target})" if target else ""
    text = f"{combatant.name}: {what}{against}: {detail} {sign} {abs(b)} = {total}{vs}"
    if d == 20:
        text += "  ·  natural 20!"
    elif d == 1:
        text += "  ·  natural 1"
    if bus is not None:
        bus.emit("log", kind="roll", text=text)
        bus.emit("check.rolled", member=member.get("id"), check=option["id"], label=option["label"], roll=d,
                 total=total, dc=dc, success=ok, target=target)
    if option["kind"] == "Tool" and ok and member.get("id"):
        from game import tools                   # a successful use of a tool counts towards proficiency
        tools.record_use(world, member, option["id"], 1, bus)
    return {"roll": d, "bonus": b, "total": total, "dc": dc, "success": ok, "proficient": prof, "text": text}


def save(world, member: dict, combatant, stat: str, dc: int, mode: str = "normal", rng: random.Random | None = None,
         bus=None) -> dict:
    """A saving throw outside a fight (fights roll their own): d20 + the stat's modifier, + proficiency if
    the character is proficient in that save. A minigame when Settings > Checks says so."""
    rng = rng or random.Random()
    b = combatant.mod(stat) + (combatant.prof if stat in (combatant.saves or set()) else 0)
    option = {"id": f"save:{stat}", "label": f"{stat.upper()} save", "stat": stat, "kind": "Save"}
    d = None
    if minigame is not None:
        try:
            d = minigame(world, member, combatant, option, dc, b, mode, "")
        except Exception:  # noqa: BLE001
            d = None
    if d is None:
        d, _detail = dice.d20(rng, mode)
    total = d + b
    ok = total >= dc
    text = f"{combatant.name}: {stat.upper()} save: {total} vs DC {dc}  ·  {'Success' if ok else 'Failure'}"
    if bus is not None:
        bus.emit("log", kind="roll", text=text)
    return {"roll": d, "bonus": b, "total": total, "dc": dc, "success": ok, "text": text}


# The minigame player, set by the game's window (ui/minigames): (world, member, combatant, option, dc, bonus,
# mode, context) -> the natural roll it stands for, or None to roll the dice after all. Fights never use it.
minigame = None
