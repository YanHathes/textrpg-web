"""A fight from start to finish, around the battle itself (game/combat/engine.py): who fights (the live party,
its pets and mounts, any allies; the enemies), the pack's potions shared out, and afterwards what's settled
(hit points, spells and uses kept; the dead; potions and ammunition used; diseases; townsfolk who were fought),
the rewards, and beasts to skin. No Qt here: the app's main window and the browser version (web/fight.py) both
go through it.

    f = Fight.prepare(world, state, members, enemy_rows, environment, size, ...)   # None if it can't be fought
    ... the battle is played (f.battle, f.sprites) ...
    f.settle(outcome, book, bus)          # what the fight changed, kept
    f.skinnable() / f.skin(members, rng, bus)
    f.reward_lines() / f.give_rewards(bus)
"""
from __future__ import annotations

import random


class Fight:
    def __init__(self, world, state, battle, sprites: dict, members: list[dict], arena: bool = False) -> None:
        self.world, self.state = world, state
        self.battle, self.sprites = battle, sprites
        self.members = members                 # the party records fighting (the live ones)
        self.arena = arena                     # a test fight: nothing is kept
        self.given: dict[str, int] = {}        # pack consumables handed out for this fight
        self.own: dict[str, dict] = {}         # member id -> their own consumables at the start
        self.start_items: dict[str, dict] = {}  # combatant id -> consumables held at the start
        self.seen: list = []                   # who saw it (game/law.py), for a fight with townsfolk
        self.to_skin: list = []
        self.rewards: dict = {}

    # ==================================================================
    # Setting up
    # ==================================================================
    @classmethod
    def prepare(cls, world, state, members: list[dict], enemy_rows: list, environment: str, size,
                style: str = "", arena: bool = False, time: str = "Day", bmap=None, allies: list | None = None,
                rng: random.Random | None = None, bus=None) -> "Fight | str":
        """The fight, ready to start; or a sentence saying why it can't be (no one on a side, no map)."""
        from game import condition
        from game.battlesetup import build_enemies, build_party, make_battle
        rng = rng or random.Random()
        members = [m for m in members if not m.get("dead")]
        party = build_party(world, members)
        own, start_items, given = {}, {}, {}
        if not arena and state is not None:
            for (c, _art), m in zip(party, members):
                condition.apply(state, m, c)
                own[m["id"]] = {it.item_id: it.count for it in c.items}
            given = hand_out_consumables(world, state, [c for c, _ in party])
            for c, _art in party:
                start_items[c.id] = {}
                for it in c.items:
                    start_items[c.id][it.item_id] = start_items[c.id].get(it.item_id, 0) + it.count
            party += animals_in_battle(world, state, party, environment, rng, bus)
        for row in allies or []:                         # the town guard, fighting beside you (game/townevents.py)
            from game.combat import builders as CB
            from game.combat.engine import ALLY
            e = world.entities.get(row.get("id") or "")
            if e is None:
                continue
            for _k in range(max(1, int(row.get("count") or 1))):
                c = CB.from_npc(world, e, rng, ALLY) if e.type == "npc" else \
                    CB.from_enemy(world, e, rng, ALLY, name=row.get("name") or e.name)
                try:
                    art = world.sprites.render_entity(e, world.entities)
                except Exception:  # noqa: BLE001 - a plain token
                    art = None
                party.append((c, art))
        enemies = build_enemies(world, enemy_rows, rng)
        if not party or not enemies:
            return "A fight needs at least one party member and one enemy."
        try:
            battle, sprites = make_battle(world, party, enemies, environment, size, style=style, time=time,
                                          bmap=bmap)
        except RuntimeError as exc:
            return str(exc)
        f = cls(world, state, battle, sprites, members, arena)
        f.given, f.own, f.start_items = given, own, start_items
        if state is not None and not arena:
            from game import jail
            battle.antimagic = jail.antimagic(world, state)      # in a jail, nobody casts (game/jail.py)
        if state is not None and not arena and bus is not None:   # what the party's reading says about them
            try:
                from game import books
                ids = [r.get("id") or r.get("enemy") for r in enemy_rows if isinstance(r, dict)]
                for line in books.bestiary_lines(world, state, [i for i in ids if i]):
                    bus.emit("log", kind="system", text=line)
            except Exception:  # noqa: BLE001 - nothing read, nothing said
                pass
        return f

    # ==================================================================
    # Afterwards
    # ==================================================================
    def settle(self, outcome: str, book=None, bus=None, rng: random.Random | None = None) -> None:
        """Remember HP, Mana, slots and uses; who died; ammunition fired (half is found again); potions used
        (from the character's own bag first, then the party pack); and what happened to any townsfolk who
        were fought."""
        from game import condition
        from game import inventory as INV
        b, world, state = self.battle, self.world, self.state
        if b is None or state is None or self.arena:
            return
        say = (lambda kind, text: bus.emit("log", kind=kind, text=text)) if bus is not None else (lambda k, t: None)
        from_pack: dict[str, int] = {}
        for c in b.combatants:
            if c.team == "player" and c.dead and str(c.entity_id).startswith("pet:"):
                from game import animals                  # a pet killed in the fight
                text = animals.died(world, state, c.entity_id.split(":", 1)[1])
                if text:
                    say("damage", text)
        for c in b.combatants:
            if c.team != "player":
                continue
            mid = c.entity_id.split(":", 1)[-1]
            m = next((x for x in self.members if x.get("id") == mid), None)
            if m is None:
                continue
            if c.dead:
                m["dead"] = True
                m["died_at"] = state.minutes
                if bus is not None:
                    bus.emit("party.died", member=mid)
            condition.store(state, m, c, save=False)
            left: dict[str, int] = {}
            for it in c.items:
                left[it.item_id] = left.get(it.item_id, 0) + it.count
            own = self.own.get(mid, {})
            for item_id, start in self.start_items.get(c.id, {}).items():
                used = max(0, start - left.get(item_id, 0))
                mine = min(used, own.get(item_id, 0))
                if mine:
                    INV.remove(m, item_id, mine)
                if used - mine > 0:
                    from_pack[item_id] = from_pack.get(item_id, 0) + used - mine
            for name in INV.settle_used_up(world, state, m):
                say("system", f"{c.name}'s {name} is used up.")
            lost = INV.settle_ammo(world, m, c.ammo_used)
            for kind, fired in c.ammo_used.items():
                if fired:
                    say("system", f"{c.name} fired {fired} {kind.lower()}{'s' if fired != 1 else ''} and recovers "
                                  f"{fired - lost.get(kind, 0)}.")
        for item_id, used in from_pack.items():
            state.remove_item(item_id, min(used, self.given.get(item_id, used)), reason="used in battle")
        try:                                          # bites that carry disease or a curse (game/survival.py)
            from game import survival
            if survival.diseases_on(world):
                hurt = []
                for c in b.combatants:
                    if c.team == "player" and not c.dead and c.hp < c.max_hp:
                        m = next((x for x in self.members if x.get("id") == c.entity_id.split(":", 1)[-1]), None)
                        if m is not None:
                            hurt.append(m)
                foes = [c.name for c in b.combatants if c.team not in ("player", "ally")]
                survival.after_battle(world, state, hurt, foes, rng or random.Random())
        except Exception:  # noqa: BLE001 - no disease rather than no fight
            pass
        for c in b.combatants:                        # townsfolk who were fought: the dead stay dead
            npc = world.entities.get(c.entity_id) if c.team not in ("player", "ally") else None
            if npc is None or npc.type != "npc":
                continue
            from game import law, schedules
            mem = state.npc(npc.id)
            if not c.alive:
                mem["dead"] = True
                if bus is not None:
                    bus.emit("npc.died", npc=npc.id)
                if book is not None:
                    book.giver_died(npc.id)
                schedules.react_to_harm(world, state, npc, True, bus)
                law.harmed(world, state, npc, True, list(self.seen), bus)
            else:
                mem["disposition"] = "Hostile"
                schedules.react_to_harm(world, state, npc, False, bus)
                law.harmed(world, state, npc, False, list(self.seen), bus)
        self.seen = []

    def outcome_rewards(self, outcome: str) -> dict:
        self.rewards = self.battle.rewards() if outcome == "victory" else {"xp": 0, "gold": 0, "items": {}}
        return self.rewards

    def reward_lines(self) -> list[str]:
        from game.battlepages import describe_rewards
        return describe_rewards(self.world, self.rewards or {})

    def give_rewards(self, bus=None) -> None:
        lines = self.reward_lines()
        if lines and not self.arena and self.state is not None:
            self.state.give_rewards(self.rewards, source="battle")
            if bus is not None:
                bus.emit("log", kind="loot", text="Rewards: " + ", ".join(lines))

    def fallen(self) -> list[str]:
        return [c.name for c in self.battle.combatants if c.team == "player" and c.dead]

    # ---- beasts to skin
    def skinnable(self) -> int:
        from game import gathering as GA
        self.to_skin = []
        for c in self.battle.combatants:
            if c.team == "player" or not c.dead:
                continue
            e = self.world.entities.get(c.entity_id or "")
            if e is not None and e.type == "enemy" and GA.skinnable(self.world, e):
                self.to_skin.append(e)
        return len(self.to_skin)

    def skin(self, members: list[dict], rng=None, bus=None) -> dict:
        from game import gathering as GA
        if not self.to_skin or self.state is None:
            return {}
        r = GA.skin(self.world, self.state, members, self.to_skin, rng or random.Random(), bus)
        self.to_skin = []
        if bus is not None:
            bus.emit("log", kind="loot" if r.get("ok") else "narration", text=r["text"])
        return r


def hand_out_consumables(world, state, fighters: list) -> dict:
    """Share the pack's potions (and other usable things) among the party for this fight. Returns what was
    handed out: item id -> how many."""
    from game.combat.builders import _timing
    from game.combat.engine import Consumable
    given: dict[str, int] = {}
    if not fighters:
        return given
    i = 0
    for item_id, n in sorted(state.inventory.items()):
        item = world.entities.get(item_id)
        if item is None or item.fields.get("category") != "Consumable":
            continue
        for _ in range(n):
            c = fighters[i % len(fighters)]
            i += 1
            have = next((x for x in c.items if x.item_id == item_id), None)
            if have:
                have.count += 1
            else:
                c.items.append(Consumable(item_id, item.name, item.fields.get("use_effect") or "Heal",
                                          item.fields.get("use_dice") or "1d4", 1, timing=_timing(item)))
        given[item_id] = n
    return given


def animals_in_battle(world, state, party: list, environment: str, rng, bus=None) -> list:
    """The party's pets fight beside it, and riders fight at their mounts' speed out in the open (basic SRD
    mounted combat: a controlled mount moves as its rider wills). Returns the pets to add."""
    from game import animals
    from game.combat import builders as CB
    from game.combat.engine import PLAYER
    out = []
    if not animals.owned(state):
        return out
    try:
        if str(environment or "").title() not in ("Dungeon", "Cave", "Interior", "Urban", "Underwater"):
            for c, _art in party:
                mt = animals.mount_of(world, state, c.entity_id.split(":", 1)[-1])
                if mt is None:
                    continue
                sq = max(1, animals.speed_ft(world, mt) // 5)
                if sq > c.speed:
                    c.speed = c.base_speed = sq
                if bus is not None:
                    bus.emit("log", kind="system", text=f"{c.name} fights from the saddle of {mt['name']}.")
        for v in animals.companions(world, state):
            e = world.entities.get(v["enemy"])
            c = CB.from_enemy(world, e, rng, PLAYER, name=v["name"])
            c.entity_id = f"pet:{v['id']}"
            try:
                art = world.sprites.render_entity(e, world.entities)
            except Exception:  # noqa: BLE001
                art = None
            out.append((c, art))
    except Exception:  # noqa: BLE001 - a fight goes ahead without them rather than not at all
        return out
    return out


__all__ = ["Fight", "hand_out_consumables", "animals_in_battle"]
