"""Craps. Two dice, a shooter, and these bets:

    Pass line      on the come-out roll 7 or 11 wins, 2, 3 or 12 loses; anything else is the point, and then
                   the point again wins before a 7 (which loses). Pays 1 to 1.
    Don't pass     the other way round: 2 or 3 wins, 7 or 11 loses, 12 is a push (barred); then a 7 before the
                   point wins. Pays 1 to 1.
    Come           made while a point is on: the next roll is its own come-out (7 or 11 wins, 2, 3 or 12 loses,
                   anything else becomes its point, won when it rolls again before a 7). Pays 1 to 1.
    Odds           behind a pass line bet once there's a point, or behind a come bet once it has one: paid at
                   true odds (2 to 1 on 4 and 10, 3 to 2 on 5 and 9, 6 to 5 on 6 and 8), so no edge for the house.
Odds bets are capped at three times the bet they back.

Cheat (Sleight of Hand): slide the dice: the next roll comes up what the pass line wants (a 7 on the come-out,
the point after).
"""
from __future__ import annotations

from game.tablegames.base import ACCENT, DIM, FELT, INK, Table, chip_prims, money

ODDS = {4: (2, 1), 10: (2, 1), 5: (3, 2), 9: (3, 2), 6: (6, 5), 8: (6, 5)}
POINTS = (4, 5, 6, 8, 9, 10)
ODDS_X = 3


def odds_win(point: int, amount: int) -> int:
    """Winnings (not the stake) on an odds bet at true odds."""
    a, b = ODDS[point]
    return amount * a // b


class Craps(Table):
    id, title = "craps", "Craps"
    help = "Bet the pass line (or don't pass) and roll. Come bets and odds once there's a point."
    uses = "dice"
    cheat_label = "Slide the dice"
    realtime = True

    def setup(self) -> None:
        self.point = None
        self.bets = {"pass": 0, "dont": 0, "come": 0, "pass_odds": 0}
        self.come: dict[int, list[int]] = {}       # point -> [bet, odds]
        self.dice = (0, 0)
        self.rolling = 0.0
        self.forced = None
        self.say("Bet the pass line and roll.")

    def betting(self) -> bool:
        return self.rolling <= 0

    def _place(self, key: str) -> None:
        if self.rolling > 0:
            return
        if key == "pass" and self.point is not None:
            return self.say("Pass bets go down on the come-out roll.")
        if key == "dont" and self.point is not None:
            return self.say("Don't pass bets go down on the come-out roll.")
        if key == "come" and self.point is None:
            return self.say("Come bets are made once there's a point.")
        if key == "pass_odds":
            if self.point is None or not self.bets["pass"]:
                return self.say("Odds go behind a pass bet once there's a point.")
            if self.bets["pass_odds"] + self.stake > self.bets["pass"] * ODDS_X:
                return self.say(f"Odds are capped at {ODDS_X} times the pass bet.")
        if not self.take(self.stake):
            return self.say("You haven't the chips.")
        self.bets[key] += self.stake

    def _come_odds(self) -> None:
        if self.rolling > 0 or not self.come:
            return
        n = max(self.come, key=lambda k: self.come[k][0])
        bet, odds = self.come[n]
        if odds + self.stake > bet * ODDS_X:
            return self.say(f"Odds are capped at {ODDS_X} times the come bet.")
        if self.take(self.stake):
            self.come[n][1] += self.stake

    def on(self, action: str) -> None:
        if action in ("pass", "dont", "come", "pass_odds"):
            self._place(action)
        elif action == "come_odds":
            self._come_odds()
        elif action == "roll" and self.rolling <= 0:
            if not (self.bets["pass"] or self.bets["dont"] or self.bets["come"] or self.come):
                return self.say("Put a bet down first.")
            if not self.house_can_cover(self._worst()):
                return self.say("The house can't cover those bets.")
            self.rolling = 1.0
        elif action == "roll_now":                     # tests and the instant setting: no animation
            self.roll()

    def _worst(self) -> int:
        out = self.bets["pass"] + self.bets["dont"] + self.bets["come"]
        if self.point:
            out += odds_win(self.point, self.bets["pass_odds"])
        out += sum(b + odds_win(n, o) for n, (b, o) in self.come.items())
        return out

    def update(self, dt: float) -> None:
        super().update(dt)
        if self.rolling > 0:
            self.rolling -= dt
            self.dice = (self.rng.randint(1, 6), self.rng.randint(1, 6))
            if self.rolling <= 0:
                self.roll()

    def roll(self, dice: tuple[int, int] | None = None) -> int:
        """Throw the dice (or these) and settle what that decides. Returns the total."""
        if dice is None and self.forced is not None:
            dice, self.forced = self.forced, None
        d1, d2 = dice or (self.rng.randint(1, 6), self.rng.randint(1, 6))
        self.dice = (d1, d2)
        t = d1 + d2
        self.rounds += 1
        said = [f"{d1} and {d2}: {t}."]
        won = lost = 0

        def win(stake: int, gain: int):
            nonlocal won
            self.push(stake)
            won += self.pay(gain)

        def lose(stake: int):
            nonlocal lost
            self.lose(stake)
            lost += stake
        # come points already standing
        for n in list(self.come):
            bet, odds = self.come[n]
            if t == n:
                win(bet, bet)
                if odds:
                    win(odds, odds_win(n, odds))
                del self.come[n]
            elif t == 7:
                lose(bet + odds)
                del self.come[n]
        # a new come bet
        c = self.bets["come"]
        if c:
            self.bets["come"] = 0
            if t in (7, 11):
                win(c, c)
            elif t in (2, 3, 12):
                lose(c)
            else:
                b, o = self.come.get(t, [0, 0])
                self.come[t] = [b + c, o]
        # the line
        p, d = self.bets["pass"], self.bets["dont"]
        if self.point is None:
            if t in (7, 11):
                if p:
                    win(p, p)
                if d:
                    lose(d)
                self.bets["pass"] = self.bets["dont"] = 0
            elif t in (2, 3, 12):
                if p:
                    lose(p)
                if d:
                    if t == 12:
                        self.push(d)
                    else:
                        win(d, d)
                self.bets["pass"] = self.bets["dont"] = 0
            else:
                self.point = t
                said.append(f"The point is {t}.")
        else:
            o = self.bets["pass_odds"]
            if t == self.point:
                if p:
                    win(p, p)
                if o:
                    win(o, odds_win(t, o))
                if d:
                    lose(d)
                self.bets["pass"] = self.bets["dont"] = self.bets["pass_odds"] = 0
                said.append("The point is made.")
                self.point = None
            elif t == 7:
                if p or o:
                    lose(p + o)
                if d:
                    win(d, d)
                self.bets["pass"] = self.bets["dont"] = self.bets["pass_odds"] = 0
                said.append("Seven out.")
                self.point = None
        if won or lost:
            said.append((f"You win {money(won)}" if won else "") + (" and " if won and lost else "") +
                        (f"lose {money(lost)}" if lost else "") + ".")
        self.say(" ".join(said))
        if self.chips < self.ctx.stake_min and not self.on_table():
            self.over = True
        return t

    def on_table(self) -> int:
        return sum(self.bets.values()) + sum(b + o for b, o in self.come.values())

    def staked(self) -> int:
        return self.on_table()

    def can_cheat(self) -> bool:
        return self.rolling <= 0 and self.on_table() > 0

    def cheat(self) -> str:
        if self.point is None:
            self.forced = (3, 4) if self.bets["pass"] or self.bets["come"] else (1, 2)
        else:
            want = self.point if (self.bets["pass"] or self.bets["pass_odds"]) else 7
            self.forced = next(((a, want - a) for a in range(1, 7) if 1 <= want - a <= 6), (3, 4))
        self.cheated += 1
        return "The dice leave your hand already set."

    def buttons(self):
        idle = self.rolling <= 0
        return [("Pass line", "pass", idle and self.point is None), ("Don't pass", "dont", idle and self.point is None),
                ("Come", "come", idle and self.point is not None),
                ("Odds", "pass_odds", idle and self.point is not None and bool(self.bets["pass"])),
                ("Come odds", "come_odds", idle and bool(self.come)), ("Roll", "roll", idle)]

    def draw(self):
        out = [("felt", 20, 20, 600, 300, FELT)]
        out.append(("text", 320, 44, f"Point: {self.point if self.point else 'off'}", 16, ACCENT, "center"))
        for i, n in enumerate(POINTS):
            x = 90 + i * 80
            on = self.point == n
            out.append(("frame", x, 60, 70, 50, ACCENT if on else DIM))
            out.append(("text", x + 35, 92, str(n), 18, ACCENT if on else INK, "center"))
            if n in self.come:
                out += chip_prims(x + 52, 100, self.come[n][0] + self.come[n][1])
        rows = (("Pass line", "pass"), ("Don't pass", "dont"), ("Come", "come"), ("Odds", "pass_odds"))
        for i, (label, key) in enumerate(rows):
            y = 130 + i * 32
            out.append(("frame", 60, y, 300, 28, DIM))
            out.append(("text", 70, y + 19, label, 12, INK, "left"))
            if self.bets.get(key):
                out += chip_prims(330, y + 20, self.bets[key])
                out.append(("text", 300, y + 19, money(self.bets[key]), 10, ACCENT, "left"))
        out.append(("die", 440, 170, 40, self.dice[0]))
        out.append(("die", 500, 190, 40, self.dice[1]))
        for line in self.lines[-1:]:
            out.append(("text", 320, 334, line, 12, INK, "center"))
        return out

    def boxes(self):
        return [(60, 130 + i * 32, 300, 28, key) for i, key in enumerate(("pass", "dont", "come", "pass_odds"))]

    def bot(self, rng):
        if self.rolling > 0:
            return ""
        if self.point is None and not self.bets["pass"]:
            return "pass"
        return "roll_now"


__all__ = ["Craps", "odds_win", "ODDS", "POINTS"]
