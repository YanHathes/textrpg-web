"""Texas Hold'em against two to five of the house's players, fixed limit: blinds of half a bet and a bet, bets
of the stake before the flop and on it, twice the stake on the turn and the river, and at most a bet and three
raises a round. Four betting rounds (before the flop, the flop, the turn, the river), then the showdown; side
pots when someone is all in. The house takes 5% of each pot (at most two bets).

The house's players play their own way: cautious (folds what's weak, raises what's strong), loose (calls a lot)
and bluffers (raise now and then with nothing). They buy in from the house's bankroll and leave when they're
broke, and others sit down while the house can stake them.

Insight reads their tells, once a hand: the better the roll (proficiency with playing cards adds to it), the
truer the read. Cheat (Sleight of Hand): swap a hole card for an ace.

Hands, best first: straight flush (a royal flush is the best of them), four of a kind, full house, flush,
straight (A-2-3-4-5 is the lowest), three of a kind, two pair, a pair, high card.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field

from game.tablegames.base import ACCENT, BAD, FELT, GOOD, INK, Seat, Table, card_text, chip_prims, deck, money

CATEGORIES = ["High card", "Pair", "Two pair", "Three of a kind", "Straight", "Flush", "Full house",
              "Four of a kind", "Straight flush"]
RAKE = 0.05
STREETS = ["preflop", "flop", "turn", "river"]
MAX_BETS = 4
STYLES = ("cautious", "loose", "bluffer")


def _straight_high(ranks) -> int:
    """The top card of the best straight in these ranks (5 for the wheel), 0 for none."""
    s = set(ranks)
    if 14 in s:
        s.add(1)
    run, best = 0, 0
    for r in range(1, 15):
        if r in s:
            run += 1
            if run >= 5:
                best = r
        else:
            run = 0
    return best


def evaluate(cards) -> tuple:
    """The best five-card hand among 5 to 7 cards, as a tuple that compares: (category, tie-breakers...)."""
    ranks = sorted((c[0] for c in cards), reverse=True)
    by_suit: dict[int, list] = {}
    for r, s in cards:
        by_suit.setdefault(s, []).append(r)
    flush = next((sorted(v, reverse=True) for v in by_suit.values() if len(v) >= 5), None)
    if flush:
        sf = _straight_high(flush)
        if sf:
            return (8, sf)
    counts = Counter(ranks)
    groups = sorted(counts.items(), key=lambda kv: (kv[1], kv[0]), reverse=True)
    if groups[0][1] == 4:
        q = groups[0][0]
        return (7, q, max(r for r in ranks if r != q))
    trips = sorted((r for r, n in counts.items() if n == 3), reverse=True)
    pairs = sorted((r for r, n in counts.items() if n == 2), reverse=True)
    if trips and (len(trips) > 1 or pairs):
        t = trips[0]
        p = max(([trips[1]] if len(trips) > 1 else []) + pairs[:1])
        return (6, t, p)
    if flush:
        return (5, *flush[:5])
    st = _straight_high(ranks)
    if st:
        return (4, st)
    if trips:
        t = trips[0]
        kick = [r for r in ranks if r != t][:2]
        return (3, t, *kick)
    if len(pairs) >= 2:
        a, b = pairs[0], pairs[1]
        return (2, a, b, max(r for r in ranks if r not in (a, b)))
    if pairs:
        p = pairs[0]
        return (1, p, *[r for r in ranks if r != p][:3])
    return (0, *ranks[:5])


def describe(score: tuple) -> str:
    if score[0] == 8 and score[1] == 14:
        return "Royal flush"
    return CATEGORIES[score[0]]


def equity(rng, hole, board, opponents: int, sims: int = 40) -> float:
    """How often this hand wins (ties split) against that many random hands, the board dealt out."""
    if opponents <= 0:
        return 1.0
    used = set(hole) | set(board)
    rest = [c for c in deck() if c not in used]
    win = 0.0
    for _ in range(sims):
        rng.shuffle(rest)
        k = 0
        opp = []
        for _o in range(opponents):
            opp.append(rest[k:k + 2])
            k += 2
        full = list(board) + rest[k:k + 5 - len(board)]
        me = evaluate(list(hole) + full)
        best = max(evaluate(o + full) for o in opp)
        if me > best:
            win += 1
        elif me == best:
            win += 0.5
    return win / sims


@dataclass
class Player:
    name: str
    chips: int
    key: str = ""
    style: str = ""                    # "" for you
    hole: list = field(default_factory=list)
    folded: bool = False
    put: int = 0                       # in this betting round
    total: int = 0                     # in this hand
    allin: bool = False
    acted: bool = False
    note: str = ""

    @property
    def live(self) -> bool:
        return not self.folded and bool(self.hole)


class Holdem(Table):
    id, title = "holdem", "Texas Hold'em"
    help = "Fixed limit. Fold, check or call, bet or raise. Insight reads a tell once a hand."
    uses = "cards"
    cheat_label = "Swap a hole card for an ace"

    def setup(self) -> None:
        self.players: list[Player] = [Player(self.ctx.player, 0)]
        self.buy_in = max(self.ctx.stake_min * 40, self.stake * 40)
        for s in self.ctx.seats[:5]:
            self._sit(s)
        self.button = 0
        self.phase = "deal"            # deal | you | done
        self.street = ""
        self.board: list = []
        self.deck: list = []
        self.pot_rake = 0
        self.bets = 0
        self.current = 0
        self.turn = 0
        self.read = False
        self.result = ""
        self.say("Deal when you're ready.")

    def _sit(self, s: Seat) -> bool:
        chips = int(s.chips or self.buy_in)
        if self.house < chips:
            return False
        self.house -= chips
        self.players.append(Player(s.name, chips, s.key, s.style or "cautious"))
        return True

    @property
    def you(self) -> Player:
        return self.players[0]

    def total_money(self) -> int:
        """Everything at the table and in the house (it never changes)."""
        return self.chips + self.house + sum(p.chips + p.total for p in self.players[1:]) + self.you.total

    def staked(self) -> int:
        """The house's players' stacks go back to the house, and so does any pot when you walk away mid-hand."""
        return sum(p.chips + p.total for p in self.players[1:]) + self.you.total

    def betting(self) -> bool:
        return self.phase != "you"

    # ----- the hand
    def on(self, action: str) -> None:
        if action == "deal" and self.phase in ("deal", "done"):
            self.deal()
        elif self.phase == "you" and action in ("fold", "check", "call", "bet"):
            self._act(self.you, action)
            self.turn = 1 % len(self.players)
            self.phase = "play"
            self._run()

    def deal(self) -> bool:
        self._tidy()
        npcs = [p for p in self.players[1:]]
        if not npcs:
            self.say("Nobody's left to play: the house is cleaned out.")
            self.over = True
            return False
        sb, bb = max(1, self.stake // 2), self.stake
        if self.chips < bb:
            self.say("You haven't the chips for the blinds.")
            self.over = True
            return False
        self.rounds += 1
        self.deck = deck()
        self.rng.shuffle(self.deck)
        self.board = []
        self.read = False
        self.result = ""
        for p in self.players:
            p.hole, p.folded, p.total, p.put, p.allin, p.acted, p.note = [], False, 0, 0, False, False, ""
        for _ in range(2):
            for p in self.players:
                p.hole.append(self.deck.pop())
        n = len(self.players)
        self.button = (self.button + 1) % n
        self.street = "preflop"
        self.bets = 1
        self.current = 0
        self._blind((self.button + 1) % n, sb)
        self._blind((self.button + 2) % n, bb)
        self.current = bb
        self.turn = (self.button + 3) % n
        self.phase = "play"
        self._run()
        return True

    def _tidy(self) -> None:
        """Broke players leave (their seat goes back to the house), and others sit while the house can stake them."""
        keep = [self.players[0]]
        for p in self.players[1:]:
            if p.chips >= self.stake:
                keep.append(p)
            else:
                self.house += p.chips
        self.players = keep
        self.you.chips = self.chips
        want = max(2, min(5, len(self.ctx.seats)))
        k = 0
        while len(self.players) - 1 < want and k < 10:
            k += 1
            s = self.ctx.seats[(len(self.players) + self.rounds + k) % max(1, len(self.ctx.seats))] if self.ctx.seats \
                else Seat("A stranger")
            if s.name in {p.name for p in self.players}:
                s = Seat(f"{s.name} ({k})", s.key, s.style)
            if not self._sit(Seat(s.name, s.key, s.style)):
                break

    def _blind(self, i: int, amount: int) -> None:
        self._put(self.players[i], amount)

    def _put(self, p: Player, amount: int) -> None:
        have = self.chips if p is self.you else p.chips
        amount = min(amount, have)
        if p is self.you:
            self.chips -= amount
        else:
            p.chips -= amount
        p.put += amount
        p.total += amount
        if (self.chips if p is self.you else p.chips) == 0:
            p.allin = True

    def bet_size(self) -> int:
        return self.stake * (2 if self.street in ("turn", "river") else 1)

    def to_call(self, p: Player) -> int:
        return max(0, self.current - p.put)

    def _act(self, p: Player, action: str) -> None:
        owe = self.to_call(p)
        if action == "fold" and owe == 0:
            action = "check"
        if action == "check" and owe > 0:
            action = "call"
        if action == "bet" and self.bets >= MAX_BETS:
            action = "call" if owe else "check"
        if action == "fold":
            p.folded = True
            p.note = "folds"
        elif action in ("check", "call"):
            if owe:
                self._put(p, owe)
                p.note = "calls" if not p.allin else "is all in"
            else:
                p.note = "checks"
        elif action == "bet":
            self._put(p, owe + self.bet_size())
            self.current = p.put
            self.bets += 1
            p.note = "raises" if self.bets > 1 else "bets"
            for q in self.players:
                if q is not p:
                    q.acted = False
        p.acted = True
        if p is not self.you:
            self.say(f"{p.name} {p.note}.")

    def _active(self) -> list[Player]:
        return [p for p in self.players if p.live]

    def _round_over(self) -> bool:
        for p in self._active():
            if p.allin:
                continue
            if not p.acted or p.put < self.current:
                return False
        return True

    def _run(self) -> None:
        """Play the house's players until it's your turn, or the hand's over."""
        guard = 0
        while guard < 200:
            guard += 1
            live = self._active()
            if len(live) == 1:
                self._award([live[0]])
                return
            if self._round_over():
                if not self._next_street():
                    return
                continue
            p = self.players[self.turn % len(self.players)]
            self.turn = (self.turn + 1) % len(self.players)
            if not p.live or p.allin:
                continue
            if p is self.you:
                self.turn = (self.turn - 1) % len(self.players)
                self.phase = "you"
                return
            self._act(p, self._decide(p))
        self.phase = "done"

    def _next_street(self) -> bool:
        for p in self.players:
            p.put, p.acted = 0, False
        self.current = 0
        self.bets = 0
        i = STREETS.index(self.street)
        if i == 3 or sum(1 for p in self._active() if not p.allin) <= 1 and i < 3:
            while len(self.board) < 5:                 # everyone left is all in: deal it out
                self.board.append(self.deck.pop())
            if i == 3 or len(self.board) == 5:
                self._showdown()
                return False
        self.street = STREETS[i + 1]
        self.board += [self.deck.pop() for _ in range(3 if self.street == "flop" else 1)]
        self.turn = (self.button + 1) % len(self.players)
        return True

    def _showdown(self) -> None:
        live = self._active()
        scores = {id(p): evaluate(p.hole + self.board) for p in live}
        # side pots: by what each put in
        levels = sorted({p.total for p in self.players if p.total > 0})
        paid_below = 0
        won_by: dict[int, int] = {}
        for lv in levels:
            layer = sum(min(p.total, lv) - min(p.total, paid_below) for p in self.players)
            if layer <= 0:
                paid_below = lv
                continue
            contenders = [p for p in live if p.total >= lv]
            if not contenders:
                contenders = live
            best = max(scores[id(p)] for p in contenders)
            winners = [p for p in contenders if scores[id(p)] == best]
            self._split(layer, winners, won_by)
            paid_below = lv
        best_live = max(live, key=lambda p: scores[id(p)])
        names = ", ".join(f"{p.name} {describe(scores[id(p)]).lower()}" for p in live)
        mine = won_by.get(id(self.you), 0)
        self.result = f"Showdown: {names}. " + (f"You take {money(mine)}." if mine else f"{best_live.name} wins.")
        self.say(self.result)
        self._end()

    def _split(self, amount: int, winners: list, won_by: dict) -> None:
        rake = int(amount * RAKE)
        rake = min(rake, max(0, self.stake * 2 - self.pot_rake))
        self.pot_rake += rake
        self.house += rake
        amount -= rake
        share, extra = divmod(amount, len(winners))
        for k, p in enumerate(winners):
            got = share + (1 if k < extra else 0)
            won_by[id(p)] = won_by.get(id(p), 0) + got
            if p is self.you:
                self.chips += got
            else:
                p.chips += got

    def _award(self, winners: list) -> None:
        pot = sum(p.total for p in self.players)
        won = {}
        self._split(pot, winners, won)
        w = winners[0]
        self.say(("You take" if w is self.you else f"{w.name} takes") + f" the pot ({money(pot)}).")
        self._end()

    def _end(self) -> None:
        for p in self.players:
            p.total = 0
            p.put = 0
        self.pot_rake = 0
        self.phase = "done"
        if self.chips < self.stake:
            self.over = True

    # ----- the house's players
    def _decide(self, p: Player) -> str:
        opp = len(self._active()) - 1
        eq = equity(self.rng, p.hole, self.board, opp, 30)
        fair = 1.0 / (opp + 1)
        owe = self.to_call(p)
        pot = sum(q.total for q in self.players)
        odds = owe / (pot + owe) if owe else 0.0
        style = p.style or "cautious"
        strong = fair + (0.25 if style == "cautious" else 0.15)
        if eq >= strong and self.bets < MAX_BETS:
            return "bet"
        if style == "bluffer" and self.rng.random() < 0.2 and self.bets < MAX_BETS:
            return "bet"
        margin = {"cautious": 0.08, "loose": -0.1, "bluffer": 0.0}.get(style, 0.0)
        if owe == 0:
            return "check"
        return "call" if eq >= odds + margin else "fold"

    def read_tells(self, total: int) -> list[str]:
        """An Insight roll's worth of reading the others: the higher, the truer."""
        out = []
        if self.read or self.phase not in ("you", "done"):
            return out
        self.read = True
        opp = max(1, len(self._active()) - 1)
        for p in self.players[1:]:
            if not p.live:
                continue
            eq = equity(self.rng, p.hole, self.board, opp, 30)
            strong = eq > 1.0 / (opp + 1) + 0.1
            right = total >= 18 or (total >= 12 and self.rng.random() < 0.75) or self.rng.random() < 0.5
            seems = strong if right else not strong
            p.note = "seems sure of their cards" if seems else "is fidgeting with their chips"
            out.append(f"{p.name} {p.note}.")
        for line in out:
            self.say(line)
        return out

    def can_cheat(self) -> bool:
        return self.phase == "you" and bool(self.you.hole)

    def cheat(self) -> str:
        used = set(self.board) | {c for p in self.players for c in p.hole}
        ace = next(((14, s) for s in range(4) if (14, s) not in used), None)
        if ace is None:
            return "There's no ace to be had."
        low = min(self.you.hole)
        self.you.hole[self.you.hole.index(low)] = ace
        if ace in self.deck:
            self.deck.remove(ace)
        self.cheated += 1
        return f"The {card_text(low)} goes up your sleeve, and the {card_text(ace)} comes down."

    # ----- the screen
    def buttons(self):
        mine = self.phase == "you"
        owe = self.to_call(self.you) if mine else 0
        return [("Deal", "deal", self.phase in ("deal", "done")),
                ("Fold", "fold", mine and owe > 0), ("Check" if not owe else f"Call {money(owe)}", "call" if owe else "check", mine),
                ("Bet" if not self.current else "Raise", "bet", mine and self.bets < MAX_BETS),
                ("Read their tells", "tells", self.phase == "you" and not self.read)]

    def draw(self):
        out = [("felt", 20, 20, 600, 300, FELT)]
        pot = sum(p.total for p in self.players)
        out.append(("text", 320, 120, f"Pot {money(pot)}" + (f"  ·  {self.street}" if self.phase == "you" else ""),
                    13, ACCENT, "center"))
        for i, c in enumerate(self.board):
            out.append(("card", 225 + i * 40, 135, c[0], c[1], True))
        spots = [(70, 70), (250, 34), (430, 34), (560, 120), (560, 220)]
        for k, p in enumerate(self.players[1:]):
            x, y = spots[k % len(spots)]
            show = self.phase == "done" and p.live and len(self.board) == 5 and bool(self.result)
            out.append(("seat", x, y, p.name, p.key, f"{money(p.chips)}  {p.note}"))
            for i, c in enumerate(p.hole):
                out.append(("card", x + 46 + i * 16, y + 4, c[0], c[1], show))
        for i, c in enumerate(self.you.hole):
            out.append(("card", 280 + i * 40, 235, c[0], c[1], True))
        if self.you.hole and len(self.board) >= 3:
            out.append(("text", 320, 225, describe(evaluate(self.you.hole + self.board)), 11, GOOD, "center"))
        out += chip_prims(380, 300, self.you.total)
        col = BAD if self.phase == "you" and self.to_call(self.you) else INK
        out.append(("text", 200, 300, f"Your chips: {money(self.chips)}", 12, col, "center"))
        for line in self.lines[-1:]:
            out.append(("text", 320, 334, line, 12, INK, "center"))
        return out

    def bot(self, rng):
        if self.phase in ("deal", "done"):
            return "deal"
        if self.phase == "you":
            eq = equity(rng, self.you.hole, self.board, max(1, len(self._active()) - 1), 20)
            if eq > 0.5:
                return "bet"
            return "call" if self.to_call(self.you) <= self.stake else "fold"
        return ""


__all__ = ["Holdem", "evaluate", "describe", "equity", "CATEGORIES", "STYLES"]
