"""The shared table every game sits on: chips and stakes, the house's bankroll, the seats, and the buttons.

A table game is a class with its own rules (and none of Qt): ui/minigames/table.py draws it and passes the
clicks and keys on, the same way the check minigames work (game/minigames.py), with the same 640 x 360 board
and the same shapes, plus a few of the table's own:

    ("card", x, y, rank, suit, face_up)        rank 2..14 (11 J, 12 Q, 13 K, 14 A), suit 0..3 (♠ ♥ ♦ ♣)
    ("chip", x, y, value_copper)               a chip of that value (coloured by it)
    ("die", x, y, size, face)                  a die showing a face (0 while it's tumbling)
    ("wheel", x, y, r, angle, ball_angle)      the roulette wheel, turned, and the ball on it
    ("felt", x, y, w, h, colour)               the table's cloth
    ("seat", x, y, name, sprite_key, note)     someone at the table, with their portrait and a line under it

Money: the player sits down with chips (taken from the purse) and the house has its bankroll. Every game
moves copper between `chips` and `house` and nothing else, so what's won is what's lost. A house that runs
out of money stops the game ("the house is cleaned out") until it refills (game/tablegames/__init__.py).

Buttons: buttons() lists the controls at the bottom of the screen [(label, action, enabled)], the same for
every game: the stake (- and +), the game's own moves, and, where a game has one, the cheat.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

W, H = 640, 360
FELT, FELT_DARK, INK, DIM, GOOD, BAD, ACCENT = "#1f5a3a", "#173f2b", "#e8e2d0", "#9aa49a", "#7ec27a", "#d0604e", "#e8c060"
SUITS = "♠♥♦♣"
RANKS = {11: "J", 12: "Q", 13: "K", 14: "A"}


def rank_text(r: int) -> str:
    return RANKS.get(r, str(r))


def card_text(c) -> str:
    return rank_text(c[0]) + SUITS[c[1]]


def deck(n: int = 1) -> list[tuple[int, int]]:
    return [(r, s) for _ in range(n) for s in range(4) for r in range(2, 15)]


@dataclass
class Seat:
    """Someone else at the table: a name, a portrait (sprite key: an NPC id), a playing style, chips."""
    name: str
    key: str = ""
    style: str = "cautious"          # cautious | loose | bluffer
    chips: int = 0
    skill: float = 0.5               # how good they are at the skill games (0..1)


@dataclass
class Ctx:
    """What a table needs to know: limits, money, who's sitting, and how good the player is."""
    stake_min: int = 10              # copper
    stake_max: int = 500
    chips: int = 0                   # the player's stack
    house: int = 100_00              # the house's bankroll
    seats: list = field(default_factory=list)
    seed: int = 0
    player: str = "You"
    bonus: dict = field(default_factory=dict)   # insight, sleight, dex, str (athletics), con, cards, dice (bonuses)
    prof: dict = field(default_factory=dict)    # cards / dice: proficient (bool)
    casino: bool = False


class Table:
    id = ""
    title = ""
    help = ""
    uses = ""                         # "cards" | "dice" | "" : which gaming set it counts towards
    cheat_label = ""                  # the Sleight of Hand move, if the game has one
    realtime = False                  # update() moves it along (the skill games)

    def __init__(self, ctx: Ctx) -> None:
        self.ctx = ctx
        self.rng = random.Random(ctx.seed or random.randrange(1 << 30))
        self.chips = int(ctx.chips)
        self.house = int(ctx.house)
        self.stake = max(ctx.stake_min, min(ctx.stake_max, ctx.stake_min * 2))
        self.lines: list[str] = []
        self.rounds = 0               # hands played, rolls bet on, spins: each a use of the set
        self.over = False             # the game has ended (cleaned out, or the house is)
        self.cheated = 0              # cheats that worked
        self.t = 0.0
        self.setup()

    # ----- money
    def say(self, text: str) -> None:
        self.lines.append(text)
        del self.lines[:-6]

    def take(self, n: int) -> bool:
        """The player puts n on the table (from their chips)."""
        if n <= 0 or n > self.chips:
            return False
        self.chips -= n
        return True

    def pay(self, n: int) -> int:
        """The house pays the player n (what it can)."""
        n = max(0, min(int(n), self.house))
        self.house -= n
        self.chips += n
        return n

    def lose(self, n: int) -> None:
        """What the player put down goes to the house."""
        self.house += max(0, int(n))

    def push(self, n: int) -> None:
        self.chips += max(0, int(n))

    def house_can_cover(self, worst: int) -> bool:
        return self.house >= worst

    def stake_up(self) -> None:
        steps = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000]
        nxt = next((s for s in steps if s > self.stake), self.stake)
        self.stake = min(self.ctx.stake_max, max(self.ctx.stake_min, nxt))

    def stake_down(self) -> None:
        steps = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000]
        prev = max([s for s in steps if s < self.stake] or [self.ctx.stake_min])
        self.stake = max(self.ctx.stake_min, prev)

    # ----- the loop
    def setup(self) -> None:
        pass

    def update(self, dt: float) -> None:
        self.t += dt

    def press(self, action: str) -> None:
        if action == "stake+":
            self.stake_up()
        elif action == "stake-":
            self.stake_down()
        else:
            self.on(action)

    def on(self, action: str) -> None:
        pass

    def buttons(self) -> list[tuple[str, str, bool]]:
        return []

    def betting(self) -> bool:
        """Can the stake be changed now (between rounds)?"""
        return True

    def draw(self) -> list:
        return []

    def boxes(self) -> list:
        """Clickable parts of the board: [(x, y, w, h, action)]."""
        return []

    def cheat(self) -> str:
        """The cheat worked: do it. Returns what happened."""
        return ""

    def staked(self) -> int:
        """What's out on the table that isn't anyone's yet (a hand in play): the house keeps it if the player
        walks away, or is thrown out."""
        return 0

    def can_cheat(self) -> bool:
        return bool(self.cheat_label)

    def bot(self, rng: random.Random) -> str:
        """A sensible move (for tests and for a seat that plays itself): an action, or ""."""
        return ""


def chip_prims(x: float, y: float, amount: int) -> list:
    """A little stack of chips for an amount."""
    out = []
    left = int(amount)
    k = 0
    for v in (10000, 1000, 100, 10, 1):
        while left >= v and k < 8:
            out.append(("chip", x, y - k * 4, v))
            left -= v
            k += 1
    return out


def money(c: int) -> str:
    from game.state import money_text
    return money_text(int(c)) if c else "0 cp"


__all__ = ["Table", "Ctx", "Seat", "deck", "card_text", "rank_text", "chip_prims", "money", "W", "H"]
