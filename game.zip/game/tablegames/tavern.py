"""The tavern's own games, each against one of the regulars for the stake (won or lost even money):

    Darts            three darts each; aim with a sight that wobbles (Dexterity steadies it). Closest to the
                     bull scores most; the higher total wins.
    Arm wrestling    push when the pulse is in the green, against the other's strength (your Athletics adds to
                     each push, theirs to theirs). Pin their arm to win.
    Liar's dice      five dice each under a cup; bid how many of a face there are among all the dice, higher
                     each time, or call the last bid a lie. Whoever's wrong loses a die; out of dice, out of the
                     game. Insight reads whether their bid is a bluff; proficiency with dice shows the odds.
    Knucklebones     throw five bones, keep what you like and throw the rest once more (twice with proficiency
                     in dice). Pairs, threes and runs score; the higher score wins.
    Drinking contest a drink a round, and keep yourself upright as the room sways (Constitution steadies you).
                     Whoever falls over first loses.
Cheats (Sleight of Hand): a weighted dart, a sly elbow, a peek under their cup, loaded bones, water in your mug.
"""
from __future__ import annotations

import math

from game.tablegames.base import ACCENT, BAD, DIM, FELT, GOOD, INK, Table, money


class Duel(Table):
    """You against one regular, for the stake."""
    realtime = True

    def setup(self) -> None:
        self.foe = self.ctx.seats[0] if self.ctx.seats else None
        self.foe_name = self.foe.name if self.foe else "A regular"
        self.foe_skill = self.foe.skill if self.foe else 0.5
        self.phase = "bet"
        self.pot = 0
        self.say(f"{self.foe_name} will take you on. Set your stake and start.")
        self.begin()

    def begin(self) -> None:
        pass

    def betting(self) -> bool:
        return self.phase == "bet"

    def start(self) -> bool:
        if not self.house_can_cover(self.stake):
            self.say("Nobody here can cover that stake.")
            return False
        if not self.take(self.stake):
            self.say("You haven't the chips.")
            return False
        self.house -= self.stake                 # their stake goes in too
        self.pot = self.stake * 2
        self.rounds += 1
        self.phase = "play"
        self.begin()
        return True

    def end(self, won: bool | None) -> None:
        if won is None:
            self.chips += self.pot // 2
            self.house += self.pot - self.pot // 2
            self.say("A draw: stakes back.")
        elif won:
            self.chips += self.pot
            self.say(f"You win {money(self.pot // 2)}!")
        else:
            self.house += self.pot
            self.say(f"{self.foe_name} wins. You lose {money(self.pot // 2)}.")
        self.pot = 0
        self.phase = "bet"
        if self.chips < self.ctx.stake_min:
            self.over = True

    def staked(self) -> int:
        return self.pot

    def on(self, action: str) -> None:
        if action == "start" and self.phase == "bet":
            self.start()
        elif self.phase == "play":
            self.play(action)

    def play(self, action: str) -> None:
        pass

    def base_buttons(self):
        return [("Start", "start", self.phase == "bet" and self.chips >= self.stake)]

    def buttons(self):
        return self.base_buttons()

    def head(self) -> list:
        out = [("felt", 20, 20, 600, 300, FELT)]
        if self.foe is not None:
            out.append(("seat", 520, 40, self.foe_name, self.foe.key, ""))
        for line in self.lines[-1:]:
            out.append(("text", 320, 334, line, 12, INK, "center"))
        return out


# ----------------------------------------------------------------------------------------------------
class Darts(Duel):
    id, title = "darts", "Darts"
    help = "Throw (space or click) when the sight crosses the bull. Dexterity steadies your hand."
    uses = ""
    cheat_label = "Throw a weighted dart"
    THROWS = 3

    def begin(self) -> None:
        self.mine: list[float] = []
        self.theirs: list[float] = []
        self.sx = self.sy = 0.0
        self.weighted = False

    def wobble(self) -> float:
        """How far the sight swings (board radii): less with Dexterity."""
        return max(0.12, 0.85 - 0.09 * float(self.ctx.bonus.get("dex", 0)))

    def update(self, dt: float) -> None:
        super().update(dt)
        a = self.wobble()
        self.sx = a * math.sin(self.t * 2.3) * math.cos(self.t * 0.7)
        self.sy = a * math.sin(self.t * 1.7 + 1.0)

    @staticmethod
    def score(dist: float) -> int:
        """Rings: bull 50, then 25, 15, 10, 5, 2; off the board 0."""
        for r, pts in ((0.05, 50), (0.12, 25), (0.3, 15), (0.5, 10), (0.75, 5), (1.0, 2)):
            if dist <= r:
                return pts
        return 0

    def throw(self, x: float, y: float) -> int:
        if self.weighted:
            x, y = 0.0, 0.0
            self.weighted = False
        d = math.hypot(x, y) + abs(self.rng.gauss(0, 0.03))
        pts = self.score(d)
        self.mine.append(pts)
        foe = abs(self.rng.gauss(0, 0.65 - 0.5 * self.foe_skill))
        self.theirs.append(self.score(foe))
        if len(self.mine) >= self.THROWS:
            a, b = sum(self.mine), sum(self.theirs)
            self.end(a > b if a != b else None)
        return pts

    def play(self, action: str) -> None:
        if action == "hit":
            self.throw(self.sx, self.sy)

    def cheat(self) -> str:
        self.weighted = True
        self.cheated += 1
        return "A dart with a little lead in its tip: it flies true."

    def can_cheat(self) -> bool:
        return self.phase == "play"

    def buttons(self):
        return self.base_buttons() + [("Throw", "hit", self.phase == "play")]

    def draw(self):
        out = self.head()
        cx, cy, r = 240, 170, 120
        for k, (rr, col) in enumerate(((1.0, "#2c2c2c"), (0.75, "#c8b890"), (0.5, "#2c2c2c"), (0.3, "#c8b890"),
                                       (0.12, "#2a7a4a"), (0.05, "#a02a2a"))):
            out.append(("circle", cx, cy, r * rr, col))
        if self.phase == "play":
            sx, sy = cx + self.sx * r, cy + self.sy * r
            out += [("line", sx - 10, sy, sx + 10, sy, ACCENT, 2), ("line", sx, sy - 10, sx, sy + 10, ACCENT, 2)]
        out.append(("text", 470, 150, f"You: {sum(self.mine)}  ({', '.join(map(str, self.mine)) or '-'})", 12, GOOD, "left"))
        out.append(("text", 470, 175, f"{self.foe_name}: {sum(self.theirs)}", 12, BAD, "left"))
        return out

    def bot(self, rng):
        if self.phase == "bet":
            return "start"
        return "hit" if math.hypot(self.sx, self.sy) < 0.15 or rng.random() < 0.02 else ""


# ----------------------------------------------------------------------------------------------------
class ArmWrestle(Duel):
    id, title = "armwrestle", "Arm wrestling"
    help = "Push (space) when the pulse is in the green. Pin their arm to the table."
    cheat_label = "A sly elbow"

    def begin(self) -> None:
        self.pos = 0.0                        # -1 their win .. +1 yours
        self.pulse = 0.0
        self.zone = 0.25

    def strength(self) -> float:
        return 0.09 + 0.012 * float(self.ctx.bonus.get("str", 0))

    def foe_strength(self) -> float:
        return 0.045 + 0.05 * self.foe_skill

    def update(self, dt: float) -> None:
        super().update(dt)
        if self.phase != "play":
            return
        self.pulse = (self.pulse + dt * 1.1) % 1.0
        self.pos -= self.foe_strength() * dt * (1.0 + 0.5 * math.sin(self.t * 3))
        if self.pos <= -1:
            self.end(False)

    def in_zone(self) -> bool:
        return abs(self.pulse - 0.5) <= self.zone / 2

    def play(self, action: str) -> None:
        if action != "hit":
            return
        self.pos += self.strength() if self.in_zone() else -0.03
        if self.pos >= 1:
            self.end(True)

    def cheat(self) -> str:
        self.pos = min(0.95, self.pos + 0.5)
        self.cheated += 1
        return "You shift your elbow an inch and lean: their arm sags."

    def can_cheat(self) -> bool:
        return self.phase == "play"

    def buttons(self):
        return self.base_buttons() + [("Push", "hit", self.phase == "play")]

    def draw(self):
        out = self.head()
        out += [("rect", 120, 150, 400, 24, "#2a3038"), ("rect", 320 - 1, 146, 2, 32, DIM),
                ("circle", 320 + self.pos * 190, 162, 16, ACCENT)]
        out += [("rect", 200, 220, 240, 14, "#2a3038"),
                ("rect", 200 + 240 * (0.5 - self.zone / 2), 220, 240 * self.zone, 14, GOOD),
                ("rect", 200 + 240 * self.pulse - 2, 216, 4, 22, INK)]
        out.append(("text", 320, 120, "Push in the green", 12, DIM, "center"))
        return out

    def bot(self, rng):
        if self.phase == "bet":
            return "start"
        return "hit" if self.in_zone() and rng.random() < 0.5 else ""


# ----------------------------------------------------------------------------------------------------
class LiarsDice(Duel):
    id, title = "liarsdice", "Liar's dice"
    help = "Bid how many of a face are under all the cups, or call their bid a lie."
    uses = "dice"
    cheat_label = "Peek under their cup"
    realtime = False
    DICE = 5

    def begin(self) -> None:
        self.n_me = self.n_foe = self.DICE
        self.peeked = False
        self.hint = ""
        self._roll()

    def _roll(self) -> None:
        self.me = [self.rng.randint(1, 6) for _ in range(self.n_me)]
        self.foe_dice = [self.rng.randint(1, 6) for _ in range(self.n_foe)]
        self.bid = None                    # (count, face, by: "me"|"foe")
        self.peeked = False
        self.hint = ""

    def count(self, face: int) -> int:
        return sum(1 for d in self.me + self.foe_dice if d == face)

    @staticmethod
    def higher(a, b) -> bool:
        """Is bid a (count, face) higher than b?"""
        return b is None or a[0] > b[0] or (a[0] == b[0] and a[1] > b[1])

    def chance(self, bid) -> float:
        """How likely a bid is true, from what you can see (your own dice)."""
        n, face = bid
        mine = sum(1 for d in self.me if d == face)
        need = n - mine
        if need <= 0:
            return 1.0
        k = self.n_foe
        p = 1 / 6
        from math import comb
        return sum(comb(k, i) * p ** i * (1 - p) ** (k - i) for i in range(need, k + 1))

    def _foe_turn(self) -> None:
        """They raise on what they hold, or call you a liar."""
        n, face, _by = self.bid
        theirs = sum(1 for d in self.foe_dice if d == face)
        expect = theirs + self.n_me / 6
        if n > expect + 0.8 + (self.rng.random() - 0.5) * (1 - self.foe_skill):
            self._call("foe")
            return
        best = max(range(1, 7), key=lambda f: sum(1 for d in self.foe_dice if d == f))
        bid = (n, best) if best > face else (n + 1, best)
        if not self.higher(bid, (n, face)):
            bid = (n + 1, face)
        if self.rng.random() < 0.15 + 0.1 * (1 - self.foe_skill):
            bid = (bid[0] + 1, bid[1])                          # a bluff
        self.bid = (bid[0], bid[1], "foe")
        self.say(f"{self.foe_name} bids {bid[0]} {bid[1]}s.")

    def _call(self, who: str) -> None:
        n, face, _by = self.bid
        true = self.count(face) >= n
        if who == "me":
            loser = "me" if true else "foe"
        else:
            loser = "foe" if true else "me"
        self.say(("You call" if who == "me" else f"{self.foe_name} calls") + f" {n} {face}s: there are "
                 f"{self.count(face)}. " + ("You lose a die." if loser == "me" else f"{self.foe_name} loses a die."))
        if loser == "me":
            self.n_me -= 1
        else:
            self.n_foe -= 1
        if self.n_me == 0 or self.n_foe == 0:
            self.end(self.n_foe == 0)
            return
        self._roll()

    def play(self, action: str) -> None:
        if action == "liar" and self.bid is not None and self.bid[2] == "foe":
            self._call("me")
        elif action.startswith("bid:"):
            n, face = (int(x) for x in action[4:].split(","))
            if not self.higher((n, face), self.bid[:2] if self.bid else None) or n > self.n_me + self.n_foe:
                self.say("Bid higher than the last.")
                return
            self.bid = (n, face, "me")
            self._foe_turn()

    def next_bids(self) -> list[tuple[int, int]]:
        base = self.bid[:2] if self.bid else (1, 0)
        out = []
        for face in range(1, 7):
            n = base[0] if face > base[1] else base[0] + 1
            if self.bid is None:
                n = 1
            if n <= self.n_me + self.n_foe:
                out.append((n, face))
        return out

    def read(self, total: int) -> str:
        """Insight: is their bid a bluff?"""
        if self.bid is None or self.bid[2] != "foe":
            return ""
        true = self.count(self.bid[1]) >= self.bid[0]
        right = total >= 15 or self.rng.random() < 0.5
        seems = true if right else not true
        self.hint = f"{self.foe_name} looks {'easy' if seems else 'twitchy'}."
        self.say(self.hint)
        return self.hint

    def cheat(self) -> str:
        self.peeked = True
        self.cheated += 1
        return f"A glance under their cup: {', '.join(map(str, sorted(self.foe_dice)))}."

    def can_cheat(self) -> bool:
        return self.phase == "play" and not self.peeked

    def buttons(self):
        out = self.base_buttons()
        if self.phase == "play":
            out += [(f"Bid {n} {f}s", f"bid:{n},{f}", True) for n, f in self.next_bids()]
            out += [("Liar!", "liar", self.bid is not None and self.bid[2] == "foe"),
                    ("Read them", "tells", self.bid is not None and self.bid[2] == "foe" and not self.hint)]
        return out

    def draw(self):
        out = self.head()
        for i, d in enumerate(self.me if self.phase == "play" else []):
            out.append(("die", 160 + i * 50, 240, 36, d))
        for i in range(self.n_foe if self.phase == "play" else 0):
            out.append(("die", 160 + i * 50, 80, 36, self.foe_dice[i] if self.peeked else 7))
        if self.bid:
            who = "You bid" if self.bid[2] == "me" else f"{self.foe_name} bids"
            out.append(("text", 320, 170, f"{who} {self.bid[0]} {self.bid[1]}s", 16, ACCENT, "center"))
            if self.ctx.prof.get("dice"):
                out.append(("text", 320, 196, f"(about {int(self.chance(self.bid[:2]) * 100)}% to be true)", 11,
                            DIM, "center"))
        return out

    def bot(self, rng):
        if self.phase == "bet":
            return "start"
        if self.bid is not None and self.bid[2] == "foe" and self.chance(self.bid[:2]) < 0.4:
            return "liar"
        bids = self.next_bids()
        if not bids:
            return "liar"
        best = max(bids, key=lambda b: self.chance(b) - 0.02 * b[0])
        return f"bid:{best[0]},{best[1]}"


# ----------------------------------------------------------------------------------------------------
def bones_score(dice: list[int]) -> int:
    """Knucklebones: the pips, plus 10 for a pair, 25 for three alike, 50 for four, 100 for five, and 20 for a
    run of four (40 for five)."""
    from collections import Counter
    c = Counter(dice)
    s = sum(dice)
    for n in c.values():
        s += {2: 10, 3: 25, 4: 50, 5: 100}.get(n, 0)
    u = sorted(set(dice))
    run = best = 1
    for a, b in zip(u, u[1:]):
        run = run + 1 if b == a + 1 else 1
        best = max(best, run)
    s += 40 if best >= 5 else 20 if best >= 4 else 0
    return s


class Knucklebones(Duel):
    id, title = "knucklebones", "Knucklebones"
    help = "Throw five bones; click the ones to keep and throw again. Pairs, threes and runs score."
    uses = "dice"
    cheat_label = "Throw loaded bones"
    realtime = False

    def begin(self) -> None:
        self.mine: list[int] = []
        self.keep: set = set()
        self.throws = 0
        self.loaded = False
        self.foe_score = None

    def max_throws(self) -> int:
        return 3 if self.ctx.prof.get("dice") else 2

    def throw(self) -> None:
        if self.loaded:
            self.mine = [6, 6, 6, 6, 6]
            self.loaded = False
        elif not self.mine:
            self.mine = [self.rng.randint(1, 6) for _ in range(5)]
        else:
            self.mine = [d if i in self.keep else self.rng.randint(1, 6) for i, d in enumerate(self.mine)]
        self.throws += 1
        if self.throws >= self.max_throws():
            self.settle()

    def settle(self) -> None:
        foe = [self.rng.randint(1, 6) for _ in range(5)]
        if self.foe_skill > 0.5:                            # a canny one throws again for the best of it
            again = [self.rng.randint(1, 6) for _ in range(5)]
            foe = max(foe, again, key=bones_score)
        self.foe_score = bones_score(foe)
        me = bones_score(self.mine)
        self.say(f"You score {me}, {self.foe_name} {self.foe_score}.")
        self.end(me > self.foe_score if me != self.foe_score else None)

    def play(self, action: str) -> None:
        if action == "throw":
            self.throw()
        elif action == "stop" and self.mine:
            self.settle()
        elif action.startswith("keep:"):
            i = int(action[5:])
            self.keep ^= {i}

    def cheat(self) -> str:
        self.loaded = True
        self.cheated += 1
        return "These bones always seem to land the right way up."

    def can_cheat(self) -> bool:
        return self.phase == "play"

    def buttons(self):
        play = self.phase == "play"
        return self.base_buttons() + [("Throw", "throw", play), ("Stand on it", "stop", play and bool(self.mine))]

    def boxes(self):
        return [(160 + i * 60, 160, 44, 44, f"keep:{i}") for i in range(len(self.mine))]

    def draw(self):
        out = self.head()
        for i, d in enumerate(self.mine):
            out.append(("die", 160 + i * 60, 160, 44, d))
            if i in self.keep:
                out.append(("frame", 156 + i * 60, 156, 52, 52, ACCENT))
        if self.mine:
            out.append(("text", 320, 240, f"Score {bones_score(self.mine)}  ·  throw {self.throws} of "
                        f"{self.max_throws()}", 13, GOOD, "center"))
        return out

    def bot(self, rng):
        if self.phase == "bet":
            return "start"
        if self.mine and self.throws < self.max_throws():
            from collections import Counter
            top = Counter(self.mine).most_common(1)[0][0]
            self.keep = {i for i, d in enumerate(self.mine) if d == top}
        return "throw"


# ----------------------------------------------------------------------------------------------------
class Drinking(Duel):
    id, title = "drinking", "Drinking contest"
    help = "Drink (space) each round, and keep yourself upright (left and right) as the room sways."
    cheat_label = "Water in your mug"

    def begin(self) -> None:
        self.drinks = 0
        self.lean = 0.0
        self.vel = 0.0
        self.foe_limit = 3 + int(self.foe_skill * 6) + self.rng.randint(0, 3)
        self.water = False
        self.left = self.right = False

    def drift(self) -> float:
        con = float(self.ctx.bonus.get("con", 0))
        return max(0.05, (0.12 + 0.07 * self.drinks) * (1 - 0.08 * con))

    def update(self, dt: float) -> None:
        super().update(dt)
        if self.phase != "play":
            return
        push = math.sin(self.t * 1.3) * self.drift() + math.sin(self.t * 3.1) * self.drift() * 0.4
        steer = (-1 if self.left else 0) + (1 if self.right else 0)
        self.vel += (push + steer * 0.6 - self.lean * 0.2) * dt
        self.vel *= 0.98
        self.lean += self.vel * dt
        if abs(self.lean) >= 1.0:
            self.say("You topple off your stool.")
            self.end(False)

    def drink(self) -> None:
        if self.water:
            self.water = False
        else:
            self.drinks += 1
        if self.drinks >= self.foe_limit:
            self.say(f"{self.foe_name} slides under the table.")
            self.end(True)

    def play(self, action: str) -> None:
        if action == "hit":
            self.drink()
        elif action == "left":
            self.left, self.right = True, False
        elif action == "right":
            self.left, self.right = False, True
        elif action == "stop":
            self.left = self.right = False

    def cheat(self) -> str:
        self.water = True
        self.cheated += 1
        return "Your next mug is mostly water."

    def can_cheat(self) -> bool:
        return self.phase == "play"

    def buttons(self):
        play = self.phase == "play"
        return self.base_buttons() + [("Drink", "hit", play), ("Lean left", "left", play), ("Steady", "stop", play),
                                      ("Lean right", "right", play)]

    def draw(self):
        out = self.head()
        out += [("rect", 120, 170, 400, 10, "#2a3038"), ("rect", 318, 160, 4, 30, DIM),
                ("circle", 320 + self.lean * 200, 175, 14, BAD if abs(self.lean) > 0.7 else ACCENT)]
        out.append(("text", 320, 230, f"Drinks: {self.drinks}", 14, INK, "center"))
        return out

    def bot(self, rng):
        if self.phase == "bet":
            return "start"
        if self.lean > 0.2:
            return "left"
        if self.lean < -0.2:
            return "right"
        return "hit" if rng.random() < 0.03 else "stop"


TAVERN = (Darts, ArmWrestle, LiarsDice, Knucklebones, Drinking)

__all__ = ["Darts", "ArmWrestle", "LiarsDice", "Knucklebones", "Drinking", "bones_score", "TAVERN"]
