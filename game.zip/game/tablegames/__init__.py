"""Games of chance and skill: where they're played, the house's money, and what a sitting comes to.

    Blackjack            every tavern and inn, and casinos
    Darts, arm wrestling, liar's dice, knucklebones, a drinking contest       every tavern and inn
    Texas Hold'em, craps, roulette                                            casinos

Each game is its own module (its rules, and how it's drawn) on the shared table (base.py); ui/minigames/table.py
shows any of them.

Stakes: a tavern's tables take 1 sp to 5 gp a hand, a casino's 1 gp to 100 gp (more in a capital). Every house
has a bankroll (a tavern 50 gp, a casino 3,000 gp, a capital's casino 10,000 gp) that can be cleaned out: what
a house has lost comes back over a week.

Skill: every hand dealt counts as a use of a playing card set, every roll or game of dice as a use of a dice set
(game/tools.py), by whoever is playing (the party member best at the game).

Cheating: a Sleight of Hand check (DC 14 in a tavern, 17 in a casino). Caught, you're thrown out (what's on
the table is lost, and the house won't have you for a week) and it's a crime (game/law.py) seen by the dealer
or the one you played.
"""
from __future__ import annotations

import random
import zlib

from game.tablegames.base import Ctx, Seat, Table
from game.tablegames.blackjack import Blackjack
from game.tablegames.craps import Craps
from game.tablegames.holdem import Holdem
from game.tablegames.roulette import Roulette
from game.tablegames.tavern import TAVERN, ArmWrestle, Darts, Drinking, Knucklebones, LiarsDice

GAMES = {g.id: g for g in (Blackjack, Holdem, Craps, Roulette) + TAVERN}
TAVERN_GAMES = ["blackjack"] + [g.id for g in TAVERN]
CASINO_GAMES = ["blackjack", "holdem", "craps", "roulette"]
# a line about each game, for choosing one
BLURB = {"blackjack": "Beat the dealer to 21.", "holdem": "Texas Hold'em against the house's players.",
         "craps": "Dice: pass, don't pass, come and odds.", "roulette": "Single zero: inside and outside bets.",
         "darts": "Three darts each, against a regular.", "armwrestle": "Strength against strength.",
         "liarsdice": "Bid and bluff with dice under cups.", "knucklebones": "A quick throw of the bones.",
         "drinking": "Last one standing wins."}
LIMITS = {"tavern": (10, 500), "casino": (100, 10000), "capital": (100, 50000)}
BANKROLL = {"tavern": 50_00, "casino": 3000_00, "capital": 10000_00}
REFILL_DAYS = 7
BARRED_DAYS = 7
CHEAT_DC = {"tavern": 14, "casino": 17, "capital": 18}
SET_KEYS = {"cards": "skill.playing-card-set", "dice": "skill.dice-set"}
# the skill each game leans on, for choosing who plays and for the game's own bonuses
SKILL_OF = {"darts": "dex", "armwrestle": "str", "drinking": "con", "liarsdice": "insight", "holdem": "insight"}


def house_kind(world, building) -> str:
    """"casino", "capital" (a capital's casino), "tavern", or "" where nobody plays."""
    if building is None:
        return ""
    k = building.fields.get("kind") or ""
    fac = building.fields.get("facilities") or []
    if k == "Casino":
        town = world.entities.get(building.fields.get("town") or "")
        return "capital" if town is not None and (town.fields.get("kind") or "") == "Capital" else "casino"
    if k in ("Tavern", "Inn") or "Blackjack table" in fac or "Tavern games" in fac:
        return "tavern"
    return ""


def games_at(world, building) -> list[str]:
    kind = house_kind(world, building)
    if not kind:
        return []
    return CASINO_GAMES if kind in ("casino", "capital") else TAVERN_GAMES


def _house(state, building) -> dict:
    return state.npc(f"house:{building.id}")


def bankroll(world, state, building) -> int:
    """What the house has now (what it lost coming back over a week, toward its full bankroll)."""
    full = BANKROLL.get(house_kind(world, building), 50_00)
    h = _house(state, building)
    if "bank" not in h:
        return full
    bank = int(h["bank"])
    if bank >= full:
        return bank
    back = full * max(0, state.minutes - int(h.get("at", state.minutes))) / (REFILL_DAYS * 1440)
    return int(min(full, bank + back))


def barred(state, building) -> int:
    """Days left before the house will let the party play again (0: welcome)."""
    until = int(_house(state, building).get("barred_until", 0))
    return max(0, (until - state.minutes + 1439) // 1440)


def _seats(world, state, building, n: int) -> list[Seat]:
    """The regulars or the house's players: the people about, with a style each."""
    from game import places
    rng = random.Random(zlib.crc32(f"{building.id}:{state.day}".encode()))
    try:
        people = [p for p in places.people_in(world, places.parse(world, building.id), state)
                  if not state.npc_dead(p.id) and (p.fields.get("occupation") or "") not in ("Guard",)]
    except Exception:  # noqa: BLE001
        people = []
    rng.shuffle(people)
    out = []
    styles = ("cautious", "loose", "bluffer")
    for i, p in enumerate(people[:n]):
        out.append(Seat(p.name, p.id, styles[zlib.crc32(p.id.encode()) % 3],
                        skill=0.3 + 0.6 * ((zlib.crc32((p.id + "skill").encode()) % 100) / 100)))
    names = ["Old Marta", "One-Eyed Dun", "Pell the Tinker", "Sabra", "A merchant from away", "Corin Vell"]
    k = 0
    while len(out) < n:
        out.append(Seat(names[k % len(names)], "", styles[k % 3], skill=0.3 + 0.1 * (k % 6)))
        k += 1
    return out


def player_for(world, members, game_id: str):
    """Who plays for the party: the best at what the game leans on (cards or dice, or a stat or skill)."""
    from game import checks, condition
    best = None
    opts = {o["label"]: o for o in checks.options(world)}
    for m in members or []:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        lean = SKILL_OF.get(game_id, "")
        if lean in ("dex", "str", "con"):
            score = c.mods.get(lean, 0)
            if lean == "str" and "Athletics" in opts:
                score = checks.bonus(world, m, c, opts["Athletics"])[0]
        elif lean == "insight" and "Insight" in opts:
            score = checks.bonus(world, m, c, opts["Insight"])[0]
        else:
            score = c.mods.get("cha", 0)
        if best is None or score > best[1]:
            best = (m, score, c)
    return best[0] if best else None


def bonuses(world, member) -> tuple[dict, dict]:
    """(bonus, proficient) for the games: dex, str (Athletics), con, insight, sleight, cards, dice."""
    from game import checks, condition, tools
    c = condition.combatant(world, member)
    opts = {o["label"]: o for o in checks.options(world)}
    b = {"dex": c.mods.get("dex", 0), "con": c.mods.get("con", 0), "str": c.mods.get("str", 0)}
    for key, label in (("str", "Athletics"), ("insight", "Insight"), ("sleight", "Sleight of Hand")):
        if label in opts:
            b[key] = checks.bonus(world, member, c, opts[label])[0]
    prof = {}
    for k, sk in SET_KEYS.items():
        lvl = tools.level(world, member, sk)[1]
        prof[k] = bool(lvl)
        b[k] = c.prof * lvl
    return b, prof


def sit(world, state, members, building, game_id: str, buy_in: int, seed: int | None = None) -> Table | None:
    """Sit down at a game: chips from the purse, the house's bankroll on the other side."""
    kind = house_kind(world, building)
    if game_id not in games_at(world, building) or barred(state, building):
        return None
    lo, hi = LIMITS[kind]
    buy_in = max(0, min(int(buy_in), state.copper))
    if buy_in < lo:
        return None
    player = player_for(world, members, game_id)
    bonus, prof = bonuses(world, player) if player is not None else ({}, {})
    n = 1 if game_id in [g.id for g in TAVERN] else 4 if game_id == "holdem" else 0
    ctx = Ctx(stake_min=lo, stake_max=hi, chips=buy_in, house=bankroll(world, state, building),
              seats=_seats(world, state, building, n), seed=seed or random.randrange(1 << 30),
              player=(player or {}).get("name", "You"), bonus=bonus, prof=prof, casino=kind != "tavern")
    state.add_copper(-buy_in, f"chips at {building.name}")
    t = GAMES[game_id](ctx)
    t.building_id = building.id
    t.player_id = (player or {}).get("id", "")
    t.house_kind = kind
    return t


def leave(world, state, members, table: Table, bus=None) -> int:
    """Cash out: chips back to the purse, the house's bankroll as it now stands, and the hands played counted as
    uses of the gaming set. Returns the party's gain (or loss) in copper."""
    from game import tools
    building = world.entities.get(getattr(table, "building_id", "") or "")
    start = int(table.ctx.chips)
    state.add_copper(table.chips, "cashed out")
    state.advance(max(5, table.rounds * 3), f"playing {table.title.lower()}")
    if building is not None:
        h = _house(state, building)
        h["bank"] = int(table.house + table.staked())
        h["at"] = state.minutes
    m = next((x for x in members or [] if x.get("id") == getattr(table, "player_id", "")), None)
    key = SET_KEYS.get(table.uses or "")
    if m is not None and key and table.rounds:
        tools.record_use(world, m, key, table.rounds, bus)
    net = table.chips - start
    if bus is not None:
        bus.emit("log", kind="loot" if net > 0 else "narration",
                 text=f"You leave the {table.title.lower()} table " +
                      (f"{_money(net)} up." if net > 0 else f"{_money(-net)} down." if net < 0 else "even."))
    state.save()
    return net


def _money(c: int) -> str:
    from game.state import money_text
    return money_text(c)


def try_cheat(world, state, members, table: Table, rng: random.Random | None = None, bus=None) -> tuple[bool, str]:
    """Sleight of Hand. Done, the game's cheat happens; caught, the party's thrown out and it's a crime."""
    from game import checks, condition, law
    rng = rng or random.Random()
    if not table.can_cheat():
        return False, "Not now."
    building = world.entities.get(getattr(table, "building_id", "") or "")
    dc = CHEAT_DC.get(getattr(table, "house_kind", "tavern"), 14)
    opt = next((o for o in checks.options(world) if o["label"] == "Sleight of Hand"), None)
    who = next((m for m in members or [] if m.get("id") == getattr(table, "player_id", "")), None) or \
        next((m for m in members or [] if not m.get("dead")), None)
    if who is None or opt is None:
        return False, "Nobody can try that."
    c = condition.combatant(world, who)
    r = checks.roll(world, who, c, opt, dc, rng=rng, bus=bus, target="cheating at the table")
    if r.get("success"):
        return True, table.cheat()
    # caught: thrown out, the stakes on the table lost, and a crime seen by whoever runs the game
    table.over = True
    table.caught = True
    if building is not None:
        h = _house(state, building)
        h["barred_until"] = state.minutes + BARRED_DAYS * 1440
        town = world.entities.get(building.fields.get("town") or "")
        dealer = next((x for x in building.fields.get("npcs") or [] if not state.npc_dead(x)), "")
        seen = [w for w in [dealer] + [s.key for s in table.ctx.seats[:1] if s.key] if w] or [law.CROWD]
        law.commit(world, state, "cheating", town, seen, 0, dealer, bus)
    return False, "You're caught! They drag you from the table and throw you out."


__all__ = ["GAMES", "TAVERN_GAMES", "CASINO_GAMES", "games_at", "house_kind", "bankroll", "barred", "sit", "leave",
           "try_cheat", "Blackjack", "Holdem", "Craps", "Roulette", "Darts", "ArmWrestle", "LiarsDice", "Knucklebones",
           "Drinking", "LIMITS", "BANKROLL", "SET_KEYS"]
