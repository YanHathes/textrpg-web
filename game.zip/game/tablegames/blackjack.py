"""Blackjack: the dealer stands on soft 17, a blackjack pays 3 to 2, double down on any first two cards (and
after a split), split pairs up to four hands (split aces take one card each). The dealer checks for blackjack
when showing an ace or a ten. Two decks in a tavern, six in a casino, reshuffled when a quarter is left.

Cheat (Sleight of Hand): palm a ten into your hand in place of your last card.
"""
from __future__ import annotations

from game.tablegames.base import ACCENT, BAD, DIM, FELT, GOOD, INK, Table, card_text, chip_prims, deck, money

MAX_HANDS = 4


def value(cards) -> tuple[int, bool]:
    """(total, soft): soft when an ace is counted as 11."""
    total, aces = 0, 0
    for r, _s in cards:
        if r == 14:
            aces += 1
            total += 11
        else:
            total += min(10, r)
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total, aces > 0


def is_blackjack(cards) -> bool:
    return len(cards) == 2 and value(cards)[0] == 21


def ten_value(card) -> bool:
    return 10 <= card[0] <= 13


def dealer_hits(cards) -> bool:
    """The dealer draws to 16 and stands on every 17, soft or hard."""
    return value(cards)[0] < 17


def settle(hand: dict, dealer: list) -> int:
    """What comes back to the player for one hand (stake included): 0 if it's lost."""
    bet = hand["bet"]
    pv = value(hand["cards"])[0]
    natural = is_blackjack(hand["cards"]) and not hand.get("split")
    dealer_bj = is_blackjack(dealer)
    if pv > 21:
        return 0
    if natural and not dealer_bj:
        return bet + bet * 3 // 2
    if dealer_bj:
        return bet if natural else 0
    dv = value(dealer)[0]
    if dv > 21 or pv > dv:
        return bet * 2
    if pv == dv:
        return bet
    return 0


def basic(hand_cards, up, can_double: bool, can_split: bool) -> str:
    """A fair basic strategy (for the dealer standing on soft 17): "hit", "stand", "double" or "split"."""
    u = 11 if up[0] == 14 else min(10, up[0])
    total, soft = value(hand_cards)
    if can_split and len(hand_cards) == 2 and min(10, hand_cards[0][0]) == min(10, hand_cards[1][0]):
        r = hand_cards[0][0]
        p = 11 if r == 14 else min(10, r)
        if p in (11, 8):
            return "split"
        if p == 9 and u not in (7, 10, 11):
            return "split"
        if p in (2, 3, 7) and u <= 7:
            return "split"
        if p == 6 and u <= 6:
            return "split"
        if p == 4 and u in (5, 6):
            return "split"
    if soft:
        if total >= 19:
            return "stand"
        if total == 18:
            if can_double and 3 <= u <= 6:
                return "double"
            return "stand" if u in (2, 7, 8) else "hit"
        if can_double and ((total == 17 and 3 <= u <= 6) or (total in (15, 16) and 4 <= u <= 6) or
                           (total in (13, 14) and 5 <= u <= 6)):
            return "double"
        return "hit"
    if total >= 17:
        return "stand"
    if total >= 13:
        return "stand" if u <= 6 else "hit"
    if total == 12:
        return "stand" if 4 <= u <= 6 else "hit"
    if total == 11 and can_double:
        return "double"
    if total == 10 and can_double and u <= 9:
        return "double"
    if total == 9 and can_double and 3 <= u <= 6:
        return "double"
    return "hit"


class Blackjack(Table):
    id, title = "blackjack", "Blackjack"
    help = "Beat the dealer without going over 21. Dealer stands on soft 17; blackjack pays 3 to 2."
    uses = "cards"
    cheat_label = "Palm a ten into your hand"

    def setup(self) -> None:
        self.decks = 6 if self.ctx.casino else 2
        self.shoe: list = []
        self._shuffle()
        self.phase = "bet"
        self.hands: list[dict] = []
        self.dealer: list = []
        self.at = 0
        self.say("Place your bet and deal.")

    def _shuffle(self) -> None:
        self.shoe = deck(self.decks)
        self.rng.shuffle(self.shoe)

    def draw_card(self):
        if len(self.shoe) < self.decks * 13:
            self._shuffle()
        return self.shoe.pop()

    def betting(self) -> bool:
        return self.phase == "bet"

    # ----- moves
    def on(self, action: str) -> None:
        if action == "deal" and self.phase == "bet":
            self.deal()
        elif self.phase == "play" and action in ("hit", "stand", "double", "split"):
            getattr(self, "_" + action)()

    def deal(self) -> bool:
        worst = self.stake * 2 * MAX_HANDS
        if not self.house_can_cover(min(worst, self.stake * 3)):
            self.say("The house can't cover that bet: it's been cleaned out.")
            self.over = self.house < self.ctx.stake_min * 3
            return False
        if not self.take(self.stake):
            self.say("You haven't the chips for that.")
            return False
        self.rounds += 1
        self.hands = [{"cards": [self.draw_card()], "bet": self.stake, "done": False}]
        self.dealer = [self.draw_card()]
        self.hands[0]["cards"].append(self.draw_card())
        self.dealer.append(self.draw_card())
        self.at = 0
        up = self.dealer[0]
        if (up[0] == 14 or ten_value(up)) and is_blackjack(self.dealer):      # the dealer peeks
            self.say("The dealer has blackjack.")
            self._finish()
            return True
        if is_blackjack(self.hands[0]["cards"]):
            self.say("Blackjack!")
            self._finish()
            return True
        self.phase = "play"
        self.say(f"You have {value(self.hand['cards'])[0]}. The dealer shows {card_text(up)}.")
        return True

    @property
    def hand(self) -> dict:
        return self.hands[self.at]

    def can_double(self) -> bool:
        h = self.hand
        return self.phase == "play" and len(h["cards"]) == 2 and not h.get("split_aces") and self.chips >= h["bet"]

    def can_split(self) -> bool:
        h = self.hand
        c = h["cards"]
        return (self.phase == "play" and len(c) == 2 and min(10, c[0][0]) == min(10, c[1][0]) and
                len(self.hands) < MAX_HANDS and self.chips >= h["bet"] and not h.get("split_aces"))

    def _hit(self) -> None:
        h = self.hand
        h["cards"].append(self.draw_card())
        t = value(h["cards"])[0]
        if t > 21:
            self.say(f"Bust with {t}.")
            self._next()
        elif t == 21:
            self._next()

    def _stand(self) -> None:
        self._next()

    def _double(self) -> None:
        if not self.can_double():
            return
        h = self.hand
        self.take(h["bet"])
        h["bet"] *= 2
        h["cards"].append(self.draw_card())
        self.say(f"Doubled: {value(h['cards'])[0]}.")
        self._next()

    def _split(self) -> None:
        if not self.can_split():
            return
        h = self.hand
        self.take(h["bet"])
        aces = h["cards"][0][0] == 14
        other = {"cards": [h["cards"].pop()], "bet": h["bet"], "split": True, "split_aces": aces}
        h["split"] = True
        h["split_aces"] = aces
        h["cards"].append(self.draw_card())
        other["cards"].append(self.draw_card())
        self.hands.insert(self.at + 1, other)
        if aces:                                   # split aces: one card each, and that's all
            self.at += 1
            self._next()
        elif value(h["cards"])[0] == 21:
            self._next()

    def _next(self) -> None:
        self.at += 1
        while self.at < len(self.hands) and value(self.hands[self.at]["cards"])[0] == 21:
            self.at += 1
        if self.at >= len(self.hands):
            self._finish()

    def _finish(self) -> None:
        if any(value(h["cards"])[0] <= 21 for h in self.hands) and not is_blackjack(self.dealer) and \
                not (len(self.hands) == 1 and is_blackjack(self.hands[0]["cards"])):
            while dealer_hits(self.dealer):
                self.dealer.append(self.draw_card())
        dv = value(self.dealer)[0]
        net = 0
        for h in self.hands:
            back = settle(h, self.dealer)
            net += back - h["bet"]
            if back > h["bet"]:
                self.pay(back - h["bet"])
                self.push(h["bet"])
            elif back == h["bet"]:
                self.push(h["bet"])
            else:
                self.lose(h["bet"])
        self.say(f"Dealer {'busts with' if dv > 21 else 'has'} {dv}. " +
                 (f"You win {money(net)}." if net > 0 else f"You lose {money(-net)}." if net < 0 else "A push."))
        self.phase = "bet"
        self.at = 0
        if self.chips < self.ctx.stake_min:
            self.over = True

    def staked(self) -> int:
        return sum(h["bet"] for h in self.hands) if self.phase == "play" else 0

    # ----- cheating
    def can_cheat(self) -> bool:
        return self.phase == "play"

    def cheat(self) -> str:
        h = self.hand
        old = h["cards"][-1]
        h["cards"][-1] = (13, old[1])
        self.cheated += 1
        return f"You palm the {card_text(old)} and there's a king in its place."

    # ----- the screen
    def buttons(self):
        play = self.phase == "play"
        return [("Deal", "deal", self.phase == "bet" and self.chips >= self.stake),
                ("Hit", "hit", play), ("Stand", "stand", play), ("Double", "double", play and self.can_double()),
                ("Split", "split", play and self.can_split())]

    def draw(self):
        out = [("felt", 20, 20, 600, 300, FELT), ("text", 320, 40, "Dealer stands on soft 17  ·  Blackjack pays 3 to 2",
                                                 11, DIM, "center")]
        hide = self.phase == "play"
        for i, c in enumerate(self.dealer):
            out.append(("card", 250 + i * 38, 60, c[0], c[1], not (hide and i == 1)))
        if self.dealer and not hide:
            out.append(("text", 320, 165, f"Dealer: {value(self.dealer)[0]}", 13, INK, "center"))
        n = len(self.hands)
        for k, h in enumerate(self.hands):
            x0 = 320 - n * 75 + k * 150 + 20
            for i, c in enumerate(h["cards"]):
                out.append(("card", x0 + i * 22, 190 + i * 6, c[0], c[1], True))
            t = value(h["cards"])[0]
            col = ACCENT if (self.phase == "play" and k == self.at) else BAD if t > 21 else GOOD
            out.append(("text", x0 + 40, 300, f"{t}  ·  {money(h['bet'])}", 11, col, "center"))
            out += chip_prims(x0 - 18, 300, h["bet"])
        y = 334
        for line in self.lines[-1:]:
            out.append(("text", 320, y, line, 12, INK, "center"))
        return out

    def bot(self, rng):
        if self.phase == "bet":
            return "deal"
        if self.phase == "play":
            mv = basic(self.hand["cards"], self.dealer[0], self.can_double(), self.can_split())
            if mv == "double" and not self.can_double():
                mv = "hit"
            if mv == "split" and not self.can_split():
                mv = basic(self.hand["cards"], self.dealer[0], self.can_double(), False)
            return mv
        return ""


__all__ = ["Blackjack", "value", "is_blackjack", "settle", "dealer_hits", "basic"]
