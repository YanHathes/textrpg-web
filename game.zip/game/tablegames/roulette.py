"""Roulette, single zero (37 pockets). Inside bets on the numbers, outside bets on the rest:

    Straight (one number) 35 to 1    Split (two side by side) 17 to 1    Street (a row of three) 11 to 1
    Corner (four) 8 to 1             Six line (two rows) 5 to 1
    Red or black, odd or even, 1-18 or 19-36: 1 to 1    A dozen, or a column: 2 to 1
Zero loses every outside bet.

The layout's numbers run in rows of three (1 2 3 / 4 5 6 / ... 34 35 36). Click a number with a kind of
bet chosen to place it there: a split goes with the number to its right (or below, at the right edge), a
corner with the three below and right of it, a street on its row, a six line on its row and the next.

Cheat (Sleight of Hand): past-posting, sliding your biggest bet onto the winning number after the ball drops.
"""
from __future__ import annotations

import math

from game.tablegames.base import ACCENT, BAD, DIM, FELT, GOOD, INK, Table, money

REDS = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}
WHEEL = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22,
         18, 29, 7, 28, 12, 35, 3, 26]
PAYS = {"straight": 35, "split": 17, "street": 11, "corner": 8, "line": 5, "red": 1, "black": 1, "odd": 1,
        "even": 1, "low": 1, "high": 1, "dozen": 2, "column": 2}
INSIDE = ("straight", "split", "street", "corner", "line")


def covers(kind: str, arg: int) -> frozenset:
    """The numbers a bet covers (arg: the number clicked, or which dozen / column, 1-3)."""
    n = arg
    if kind == "straight":
        return frozenset({n})
    if kind == "split":
        if n % 3 != 0:
            return frozenset({n, n + 1})
        return frozenset({n, n + 3}) if n + 3 <= 36 else frozenset({n, n - 3})
    row = (n - 1) // 3 * 3 + 1 if n else 1
    if kind == "street":
        return frozenset({row, row + 1, row + 2})
    if kind == "corner":
        a = n if n % 3 != 0 else n - 1
        a = min(a, 32)
        return frozenset({a, a + 1, a + 3, a + 4})
    if kind == "line":
        r = min(row, 31)
        return frozenset(range(r, r + 6))
    if kind == "red":
        return frozenset(REDS)
    if kind == "black":
        return frozenset(set(range(1, 37)) - REDS)
    if kind == "odd":
        return frozenset(x for x in range(1, 37) if x % 2)
    if kind == "even":
        return frozenset(x for x in range(1, 37) if not x % 2)
    if kind == "low":
        return frozenset(range(1, 19))
    if kind == "high":
        return frozenset(range(19, 37))
    if kind == "dozen":
        return frozenset(range(12 * (arg - 1) + 1, 12 * arg + 1))
    if kind == "column":
        return frozenset(x for x in range(1, 37) if (x - arg) % 3 == 0)
    return frozenset()


def payout(kind: str, nums: frozenset, amount: int, result: int) -> int:
    """What comes back for a bet (stake included), 0 when it loses."""
    return amount * (PAYS[kind] + 1) if result in nums else 0


class Roulette(Table):
    id, title = "roulette", "Roulette"
    help = "Choose a kind of bet, click the layout to place it, then spin. Single zero."
    uses = ""
    cheat_label = "Past-post: slide your biggest bet onto the winner"

    def setup(self) -> None:
        self.mode = "straight"
        self.bets: list[dict] = []            # {"kind", "arg", "nums", "amount"}
        self.phase = "bet"
        self.result = None
        self.spin_t = 0.0
        self.angle, self.ball = 0.0, 0.0
        self.realtime = True
        self.say("Place your bets.")

    def betting(self) -> bool:
        return self.phase == "bet"

    def place(self, kind: str, arg: int) -> bool:
        if self.phase != "bet" or kind not in PAYS:
            return False
        if sum(b["amount"] for b in self.bets) + self.stake > self.ctx.stake_max * 10:
            self.say("That's the table's limit.")
            return False
        if not self.take(self.stake):
            self.say("You haven't the chips.")
            return False
        nums = covers(kind, arg)
        for b in self.bets:
            if b["kind"] == kind and b["nums"] == nums:
                b["amount"] += self.stake
                return True
        self.bets.append({"kind": kind, "arg": arg, "nums": nums, "amount": self.stake})
        return True

    def on(self, action: str) -> None:
        if action.startswith("mode:"):
            self.mode = action[5:]
        elif action.startswith("num:"):
            n = int(action[4:])
            if n == 0:
                self.place("straight", 0)
            else:
                self.place(self.mode, n)
        elif action.startswith("out:"):
            kind, _s, arg = action[4:].partition(":")
            self.place(kind, int(arg or 0))
        elif action == "clear" and self.phase == "bet":
            for b in self.bets:
                self.push(b["amount"])
            self.bets = []
        elif action == "spin" and self.phase == "bet" and self.bets:
            worst = max(payout(b["kind"], b["nums"], b["amount"], n) for n in range(37) for b in self.bets) \
                if self.bets else 0
            if not self.house_can_cover(worst):
                self.say("The house can't cover those bets.")
                return
            self.phase = "spin"
            self.spin_t = 0.0
            self.result = self.rng.randrange(37)
            self.rounds += 1

    def update(self, dt: float) -> None:
        super().update(dt)
        if self.phase == "spin":
            self.spin_t += dt
            speed = max(0.0, 3.0 - self.spin_t)
            self.angle += dt * speed * 2.0
            target = -WHEEL.index(self.result) * 2 * math.pi / 37
            k = min(1.0, self.spin_t / 3.0)
            self.ball = (1 - k) * (self.ball - dt * 6) + k * (self.angle + target)
            if self.spin_t >= 3.2:
                self.resolve()

    def resolve(self) -> None:
        n = self.result
        won = 0
        staked = 0
        for b in self.bets:
            staked += b["amount"]
            back = payout(b["kind"], b["nums"], b["amount"], n)
            if back:
                self.push(b["amount"])
                won += self.pay(back - b["amount"])
            else:
                self.lose(b["amount"])
        colour = "green" if n == 0 else "red" if n in REDS else "black"
        self.say(f"{n} {colour}. " + (f"You win {money(won)}." if won else f"You lose {money(staked)}."))
        self.bets = []
        self.phase = "bet"
        if self.chips < self.ctx.stake_min:
            self.over = True

    def staked(self) -> int:
        return sum(b["amount"] for b in self.bets)

    def can_cheat(self) -> bool:
        return self.phase == "spin" and bool(self.bets) and self.spin_t > 2.0

    def cheat(self) -> str:
        big = max(self.bets, key=lambda b: b["amount"])
        big.update(kind="straight", arg=self.result, nums=frozenset({self.result}))
        self.cheated += 1
        return f"Your hand drifts over the layout: your {money(big['amount'])} sits on {self.result} now."

    def buttons(self):
        b = self.phase == "bet"
        out = [(("> " if self.mode == m else "") + m.capitalize(), f"mode:{m}", b) for m in INSIDE]
        out += [("Spin", "spin", b and bool(self.bets)), ("Clear", "clear", b and bool(self.bets))]
        return out

    # the layout: 12 columns of three numbers (left to right), zero on the left, outside bets below
    def _cell(self, n: int) -> tuple[float, float, float, float]:
        col, row = (n - 1) // 3, 2 - (n - 1) % 3
        return 250 + col * 30, 70 + row * 34, 30, 34

    def boxes(self):
        out = [(220, 70, 30, 102, "num:0")]
        for n in range(1, 37):
            x, y, w, h = self._cell(n)
            out.append((x, y, w, h, f"num:{n}"))
        for i, (k, a) in enumerate((("low", 0), ("even", 0), ("red", 0), ("black", 0), ("odd", 0), ("high", 0))):
            out.append((250 + i * 60, 210, 60, 26, f"out:{k}:{a}"))
        for d in (1, 2, 3):
            out.append((250 + (d - 1) * 120, 176, 120, 30, f"out:dozen:{d}"))
            out.append((610, 70 + (3 - d) * 34, 26, 34, f"out:column:{d}"))
        return out

    def draw(self):
        out = [("felt", 10, 20, 620, 300, FELT)]
        out.append(("wheel", 110, 140, 82, self.angle, self.ball))
        out.append(("rect", 220, 70, 30, 102, "#2c7a4a"))
        out.append(("text", 235, 125, "0", 12, INK, "center"))
        on = {}
        for b in self.bets:
            for n in b["nums"]:
                on[n] = on.get(n, 0) + b["amount"]
        for n in range(1, 37):
            x, y, w, h = self._cell(n)
            out.append(("rect", x + 1, y + 1, w - 2, h - 2, "#9b2b2b" if n in REDS else "#1d1d1d"))
            out.append(("text", x + w / 2, y + 22, str(n), 11, INK, "center"))
            if n in on:
                out.append(("chip", x + w - 8, y + 8, min(10000, on[n])))
        for i, k in enumerate(("1-18", "Even", "Red", "Black", "Odd", "19-36")):
            out.append(("frame", 250 + i * 60, 210, 60, 26, DIM))
            out.append(("text", 280 + i * 60, 228, k, 11, INK, "center"))
        for d in (1, 2, 3):
            out.append(("frame", 250 + (d - 1) * 120, 176, 120, 30, DIM))
            out.append(("text", 310 + (d - 1) * 120, 196, f"{('1st', '2nd', '3rd')[d - 1]} 12", 11, INK, "center"))
            out.append(("frame", 610, 70 + (3 - d) * 34, 26, 34, DIM))
            out.append(("text", 623, 92 + (3 - d) * 34, "2:1", 9, INK, "center"))
        out.append(("text", 430, 262, f"Placing: {self.mode}  ·  on the table: "
                    f"{money(sum(b['amount'] for b in self.bets))}", 11, ACCENT, "center"))
        if self.phase == "bet" and self.result is not None:
            col = GOOD if self.result else BAD
            out.append(("text", 110, 250, f"Last: {self.result}", 14, col, "center"))
        for line in self.lines[-1:]:
            out.append(("text", 320, 334, line, 12, INK, "center"))
        return out

    def bot(self, rng):
        if self.phase != "bet":
            return ""
        if not self.bets:
            return rng.choice(["out:red:0", "out:dozen:2", "num:17", "out:odd:0"])
        return "spin"


__all__ = ["Roulette", "covers", "payout", "PAYS", "REDS", "WHEEL"]
