"""Animals and vehicles: taming, mounts, pack animals, pets and livestock, carts and wagons, boats.

What the party owns is kept in the save's holdings (game/holdings.py, "vehicles"):

    {"id", "kind": "animal" | "vehicle" | "boat", "type": catalogue name, "enemy": stat block id (animals),
     "name", "role": "mount" | "pack" | "pet" | "livestock" (animals), "rider": member id, "pulls": vehicle id,
     "storage": {item id: n}, "home": town id, "sailing_to": town id, "dead": bool, "since": day}

Buying (the SRD's prices): mounts and carts at stables, boats at boatwrights (or a harbour warehouse).

Taming: any beast that isn't fighting the party. Five successful Wisdom (Animal Handling) checks tame it
(a calm-the-animal minigame when Settings > Checks says so); each try takes a few minutes; the DC goes up
with its challenge rating; offering food it likes gives advantage. A failure keeps the progress made;
failing by 5 or more scares it off (a predator turns on you) and that progress is lost. Each success counts
as a use of Animal Handling (game/tools.py).

Travel: a cart or wagon with an animal to pull it, or a mount for everyone, makes road journeys and treks
quicker by its speed (a riding horse's 60 feet against a walker's 30: half the time). An owned boat sails
to coastal towns without buying passage; the bigger ones need a hired crew.

Storage: each has a carrying capacity in pounds. A mount's or cart's opens while you're travelling with it
(on the road, a trek, the wilds); in town it waits at the stable, and opens only there. A boat's opens on
the water, or at the dock where it's moored.

Upkeep: stabling, 5 sp a day for each animal, while the party is in town. Pets come to fights as companions;
a mounted rider fights at the mount's speed (basic SRD mounted combat).
"""
from __future__ import annotations

import math
import random
import zlib

DAY = 1440
WALK_FT = 30
STABLE_SP = 5                       # silver a day for each animal stabled
TAME_SUCCESSES = 5
TAME_MINUTES = 10
SCARE_BY = 5
CREW_WAGE = 2.0                     # gp a day for each hired sailor

# the SRD's mounts: price gp, speed ft, carrying capacity lb, what it's best as
MOUNTS = {"Riding horse": (75, 60, 480, "mount"), "Draft horse": (50, 40, 540, "mount"),
          "Warhorse": (400, 60, 540, "mount"), "Pony": (30, 40, 225, "mount"), "Mule": (8, 40, 420, "pack"),
          "Camel": (50, 50, 480, "mount"), "Mastiff": (25, 40, 195, "pet"), "Elephant": (200, 40, 1320, "mount")}
# vehicles: price gp, carrying capacity lb, weight lb (pulled by an animal)
VEHICLES = {"Cart": (15, 400, 200), "Wagon": (35, 1500, 400), "Sled": (20, 300, 300), "Carriage": (100, 300, 600),
            "Chariot": (250, 200, 100)}
# boats: price gp, speed mph, crew to hire, cargo lb, hours a day under way
BOATS = {"Rowboat": (50, 1.5, 0, 500, 10), "Keelboat": (3000, 1.0, 1, 1000, 10), "Longship": (10000, 3.0, 40, 20000, 24),
         "Sailing ship": (10000, 2.0, 20, 200000, 24), "Galley": (30000, 4.0, 80, 300000, 24),
         "Warship": (25000, 2.5, 60, 400000, 24)}
LIVESTOCK_WORDS = ("goat", "cow", "ox", "sheep", "pig", "chicken", "boar", "yak", "llama", "deer", "elk", "auroch",
                   "mule", "camel", "draft")
HERBIVORE_WORDS = ("horse", "pony", "mule", "camel", "elk", "deer", "goat", "cow", "ox", "sheep", "yak", "llama",
                   "elephant", "mammoth", "moose", "rhino", "auroch", "donkey", "antelope", "giraffe", "hippo")
FOOD_HERB = ("grain", "berry")
FOOD_MEAT = ("meat", "fish")
SIZES = ["Tiny", "Small", "Medium", "Large", "Huge", "Gargantuan"]
CAP_MULT = {"Tiny": 0.5, "Small": 1, "Medium": 1, "Large": 2, "Huge": 4, "Gargantuan": 8}


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


def owned(state, include_dead: bool = False) -> list[dict]:
    h = getattr(state, "holdings", None)
    if h is None:
        return []
    lst = h.setdefault("vehicles", [])
    return [v for v in lst if isinstance(v, dict) and (include_dead or not v.get("dead"))]


def get(state, vid: str) -> dict | None:
    return next((v for v in owned(state, True) if v.get("id") == vid), None)


def _save(world, state) -> None:
    try:
        from game import holdings
        holdings.save(world, state)
    except Exception:  # noqa: BLE001 - a test state with no world folder
        pass
    state.save()


# ----------------------------------------------------------------------------------------------------
# What a thing is
# ----------------------------------------------------------------------------------------------------
def _cr(enemy) -> float:
    from game.constants import cr_value
    try:
        return float(cr_value(enemy.fields.get("cr", "0")))
    except Exception:  # noqa: BLE001
        return 0.0


def is_beast(enemy) -> bool:
    return enemy is not None and "beast" in {str(t).lower() for t in enemy.tags or []}


def tameable(enemy) -> bool:
    """A single beast (not a swarm or a pack)."""
    return is_beast(enemy) and not any(w in enemy.name.lower() for w in ("swarm", "pack", "flock"))


def mount_stats(name: str):
    """The SRD's price, speed, capacity and best role for a mount, by name (any case)."""
    n = (name or "").lower()
    for k, v in MOUNTS.items():
        if k.lower() == n:
            return v
    return None


def speed_ft(world, v: dict) -> int:
    if v["kind"] == "animal":
        if mount_stats(v["type"]):
            return mount_stats(v["type"])[1]
        e = world.entities.get(v.get("enemy") or "")
        return int((e.fields.get("speed") if e is not None else 30) or 30)
    return 0


def capacity(world, v: dict) -> int:
    """How much it carries, in pounds."""
    if v["kind"] == "vehicle":
        return VEHICLES.get(v["type"], (0, 300, 0))[1]
    if v["kind"] == "boat":
        return BOATS.get(v["type"], (0, 0, 0, 500, 10))[3]
    if mount_stats(v["type"]):
        return mount_stats(v["type"])[2]
    e = world.entities.get(v.get("enemy") or "")
    if e is None:
        return 0
    st = int((e.fields.get("stats") or {}).get("str") or 10)
    return int(15 * st * CAP_MULT.get(e.fields.get("size") or "Medium", 1))


def load(world, v: dict) -> float:
    total = 0.0
    for iid, n in (v.get("storage") or {}).items():
        it = world.entities.get(iid)
        if it is not None:
            total += float(it.fields.get("weight") or 0) * int(n)
    return round(total, 1)


def roles_for(world, enemy) -> list[str]:
    """What a tamed beast can be: always a pet; a mount if it's Large or bigger and walks; a pack animal if it's
    strong enough to carry a load; livestock if it's a farm sort of creature."""
    out = ["pet"]
    if enemy is None:
        return out
    size = enemy.fields.get("size") or "Medium"
    big = SIZES.index(size) >= SIZES.index("Large") if size in SIZES else False
    st = int((enemy.fields.get("stats") or {}).get("str") or 10)
    walks = int(enemy.fields.get("speed") or 0) >= 30
    name = enemy.name.lower()
    if (big or name in ("pony", "mule")) and walks:
        out.append("mount")
    if (big or st >= 14 or name in ("mule", "pony", "donkey")) and walks:
        out.append("pack")
    if any(w in name for w in LIVESTOCK_WORDS):
        out.append("livestock")
    return out


ROLE_WORDS = {"mount": "a mount", "pack": "a pack animal", "pet": "a pet", "livestock": "livestock"}


# ----------------------------------------------------------------------------------------------------
# Buying and selling
# ----------------------------------------------------------------------------------------------------
def shop(world, building) -> list[dict]:
    """What a stable or a boatwright sells: [{"kind", "type", "price", "enemy"}]."""
    if building is None:
        return []
    k = building.fields.get("kind") or ""
    town = world.entities.get(building.fields.get("town") or "")
    tier = (town.fields.get("kind") if town is not None else "") or "Village"
    big = tier in ("Town", "City", "Capital")
    land = (town.fields.get("terrain") if town is not None else "") or "Plains"
    out = []
    if k == "Stable":
        for name in ("Riding horse", "Draft horse", "Pony", "Mule", "Mastiff"):
            out.append(_offer_animal(world, name))
        if land in ("Desert", "Badlands", "Savanna") or "desert" in str(land).lower():
            out.append(_offer_animal(world, "Camel"))
        if tier in ("City", "Capital"):
            out.append(_offer_animal(world, "Warhorse"))
            out.append(_offer_animal(world, "Elephant") if land in ("Jungle", "Savanna") else None)
        for name in ("Cart", "Wagon") + (("Sled",) if land in ("Arctic", "Tundra", "Taiga", "Mountains") else ()) + \
                (("Carriage",) if big else ()) + (("Chariot",) if tier in ("City", "Capital") else ()):
            out.append({"kind": "vehicle", "type": name, "price": VEHICLES[name][0], "enemy": ""})
    if k == "Boatwright" or (k == "Warehouse" and (land == "Coast" or "Dock" in (building.fields.get("facilities") or []))):
        names = ["Rowboat", "Keelboat"] + (["Sailing ship", "Longship"] if big else []) + \
            (["Galley", "Warship"] if tier == "Capital" else [])
        for name in names:
            out.append({"kind": "boat", "type": name, "price": BOATS[name][0], "enemy": ""})
    return [o for o in out if o]


def _offer_animal(world, name: str) -> dict | None:
    e = world.entities.find_by_name("enemy", name)
    return {"kind": "animal", "type": name, "price": MOUNTS[name][0], "enemy": e.id if e is not None else ""}


def is_stable(building) -> bool:
    return building is not None and (building.fields.get("kind") or "") == "Stable"


def is_dock(world, building) -> bool:
    if building is None:
        return False
    k = building.fields.get("kind") or ""
    if k == "Boatwright" or "Dock" in (building.fields.get("facilities") or []):
        return True
    town = world.entities.get(building.fields.get("town") or "")
    return k == "Warehouse" and town is not None and (town.fields.get("terrain") or "") == "Coast"


def buy(world, state, offer: dict, name: str = "", town_id: str = "") -> tuple[bool, str, dict | None]:
    cost = int(offer["price"]) * 100
    if cost > state.copper:
        from game.state import money_text
        return False, f"That costs {money_text(cost)}. You can't afford it.", None
    state.add_copper(-cost, f"bought a {offer['type'].lower()}")
    role = MOUNTS[offer["type"]][3] if offer["kind"] == "animal" else ""
    v = {"id": state.next_id("v"), "kind": offer["kind"], "type": offer["type"], "enemy": offer.get("enemy") or "",
         "name": name or offer["type"], "role": role, "rider": "", "pulls": "", "storage": {},
         "home": town_id, "since": state.day, "dead": False}
    state.holdings.setdefault("vehicles", []).append(v)
    _start_stabling(state)
    _save(world, state)
    return True, f"You buy {_a(offer['type'])}. " + _what_now(v), v


def _a(word: str) -> str:
    return ("an " if word[:1].lower() in "aeiou" else "a ") + word.lower()


def _what_now(v: dict) -> str:
    if v["kind"] == "boat":
        return "It's moored at the dock."
    if v["kind"] == "vehicle":
        return "It needs an animal to pull it."
    return f"It's {ROLE_WORDS.get(v.get('role'), 'yours')}."


def sell_price(world, v: dict) -> int:
    """Copper: half what it cost new (a tamed beast: what a stable would ask for its kind, halved)."""
    if v["kind"] == "vehicle":
        p = VEHICLES.get(v["type"], (10,))[0]
    elif v["kind"] == "boat":
        p = BOATS.get(v["type"], (10,))[0]
    else:
        p = (mount_stats(v["type"]) or (0,))[0]
        if not p:
            e = world.entities.get(v.get("enemy") or "")
            p = max(5, int(10 + _cr(e) * 40)) if e is not None else 5
    return int(p * 50)


def sell(world, state, vid: str) -> tuple[bool, str]:
    v = get(state, vid)
    if v is None:
        return False, "That isn't yours."
    if v.get("storage"):
        return False, "Empty it first."
    pay = sell_price(world, v)
    state.holdings["vehicles"] = [x for x in owned(state, True) if x.get("id") != vid]
    for x in owned(state):
        if x.get("pulls") == vid:
            x["pulls"] = ""
    state.add_copper(pay, f"sold {v['name']}")
    _save(world, state)
    from game.state import money_text
    return True, f"Sold {v['name']} for {money_text(pay)}."


def release(world, state, vid: str) -> str:
    v = get(state, vid)
    if v is None:
        return ""
    for iid, n in (v.get("storage") or {}).items():
        state.add_item(iid, n, source="unloaded")
    state.holdings["vehicles"] = [x for x in owned(state, True) if x.get("id") != vid]
    _save(world, state)
    return f"You let {v['name']} go."


def rename(world, state, vid: str, name: str) -> None:
    v = get(state, vid)
    if v is not None and name.strip():
        v["name"] = name.strip()[:40]
        _save(world, state)


def set_role(world, state, vid: str, role: str) -> tuple[bool, str]:
    v = get(state, vid)
    if v is None or v["kind"] != "animal":
        return False, "Only animals have roles."
    allowed = roles_for(world, world.entities.get(v.get("enemy") or "")) if v.get("enemy") else \
        [(mount_stats(v["type"]) or (0, 0, 0, "pet"))[3], "pet"]
    if mount_stats(v["type"]) and role in ("mount", "pack", "pet"):
        allowed = list(dict.fromkeys(allowed + ["mount", "pack"]))
    if role not in allowed:
        return False, f"{v['name']} can't be {ROLE_WORDS.get(role, role)}."
    v["role"] = role
    if role != "mount":
        v["rider"] = ""
    _save(world, state)
    return True, f"{v['name']} is now {ROLE_WORDS[role]}."


def assign_rider(world, state, vid: str, member_id: str) -> tuple[bool, str]:
    v = get(state, vid)
    if v is None or v.get("role") != "mount":
        return False, "That isn't a mount."
    for x in owned(state):
        if x.get("rider") == member_id and x is not v:
            x["rider"] = ""
    v["rider"] = member_id
    v["pulls"] = ""
    _save(world, state)
    return True, "Mounted." if member_id else "Nobody rides it now."


def hitch(world, state, animal_id: str, vehicle_id: str) -> tuple[bool, str]:
    a, veh = get(state, animal_id), get(state, vehicle_id)
    if a is None or a["kind"] != "animal" or (veh is not None and veh["kind"] != "vehicle"):
        return False, "That can't pull that."
    if veh is not None and not set(roles_for(world, world.entities.get(a.get("enemy") or ""))) & {"mount", "pack"} \
            and not mount_stats(a["type"]):
        return False, f"{a['name']} isn't strong enough to pull it."
    for x in owned(state):
        if x.get("pulls") == vehicle_id:
            x["pulls"] = ""
    a["pulls"] = vehicle_id if veh is not None else ""
    a["rider"] = ""
    _save(world, state)
    return True, f"{a['name']} is hitched to the {veh['name'].lower()}." if veh else f"{a['name']} is unhitched."


# ----------------------------------------------------------------------------------------------------
# Where things are, and their storage
# ----------------------------------------------------------------------------------------------------
def _spot(world, state):
    from game import places
    return places.current(world, state)


def in_town(spot) -> bool:
    return spot.kind in ("street", "building")


def parked(state) -> dict | None:
    """Where the party got down and left its mount (cart, wagon or horses): {"area", "level", "x", "y",
    "facing", "kind", "ids"}, or None while it rides (or has nothing to ride)."""
    pk = (getattr(state, "holdings", None) or {}).get("parked")
    return pk if isinstance(pk, dict) and pk.get("ids") else None


def park(world, state, area_key: str, level: str, x: int, y: int, facing: str, kind: str) -> dict:
    """Leave what the party rides (its cart or wagon and what pulls it, or its mounts and pack animals) on
    this square of the walking map. Pets keep following the party."""
    ids = [v["id"] for v in owned(state) if where(world, state, v) == "with" and
           (v["kind"] == "vehicle" or (v["kind"] == "animal" and v.get("role") in ("mount", "pack")))]
    pk = {"area": area_key, "level": level, "x": int(x), "y": int(y), "facing": facing, "kind": kind, "ids": ids}
    state.holdings["parked"] = pk
    _save(world, state)
    return pk


def unpark(world, state) -> None:
    """The party's back up on its mount: it travels with them again."""
    state.holdings["parked"] = {}
    _save(world, state)


def where(world, state, v: dict) -> str:
    """"with" (travelling with the party), "aboard" (in the hold of the ship the party's on), "stable:<town id>"
    or "dock:<town id>". Animals and carts go wherever the party goes, and wait at the stable in town; boats
    stay moored where they were left."""
    if v.get("route"):                          # out on a trade route with its hired crew (game/trade.py)
        return "away"
    pk = parked(state)
    if pk is not None and v["id"] in pk["ids"]:  # left standing where the party got down
        return "parked"
    spot = _spot(world, state)
    if v["kind"] == "boat":
        j = state.journey or {}
        if j.get("kind") == "voyage" and j.get("own") == v["id"]:
            return "with"
        if v.get("sailing_to"):
            moored(world, state, v["id"], v["sailing_to"], save=False)
        return f"dock:{v.get('home') or ''}"
    if spot.kind == "voyage":
        return "aboard"
    if in_town(spot) and spot.town is not None:
        v["home"] = spot.town.id
        return f"stable:{spot.town.id}"
    return "with"


def moored(world, state, vid: str, town_id: str, save: bool = True) -> None:
    """An owned boat has come in to a town's harbour."""
    v = get(state, vid)
    if v is None:
        return
    v["home"] = town_id
    v.pop("sailing_to", None)
    if save:
        _save(world, state)


def storage_open(world, state, v: dict) -> tuple[bool, str]:
    """Can the party get at its storage here? Travelling with it (a mount or a cart on the road or in the
    wilds; a boat on the water), or at the stable or dock where it waits."""
    w = where(world, state, v)
    spot = _spot(world, state)
    if w == "with":
        if spot.kind == "dungeon" and v["kind"] != "boat":
            return False, f"{v['name']} waits outside."
        return True, ""
    if w == "aboard":
        return False, f"{v['name']} is in the ship's hold until you land."
    if w == "parked":
        return False, f"{v['name']} is where you left it: climb back on to get at what it carries."
    if w == "away":
        return False, f"{v['name']} is out on a trade route."
    b = spot.building if spot.kind == "building" else None
    if w.startswith("stable:"):
        if b is not None and is_stable(b) and (b.fields.get("town") or "") == w.split(":", 1)[1]:
            return True, ""
        return False, f"{v['name']} is at the stable: go there to load or unload it."
    if b is not None and is_dock(world, b) and (b.fields.get("town") or "") == w.split(":", 1)[1]:
        return True, ""
    home = world.entities.get(w.split(":", 1)[1])
    return False, f"{v['name']} is moored at {home.name if home else 'the dock'}: go to the docks there."


def put(world, state, vid: str, item_id: str, n: int = 1) -> tuple[bool, str]:
    """From the party's pack into its storage."""
    v = get(state, vid)
    if v is None:
        return False, "That isn't yours."
    ok, why = storage_open(world, state, v)
    if not ok:
        return False, why
    it = world.entities.get(item_id)
    if it is None or state.count(item_id) <= 0:
        return False, "You don't have that."
    n = min(n, state.count(item_id))
    w = float(it.fields.get("weight") or 0)
    room = capacity(world, v) - load(world, v)
    if w > 0:
        n = min(n, int(room // w))
    if n <= 0:
        return False, f"{v['name']} can't carry any more."
    state.remove_item(item_id, n, reason=f"stowed on {v['name']}")
    st = v.setdefault("storage", {})
    st[item_id] = st.get(item_id, 0) + n
    _save(world, state)
    return True, f"Stowed {it.name}" + (f" x{n}" if n > 1 else "") + "."


def take(world, state, vid: str, item_id: str, n: int = 1) -> tuple[bool, str]:
    v = get(state, vid)
    if v is None:
        return False, "That isn't yours."
    ok, why = storage_open(world, state, v)
    if not ok:
        return False, why
    st = v.setdefault("storage", {})
    have = int(st.get(item_id, 0))
    if have <= 0:
        return False, "It isn't there."
    n = min(n, have)
    if have - n > 0:
        st[item_id] = have - n
    else:
        st.pop(item_id, None)
    state.add_item(item_id, n, source=f"from {v['name']}")
    _save(world, state)
    it = world.entities.get(item_id)
    return True, f"Took {it.name if it else item_id}" + (f" x{n}" if n > 1 else "") + "."


def open_stores(world, state) -> list[dict]:
    """Every storage the party can get at right now."""
    return [v for v in owned(state) if (v.get("kind") != "animal" or (v.get("role") in ("mount", "pack")
                                                                       and not v.get("pulls")))
            and capacity(world, v) > 0 and storage_open(world, state, v)[0]]


# ----------------------------------------------------------------------------------------------------
# Travel
# ----------------------------------------------------------------------------------------------------
def travel_factor(world, state, members) -> float:
    """How much faster the party goes on roads and treks: a cart or wagon pulled by an animal (everyone rides
    in it), or a mount for everyone; the slowest sets the pace. 1.0 on foot."""
    alive = [m for m in members or [] if not m.get("dead")]
    if not alive:
        return 1.0
    mine = [v for v in owned(state) if where(world, state, v) == "with"]
    if world.rules.get("survival"):                  # a hungry animal plods (game/survival.py)
        from game import survival
        mine = [v for v in mine if v["kind"] != "animal" or not survival.hungry_animal(state, v["id"])]
    best = 1.0
    for veh in [v for v in mine if v["kind"] == "vehicle"]:
        pullers = [a for a in mine if a["kind"] == "animal" and a.get("pulls") == veh["id"]]
        if pullers:
            best = max(best, min(speed_ft(world, a) for a in pullers) / WALK_FT)
    riders = {v.get("rider"): v for v in mine if v["kind"] == "animal" and v.get("role") == "mount" and v.get("rider")}
    if all(m.get("id") in riders for m in alive):
        best = max(best, min(speed_ft(world, riders[m["id"]]) for m in alive) / WALK_FT)
    return round(best, 3)


def ride_kind(world, state, members) -> str:
    """What the party is seen travelling in on the map (game/art/vehicles.py): 'cart', 'wagon', 'horse' or ''."""
    mine = [v for v in owned(state) if where(world, state, v) == "with"]
    for veh in [v for v in mine if v["kind"] == "vehicle"]:
        if any(a.get("pulls") == veh["id"] for a in mine):
            return "cart" if veh["type"] in ("Cart", "Chariot") else "wagon"
    alive = [m for m in members or [] if not m.get("dead")]
    if alive and all(any(v.get("rider") == m.get("id") for v in mine) for m in alive):
        return "horse"
    return ""


# ----------------------------------------------------------------------------------------------------
# Boats
# ----------------------------------------------------------------------------------------------------
def boats(state) -> list[dict]:
    return [v for v in owned(state) if v["kind"] == "boat"]


def coastal(world, town, g=None) -> bool:
    """Is a town on the water (the coast, or a lake shore)? g: the world's terrain grid, when asking about many."""
    from game import geography as G
    if town is None:
        return False
    if (town.fields.get("terrain") or "") in ("Coast",):
        return True
    p = G.town_position(world, town)
    if p is None:
        return False
    g = g or G.terrain(world)
    for dx, dy in ((0, 0), (g.cell, 0), (-g.cell, 0), (0, g.cell), (0, -g.cell)):
        if g.biome_at(p[0] + dx, p[1] + dy) in ("Ocean", "Lake"):
            return True
    return False


def routes(world, state, boat: dict, town=None, limit: int = 10) -> list[dict]:
    """Where an owned boat can sail from here: coastal towns, nearest first, with the days it takes and the
    crew's wages. Known sea passages (game/passage.py) from here count too."""
    from game import geography as G
    from game import passage
    town = town or world.entities.get(boat.get("home") or "")
    if town is None:
        return []
    price, mph, crew, _cargo, hours = BOATS.get(boat["type"], BOATS["Rowboat"])
    p0 = G.town_position(world, town)
    cands = {}
    for o in passage.known(world, state):
        if o.get("from") is not None and o["from"].id == town.id and (o.get("method") or "Boat") == "Boat":
            cands[o["to"].id] = o["to"]
    if p0 is not None:
        near = []
        for t in world.entities.all("town"):
            if t.id == town.id:
                continue
            p = G.town_position(world, t)
            if p is None:
                continue
            d = math.hypot(p[0] - p0[0], p[1] - p0[1])
            if d > 400 or (G.continent_of_town(world, t) is not G.continent_of_town(world, town) and d > 250):
                continue
            near.append((d, t))
        near.sort(key=lambda x: x[0])
        g = G.terrain(world)
        for d, t in near:
            if len(cands) >= limit:
                break
            if coastal(world, t, g):
                cands.setdefault(t.id, t)
    out = []
    for t in cands.values():
        p = G.town_position(world, t)
        miles = math.hypot(p[0] - p0[0], p[1] - p0[1]) * 1.3 if (p and p0) else 100
        days = max(1, math.ceil(miles / (mph * hours)))
        out.append({"to": t, "days": days, "miles": round(miles), "crew": crew,
                    "wages": int(round(crew * CREW_WAGE * days * 100)), "boat": boat})
    return sorted(out, key=lambda r: r["days"])


def sail(world, state, boat: dict, route: dict, bus=None) -> tuple[bool, str]:
    """Set off in your own boat: no passage to buy, but the crew to pay."""
    from game import passage, places
    if state.journey:
        return False, "You're already travelling."
    spot = places.current(world, state)
    home = world.entities.get(boat.get("home") or "")
    if home is None or spot.town is None or spot.town.id != home.id:
        return False, f"{boat['name']} is moored at {home.name if home else 'another town'}."
    if route["wages"] > state.copper:
        from game.state import money_text
        return False, f"The crew wants {money_text(route['wages'])} for the trip. You can't afford it."
    if route["wages"]:
        state.add_copper(-route["wages"], "the crew's wages")
    dest = route["to"]
    state.trek = None
    state.journey = {"kind": "voyage", "method": "Boat", "from": home.id, "to": dest.id, "days": route["days"],
                     "done": 0, "danger": 25 if boat["type"] in ("Rowboat", "Keelboat") else 35, "npc": "",
                     "hours": route["days"] * 24.0, "own": boat["id"]}
    boat["sailing_to"] = dest.id
    places.enter(world, state, passage.voyage_id(home.id, dest.id), bus)
    text = f"You cast off in {boat['name']}, bound for {dest.name}. It's {route['days']} day" + \
        ("s" if route["days"] != 1 else "") + " away" + (f", with a hired crew of {route['crew']}." if route["crew"] else ".")
    _save(world, state)
    if bus is not None:
        bus.emit("log", kind="narration", text=text)
        bus.emit("voyage.started", journey=dict(state.journey))
    return True, text


# ----------------------------------------------------------------------------------------------------
# Upkeep (the ticker)
# ----------------------------------------------------------------------------------------------------
def _start_stabling(state) -> None:
    state.ticks.setdefault("stabling", state.minutes)


def _stabling(world, state, since: int, now: int) -> None:
    """Stabling at 5 sp a day for each animal while the party is in town (paid as the days go)."""
    try:
        spot = _spot(world, state)
    except Exception:  # noqa: BLE001
        return
    if not in_town(spot) or spot.town is None:
        return
    if any(b.fields.get("kind") == "Stable" and b.fields.get("status") == "done"
                                     and b.fields.get("town") == spot.town.id
                                     for b in world.entities.overlay_entities() if b.type == "building"):
        return                                   # your own stable in town (game/estate.py): kept for free
    beasts = [v for v in owned(state) if v["kind"] == "animal"]
    if not beasts:
        return
    h = state.holdings
    owed = float(h.get("bank", {}).get("stabling_owed", 0) or 0) if isinstance(h.get("bank"), dict) else 0.0
    owed += len(beasts) * STABLE_SP * 10 * (now - since) / DAY
    whole = int(owed)
    if whole > 0:
        pay = min(whole, state.copper)
        if pay:
            state.copper -= pay
        owed -= pay
    if isinstance(h.get("bank"), dict):
        h["bank"]["stabling_owed"] = round(owed, 3)


# ----------------------------------------------------------------------------------------------------
# Taming
# ----------------------------------------------------------------------------------------------------
def tame_dc(enemy) -> int:
    """10, plus two for each point of challenge rating (half a point for the weakest)."""
    return min(25, 10 + int(math.ceil(_cr(enemy) * 2)))


def predator(enemy) -> bool:
    n = enemy.name.lower()
    if any(w in n for w in HERBIVORE_WORDS):
        return False
    atts = " ".join(str(a.get("name") or "") for a in enemy.fields.get("attacks") or []).lower()
    return any(w in atts for w in ("bite", "claw", "talon", "sting"))


def likes(world, enemy) -> list[str]:
    """Food it likes (item ids)."""
    tags = FOOD_MEAT if predator(enemy) else FOOD_HERB
    out = []
    for i in world.entities.all("item"):
        t = {str(x).lower() for x in i.tags or []}
        if t & set(tags) and not t & {"magic", "fibre"}:
            out.append(i.id)
    return out


def taming(state) -> dict:
    return state.taming


def tame_try(world, state, members, enemy, key: str, rng: random.Random | None = None, bus=None,
             offer_food: bool = True) -> dict:
    """One try at taming. {"result": "progress" | "tamed" | "fail" | "fled" | "angry", "successes", "text",
    "food": item used}. Five successes tame it; failing by 5 or more loses it (a predator turns on you)."""
    from game import checks, condition, tools
    rng = rng or random.Random()
    if not tameable(enemy):
        return {"result": "fail", "successes": 0, "text": f"{enemy.name} can't be tamed."}
    opt = next((o for o in checks.options(world) if o["label"] == "Animal Handling"), None)
    best = None
    for m in members or []:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        b = checks.bonus(world, m, c, opt)[0] if opt else c.mods.get("wis", 0)
        if best is None or b > best[2]:
            best = (m, c, b)
    if best is None:
        return {"result": "fail", "successes": 0, "text": "Nobody can do that."}
    m, c, _b = best
    food = ""
    if offer_food:
        mine = set(likes(world, enemy))
        food = next((i for i in sorted(state.inventory) if i in mine and state.count(i) > 0), "")
    if food:
        state.remove_item(food, 1, reason=f"offered to the {enemy.name.lower()}")
    dc = tame_dc(enemy)
    state.advance(TAME_MINUTES, "taming")
    if opt is not None:
        r = checks.roll(world, m, c, opt, dc, mode="advantage" if food else "normal", rng=rng, bus=bus,
                        target=f"calming the {enemy.name.lower()}", context="")
    else:
        roll = max(rng.randint(1, 20), rng.randint(1, 20)) if food else rng.randint(1, 20)
        r = {"total": roll + _b, "success": roll + _b >= dc}
    mem = taming(state)
    got = int(mem.get(key, 0))
    fname = world.entities.get(food).name.lower() if food else ""
    if r.get("success"):
        got += 1
        mem[key] = got
        key_skill = opt["id"] if opt is not None else ""
        if key_skill:
            tools.record_use(world, m, key_skill, 1, bus)
        if got >= TAME_SUCCESSES:
            mem.pop(key, None)
            state.save()
            return {"result": "tamed", "successes": got, "member": m, "food": food,
                    "text": f"{m.get('name')} calms the {enemy.name.lower()}" + (f" with {fname}" if food else "") +
                            ". It's tame: it trusts you now."}
        state.save()
        return {"result": "progress", "successes": got, "member": m, "food": food,
                "text": f"{m.get('name')} edges closer to the {enemy.name.lower()}" + (f", holding out {fname}" if food else "")
                        + f". It lets them ({got} of {TAME_SUCCESSES})."}
    short = dc - int(r.get("total") or 0)
    if short >= SCARE_BY:
        mem.pop(key, None)
        state.save()
        if predator(enemy):
            return {"result": "angry", "successes": 0, "member": m, "food": food,
                    "text": f"The {enemy.name.lower()} snarls and turns on {m.get('name')}!"}
        return {"result": "fled", "successes": 0, "member": m, "food": food,
                "text": f"The {enemy.name.lower()} startles and bolts. It's gone."}
    state.save()
    return {"result": "fail", "successes": got, "member": m, "food": food,
            "text": f"The {enemy.name.lower()} shies away from {m.get('name')}, but doesn't run ({got} of {TAME_SUCCESSES})."}


def find_wild(world, state, members, rng: random.Random | None = None, bus=None) -> object | None:
    """Look about for an animal to tame (half an hour): a beast of this land, weak enough to approach."""
    from game import geography as G
    from game import neighborhood as NB
    rng = rng or random.Random()
    state.advance(30, "looking for animals")
    land = "Plains"
    try:
        pos = G.party_position(world, state)
        if pos is not None:
            land = G.biome_at(world, *pos)
    except Exception:  # noqa: BLE001
        pass
    land = {"Ocean": "Coast", "Lake": "Coast"}.get(land, land)
    top = max(0.25, NB.party_level(members) / 2)
    cands = [e for e in world.entities.all("enemy") if tameable(e) and _cr(e) <= top
             and land.lower() in {str(x).lower() for x in e.fields.get("environments") or []}]
    if not cands or rng.random() < 0.35:
        return None
    return rng.choice(cands)


def activities(world, state, spot) -> list[dict]:
    """What the places panel offers about animals here."""
    out = []
    b = spot.building if spot.kind == "building" else None
    mine = owned(state)
    if b is not None and is_stable(b):
        out.append({"label": "The stable: buy, sell and see to your animals", "target": "animals", "enabled": True,
                    "note": "mounts, pack animals, carts and wagons", "group": "Here"})
    elif b is not None and is_dock(world, b):
        out.append({"label": "Boats: buy, sell and sail", "target": "animals", "enabled": True,
                    "note": "your own boat needs no passage", "group": "Here"})
    elif mine and spot.kind not in ("nowhere",):
        out.append({"label": "Your animals and vehicles", "target": "animals", "enabled": True,
                    "note": f"{len(mine)} of them", "group": "Here"})
    if spot.kind in ("wild", "hex", "road", "landmark"):
        out.append({"label": "Look for animals to tame (30 min)", "target": "tame:look", "enabled": True,
                    "note": "Animal Handling", "group": "Here"})
    return out


def adopt(world, state, enemy, role: str = "", name: str = "") -> dict:
    """A tamed beast joins the party's animals."""
    roles = roles_for(world, enemy)
    role = role if role in roles else ("mount" if "mount" in roles else roles[0])
    spot = _spot(world, state)
    v = {"id": state.next_id("v"), "kind": "animal", "type": enemy.name, "enemy": enemy.id, "name": name or enemy.name,
         "role": role, "rider": "", "pulls": "", "storage": {}, "home": spot.town.id if spot.town is not None else "",
         "since": state.day, "dead": False, "tamed": True}
    state.holdings.setdefault("vehicles", []).append(v)
    _start_stabling(state)
    _save(world, state)
    return v


# ----------------------------------------------------------------------------------------------------
# Fights: companions and mounts
# ----------------------------------------------------------------------------------------------------
def companions(world, state) -> list[dict]:
    """Pets that come along and fight beside the party (those travelling with it, or in town with it)."""
    return [v for v in owned(state) if v["kind"] == "animal" and v.get("role") == "pet" and v.get("enemy")
            and world.entities.get(v["enemy"]) is not None]


def mount_of(world, state, member_id: str) -> dict | None:
    return next((v for v in owned(state) if v["kind"] == "animal" and v.get("role") == "mount"
                 and v.get("rider") == member_id and where(world, state, v) == "with"), None)


def died(world, state, vid: str) -> str:
    v = get(state, vid)
    if v is None:
        return ""
    v["dead"] = True
    for iid, n in (v.get("storage") or {}).items():
        state.add_item(iid, n, source="recovered")
    v["storage"] = {}
    _save(world, state)
    return f"{v['name']} is dead."


def _register() -> None:
    from game import ticker
    ticker.register("stabling", _stabling)


_register()

__all__ = ["owned", "get", "shop", "buy", "sell", "release", "rename", "set_role", "assign_rider", "hitch", "where",
           "storage_open", "put", "take", "open_stores", "capacity", "load", "travel_factor", "ride_kind", "boats",
           "routes", "sail", "tame_try", "find_wild", "activities", "moored", "tame_dc", "adopt", "roles_for", "companions", "mount_of", "died",
           "is_beast", "tameable", "mount_stats", "predator", "likes", "MOUNTS", "VEHICLES", "BOATS", "TAME_SUCCESSES"]
