"""Where NPCs are through the day, and who they know.

Schedule (NPC field "schedule"): rows of From / To (24-hour times, a row may run past midnight),
Where (a building or a town) and what they're doing. Hours no row covers: at work while their
building is open, at home (NPC field "home") when it's closed. Without a home they stay at work.
World rule npc_schedules turns all of this off (everyone stays where they're placed).

The watch (step 11): guards with no schedule of their own walk their town's streets by day, two hours on and
two off, and when a crime is seen in their town they come to where it happened for the next hour.

Relationships (NPC field "relationships"): rows of Who / Is their / Note. They're read both ways:
if Mara lists Tobin as her Child, Tobin sees Mara as his Parent.
"""
from __future__ import annotations

import re

from game.constants import RELATIONSHIP_REVERSE

FAMILY = {"Parent", "Child", "Sibling", "Spouse", "Partner"}
CLOSE = FAMILY | {"Friend", "Mentor", "Student"}
_TIME = re.compile(r"^\s*(\d{1,2})(?::(\d{2}))?\s*$")


def parse_time(text) -> int | None:
    m = _TIME.match(str(text or ""))
    if not m:
        return None
    h, mins = int(m.group(1)), int(m.group(2) or 0)
    if h > 24 or mins > 59:
        return None
    return (h * 60 + mins) % (24 * 60)


def _covers(row: dict, minute: int) -> bool:
    a, b = parse_time(row.get("from")), parse_time(row.get("to"))
    if a is None or b is None or a == b:
        return False
    return a <= minute < b if a < b else (minute >= a or minute < b)


def enabled(world) -> bool:
    return bool(world.rules.get("npc_schedules", True))


def scheduled_row(npc, minute: int) -> dict | None:
    for row in npc.fields.get("schedule") or []:
        if row.get("place") and _covers(row, minute):
            return row
    return None


def where_now(world, npc, minute: int) -> str:
    """The location string where this NPC is at that minute of the day."""
    from game import places
    if npc is None:
        return ""
    work = places.building_of(world, npc)
    if not enabled(world):
        return places.where_is(world, npc)
    from game import destruction
    out = destruction.displaced(world, npc, minute)      # their place is a ruin: rebuilding it, sleeping rough
    if out:
        return out
    if (npc.fields.get("occupation") or "") == "Guard":
        watch = _watch(world, npc, minute)
        if watch:
            return watch
    hired = _hired_at(world, npc, minute)
    if hired:
        return hired
    row = scheduled_row(npc, minute)
    if row is not None:
        place = world.entities.get(row["place"])
        if place is not None and place.type == "building":
            return place.id
        if place is not None and place.type == "town":
            street = npc.fields.get("street") or places.first_street(place)
            names = [s["name"] for s in places.streets_of(place)]
            return places.street_id(place.id, street if street in names else names[0])
    work_b = world.entities.get(work)
    home = world.entities.get(npc.fields.get("home") or "")
    if work_b is not None and home is not None and home.id != work_b.id and not places.is_open(work_b, minute):
        return home.id
    if work_b is None and home is not None and not npc.fields.get("town"):
        return home.id
    return places.where_is(world, npc)


def _hired_at(world, npc, minute: int) -> str:
    """A hand the party hired walks to the building they're put to work at, in working hours (game/estate.py)."""
    st = getattr(world, "_state_for_places", None)
    h = getattr(st, "holdings", None) if st is not None else None
    if not h or not h.get("workers"):
        return ""
    from game import estate
    bid = estate.assigned_building(world, npc.id)
    return bid if bid and estate.at_work(minute) and world.entities.get(bid) is not None else ""


PATROL_HOURS = (8, 20)          # guards walk the streets by day, two hours on and two off


def _watch(world, npc, minute: int) -> str:
    """Where the watch is: answering an alarm (a crime seen in their town in the last hour: game/law.py), or
    walking a street of their town on patrol. "" to go by their schedule."""
    import zlib
    from game import places
    town_id = npc.fields.get("town") or ""
    if not town_id:                                  # most people's town is their workplace's
        b = world.entities.get(places.building_of(world, npc) or "")
        town_id = (b.fields.get("town") or "") if b is not None else ""
    st = getattr(world, "_state_for_places", None)
    raid = (getattr(st, "events", None) or {}).get("raid") if st is not None else None
    if raid and raid.get("status") == "on" and raid.get("town") == town_id and raid.get("at"):
        return raid["at"]                            # the guard turns out at the gate the raiders came by
    alarm = (getattr(st, "law", None) or {}).get("alarm") if st is not None else None
    if alarm and alarm.get("town") == town_id and st.minutes < int(alarm.get("until", 0)) and alarm.get("at"):
        return alarm["at"]
    if scheduled_row(npc, minute) is not None:
        return ""
    lo, hi = PATROL_HOURS
    h = minute // 60
    if not (lo <= h < hi):
        return ""
    k = zlib.crc32(npc.id.encode("utf-8"))
    if (h // 2 + k) % 2:
        return ""
    town = world.entities.get(town_id)
    names = [x["name"] for x in places.streets_of(town)] if town is not None else []
    if not names:
        return ""
    return places.street_id(town.id, names[(k + h // 2) % len(names)])


def activity_now(npc, minute: int) -> str:
    row = scheduled_row(npc, minute)
    return str(row.get("activity") or "") if row else ""


def candidates(world, place_id: str) -> list:
    """NPCs whose schedule or home can bring them to a building or town."""
    store = world.entities
    out = {}
    for n in store.by_field("npc", "place", place_id) + store.by_field("npc", "home", place_id):
        out.setdefault(n.id, n)
    return [out[k] for k in sorted(out)]


# ======================================================================
# Relationships
# ======================================================================
def relations(world, npc) -> list[tuple]:
    """[(other NPC, what the other is to this NPC, note)], from both sides."""
    if npc is None:
        return []
    out = []
    seen = set()
    for row in npc.fields.get("relationships") or []:
        other = world.entities.get(row.get("npc") or "")
        if other is not None and other.type == "npc" and other.id != npc.id:
            out.append((other, row.get("kind") or "Friend", row.get("note") or ""))
            seen.add(other.id)
    for other in sorted(world.entities.by_field("npc", "rel", npc.id), key=lambda e: e.id):
        if other.id in seen or other.id == npc.id:
            continue
        for row in other.fields.get("relationships") or []:
            if row.get("npc") == npc.id:
                kind = row.get("kind") or "Friend"
                out.append((other, RELATIONSHIP_REVERSE.get(kind, kind), row.get("note") or ""))
                seen.add(other.id)
                break
    return out


def word_for(kind: str, other) -> str:
    """'Sibling' -> 'sister' / 'brother' when the NPC's look says, else the plain word."""
    look = other.fields.get("appearance") or {}
    female = str(look.get("body") or look.get("sex") or "").lower() in ("female", "woman", "f")
    words = {"Parent": ("mother", "father"), "Child": ("daughter", "son"), "Sibling": ("sister", "brother"),
             "Spouse": ("wife", "husband")}
    if kind in words:
        return words[kind][0 if female else 1]
    return kind.lower()


def react_to_harm(world, state, victim, killed: bool, bus=None) -> list[str]:
    """Family and friends of someone the party hurt turn on them, and the victim's faction remembers.
    Returns the names of those who turned."""
    from game import factions
    factions.harmed(world, state, victim, killed, bus)
    angry = []
    for other, kind, _note in relations(world, victim):
        if state.npc_dead(other.id):
            continue
        mood = None
        if killed:
            mood = "Hostile" if kind in CLOSE else "Wary" if kind in ("Employer", "Employee", "Neighbor") else None
        elif kind in FAMILY or kind == "Friend":
            mood = "Wary"
        if mood and state.disposition(other) != "Hostile":
            state.npc(other.id)["disposition"] = mood
            angry.append(other.name)
    if angry:
        state.save()
        if bus is not None:
            bus.emit("log", kind="system", text=f"Word gets around. {', '.join(angry)} won't forget this.")
    return angry
