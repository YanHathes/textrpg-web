"""A quest chain's neighborhood: the town it starts in, the towns about a day away by road in the same
region, and the dungeons, landmarks and wild spots between them. Chains stay inside it (game/chains.py)
until the party outgrows it; then the main story moves on to the nearest one whose level range fits.

    hood = neighborhood(world, town)
    hood.towns, hood.villages, hood.dungeons, hood.landmarks, hood.npcs(), hood.level_range, hood.contains(...)
"""
from __future__ import annotations

from dataclasses import dataclass, field

DAY_HOURS = 14.0                      # "about a day" by road
SMALL = ("Hamlet", "Village")


def _region_of(world, town):
    rid = town.fields.get("region_ref") or ""
    reg = world.entities.get(rid) if rid else None
    if reg is None and town.fields.get("region"):
        reg = world.entities.find_by_name("region", str(town.fields.get("region")))
    return reg


def level_range(world, town) -> tuple[int, int]:
    """The level range of a town's region (1-4 when it has none)."""
    reg = _region_of(world, town) if town is not None else None
    if reg is None:
        return 1, 4
    lo = int(reg.fields.get("level_min") or 1)
    hi = int(reg.fields.get("level_max") or max(lo, 4))
    return max(1, lo), max(lo, hi)


@dataclass
class Neighborhood:
    town: object
    towns: list = field(default_factory=list)            # the start town first
    dungeons: list = field(default_factory=list)
    landmarks: list = field(default_factory=list)
    level_range: tuple = (1, 4)

    @property
    def villages(self) -> list:
        """The smaller places nearby (or any other nearby town, or home itself)."""
        small = [t for t in self.towns[1:] if (t.fields.get("kind") or "") in SMALL]
        return small or self.towns[1:] or self.towns[:1]

    @property
    def town_ids(self) -> set:
        return {t.id for t in self.towns}

    @property
    def place_ids(self) -> set:
        return self.town_ids | {d.id for d in self.dungeons} | {lm.id for lm in self.landmarks}

    def npcs(self, world, state=None) -> list:
        key = world.entities.count("npc")
        got = self.__dict__.get("_people")
        if got is None or got[0] != key:
            ids = self.town_ids
            store = world.entities
            found: dict = {}
            for tid in sorted(ids):                      # the towns' own people, and those of their buildings
                for n in store.by_field("npc", "town", tid):
                    found.setdefault(n.id, n)
                for b in store.by_field("building", "town", tid):
                    for n in store.by_field("npc", "building", b.id) + store.by_field("npc", "home", b.id):
                        found.setdefault(n.id, n)
            got = (key, sorted((n for n in found.values() if npc_town(world, n) in ids),
                               key=lambda n: n.name.lower()))
            self.__dict__["_people"] = got
        if state is None:
            return list(got[1])
        return [n for n in got[1] if not state.npcs.get(n.id, {}).get("dead")]

    def contains(self, world, entity_id: str) -> bool:
        """Is a place, a building or a person inside?"""
        if not entity_id or entity_id in self.place_ids:
            return True
        e = world.entities.get(entity_id)
        if e is None:
            return False
        if e.type == "npc":
            return npc_town(world, e) in self.town_ids
        if e.type == "building":
            return (e.fields.get("town") or "") in self.town_ids
        if e.type in ("enemy", "item"):
            return True                                  # a kind of creature or thing, not a place
        return False


def npc_town(world, npc) -> str:
    """The town someone lives or works in (their own field, else their building's)."""
    t = npc.fields.get("town") or ""
    if t:
        return t
    memo = world.entities.memo("npc", "town-of")
    if npc.id not in memo:
        b = world.entities.get(npc.fields.get("building") or "") or world.entities.get(npc.fields.get("home") or "")
        memo[npc.id] = (b.fields.get("town") or "") if b is not None else ""
    return memo[npc.id]


def neighborhood(world, town) -> Neighborhood:
    """The neighborhood around a town (cached per world)."""
    cache = world.__dict__.setdefault("_hoods", {})
    key = (town.id, world.entities.count("town"), world.entities.count("dungeon"), world.entities.count("landmark"))
    got = cache.get(key)
    if got is not None:
        return got
    from game import geography as G
    from game import places
    reg = _region_of(world, town)
    towns = [town]
    for road in places.roads_of(town):
        other = world.entities.get(road.get("leads_to") or "")
        if other is None or other in towns:
            continue
        try:
            hours = float(G.road_hours(world, town, road))
        except Exception:  # noqa: BLE001
            hours = float(road.get("hours") or 99)
        if hours > DAY_HOURS:
            continue
        oreg = _region_of(world, other)
        if reg is not None and oreg is not None and oreg.id != reg.id:
            continue
        towns.append(other)
    ids = {t.id for t in towns}
    dungeons = [d for d in world.entities.all("dungeon") if (d.fields.get("town") or "") in ids]
    landmarks = [lm for lm in world.entities.all("landmark") if (lm.fields.get("near_town") or "") in ids]
    hood = Neighborhood(town, towns, dungeons, landmarks, level_range(world, town))
    cache[key] = hood
    return hood


def party_level(members) -> int:
    lv = [max(1, int(m.get("level") or 1)) for m in members or [] if not m.get("dead")] or [1]
    return max(1, round(sum(lv) / len(lv)))


def outgrown(world, hood: Neighborhood, level: int) -> bool:
    """Can this neighborhood no longer challenge the party?"""
    return level > hood.level_range[1]


def fitting_town(world, from_town, level: int):
    """The nearest town (by map distance) whose region's level range fits the party."""
    from game import geography as G
    p0 = G.town_position(world, from_town)
    best = None
    for t in world.entities.all("town"):
        if t.id == from_town.id:
            continue
        lo, hi = level_range(world, t)
        if not (lo <= level <= hi):
            continue
        p = G.town_position(world, t)
        if p is None or p0 is None:
            d = 0.0
        else:
            d = (p[0] - p0[0]) ** 2 + (p[1] - p0[1]) ** 2
        if best is None or d < best[0]:
            best = (d, t)
    return best[1] if best else None


__all__ = ["neighborhood", "Neighborhood", "level_range", "party_level", "outgrown", "fitting_town", "DAY_HOURS"]
