"""Quest chains: a story told in steps that reach further out as it goes (in town, a nearby village, a
wild spot or dungeon, the finale and back to the giver), all within the giver's neighborhood
(game/neighborhood.py). Any chain can become the main story: once the party outgrows the neighborhood, the
next chapter sends it on to the nearest one whose level range fits.

Where they come from:
    the starter     the first person the party talks to offers the story of their trade (STORIES, by
                    occupation); declined, they offer it again whenever asked for work
    later chains    anyone with a story offers one now and then when asked for work (on the usual cooldown)
    hand-made       a Questline (Library) is an ordered list of quests, each with who hands it over

A generated chain is filled with real people and places from the neighborhood when it's accepted, and kept
in the save (state.chains), so it never changes after. Each step is an ordinary quest (game/quests.py) with
"chain" and "chain_step" set; finishing one starts the next.

Failure only on death: if the giver dies the chain passes to a relative or friend (or fails if there's
none); if someone the chain needs dies it fails, and the journal says why; an enemy killed before its step
comes up counts for that step.

    state.chains = {"starter": {"npc", "story", "chain"}, "list": {chain id: chain}}
    chain = {"id", "story", "title", "giver", "giver_name", "town", "chapter", "step", "steps": [step],
             "roles": {role: id}, "status", "main", "starter", "history": [line], "quest": current quest id,
             "kills_at": {enemy id: n}, "levels": [..], "questline": id (hand-made)}
"""
from __future__ import annotations

import random
import zlib

from game import neighborhood as NB

CHAIN_CHANCE = 0.35                   # how often someone with a story offers a chain rather than a single job
STARTER_MAX = 3                        # starter chains are pitched at levels 1 to about 3

# occupation -> story
OCC_STORY = {"Blacksmith": "ore", "Armorer": "ore", "Weaponsmith": "ore", "Innkeeper": "guest", "Farmer": "livestock",
             "Merchant": "caravan", "Caravan master": "caravan", "Priest": "shrine", "Guard": "bandits",
             "Mercenary": "bandits", "Hunter": "beast", "Alchemist": "sickness", "Scholar": "ruin",
             "Arcanist": "ruin", "Librarian": "ruin", "Noble": "feud", "Tailor": "commission",
             "Fletcher": "commission", "Jeweler": "commission", "Ship captain": "smugglers",
             "Airship pilot": "smugglers"}

# A story: its title, the pitch, and four steps (in town, a village, the wild, the finale). Objectives are
# (kind, role, count, text); roles are filled from the neighborhood when the chain is accepted.
STORIES = {
    "ore": {"title": "The Lost Ore", "teaches": "gathering, crafting",
            "pitch": "My ore shipment never arrived, and I've an order to fill. The carter left {village} days ago.",
            "steps": [
                {"title": "Asking about the cart", "objectives": [("Talk", "witness", 1, "Ask {witness} about the ore cart")]},
                {"title": "The raided cart", "objectives": [("Visit", "village", 1, "Go to {village}"),
                                                            ("Investigate", "village", 1, "Find the raided cart near {village}")]},
                {"title": "Ore of our own", "objectives": [("Visit", "mine", 1, "Go to {mine}"),
                                                           ("Gather", "ore", 4, "Mine {count} {ore}")]},
                {"title": "Forging the order", "return": True,
                 "objectives": [("Craft", "ingot", 2, "Smelt {count} {ingot} at a forge")]}]},
    "guest": {"title": "The Unpaid Room", "teaches": "investigating, dungeons",
              "pitch": "A guest of mine vanished in the night without paying, and their things are still upstairs. "
                       "Something's wrong.",
              "steps": [
                  {"title": "The empty room", "objectives": [("Investigate", "inn", 1, "Search the guest's room at {inn}")]},
                  {"title": "The trail", "objectives": [("Visit", "village", 1, "Follow the trail to {village}"),
                                                        ("Talk", "villager", 1, "Ask {villager} what they saw")]},
                  {"title": "The kidnappers' den", "objectives": [("Visit", "lair", 1, "Find the den at {lair}"),
                                                                  ("Defeat", "kidnapper", 1, "Defeat {count_text} {kidnapper}")]},
                  {"title": "Home again", "return": True,
                   "objectives": [("Escort", "town", 1, "Bring the guest safely back to {town}")]}]},
    "livestock": {"title": "Something in the Fields", "teaches": "tracking, combat",
                  "pitch": "Something's been killing my animals. Three sheep this week. I can't sit up every night.",
                  "steps": [
                      {"title": "The dead animals", "objectives": [("Investigate", "town", 1, "Look over the dead animals")]},
                      {"title": "Other farms", "objectives": [("Visit", "village", 1, "Go to {village}"),
                                                              ("Talk", "villager", 1, "Ask {villager} if they've lost stock")]},
                      {"title": "The tracks", "objectives": [("Visit", "lair", 1, "Track it to {lair}")]},
                      {"title": "The killer", "return": True,
                       "objectives": [("Defeat", "beast", 1, "Kill {count_text} {beast}")]}]},
    "caravan": {"title": "The Overdue Caravan", "teaches": "road travel",
                "pitch": "My caravan should have been here two days ago. The road from {village} isn't long.",
                "steps": [
                    {"title": "Word on the road", "objectives": [("Talk", "witness", 1, "Ask {witness} about the road")]},
                    {"title": "The last stop", "objectives": [("Visit", "village", 1, "Go to {village}"),
                                                              ("Talk", "villager", 1, "Ask {villager} when the caravan left")]},
                    {"title": "The wreck", "objectives": [("Visit", "wild", 1, "Search {wild}"),
                                                          ("Investigate", "wild", 1, "Look over the wrecked wagons")]},
                    {"title": "The goods", "return": True,
                     "objectives": [("Defeat", "bandit", 1, "Defeat {count_text} {bandit} who took the goods")]}]},
    "shrine": {"title": "The Desecrated Shrine", "teaches": "dungeons, night",
               "pitch": "Someone has defiled the old shrine near {village}. The dead there will not rest.",
               "steps": [
                   {"title": "What was seen", "objectives": [("Talk", "witness", 1, "Ask {witness} what they saw")]},
                   {"title": "The village", "objectives": [("Visit", "village", 1, "Go to {village}")]},
                   {"title": "The shrine", "objectives": [("Visit", "shrine", 1, "Go to {shrine}"),
                                                          ("Investigate", "shrine", 1, "Find what was done there")]},
                   {"title": "Laying them to rest", "return": True,
                    "objectives": [("Defeat", "undead", 3, "Lay {count_text} {undead} to rest")]}]},
    "bandits": {"title": "Bandits on the Road", "teaches": "combat",
                "pitch": "Bandits are robbing travellers on the roads round here. Find their camp and end it.",
                "steps": [
                    {"title": "The last robbery", "objectives": [("Talk", "witness", 1, "Ask {witness} about the robbery")]},
                    {"title": "The road", "objectives": [("Visit", "village", 1, "Go to {village}")]},
                    {"title": "The camp", "objectives": [("Visit", "camp", 1, "Find the camp at {camp}"),
                                                         ("Investigate", "camp", 1, "Scout the camp")]},
                    {"title": "Their leader", "return": True,
                     "objectives": [("Defeat", "bandit", 1, "Defeat {count_text} {bandit}, their leader's band")]}]},
    "beast": {"title": "A Beast Unlike Any Other", "teaches": "tracking, skinning",
              "pitch": "There's a beast out there unlike anything I've hunted. I want it, and I want proof.",
              "steps": [
                  {"title": "Signs", "objectives": [("Investigate", "village", 1, "Read the tracks near {village}")]},
                  {"title": "Its range", "objectives": [("Visit", "lair", 1, "Follow it to {lair}")]},
                  {"title": "The hunt", "objectives": [("Defeat", "beast", 1, "Kill {count_text} {beast}")]},
                  {"title": "Proof", "return": True, "objectives": [("Fetch", "pelt", 1, "Bring back {pelt}")]}]},
    "sickness": {"title": "The Sickness in {village}", "teaches": "foraging, crafting",
                 "pitch": "There's a sickness in {village}. I know the cure, but I haven't the herbs or the hands.",
                 "steps": [
                     {"title": "The sick", "objectives": [("Visit", "village", 1, "Go to {village}"),
                                                          ("Talk", "sick", 1, "See {sick}")]},
                     {"title": "The herbs", "objectives": [("Gather", "herb", 3, "Gather {count} {herb}")]},
                     {"title": "The cure", "objectives": [("Craft", "cure", 1, "Brew {cure} at an alchemy lab")]},
                     {"title": "Bringing the cure", "return": True,
                      "objectives": [("Deliver", "sick", 1, "Take {cure} to {sick}")]}]},
    "ruin": {"title": "The Stirring Ruin", "teaches": "dungeons",
             "pitch": "The old ruin at {ruin} has stirred. Lights, sounds. Something there wants finding.",
             "steps": [
                 {"title": "Old records", "objectives": [("Talk", "witness", 1, "Ask {witness} about the ruin")]},
                 {"title": "The way there", "objectives": [("Visit", "village", 1, "Go to {village}")]},
                 {"title": "Inside", "objectives": [("Visit", "ruin", 1, "Enter {ruin}"),
                                                    ("Investigate", "ruin", 1, "Find what has stirred")]},
                 {"title": "The guardian", "return": True,
                  "objectives": [("Defeat", "guardian", 1, "Defeat {count_text} {guardian}")]}]},
    "feud": {"title": "An Old Feud", "teaches": "choices, reputation",
             "pitch": "{rival} has gone too far this time. I need someone to settle this.",
             "steps": [
                 {"title": "The other side", "objectives": [("Talk", "rival", 1, "Hear {rival} out")]},
                 {"title": "A friend's view", "objectives": [("Talk", "witness", 1, "Ask {witness} who's in the right")]},
                 {"title": "Choosing a side", "objectives": [("Choose", "rival", 1, "Decide the feud with {rival}")]},
                 {"title": "Settled", "return": True, "objectives": [("Talk", "giver", 1, "Tell {giver} how it ended")]}]},
    "commission": {"title": "A Rare Commission", "teaches": "gathering, crafting",
                   "pitch": "I've a commission I can't fill without something rare, and it only comes from {wild}.",
                   "steps": [
                       {"title": "Where to look", "objectives": [("Talk", "witness", 1, "Ask {witness} about {wild}")]},
                       {"title": "The road out", "objectives": [("Visit", "village", 1, "Go to {village}")]},
                       {"title": "The rare stuff", "objectives": [("Visit", "wild", 1, "Go to {wild}"),
                                                                  ("Gather", "rare", 3, "Get {count} {rare}")]},
                       {"title": "The commission", "return": True,
                        "objectives": [("Craft", "commission", 1, "Make {commission}")]}]},
    "smugglers": {"title": "Smugglers' Cove", "teaches": "choices, reputation",
                  "pitch": "Smugglers are using a cove near {village}. They're cutting into honest trade. Or are they?",
                  "steps": [
                      {"title": "Dock talk", "objectives": [("Talk", "witness", 1, "Ask {witness} about the smugglers")]},
                      {"title": "The cove", "objectives": [("Visit", "wild", 1, "Find the cove at {wild}"),
                                                           ("Investigate", "wild", 1, "Watch the smugglers")]},
                      {"title": "Expose or bargain", "objectives": [("Choose", "smuggler", 1,
                                                                     "Deal with {smuggler}, their leader")]},
                      {"title": "The end of it", "return": True,
                       "objectives": [("Talk", "giver", 1, "Report to {giver}")]}]},
    "missing": {"title": "Missing in the Wilds", "teaches": "exploring",
                "pitch": "My {relation} went out to {village} and never came back. Please, find them.",
                "steps": [
                    {"title": "Who saw them", "objectives": [("Talk", "witness", 1, "Ask {witness} when they left")]},
                    {"title": "The village", "objectives": [("Visit", "village", 1, "Go to {village}"),
                                                            ("Talk", "villager", 1, "Ask {villager} about them")]},
                    {"title": "Lost", "objectives": [("Visit", "wild", 1, "Search {wild}"),
                                                     ("Investigate", "wild", 1, "Find the missing traveller")]},
                    {"title": "Home", "return": True, "objectives": [("Escort", "town", 1, "Bring them home to {town}")]}]},
}
# the wild spot each story wants (dungeon or landmark kinds, best first)
WILD_KINDS = {"mine": ["Mine", "Cave"], "lair": ["Lair", "Cave", "Ruins"], "shrine": ["Shrine", "Crypt", "Temple", "Grove"],
              "camp": ["Camp", "Ruins", "Fortress"], "ruin": ["Ruins", "Tower", "Crypt", "Temple"],
              "wild": ["Grove", "Ruins", "Shipwreck", "Cave", "Battlefield", "Monument", "Standing stones", "Camp"]}
# what kind of creature a role wants (enemy tags)
FOE_TAGS = {"kidnapper": {"humanoid"}, "bandit": {"humanoid"}, "beast": {"beast", "monstrosity"},
            "undead": {"undead"}, "guardian": {"construct", "undead", "monstrosity", "elemental"}}
CHOICES = {
    "feud": [{"text": "Side with {giver}", "journal": "you sided with {giver}", "rep": 10, "other": -10, "gold": 1.0},
             {"text": "Side with {rival}", "journal": "you sided with {rival}", "rep": -10, "other": 10, "gold": 0.5},
             {"text": "Make them make peace", "journal": "you made {giver} and {rival} make peace", "rep": 3,
              "other": 3, "gold": 0.5, "check": ("Persuasion", 13)}],
    "smugglers": [{"text": "Expose them to the watch", "journal": "you exposed {smuggler} to the watch", "rep": 10,
                   "other": -15, "gold": 1.0},
                  {"text": "Take their bribe and look away", "journal": "you took {smuggler}'s bribe", "rep": -10,
                   "other": 10, "gold": 2.0}],
}
COMMISSIONS = {"Tailor": ("Wolf Pelt", "Fur Cloak"), "Fletcher": ("Eagle Feathers", "Longbow"),
               "Jeweler": ("Silver Ore", "Signet ring")}
RELATIONS = ["brother", "sister", "son", "daughter", "cousin", "father", "mother"]
HEIRS = ("family", "spouse", "sibling", "parent", "child", "brother", "sister", "son", "daughter", "friend", "partner")


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


def data(state) -> dict:
    d = state.chains
    d.setdefault("list", {})
    return d


def all_chains(state) -> list[dict]:
    return list(data(state)["list"].values())


def get(state, chain_id: str) -> dict | None:
    return data(state)["list"].get(chain_id or "")


def story_for(npc) -> str:
    return OCC_STORY.get((npc.fields.get("occupation") or "") if npc is not None else "", "missing")


# ----------------------------------------------------------------------------------------------------
# Offering
# ----------------------------------------------------------------------------------------------------
def _town_of(world, npc):
    from game import places
    return world.entities.get(places.town_of(world, npc) or NB.npc_town(world, npc) or "")


def _fmt(text: str, names: dict) -> str:
    class D(dict):
        def __missing__(self, k):
            return "someone" if k in ("witness", "villager", "rival", "sick", "smuggler") else "somewhere nearby"
    try:
        return text.format_map(D(names))
    except (ValueError, IndexError):
        return text


def offer(world, state, npc, levels: list[int], starter: bool = False, story: str | None = None) -> dict | None:
    """A chain this person offers, as a quest offer (filled in only when accepted)."""
    town = _town_of(world, npc)
    if town is None:
        return None
    key = story or story_for(npc)
    s = STORIES.get(key)
    if s is None:
        return None
    hood = NB.neighborhood(world, town)
    preview = _names_for_pitch(world, hood, npc, key)
    first = s["steps"][0]
    return {"id": "offer", "title": _fmt(s["title"], preview), "kind": "Chain", "source": "chain",
            "giver": npc.id, "giver_name": npc.name, "pitch": _fmt(s["pitch"], preview),
            "level": min(STARTER_MAX, NB.party_level([{"level": lv} for lv in levels])) if starter else
            NB.party_level([{"level": lv} for lv in levels]),
            "objectives": [{"text": f"{len(s['steps'])} parts, starting with: {first['title'].lower()}", "kind": "Custom",
                            "target": "", "count": 1, "progress": 0, "done": False, "hint": f"Teaches {s['teaches']}"}],
            "return_to_giver": True, "status": "offered", "tracked": False, "journal": [],
            "rewards": _chain_rewards(levels, len(s["steps"])),
            "chain_offer": {"story": key, "giver": npc.id, "starter": bool(starter)}}


def _names_for_pitch(world, hood, npc, key) -> dict:
    vil = hood.villages[0] if hood.villages else hood.town
    rng = _rng("pitch", npc.id)
    names = {"village": vil.name, "town": hood.town.name, "giver": npc.name, "relation": rng.choice(RELATIONS)}
    wild = _pick_wild(hood, WILD_KINDS.get("ruin" if key == "ruin" else "wild", []), rng)
    if wild is not None:
        names["wild"] = names["ruin"] = wild.name
    rival = _rival(world, npc, hood, None)
    if rival is not None:
        names["rival"] = rival.name
    return names


def _chain_rewards(levels, steps: int) -> dict:
    from game import quests as Q
    base = Q.xp_budget(levels or [1], "Medium")[1]
    lvl = NB.party_level([{"level": lv} for lv in levels or [1]])
    return {"gold": 20 * lvl + 10 * steps, "xp": int(base * 0.4 * steps), "items": {}}


def starter_offer(world, state, npc, levels: list[int]) -> dict | None:
    """The first person the party talks to offers the story of their trade; it's theirs to offer until it's
    taken. None if someone else is the starter, or it's been taken."""
    d = data(state)
    st = d.get("starter")
    if st is None:
        o = offer(world, state, npc, levels, starter=True, story=story_for(npc))
        if o is None:                                   # someone with no town to tell of: the next one, then
            return None
        d["starter"] = {"npc": npc.id, "story": story_for(npc), "chain": ""}
        state.save()
        return o
    if st.get("npc") != npc.id or st.get("chain"):
        return None
    return offer(world, state, npc, levels, starter=True, story=st.get("story"))


# ----------------------------------------------------------------------------------------------------
# Filling a chain in
# ----------------------------------------------------------------------------------------------------
def _pick_wild(hood, kinds: list, rng: random.Random):
    pool = hood.dungeons + hood.landmarks
    if not pool:
        return None
    for k in kinds:
        got = [p for p in pool if (p.fields.get("kind") or "") == k]
        if got:
            return rng.choice(sorted(got, key=lambda e: e.id))
    return rng.choice(sorted(pool, key=lambda e: e.id))


def _pick_npc(world, state, people, rng, exclude: set, prefer: tuple = ()):
    cands = [n for n in people if n.id not in exclude]
    if not cands:
        return None
    for occ in prefer:
        got = [n for n in cands if (n.fields.get("occupation") or "") == occ]
        if got:
            return rng.choice(sorted(got, key=lambda e: e.id))
    return rng.choice(sorted(cands, key=lambda e: e.id))


def _rival(world, npc, hood, state):
    for rel in npc.fields.get("relationships") or []:
        if str(rel.get("kind") or "").lower() in ("rival", "enemy", "feud"):
            other = world.entities.get(rel.get("npc") or "")
            if other is not None and hood.contains(world, other.id):
                return other
    nobles = [n for n in hood.npcs(world, state) if n.id != npc.id and (n.fields.get("occupation") or "") == "Noble"]
    return sorted(nobles, key=lambda e: e.id)[0] if nobles else None


def _foe(world, hood, levels, tags: set, rng, difficulty: str = "Medium"):
    from game import quests as Q
    terrain = (hood.town.fields.get("terrain") or "") if hood.town is not None else ""
    opts = Q.encounter_options(world, levels, difficulty, terrain)
    if tags:
        tagged = [o for o in opts if tags & {str(t).lower() for t in (o[0].tags or [])}]
        opts = tagged or opts
    if not opts:
        return None, 1
    enemy, n, _adj, _s = opts[min(len(opts) - 1, rng.randrange(min(3, len(opts))))]
    return enemy, n


def _levels_for(hood, levels: list[int]) -> list[int]:
    lo, hi = hood.level_range
    return [max(lo, min(hi, int(lv))) for lv in (levels or [1])]


def fill(world, state, npc, key: str, levels: list[int], hood=None, seed: str = "") -> dict:
    """Pick the real people, places, foes and things a story needs (once, when it's accepted)."""
    from game import gathering as GA
    town = _town_of(world, npc)
    hood = hood or NB.neighborhood(world, town)
    rng = _rng("chain", npc.id, key, seed)
    lv = _levels_for(hood, levels)
    people = hood.npcs(world, state)
    home = [n for n in people if NB.npc_town(world, n) == hood.town.id]
    vil = rng.choice(sorted(hood.villages, key=lambda t: t.id))
    vil_people = [n for n in people if NB.npc_town(world, n) == vil.id] or home
    used = {npc.id}
    roles: dict = {"giver": npc.id, "town": hood.town.id, "village": vil.id}
    w = _pick_npc(world, state, home, rng, used, ("Guard", "Innkeeper", "Merchant", "Priest", "Commoner"))
    if w is not None:
        roles["witness"] = w.id
        used.add(w.id)
    v = _pick_npc(world, state, vil_people, rng, used, ("Farmer", "Hunter", "Innkeeper", "Commoner"))
    if v is not None:
        roles["villager"] = v.id
        used.add(v.id)
    for role, fallback in (("witness", "villager"), ("villager", "witness")):   # nobody else about: one will do
        if role not in roles and fallback in roles:
            roles[role] = roles[fallback]
    roles.setdefault("witness", npc.id)
    roles.setdefault("villager", roles["witness"])
    for role, kinds in WILD_KINDS.items():
        got = _pick_wild(hood, kinds, rng)
        roles[role] = got.id if got is not None else vil.id
    b = world.entities.get(npc.fields.get("building") or "")
    roles["inn"] = b.id if b is not None else hood.town.id
    rival = _rival(world, npc, hood, state)
    if rival is not None:
        roles["rival"] = rival.id
    else:
        r = _pick_npc(world, state, people, rng, used)
        if r is not None:
            roles["rival"] = r.id
    used.add(roles.get("rival", ""))
    s = _pick_npc(world, state, vil_people, rng, used, ("Commoner", "Farmer"))
    roles["sick"] = s.id if s is not None else roles["villager"]
    used.add(roles["sick"])
    sm = _pick_npc(world, state, people, rng, used, ("Mercenary", "Merchant", "Commoner"))
    roles["smuggler"] = sm.id if sm is not None else roles["witness"]
    roles.setdefault("rival", roles["witness"])
    for role, tags in FOE_TAGS.items():
        e, n = _foe(world, hood, lv, tags, rng, "Hard" if role in ("guardian", "beast") else "Medium")
        if e is not None:
            roles[role] = e.id
            roles[role + "#"] = n
    beast = world.entities.get(roles.get("beast") or "")
    pelt = GA.skin_item(world, beast) if beast is not None and GA.skinnable(world, beast) else None
    if pelt is None:
        pelt = world.entities.find_by_name("item", "Thick Hide")
    if pelt is not None:
        roles["pelt"] = pelt.id
    names = {"ore": "Iron Ore", "ingot": "Iron Ingot", "cure": "Antitoxin (vial)", "herb": "Silverleaf"}
    occ = npc.fields.get("occupation") or ""
    rare, commission = COMMISSIONS.get(occ, ("Silver Ore", "Signet ring"))
    names.update(rare=rare, commission=commission)
    for role, nm in names.items():
        e = world.entities.find_by_name("item", nm)
        if e is not None:
            roles[role] = e.id
    roles["relation"] = rng.choice(RELATIONS)
    return roles


def _name(world, roles: dict, role: str) -> str:
    v = roles.get(role, "")
    e = world.entities.get(v) if isinstance(v, str) else None
    return e.name if e is not None else (v if isinstance(v, str) and v and "." not in v else "")


def _names(world, roles: dict) -> dict:
    out = {}
    for k in roles:
        if not k.endswith("#"):
            out[k] = _name(world, roles, k)
    return out


def _loc_of(world, eid: str) -> str:
    """The place to go for something (a person's whereabouts, a dungeon's entrance...)."""
    from game import dungeons as DG
    from game import places
    e = world.entities.get(eid or "")
    if e is None:
        return ""
    if e.type == "npc":
        return places.where_is(world, e) or (e.fields.get("town") or "")
    if e.type == "dungeon":
        lm = next((x for x in world.entities.all("landmark") if x.fields.get("dungeon") == e.id), None)
        return DG.landmark_id(lm.id) if lm is not None else (e.fields.get("town") or "")
    if e.type == "landmark":
        return DG.landmark_id(e.id)
    if e.type in ("town", "building"):
        return e.id
    return ""


def build_step(world, state, chain: dict, index: int) -> dict:
    """The quest for one step of a chain (objectives with real targets)."""
    from game import quests as Q
    roles = chain["roles"]
    names = _names(world, roles)
    if chain.get("questline"):
        return _questline_step(world, state, chain, index)
    step = chain["steps"][index]
    objs = []
    for kind, role, count, text in [tuple(o) for o in step["objectives"]]:
        target = roles.get(role, "")
        n = int(roles.get(role + "#") or count) if kind == "Defeat" else count
        e = world.entities.get(target) if isinstance(target, str) else None
        vals = dict(names, count=n, count_text=Q.number_word(n) if n > 1 else ("the" if kind == "Defeat" else "one"))
        if kind == "Defeat" and e is not None:
            vals[role] = Q.plural(e.name, n) if n > 1 else e.name
        if kind in ("Gather", "Craft", "Fetch") and e is not None and n > 1:
            vals[role] = Q.plural(e.name, n)
        o = {"text": _fmt(text, vals), "kind": kind, "target": target, "count": n, "progress": 0, "done": False,
             "hint": "", "where": ""}
        if kind in ("Visit", "Investigate", "Escort"):
            o["where"] = _loc_of(world, target) or target
            if kind == "Investigate":
                o["dc"] = 10 + min(5, max(0, (chain.get("level") or 1) // 2))
                o["hint"] = "Investigation or Perception, there"
            if kind == "Escort":
                o["who"] = names.get("relation") if chain["story"] == "missing" else "the guest"
        elif kind in ("Talk", "Choose", "Deliver"):
            o["where"] = _loc_of(world, target)
            if kind == "Choose":
                o["choices"] = [dict(c, text=_fmt(c["text"], names), journal=_fmt(c["journal"], names))
                                for c in CHOICES.get(chain["story"], [])]
            if kind == "Deliver":
                o["item"] = roles.get("cure", "")
        elif kind == "Defeat" and e is not None:
            env = Q.hunt_environment(e, (chain.get("terrain") or ""), random.Random(0))
            at = ""
            for st in chain["steps"][:index + 1]:          # where the story last sent the party
                for ob in st["objectives"]:
                    if ob[0] == "Visit" and ob[1] not in ("village", "dest", "town"):
                        at = roles.get(ob[1]) or at
            o["where"] = _loc_of(world, at) if at else ""
            o["at_id"] = at
            o["hunt"] = {"enemy": e.id, "count": n, "environment": env, "where": Q.ENV_PHRASE.get(env, ""),
                         "town": chain["town"], "direction": "North"}
            o["at"] = o["where"]
            o["hint"] = f"CR {e.fields.get('cr', '?')}  ·  waiting at {names.get('lair') or 'its lair'}"
            already = int(state.kills.get(e.id, 0)) - int(chain.get("kills_at", {}).get(e.id, 0))
            if already > 0:                                    # killed before the step came up: it counts
                o["progress"] = min(n, already)
                o["done"] = o["progress"] >= n
        elif kind in ("Gather", "Craft", "Fetch"):
            from game import crafting
            r = crafting.recipe_for(world, target) if kind == "Craft" else None
            if r is not None:
                o["hint"] = "Made at a " + crafting.station_info(world, r["stations"][0])["label"].lower()
            elif kind == "Gather":
                o["hint"] = "Gathered (or bought)"
        objs.append(o)
    last = index == len(chain["steps"]) - 1
    lvl = chain.get("levels") or [1]
    base = Q.xp_budget(lvl, "Medium")[1]
    rewards = {"gold": int(10 * max(1, chain.get("level") or 1) * (2.5 if last else 0.5)),
               "xp": int(base * (0.6 if last else 0.2)), "items": {}}
    giver = world.entities.get(chain["giver"])
    return {"title": f"{chain['title']}: {step['title']}", "kind": "Chain", "chain": chain["id"], "chain_step": index,
            "giver": chain["giver"], "giver_name": giver.name if giver else chain.get("giver_name", ""),
            "source": "chain", "pitch": step.get("text") or "", "level": chain.get("level") or 1,
            "objectives": objs, "return_to_giver": bool(step.get("return")), "status": "offered",
            "tracked": False, "journal": [], "rewards": rewards}


def begin(world, state, book, offer: dict) -> dict | None:
    """Accept a chain offer: fill it in, keep it, and start its first step. Returns the first step's quest."""
    co = offer.get("chain_offer") or {}
    npc = world.entities.get(co.get("giver") or offer.get("giver") or "")
    if npc is None:
        return None
    key = co.get("story") or story_for(npc)
    s = STORIES[key]
    levels = list(book.levels()) if book is not None else [1]
    if co.get("starter"):
        levels = [min(STARTER_MAX, lv) for lv in levels]
    town = _town_of(world, npc)
    hood = NB.neighborhood(world, town)
    cid = state.next_id("chain")
    roles = fill(world, state, npc, key, levels, hood, seed=cid)
    names = _names(world, roles)
    chain = {"id": cid, "story": key, "title": _fmt(s["title"], names), "giver": npc.id, "giver_name": npc.name,
             "town": town.id, "chapter": int(co.get("chapter") or 1), "step": 0,
             "steps": [dict(st) for st in s["steps"]], "roles": roles, "status": "active", "main": bool(co.get("main")),
             "starter": bool(co.get("starter")), "history": [f"Day {state.day}: {npc.name} asked for your help."],
             "kills_at": dict(state.kills), "levels": _levels_for(hood, levels),
             "level": NB.party_level([{"level": lv} for lv in _levels_for(hood, levels)]),
             "terrain": town.fields.get("terrain") or "", "quest": "", "accepted": state.minutes}
    if co.get("pre"):
        chain["steps"] = list(co["pre"]) + chain["steps"]
        chain["roles"].update(co.get("pre_roles") or {})
    data(state)["list"][cid] = chain
    if co.get("starter"):
        data(state).setdefault("starter", {})["chain"] = cid
    if co.get("continues"):
        old = get(state, co["continues"])
        if old is not None:
            chain["title"] = old["title"]
            chain["chapter"] = int(old.get("chapter") or 1) + 1
            chain["history"] = list(old.get("history") or []) + chain["history"][-1:]
            chain["main"] = bool(old.get("main") or co.get("main"))
            old["status"] = "continued"
            old["next"] = cid
    state.save()
    return _start_step(world, state, book, chain, 0)


def _start_step(world, state, book, chain: dict, index: int) -> dict:
    q = build_step(world, state, chain, index)
    chain["step"] = index
    q["id"] = state.next_id("q")
    q["status"] = "active"
    q["accepted_day"] = state.day
    q["journal"] = [f"Day {state.day}: " + ("the story begins." if index == 0 else "the story goes on.")]
    prev_tracked = any(x.get("tracked") and x.get("chain") == chain["id"] for x in state.quests)
    if not any(x.get("tracked") for x in state.quests if x.get("status") in ("active", "ready")) or prev_tracked:
        for x in state.quests:
            x["tracked"] = False
        q["tracked"] = True
    state.quests.append(q)
    chain["quest"] = q["id"]
    state.save()
    if book is not None:
        book._log(f"Quest: {q['title']}")
        book._emit("quest.accepted", quest=q)
        book.check(q)
    return q


def step_done(world, state, book, q: dict) -> dict | None:
    """A chain step's quest is complete: start the next, or finish the chain. Returns the next quest."""
    chain = get(state, q.get("chain") or "")
    if chain is None or chain.get("status") != "active":
        return None
    note = q.get("chose")
    if note:
        chain["history"].append(f"Day {state.day}: {note}.")
    nxt = int(q.get("chain_step", 0)) + 1
    if chain.get("questline"):
        total = len(_questline_steps(world, chain))
    else:
        total = len(chain["steps"])
    if nxt < total:
        return _start_step(world, state, book, chain, nxt)
    chain["status"] = "completed"
    chain["history"].append(f"Day {state.day}: the chapter is done.")
    state.save()
    if book is not None:
        book._log(f"Story complete: {chain['title']}" + (" (chapter %d)" % chain["chapter"] if chain["chapter"] > 1 else ""), "loot")
        book._emit("chain.completed", chain=chain)
    return None


# ----------------------------------------------------------------------------------------------------
# What comes next: another chapter, here or (once the party has outgrown it) in a fitting neighborhood
# ----------------------------------------------------------------------------------------------------
def follow_up(world, state, npc, levels: list[int]) -> dict | None:
    """The next chapter of a finished chain, offered by its giver (or, for the main story, the person the
    last chapter led to)."""
    for chain in all_chains(state):
        if chain.get("status") != "completed" or chain.get("giver") != npc.id or chain.get("questline"):
            continue
        town = world.entities.get(chain.get("town") or "")
        if town is None:
            continue
        hood = NB.neighborhood(world, town)
        lvl = NB.party_level([{"level": lv} for lv in levels])
        if NB.outgrown(world, hood, lvl):
            return _main_story_offer(world, state, npc, chain, lvl)
        stories = [k for k in STORIES if k != chain["story"]]
        key = _rng("next", chain["id"]).choice(sorted(stories))
        o = offer(world, state, npc, levels, story=key)
        if o is None:
            return None
        o["title"] = f"{chain['title']}, chapter {int(chain.get('chapter') or 1) + 1}"
        o["chain_offer"].update(continues=chain["id"], chapter=int(chain.get("chapter") or 1) + 1)
        o["pitch"] = "There's more to it than we thought. " + o["pitch"]
        return o
    return None


def _main_story_offer(world, state, npc, chain: dict, level: int) -> dict | None:
    """The party has outgrown this neighborhood: the story moves on to the nearest one that fits."""
    town = world.entities.get(chain["town"])
    dest = NB.fitting_town(world, town, level)
    if dest is None:
        return None
    hood = NB.neighborhood(world, dest)
    rng = _rng("main", chain["id"])
    people = [n for n in hood.npcs(world, state) if NB.npc_town(world, n) == dest.id
              and (n.fields.get("occupation") or "") in OCC_STORY]
    if not people:
        people = [n for n in hood.npcs(world, state) if NB.npc_town(world, n) == dest.id]
    if not people:
        return None
    contact = rng.choice(sorted(people, key=lambda e: e.id))
    key = story_for(contact)
    o = offer(world, state, contact, [level], story=key)
    if o is None:
        return None
    pre = [{"title": f"The road to {dest.name}", "objectives": [["Visit", "dest", 1, "Travel to {dest}"],
                                                                 ["Talk", "giver", 1, "Find {giver} there"]]}]
    o.update(title=f"{chain['title']}, chapter {int(chain.get('chapter') or 1) + 1}",
             pitch=f"What we've found points further afield, to {dest.name}. {contact.name} there knows more. "
                   "Our troubles here are nothing to what's coming there.",
             giver=npc.id, giver_name=npc.name)
    o["chain_offer"].update(continues=chain["id"], chapter=int(chain.get("chapter") or 1) + 1, main=True,
                            giver=contact.id, pre=pre, pre_roles={"dest": dest.id}, told_by=npc.id)
    return o


def main_story(state) -> dict | None:
    for chain in all_chains(state):
        if chain.get("main") and chain.get("status") in ("active", "completed"):
            return chain
    return None


# ----------------------------------------------------------------------------------------------------
# Hand-made chains (Questline entities)
# ----------------------------------------------------------------------------------------------------
def _questline_steps(world, chain: dict) -> list:
    ql = world.entities.get(chain.get("questline") or "")
    return [r for r in (ql.fields.get("steps") or []) if r.get("quest")] if ql is not None else []


def questline_of(world, quest_entity_id: str):
    """(questline, index) for a hand-made quest that's a step of one, else (None, -1)."""
    for ql in world.entities.all("questline"):
        for i, row in enumerate(ql.fields.get("steps") or []):
            if row.get("quest") == quest_entity_id:
                return ql, i
    return None, -1


def _questline_step(world, state, chain: dict, index: int) -> dict:
    from game import quests as Q
    rows = _questline_steps(world, chain)
    row = rows[index]
    e = world.entities.get(row["quest"])
    giver = world.entities.get(row.get("giver") or "") or world.entities.get(chain["giver"])
    q = Q.from_entity(world, e, giver)
    q.update(chain=chain["id"], chain_step=index, title=e.name)
    return q


def begin_questline(world, state, book, q: dict) -> None:
    """A hand-made quest that's the first step of a Questline was accepted: keep it as a chain."""
    ql, i = questline_of(world, q.get("source") or "")
    if ql is None or i != 0 or q.get("chain"):
        return
    cid = state.next_id("chain")
    giver = world.entities.get(q.get("giver") or "")
    chain = {"id": cid, "story": "", "questline": ql.id, "title": ql.name, "giver": q.get("giver") or "",
             "giver_name": q.get("giver_name") or "", "town": (giver.fields.get("town") if giver else "") or "",
             "chapter": 1, "step": 0, "steps": [], "roles": {}, "status": "active", "main": bool(ql.fields.get("main_story")),
             "starter": False, "history": [f"Day {state.day}: {q.get('giver_name') or 'Someone'} asked for your help."],
             "kills_at": dict(state.kills), "levels": [], "level": int(q.get("level") or 1), "quest": q["id"],
             "accepted": state.minutes}
    data(state)["list"][cid] = chain
    q["chain"], q["chain_step"] = cid, 0
    state.save()


# ----------------------------------------------------------------------------------------------------
# Deaths
# ----------------------------------------------------------------------------------------------------
def _heir(world, state, npc):
    for rel in npc.fields.get("relationships") or []:
        if any(h in str(rel.get("kind") or "").lower() for h in HEIRS):
            other = world.entities.get(rel.get("npc") or "")
            if other is not None and not state.npcs.get(other.id, {}).get("dead"):
                return other
    for other in sorted(world.entities.by_field("npc", "rel", npc.id), key=lambda n: n.name.lower()):
        # someone who names them family or friend
        if state.npcs.get(other.id, {}).get("dead"):
            continue
        for rel in other.fields.get("relationships") or []:
            if rel.get("npc") == npc.id and any(h in str(rel.get("kind") or "").lower() for h in HEIRS):
                return other
    return None


def npc_died(world, state, book, npc_id: str) -> list[str]:
    """Someone died: chains they gave pass to an heir (or fail); chains that needed them fail. Returns
    what the journal says."""
    npc = world.entities.get(npc_id)
    said = []
    for chain in all_chains(state):
        if chain.get("status") != "active":
            continue
        q = next((x for x in state.quests if x.get("id") == chain.get("quest")), None)
        if chain.get("giver") == npc_id:
            heir = _heir(world, state, npc) if npc is not None else None
            if heir is not None:
                chain["giver"], chain["giver_name"] = heir.id, heir.name
                chain["roles"]["giver"] = heir.id
                line = f"Day {state.day}: {npc.name} is dead. {heir.name} takes up their cause."
                chain["history"].append(line)
                if q is not None:
                    q["giver"], q["giver_name"] = heir.id, heir.name
                    q["journal"].append(line)
                    for o in q["objectives"]:
                        if o.get("target") == npc_id and o["kind"] in ("Talk", "Deliver", "Choose"):
                            o["target"] = heir.id
                            o["where"] = _loc_of(world, heir.id)
                said.append(line)
                continue
            _fail(state, book, chain, q, f"{npc.name if npc else 'The giver'} is dead, and nobody is left to see it through")
            said.append(chain["history"][-1])
            continue
        needed = {v for k, v in chain.get("roles", {}).items() if k not in ("giver",) and isinstance(v, str)}
        left = []
        if q is not None:
            left = [o for o in q["objectives"] if not o.get("done")]
        future = []
        if not chain.get("questline"):
            for st in chain["steps"][int(chain.get("step", 0)) + 1:]:
                future += [o[1] for o in st["objectives"]]
        if npc_id in needed and (any(o.get("target") == npc_id and o["kind"] != "Defeat" for o in left) or
                                 any(chain["roles"].get(r) == npc_id for r in future)):
            _fail(state, book, chain, q, f"{npc.name if npc else 'Someone it needed'} is dead")
            said.append(chain["history"][-1])
    state.save()
    return said


def _fail(state, book, chain: dict, q: dict | None, why: str) -> None:
    chain["status"] = "failed"
    chain["history"].append(f"Day {state.day}: the story has ended: {why}.")
    chain["why"] = why
    if q is not None and q.get("status") in ("active", "ready"):
        q["status"] = "failed"
        q["tracked"] = False
        q["journal"].append(f"Day {state.day}: failed: {why}.")
    if book is not None:
        book._log(f"Story failed: {chain['title']} ({why}).", "system")
        book._emit("quest.failed", quest=q)
        book._retrack()


# ----------------------------------------------------------------------------------------------------
# Quest items, fights waiting at a place, objectives to show
# ----------------------------------------------------------------------------------------------------
def locked_items(world, state) -> set[str]:
    """Things the active chains need: they can't be sold or dropped while the chain goes on."""
    out = set()
    for chain in all_chains(state):
        if chain.get("status") != "active":
            continue
        q = next((x for x in state.quests if x.get("id") == chain.get("quest")), None)
        if q is not None:
            for o in q["objectives"]:
                if o["kind"] in ("Fetch", "Gather", "Craft") and o.get("target"):
                    out.add(o["target"])
                if o["kind"] == "Deliver" and o.get("item"):
                    out.add(o["item"])
        if not chain.get("questline"):
            for st in chain["steps"][int(chain.get("step", 0)) + 1:]:
                for o in st["objectives"]:
                    if o[0] in ("Fetch", "Gather", "Craft", "Deliver"):
                        t = chain["roles"].get(o[1] if o[0] != "Deliver" else "cure")
                        if t:
                            out.add(t)
    return out


def fight_at(world, state, loc: str) -> dict | None:
    """A chain foe waiting where the party has just arrived: an encounter to start (or None)."""
    if not loc:
        return None
    from game import quests as Q
    ids = Q.QuestBook(world, state)._place_ids(loc)
    if loc.startswith("landmark|"):
        lm = world.entities.get(loc.split("|")[1])
        if lm is not None and lm.fields.get("dungeon"):
            ids.add(lm.fields["dungeon"])
    for q in state.quests:
        if q.get("status") != "active" or not q.get("chain"):
            continue
        for o in q["objectives"]:
            if o["kind"] != "Defeat" or o.get("done") or not (o.get("at") or o.get("at_id")):
                continue
            here = (o.get("at_id") and o["at_id"] in ids) or (o.get("at") and o["at"] in ids and
                                                               not str(o["at"]).startswith("town."))
            if not here:
                continue
            e = world.entities.get(o["target"])
            if e is None:
                continue
            n = max(1, int(o["count"]) - int(o.get("progress", 0)))
            from game.quests import ENV_TO_MAP, counted
            env = (o.get("hunt") or {}).get("environment") or "Forest"
            return {"rows": [{"id": e.id, "count": n}], "environment": ENV_TO_MAP.get(env, "plains"),
                    "text": f"{counted(e.name, n)[:1].upper()}{counted(e.name, n)[1:]}: {o['text'].lower()}!"}
    return None


__all__ = ["STORIES", "OCC_STORY", "offer", "starter_offer", "begin", "step_done", "follow_up", "main_story",
           "npc_died", "locked_items", "fight_at", "all_chains", "get", "story_for", "begin_questline", "questline_of",
           "build_step", "fill"]
