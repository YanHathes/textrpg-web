"""Shared option lists. Templates refer to these as "@name" (e.g. "options": "@damage_types")."""

DAMAGE_TYPES = ["slashing", "piercing", "bludgeoning", "fire", "cold", "lightning", "thunder",
                "acid", "poison", "necrotic", "radiant", "force", "psychic"]

# size -> squares per side on the battle map
SIZES = {"Tiny": 1, "Small": 1, "Medium": 1, "Large": 2, "Huge": 3, "Gargantuan": 4}

# challenge rating -> experience points
CR_XP = {
    "0": 10, "1/8": 25, "1/4": 50, "1/2": 100, "1": 200, "2": 450, "3": 700, "4": 1100, "5": 1800,
    "6": 2300, "7": 2900, "8": 3900, "9": 5000, "10": 5900, "11": 7200, "12": 8400, "13": 10000,
    "14": 11500, "15": 13000, "16": 15000, "17": 18000, "18": 20000, "19": 22000, "20": 25000,
    "21": 33000, "22": 41000, "23": 50000, "24": 62000, "25": 75000, "26": 90000, "27": 105000,
    "28": 120000, "29": 135000, "30": 155000,
}
CRS = list(CR_XP)


def cr_value(cr: str) -> float:
    cr = str(cr)
    if "/" in cr:
        a, b = cr.split("/")
        return int(a) / int(b)
    try:
        return float(cr)
    except ValueError:
        return 0.0


DIRECTIONS = ["North", "North-east", "East", "South-east", "South", "South-west", "West", "North-west"]

ITEM_CATEGORIES = ["Weapon", "Armor", "Shield", "Consumable", "Ammunition", "Gear", "Tool",
                   "Clothing", "Trinket", "Treasure", "Material", "Book"]
RARITIES = ["Common", "Uncommon", "Rare", "Very rare", "Legendary", "Artifact"]
EQUIP_SLOTS = ["None", "Main hand", "Off hand", "Two hands", "Body", "Head", "Cloak", "Neck",
               "Ring", "Hands", "Feet", "Waist"]
WEAPON_KINDS = ["Simple melee", "Martial melee", "Simple ranged", "Martial ranged"]
WEAPON_PROPERTIES = ["finesse", "light", "heavy", "two-handed", "versatile", "reach", "thrown",
                     "ammunition", "loading", "special"]
ARMOR_TYPES = ["Light", "Medium", "Heavy"]

SKILL_KINDS = ["Skill", "Tool", "Language", "Other proficiency"]
FEATURE_KINDS = ["Class feature", "Racial trait", "Feat", "Background feature", "Monster ability", "Other"]
ACTIVATIONS = ["Passive", "Action", "Bonus action", "Reaction", "Free"]
USE_LIMITS = ["Unlimited", "Once per turn", "Per short rest", "Per long rest", "Recharge 5-6", "Recharge 6",
              "Recharge 4-6", "Costs Mana/Stamina", "Costs resource", "Item charges"]
FEATURE_DURATIONS = ["Instant", "Until end of your turn", "Until your next turn", "1 minute", "10 minutes",
                     "Until you rest"]
FEATURE_REQUIREMENTS = ["Wearing no armor", "Not in heavy armor", "No shield", "Holding a melee weapon"]
FEATURE_EFFECTS = ["Heal self", "Temporary hit points", "Extra action", "Extra damage", "Bonus to attack rolls",
                   "Bonus to damage", "Bonus to AC", "Bonus to saving throws", "Resistance", "Condition immunity",
                   "Advantage on attacks", "Attacks against you have advantage", "Extra speed",
                   "Critical hit range", "Armor formula", "Dash, Disengage or Dodge", "Regain spell slots",
                   "Reduce damage", "Impose disadvantage", "Bonus hit points", "Note",
                   # character building (9b)
                   "Attunement slots", "Resource pool", "Restore resource", "Skill proficiency", "Expertise",
                   "Bonus to skill checks", "Saving throw proficiency", "Bonus to initiative", "Extra attack",
                   "Unarmed strike", "Darkvision", "Damage immunity", "Vulnerability",
                   "Advantage on saving throws", "Regenerate", "Spell attack and DC bonus", "Magical attacks"]
REACTION_TRIGGERS = ["When you are hit by an attack", "When you take damage", "When a creature attacks you",
                     "When an ally near you is attacked", "When a creature casts a spell"]
EFFECT_TARGETS = ["Self", "One ally", "One enemy", "Allies in the area", "Enemies in the area"]
CHOICE_KINDS = ["", "Features", "Skill proficiency", "Skill expertise", "Spells"]
RESOURCE_RECHARGE = ["Short rest", "Long rest", "Never"]
CASTING_STYLES = ["Known", "Prepared (whole class list)", "Spellbook"]
FEATURE_CONDITIONS = ["Always", "Melee attacks", "Ranged attacks", "Finesse or ranged attacks", "Strength attacks",
                      "Advantage or ally next to target", "Finesse or ranged, with advantage or ally next to target",
                      "Ally next to target", "Below half hit points"]
SPELL_SCHOOLS = ["Abjuration", "Conjuration", "Divination", "Enchantment", "Evocation", "Illusion",
                 "Necromancy", "Transmutation"]
SPELL_EFFECTS = ["Spell attack (melee)", "Spell attack (ranged)", "Saving throw", "Automatic hit",
                 "Healing", "Effect blocks", "Temporary hit points", "Teleport", "Summon", "Remove condition",
                 "Revive", "Utility"]
RELATIONSHIP_KINDS = ["Parent", "Child", "Sibling", "Spouse", "Partner", "Friend", "Rival", "Enemy", "Employer",
                      "Employee", "Mentor", "Student", "Neighbor"]
# how each kind reads from the other side
RELATIONSHIP_REVERSE = {"Parent": "Child", "Child": "Parent", "Employer": "Employee", "Employee": "Employer",
                        "Mentor": "Student", "Student": "Mentor"}
ACTION_TYPES = ["Action", "Bonus action", "Reaction", "Free", "1 minute", "10 minutes", "1 hour"]
AREA_SHAPES = ["None", "Sphere", "Cube", "Cone", "Line", "Cylinder"]

OCCUPATIONS = {
    # occupation -> item tags they sell by default
    "Blacksmith": ["weapon", "armor", "metal"],
    "Armorer": ["armor", "shield"],
    "Weaponsmith": ["weapon"],
    "Merchant": ["gear", "tool", "clothing", "food"],
    "Alchemist": ["potion", "alchemical", "herb"],
    "Innkeeper": ["food", "drink"],
    "Priest": ["holy", "potion"],
    "Fletcher": ["bow", "ammunition", "feather"],
    "Tailor": ["clothing", "cloth", "fibre"],
    "Jeweler": ["jewelry", "treasure"],
    "Scholar": ["book", "scroll"],
    "Arcanist": ["magic", "scroll", "potion", "book"],
    "Hunter": ["hide", "food", "trap"],
    "Farmer": ["food", "farm"],
    "Guard": [],
    "Noble": [],
    "Mercenary": [],
    "Commoner": [],
    "Ship captain": [],
    "Airship pilot": [],
    "Caravan master": [],
}
PASSAGE_METHODS = ["Boat", "Airship", "Caravan"]

DISPOSITIONS = ["Friendly", "Neutral", "Wary", "Hostile"]
FACTION_KINDS = ["Realm", "Town", "Guild", "Temple", "Criminal", "Other"]
AI_BEHAVIORS = ["Aggressive", "Defensive", "Ranged", "Cowardly", "Guardian"]

ENVIRONMENTS = ["Forest", "Plains", "Hills", "Mountains", "Swamp", "Desert", "Arctic", "Coast",
                "Underwater", "Urban", "Dungeon", "Cave", "Interior",
                "Jungle", "Savanna", "Taiga", "Tundra", "Badlands"]
TERRAINS = ["Plains", "Forest", "Hills", "Mountains", "Coast", "Swamp", "Desert", "Arctic"]
BIOMES = TERRAINS + ["Jungle", "Badlands", "Lake", "Ocean", "Taiga", "Tundra", "Savanna"]
LANDMARK_KINDS = ["Ruins", "Tower", "Shrine", "Cave", "Monument", "Battlefield", "Camp", "Bridge", "Grove", "Mine",
                  "Lair", "Standing stones", "Shipwreck", "Other"]
DUNGEON_KINDS = ["Cave", "Crypt", "Ruins", "Mine", "Tower", "Lair", "Sewer", "Temple", "Fortress", "Other"]
SETTLEMENT_KINDS = ["Hamlet", "Village", "Town", "City", "Capital"]
BUILDING_KINDS = ["Shop", "Tavern", "Inn", "Temple", "Smithy", "Guild hall", "House", "Town hall",
                  "Barracks", "Warehouse", "Library", "Stable", "Market", "Mansion", "Castle", "Bank", "Jail",
                  "Casino", "Arena", "Brothel", "College", "Granary", "Mill", "Boatwright", "Workshop", "Other"]
FACILITIES = ["Notice board", "Blackjack table", "Tavern games", "Forge", "Carpenter's bench", "Tannery", "Loom",
              "Alchemy lab", "Scribe's desk", "Jeweler's bench", "Kitchen", "Festival grounds", "Stable yard",
              "Dock", "Bounty board", "Archives"]
JOB_KINDS = ["Smithy", "Farm", "Tavern", "Docks", "Market stall", "Lumber camp", "Mine"]
TRADE_GOODS = ["ore", "stone", "gems", "timber", "fish", "salt", "grain", "livestock", "wool", "furs", "herbs",
               "spices", "dyes", "wine", "cloth", "tools"]
DEFENSES = ["", "None", "Hedge", "Ditch", "Palisade", "Wooden wall", "Stone wall", "Stone walls with towers",
            "Double walls"]
INTERIOR_STYLES = ["Wooden", "Stone", "Rich", "Rustic"]

QUEST_KINDS = ["Fetch", "Defeat", "Visit", "Talk", "Escort", "Deliver", "Investigate", "Choose", "Gather", "Craft",
               "Build", "Custom"]

MECHANIC_TRIGGERS = ["Turn start", "Turn end", "Attack made", "Attack hit", "Attack missed", "Critical hit",
                     "Hit by an attack", "Damage taken", "Damage dealt", "Healed", "Creature defeated", "Spell cast",
                     "Feature used", "Item used", "Condition applied", "Combat start", "Combat end", "Check rolled",
                     "Location entered", "Rest", "Time passed", "New day", "Quest accepted", "Quest completed",
                     "Item bought", "Item sold", "Custom event"]
MECHANIC_TARGETS = ["Party members", "Enemies", "Anyone", "Specific thing"]
MECHANIC_WHERE = ["Anywhere", "In combat", "Outside combat"]
MECHANIC_LIMITS = ["No limit", "Once per fight", "Once per day", "Once ever"]
MECHANIC_EFFECT_TARGETS = ["Who it happened to", "The other one", "The whole party", "All enemies in the fight",
                           "Everyone in the fight", "The world"]
MECHANIC_ACTIONS = ["Deal damage", "Heal", "Give temporary HP", "Apply condition", "Remove condition",
                    "Change value", "Set value", "Give item", "Remove item", "Give gold", "Take gold", "Give XP",
                    "Start quest", "Grant feature for the fight", "Saving throw (stop if passed)",
                    "Check (stop if failed)", "Give level", "Change resource", "Message", "Trigger event"]
CONDITIONS = ["Blinded", "Charmed", "Deafened", "Exhaustion", "Frightened", "Grappled", "Incapacitated",
              "Invisible", "Paralyzed", "Petrified", "Poisoned", "Prone", "Restrained", "Stunned",
              "Unconscious"]

HIT_DICE = ["d6", "d8", "d10", "d12"]

OPTION_LISTS = {
    "damage_types": DAMAGE_TYPES, "sizes": list(SIZES), "crs": CRS, "directions": DIRECTIONS,
    "item_categories": ITEM_CATEGORIES, "rarities": RARITIES, "equip_slots": EQUIP_SLOTS,
    "weapon_kinds": WEAPON_KINDS, "weapon_properties": WEAPON_PROPERTIES, "armor_types": ARMOR_TYPES,
    "skill_kinds": SKILL_KINDS, "feature_kinds": FEATURE_KINDS, "activations": ACTIVATIONS,
    "use_limits": USE_LIMITS, "feature_durations": FEATURE_DURATIONS, "feature_requirements": FEATURE_REQUIREMENTS,
    "feature_effects": FEATURE_EFFECTS, "feature_conditions": FEATURE_CONDITIONS, "spell_schools": SPELL_SCHOOLS, "spell_effects": SPELL_EFFECTS,
    "action_types": ACTION_TYPES, "area_shapes": AREA_SHAPES, "occupations": list(OCCUPATIONS), "passage_methods": PASSAGE_METHODS,
    "dispositions": DISPOSITIONS, "faction_kinds": FACTION_KINDS, "ai_behaviors": AI_BEHAVIORS, "environments": ENVIRONMENTS,
    "terrains": TERRAINS, "building_kinds": BUILDING_KINDS, "facilities": FACILITIES, "job_kinds": JOB_KINDS,
    "trade_goods": TRADE_GOODS, "defenses": DEFENSES, "interior_styles": INTERIOR_STYLES,
    "quest_kinds": QUEST_KINDS, "mechanic_triggers": MECHANIC_TRIGGERS,
    "mechanic_targets": MECHANIC_TARGETS, "mechanic_actions": MECHANIC_ACTIONS, "mechanic_where": MECHANIC_WHERE,
    "mechanic_limits": MECHANIC_LIMITS, "mechanic_effect_targets": MECHANIC_EFFECT_TARGETS,
    "conditions": CONDITIONS, "hit_dice": HIT_DICE, "reaction_triggers": REACTION_TRIGGERS,
    "effect_targets": EFFECT_TARGETS, "conditions_or_none": [""] + CONDITIONS,
    "book_kinds": ["History", "Religion", "Bestiary", "Map", "Field guide", "Manual", "Letters", "Other"],
    "craft_stations": ["forge", "carpenter's bench", "tannery", "loom", "alchemy lab", "scribe's desk",
                       "jeweler's bench", "kitchen", "campfire"],
    "biomes": BIOMES, "landmark_kinds": LANDMARK_KINDS, "dungeon_kinds": DUNGEON_KINDS,
    "room_roles": ["Entrance", "Common", "Private", "Service", "Storage", "Work", "Hall", "Stairs", "Yard",
                   "Special", "Room", "Hallway", "Chamber", "Treasure room", "Boss"],
    "room_kinds": ["Any building", "Any dungeon"] + BUILDING_KINDS + [k for k in DUNGEON_KINDS if k not in BUILDING_KINDS],
    "room_floors": ["Any", "Ground", "Upper", "Cellar", "Ground or upper"],
    "room_stairs": ["", "Up", "Down", "Both"],
    "room_features": ["bar", "counter", "forge", "altar", "beds", "hearth", "tables", "shelves", "crates", "pews",
                      "stalls", "racks", "desk", "bath", "throne"],
    "room_perks": ["", "Rest", "Healing", "Income", "Storage", "Training", "Crafting"],
    "room_scenes": ["", "Tavern", "Inn", "Shop", "Temple", "Smithy", "Guild hall", "House", "Town hall", "Barracks",
                    "Warehouse", "Library", "Stable", "Market"],
    "settlement_kinds": SETTLEMENT_KINDS, "directions_or_none": [""] + DIRECTIONS,
    "choice_kinds": CHOICE_KINDS, "relationship_kinds": RELATIONSHIP_KINDS, "resource_recharge": RESOURCE_RECHARGE, "casting_styles": CASTING_STYLES,
}
