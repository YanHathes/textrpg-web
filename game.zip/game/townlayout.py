"""What stands round a town's streets on its walking map: its walls and gates, wells, street lamps and
fountains, the farms outside, and the empty lots with a "For sale" sign.

Everything comes from the settlement rules (game/settlements.py) and the town's own fields, and is worked
out the same every time from the town's id, so nothing is stored. game/area.py calls in two steps:

    extra = margin(town)                 how much room round the town the walls and farms need
    dress(area, base, town, ...)         lay it all in, once the streets and buildings are down

Walls by defence:  Hedge -> a hedge;  Ditch -> a water-filled ditch;  Palisade / Wooden wall -> wood;
Stone wall -> stone;  Stone walls with towers -> stone with towers;  Double walls -> two stone rings.
Every wall has gates (gaps) where roads and streets go out. Lamps line the streets of towns and bigger.
"""
from __future__ import annotations

import random
import zlib

from game import settlements as ST

WALL_KIND = {"Hedge": "hedge", "Palisade": "wood_wall", "Wooden wall": "wood_wall", "Stone wall": "stone_wall",
             "Stone walls with towers": "stone_wall", "Double walls": "stone_wall"}
RING = 3                        # squares between the outermost building or street and the wall
FARMS = {"Camp": 0, "Hamlet": (1, 2), "Village": (2, 4), "Town": (3, 5), "City": (4, 6), "Capital": (5, 8)}
FARM_BAND = 16                  # how far out the farms reach beyond the wall
LAMP_EVERY = 7
LOT_SIZE = (8, 7)               # an empty lot: about 80 by 70 feet


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


def defence(town) -> str:
    return ST.defenses(town) or "None"


def rings(town) -> int:
    d = defence(town)
    if d == "Double walls":
        return 2
    return 1 if d in WALL_KIND or d == "Ditch" else 0


def farm_count(town) -> int:
    span = FARMS.get(ST.tier_of(town)) or 0
    return _rng("farms", town.id).randint(*span) if span else 0


def margin(town) -> int:
    """Extra squares the map needs round the town for its walls and farms."""
    out = RING * rings(town) + (2 if rings(town) else 0)
    if farm_count(town):
        out += FARM_BAND
    return out


def lot_rows() -> list[dict]:
    w, h = LOT_SIZE
    return [{"name": "Lot", "type": "Entrance", "tile": "", "floor": 0, "x": 0, "y": 0, "w": w - 1, "h": h - 1,
             "connects": ""}]


# ----------------------------------------------------------------------------------------------------
def _ring_cells(x0: int, y0: int, x1: int, y1: int) -> list[tuple[int, int]]:
    out = [(x, y0) for x in range(x0, x1 + 1)] + [(x, y1) for x in range(x0, x1 + 1)]
    out += [(x0, y) for y in range(y0 + 1, y1)] + [(x1, y) for y in range(y0 + 1, y1)]
    return out


def _gate_on_ring(box, cx: float, cy: float, vx: float, vy: float) -> tuple[int, int]:
    """Where a line out of the middle of town in direction (vx, vy) meets the ring `box`."""
    x0, y0, x1, y1 = box
    best = None
    for t_x in ([(x1 - cx) / vx] if vx > 1e-6 else [(x0 - cx) / vx] if vx < -1e-6 else []):
        best = t_x
    for t_y in ([(y1 - cy) / vy] if vy > 1e-6 else [(y0 - cy) / vy] if vy < -1e-6 else []):
        best = t_y if best is None else min(best, t_y)
    best = best or 0
    gx = int(round(min(max(cx + vx * best, x0), x1)))
    gy = int(round(min(max(cy + vy * best, y0), y1)))
    return gx, gy


def dress(a, base, town, rng, footprint: tuple, street_cells: set, lots: list, plaza, road_cells: dict,
          sale_lots: list, embedded: bool) -> list[tuple]:
    """Lay the walls, gates, wells, lamps, fountain, farms and for-sale lots into the town's ground level.
    footprint: (x0, y0, x1, y1) of the streets and buildings, in map squares. Returns the rectangles now
    taken (so the trees keep off them)."""
    from game import geography as G
    from game import places
    tier = ST.tier_of(town)
    taken: list[tuple] = []
    fx0, fy0, fx1, fy1 = footprint
    cx, cy = (fx0 + fx1) / 2, (fy0 + fy1) / 2
    dropped: set = set()

    def drop(p) -> None:                     # quicker than Level.remove_prop for many (props compare slowly)
        dropped.add(id(p))
        for c in p.cells():
            if base.prop_cells.get(c) is p:
                del base.prop_cells[c]
    street_floor = "cobble" if any(base.floor_at(*c) == "cobble" for c in list(street_cells)[:20]) else "path"

    # ---- walls and gates ----------------------------------------------------------------------------
    d = defence(town)
    n_rings = rings(town)
    gate_dirs = sorted({r["direction"] for r in places.roads_of(town)} | set(places.town_exits(town))) or \
        ["East", "West"]
    a.walls_of_town = []
    a.gate_cells = []
    a.gate_rings = []                  # per ring (innermost first): the middle of each gate, one per direction
    for k in range(n_rings):
        off = RING * (k + 1)
        box = (fx0 - off, fy0 - off, fx1 + off, fy1 + off)
        cells = _ring_cells(*box)
        gaps = set()
        a.gate_rings.append([])
        for direction in gate_dirs:
            vx, vy = G.VECTORS.get(direction, (0, 1))
            gx, gy = _gate_on_ring(box, cx, cy, vx, vy)
            horizontal = gy in (box[1], box[3]) and box[0] < gx < box[2]
            for dd in (-1, 0, 1):
                gaps.add((gx + dd, gy) if horizontal else (gx, gy + dd))
            a.gate_cells.append((gx, gy))
            a.gate_rings[-1].append((gx, gy))
        gaps |= {c for c in cells if c in road_cells}             # a road out always gets through
        kind = WALL_KIND.get(d)
        for c in cells:
            if not base.inside(*c):
                continue
            if c in gaps:
                if base.floor_at(*c) not in (street_floor, "path", "dirt"):
                    base.set_floor(c[0], c[1], "path")
                if d == "Ditch":
                    base.set_floor(c[0], c[1], "wood")          # a plank bridge over the ditch
                continue
            p = base.prop_cells.get(c)
            if p is not None:
                drop(p)
            if d == "Ditch":
                base.water[c] = "water"
            else:
                base.walls[c] = kind
        if d in ("Stone walls with towers", "Double walls") and k == n_rings - 1:
            corners = [(box[0], box[1]), (box[2], box[1]), (box[0], box[3]), (box[2], box[3])]
            towers = corners + [c for i, c in enumerate(cells) if i % 14 == 7 and c not in gaps]
            for (tx, ty) in towers:
                for dy in (-1, 0, 1):
                    for dx in (-1, 0, 1):
                        c = (tx + dx, ty + dy)
                        if base.inside(*c) and c not in gaps and not any(abs(c[0] - g[0]) + abs(c[1] - g[1]) <= 2
                                                                         for g in gaps):
                            p = base.prop_cells.get(c)
                            if p is not None:
                                drop(p)
                            base.walls[c] = "stone_wall"
        a.walls_of_town.append(box)
        # lights at each gate, inside
        for g in a.gate_cells[-len(gate_dirs):]:
            for side in ((2, 0), (-2, 0), (0, 2), (0, -2)):
                c = (g[0] + side[0], g[1] + side[1])
                if base.inside(*c) and base.free(*c) and c not in street_cells and c not in road_cells and \
                        c not in base.walls:
                    base.add_prop("brazier" if tier in ("City", "Capital") else "lamp", c[0], c[1])
                    break
    wall_box = a.walls_of_town[-1] if a.walls_of_town else (fx0 - 2, fy0 - 2, fx1 + 2, fy1 + 2)

    def near_door(c) -> bool:
        x, y = c
        return any((x + dx, y + dy) in base.doors for dx in (-1, 0, 1) for dy in (-1, 0, 1))

    lot_cells: tuple[set, set] = (set(), set())          # squares in a lot; and in or next to one
    for (lx, ly, lw, lh) in lots:
        for yy in range(ly - 1, ly + lh + 1):
            for xx in range(lx - 1, lx + lw + 1):
                lot_cells[1].add((xx, yy))
                if lx <= xx < lx + lw and ly <= yy < ly + lh:
                    lot_cells[0].add((xx, yy))

    def in_lot(c, pad=0) -> bool:
        return c in lot_cells[1 if pad else 0]

    # ---- the fountain or well in the square ----------------------------------------------------------
    wells_left = ST.wells(town)
    if plaza is not None:
        well = next((p for p in base.props if p.id == "well"), None)
        if well is not None and tier in ("City", "Capital"):
            drop(well)
            base.add_prop("fountain", well.x, well.y)
            if tier == "Capital":
                for c in ((well.x - 2, well.y - 2), (well.x + 3, well.y + 3)):
                    if base.free(*c):
                        base.add_prop("statue", *c)
        elif well is not None:
            wells_left -= 1

    # ---- wells and lamps along the streets -----------------------------------------------------------
    edge = sorted(c for c in {(x + dx, y + dy) for (x, y) in street_cells for dx, dy in ((1, 0), (-1, 0), (0, 1),
                                                                                          (0, -1))}
                  if c not in street_cells)
    rng2 = _rng("dress", town.id)
    rng2.shuffle(edge)
    ground = base.floor_at(0, 0)
    wells_at = [(p.x, p.y) for p in base.props if p.id in ("well", "fountain")]
    for c in edge:
        if wells_left <= 0:
            break
        x, y = c
        box = [(x + i, y + j) for i in (0, 1) for j in (0, 1)]
        if all(base.inside(*q) and base.free(*q) and base.floor_at(*q) == ground and not in_lot(q, 1)
               and not near_door(q) and q not in road_cells for q in box) and \
                not any(abs(wx - x) < 12 and abs(wy - y) < 12 for (wx, wy) in wells_at):
            base.add_prop("well", x, y)
            wells_at.append((x, y))
            wells_left -= 1
    if tier in ("Town", "City", "Capital"):
        lit: set = set()                                  # coarse grid: one lamp per LAMP_EVERY squares
        for c in sorted(edge):
            x, y = c
            cell = (x // LAMP_EVERY, y // LAMP_EVERY)
            if cell in lit:
                continue
            if base.inside(x, y) and base.free(x, y) and base.floor_at(x, y) == ground and not near_door(c) \
                    and c not in road_cells and not in_lot(c, 0) and c not in base.walls:
                base.add_prop("lamp", x, y)
                lit.add(cell)

    # ---- empty lots for sale ---------------------------------------------------------------------------
    for i, rect in enumerate(sale_lots):
        lx, ly, lw, lh = rect[:4]
        lot_no = rect[4] if len(rect) > 4 else i               # (its number: sold lots aren't passed)
        taken.append((lx, ly, lw, lh))
        for yy in range(ly, ly + lh):
            for xx in range(lx, lx + lw):
                p = base.prop_cells.get((xx, yy))
                if p is not None:
                    drop(p)
                if (xx + yy) % 5 == 0:
                    base.set_floor(xx, yy, "dirt")
        for c in ((lx, ly), (lx + lw - 1, ly), (lx, ly + lh - 1), (lx + lw - 1, ly + lh - 1)):
            if base.free(*c):
                base.add_prop("fence", *c)
        # the sign stands on the side nearest a street
        sides = {(lx + lw // 2, ly): (0, -1), (lx + lw // 2, ly + lh - 1): (0, 1), (lx, ly + lh // 2): (-1, 0),
                 (lx + lw - 1, ly + lh // 2): (1, 0)}
        def street_side(c, out) -> int:
            for k in range(1, 6):
                if (c[0] + out[0] * k, c[1] + out[1] * k) in street_cells:
                    return k
            return 99
        spot = min(sides, key=lambda c: street_side(c, sides[c]))
        if base.free(*spot):
            base.add_prop("sale_sign", *spot)
            base.stations[spot] = {"kind": "sale_sign", "room": "", "spot": None, "town": town.id, "lot": lot_no}

    # ---- farms outside the walls -------------------------------------------------------------------------
    n = farm_count(town)
    wx0, wy0, wx1, wy1 = wall_box
    gates = [_gate_on_ring(wall_box, cx, cy, *G.VECTORS.get(dr, (0, 1))) for dr in gate_dirs]
    farm_rects: list[tuple] = []
    tries = 0
    while len(farm_rects) < n and tries < 60:
        tries += 1
        big = tier in ("Town", "City", "Capital")
        w, h = (rng2.randint(12, 18), rng2.randint(8, 12)) if big else (rng2.randint(7, 11), rng2.randint(5, 8))
        side = rng2.choice("NSEW")
        gap = rng2.randint(2, 3)
        if side in "NS":
            x = rng2.randint(wx0 - 4, max(wx0 - 4, wx1 - w + 4))
            y = wy0 - gap - h if side == "N" else wy1 + gap + 1
        else:
            y = rng2.randint(wy0 - 4, max(wy0 - 4, wy1 - h + 4))
            x = wx0 - gap - w if side == "W" else wx1 + gap + 1
        if x < 1 or y < 1 or x + w >= a.w - 1 or y + h >= a.h - 1:
            continue
        if any(x - 2 < fx + fw and fx < x + w + 2 and y - 2 < fy + fh and fy < y + h + 2 for fx, fy, fw, fh in farm_rects):
            continue
        if any((side == "N" and gy <= wy0 or side == "S" and gy >= wy1) and x - 3 <= gx < x + w + 3 or
               (side == "W" and gx <= wx0 or side == "E" and gx >= wx1) and y - 3 <= gy < y + h + 3
               for gx, gy in gates):
            continue                                       # keep the way out of each gate clear
        cells = [(xx, yy) for yy in range(y, y + h) for xx in range(x, x + w)]
        if any(c in road_cells or c in base.walls or c in base.water or c in street_cells or in_lot(c, 1)
               for c in cells):
            continue
        crop = rng2.randrange(3)
        for (xx, yy) in cells:
            p = base.prop_cells.get((xx, yy))
            if p is not None:
                drop(p)
            base.set_floor(xx, yy, "dirt")
            if 0 < xx - x < w - 1 and 0 < yy - y < h - 1:
                base.add_prop("crops", xx, yy, crop)
            elif yy == y and rng2.random() < 0.7:
                base.add_prop("fence", xx, yy)
        if rng2.random() < 0.6 and base.free(x + w, y):
            base.add_prop("haybale", x + w, y)
        farm_rects.append((x, y, w, h))
    a.farms = farm_rects
    taken += farm_rects
    if dropped:
        base.props = [p for p in base.props if id(p) not in dropped]
    return taken


__all__ = ["dress", "margin", "rings", "farm_count", "defence", "lot_rows", "WALL_KIND", "LOT_SIZE"]
