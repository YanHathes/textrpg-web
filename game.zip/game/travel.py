"""Journeys along roads, exploring the wilds, and random encounters.

A journey moves in legs of up to two hours. Before each leg there's a chance of
an encounter; a road's "Encounter chance" is the chance of at least one over the
whole trip. Exploring the wilds takes an hour and finds trouble more often, and
if a quest's quarry lives out this way, that's usually what you find.

Nothing here touches the screen: the window asks for the next step and starts a
fight when one comes back.
"""
from __future__ import annotations

import random

from game import places
from game.quests import ENV_TO_MAP, counted, encounter_options

LEG_HOURS = 2.0


def terrain_of(town) -> str:
    return (town.fields.get("terrain") if town is not None else "") or "Plains"


def encounter(world, terrain: str, levels: list[int], rng: random.Random, difficulty: str = "",
              region=None, night: bool | None = None) -> dict | None:
    """A random fight for this land (a biome or terrain name): {"rows": [...], "environment": map key,
    "text": ...}, from the land's encounter table (game/encounters.py), built for the party's levels and
    numbers. A region's 'Typical creatures' are preferred when they fit the party."""
    from game import encounters
    found = encounters.roll(world, terrain, levels, rng, difficulty, region, night)
    if found is not None:
        return found
    difficulty = difficulty or rng.choice(["Easy", "Easy", "Medium"])
    opts = encounter_options(world, levels, difficulty, terrain)
    if not opts:
        opts = encounter_options(world, levels, "Medium")
    if not opts:
        return None
    local = [o for o in opts if terrain in (o[0].fields.get("environments") or [])]
    if region is not None and region.fields.get("enemies"):
        favoured = [o for o in opts if o[0].id in (region.fields.get("enemies") or [])]
        local = favoured or local
    enemy, n, _adj, _s = rng.choice((local or opts)[:6])
    env = terrain if terrain in (enemy.fields.get("environments") or []) else (
        (enemy.fields.get("environments") or [terrain])[0])
    return {"rows": [{"id": enemy.id, "count": n}], "environment": ENV_TO_MAP.get(env, ENV_TO_MAP.get(terrain, "plains")),
            "text": f"{counted(enemy.name, n)[:1].upper()}{counted(enemy.name, n)[1:]} "
                    f"{'block' if n > 1 else 'blocks'} the way!"}


# ======================================================================
# Roads
# ======================================================================
def start_journey(world, state, town_id: str, direction: str, bus=None) -> dict | None:
    town = world.entities.get(town_id)
    road = places.road_to(town, direction) if town is not None else None
    dest = world.entities.get(road.get("leads_to")) if road else None
    if dest is None:
        return None
    from game import geography
    region = geography.region_of_town(world, town)
    bonus = int((region.fields.get("danger") if region is not None else 0) or 0)
    state.journey = {"from": town.id, "to": dest.id, "direction": direction,
                     "hours": max(0.5, geography.road_hours(world, town, road)), "done": 0.0,
                     "danger": max(0, min(100, int(road.get("danger", 20) or 0) + bonus)),
                     "grade": road.get("grade") or "",
                     "terrain": terrain_of(town)}
    places.enter(world, state, places.road_id(town.id, direction), bus)
    if bus is not None:
        bus.emit("log", kind="narration", text=f"You take the {direction.lower()} road out of {town.name}, "
                                               f"bound for {dest.name}. It's about {state.journey['hours']:g} hours.")
        bus.emit("journey.started", journey=dict(state.journey))
    return state.journey


def turn_back(world, state, bus=None) -> None:
    j = state.journey
    if not j:
        return
    j["from"], j["to"] = j["to"], j["from"]
    j["done"] = max(0.0, j["hours"] - j["done"])
    back = world.entities.get(j["to"])
    state.save()
    if bus is not None:
        bus.emit("log", kind="narration", text=f"You turn back toward {back.name if back else 'town'}.")


def stop(world, state, bus=None) -> None:
    """Leave the road partway (on the walking map): the party is out in the open country now."""
    j = state.journey
    if not j or j.get("kind") == "voyage":
        return
    state.journey = None
    state.save()
    if bus is not None:
        bus.emit("log", kind="narration", text="You leave the road.")


def step(world, state, rng: random.Random, levels: list[int], bus=None, leg: float | None = None,
         quiet: bool = False, members: list | None = None) -> dict:
    """One leg of the journey (LEG_HOURS, or `leg` hours). Returns {"kind": "progress" | "encounter" |
    "arrived", ...}. A mount for everyone, or a cart with an animal to pull it, covers the road faster
    (game/animals.py): the journey's hours are walking hours, and the clock moves less for each of them."""
    j = state.journey
    if not j:
        return {"kind": "arrived"}
    fast = 1.0
    if members and j.get("kind") != "voyage":
        from game import animals
        fast = animals.travel_factor(world, state, members)
    left = (j["hours"] - j["done"]) / fast
    leg = min(leg or LEG_HOURS, left)
    share = leg * fast / j["hours"] if j["hours"] else 1.0
    chance = 1 - (1 - j["danger"] / 100.0) ** share
    state.advance(int(round(leg * 60)), "journey")
    if members is not None and world.rules.get("survival"):       # out of food or water: stop (game/survival.py)
        from game import survival
        warn = survival.out_of_supplies(world, state, members)
        if warn:
            try:                                                  # stand where the road had got to
                from game import geography
                from game import hexes as H
                pos = geography.party_position(world, state)
            except Exception:  # noqa: BLE001
                pos = None
            stop(world, state, bus)
            if pos is not None:
                try:
                    places.enter(world, state, H.hex_of_point(world, pos), bus)
                except Exception:  # noqa: BLE001
                    pass
            if bus is not None:
                bus.emit("log", kind="system", text=warn)
            return {"kind": "stopped", "text": warn}
    if j.get("kind") != "voyage":
        try:                                      # safe near towns, safer on better roads, worse far out
            from game import geography
            from game import settlements as ST
            pos = geography.party_position(world, state)
            if pos is not None:
                chance *= ST.danger_factor(world, pos[0], pos[1], j.get("grade") or "road") / \
                    ST.GRADE_SAFETY["road"]
        except Exception:      # noqa: BLE001 - an odd position leaves the chance as it was
            pass
    slow = 1.0
    if j.get("kind") != "voyage":
        try:                                      # blizzards, dust storms and storms slow the going
            from game import weather as W
            slow = W.here(world, state).travel
        except Exception:      # noqa: BLE001
            slow = 1.0
    j["done"] = round(min(j["hours"], j["done"] + leg * slow * fast), 3)
    try:
        from game import geography
        geography.reveal_here(world, state)
    except Exception:          # noqa: BLE001
        pass
    state.save()
    if rng.random() < chance:
        land = j.get("terrain", "Plains")
        try:                                              # the land the road is crossing right now
            from game import geography
            pos = geography.party_position(world, state)
            b = geography.biome_at(world, *pos) if pos is not None else ""
            if b and b not in ("Ocean", "Lake"):
                land = b
        except Exception:      # noqa: BLE001
            pass
        found = encounter(world, land, levels, rng, night=state.time_of_day in ("Night", "Dusk"))
        if found:
            found["kind"] = "encounter"
            return found
    if j["done"] >= j["hours"] - 1e-6:
        dest = world.entities.get(j["to"])
        start = j["from"]
        state.journey = None
        street = places.arrival_street(world, dest, start)
        places.enter(world, state, places.street_id(dest.id, street), bus)
        if bus is not None:
            bus.emit("journey.arrived", town=dest.id)
        return {"kind": "arrived", "town": dest.id}
    dest = world.entities.get(j["to"])
    lines = ["The road winds on.", "You keep a steady pace.", "Hours pass on the road.",
             "Fields give way to rougher country, then back again.", "You stop briefly to rest your feet."]
    text = f"{rng.choice(lines)} ({j['done']:g} of {j['hours']:g} hours to {dest.name if dest else 'town'})"
    if bus is not None and not quiet:
        bus.emit("log", kind="narration", text=text)
    return {"kind": "progress", "text": text}


# ======================================================================
# The wilds
# ======================================================================
def quarry_here(book, spot) -> list[tuple[dict, int]]:
    """(quest, objective index) for unfinished hunts that live in this patch of wilds."""
    out = []
    if book is None or spot.kind != "wild":
        return out
    for q in book.active():
        for i, o in enumerate(q["objectives"]):
            h = o.get("hunt") or {}
            if o.get("done") or not h:
                continue
            if h.get("town") == spot.town.id and h.get("direction") == spot.direction:
                out.append((q, i))
    return out


def explore(world, state, rng: random.Random, levels: list[int], book=None, chance: int = 35) -> dict:
    """An hour of looking around the wilds. Returns {"kind": "encounter" | "nothing", ...}."""
    spot = places.current(world, state)
    state.advance(60, "exploring")
    if spot.kind == "hex":
        return _explore_hex(world, state, spot, rng, levels, chance)
    hunts = quarry_here(book, spot)
    if hunts and rng.random() < 0.75:
        q, i = hunts[0]
        o = q["objectives"][i]
        h = o["hunt"]
        enemy = world.entities.get(h["enemy"])
        if enemy is not None:
            n = int(h.get("count") or 1)
            if o["kind"] == "Defeat":
                n = max(1, o["count"] - int(o.get("progress", 0)))
            return {"kind": "encounter", "rows": [{"id": enemy.id, "count": n}],
                    "environment": ENV_TO_MAP.get(h.get("environment") or terrain_of(spot.town), "forest"),
                    "text": f"You find what you came for: {counted(enemy.name, n)}!", "quest": q["id"]}
    from game import dungeons as D
    from game import geography
    hidden = [e for e in D.here_from_wild(world, state, spot.town.id, spot.direction)
              if not D.is_discovered(state, e)]
    if hidden and rng.random() < 0.45:
        e = hidden[0]
        D.discover(state, e)
        what = (e.fields.get("kind") or e.type).lower()
        return {"kind": "found", "target": e.id,
                "text": f"You come across something: {e.name}, a {what}. It's marked on your map."}
    region = geography.region_of_town(world, spot.town)
    chance += int((region.fields.get("danger") if region is not None else 0) or 0)
    if rng.random() < chance / 100.0:
        found = encounter(world, terrain_of(spot.town), levels, rng, region=region)
        if found:
            found["kind"] = "encounter"
            found["text"] = rng.choice(["Something was watching you. ", "Tracks, then movement. ",
                                        "You aren't alone out here. "]) + found["text"].replace("block the way",
                                        "come at you").replace("blocks the way", "comes at you")
            return found
    lines = ["You find nothing but wind and old tracks.", "An hour of searching turns up nothing.",
             "Birds scatter ahead of you, but nothing else stirs.", "You find a good view, and little else."]
    if hunts:
        lines = [f"No sign of your quarry yet, but this is the right place. ({hunts[0][0]['title']})"]
    return {"kind": "nothing", "text": rng.choice(lines)}


def _explore_hex(world, state, spot, rng: random.Random, levels: list[int], chance: int) -> dict:
    """An hour searching one hex of open country: hidden places in it, or trouble."""
    from game import dungeons as D
    from game import hexes as H
    q, r = spot.extra["q"], spot.extra["r"]
    here = H.things_in(world, q, r)
    hidden = [e for e in here["landmarks"] + here["dungeons"] if not D.is_discovered(state, e)]
    if hidden and rng.random() < 0.45:
        e = hidden[0]
        D.discover(state, e)
        what = (e.fields.get("kind") or e.type).lower()
        return {"kind": "found", "target": e.id,
                "text": f"You come across something: {e.name}, a {what}. It's marked on your map."}
    region = spot.extra.get("region")
    chance += int((region.fields.get("danger") if region is not None else 0) or 0)
    from game import settlements as ST
    chance *= ST.danger_factor(world, *H.center(world, q, r))
    if rng.random() < chance / 100.0:
        found = encounter(world, H._terrain(spot.extra.get("biome") or "Plains"), levels, rng, region=region)
        if found:
            found["kind"] = "encounter"
            found["text"] = rng.choice(["Something was watching you. ", "Tracks, then movement. ",
                                        "You aren't alone out here. "]) + found["text"].replace(
                "block the way", "come at you").replace("blocks the way", "comes at you")
            return found
    lines = ["You find nothing but wind and old tracks.", "An hour of searching turns up nothing.",
             "You find a good view, and little else.", "Nothing here but the land itself."]
    return {"kind": "nothing", "text": rng.choice(lines)}
