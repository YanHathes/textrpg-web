"""Player homes: buy a house in a town, then build rooms onto it from the room tiles (game/rooms.py).

Only a home out on the party's own land can grow new rooms. A building inside a town (a house bought on a
street, or anything built on a town lot) keeps its walls: it's furnished from within instead (FURNISHINGS:
beds, a hearth, shelves, a shrine..., and WORKBENCHES: the crafting stations), so nothing is ever built out past
its lot or into a neighbour.

A home is a building with "Owned by the party" ticked. It belongs to the playthrough, not the world: it's
kept in the save's holdings (game/holdings.py), so another save in the same world doesn't have it. Its rooms are the same kind of layout as any
other building's; building onto it attaches a tile to an open doorway (or the top of a stair), costs the
tile's gold and takes its days. What a home does for you comes from its rooms' perks:
    Rest      a bedroom, kitchen or bath: sleep at home for free, safe from the road
    Healing   a home shrine: a night at home also clears exhaustion and restores every hit die
    Income    lodgers' rooms and gardens: a little gold for every day since you last slept at home
"""
from __future__ import annotations

import random

from game import rooms as R

PRICE = {"Village": 400, "Town": 800, "City": 1500, "Capital": 2500}       # gold for a small house
INCOME_PER_DAY = {"Lodger's Room": 2, "Herb Garden": 1}                      # gp a day (other Income rooms: 1)
HOME_KINDS = ("House", "Mansion")
MAX_INCOME_DAYS = 30


def homes(world) -> list:
    """The party's homes: houses bought in town, and finished buildings of its own with somewhere to sleep
    (game/estate.py). Workshops, farms and the like on its land aren't homes."""
    out = []
    for b in sorted(world.entities.having("building", "owner"), key=lambda b: b.name.lower()):
        if not b.fields.get("owner"):
            continue
        if b.fields.get("claim") and (b.fields.get("status") != "done" or not perks(world, b).get("Rest")):
            continue
        out.append(b)
    return out


def home_in(world, town) -> object | None:
    if town is None:
        return None
    return next((b for b in homes(world) if (b.fields.get("town") or "") == town.id), None)


def price_in(world, town) -> int:
    from game import geography as G
    return PRICE.get(G.settlement_kind(town), 0) if town is not None else 0


def can_buy(world, state, spot) -> tuple[bool, int, str]:
    """(allowed, price in gp, why not)."""
    if spot is None or spot.kind != "street" or spot.town is None:
        return False, 0, "Find a street in a town first."
    price = price_in(world, spot.town) if not spot.town.fields.get("settlement") else 0
    if not price:
        return False, 0, "There are no houses for sale in a place this small."
    if home_in(world, spot.town) is not None:
        return False, price, "You already have a home here."
    if state.copper < price * 100:
        return False, price, f"A house here costs {price} gp."
    return True, price, ""


def buy(world, state, spot, owner_name: str = "", bus=None):
    """Buy a small house on this street: a front room, a bedroom and a kitchen. Returns the building."""
    ok, price, why = can_buy(world, state, spot)
    if not ok:
        raise ValueError(why)
    state.add_copper(-price * 100, f"a house in {spot.town.name}")
    name = f"{owner_name}'s House" if owner_name else "Your House"
    k = 2
    base = name
    while world.entities.has_name("building", name):
        name = f"{base} {k}"
        k += 1
    b = world.entities.create("building", name, {
        "kind": "House", "town": spot.town.id, "street": spot.street, "interior": "Wooden",
        "open_hours": "always", "owner": True, "generate": False, "size": "Small"},
        f"Your own house on {spot.street}, {spot.town.name}. Room to grow.", overlay=True)
    lay = R.Layout("House", "building", R.FOOTPRINT["Mansion"], random.Random(b.id))
    front = R.tile(world, "Front Room")
    lay.add(dict(front, door_used=None), 0, 0, 0)
    for k2, (side, _o) in enumerate(lay.rooms[0]["doors"]):
        if side == "S":
            lay.rooms[0]["used"].add(k2)
            break
    for want in ("Bedroom", "Kitchen"):
        t = R.tile(world, want)
        for i, k2 in lay.open_doors():
            cands = lay.candidates([t], i, k2)
            if cands:
                tt, (x, y) = cands[0]
                lay.add(tt, x, y, lay.rooms[i]["floor"], i, k2)
                break
    world.entities.update(b.id, fields={"rooms": lay.rows(), "income_day": state.day})
    if bus is not None:
        bus.emit("log", kind="quest", text=f"You buy a house on {spot.street} for {price} gp. Welcome home.")
        bus.emit("home.bought", building=b.id)
    return world.entities.get(b.id)


def buildable(world) -> list[dict]:
    """Room tiles a player can build onto a home (they have a cost)."""
    out, seen = [], set()
    for kind in HOME_KINDS:
        for t in R.tiles_for(world, kind, "building"):
            if float(t.get("cost") or 0) > 0 and t["name"] not in seen:
                seen.add(t["name"])
                out.append(dict(t, min=0))
    return out


def layout(world, b) -> R.Layout:
    return R.Layout.from_rows(world, R.ensure(world, b), "House", "building", R.FOOTPRINT["Mansion"],
                              random.Random(b.id))


def build_room(world, state, b, lay: R.Layout, t: dict, x: int, y: int, floor: int, parent: int,
               parent_door: int | None, bus=None) -> tuple[bool, str]:
    """Pay for and build one room onto the home (already checked to fit). Days pass while it's built. Only out
    on the party's own land: a building in town is furnished from within (furnish)."""
    if not can_extend(b):
        return False, "A building in town can't grow past its walls: furnish it from within instead."
    from game import estate
    cost = int(float(t.get("cost") or 0))
    if state.copper < cost * 100:
        return False, f"{t['name']} costs {cost} gp; you have {state.copper // 100}."
    mats = estate.room_materials(world, t)
    lack = [(i, n - state.count(i)) for i, n in mats if state.count(i) < n]
    if lack:
        names = ", ".join(f"{n} more {(world.entities.get(i).name if world.entities.get(i) else i)}" for i, n in lack)
        return False, f"{t['name']} also takes materials: you need {names}."
    state.add_copper(-cost * 100, f"building a {t['name'].lower()}")
    for i, n in mats:
        state.remove_item(i, n, f"building a {t['name'].lower()}")
    days = int(t.get("days") or 0)
    if days:
        state.advance(days * 1440, f"building a {t['name'].lower()}")
    lay.add(t, x, y, floor, parent, parent_door)
    world.entities.update(b.id, fields={"rooms": lay.rows()})
    msg = f"The {t['name'].lower()} is finished" + (f" after {days} day{'s' if days != 1 else ''}" if days else "") + \
        f" ({cost} gp" + (" and the materials" if mats else "") + ")."
    if bus is not None:
        bus.emit("log", kind="quest", text=msg)
        bus.emit("home.built", building=b.id, room=t["name"])
    return True, msg


def perks(world, b) -> dict[str, int]:
    """perk -> how many rooms give it (from the room's tile, or what it's been furnished with)."""
    out: dict[str, int] = {}
    for row in R.ensure(world, b):
        t = R.tile(world, row.get("tile") or "")
        got = {(t or {}).get("perk") or ""}
        for f in row.get("furnished") or []:
            got.add(FURNISH_PERK.get(f, ""))
        for p in got - {""}:
            out[p] = out.get(p, 0) + 1
    return out


# ======================================================================
# Building within: furniture and workbenches (for buildings in town)
# ======================================================================
# feature -> (label, gp, [(material, count)])         the feature is what game/area.py furnish() lays in
FURNISHINGS = {
    "beds": ("Beds", 20, [("Timber Plank", 6)]),
    "tables": ("Table and chairs", 10, [("Timber Plank", 4)]),
    "hearth": ("A hearth", 15, [("Stone Block", 6)]),
    "shelves": ("Shelves", 8, [("Timber Plank", 3)]),
    "crates": ("Crates and barrels", 5, [("Timber Plank", 3)]),
    "desk": ("A writing desk", 12, [("Timber Plank", 4)]),
    "counter": ("A counter", 10, [("Timber Plank", 4)]),
    "racks": ("Weapon racks", 15, [("Timber Plank", 3), ("Iron Ingot", 1)]),
    "bath": ("A bathtub", 30, [("Iron Ingot", 2), ("Timber Plank", 2)]),
    "altar": ("A shrine", 60, [("Stone Block", 8)]),
}
FURNISH_PERK = {"beds": "Rest", "altar": "Healing"}
# facility (game/crafting.py FACILITY_STATION) -> (gp, [(material, count)])
WORKBENCHES = {
    "Forge": (40, [("Stone Block", 10), ("Iron Ingot", 4)]),
    "Carpenter's bench": (20, [("Timber Plank", 8)]),
    "Tannery": (20, [("Timber Plank", 6)]),
    "Loom": (25, [("Timber Plank", 8)]),
    "Alchemy lab": (50, [("Stone Block", 4), ("Timber Plank", 4)]),
    "Scribe's desk": (15, [("Timber Plank", 4)]),
    "Jeweler's bench": (40, [("Iron Ingot", 2), ("Timber Plank", 3)]),
    "Kitchen": (25, [("Stone Block", 6), ("Iron Ingot", 1)]),
}
FURNISH_HOURS = 3


def in_town(b) -> bool:
    return bool(b is not None and b.fields.get("town"))


def can_extend(b) -> bool:
    """New rooms only out on the party's own land: a building in town is furnished from within."""
    return b is not None and bool(b.fields.get("owner")) and not in_town(b)


def room_room(row: dict) -> int:
    """How many more pieces of furniture a room has space for."""
    inside = max(0, int(row.get("w") or 0) - 1) * max(0, int(row.get("h") or 0) - 1)
    return max(1, inside // 12) - len(row.get("furnished") or [])


def bench_room(world, b) -> int:
    """How many more workbenches the building has floor for."""
    inside = sum(max(0, int(r.get("w") or 0) - 1) * max(0, int(r.get("h") or 0) - 1)
                 for r in R.ensure(world, b) if int(r.get("floor") or 0) == 0)
    return max(1, inside // 25) - len(b.fields.get("facilities") or [])


def _laid_out(world, b, fields: dict) -> tuple[dict, set]:
    """Lay the building out on its own (as it would be with these fields): {room name: pieces of furniture in
    it}, and the crafting stations it got. To check something new actually fits before it's paid for."""
    from game import area as A
    from game.entities import Entity
    e = Entity(b.id, b.type, b.name, b.description, list(b.tags), {**b.fields, **fields}, [], b.created, b.modified)
    rows = [r for r in (e.fields.get("rooms") or []) if str(r.get("name") or "").strip() and
            int(r.get("floor") or 0) == 0]
    if not rows:
        return {}, set()
    p = A.Plan(e, rows, world)
    w, h = p.size()
    a = A.Area(f"furnish:{b.id}", "town", w + 4, h + 4)
    lv = A.Level("0", 0, 0, w + 4, h + 4, "grass")
    a.levels["0"] = lv
    p.px = p.py = 2
    A._stamp_town_building(world, a, lv, p, {}, 0, 0, "path")
    pieces = {}
    for r in rows:
        x, y, rw, rh = p.rect_of(r)
        pieces[r["name"]] = sum(1 for q in lv.props if x < q.x < x + rw and y < q.y < y + rh)
    benches = {st.get("station") for st in lv.stations.values() if st.get("kind") == "craft"}
    return pieces, benches


def furnish_cost(world, what: str) -> tuple[int, list[tuple[str, int]]]:
    """(gp, [(item id, count)]) for a furnishing ('feature') or a workbench ('bench:<facility>')."""
    from game import estate
    if what.startswith("bench:"):
        gp, mats = WORKBENCHES.get(what[6:], (0, []))
    else:
        _label, gp, mats = FURNISHINGS.get(what, ("", 0, []))
    return gp, [(i, n) for i, n in ((estate._item_ref(world, m), n) for m, n in mats) if i]


def furnish(world, state, b, room: str, what: str, bus=None) -> tuple[bool, str]:
    """Put a piece of furniture into one of the building's rooms, or a workbench into the building."""
    if b is None or not b.fields.get("owner"):
        return False, "That isn't yours to furnish."
    rows = [dict(r) for r in R.ensure(world, b)]
    bench = what.startswith("bench:")
    if bench:
        fac = what[6:]
        if fac not in WORKBENCHES:
            return False, "No such workbench."
        if fac in (b.fields.get("facilities") or []):
            return False, f"There's a {fac.lower()} here already."
        if bench_room(world, b) <= 0:
            return False, "There's no floor left for another workbench."
        label = fac
    else:
        if what not in FURNISHINGS:
            return False, "No such furniture."
        row = next((r for r in rows if r.get("name") == room), None)
        if row is None:
            return False, "No such room."
        if what in (row.get("furnished") or []) or what in R.tile_features(world, {"tile": row.get("tile")}):
            return False, f"The {room.lower()} has that already."
        if room_room(row) <= 0:
            return False, f"The {room.lower()} is full."
        label = FURNISHINGS[what][0]
    gp, mats = furnish_cost(world, what)
    if state.copper < gp * 100:
        return False, f"{label} costs {gp} gp."
    lack = [(i, n - state.count(i)) for i, n in mats if state.count(i) < n]
    if lack:
        return False, f"{label} needs " + ", ".join(
            f"{n} more {(world.entities.get(i).name if world.entities.get(i) else i)}" for i, n in lack) + "."
    if bench:
        change = {"facilities": list(b.fields.get("facilities") or []) + [label]}
    else:
        for r in rows:
            if r.get("name") == room:
                r["furnished"] = list(r.get("furnished") or []) + [what]
        change = {"rooms": rows}
    before, _b = _laid_out(world, b, {})
    after, benches = _laid_out(world, b, change)
    from game import crafting
    if (bench and crafting.FACILITY_STATION.get(label) not in benches) or \
            (not bench and after.get(room, 0) <= before.get(room, 0)):
        return False, f"There's no space for {label.lower()} " + ("in here." if bench else f"in the {room.lower()}.")
    state.add_copper(-gp * 100, f"furnishing {b.name}")
    for i, n in mats:
        state.remove_item(i, n, f"furnishing {b.name}")
    world.entities.update(b.id, fields=change)
    state.advance(FURNISH_HOURS * 60, f"furnishing {b.name}")
    from game import estate
    from game import area as A
    estate._changed(world, state, claim=b.fields.get("claim") or None, town=b.fields.get("town") or "")
    A.forget(f"town:{b.fields.get('town')}") if b.fields.get("town") else None
    msg = f"{label} {'goes in' if bench else 'goes into the ' + room.lower()} ({gp} gp" + \
        (" and the materials" if mats else "") + ")."
    if bus is not None:
        bus.emit("log", kind="quest", text=msg)
    return True, msg


def income(world, state, b) -> int:
    """Gold waiting to be collected (from Income rooms, for the days since you last slept at home)."""
    days = max(0, min(MAX_INCOME_DAYS, state.day - int(b.fields.get("income_day") or state.day)))
    per = 0
    for row in R.ensure(world, b):
        t = R.tile(world, row.get("tile") or "")
        if (t or {}).get("perk") == "Income":
            per += INCOME_PER_DAY.get(t["name"], 1)
    return per * days


def rest(world, state, b, members: list, bus=None) -> list[str]:
    """A night at home: free, safe; a shrine heals completely; lodgers and gardens pay out."""
    from game import condition
    have = perks(world, b)
    lines = []
    gold = income(world, state, b)
    if gold:
        state.add_copper(gold * 100, "income from your home")
        lines.append(f"Your home has earned {gold} gp since you were last here.")
    world.entities.update(b.id, fields={"income_day": state.day})
    if not have.get("Rest"):
        lines.append("There's nowhere comfortable to sleep yet: build a bedroom.")
        if bus is not None:
            for line in lines:
                bus.emit("log", kind="system", text=line)
        return lines
    out = condition.long_rest(world, state, members, bus)
    if out and have.get("Healing"):
        for m in members:
            if m.get("dead"):
                continue
            rec = condition.record(state, m)
            rec["hit_dice"] = int(m.get("level") or 1)
            rec["conditions"] = {}
        state.save()
        lines.append("The shrine's quiet light leaves everyone whole: exhaustion gone, every hit die restored.")
    if bus is not None:
        for line in lines:
            bus.emit("log", kind="heal", text=line)
    return lines
