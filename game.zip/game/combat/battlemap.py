"""Battle maps: a grid of floor, walls, water and props, generated to fit where
the fight happens (a tavern, a street, a forest, a dungeon...).

The map knows which squares block movement; combat.py does the rules.
render() produces the full background picture (everything except creatures).
"""
from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass, field

from game.art import tiles as TL
from game.art.canvas import Canvas

ENVIRONMENT_LABELS = {
    "forest": "Forest", "plains": "Plains", "street": "Town street", "interior": "Building interior",
    "dungeon": "Dungeon", "cave": "Cave", "swamp": "Swamp", "desert": "Desert", "arctic": "Snowfield",
    "coast": "Coast", "hills": "Hills", "dungeon_room": "Dungeon room", "ship": "Ship's deck",
    "airship": "Airship deck", "caravan": "Caravan", "arena": "Arena",
}

# Map from the template environment names to generator names.
ENVIRONMENT_ALIASES = {
    "Forest": "forest", "Plains": "plains", "Hills": "hills", "Mountains": "hills", "Swamp": "swamp",
    "Desert": "desert", "Arctic": "arctic", "Coast": "coast", "Underwater": "coast", "Urban": "street",
    "Dungeon": "dungeon", "Cave": "cave", "Interior": "interior", "Arena": "arena",
}


@dataclass
class Prop:
    id: str
    x: int
    y: int
    variant: int = 0

    @property
    def defn(self) -> TL.PropDef:
        return TL.prop_def(self.id)

    def cells(self) -> list[tuple[int, int]]:
        d = self.defn
        return [(self.x + dx, self.y + dy) for dy in range(d.h) for dx in range(d.w)]


@dataclass
class BattleMap:
    w: int
    h: int
    environment: str = "plains"
    floor: list[list[tuple[str, int]]] = field(default_factory=list)
    walls: dict[tuple[int, int], str] = field(default_factory=dict)
    water: dict[tuple[int, int], str] = field(default_factory=dict)
    props: list[Prop] = field(default_factory=list)
    player_zone: list[tuple[int, int]] = field(default_factory=list)
    enemy_zone: list[tuple[int, int]] = field(default_factory=list)
    style: str = ""

    def __post_init__(self) -> None:
        if not self.floor:
            self.floor = [[("grass", 0) for _ in range(self.w)] for _ in range(self.h)]
        self._blocked: set[tuple[int, int]] | None = None

    # ---- queries --------------------------------------------------------
    def inside(self, x: int, y: int) -> bool:
        return 0 <= x < self.w and 0 <= y < self.h

    def blocked_cells(self) -> set[tuple[int, int]]:
        if self._blocked is None:
            b = set(self.walls) | set(self.water)
            for p in self.props:
                if p.defn.blocks:
                    b.update(p.cells())
            self._blocked = b
        return self._blocked

    def invalidate(self) -> None:
        self._blocked = None

    def walkable(self, x: int, y: int) -> bool:
        return self.inside(x, y) and (x, y) not in self.blocked_cells()

    def fits(self, x: int, y: int, size: int, ignore: set | None = None) -> bool:
        """Can a creature of `size` squares per side stand with its top-left at (x, y)?"""
        for dy in range(size):
            for dx in range(size):
                if not self.walkable(x + dx, y + dy):
                    return False
                if ignore is not None and (x + dx, y + dy) in ignore:
                    return False
        return True

    def edge_cells(self) -> set[tuple[int, int]]:
        cells = set()
        for x in range(self.w):
            cells.add((x, 0))
            cells.add((x, self.h - 1))
        for y in range(self.h):
            cells.add((0, y))
            cells.add((self.w - 1, y))
        return {c for c in cells if self.walkable(*c)}

    def prop_at(self, x: int, y: int) -> Prop | None:
        for p in self.props:
            if (x, y) in p.cells():
                return p
        return None

    def cover_at(self, x: int, y: int) -> bool:
        p = self.prop_at(x, y)
        return bool(p and p.defn.cover)

    # ---- drawing ----------------------------------------------------------
    def render(self, include_tall: bool = True) -> Canvas:
        T = TL.T
        out = Canvas(self.w * T, self.h * T)
        for y in range(self.h):
            for x in range(self.w):
                kind, v = self.floor[y][x]
                out.blit(TL.floor_tile(kind, v), x * T, y * T)
        self._blend_floors(out)
        self._wall_shadows(out)
        for (x, y), kind in self.water.items():
            mask = self._mask(x, y, self.water, same_kind=kind)
            out.blit(TL.water_tile(mask, (x * 7 + y * 3) % 4, kind), x * T, y * T)
        for (x, y), kind in self.walls.items():
            mask = self._mask(x, y, self.walls, edge_counts=True)
            out.blit(TL.wall_tile(kind, mask), x * T, y * T)
        for p in sorted(self.props, key=lambda p: (p.y + p.defn.h, p.x)):
            if p.defn.tall and not include_tall:
                continue
            art = TL.prop_sprite(p.id, p.variant)
            dx, dy = TL.prop_offset(p.id, art.w, art.h)
            out.blit(art, p.x * T + dx, p.y * T + dy)
        wreck = self.__dict__.get("wreck") or {}
        for (x, y), n in (wreck.get("dmg") or {}).items():         # battered, and burning (game/combat/wreck.py)
            if n:
                out.blit(TL.crack_sprite(1), x * T, y * T)
        for (x, y) in sorted(wreck.get("burning") or ()):
            art = TL.flame_sprite((x + y) % 2, 2)
            out.blit(art, x * T, y * T + T - art.h)
        return out

    def _blend_floors(self, out: Canvas) -> None:
        """Soft, ragged edges where natural ground types meet (grass spilling over dirt)."""
        T = TL.T
        for y in range(self.h):
            for x in range(self.w):
                kind, _ = self.floor[y][x]
                if kind not in NATURAL_PRIORITY:
                    continue
                mine = NATURAL_PRIORITY[kind]
                sides = {}
                for name, (dx, dy) in (("n", (0, -1)), ("s", (0, 1)), ("w", (-1, 0)), ("e", (1, 0)),
                                       ("nw", (-1, -1)), ("ne", (1, -1)), ("sw", (-1, 1)), ("se", (1, 1))):
                    nx, ny = x + dx, y + dy
                    if not self.inside(nx, ny):
                        continue
                    other, ov = self.floor[ny][nx]
                    if other in NATURAL_PRIORITY and NATURAL_PRIORITY[other] > mine:
                        sides[name] = (other, ov)
                if not sides:
                    continue
                for py0 in range(T):
                    for px0 in range(T):
                        px, py = px0 - px0 % 2, py0 - py0 % 2         # decided per art pixel (2 x 2)
                        jitter = _jitter(x * T + px, y * T + py)
                        best = None
                        best_d = 99.0
                        for name, src in sides.items():
                            if name == "n":
                                d = py
                            elif name == "s":
                                d = T - 1 - py
                            elif name == "w":
                                d = px
                            elif name == "e":
                                d = T - 1 - px
                            else:
                                cx = 0 if "w" in name else T - 1
                                cy = 0 if "n" in name else T - 1
                                if name[0] in sides or name[1] in sides:
                                    continue
                                d = ((px - cx) ** 2 + (py - cy) ** 2) ** 0.5 - 1
                            if d < best_d:
                                best_d, best = d, src
                        if best is None:
                            continue
                        v = best_d + jitter
                        if v < 6.5:
                            out.set(x * T + px0, y * T + py0, TL.floor_tile(best[0], best[1]).get(px0, py0))
                        elif v < 7.5:
                            under = out.get(x * T + px0, y * T + py0)
                            if under is not None:
                                out.set(x * T + px0, y * T + py0, _darken(under, 0.82))

    def _wall_shadows(self, out: Canvas) -> None:
        T = TL.T
        for (x, y) in self.walls:
            if self.inside(x, y + 1) and (x, y + 1) not in self.walls:
                for d in range(7):
                    a = int(150 * (1 - d / 7))
                    for px in range(T):
                        out.put(x * T + px, (y + 1) * T + d, (10, 12, 14, a))
            if self.inside(x + 1, y) and (x + 1, y) not in self.walls:
                for d in range(4):
                    a = int(70 * (1 - d / 4))
                    for py in range(T):
                        out.put((x + 1) * T + d, y * T + py, (10, 12, 14, a))

    def render_tall(self) -> Canvas:
        """Only the props drawn above creatures (tree canopies)."""
        T = TL.T
        out = Canvas(self.w * T, self.h * T)
        for p in self.props:
            if p.defn.tall:
                art = TL.prop_sprite(p.id, p.variant)
                dx, dy = TL.prop_offset(p.id, art.w, art.h)
                out.blit(art, p.x * T + dx, p.y * T + dy)
        return out

    def _mask(self, x: int, y: int, cells: dict, same_kind: str | None = None, edge_counts: bool = False) -> int:
        m = 0
        for bit, (dx, dy) in ((TL.N, (0, -1)), (TL.E, (1, 0)), (TL.S, (0, 1)), (TL.W, (-1, 0))):
            nx, ny = x + dx, y + dy
            if not self.inside(nx, ny):
                if edge_counts:
                    m |= bit
                continue
            if (nx, ny) in cells and (same_kind is None or cells[(nx, ny)] == same_kind):
                m |= bit
        return m

    # ---- persistence ----------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "w": self.w, "h": self.h, "environment": self.environment, "style": self.style,
            "floor": [[list(c) for c in row] for row in self.floor],
            "walls": [[x, y, k] for (x, y), k in self.walls.items()],
            "water": [[x, y, k] for (x, y), k in self.water.items()],
            "props": [[p.id, p.x, p.y, p.variant] for p in self.props],
            "player_zone": [list(c) for c in self.player_zone],
            "enemy_zone": [list(c) for c in self.enemy_zone],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "BattleMap":
        m = cls(d["w"], d["h"], d.get("environment", "plains"),
                [[tuple(c) for c in row] for row in d["floor"]],
                {(x, y): k for x, y, k in d.get("walls", [])},
                {(x, y): k for x, y, k in d.get("water", [])},
                [Prop(i, x, y, v) for i, x, y, v in d.get("props", [])],
                [tuple(c) for c in d.get("player_zone", [])],
                [tuple(c) for c in d.get("enemy_zone", [])],
                d.get("style", ""))
        return m


NATURAL_PRIORITY = {"cave": 1, "dirt": 2, "path": 3, "sand": 4, "grass": 6, "snow": 7}


def _jitter(x: int, y: int) -> float:
    h = (x * 374761393 + y * 668265263) & 0xFFFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
    return ((h & 0xFFFF) / 0xFFFF) * 2.6 - 1.3 + 2.6 * __import__("math").sin(x * 0.55) * __import__("math").cos(y * 0.45)


def _darken(c, f: float):
    return (int(c[0] * f), int(c[1] * f), int(c[2] * f), c[3])


# ======================================================================
# Generation
# ======================================================================
def generate(environment: str = "plains", w: int = 18, h: int = 13, seed: int | None = None,
             style: str = "") -> BattleMap:
    env = ENVIRONMENT_ALIASES.get(environment, environment)
    if env not in ENVIRONMENT_LABELS:
        env = "plains"
    rng = random.Random(seed)
    gen = {
        "forest": _forest, "plains": _plains, "street": _street, "interior": _interior,
        "dungeon": _dungeon, "cave": _cave, "swamp": _swamp, "desert": _desert, "arctic": _arctic,
        "coast": _coast, "hills": _hills, "dungeon_room": _dungeon_room, "ship": _ship, "airship": _airship,
        "caravan": _caravan, "arena": _arena,
    }[env]
    for attempt in range(12):
        m = BattleMap(w, h, env, style=style)
        gen(m, rng)
        _zones(m)
        if _connect(m, rng):
            return m
    return m


def _fill(m: BattleMap, kind: str, rng: random.Random, variants: int = 4) -> None:
    m.floor = [[(kind, rng.randrange(variants)) for _ in range(m.w)] for _ in range(m.h)]


def _patch(m: BattleMap, kind: str, rng: random.Random, count: int, radius: tuple[int, int] = (1, 3)) -> None:
    """Organic blobs of a ground type, grown by a short random walk of overlapping circles."""
    for _ in range(count):
        x, y = rng.randrange(m.w), rng.randrange(m.h)
        steps = rng.randint(radius[0] + 2, radius[1] * 3 + 2)
        for _ in range(steps):
            r = rng.choice((0.9, 1.2, 1.5))
            for yy in range(int(y - 2), int(y + 3)):
                for xx in range(int(x - 2), int(x + 3)):
                    if m.inside(xx, yy) and (xx - x) ** 2 + (yy - y) ** 2 <= r * r:
                        m.floor[yy][xx] = (kind, rng.randrange(3))
            x += rng.choice((-1, 0, 1))
            y += rng.choice((-1, 0, 1))


def _path(m: BattleMap, kind: str, rng: random.Random, horizontal: bool = True) -> None:
    if horizontal:
        y = rng.randrange(m.h // 3, 2 * m.h // 3)
        for x in range(m.w):
            for dy in (0, 1):
                if m.inside(x, y + dy):
                    m.floor[y + dy][x] = (kind, rng.randrange(3))
            if rng.random() < 0.3:
                y = max(1, min(m.h - 3, y + rng.choice((-1, 1))))
    else:
        x = rng.randrange(m.w // 3, 2 * m.w // 3)
        for y in range(m.h):
            for dx in (0, 1):
                if m.inside(x + dx, y):
                    m.floor[y][x + dx] = (kind, rng.randrange(3))
            if rng.random() < 0.3:
                x = max(1, min(m.w - 3, x + rng.choice((-1, 1))))


UNIQUE_PROPS = {"well", "cart", "forge", "altar", "counter", "big_tree"}


def _scatter(m: BattleMap, prop_ids: list[str], rng: random.Random, count: int, avoid_edges: int = 3) -> None:
    occupied = {c for p in m.props for c in p.cells()} | set(m.walls) | set(m.water)
    tries = 0
    placed = 0
    while placed < count and tries < count * 30:
        tries += 1
        pid = rng.choice(prop_ids)
        if pid in UNIQUE_PROPS and any(p.id == pid for p in m.props):
            continue
        d = TL.prop_def(pid)
        x = rng.randrange(avoid_edges, max(avoid_edges + 1, m.w - avoid_edges - d.w + 1))
        y = rng.randrange(0, m.h - d.h + 1)
        cells = [(x + dx, y + dy) for dy in range(d.h) for dx in range(d.w)]
        if any(c in occupied or not m.inside(*c) for c in cells):
            continue
        m.props.append(Prop(pid, x, y, rng.randrange(8)))
        occupied.update(cells)
        placed += 1
    m.invalidate()


def _forest(m, rng):
    _fill(m, "grass", rng)
    _patch(m, "dirt", rng, 3)
    if rng.random() < 0.6:
        _path(m, "path", rng)
    _scatter(m, ["tree", "tree", "tree", "pine", "big_tree"], rng, int(m.w * m.h * 0.09))
    _scatter(m, ["bush", "bush", "rock", "stump", "mushrooms", "log"], rng, int(m.w * m.h * 0.05))


def _plains(m, rng):
    _fill(m, "grass", rng)
    _patch(m, "dirt", rng, 2)
    if rng.random() < 0.7:
        _path(m, "path", rng)
    _scatter(m, ["bush", "rock", "tree", "haybale"], rng, int(m.w * m.h * 0.035))


def _hills(m, rng):
    _fill(m, "grass", rng)
    _patch(m, "dirt", rng, 4, (1, 2))
    for _ in range(3):
        cx, cy = rng.randrange(m.w), rng.randrange(m.h)
        for y in range(cy - 1, cy + 2):
            for x in range(cx - 2, cx + 2):
                if m.inside(x, y) and rng.random() < 0.75:
                    m.walls[(x, y)] = "rock_wall"
    _scatter(m, ["boulder", "rock", "rock", "bush", "pine"], rng, int(m.w * m.h * 0.05))


def _swamp(m, rng):
    _fill(m, "grass", rng)
    _patch(m, "dirt", rng, 3)
    for _ in range(4):
        cx, cy = rng.randrange(m.w), rng.randrange(m.h)
        r = rng.randint(1, 2)
        for y in range(cy - r, cy + r + 1):
            for x in range(cx - r - 1, cx + r + 2):
                if m.inside(x, y) and rng.random() < 0.85:
                    m.water[(x, y)] = "swamp"
    _scatter(m, ["tree", "bush", "mushrooms", "stump", "log"], rng, int(m.w * m.h * 0.05))


def _desert(m, rng):
    _fill(m, "sand", rng, 3)
    _scatter(m, ["rock", "rock", "boulder", "bones"], rng, int(m.w * m.h * 0.035))


def _arctic(m, rng):
    _fill(m, "snow", rng, 3)
    _scatter(m, ["pine", "pine", "rock", "boulder"], rng, int(m.w * m.h * 0.05))


def _coast(m, rng):
    _fill(m, "sand", rng, 3)
    _patch(m, "grass", rng, 2)
    edge = rng.randint(3, 4)
    for y in range(m.h):
        for x in range(m.w):
            if y >= m.h - edge + round(1.2 * __import__("math").sin(x * 0.7 + rng.random() * 0.3)):
                m.water[(x, y)] = "water"
    _scatter(m, ["rock", "bush", "log"], rng, int(m.w * m.h * 0.03))


def _arena(m, rng):
    """An arena's floor: raked sand inside a ring wall, a few pillars and braziers to fight round."""
    _fill(m, "sand", rng, 3)
    cx, cy = (m.w - 1) / 2, (m.h - 1) / 2
    rx, ry = m.w / 2 - 0.5, m.h / 2 - 0.5
    for y in range(m.h):
        for x in range(m.w):
            if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 > 1.0:
                m.walls[(x, y)] = "stone_wall"
    for x, y in ((int(cx - rx * 0.45), int(cy)), (int(cx + rx * 0.45), int(cy))):
        if 0 < x < m.w - 1:
            m.props.append(Prop("pillar", x, y, rng.randrange(2)))
    for x, y in ((int(cx), 1), (int(cx), m.h - 2)):
        if (x, y) not in m.walls:
            m.props.append(Prop("brazier", x, y, 0))


def _street(m, rng):
    _fill(m, "cobble", rng, 3)
    wall_kind = rng.choice(["stone_wall", "wood_wall", "brick_wall"])
    top, bottom = rng.randint(2, 3), rng.randint(2, 3)
    for x in range(m.w):
        for y in range(top):
            m.walls[(x, y)] = wall_kind
        for y in range(m.h - bottom, m.h):
            m.walls[(x, y)] = wall_kind
    # doors and alley gaps
    for row in (top - 1, m.h - bottom):
        for _ in range(3):
            x = rng.randrange(2, m.w - 2)
            m.walls.pop((x, row), None)
            m.floor[row][x] = ("wood", 0)
    if rng.random() < 0.6:
        x = rng.randrange(4, m.w - 4)
        for y in range(m.h):
            m.walls.pop((x, y), None)
    _scatter(m, ["barrel", "crate", "barrel", "cart", "well", "haybale"], rng, int(m.w * 0.5))


def _interior(m, rng):
    style = m.style or rng.choice(["Wooden", "Stone", "Rich", "Rustic"])
    m.style = style
    floor = {"Wooden": "wood", "Stone": "stone", "Rich": "carpet", "Rustic": "wood"}[style]
    _fill(m, floor, rng, 3)
    wall_kind = {"Wooden": "wood_wall", "Stone": "stone_wall", "Rich": "stone_wall", "Rustic": "wood_wall"}[style]
    for x in range(m.w):
        m.walls[(x, 0)] = wall_kind
        m.walls[(x, m.h - 1)] = wall_kind
    for y in range(m.h):
        m.walls[(0, y)] = wall_kind
        m.walls[(m.w - 1, y)] = wall_kind
    # doors on left and right so both sides can arrive
    for x in (0, m.w - 1):
        y = m.h // 2
        m.walls.pop((x, y), None)
        m.walls.pop((x, y - 1), None)
    if rng.random() < 0.5:
        split = rng.randrange(m.w // 3, 2 * m.w // 3)
        for y in range(1, m.h - 1):
            if abs(y - m.h // 2) > 1:
                m.walls[(split, y)] = wall_kind
    m.props.append(Prop("counter", rng.randrange(3, m.w - 6), 2, 0))
    m.props.append(Prop("bookshelf", rng.randrange(3, m.w - 6), 1, rng.randrange(3)))
    _scatter(m, ["table", "table", "chair", "chair", "barrel", "crate", "chest", "brazier"], rng,
             int(m.w * m.h * 0.05), avoid_edges=3)


def _dungeon(m, rng):
    _fill(m, "dungeon", rng, 3)
    for y in range(m.h):
        for x in range(m.w):
            m.walls[(x, y)] = "stone_wall"
    rooms = []
    for _ in range(30):
        rw, rh = rng.randint(4, 7), rng.randint(3, 6)
        rx, ry = rng.randrange(1, max(2, m.w - rw - 1)), rng.randrange(1, max(2, m.h - rh - 1))
        if any(rx < o[0] + o[2] + 1 and o[0] < rx + rw + 1 and ry < o[1] + o[3] + 1 and o[1] < ry + rh + 1 for o in rooms):
            continue
        rooms.append((rx, ry, rw, rh))
        if len(rooms) >= 5:
            break
    rooms.sort()
    for rx, ry, rw, rh in rooms:
        for y in range(ry, ry + rh):
            for x in range(rx, rx + rw):
                m.walls.pop((x, y), None)
    for a, b in zip(rooms, rooms[1:]):
        ax, ay = a[0] + a[2] // 2, a[1] + a[3] // 2
        bx, by = b[0] + b[2] // 2, b[1] + b[3] // 2
        for x in range(min(ax, bx), max(ax, bx) + 1):
            for dy in (0, 1):
                m.walls.pop((x, ay + dy), None)
        for y in range(min(ay, by), max(ay, by) + 1):
            for dx in (0, 1):
                m.walls.pop((bx + dx, y), None)
    # open the left and right edges where the first and last rooms are
    for room, x_range in ((rooms[0], range(0, rooms[0][0] + 1)), (rooms[-1], range(rooms[-1][0], m.w))):
        y = room[1] + room[3] // 2
        for x in x_range:
            m.walls.pop((x, y), None)
    _scatter(m, ["pillar", "rubble", "bones", "brazier", "chest", "rubble"], rng, len(rooms) * 2, avoid_edges=2)


def _dungeon_room(m, rng):
    """One dungeon room, shaped by its type (m.style): Room, Hallway, Chamber, Treasure room,
    Special, Boss or Entrance. Doors on the left and right walls."""
    kind = m.style or "Room"
    _fill(m, "dungeon", rng, 3)
    for x in range(m.w):
        m.walls[(x, 0)] = "stone_wall"
        m.walls[(x, m.h - 1)] = "stone_wall"
    for y in range(m.h):
        m.walls[(0, y)] = "stone_wall"
        m.walls[(m.w - 1, y)] = "stone_wall"
    mid = m.h // 2
    for x in (0, m.w - 1):
        for y in (mid - 1, mid):
            m.walls.pop((x, y), None)
    if kind == "Hallway":
        _scatter(m, ["rubble", "bones"], rng, 2, avoid_edges=2)
        return
    if kind in ("Chamber", "Boss"):
        for x in range(4, m.w - 4, 5):                   # two rows of pillars
            for y in (3, m.h - 4):
                m.props.append(Prop("pillar", x, y, rng.randrange(2)))
        for x, y in ((1, 1), (m.w - 2, 1), (1, m.h - 2), (m.w - 2, m.h - 2)):
            m.props.append(Prop("brazier", x, y, 0))
        if kind == "Boss":
            m.props.append(Prop(rng.choice(["altar", "statue"]), m.w - 4, mid - 1, 0))
        _scatter(m, ["rubble", "bones"], rng, 3, avoid_edges=3)
        return
    if kind == "Treasure room":
        for _ in range(rng.randint(2, 3)):
            m.props.append(Prop("chest", rng.randrange(2, m.w - 2), rng.choice([1, m.h - 2]), rng.randrange(3)))
        _scatter(m, ["crate", "barrel"], rng, 2, avoid_edges=2)
        return
    if kind == "Special":
        m.props.append(Prop(rng.choice(["altar", "statue", "well", "bookshelf"]), m.w // 2, 1, 0))
    _scatter(m, ["rubble", "bones", "brazier", "crate", "table", "chest"], rng, max(2, m.w * m.h // 40),
             avoid_edges=2)


def _deck(m, rng, void: str):
    """A ship's deck across the middle of the map, with water (or sky) all round."""
    _fill(m, "wood", rng, 3)
    top, bottom = 2, m.h - 3
    for y in range(m.h):
        for x in range(m.w):
            narrow = 1 if x >= m.w - 3 else 0           # the bow tapers
            if y < top + narrow or y > bottom - narrow:
                m.water[(x, y)] = void
    for x in range(m.w // 3, m.w - 3, max(5, m.w // 3)):  # masts
        m.props.append(Prop("pillar", x, m.h // 2, 0))
    _scatter(m, ["barrel", "crate", "barrel", "crate"], rng, max(3, m.w // 4), avoid_edges=2)


def _ship(m, rng):
    _deck(m, rng, "sea")


def _airship(m, rng):
    _deck(m, rng, "sky")


def _caravan(m, rng):
    """Wagons halted on a road across open land (m.style: the land, e.g. desert or plains)."""
    land = (m.style or "plains").lower()
    if land in ("desert", "badlands"):
        _fill(m, "sand", rng, 3)
    elif land in ("arctic",):
        _fill(m, "snow", rng, 3)
    else:
        _fill(m, "grass", rng, 4)
    mid = m.h // 2
    for y in range(mid - 1, mid + 2):
        for x in range(m.w):
            m.floor[y][x] = ("path", rng.randrange(3))
    for x in range(m.w // 2 - 4, m.w // 2 + 5, 4):
        m.props.append(Prop("cart", x, mid - 1, rng.randrange(2)))
    _scatter(m, ["crate", "barrel", "haybale", "rock", "bush"], rng, max(3, m.w * m.h // 30), avoid_edges=2)


def _cave(m, rng):
    _fill(m, "cave", rng, 3)
    cells = {(x, y): rng.random() < 0.43 for y in range(m.h) for x in range(m.w)}
    for _ in range(4):
        nxt = {}
        for (x, y), wall in cells.items():
            n = sum(cells.get((x + dx, y + dy), True) for dx in (-1, 0, 1) for dy in (-1, 0, 1) if dx or dy)
            nxt[(x, y)] = n >= 5 or (n >= 4 and wall)
        cells = nxt
    for (x, y), wall in cells.items():
        if wall:
            m.walls[(x, y)] = "rock_wall"
    if rng.random() < 0.5:
        cx, cy = rng.randrange(m.w // 3, 2 * m.w // 3), rng.randrange(m.h // 3, 2 * m.h // 3)
        for y in range(cy - 1, cy + 2):
            for x in range(cx - 1, cx + 2):
                if (x, y) not in m.walls and m.inside(x, y):
                    m.water[(x, y)] = "water"
    _scatter(m, ["mushrooms", "rock", "boulder", "bones", "rubble"], rng, int(m.w * m.h * 0.035), avoid_edges=2)


def _zones(m: BattleMap) -> None:
    m.invalidate()
    left = [(x, y) for x in range(0, 4) for y in range(m.h) if m.walkable(x, y)]
    right = [(x, y) for x in range(m.w - 4, m.w) for y in range(m.h) if m.walkable(x, y)]
    m.player_zone, m.enemy_zone = left, right


def _connect(m: BattleMap, rng: random.Random) -> bool:
    """Make sure the two sides can reach each other, carving a path if needed."""
    if not m.player_zone or not m.enemy_zone:
        # carve a corridor through the middle row
        y = m.h // 2
        for x in range(m.w):
            m.walls.pop((x, y), None)
            m.water.pop((x, y), None)
            m.props = [p for p in m.props if (x, y) not in p.cells()]
        _zones(m)
    reach = flood(m, m.player_zone[0]) if m.player_zone else set()
    if any(c in reach for c in m.enemy_zone):
        return _enough_room(m)
    # carve a wandering path from left to right
    y = m.player_zone[0][1]
    for x in range(m.w):
        m.walls.pop((x, y), None)
        m.water.pop((x, y), None)
        m.props = [p for p in m.props if (x, y) not in p.cells()]
        if rng.random() < 0.25:
            y = max(1, min(m.h - 2, y + rng.choice((-1, 1))))
            m.walls.pop((x, y), None)
            m.water.pop((x, y), None)
            m.props = [p for p in m.props if (x, y) not in p.cells()]
    _zones(m)
    reach = flood(m, m.player_zone[0])
    return any(c in reach for c in m.enemy_zone) and _enough_room(m)


def _enough_room(m: BattleMap) -> bool:
    walkable = sum(1 for y in range(m.h) for x in range(m.w) if m.walkable(x, y))
    return walkable >= m.w * m.h * 0.35 and len(m.player_zone) >= 4 and len(m.enemy_zone) >= 4


def flood(m: BattleMap, start: tuple[int, int], size: int = 1) -> set[tuple[int, int]]:
    seen = {start}
    q = deque([start])
    while q:
        x, y = q.popleft()
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                n = (x + dx, y + dy)
                if n not in seen and m.fits(n[0], n[1], size):
                    seen.add(n)
                    q.append(n)
    return seen
