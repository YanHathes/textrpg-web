"""Turn world entities (enemies, NPCs, a test character) into Combatants."""
from __future__ import annotations

import random
import uuid

from game import dice
from game.combat import features as F
from game.combat.engine import ALLY, ENEMY, PLAYER, Attack, Combatant, Consumable, Spell
from game.constants import CR_XP, SIZES, cr_value

FEET = 5


def _id() -> str:
    return uuid.uuid4().hex[:8]


def stat_scores(world, given: dict | None) -> dict[str, int]:
    scores = {}
    for stat in world.entities.stats():
        key = stat.fields.get("key")
        if key:
            scores[key] = int(stat.fields.get("default", 10) or 10)
    for k, v in (given or {}).items():
        try:
            scores[k] = int(v)
        except (TypeError, ValueError):
            pass
    return scores


def modifiers(world, scores: dict) -> dict[str, int]:
    return {k: world.modifier(k, v) for k, v in scores.items()}


def _stat_key(world, stat_id: str) -> str:
    stat = world.entities.get(stat_id)
    return stat.fields.get("key", "") if stat else ""


def _squares(feet) -> int:
    try:
        return max(0, int(round(float(feet or 0) / FEET)))
    except (TypeError, ValueError):
        return 0


# ----------------------------------------------------------------------
# Weapons, armor and spells
# ----------------------------------------------------------------------
AMMO_BY_NAME = (("crossbow", "Bolt"), ("sling", "Sling bullet"), ("blowgun", "Blowgun needle"), ("bow", "Arrow"))


def ammo_type(item) -> str:
    """What a weapon fires ('' for weapons that don't need ammunition)."""
    f = item.fields
    if f.get("uses_ammo"):
        return f["uses_ammo"]
    if "ammunition" not in (f.get("properties") or []):
        return ""
    low = item.name.lower()
    return next((t for word, t in AMMO_BY_NAME if word in low), "Arrow")


def weapon_attacks(world, item, mods: dict, prof: int, two_handed_grip: bool = False,
                   offhand: bool = False, magic: bool = True) -> list[Attack]:
    """Attacks a weapon gives. offhand=True: the two-weapon bonus attack, which adds
    no ability modifier to damage (unless the modifier is negative)."""
    f = item.fields
    rules = world.rules
    props = set(f.get("properties") or [])
    kind = (f.get("weapon_kind") or "").lower()
    ranged = "ranged" in kind
    str_key, dex_key = rules.get("melee_stat", "str"), rules.get("ranged_stat", "dex")
    if "finesse" in props:
        stat = str_key if mods.get(str_key, 0) >= mods.get(dex_key, 0) else dex_key
    elif ranged:
        stat = dex_key
    else:
        stat = str_key
    mod = mods.get(stat, 0)
    magic = int(f.get("magic_bonus") or 0) if magic else 0
    q_hit, q_dmg = int(f.get("quality_attack") or 0), int(f.get("quality_damage") or 0)   # (game/quality.py)
    to_hit = mod + prof + magic + q_hit
    base = f.get("damage") or "1d4"
    if two_handed_grip and "versatile" in props and f.get("versatile_damage"):
        base = f["versatile_damage"]
    bonus = (min(0, mod) if offhand else mod) + magic + q_dmg
    dmg = base if bonus == 0 else f"{base}{'+' if bonus > 0 else '-'}{abs(bonus)}"
    if not dice.is_valid(dmg):
        dmg = "1d4"
    dtype = f.get("damage_type") or "bludgeoning"
    extra = dict(stat=stat, finesse="finesse" in props, light="light" in props, offhand=offhand,
                 ammo_type=ammo_type(item) if ranged else "",
                 magical=bool(int(f.get("magic_bonus") or 0) or f.get("rarity") not in (None, "", "Common")))
    name = f"{item.name} (off hand)" if offhand else item.name
    out = []
    if ranged:
        out.append(Attack(name, "Ranged", to_hit, dmg, dtype, 1, _squares(f.get("range_ft") or 80),
                          _squares(f.get("long_range_ft") or f.get("range_ft") or 80), item.id, **extra))
    else:
        reach = 2 if "reach" in props else 1
        out.append(Attack(name, "Melee", to_hit, dmg, dtype, reach, 0, 0, item.id, **extra))
        if "thrown" in props and f.get("range_ft") and not offhand:
            out.append(Attack(f"{item.name} (thrown)", "Ranged", to_hit, dmg, dtype, 1, _squares(f.get("range_ft")),
                              _squares(f.get("long_range_ft") or f.get("range_ft")), item.id, **extra))
    return out


def unarmed_strike(world, mods: dict, prof: int) -> Attack:
    key = world.rules.get("melee_stat", "str")
    return Attack("Unarmed strike", "Melee", prof + mods.get(key, 0), str(max(1, 1 + mods.get(key, 0))),
                  "bludgeoning", stat=key)


def armor_worn(world, equipment: dict) -> tuple[str, bool, int]:
    """(armor type worn or "", has a shield, shield AC bonus)."""
    kind, shield, shield_ac = "", False, 0
    for item_id in equipment.values():
        item = world.entities.get(item_id)
        if not item:
            continue
        cat = item.fields.get("category")
        if cat == "Armor":
            kind = item.fields.get("armor_type") or "Light"
        elif cat == "Shield":
            shield = True
            shield_ac = int(item.fields.get("armor_class") or 2) + int(item.fields.get("magic_bonus") or 0) + \
                int(item.fields.get("quality_ac") or 0)
    return kind, shield, shield_ac


def armor_class(world, equipment: dict, mods: dict, unattuned: set | None = None) -> int:
    dex = mods.get(world.rules.get("armor_stat", "dex"), 0)
    body = shield = 0
    found_armor = False
    for item_id in equipment.values():
        item = world.entities.get(item_id)
        if not item:
            continue
        f = item.fields
        cat = f.get("category")
        magic = 0 if unattuned and item.id in unattuned else int(f.get("magic_bonus") or 0)
        if cat == "Armor":
            found_armor = True
            cap = int(f.get("dex_cap", -1) if f.get("dex_cap") is not None else -1)
            body = int(f.get("armor_class") or 10) + (dex if cap < 0 else min(dex, cap)) + magic + \
                int(f.get("quality_ac") or 0)
        elif cat == "Shield":
            shield = int(f.get("armor_class") or 2) + magic + int(f.get("quality_ac") or 0)
    if not found_armor:
        body = 10 + dex
    return body + shield


def build_spell(world, spell) -> Spell:
    skill = spell
    f = spell.fields
    area = f.get("area") or "None"
    return Spell(
        id=skill.id, name=skill.name, level=int(f.get("level") or 0),
        effect=f.get("effect") or "Utility", damage=f.get("damage") or "", damage_type=f.get("damage_type") or "",
        healing=f.get("healing") or "", save_stat=_stat_key(world, f.get("save_stat")) or "dex",
        on_save=f.get("on_save") or "Half damage", range=_squares(f.get("range_ft", 30)),
        area=area, area_size=_squares(f.get("area_ft")) if area != "None" else 0,
        missiles=int(f.get("missiles") or 1), upcast=f.get("upcast") or "",
        casting_time=f.get("casting_time") or "Action", description=skill.description,
        condition=f.get("condition") or "", condition_rounds=int(f.get("condition_rounds") or 0),
        condition_save_each_turn=bool(f.get("condition_save_each_turn", True)),
        effects=[F.Effect(r.get("effect") or "Note", str(r.get("amount") or ""), str(r.get("detail") or ""),
                          r.get("only_when") or "Always") for r in f.get("buff_effects") or [] if r.get("effect")],
        buff_target=f.get("buff_target") or "Self", rounds=F.rounds_from_text(f.get("duration")),
        concentration=bool(f.get("concentration")), reaction_trigger=f.get("reaction_trigger") or "",
        temp_hp=f.get("temp_hp") or "", summons=f.get("summons") or "", summon_count=str(f.get("summon_count") or "1"),
        removes=list(f.get("removes") or []), revive_hp=int(f.get("revive_hp") or 1), ritual=bool(f.get("ritual")),
        cantrip_scaling=f.get("cantrip_scaling") or "Damage dice",
        hp_limit=int(f.get("hp_limit") or 0), slays=bool(f.get("slays")),
    )


def _consumables(world, ids: list) -> list[Consumable]:
    out: dict[str, Consumable] = {}
    for item_id in ids:
        item = world.entities.get(item_id)
        if not item or item.fields.get("category") != "Consumable":
            continue
        effect = item.fields.get("use_effect") or "Heal"
        if item.id in out:
            out[item.id].count += 1
        else:
            out[item.id] = Consumable(item.id, item.name, effect, item.fields.get("use_dice") or "1d4",
                                      timing=_timing(item))
    return list(out.values())


def _timing(item) -> str:
    return "Bonus action" if item.fields.get("use_action") == "Bonus action" else "Action"


def _spells(world, ids) -> list[Spell]:
    return [build_spell(world, s) for s in (world.entities.get(i) for i in ids or []) if s and s.type == "spell"]


def _equipment_attacks(world, equipment: dict, mods: dict, prof: int) -> list[Attack]:
    attacks, _bonus = _weapon_attacks(world, equipment, mods, prof)
    return attacks


def _weapon_attacks(world, equipment: dict, mods: dict, prof: int,
                    unattuned: set | None = None) -> tuple[list[Attack], list[Attack]]:
    """Attacks with the weapons held, plus the off-hand bonus attack when both hands
    hold light melee weapons (two-weapon fighting)."""
    attacks = []
    has_shield = any((world.entities.get(i) or _Nil).fields.get("category") == "Shield" for i in equipment.values())
    for slot in ("Main hand", "Two hands", "Off hand"):
        item = world.entities.get(equipment.get(slot))
        if item and item.fields.get("category") == "Weapon":
            attacks += weapon_attacks(world, item, mods, prof, two_handed_grip=not has_shield and slot != "Off hand",
                                      magic=not (unattuned and item.id in unattuned))
    bonus = []
    main = world.entities.get(equipment.get("Main hand"))
    off = world.entities.get(equipment.get("Off hand"))

    def light_melee(it):
        return (it and it.fields.get("category") == "Weapon" and "light" in (it.fields.get("properties") or [])
                and "ranged" not in (it.fields.get("weapon_kind") or "").lower())
    if light_melee(main) and light_melee(off):
        bonus = [a for a in weapon_attacks(world, off, mods, prof, offhand=True) if not a.ranged]
    return attacks, bonus


class _Nil:
    fields: dict = {}


def _carried_light(world, equipment: dict) -> tuple[int, int]:
    bright = dim = 0
    for item_id in equipment.values():
        item = world.entities.get(item_id)
        if not item:
            continue
        f = item.fields
        b, d = _squares(f.get("light_bright_ft")), _squares(f.get("light_dim_ft"))
        if not (b or d) and (f.get("sprite") == "weapon/torch" or item.name.lower() in ("torch", "lantern")):
            b, d = 4, 4
        if b + d > bright + dim:
            bright, dim = b, d
    return bright, dim


def _darkvision(world, entity_or_none, race) -> int:
    own = int((entity_or_none.fields.get("darkvision") if entity_or_none else 0) or 0)
    ft = own or int((race.fields.get("darkvision") if race else 0) or 0)
    return _squares(ft)


def _size_of(world, entity) -> int:
    size = entity.fields.get("size")
    race = world.entities.get(entity.fields.get("race"))
    if (not size or size == "Medium") and race and race.fields.get("size") not in (None, "", "Medium"):
        size = race.fields.get("size")
    return SIZES.get(size or "Medium", 1)


def _race_mods(world, race, scores: dict) -> dict:
    if not race:
        return scores
    out = dict(scores)
    for row in race.fields.get("stat_modifiers") or []:
        key = _stat_key(world, row.get("stat"))
        if key:
            out[key] = out.get(key, 10) + int(row.get("amount") or 0)
    return out


# ----------------------------------------------------------------------
# Enemies
# ----------------------------------------------------------------------
def from_enemy(world, enemy, rng: random.Random | None = None, team: str = ENEMY, name: str = "") -> Combatant:
    rng = rng or random.Random()
    f = enemy.fields
    scores = stat_scores(world, f.get("stats"))
    mods = modifiers(world, scores)
    prof = int(f.get("proficiency") or 2)
    equipment = dict(f.get("equipment") or {})
    hp = int(f.get("hp") or 1)
    if f.get("hp_dice") and dice.is_valid(f["hp_dice"]):
        hp = max(1, dice.roll(f["hp_dice"], rng).total)
    ac = int(f.get("ac") or 0) or armor_class(world, equipment, mods)

    attacks = []
    for row in f.get("attacks") or []:
        if not row.get("name") or not dice.is_valid(row.get("damage") or ""):
            continue
        ranged = row.get("kind") == "Ranged"
        sq = max(1, _squares(row.get("reach_ft") or 5))
        long_sq = max(sq, _squares(row.get("long_range_ft") or 0)) if row.get("long_range_ft") else sq * 4
        attacks.append(Attack(row["name"], "Ranged" if ranged else "Melee", int(row.get("to_hit") or 0),
                              row["damage"], row.get("damage_type") or "bludgeoning",
                              1 if ranged else sq, sq if ranged else 0, long_sq if ranged else 0,
                              stat="dex" if ranged else "str", condition=row.get("condition") or "",
                              cond_save=_stat_key(world, row.get("save_stat")),
                              cond_dc=int(row.get("save_dc") or 0),
                              extra_damage=str(row.get("extra_damage") or ""),
                              extra_type=row.get("extra_type") or "", magical=bool(f.get("magic_attacks"))))
    held, bonus_attacks = _weapon_attacks(world, equipment, mods, prof)
    attacks += held
    if not attacks:
        attacks.append(unarmed_strike(world, mods, prof))

    spell_key = _stat_key(world, f.get("spell_stat"))
    spell_mod = mods.get(spell_key, 0)
    spells = _spells(world, f.get("spells"))

    race = world.entities.get(f.get("race"))
    resist = set(f.get("resistances") or []) | set((race.fields.get("resistances") if race else None) or [])
    xp = int(f.get("xp") or 0) or CR_XP.get(str(f.get("cr", "1")), 0)
    fly = int(f.get("fly_speed") or 0) or int((race.fields.get("fly_speed") if race else 0) or 0)
    speed = int(f.get("speed") or 30)
    lb, ld = _carried_light(world, equipment)
    worn, shield, shield_ac = armor_worn(world, equipment)
    c = Combatant(
        level=max(1, int(cr_value(f.get("cr", "1")))), bonus_attacks=bonus_attacks,
        armor_worn=worn, has_shield=shield, shield_ac=shield_ac,
        darkvision=_darkvision(world, enemy, race), light_bright=lb, light_dim=ld,
        id=_id(), name=name or enemy.name, team=team, hp=hp, max_hp=hp, ac=ac,
        speed=max(1, _squares(max(speed, fly))), size=_size_of(world, enemy), entity_id=enemy.id,
        stats=scores, mods=mods, prof=prof,
        saves={_stat_key(world, s) for s in f.get("saving_throws") or []},
        attacks=attacks, attacks_per_action=max(1, int(f.get("multiattack") or 1)),
        spells=spells, spell_attack=prof + spell_mod, spell_dc=8 + prof + spell_mod, casting_stat=spell_key,
        resist=resist, immune=set(f.get("immunities") or []), vulnerable=set(f.get("vulnerabilities") or []),
        behavior=f.get("behavior") or "Aggressive", xp=xp, loot=list(f.get("loot") or []), gold=f.get("gold") or "",
        flying=fly > 0, init_bonus=mods.get(world.rules.get("initiative_stat", "dex"), 0), is_monster=True,
        condition_immune={x.title() for x in f.get("condition_immunities") or []},
        race_id=race.id if race else "", equipment=list(equipment.values()),
        vars={c["key"]: c.get("value") for c in enemy.custom if c.get("key")},
    )
    c.features = F.build_all(world, list(f.get("features") or []) + race_features(race), c)
    F.apply_static(world, c)
    slots = {}
    for i, part in enumerate(str(f.get("spell_slots") or "").replace(";", ",").split(","), start=1):
        try:
            if int(part.strip()) > 0:
                slots[i] = int(part.strip())
        except ValueError:
            pass
    c.slots, c.slots_max = dict(slots), dict(slots)
    c.legendary_max = c.legendary_left = max(0, int(f.get("legendary_actions") or 0))
    c.legendary = [dict(r) for r in f.get("legendary") or [] if r.get("does") or r.get("what")]
    c.legendary_resist = max(0, int(f.get("legendary_resistance") or 0))
    c.weapon_guard = f.get("weapon_guard") or ""
    return c


def race_features(race) -> list[str]:
    return list((race.fields.get("features") if race else None) or [])


def class_features(klass, level: int) -> list[str]:
    out = []
    for row in (klass.fields.get("features") if klass else None) or []:
        if isinstance(row, dict) and row.get("feature") and int(row.get("level") or 1) <= level:
            until = int(row.get("until") or 0)
            if until and level >= until:
                continue                       # replaced by a better version at that level
            out.append(row["feature"])
    return out


# ----------------------------------------------------------------------
# Characters (test arena, later the real player)
# ----------------------------------------------------------------------
STANDARD_ARRAY = [15, 14, 13, 12, 10, 8]


def character(world, name: str, race_id: str = "", class_id: str = "", level: int = 1,
              equipment: dict | None = None, scores: dict | None = None, potions: int = 2,
              team: str = PLAYER) -> Combatant:
    race = world.entities.get(race_id)
    klass = world.entities.get(class_id)
    level = max(1, min(20, int(level)))
    prof = 2 + (level - 1) // 4
    equipment = dict(equipment or {})

    if not scores:
        keys = [s.fields.get("key") for s in world.entities.stats() if s.fields.get("key")]
        primary = _stat_key(world, klass.fields.get("primary_stat")) if klass else ""
        hp_key = world.rules.get("hp_stat", "con")
        order = [k for k in [primary, hp_key, world.rules.get("ranged_stat", "dex")] if k in keys]
        order += [k for k in keys if k not in order]
        scores = {k: STANDARD_ARRAY[i] if i < len(STANDARD_ARRAY) else 10 for i, k in enumerate(order)}
    scores = _race_mods(world, race, stat_scores(world, scores))
    mods = modifiers(world, scores)

    hit_die = int(str((klass.fields.get("hit_die") if klass else "d8") or "d8").lstrip("d") or 8)
    con = mods.get(world.rules.get("hp_stat", "con"), 0)
    hp = max(1, hit_die + con + (level - 1) * (hit_die // 2 + 1 + con))

    attacks, bonus_attacks = _weapon_attacks(world, equipment, mods, prof)
    attacks.append(unarmed_strike(world, mods, prof))      # always an option
    extra_at = int((klass.fields.get("extra_attacks") if klass else 0) or 0)
    per_action = 2 if extra_at and level >= extra_at else 1

    spells, slots, cast_key = [], {}, ""
    if klass and klass.fields.get("spellcasting"):
        cast_key = _stat_key(world, klass.fields.get("casting_stat"))
        spells = _spells(world, klass.fields.get("spells"))
        rows = sorted((r for r in klass.fields.get("slots") or [] if int(r.get("level") or 0) <= level),
                      key=lambda r: int(r.get("level") or 0))
        if rows:
            for i, part in enumerate(str(rows[-1].get("slots") or "").split(","), start=1):
                try:
                    if int(part.strip()) > 0:
                        slots[i] = int(part.strip())
                except ValueError:
                    pass
    cast_mod = mods.get(cast_key, 0)

    speed = int((race.fields.get("speed") if race else 30) or 30)
    items = _consumables(world, [i for i in equipment.values()])
    potion = next((e for e in world.entities.all("item") if e.fields.get("category") == "Consumable"
                   and (e.fields.get("use_effect") or "Heal") == "Heal"), None)
    if potion and potions > 0:
        existing = next((c for c in items if c.item_id == potion.id), None)
        if existing:
            existing.count += potions
        else:
            items.append(Consumable(potion.id, potion.name, "Heal", potion.fields.get("use_dice") or "2d4+2", potions,
                                    timing=_timing(potion)))

    lb, ld = _carried_light(world, equipment)
    worn, shield, shield_ac = armor_worn(world, equipment)
    c = Combatant(
        level=level, bonus_attacks=bonus_attacks, armor_worn=worn, has_shield=shield, shield_ac=shield_ac,
        darkvision=_darkvision(world, None, race), light_bright=lb, light_dim=ld,
        id=_id(), name=name, team=team, hp=hp, max_hp=hp,
        ac=armor_class(world, equipment, mods), speed=max(1, _squares(speed)),
        size=SIZES.get((race.fields.get("size") if race else "Medium") or "Medium", 1),
        stats=scores, mods=mods, prof=prof,
        saves={_stat_key(world, s) for s in ((klass.fields.get("saving_throws") if klass else None) or [])},
        attacks=attacks, attacks_per_action=per_action, spells=spells, spell_attack=prof + cast_mod,
        spell_dc=8 + prof + cast_mod, casting_stat=cast_key, slots=slots, slots_max=dict(slots), items=items,
        resist=set((race.fields.get("resistances") if race else None) or []),
        init_bonus=mods.get(world.rules.get("initiative_stat", "dex"), 0),
        race_id=race.id if race else "", class_id=klass.id if klass else "", equipment=list(equipment.values()),
    )
    c.features = F.build_all(world, class_features(klass, level) + race_features(race), c,
                             {fid: level for fid in class_features(klass, level)})
    F.apply_static(world, c)
    return c


def from_npc(world, npc, rng: random.Random | None = None, team: str = ENEMY) -> Combatant:
    """An NPC turned hostile: uses its 'fights as' stat block, or its class and level."""
    stat_block = world.entities.get(npc.fields.get("fights_as"))
    if stat_block:
        c = from_enemy(world, stat_block, rng, team, name=npc.name)
        c.entity_id = npc.id
        return c
    c = character(world, npc.name, npc.fields.get("race") or "", npc.fields.get("class") or "",
                  int(npc.fields.get("level") or 1), npc.fields.get("equipment") or {}, potions=0, team=team)
    c.entity_id = npc.id
    c.is_monster = True
    c.xp = CR_XP.get(str(max(0, int(npc.fields.get("level") or 1) // 2)), 25)
    return c


__all__ = ["from_enemy", "from_npc", "character", "weapon_attacks", "armor_class", "build_spell", "ALLY", "PLAYER",
           "ENEMY"]
