"""The SRD conditions and what they do in a fight.

A creature's conditions live in `combatant.conditions`:
    name -> {"rounds": rounds left (-1 = until removed), "source": id of who caused it,
             "save": [stat key, DC] to shake it off at the end of each of its turns (or None),
             "level": exhaustion level}

What each condition does (5e SRD 5.1, appendix A):
  Blinded        can't see: its attacks have disadvantage, attacks against it have advantage
  Charmed        can't attack whoever charmed it
  Deafened       can't hear (no effect in a fight yet)
  Frightened     disadvantage on attacks and checks while it can see the source; can't move closer to it
  Grappled       speed 0
  Incapacitated  no actions, bonus actions or reactions
  Invisible      can't be seen: its attacks have advantage, attacks against it have disadvantage
  Paralyzed      incapacitated, can't move, fails STR and DEX saves, attacks against it have
                 advantage, and any hit from within 5 feet is a critical hit
  Petrified      incapacitated, can't move, fails STR and DEX saves, attacks against it have
                 advantage, resistance to all damage, immune to poison
  Poisoned       disadvantage on attacks and ability checks
  Prone          its attacks have disadvantage; attacks against it have advantage from within
                 5 feet and disadvantage from further away; standing up costs half its speed
  Restrained     speed 0, its attacks have disadvantage, attacks against it have advantage,
                 disadvantage on DEX saves
  Stunned        incapacitated, can't move, fails STR and DEX saves, attacks against it have advantage
  Unconscious    incapacitated, can't move, falls prone, fails STR and DEX saves, attacks against
                 it have advantage, and any hit from within 5 feet is a critical hit
  Exhaustion     levels: 1 disadvantage on checks, 2 speed halved, 3 disadvantage on attacks and
                 saves, 4 hit point maximum halved, 5 speed 0, 6 death
"""
from __future__ import annotations

import math

CONDITIONS = ["Blinded", "Charmed", "Deafened", "Exhaustion", "Frightened", "Grappled", "Incapacitated",
              "Invisible", "Paralyzed", "Petrified", "Poisoned", "Prone", "Restrained", "Stunned", "Unconscious"]

INCAPACITATED = {"Incapacitated", "Paralyzed", "Petrified", "Stunned", "Unconscious"}
CANT_MOVE = {"Grappled", "Restrained", "Paralyzed", "Petrified", "Stunned", "Unconscious"}
FAILS_STR_DEX = {"Paralyzed", "Petrified", "Stunned", "Unconscious"}
EASY_TO_HIT = {"Blinded", "Paralyzed", "Petrified", "Restrained", "Stunned", "Unconscious"}
HARD_TO_ATTACK_WITH = {"Blinded", "Poisoned", "Restrained", "Prone"}
CRIT_FROM_CLOSE = {"Paralyzed", "Unconscious"}

SHORT = {
    "Blinded": "can't see", "Charmed": "won't attack the charmer", "Deafened": "can't hear",
    "Exhaustion": "worn out", "Frightened": "afraid", "Grappled": "held in place", "Incapacitated": "can't act",
    "Invisible": "unseen", "Paralyzed": "can't move or act", "Petrified": "turned to stone",
    "Poisoned": "sickened", "Prone": "on the ground", "Restrained": "held fast", "Stunned": "reeling",
    "Unconscious": "out cold",
}


def has(c, name: str) -> bool:
    return name in getattr(c, "conditions", {})


def exhaustion(c) -> int:
    rec = getattr(c, "conditions", {}).get("Exhaustion")
    return int(rec.get("level", 1)) if rec else 0


def incapacitated(c) -> bool:
    return any(n in INCAPACITATED for n in getattr(c, "conditions", {}))


def can_act(c) -> bool:
    return c.active and not incapacitated(c)


def immune(c, name: str) -> bool:
    imm = {x.title() for x in (getattr(c, "condition_immune", set()) or set())}
    return name.title() in imm or (name == "Poisoned" and "poison" in getattr(c, "immune", set()))


def speed_factor(c) -> float:
    if any(n in CANT_MOVE for n in c.conditions) or exhaustion(c) >= 5:
        return 0.0
    if exhaustion(c) >= 2:
        return 0.5
    return 1.0


def summary(c) -> str:
    parts = []
    for name, rec in sorted(c.conditions.items()):
        if name == "Exhaustion":
            parts.append(f"Exhaustion {rec.get('level', 1)}")
        elif rec.get("rounds", -1) > 0:
            parts.append(f"{name} ({rec['rounds']})")
        else:
            parts.append(name)
    return ", ".join(parts)


# ----------------------------------------------------------------------
# Applying and removing
# ----------------------------------------------------------------------
def apply(battle, target, name: str, rounds: int = -1, source=None, save: tuple | None = None,
          quiet: bool = False) -> bool:
    """Give `target` a condition. Returns False if it's immune (or already gone)."""
    name = name.strip().title() if name else ""
    if name not in CONDITIONS or not target.alive:
        return False
    if immune(target, name):
        if battle is not None and not quiet:
            battle.say("system", f"{target.name} is immune to being {name.lower()}.")
        return False
    rec = target.conditions.get(name)
    if name == "Exhaustion":
        level = (rec.get("level", 0) if rec else 0) + 1
        target.conditions[name] = {"rounds": -1, "source": "", "save": None, "level": level}
        if battle is not None and not quiet:
            battle.say("damage", f"{target.name} gains a level of exhaustion (now {level}).")
        if level >= 6 and battle is not None:
            battle.say("damage", f"{target.name} collapses from exhaustion.")
            battle.damage(target, target.hp + target.temp_hp)
    else:
        if rec and rec.get("rounds", -1) < 0 <= rounds:
            rounds = -1                                   # keep the longer one
        elif rec and rounds >= 0:
            rounds = max(rounds, rec.get("rounds", 0))
        target.conditions[name] = {"rounds": int(rounds), "source": getattr(source, "id", source or ""),
                                   "save": list(save) if save else None}
        if battle is not None and not quiet:
            how = f" for {rounds} round{'s' if rounds != 1 else ''}" if rounds > 0 else ""
            battle.say("damage", f"{target.name} is {name.lower()}{how}!")
        if name == "Unconscious" and not has(target, "Prone"):
            target.conditions["Prone"] = {"rounds": -1, "source": "", "save": None}
    if battle is not None:
        battle.refresh_stats(target)
        battle._emit("combat.condition", combatant=target, condition=name, applied=True,
                     source=source if not isinstance(source, str) else None)
    return True


def remove(battle, target, name: str, reason: str = "") -> bool:
    name = name.strip().title()
    if name not in target.conditions:
        return False
    if name == "Exhaustion" and target.conditions[name].get("level", 1) > 1 and reason != "all":
        target.conditions[name]["level"] -= 1
        lvl = target.conditions[name]["level"]
        if battle is not None:
            battle.say("heal", f"{target.name}'s exhaustion eases (now {lvl}).")
    else:
        del target.conditions[name]
        if battle is not None:
            battle.say("heal", f"{target.name} is no longer {name.lower()}{(' ' + reason) if reason and reason != 'all' else ''}.")
    if battle is not None:
        battle.refresh_stats(target)
        battle._emit("combat.condition", combatant=target, condition=name, applied=False)
    return True


def end_concentration(battle, caster, reason: str = "") -> None:
    """Drop whatever the caster was concentrating on: conditions and buffs it put on others."""
    conc = getattr(caster, "concentration", None)
    if not conc:
        return
    caster.concentration = None
    if battle is not None:
        battle.say("system", f"{caster.name} loses concentration on {conc.get('name', 'a spell')}"
                             f"{(' (' + reason + ')') if reason else ''}.")
        for c in battle.combatants:
            for name, rec in list(c.conditions.items()):
                if rec.get("concentration") == caster.id and rec.get("spell") == conc.get("id"):
                    remove(battle, c, name)
            for f in list(c.features):
                if getattr(f, "granted_by", "") == f"{caster.id}:{conc.get('id')}":
                    c.features.remove(f)
                    battle.refresh_stats(c)
            if getattr(c, "summoned_by", "") == f"{caster.id}:{conc.get('id')}" and c.active:
                battle._dismiss(c, f"{c.name} vanishes.")


# ----------------------------------------------------------------------
# Turns
# ----------------------------------------------------------------------
def start_of_turn(battle, c) -> None:
    """Standing up from prone costs half your speed (done for you when you can move)."""
    if has(c, "Prone") and not has(c, "Unconscious") and speed_factor(c) > 0 and c.alive:
        cost = int(math.ceil(c.speed / 2))
        if c.movement_left() >= cost:
            c.moved += cost
            del c.conditions["Prone"]
            battle.say("narration", f"{c.name} gets back up (half their movement).")
            battle._emit("combat.condition", combatant=c, condition="Prone", applied=False)


def end_of_turn(battle, c) -> None:
    """Saves to shake things off, then durations run down."""
    for name, rec in list(c.conditions.items()):
        if not c.alive:
            break
        save = rec.get("save")
        if save and save[0]:
            if battle.saving_throw(c, save[0], int(save[1])):
                remove(battle, c, name, "after a successful save")
                continue
        if rec.get("rounds", -1) > 0:
            rec["rounds"] -= 1
            if rec["rounds"] <= 0:
                remove(battle, c, name)


# ----------------------------------------------------------------------
# Rolls
# ----------------------------------------------------------------------
def attack_modifiers(battle, attacker, target) -> tuple[bool, bool]:
    """(advantage, disadvantage) from conditions on both sides."""
    adv = dis = False
    a, t = attacker.conditions, target.conditions
    if any(n in HARD_TO_ATTACK_WITH for n in a) or exhaustion(attacker) >= 3:
        dis = True
    fright = a.get("Frightened")
    if fright:
        src = next((o for o in battle.combatants if o.id == fright.get("source") and o.active), None)
        if src is None or battle.can_see(attacker, src):
            dis = True
    if any(n in EASY_TO_HIT for n in t if n != "Prone"):
        adv = True
    if "Prone" in t:
        if battle.distance(attacker, target) <= 1:
            adv = True
        else:
            dis = True
    return adv, dis


def auto_crit(battle, attacker, target) -> bool:
    return any(n in CRIT_FROM_CLOSE for n in target.conditions) and battle.distance(attacker, target) <= 1


def save_effect(c, stat: str) -> str:
    """'fail', 'disadvantage' or '' for a saving throw with this stat."""
    if stat in ("str", "dex") and any(n in FAILS_STR_DEX for n in c.conditions):
        return "fail"
    if (stat == "dex" and has(c, "Restrained")) or exhaustion(c) >= 3:
        return "disadvantage"
    return ""


def check_disadvantage(c) -> bool:
    return has(c, "Poisoned") or has(c, "Frightened") or exhaustion(c) >= 1
