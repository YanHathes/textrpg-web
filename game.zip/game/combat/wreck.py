"""Destruction in fights (Hotfix 23): walls, trees, rocks and furniture on a battle map can be attacked and
broken, area spells batter what's in them, and fire sets what burns alight. A tree falls away from whoever
brought it down, crushing those in the way (a Dexterity save against 4d6 bludgeoning). The toughness of each
thing is game/destruction.py's.

After the fight, what changed is carried back to the walking map the battle map was cut from
(game/battlesite.py: the map's "origin"): holes in walls (and buildings coming down), stumps and fallen
trunks, rubble and debris, damage short of breaking, and fires still burning (game/fire.py).

Kept on the battle map (bmap.wreck): {"dmg": {(x, y): damage}, "changed": {(x, y): land change},
"burning": {(x, y), ...}, "v": how many times it's changed (the screen redraws the field when it does)}.
"""
from __future__ import annotations

from game import destruction as D
from game.combat.battlemap import Prop

FIRE_TYPES = ("fire",)


def _w(bmap) -> dict:
    w = bmap.__dict__.get("wreck")
    if w is None:
        w = bmap.__dict__["wreck"] = {"dmg": {}, "changed": {}, "burning": set(), "v": 0}
    return w


def version(bmap) -> int:
    return int((bmap.__dict__.get("wreck") or {}).get("v", 0))


def burning(bmap) -> set:
    return set((bmap.__dict__.get("wreck") or {}).get("burning") or ())


def _prop_at(bmap, x: int, y: int):
    for p in bmap.props:
        if (x, y) in p.cells():
            return p
    return None


def _open(bmap, x: int, y: int) -> bool:
    return 0 <= x < bmap.w and 0 <= y < bmap.h and (x, y) not in bmap.walls


def thing(bmap, x: int, y: int) -> dict | None:
    """What could be broken on this square of the battle map (as destruction.thing_at)."""
    if (x, y) in bmap.walls:
        if not ((_open(bmap, x - 1, y) and _open(bmap, x + 1, y)) or (_open(bmap, x, y - 1) and _open(bmap, x, y + 1))):
            return None                                     # solid rock, or the edge of the field
        kind = bmap.walls[(x, y)]
        if kind == "rock_wall" and getattr(bmap, "underground", False):
            return None
        mat, hp, thr, fl = D.WALLS.get(kind, D.WALL_DEFAULT)
        return {"kind": "wall", "x": x, "y": y, "id": kind, "label": "Wall", "material": mat,
                "ac": D.MATERIAL[mat], "hp": hp, "threshold": thr, "flammable": fl, "leaves": "rubble"}
    p = _prop_at(bmap, x, y)
    if p is None or p.id not in D.TOUGH:
        return None
    mat, hp, thr, fl, leaves, _gp = D.TOUGH[p.id]
    return {"kind": "prop", "x": p.x, "y": p.y, "id": p.id, "label": p.defn.label, "material": mat,
            "ac": D.MATERIAL[mat], "hp": hp, "threshold": thr, "flammable": fl, "leaves": leaves, "prop": p}


def left(bmap, t: dict) -> int:
    return max(0, int(t["hp"]) - int(_w(bmap)["dmg"].get((t["x"], t["y"]), 0)))


def targets(battle, c, attack) -> list[tuple[int, int]]:
    """Squares with something on them this attack can reach."""
    bmap = battle.map
    reach = attack.max_range() if attack is not None else 1
    out = []
    cells = c.cells()
    for y in range(bmap.h):
        for x in range(bmap.w):
            d = min(max(abs(x - cx), abs(y - cy)) for cx, cy in cells)
            if d > reach or d == 0:
                continue
            if battle.at(x, y) is not None:
                continue
            t = thing(bmap, x, y)
            if t is None:
                continue
            if attack is not None and attack.ranged and attack.damage_type == "piercing" and t["material"] in (
                    "stone", "iron"):
                continue
            out.append((x, y))
    return out


def attack(battle, c, atk, cell) -> bool:
    """c attacks the thing on `cell` with atk (an attack's worth of their action)."""
    from game import dice
    if cell not in targets(battle, c, atk) or not battle.has_ammo(c, atk):
        return False
    t = thing(battle.map, *cell)
    if t is None:
        return False
    battle._spend_ammo(c, atk)
    if atk.offhand:
        if not battle.can_offhand(c):
            return False
        c.bonus_used = True
    elif not battle._attack_slot(c):
        return False
    c.facing = _facing(cell[0] - c.x, cell[1] - c.y, c.facing)
    d20 = battle.rng.randint(1, 20)
    name = t["label"].lower()
    if d20 != 20 and (d20 == 1 or d20 + atk.to_hit < t["ac"]):
        battle.say("miss", f"{c.name} swings at the {name} and misses ({d20 + atk.to_hit} vs AC {t['ac']}).")
        battle._emit("combat.terrain_hit", combatant=c, cell=cell, amount=0)
        return True
    dmg = dice.roll(atk.damage, battle.rng).total
    if d20 == 20:
        dmg += dice.roll(atk.damage, battle.rng).total
    hurt(battle, cell, dmg, atk.damage_type, frm=(c.x, c.y), who=c)
    return True


def hurt(battle, cell, amount: int, dtype: str, frm=None, who=None) -> bool:
    """Damage to the thing on `cell`. Fire sets what burns alight. Returns whether it broke."""
    bmap = battle.map
    t = thing(bmap, *cell)
    if t is None:
        return False
    w = _w(bmap)
    if (dtype or "").lower() in FIRE_TYPES and t["flammable"]:
        if (t["x"], t["y"]) not in w["burning"]:
            w["burning"].add((t["x"], t["y"]))
            w["v"] += 1
            battle.say("damage", f"The {t['label'].lower()} catches fire!")
            battle._emit("combat.terrain", cell=cell)
    amount = int(amount * D._multiplier(t, dtype))
    if amount < t["threshold"] or amount <= 0:
        if who is not None:
            battle.say("miss", f"{who.name}'s blow does nothing to the {t['label'].lower()}.")
        return False
    key = (t["x"], t["y"])
    have = left(bmap, t)
    if amount < have:
        w["dmg"][key] = int(w["dmg"].get(key, 0)) + amount
        if who is not None:
            battle.say("damage", f"{who.name} hits the {t['label'].lower()}: {amount} damage "
                                 f"({have - amount}/{t['hp']} left).")
        battle._emit("combat.terrain_hit", combatant=who, cell=cell, amount=amount)
        return False
    w["dmg"].pop(key, None)
    smash(battle, t, frm or (cell[0], cell[1] - 1), who)
    return True


def smash(battle, t: dict, frm, who=None) -> None:
    """It breaks: off the field (a tree falls)."""
    bmap = battle.map
    w = _w(bmap)
    x, y = t["x"], t["y"]
    name = t["label"].lower()
    if t["kind"] == "wall":
        bmap.walls.pop((x, y), None)
        bmap.props.append(Prop("rubble", x, y, (x * 7 + y) % 3))
        w["changed"][(x, y)] = {"wall": "", "prop": "rubble", "variant": (x * 7 + y) % 3}
        battle.say("damage", f"The {name} gives way!" if who is None else f"{who.name} breaks through the {name}!")
    elif t["leaves"] == "fall":
        _fall(battle, t, frm, who)
    else:
        p = t.get("prop")
        if p in bmap.props:
            bmap.props.remove(p)
        if t["leaves"]:
            bmap.props.append(Prop(t["leaves"], x, y, (x * 3 + y) % 3))
        w["changed"][(x, y)] = {"prop": t["leaves"], "variant": (x * 3 + y) % 3}
        battle.say("damage", f"The {name} is smashed." if who is None else f"{who.name} smashes the {name}.")
    w["burning"].discard((x, y))
    w["v"] += 1
    bmap.invalidate()
    battle._emit("combat.terrain", cell=(x, y))


def _fall(battle, t: dict, frm, who=None) -> None:
    from game import dice
    bmap = battle.map
    w = _w(bmap)
    x, y = t["x"], t["y"]
    p = t.get("prop")
    if p in bmap.props:
        bmap.props.remove(p)
    bmap.props.append(Prop("stump", x, y, 0))
    w["changed"][(x, y)] = {"prop": "stump", "variant": 0, "was": {"prop": t["id"], "variant": 0}, "regrow": True}
    dx, dy = D._dir_from(frm, x, y)
    battle.say("damage", f"The {t['label'].lower()} comes crashing down, {D._dir_word(dx, dy)}!")
    piece = 0 if dy == 0 else 1 if dx == 0 else 2 if dx == dy else 3
    n = D.TRUNK.get(t["id"], 3)
    for i in range(1, n + 1):
        cx, cy = x + dx * i, y + dy * i
        if not (0 <= cx < bmap.w and 0 <= cy < bmap.h):
            break
        if (cx, cy) in bmap.walls:
            o = thing(bmap, cx, cy)
            if o is not None:
                hurt(battle, (cx, cy), dice.roll(D.FALL_DICE, battle.rng).total, "bludgeoning", frm=(x, y))
            break
        under = battle.at(cx, cy)
        if under is not None and under.active:
            dmg = dice.roll(D.FALL_DICE, battle.rng).total
            if battle.saving_throw(under, "dex", D.FALL_DC):
                dmg //= 2
                battle.say("damage", f"{under.name} throws themselves half clear of the falling tree.")
            else:
                battle.say("damage", f"The tree comes down on {under.name}!")
            battle.damage(under, dmg, "bludgeoning", source=who)
        other = _prop_at(bmap, cx, cy)
        if other is not None and other.id in ("rock", "boulder", "well", "fountain", "statue", "pillar", "tree",
                                              "big_tree", "pine"):
            break
        if other is not None:
            bmap.props.remove(other)
        crown = i == n
        v = (cx + cy) % 3 if crown else piece
        bmap.props.append(Prop("branches" if crown else "fallen_trunk", cx, cy, v))
        w["changed"][(cx, cy)] = {"prop": "branches" if crown else "fallen_trunk", "variant": v, "trunk": True}


def area(battle, c, cells, expr: str, dtype: str) -> None:
    """An area spell's damage on what's in it (one roll for them all)."""
    from game import dice
    if not expr:
        return
    hit = {}
    for cell in cells:
        t = thing(battle.map, *cell)
        if t is not None:
            hit[(t["x"], t["y"])] = t
    if not hit:
        return
    amount = dice.roll(expr, battle.rng).total
    for (x, y) in list(hit):
        hurt(battle, (x, y), amount, dtype, frm=(c.x, c.y))


def _facing(dx: int, dy: int, now: str) -> str:
    if dx == 0 and dy == 0:
        return now
    return ("E" if dx > 0 else "W") if abs(dx) >= abs(dy) else ("S" if dy > 0 else "N")


# ----------------------------------------------------------------------------------------------------
# Back to the walking map
# ----------------------------------------------------------------------------------------------------
def write_back(ex, bmap) -> list[str]:
    """What the fight broke, carried back to the walking map it was cut from."""
    w = bmap.__dict__.get("wreck")
    org = bmap.__dict__.get("origin")
    if not w or org is None or ex is None or ex.area is None:
        return []
    x0, y0 = org[0], org[1]
    st = ex.state
    lines = []
    from game import gathering as GA
    for (x, y), chg in w["changed"].items():
        X, Y = x0 + x, y0 + y
        lv = ex.layer(X, Y)
        chg = dict(chg)
        if chg.pop("regrow", False):
            pid = (chg.get("was") or {}).get("prop") or "tree"
            days = (GA.SOURCES.get(pid) or (0, 0, 0, 0, 12))[4]
            chg["until"] = st.minutes + int(days * 1440)
        if chg.pop("trunk", False):
            chg["until"] = st.minutes + D.TRUNK_DAYS * 1440
        if "wall" in chg:
            if (X, Y) not in lv.walls:
                continue
            D._record(ex, lv, X, Y, chg)
            lines += D._wall_down(ex, lv, X, Y, ex.rng)
        else:
            D._record(ex, lv, X, Y, chg)
    for (x, y), n in w["dmg"].items():
        X, Y = x0 + x, y0 + y
        lv = ex.layer(X, Y)
        k = D.sq_key(lv, X, Y)
        D.data(st)["dmg"][k] = int(D.data(st)["dmg"].get(k, 0)) + int(n)
    if w["burning"]:
        from game import fire
        for (x, y) in w["burning"]:
            X, Y = x0 + x, y0 + y
            fire.ignite(ex, ex.layer(X, Y), X, Y, party=True)
        lines.append("Fire is still burning where you fought.")
    st.save()
    D._redraw(ex)
    return lines


__all__ = ["thing", "targets", "attack", "hurt", "smash", "area", "write_back", "version", "burning"]
