"""Features (class features, racial traits, feats, monster abilities) at run time.

A Feature entity is a handful of plain settings (how it's used, how often,
how long it lasts) plus a list of effect blocks. This module turns one into a
RFeature that the battle engine can ask questions of:

    "which effects of kind X apply to this attack right now?"
    "can this be used as a bonus action?"

Amounts can be dice, numbers or formulas. Names available in formulas:
level (the class level for class features, otherwise the character level),
character_level, prof, scale (from the Scaling table, by class level), hp,
max_hp, every stat score by its key (str, dex...) and every modifier as
<key>_mod (str_mod, dex_mod...), and casting_mod (the spellcasting modifier).
Put a formula inside braces to use it in a dice expression:  {scale}d6,
{ceil(level / 2)}d6.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from game import dice, formula
from game.constants import DAMAGE_TYPES

ROUNDS = {"Instant": 0, "Until end of your turn": 1, "Until your next turn": 1, "1 minute": 10,
          "10 minutes": 100, "Until you rest": -1}

# Effects that happen once, when the feature is used.
ONE_SHOT = {"Heal self", "Temporary hit points", "Extra action", "Dash, Disengage or Dodge", "Regain spell slots",
            "Note", "Restore resource"}
# Effects that last while the feature is on (always, for passive features).
LASTING = {"Extra damage", "Bonus to attack rolls", "Bonus to damage", "Bonus to AC", "Bonus to saving throws",
           "Resistance", "Condition immunity", "Advantage on attacks", "Attacks against you have advantage",
           "Extra speed", "Critical hit range", "Armor formula", "Bonus hit points", "Damage immunity",
           "Vulnerability", "Advantage on saving throws", "Regenerate", "Spell attack and DC bonus",
           "Bonus to skill checks", "Darkvision"}
# Effects worked out once when a creature is built (from passive features): see apply_static().
STATIC = {"Attunement slots", "Resource pool", "Skill proficiency", "Expertise", "Saving throw proficiency",
          "Bonus to initiative", "Extra attack", "Unarmed strike", "Darkvision", "Magical attacks"}


@dataclass
class Effect:
    kind: str
    amount: str = ""
    detail: str = ""
    only_when: str = "Always"


@dataclass
class RFeature:
    id: str
    name: str
    description: str = ""
    kind: str = "Class feature"
    activation: str = "Passive"
    uses: str = "Unlimited"
    max_uses: int = 0                 # per-rest features
    uses_left: int = 0
    ready: bool = True                # recharge features
    used_this_turn: bool = False      # once-per-turn features
    duration: str = "Instant"
    requires: list = field(default_factory=list)
    effects: list = field(default_factory=list)
    damage: dict | None = None        # see build(); None when it deals no damage
    scale: int = 0
    rounds_left: int = 0              # while switched on: rounds remaining, -1 = until rest
    mechanic: str = ""
    reaction_trigger: str = ""        # for activation == "Reaction"
    cost: str = ""                    # Mana/Stamina, resource or charge cost
    granted_by: str = ""              # "<caster id>:<spell id>" for effects a spell put on someone
    class_level: int = 0              # level in the class that grants it (0 = use the character level)
    resource: str = ""                # pool spent (uses == "Costs resource")
    spell: object = None              # a Spell it casts (casts_spell)
    aura: int = 0                     # squares: its lasting effects also reach allies this close
    source_item: str = ""             # the item that grants it (item charges)

    # ------------------------------------------------------------------
    @property
    def passive(self) -> bool:
        return self.activation == "Passive"

    @property
    def is_on(self) -> bool:
        """Do the lasting effects apply right now (ignoring 'Only works while')?"""
        return self.passive or self.rounds_left != 0

    @property
    def per_rest(self) -> bool:
        return self.uses in ("Per short rest", "Per long rest")

    @property
    def recharge(self) -> int:
        """Lowest d6 roll that recharges it (0 = not a recharge feature)."""
        return {"Recharge 5-6": 5, "Recharge 6": 6, "Recharge 4-6": 4}.get(self.uses, 0)

    def available(self, reaction: bool = False) -> bool:
        if self.passive or self.activation == "Granted" or (self.activation == "Reaction") != reaction:
            return False
        if self.per_rest and self.uses_left <= 0:
            return False
        if self.recharge and not self.ready:
            return False
        if self.uses == "Once per turn" and self.used_this_turn:
            return False
        if self.rounds_left != 0 and any(e.kind in LASTING for e in self.effects):
            return False                   # already switched on
        return True

    def uses_text(self) -> str:
        if self.uses == "Costs Mana/Stamina":
            return f"costs {self.cost or '?'}"
        if self.uses == "Costs resource":
            return f"{self.cost or 1} {self.resource or 'resource'}"
        if self.uses == "Item charges":
            return f"{self.cost or 1} charge{'s' if str(self.cost or 1) != '1' else ''}"
        if self.per_rest:
            return f"{self.uses_left}/{self.max_uses} {'short' if 'short' in self.uses else 'long'} rest"
        if self.recharge:
            return "ready" if self.ready else f"recharge {self.recharge}-6"
        if self.uses == "Once per turn":
            return "once per turn"
        return ""

    def options(self) -> list[str]:
        """Choices offered when it's used (Cunning Action: Dash or Disengage)."""
        for e in self.effects:
            if e.kind == "Dash, Disengage or Dodge":
                picks = [p.strip().title() for p in re.split(r"[,/]| or ", e.detail or "") if p.strip()]
                picks = [p for p in picks if p in ("Dash", "Disengage", "Dodge")]
                return picks or ["Dash", "Disengage", "Dodge"]
        return []

    def summary(self) -> str:
        bits = [self.activation.lower()] if not self.passive else ["passive"]
        u = self.uses_text()
        if u:
            bits.append(u)
        if self.rounds_left:
            bits.append("active" if self.rounds_left < 0 else f"active, {self.rounds_left} rd")
        return "  ·  ".join(bits)


# ----------------------------------------------------------------------
# Formulas and dice
# ----------------------------------------------------------------------
def variables(c, f: RFeature | None = None) -> dict:
    char_level = getattr(c, "level", 1)
    out = {"level": (f.class_level if f is not None and f.class_level else char_level), "character_level": char_level,
           "prof": c.prof, "hp": c.hp, "max_hp": c.max_hp, "scale": f.scale if f else 0}
    out["class_level"] = out["level"]
    for k, v in (c.stats or {}).items():
        out[k] = v
    for k, v in (c.mods or {}).items():
        out[f"{k}_mod"] = v
    out["casting_mod"] = (c.mods or {}).get(getattr(c, "casting_stat", "") or "", 0)
    return out


_BRACES = re.compile(r"\{([^{}]+)\}")
_WORD = re.compile(r"\b([A-Za-z_][A-Za-z_0-9]*)\b")


def _substitute(text: str, values: dict) -> str:
    def braces(m):
        try:
            return str(int(formula.evaluate(m.group(1), values)))
        except Exception:      # noqa: BLE001 - a bad formula just counts as 0
            return "0"
    text = _BRACES.sub(braces, text)

    def word(m):
        w = m.group(1)
        if re.fullmatch(r"\d*d\d+", w):
            return w
        return str(values[w]) if w in values and isinstance(values[w], (int, float)) else w
    return _WORD.sub(word, text)


def amount(c, f: RFeature | None, text: str, rng=None, crit: bool = False) -> tuple[int, str]:
    """Roll or work out an amount. Returns (total, detail)."""
    text = str(text or "").strip()
    if not text:
        return 0, ""
    values = variables(c, f)
    plain = _substitute(text, values).replace(" ", "")
    plain = plain.replace("+-", "-").replace("--", "+")
    if dice.is_valid(plain):
        expr = dice.parse(plain)
        if crit:
            expr = expr.doubled_dice()
        r = dice.roll(expr, rng)
        return r.total, r.detail
    try:
        v = formula.evaluate(text, values, rng)
        return int(v), str(int(v))
    except Exception:          # noqa: BLE001
        return 0, "0"


def fixed(c, f: RFeature | None, text: str) -> int:
    """An amount that shouldn't be rolled (AC bonus, speed): dice count as their average."""
    text = str(text or "").strip()
    if not text:
        return 0
    values = variables(c, f)
    plain = _substitute(text, values).replace(" ", "")
    if dice.is_valid(plain):
        return int(dice.average(plain))
    try:
        return int(formula.evaluate(text, values))
    except Exception:          # noqa: BLE001
        return 0


def damage_types(text: str) -> set[str]:
    words = {w.strip().lower() for w in re.split(r"[,/;]| and ", text or "") if w.strip()}
    if "all" in words:
        return set(DAMAGE_TYPES)
    if "nonmagical" in words or "physical" in words:
        words |= {"bludgeoning", "piercing", "slashing"}
    return {w for w in words if w in DAMAGE_TYPES}


# ----------------------------------------------------------------------
# Building from entities
# ----------------------------------------------------------------------
def _scale_for(rows, level: int) -> int:
    best = 0
    for r in sorted(rows or [], key=lambda r: int(r.get("level") or 1)):
        if int(r.get("level") or 1) <= level:
            try:
                best = int(float(r.get("value") or 0))
            except (TypeError, ValueError):
                pass
    return best


def build(world, entity, c, class_level: int = 0, source_item: str = "") -> RFeature:
    """A runtime feature for combatant c (needs c.level, c.prof, c.mods for its formulas).
    class_level: the level in the class that grants it (class features scale with that)."""
    from game.combat.builders import _squares, _stat_key, build_spell   # avoid an import cycle
    fl = entity.fields
    rf = RFeature(
        id=entity.id, name=entity.name, description=entity.description, kind=fl.get("kind") or "Class feature",
        activation=fl.get("activation") or "Passive", uses=fl.get("uses") or "Unlimited",
        duration=fl.get("duration") or "Instant", requires=list(fl.get("requires") or []),
        effects=[Effect(r.get("effect") or "Note", str(r.get("amount") or ""), str(r.get("detail") or ""),
                        r.get("only_when") or "Always") for r in fl.get("effects") or [] if r.get("effect")],
        scale=_scale_for(fl.get("scale"), class_level or getattr(c, "level", 1)), mechanic=fl.get("mechanic") or "",
        reaction_trigger=fl.get("reaction_trigger") or "", cost=str(fl.get("cost") or ""),
        class_level=int(class_level or 0), resource=str(fl.get("resource") or "").strip(),
        aura=_squares(fl.get("aura_ft") or 0), source_item=source_item,
    )
    spell = world.entities.get(fl.get("casts_spell") or "")
    if spell is not None and spell.type == "spell":
        rf.spell = build_spell(world, spell)
    if rf.per_rest:
        rf.max_uses = max(1, fixed(c, rf, fl.get("uses_count") or "1"))
        rf.uses_left = rf.max_uses
    if fl.get("deals_damage"):            # an attack or a saving throw (the damage itself may be empty)
        target = fl.get("target") or "One creature (save)"
        rf.damage = {
            "target": target, "dice": str(fl.get("damage")), "type": fl.get("damage_type") or "",
            "attack_bonus": fixed(c, rf, fl.get("attack_bonus") or "prof + str_mod"),
            "save_stat": _stat_key(world, fl.get("save_stat")) or "dex",
            "dc": fixed(c, rf, fl.get("save_dc") or "8 + prof + con_mod"),
            "on_save": fl.get("on_save") or "Half damage",
            "range": max(1, _squares(fl.get("range_ft") or 5)),
            "area": (fl.get("area") or "Cone") if target == "Area (save)" else "None",
            "area_size": max(1, _squares(fl.get("area_ft") or 15)) if target == "Area (save)" else 0,
            "condition": fl.get("condition") or "", "condition_rounds": int(fl.get("condition_rounds") or 0),
            "condition_save_each_turn": bool(fl.get("condition_save_each_turn", True)),
            "only_foes": bool(fl.get("only_foes")),
        }
    return rf


def build_all(world, ids, c, levels: dict | None = None, sources: dict | None = None) -> list[RFeature]:
    """levels: feature id -> class level; sources: feature id -> item id (features items grant)."""
    out, seen = [], set()
    for fid in ids or []:
        e = world.entities.get(fid)
        if e and e.type == "feature" and e.id not in seen:
            seen.add(e.id)
            out.append(build(world, e, c, (levels or {}).get(fid, 0), (sources or {}).get(fid, "")))
    return out


def apply_static(world, c) -> None:
    """Passive effects that change the creature itself rather than a roll: more attacks, a better
    unarmed strike, proficiencies, darkvision, initiative, resource pools, attunement slots."""
    from game.combat.builders import _squares
    from game.combat.engine import Attack
    c.attune_max = max(0, int(world.rules.get("attunement_slots", 3) or 0))
    for f in c.features:
        if not f.passive:
            continue
        for e in f.effects:
            k = e.kind
            if k == "Extra attack":
                c.attacks_per_action = max(c.attacks_per_action, max(2, fixed(c, f, e.amount or "2")))
            elif k == "Bonus to initiative":
                c.init_bonus += fixed(c, f, e.amount)
            elif k == "Darkvision":
                c.darkvision = max(c.darkvision, _squares(fixed(c, f, e.amount or e.detail or "60")))
            elif k == "Saving throw proficiency":
                c.saves |= _stat_keys(world, e.detail or e.amount)
            elif k in ("Skill proficiency", "Expertise"):
                names = {w.strip().lower() for w in re.split(r"[,;/]", e.detail or e.amount or "") if w.strip()}
                c.skill_profs |= names
                if k == "Expertise":
                    c.expertise |= names
            elif k == "Attunement slots":
                c.attune_max += max(0, fixed(c, f, e.amount or "1"))
            elif k == "Resource pool":
                name, recharge = _pool_name(e.detail)
                if name:
                    have = c.resources.get(name)
                    top = max(0, fixed(c, f, e.amount or "1"))
                    if have is None or top > have["max"]:
                        c.resources[name] = {"cur": top, "max": top, "recharge": recharge}
            elif k == "Magical attacks":          # Ki-Empowered Strikes: "unarmed"; blank = every attack
                only_unarmed = "unarmed" in (e.detail or e.amount or "").lower()
                for a in c.attacks:
                    if not only_unarmed or a.name == "Unarmed strike":
                        a.magical = True
            elif k == "Unarmed strike":
                die = str(e.amount or "1d4")
                key = (e.detail or "").strip().lower()
                stat = key if key in c.mods else world.rules.get("melee_stat", "str")
                if key in ("dex", "better", "finesse"):
                    melee = world.rules.get("melee_stat", "str")
                    dex = world.rules.get("ranged_stat", "dex")
                    stat = dex if c.mods.get(dex, 0) >= c.mods.get(melee, 0) else melee
                values = variables(c, f)
                die = _substitute(die, values).replace(" ", "")
                mod = c.mods.get(stat, 0)
                dmg = f"{die}{'+' if mod >= 0 else '-'}{abs(mod)}" if mod else die
                if not dice.is_valid(dmg):
                    continue
                for a in c.attacks:
                    if a.name == "Unarmed strike":
                        a.damage, a.stat, a.to_hit = dmg, stat, c.prof + mod
                        a.finesse = True


def _stat_keys(world, text: str) -> set:
    out = set()
    for w in re.split(r"[,;/ ]+", str(text or "").lower()):
        if not w:
            continue
        stat = world.entities.stat_by_key(w)
        if stat is None:
            stat = next((s for s in world.entities.stats() if s.name.lower() == w
                         or str(s.fields.get("abbreviation") or "").lower() == w), None)
        if stat is not None:
            out.add(stat.fields.get("key"))
    return out


def _pool_name(detail: str) -> tuple[str, str]:
    """'Lucky points, long rest' -> ('Lucky points', 'Long rest')."""
    text = str(detail or "").strip()
    recharge = "Long rest"
    low = text.lower()
    for word, value in (("short", "Short rest"), ("long", "Long rest"), ("never", "Never")):
        if word in low.split(",")[-1] and "," in text:
            recharge = value
            text = text.rsplit(",", 1)[0].strip()
            break
    return text, recharge


def describe_entity(entity) -> str:
    """One line for lists: 'Bonus action · 1 per short rest · Heal self 1d10 + level'."""
    fl = entity.fields
    bits = [fl.get("activation") or "Passive"]
    uses = fl.get("uses") or "Unlimited"
    if uses in ("Per short rest", "Per long rest"):
        bits.append(f"{fl.get('uses_count') or 1} {uses.lower()}")
    elif uses != "Unlimited":
        bits.append(uses)
    effects = [f"{r.get('effect')} {r.get('amount') or r.get('detail') or ''}".strip()
               for r in fl.get("effects") or [] if r.get("effect")]
    if fl.get("deals_damage"):
        effects.append(f"{fl.get('damage')} {fl.get('damage_type') or ''}".strip())
    if effects:
        bits.append(", ".join(effects))
    return "  ·  ".join(bits)


def rounds_from_text(text: str) -> int:
    """Spell durations: 'Instantaneous' -> 0, '1 round' -> 1, '1 minute' -> 10, '1 hour' -> 600,
    'Until dispelled' -> -1. 'Concentration, up to 1 minute' -> 10."""
    s = str(text or "").lower()
    if not s or "instant" in s:
        return 0
    if "dispel" in s or "permanent" in s or "until" in s and "turn" not in s:
        return -1
    if "next turn" in s:
        return 1
    m = re.search(r"(\d+)\s*(round|minute|min|hour|day)", s)
    if not m:
        return 10
    n, unit = int(m.group(1)), m.group(2)
    return n * {"round": 1, "minute": 10, "min": 10, "hour": 600, "day": 14400}[unit]


def granted(spell, effects, rounds: int, caster_id: str) -> RFeature:
    """A spell's effect blocks, worn by whoever it was cast on for the spell's duration."""
    return RFeature(id=f"spell:{spell.id}", name=spell.name, description=spell.description, kind="Spell effect",
                    activation="Granted", duration="Spell", effects=list(effects), rounds_left=rounds or 1,
                    granted_by=f"{caster_id}:{spell.id}")
