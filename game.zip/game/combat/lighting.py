"""Light, darkness and darkvision, following the 5e SRD.

Every square is in bright light, dim light or darkness.
  * Bright: normal vision.
  * Dim: lightly obscured (matters for Perception, not attacks).
  * Darkness: heavily obscured. A creature that can't see into a square is
    effectively blinded against whatever is there.
Darkvision (within its range): dim light counts as bright, and darkness as
dim light, but in darkness only shades of gray can be seen.

Light comes from the surroundings (sunlight, a lit room) and from sources:
fires, braziers, and torches or lanterns a creature carries.
"""
from __future__ import annotations

from dataclasses import dataclass

DARK, DIM, BRIGHT = 0, 1, 2
LEVEL_NAMES = {DARK: "darkness", DIM: "dim light", BRIGHT: "bright light"}

OUTDOOR = {"forest", "plains", "hills", "swamp", "desert", "arctic", "coast", "street", "ship", "airship", "caravan"}

# prop id -> (bright squares, extra dim squares, color, flickers)
PROP_LIGHTS = {
    "campfire": (4, 4, "#ff9a3c", True),
    "brazier": (4, 4, "#ffa04a", True),
    "forge": (4, 4, "#ff7a2a", True),
    "altar": (1, 2, "#ffd27a", True),
    "torch_post": (4, 4, "#ffa84e", True),
    "lamp": (1, 2, "#ffd88a", False),            # a street lamp (game/townlayout.py)
}
WINDOW_LIGHT = (1, 2, "#ffcf7a", False)           # a lit window at night
LIGHT_SPELL = (4, 4, "#f4f0ff", False)           # the Light cantrip: 20 ft bright, 20 more dim

TIMES = ["Day", "Dusk", "Night"]


# ----------------------------------------------------------------------------------------------------
# The day's light, the same for the walking map and the battle map
# ----------------------------------------------------------------------------------------------------
def outdoor_light(minutes: int, weather=None) -> int:
    """Bright, dim or dark under the open sky at this minute: bright by day; dim at dawn and dusk; at night
    the moon gives dim light, unless it's new or the clouds hide it."""
    from game import calendar as CAL
    day = CAL.daylight(minutes)
    if weather is not None and getattr(weather, "dim", 0) >= 0.3:
        day *= 0.75                                         # a storm darkens the day
    if day >= 0.55:
        return BRIGHT
    if day >= 0.12:
        return DIM
    cloudy = bool(weather is not None and getattr(weather, "cloudy", False))
    return DIM if CAL.moonlight(minutes) >= 0.25 and not cloudy else DARK


def light_time(minutes: int, weather=None) -> str:
    """The battle map's time of day ("Day", "Dusk" or "Night") for the light outdoors right now."""
    return {BRIGHT: "Day", DIM: "Dusk", DARK: "Night"}[outdoor_light(minutes, weather)]


def party_light(world, members) -> tuple[int, int, str]:
    """(bright squares, dim squares, colour) the party carries: the best torch or lantern anyone holds,
    or the Light cantrip if someone knows it."""
    from game.combat.builders import _carried_light
    best = (0, 0, "#ffb860")
    for m in members or []:
        if m.get("dead"):
            continue
        b, d = _carried_light(world, m.get("equipment") or {})
        if b + d > best[0] + best[1]:
            best = (b, d, "#ffb860")
        if LIGHT_SPELL[0] + LIGHT_SPELL[1] > best[0] + best[1] and _knows_light(world, m):
            best = (LIGHT_SPELL[0], LIGHT_SPELL[1], LIGHT_SPELL[2])
    return best


def _knows_light(world, m: dict) -> bool:
    try:
        from game import character
        ids = character.castable_spell_ids(world, m)
    except Exception:  # noqa: BLE001 - an odd member just has no spells here
        return False
    return any((world.entities.get(i).name if world.entities.get(i) else "") == "Light" for i in ids)


def party_darkvision(world, members) -> int:
    """The longest darkvision in the party, in squares."""
    best = 0
    for m in members or []:
        if m.get("dead"):
            continue
        race = world.entities.get(m.get("race") or "")
        ft = int((race.fields.get("darkvision") if race else 0) or 0)
        sub = world.entities.get((race.fields.get("subrace_of") if race else "") or "")
        if sub is not None:
            ft = max(ft, int(sub.fields.get("darkvision") or 0))
        best = max(best, ft // 5)
    return best


@dataclass
class LightSource:
    x: float                 # center, in squares
    y: float
    bright: int              # squares of bright light
    dim: int                 # further squares of dim light
    color: str = "#ffb050"
    flicker: bool = True
    owner: str = ""          # combatant id for carried lights


def ambient_for(environment: str, time: str = "Day", style: str = "") -> int:
    """Light everywhere on the map before any sources are added."""
    if environment in ("cave",):
        return DARK
    if environment in ("dungeon", "dungeon_room"):
        return DARK
    if environment == "interior":
        return BRIGHT if time != "Night" else DIM
    if environment in OUTDOOR:
        return {"Day": BRIGHT, "Dusk": DIM, "Night": DARK}.get(time, BRIGHT)
    return BRIGHT


class LightMap:
    def __init__(self, bmap, ambient: int, sources: list[LightSource] | None = None) -> None:
        self.map = bmap
        self.ambient = ambient
        self.sources = list(sources or [])
        self.carried: list[LightSource] = []

    @classmethod
    def for_map(cls, bmap, time: str = "Day") -> "LightMap":
        sources = []
        for p in bmap.props:
            if p.id in PROP_LIGHTS:
                b, d, col, fl = PROP_LIGHTS[p.id]
                pd = p.defn
                sources.append(LightSource(p.x + pd.w / 2, p.y + pd.h / 2, b, d, col, fl))
        return cls(bmap, ambient_for(bmap.environment, time, bmap.style), sources)

    def update_carried(self, combatants) -> None:
        self.carried = []
        for c in combatants:
            if c.active and (c.light_bright or c.light_dim):
                cx, cy = c.center()
                self.carried.append(LightSource(cx, cy, c.light_bright, c.light_dim, "#ffb860", True, c.id))

    def all_sources(self) -> list[LightSource]:
        return self.sources + self.carried

    def level(self, x: int, y: int) -> int:
        best = self.ambient
        if best == BRIGHT:
            return BRIGHT
        for s in self.all_sources():
            d = max(abs(x + 0.5 - s.x), abs(y + 0.5 - s.y)) - 0.5
            if d <= s.bright:
                return BRIGHT
            if d <= s.bright + s.dim:
                best = max(best, DIM)
        return best

    def perceived(self, viewer, x: int, y: int) -> tuple[int, bool]:
        """What `viewer` makes of square (x, y): (level, seen only in gray)."""
        light = self.level(x, y)
        if viewer is not None and viewer.darkvision and light < BRIGHT:
            dx = max(0, x - (viewer.x + viewer.size - 1), viewer.x - x)
            dy = max(0, y - (viewer.y + viewer.size - 1), viewer.y - y)
            if max(dx, dy) <= viewer.darkvision:
                return (DIM, True) if light == DARK else (BRIGHT, False)
        return light, False

    def can_see(self, viewer, target) -> bool:
        """Is any part of `target` lit enough for `viewer` to see it?"""
        return any(self.perceived(viewer, x, y)[0] >= DIM for x, y in target.cells())

    def party_view(self, viewers, x: int, y: int) -> tuple[int, bool]:
        """Best view of a square among several viewers (the player's party)."""
        best = (DARK, False)
        for v in viewers:
            lvl, grey = self.perceived(v, x, y)
            if lvl > best[0] or (lvl == best[0] and best[1] and not grey):
                best = (lvl, grey)
        if not viewers:
            best = (self.level(x, y), False)
        return best
