"""Turn-based combat on a square grid, simplified from 5e.

Each square is 5 ft. Creatures take one or more squares (Large = 2x2 ...).
On a turn a creature can move up to its speed and take one action:
Attack (possibly several attacks), Cast, Use Item, Dash, Dodge, Disengage, or
Flee (from the map edge). Leaving a hostile's reach without Disengaging
provokes an opportunity attack.

Everything that happens is reported through `on_event(name, **data)` (the
event bus in the game) and appended to `battle.log` as (kind, text).
"""
from __future__ import annotations

import re

import heapq
import math
import random
from dataclasses import dataclass, field
from typing import Callable, Iterator

from game import dice
from game.combat import conditions as CND
from game.combat import features as F
from game.combat.battlemap import BattleMap
from game.combat.lighting import LightMap

PLAYER, ENEMY, ALLY = "player", "enemy", "ally"


COUNTER = "When a creature casts a spell"


@dataclass
class Attack:
    name: str
    kind: str = "Melee"            # Melee or Ranged
    to_hit: int = 0
    damage: str = "1"
    damage_type: str = "bludgeoning"
    reach: int = 1                 # squares, melee
    range: int = 0                 # squares, ranged normal range
    long_range: int = 0            # squares, ranged long range
    item_id: str = ""
    stat: str = ""                 # stat key the attack uses (str, dex...)
    finesse: bool = False
    light: bool = False
    offhand: bool = False          # the bonus-action attack with a second light weapon
    weapon: bool = True            # False for spell attacks (no Sneak Attack, Rage damage...)
    condition: str = ""            # a condition a hit can cause (Wolf bite: Prone)
    cond_save: str = ""            # stat key for the save against it ("" = no save)
    cond_dc: int = 0
    ammo_type: str = ""            # what it fires (Arrow, Bolt...), "" = nothing
    extra_damage: str = ""         # a second part of the damage (a dragon's bite: piercing plus fire)
    extra_type: str = ""
    magical: bool = False          # beats "resistant to nonmagical weapons"

    @property
    def ranged(self) -> bool:
        return self.kind == "Ranged"

    def max_range(self) -> int:
        return (self.long_range or self.range) if self.ranged else self.reach

    def describe(self) -> str:
        sign = "+" if self.to_hit >= 0 else ""
        where = f"range {self.range * 5}/{self.long_range * 5} ft" if self.ranged else f"reach {self.reach * 5} ft"
        return f"{self.name}: {sign}{self.to_hit} to hit, {self.damage} {self.damage_type}, {where}"


@dataclass
class Spell:
    id: str
    name: str
    level: int = 0
    effect: str = "Spell attack (ranged)"
    damage: str = ""
    damage_type: str = ""
    healing: str = ""
    save_stat: str = ""            # stat key
    on_save: str = "Half damage"
    range: int = 12                # squares (0 = self)
    area: str = "None"
    area_size: int = 0             # squares
    missiles: int = 1
    upcast: str = ""
    casting_time: str = "Action"
    description: str = ""
    dc: int = 0                    # overrides the caster's spell DC (feature damage)
    attack_bonus: int | None = None  # overrides the caster's spell attack bonus
    condition: str = ""            # caused on a failed save, or on a hit
    condition_rounds: int = 0      # 0 = until removed (or until concentration ends)
    condition_save_each_turn: bool = True
    only_foes: bool = False        # an area that spares the caster's allies
    effects: list = field(default_factory=list)   # Effect blocks (buffs/debuffs) for "Effect blocks" spells
    buff_target: str = "Self"
    rounds: int = 0                # duration in rounds (from the spell's duration text)
    concentration: bool = False
    reaction_trigger: str = ""
    temp_hp: str = ""              # Temporary hit points spells
    summons: str = ""              # Summon: enemy entity id
    summon_count: str = "1"
    removes: list = field(default_factory=list)     # Remove condition: conditions it ends
    revive_hp: int = 1             # Revive
    ritual: bool = False
    cantrip_scaling: str = "Damage dice"   # cantrips grow at levels 5, 11, 17: more dice, or one more beam
    hp_limit: int = 0              # does nothing to a creature with more hit points (Power Word Kill)
    slays: bool = False            # the target just dies

    @property
    def self_only(self) -> bool:
        """Cast on yourself without picking a target."""
        if self.effect == "Effect blocks":
            return self.buff_target == "Self" and not self.targets_area
        if self.effect == "Summon":
            return True
        return self.effect in ("Healing", "Temporary hit points", "Remove condition") and self.range == 0 \
            and not self.targets_area

    @property
    def helps_allies(self) -> bool:
        return self.effect in ("Healing", "Temporary hit points", "Remove condition", "Revive", "Summon") or (
            self.effect == "Effect blocks" and self.buff_target in ("Self", "One ally", "Allies in the area"))

    @property
    def targets_cell(self) -> bool:
        """Aimed at a square rather than a creature (areas, teleporting)."""
        return self.targets_area or self.effect == "Teleport"

    @property
    def bonus_action(self) -> bool:
        return self.casting_time == "Bonus action"

    @property
    def in_combat(self) -> bool:
        return self.casting_time in ("Action", "Bonus action")

    @property
    def targets_area(self) -> bool:
        return self.area not in ("", "None") and self.area_size > 0

    def describe(self) -> str:
        lvl = "Cantrip" if self.level == 0 else f"Level {self.level}"
        if self.damage:
            what = f"{self.damage} {self.damage_type}"
        elif self.healing:
            what = f"heals {self.healing}"
        else:
            what = self.effect
        area = f", {self.area.lower()} {self.area_size * 5} ft" if self.targets_area else ""
        return f"{self.name} ({lvl}): {what}{area}, range {self.range * 5} ft"


@dataclass
class Consumable:
    item_id: str
    name: str
    effect: str = "Heal"
    dice: str = "2d4+2"
    count: int = 1
    timing: str = "Action"         # Action or Bonus action


@dataclass
class Combatant:
    id: str
    name: str
    team: str
    hp: int
    max_hp: int
    ac: int
    speed: int = 6                 # squares per turn
    size: int = 1                  # squares per side
    x: int = -1
    y: int = -1
    entity_id: str = ""
    stats: dict = field(default_factory=dict)       # stat key -> score
    mods: dict = field(default_factory=dict)        # stat key -> modifier
    prof: int = 2
    saves: set = field(default_factory=set)         # proficient saving throw stat keys
    attacks: list = field(default_factory=list)
    attacks_per_action: int = 1
    spells: list = field(default_factory=list)
    spell_attack: int = 0
    spell_dc: int = 10
    casting_stat: str = ""
    slots: dict = field(default_factory=dict)       # level -> remaining
    slots_max: dict = field(default_factory=dict)   # level -> slots when rested
    once_per_fight: set = field(default_factory=set)  # spell ids already used (monsters)
    items: list = field(default_factory=list)
    resist: set = field(default_factory=set)
    immune: set = field(default_factory=set)
    vulnerable: set = field(default_factory=set)
    behavior: str = "Aggressive"
    xp: int = 0
    loot: list = field(default_factory=list)        # [{"item": id, "chance": %, "quantity": dice}]
    gold: str = ""
    flying: bool = False
    initiative: int = 0
    init_bonus: int = 0
    facing: int = 0                # 0 south, 1 west, 2 north, 3 east
    alive: bool = True
    fled: bool = False
    is_monster: bool = False
    darkvision: int = 0            # squares
    light_bright: int = 0          # squares of bright light this creature carries (torch: 4)
    light_dim: int = 0             # further squares of dim light
    miss_streak: int = 0           # hidden: consecutive misses (player characters only)
    look: dict = field(default_factory=dict)        # for the sprite
    sprite_key: str = ""
    level: int = 1                 # character level (monsters: their CR), used by feature formulas
    features: list = field(default_factory=list)    # RFeature
    bonus_attacks: list = field(default_factory=list)  # off-hand attacks
    temp_hp: int = 0
    base_ac: int = 0               # before features (filled in automatically)
    base_speed: int = 0
    base_resist: set = field(default_factory=set)
    armor_worn: str = ""           # "", Light, Medium, Heavy
    has_shield: bool = False
    shield_ac: int = 0
    condition_immune: set = field(default_factory=set)
    base_condition_immune: set = field(default_factory=set)
    base_max_hp: int = 0
    base_spell_attack: int | None = None
    base_spell_dc: int | None = None
    base_immune: set = field(default_factory=set)
    base_vulnerable: set = field(default_factory=set)
    base_darkvision: int | None = None
    conditions: dict = field(default_factory=dict)  # see game/combat/conditions.py
    concentration: dict | None = None               # {"id", "name"} of the spell being concentrated on
    vars: dict = field(default_factory=dict)        # custom values mechanics can read and change
    race_id: str = ""
    class_id: str = ""
    equipment: list = field(default_factory=list)   # item ids worn or held
    # Mana / Stamina (characters; see game/character.py). mana_max 0 = not used
    mana: int = 0
    mana_max: int = 0
    mana_name: str = "Mana"
    max_cast_level: int = 0        # highest spell level the character could cast (from the slot table)
    ammo: dict | None = None       # ammo type -> pieces carried (None = unlimited, for monsters)
    ammo_used: dict = field(default_factory=dict)
    armor_untrained: bool = False  # wearing armor without proficiency
    stealth_dis: bool = False
    skill_profs: set = field(default_factory=set)   # proficient skill names, lower case
    expertise: set = field(default_factory=set)     # skills with double proficiency, lower case
    resources: dict = field(default_factory=dict)   # name -> {"cur", "max", "recharge"} (Ki, Sorcery Points...)
    charges: dict = field(default_factory=dict)     # item id -> charges left (wands, staffs)
    attune_max: int = 3
    # monsters
    legendary_max: int = 0         # legendary action points per round
    legendary_left: int = 0
    legendary: list = field(default_factory=list)   # [{"name", "cost", "does", "what"}]
    legendary_resist: int = 0      # times it can turn a failed save into a success
    weapon_guard: str = ""         # "Resistant" / "Immune" to nonmagical weapon hits (b/p/s)
    summoned_by: str = ""          # combatant id of the caster, for summoned creatures
    summon_rounds: int = 0         # rounds until a summoned creature vanishes (-1 = until concentration ends)
    regen_blocked: bool = False    # took damage that stops its regeneration this round
    # actions (9b)
    helped: bool = False           # an ally used the Help action: advantage on the next attack
    hidden: bool = False           # hid successfully: unseen until it attacks or is found
    hidden_score: int = 0          # its Stealth roll when it hid
    grappling: str = ""            # id of the creature it is grappling
    # dying (player characters drop to 0 HP and make death saving throws)
    dying: bool = False
    stable: bool = False
    death_saves: list = field(default_factory=lambda: [0, 0])   # successes, failures
    dead: bool = False
    # turn state
    moved: int = 0
    action_used: bool = False
    bonus_used: bool = False
    attacks_left: int = 0
    reaction_used: bool = False
    dodging: bool = False
    disengaged: bool = False
    dashed: bool = False
    light_attacked: bool = False   # attacked with a light melee weapon this turn (two-weapon fighting)
    bonus_spell: bool = False      # cast a bonus-action spell this turn
    leveled_action_spell: bool = False

    def __post_init__(self) -> None:
        self.base_ac = self.base_ac or self.ac
        self.base_speed = self.base_speed or self.speed
        self.base_resist = set(self.base_resist or self.resist)
        self.base_condition_immune = set(self.base_condition_immune or self.condition_immune)
        self.base_max_hp = self.base_max_hp or self.max_hp
        self.base_immune = set(self.base_immune or self.immune)
        self.base_vulnerable = set(self.base_vulnerable or self.vulnerable)

    @property
    def active(self) -> bool:
        return self.alive and not self.fled

    def cells(self, x: int | None = None, y: int | None = None) -> list[tuple[int, int]]:
        x = self.x if x is None else x
        y = self.y if y is None else y
        return [(x + dx, y + dy) for dy in range(self.size) for dx in range(self.size)]

    def center(self) -> tuple[float, float]:
        return self.x + self.size / 2, self.y + self.size / 2

    def movement_left(self) -> int:
        full = int(self.speed * (2 if self.dashed else 1) * CND.speed_factor(self))
        return max(0, full - self.moved)

    def mod(self, key: str) -> int:
        return int(self.mods.get(key, 0))

    def hostile_to(self, other: "Combatant") -> bool:
        friendly = {PLAYER, ALLY}
        return (self.team in friendly) != (other.team in friendly)

    def hp_text(self) -> str:
        return f"{self.hp}/{self.max_hp}" + (f" +{self.temp_hp}" if self.temp_hp else "")

    def action_done(self) -> bool:
        return self.action_used and self.attacks_left <= 0


@dataclass
class AttackResult:
    hit: bool
    crit: bool
    roll: int
    total: int
    damage: int = 0
    text: str = ""


class Battle:
    def __init__(self, bmap: BattleMap, combatants: list[Combatant], rng: random.Random | None = None,
                 rules: dict | None = None, on_event: Callable | None = None, time: str = "Day") -> None:
        self.map = bmap
        self.time = time
        self.light = LightMap.for_map(bmap, time)
        self.combatants = combatants
        self.rng = rng or random.Random()
        self.rules = rules or {}
        self.on_event = on_event
        self.log: list[tuple[str, str]] = []
        self.order: list[Combatant] = []
        self.turn_index = 0
        self.round = 0
        self.outcome: str | None = None
        self.started = False
        # Asked when a player character could use their reaction:
        # ask_reaction(reactor, title, text, options) -> index of the chosen option, or None to decline.
        # Left unset (tests, automatic play), reactions are always taken.
        self.ask_reaction: Callable | None = None

    # ==================================================================
    # Reporting
    # ==================================================================
    def say(self, kind: str, text: str) -> None:
        self.log.append((kind, text))
        self._emit("combat.log", kind=kind, text=text)

    def _emit(self, name: str, **data) -> None:
        if self.on_event:
            self.on_event(name, **data)

    # ==================================================================
    # Setup and turns
    # ==================================================================
    def start(self) -> None:
        self._place_everyone()
        for c in self.combatants:
            self.refresh_stats(c)
        for c in self.combatants:
            roll, _ = dice.d20(self.rng)
            c.initiative = roll + c.init_bonus
        self.order = sorted(self.combatants, key=lambda c: (-c.initiative, -c.init_bonus, c.team != PLAYER, c.name))
        self.round = 1
        self.turn_index = 0
        self.started = True
        names = ", ".join(f"{c.name} ({c.initiative})" for c in self.order)
        self.say("system", f"Initiative: {names}")
        self._emit("combat.start", battle=self)
        self._begin_turn()

    @property
    def current(self) -> Combatant | None:
        if not self.order:
            return None
        return self.order[self.turn_index % len(self.order)]

    def _begin_turn(self) -> None:
        c = self.current
        if c is None:
            return
        c.moved = 0
        c.action_used = False
        c.bonus_used = False
        c.attacks_left = 0
        c.reaction_used = False
        c.dodging = False
        c.disengaged = False
        c.dashed = False
        c.light_attacked = False
        c.bonus_spell = False
        c.leveled_action_spell = False
        self._tick_features(c)
        c.legendary_left = c.legendary_max
        regen = self.effects(c, "Regenerate")
        if regen and c.hp > 0 and c.hp < c.max_hp:
            if c.regen_blocked:
                self.say("system", f"{c.name} doesn't regenerate this turn.")
            else:
                n = sum(F.fixed(c, f, e.amount or "10") for f, e in regen)
                self.say("heal", f"{c.name} regenerates.")
                self.heal(c, n)
        c.regen_blocked = False
        if c.summoned_by and c.summon_rounds > 0:
            c.summon_rounds -= 1
            if c.summon_rounds == 0:
                self._dismiss(c, f"{c.name} fades away as the summoning ends.")
                if not self.outcome:
                    self.end_turn()
                return
        if c.dying and not c.stable and c.alive:
            self.death_save(c)
        if c.grappling:
            held = next((o for o in self.combatants if o.id == c.grappling), None)
            if held is None or not held.active or not CND.has(held, "Grappled"):
                c.grappling = ""
        if c.team != PLAYER and not c.dying:
            self._search(c)
        CND.start_of_turn(self, c)
        self._emit("combat.turn_start", combatant=c, round=self.round)

    def end_turn(self) -> None:
        if self.outcome:
            return
        c = self.current
        if c is not None:
            for f in c.features:
                if f.rounds_left > 0 and f.duration in ("Until end of your turn", "Instant"):
                    f.rounds_left = 0
                    self.say("system", f"{c.name}'s {f.name} ends.")
            self.refresh_stats(c)
            if c.active:
                CND.end_of_turn(self, c)
        self._emit("combat.turn_end", combatant=c)
        if self.outcome:
            return
        self._legendary_after(c)
        if self.outcome:
            return
        for _ in range(len(self.order)):
            self.turn_index += 1
            if self.turn_index >= len(self.order):
                self.turn_index = 0
                self.round += 1
                self._emit("combat.round", round=self.round)
            if self.current.active:
                break
        self._begin_turn()

    def team(self, team: str) -> list[Combatant]:
        friendly = {PLAYER, ALLY}
        if team in friendly:
            return [c for c in self.combatants if c.team in friendly and c.active]
        return [c for c in self.combatants if c.team not in friendly and c.active]

    def enemies_of(self, c: Combatant) -> list[Combatant]:
        return [o for o in self.combatants if o.active and c.hostile_to(o)]

    def allies_of(self, c: Combatant) -> list[Combatant]:
        return [o for o in self.combatants if o.active and not c.hostile_to(o) and o is not c]

    def _check_outcome(self) -> None:
        if self.outcome:
            return
        players = [c for c in self.combatants if c.team == PLAYER]
        if players and not any(c.active and c.hp > 0 for c in players):
            self.outcome = "fled" if any(c.fled and c.alive for c in players) else "defeat"
        elif not self.team(ENEMY):
            self.outcome = "victory"
        if self.outcome:
            self.say("system", {"victory": "Victory!", "defeat": "You have fallen...",
                                "fled": "You escaped."}[self.outcome])
            self._emit("combat.end", outcome=self.outcome, battle=self)

    # ==================================================================
    # Placement and geometry
    # ==================================================================
    def _place_everyone(self) -> None:
        taken: set = set()
        for c in sorted(self.combatants, key=lambda c: -c.size):
            if c.x >= 0 and self.map.fits(c.x, c.y, c.size, taken):
                taken.update(c.cells())
                continue
            zone = self.map.player_zone if c.team in (PLAYER, ALLY) else self.map.enemy_zone
            c.x, c.y = self._find_spot(c, zone, taken)
            c.facing = 3 if c.team in (PLAYER, ALLY) else 1
            taken.update(c.cells())

    def _find_spot(self, c: Combatant, zone: list, taken: set) -> tuple[int, int]:
        cx = sum(x for x, _ in zone) / max(1, len(zone))
        cy = sum(y for _, y in zone) / len(zone) if zone else self.map.h / 2
        candidates = sorted(set(zone), key=lambda p: (p[0] - cx) ** 2 + (p[1] - cy) ** 2 + self.rng.random())
        for x, y in candidates:
            for ox, oy in ((0, 0), (-c.size + 1, 0), (0, -c.size + 1), (-c.size + 1, -c.size + 1)):
                if self.map.fits(x + ox, y + oy, c.size, taken):
                    return x + ox, y + oy
        for y in range(self.map.h):
            for x in range(self.map.w):
                if self.map.fits(x, y, c.size, taken):
                    return x, y
        raise RuntimeError(f"No room on the map for {c.name}")

    def occupied(self, ignore: Combatant | None = None) -> dict[tuple[int, int], Combatant]:
        out = {}
        for o in self.combatants:
            if o.active and o is not ignore:
                for cell in o.cells():
                    out[cell] = o
        return out

    def at(self, x: int, y: int) -> Combatant | None:
        return self.occupied().get((x, y))

    @staticmethod
    def distance(a: Combatant, b: Combatant, ax: int | None = None, ay: int | None = None) -> int:
        """Squares between two creatures' nearest edges, plus one (adjacent = 1).
        Diagonals count as one square, as in 5e."""
        ax = a.x if ax is None else ax
        ay = a.y if ay is None else ay
        dx = max(0, b.x - (ax + a.size - 1), ax - (b.x + b.size - 1))
        dy = max(0, b.y - (ay + a.size - 1), ay - (b.y + b.size - 1))
        return max(dx, dy)

    @staticmethod
    def distance_to_cell(a: Combatant, x: int, y: int) -> int:
        dx = max(0, x - (a.x + a.size - 1), a.x - x)
        dy = max(0, y - (a.y + a.size - 1), a.y - y)
        return max(dx, dy)

    def line_of_sight(self, a: Combatant, b: Combatant) -> bool:
        (ax, ay), (bx, by) = a.center(), b.center()
        steps = int(max(abs(bx - ax), abs(by - ay)) * 3) + 1
        for i in range(1, steps):
            t = i / steps
            x, y = int(ax + (bx - ax) * t), int(ay + (by - ay) * t)
            if (x, y) in self.map.walls:
                return False
        return True

    # ==================================================================
    # Movement
    # ==================================================================
    def _neighbors(self, c: Combatant, x: int, y: int, occ: dict, memo: dict | None = None):
        if memo is None:
            memo = {}

        def ok(px, py):
            k = (px, py)
            v = memo.get(k)
            if v is None:
                v = memo[k] = self._can_pass(c, px, py, occ)
            return v
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                if not dx and not dy:
                    continue
                nx, ny = x + dx, y + dy
                if not ok(nx, ny):
                    continue
                if dx and dy and not (ok(x + dx, y) or ok(x, y + dy)):
                    continue  # no squeezing diagonally between two blocked squares
                yield nx, ny

    def reachable(self, c: Combatant, budget: int | None = None) -> dict[tuple[int, int], tuple[int, tuple | None]]:
        """Top-left positions c can stop at this turn: pos -> (cost, previous pos)."""
        budget = c.movement_left() if budget is None else budget
        occ = self.occupied(ignore=c)
        start = (c.x, c.y)
        best: dict = {start: (0, None)}
        heap = [(0, start)]
        memo: dict = {}                       # each square's passability, worked out once per search
        while heap:
            cost, (x, y) = heapq.heappop(heap)
            if cost > best[(x, y)][0] or cost >= budget:
                continue
            for n in self._neighbors(c, x, y, occ, memo):
                if n not in best or cost + 1 < best[n][0]:
                    best[n] = (cost + 1, (x, y))
                    heapq.heappush(heap, (cost + 1, n))
        # can't end a move on another creature (allies can be passed through)
        out = {p: v for p, v in best.items() if not any(cell in occ for cell in c.cells(*p))}
        fear = c.conditions.get("Frightened")
        src = next((o for o in self.combatants if fear and o.id == fear.get("source") and o.active), None)
        if src is not None:                 # can't willingly move closer to what frightens you
            now = self.distance(c, src)
            out = {p: v for p, v in out.items() if self.distance(c, src, *p) >= now}
        return out

    def _can_pass(self, c: Combatant, x: int, y: int, occ: dict) -> bool:
        blocked = self.map.blocked_cells()
        for cell in c.cells(x, y):
            if not self.map.inside(*cell) or cell in self.map.walls:
                return False
            if not c.flying and cell in blocked:
                return False
            other = occ.get(cell)
            if other is not None and c.hostile_to(other):
                return False
        return True

    def _trace(self, best: dict, dest) -> list:
        path = [dest]
        while best[path[-1]][1] is not None:
            path.append(best[path[-1]][1])
        path.reverse()
        return path[1:]

    def _shortest(self, c: Combatant, dest: tuple[int, int], budget: int | None = None) -> list[tuple[int, int]]:
        """Fewest squares to dest (diagonals count as one, as in 5e). Among the many routes
        that are equally short, take the one that stays closest to the straight line, so
        long moves look natural instead of going straight up and then across."""
        occ = self.occupied(ignore=c)
        start = (c.x, c.y)
        sx, sy = start
        dx, dy = dest[0] - sx, dest[1] - sy
        length = math.hypot(dx, dy) or 1.0

        def off_line(p) -> float:
            return abs((p[0] - sx) * dy - (p[1] - sy) * dx) / length

        def h(p) -> int:                      # squares left, at best (diagonals count as one)
            return max(abs(dest[0] - p[0]), abs(dest[1] - p[1]))

        best: dict = {start: ((0, 0.0), None)}
        heap = [((h(start), 0.0), (0, 0.0), start)]      # searched toward dest first (A*), same answer
        memo: dict = {}
        while heap:
            _f, cost, cur = heapq.heappop(heap)
            if cur == dest:
                break
            if cost > best[cur][0]:
                continue
            if budget is not None and cost[0] >= budget:
                continue
            for n in self._neighbors(c, cur[0], cur[1], occ, memo):
                nc = (cost[0] + 1, round(cost[1] + off_line(n), 6))
                if n not in best or nc < best[n][0]:
                    best[n] = (nc, cur)
                    heapq.heappush(heap, ((nc[0] + h(n), nc[1]), nc, n))
        if dest not in best:
            return []
        path = [dest]
        while best[path[-1]][1] is not None:
            path.append(best[path[-1]][1])
        path.reverse()
        return path[1:]

    def path_to(self, c: Combatant, dest: tuple[int, int]) -> list[tuple[int, int]]:
        occ = self.occupied(ignore=c)
        if any(cell in occ for cell in c.cells(*dest)):
            return []
        return self._shortest(c, dest, c.movement_left())

    def _full_path(self, c: Combatant, dest: tuple[int, int]) -> list[tuple[int, int]]:
        """Shortest path ignoring this turn's movement limit."""
        return self._shortest(c, dest)

    def move(self, c: Combatant, dest: tuple[int, int]) -> list[tuple[int, int]]:
        """Walk to dest one square at a time. Returns the squares actually entered
        (shorter if an opportunity attack drops the mover)."""
        path = self.path_to(c, dest)
        walked = []
        for step in path:
            self._opportunity_attacks(c, step)
            if not c.active:
                break
            old = (c.x, c.y)
            c.x, c.y = step
            c.moved += 1
            c.facing = _facing(step[0] - old[0], step[1] - old[1], c.facing)
            walked.append(step)
            self._emit("combat.moved", combatant=c, x=c.x, y=c.y)
        if c.grappling:
            held = next((o for o in self.combatants if o.id == c.grappling), None)
            if held is not None and self.distance(c, held) > 1:
                self._release(c, held, f"{c.name} lets go of {held.name}.")
        return walked

    def _opportunity_attacks(self, mover: Combatant, nxt: tuple[int, int]) -> None:
        if mover.disengaged:
            return
        for o in self.enemies_of(mover):
            if o.reaction_used or not CND.can_act(o):
                continue
            usable = [a for a in o.attacks if not a.ranged and self.distance(mover, o) <= a.reach
                      and self.distance(mover, o, nxt[0], nxt[1]) > a.reach]
            if not usable:
                continue
            usable.sort(key=lambda a: -(dice.average(a.damage) + a.to_hit))
            attack = usable[0]
            if o.team == PLAYER and self.ask_reaction is not None:
                options = [f"Attack with {a.name}" for a in usable]
                pick = self.ask_reaction(o, "Opportunity attack",
                                         f"{mover.name} is moving out of {o.name}'s reach. Use {o.name}'s reaction "
                                         f"to make an opportunity attack?", options)
                if pick is None:
                    self.say("system", f"{o.name} lets {mover.name} go.")
                    continue
                attack = usable[max(0, min(len(usable) - 1, int(pick)))]
            o.reaction_used = True
            self.say("system", f"{o.name} gets an opportunity attack!")
            self._emit("combat.reaction", combatant=o, kind="opportunity attack", target=mover)
            self._resolve_attack(o, attack, mover)
            if not mover.active:
                return

    # ==================================================================
    # Attacks
    # ==================================================================
    def targets_for(self, c: Combatant, attack: Attack) -> list[Combatant]:
        out = []
        charm = c.conditions.get("Charmed")
        for o in self.enemies_of(c):
            if charm and charm.get("source") == o.id:
                continue                   # a charmed creature can't attack its charmer
            d = self.distance(c, o)
            if d <= attack.max_range() and (d <= 1 or self.line_of_sight(c, o)):
                out.append(o)
        return out

    def can_attack(self, c: Combatant) -> bool:
        return CND.can_act(c) and ((not c.action_used) or c.attacks_left > 0)

    def can_offhand(self, c: Combatant) -> bool:
        """Two-weapon fighting: after attacking with a light melee weapon, a bonus action
        attack with the light weapon in the other hand."""
        return bool(c.bonus_attacks) and c.light_attacked and not c.bonus_used and CND.can_act(c)

    def has_ammo(self, c: Combatant, attack: Attack) -> bool:
        return not attack.ammo_type or c.ammo is None or c.ammo.get(attack.ammo_type, 0) > 0

    def _spend_ammo(self, c: Combatant, attack: Attack) -> None:
        if attack.ammo_type and c.ammo is not None:
            c.ammo[attack.ammo_type] = c.ammo.get(attack.ammo_type, 0) - 1
            c.ammo_used[attack.ammo_type] = c.ammo_used.get(attack.ammo_type, 0) + 1

    def attack(self, c: Combatant, attack: Attack, target: Combatant) -> AttackResult | None:
        if target not in self.targets_for(c, attack) or not self.has_ammo(c, attack):
            return None
        self._spend_ammo(c, attack)
        if attack.offhand:
            if not self.can_offhand(c):
                return None
            c.bonus_used = True
            return self._resolve_attack(c, attack, target)
        if not self.can_attack(c):
            return None
        if not c.action_used:
            c.action_used = True
            c.attacks_left = max(1, c.attacks_per_action)
        c.attacks_left -= 1
        if attack.light and not attack.ranged:
            c.light_attacked = True
        return self._resolve_attack(c, attack, target)

    def can_see(self, viewer: Combatant, target: Combatant) -> bool:
        if CND.has(viewer, "Blinded") or CND.has(target, "Invisible") or target.hidden:
            return False
        self.light.update_carried(self.combatants)
        return self.light.can_see(viewer, target)

    def attack_mode(self, c: Combatant, attack: Attack, target: Combatant) -> str:
        adv = dis = False
        if target.dodging:
            dis = True
        if attack.ranged:
            if any(self.distance(c, o) <= 1 for o in self.enemies_of(c)):
                dis = True
            if attack.range and self.distance(c, target) > attack.range:
                dis = True
        # Darkness: attacking something you can't see has disadvantage; being
        # attacked by something you can't see gives the attacker advantage.
        if not self.can_see(c, target):
            dis = True
        if not self.can_see(target, c):
            adv = True
        if self.effects(c, "Advantage on attacks", attack, target):
            adv = True
        if self.effects(target, "Attacks against you have advantage"):
            adv = True
        if c.helped:
            adv = True
        c_adv, c_dis = CND.attack_modifiers(self, c, target)
        adv, dis = adv or c_adv, dis or c_dis or c.armor_untrained
        if adv and dis:
            return "normal"
        return "advantage" if adv else "disadvantage" if dis else "normal"

    def crit_on(self, c: Combatant, attack: Attack | None = None) -> int:
        lowest = int(self.rules.get("crit_on", 20))
        for f, e in self.effects(c, "Critical hit range", attack):
            v = F.fixed(c, f, e.amount or e.detail or "20")
            if 2 <= v < lowest:
                lowest = v
        return lowest

    def _resolve_attack(self, c: Combatant, attack: Attack, target: Combatant) -> AttackResult:
        c.facing = _facing(target.x - c.x, target.y - c.y, c.facing)
        mode = self.attack_mode(c, attack, target)
        if c.helped:
            c.helped = False
        if c.hidden:
            c.hidden = False
            self.say("system", f"{c.name} strikes from hiding!")
        # Reactions before the roll: the target, or an ally standing next to it, may interfere.
        forced = False
        r = self._offer_reaction(target, "When a creature attacks you", c,
                                 f"{c.name} is attacking {target.name} with {attack.name}.")
        forced = forced or bool(r and r["disadvantage"])
        for ally in self.allies_of(target):
            if ally.team == target.team and self.distance(ally, target) <= 1:
                r = self._offer_reaction(ally, "When an ally near you is attacked", c,
                                         f"{c.name} is attacking {target.name}, next to {ally.name}.")
                forced = forced or bool(r and r["disadvantage"])
        if forced:
            self.say("system", f"{c.name}'s attack is hampered (disadvantage).")
            mode = "normal" if mode == "advantage" else "disadvantage"
        roll, detail = dice.d20(self.rng, mode)
        bonus_txt = ""
        bonus = 0
        for f, e in self.effects(c, "Bonus to attack rolls", attack, target, mode):
            n, d = F.amount(c, f, e.amount, self.rng)
            bonus += n
            bonus_txt += f" {'+' if n >= 0 else '-'} {abs(n)} ({f.name})"
        shown = roll + attack.to_hit + bonus
        player_side = c.team == PLAYER
        # Hidden cascading bonus: each miss in a row quietly adds +1 to the next attack.
        hidden = c.miss_streak if player_side else 0
        crit = roll >= self.crit_on(c, attack)
        hit = crit or (roll != 1 and shown + hidden >= target.ac)
        if hit and not crit and CND.auto_crit(self, c, target):
            crit = True                     # paralyzed or unconscious, hit from within 5 feet
        reduce = None
        if hit:
            def worth_it(opts):             # how the computer decides: only if it helps
                for o in opts:
                    bonus = self._reaction_ac(target, o)
                    if not crit and bonus and shown + hidden < target.ac + bonus:
                        return o
                    if self._reaction_has(o, ("Reduce damage",)) or (o["kind"] == "feature" and o["feature"].damage):
                        return o
                return None
            r = self._offer_reaction(target, "When you are hit by an attack", c,
                                     f"{c.name} hits {target.name} with {attack.name}"
                                     f"{' (a critical hit!)' if crit else ''}.", worth_it)
            if r:
                if not crit and shown + hidden < target.ac + r["ac"]:
                    hit = False
                    self.say("system", f"The attack is turned aside! ({target.name}'s AC is now "
                                       f"{target.ac + r['ac']}.)" if target.team == PLAYER else
                             "The attack is turned aside!")
                reduce = r["reduce"]
        if player_side:
            c.miss_streak = 0 if hit else c.miss_streak + 1
        sign = "+" if attack.to_hit >= 0 else "-"
        line = (f"{c.name} attacks {target.name} with {attack.name}: {detail} {sign} {abs(attack.to_hit)}{bonus_txt}"
                f" = {shown}")
        if target.team == PLAYER:
            line += f" vs AC {target.ac}"     # your own armor is no secret; the enemy's is
        if not hit:
            self.say("roll", line + ("  ·  Natural 1, miss" if roll == 1 else "  ·  Miss"))
            self._emit("combat.attack", attacker=c, target=target, hit=False, crit=False, damage=0, attack=attack,
                       roll=roll, total=shown)
            return AttackResult(False, False, roll, shown, text=line)
        expr = dice.parse(attack.damage)
        if crit:
            expr = expr.doubled_dice()
        r = dice.roll(expr, self.rng)
        total, detail_txt = r.total, r.detail
        extra_hits: list[tuple[int, str, str]] = []      # (amount, damage type, detail)
        if attack.extra_damage and dice.is_valid(attack.extra_damage):
            xe = dice.parse(attack.extra_damage)
            xr = dice.roll(xe.doubled_dice() if crit else xe, self.rng)
            if attack.extra_type and attack.extra_type != attack.damage_type:
                extra_hits.append((xr.total, attack.extra_type, xr.detail))
            else:
                total += xr.total
                detail_txt += f" + {xr.detail}"
        if attack.weapon:
            for f, e in self.effects(c, "Bonus to damage", attack, target, mode):
                n, d = F.amount(c, f, e.amount, self.rng, crit)
                total += n
                detail_txt += f" + {d} ({f.name})"
            for f, e in self.effects(c, "Extra damage", attack, target, mode):
                if f.uses == "Once per turn":
                    if f.used_this_turn:
                        continue
                    f.used_this_turn = True
                n, d = F.amount(c, f, e.amount, self.rng, crit)
                dtype = (e.detail or "").strip().lower()
                if dtype and dtype in F.DAMAGE_TYPES and dtype != attack.damage_type:
                    extra_hits.append((n, dtype, f"{d} {f.name}"))
                else:
                    total += n
                    detail_txt += f" + {d} ({f.name})"
        self.say("roll", line + ("  ·  CRITICAL HIT!" if crit else "  ·  Hit"))
        if reduce:
            before = total
            total = self._reduced(target, total, reduce)
            detail_txt += f", reduced from {before}"
        dealt = self.damage(target, max(0, total), attack.damage_type, source=c, detail=detail_txt, crit=crit,
                            mundane=attack.weapon and not attack.magical)
        for n, dtype, d in extra_hits:
            if target.alive:
                dealt += self.damage(target, max(0, n), dtype, source=c, detail=d)
        if attack.condition and target.alive and not CND.has(target, attack.condition):
            if not attack.cond_dc or not self.saving_throw(target, attack.cond_save or "str", attack.cond_dc):
                repeat = (attack.cond_save or "str", attack.cond_dc) if attack.cond_dc and \
                    attack.condition not in ("Prone",) else None
                CND.apply(self, target, attack.condition, -1, c, repeat)
        self._emit("combat.attack", attacker=c, target=target, hit=True, crit=crit, damage=dealt, attack=attack,
                   roll=roll, total=shown)
        return AttackResult(True, crit, roll, shown, dealt, line)

    def damage(self, target: Combatant, amount: int, damage_type: str = "", source: Combatant | None = None,
               detail: str = "", crit: bool = False, mundane: bool = False) -> int:
        """mundane: a hit from a weapon that isn't magical (some creatures shrug those off)."""
        note = ""
        if not target.alive:
            return 0
        if amount > 0 and target.alive and source is not None:
            r = self._offer_reaction(target, "When you take damage", source,
                                     f"{target.name} is about to take {amount} {damage_type} damage.".replace("  ", " "))
            if r and r["reduce"]:
                before = amount
                amount = self._reduced(target, amount, r["reduce"])
                note += f" (reduced from {before})"
        guard = target.weapon_guard if mundane and damage_type in ("bludgeoning", "piercing", "slashing") else ""
        if damage_type in target.immune or (damage_type == "poison" and CND.has(target, "Petrified")) \
                or guard == "Immune":
            amount, note = 0, " (immune)" if not guard else " (immune to nonmagical weapons)"
        elif guard == "Resistant" and damage_type not in target.vulnerable:
            amount, note = amount // 2, " (resists nonmagical weapons)"
        elif damage_type in target.resist or (CND.has(target, "Petrified") and amount > 0):
            amount, note = amount // 2, " (resisted)"
        elif damage_type in target.vulnerable:
            amount, note = amount * 2, " (vulnerable)"
        if target.temp_hp and amount > 0:
            soaked = min(target.temp_hp, amount)
            target.temp_hp -= soaked
            note += f" ({soaked} absorbed by temporary HP)"
            hp_loss = amount - soaked
        else:
            hp_loss = amount
        was_down = target.dying or (target.hp <= 0 and target.alive)
        overflow = max(0, hp_loss - target.hp)
        target.hp = max(0, target.hp - hp_loss)
        dtype = f" {damage_type}" if damage_type else ""
        detail_txt = f" [{detail}]" if detail else ""
        self.say("damage", f"{target.name} takes {amount}{dtype} damage{note}{detail_txt}. ({target.hp_text()} HP)")
        self._emit("combat.damage", target=target, amount=amount, damage_type=damage_type, source=source)
        if amount > 0:
            target.hidden = False
            for _f, e in self.effects(target, "Regenerate"):
                if damage_type and damage_type in F.damage_types(e.detail):
                    target.regen_blocked = True
        self.refresh_stats(target)
        if target.concentration and amount > 0 and target.hp > 0:
            dc = max(10, amount // 2)
            self.say("system", f"{target.name} tries to keep concentrating on {target.concentration.get('name')}.")
            if not self.saving_throw(target, self.rules.get("hp_stat", "con"), dc):
                CND.end_concentration(self, target)
        if was_down and hp_loss > 0 and target.alive:
            # hurt while dying: a failed death save (two for a critical hit), or death from a big enough blow
            if overflow >= target.max_hp:
                self._die(target, source, "The blow is fatal.")
            else:
                self._death_fail(target, 2 if crit else 1, source)
        elif target.hp <= 0 and target.alive:
            if target.concentration:
                CND.end_concentration(self, target, "down")
            if self.dies_slowly(target) and overflow < target.max_hp:
                target.dying, target.stable, target.death_saves = True, False, [0, 0]
                CND.apply(self, target, "Unconscious", -1, source, quiet=True)
                self.say("damage", f"{target.name} falls unconscious and is dying!")
                self._emit("combat.down", combatant=target, source=source)
                self._check_outcome()
            elif self.dies_slowly(target):
                self._die(target, source, f"The damage is overwhelming. {target.name} is killed outright!")
            else:
                target.alive = False
                self.say("loot" if target.team == ENEMY else "damage", f"{target.name} is defeated!")
                self._emit("combat.defeated", combatant=target, source=source)
                self._check_outcome()
        return amount

    # ------------------------------------------------------------------
    # Dying (player characters)
    # ------------------------------------------------------------------
    def dies_slowly(self, c: Combatant) -> bool:
        """Player characters at 0 HP fall unconscious and make death saving throws."""
        return c.team == PLAYER and bool(self.rules.get("death_saves", True))

    def _die(self, c: Combatant, source=None, text: str = "") -> None:
        c.alive = False
        c.dead = True
        c.dying = False
        if text:
            self.say("damage", text)
        self.say("damage", f"{c.name} is dead.")
        self._emit("combat.defeated", combatant=c, source=source)
        self._emit("combat.died", combatant=c, source=source)
        self._check_outcome()

    def _death_fail(self, c: Combatant, n: int = 1, source=None) -> None:
        c.stable = False
        c.death_saves[1] += n
        self.say("damage", f"{c.name} fails {'two death saves' if n > 1 else 'a death save'} "
                           f"({c.death_saves[0]} successes, {c.death_saves[1]} failures).")
        if c.death_saves[1] >= 3:
            self._die(c, source)

    def death_save(self, c: Combatant) -> str:
        """Roll a death saving throw for a dying creature. Returns what happened."""
        roll = self.rng.randint(1, 20)
        if roll == 20:
            self.say("heal", f"{c.name} rolls a natural 20 on the death save and wakes with 1 HP!")
            self.heal(c, 1)
            return "revived"
        if roll == 1:
            self.say("roll", f"{c.name} death save: natural 1.")
            self._death_fail(c, 2)
            return "dead" if c.dead else "fail"
        if roll >= 10:
            c.death_saves[0] += 1
            self.say("roll", f"{c.name} death save: {roll}  ·  success ({c.death_saves[0]} of 3).")
            if c.death_saves[0] >= 3:
                c.stable = True
                self.say("heal", f"{c.name} is stable, though still unconscious.")
                return "stable"
            return "success"
        self.say("roll", f"{c.name} death save: {roll}  ·  failure.")
        self._death_fail(c, 1)
        return "dead" if c.dead else "fail"

    def dying_allies(self, c: Combatant) -> list[Combatant]:
        return [o for o in self.allies_of(c) if o.dying and not o.stable and self.distance(c, o) <= 1]

    def stabilize(self, c: Combatant, target: Combatant) -> bool:
        """Medicine check (DC 10) as an action to stop an adjacent ally from dying."""
        if c.action_used or not CND.can_act(c) or target not in self.dying_allies(c):
            return False
        c.action_used = True
        c.attacks_left = 0
        bonus = c.mod("wis") + (c.prof if "medicine" in c.skill_profs else 0)
        roll, detail = dice.d20(self.rng, "disadvantage" if CND.check_disadvantage(c) else "normal")
        ok = roll + bonus >= 10
        self.say("roll", f"{c.name} tries to stabilize {target.name}: {detail} {'+' if bonus >= 0 else '-'} "
                         f"{abs(bonus)} = {roll + bonus} vs DC 10  ·  {'Success' if ok else 'Failure'}")
        if ok:
            target.stable = True
            self.say("heal", f"{target.name} is stable.")
        return True

    def heal(self, target: Combatant, amount: int) -> int:
        if not target.alive:
            return 0
        if (target.dying or target.hp <= 0) and amount > 0:
            target.dying, target.stable, target.death_saves = False, False, [0, 0]
            if CND.has(target, "Unconscious"):
                CND.remove(self, target, "Unconscious")
            self.say("heal", f"{target.name} regains consciousness!")
        before = target.hp
        target.hp = min(target.max_hp, target.hp + max(0, amount))
        gained = target.hp - before
        self.say("heal", f"{target.name} recovers {gained} HP. ({target.hp_text()} HP)")
        self._emit("combat.heal", target=target, amount=gained)
        self.refresh_stats(target)
        return gained

    # ==================================================================
    # Spells
    # ==================================================================
    def uses_mana(self, c: Combatant) -> bool:
        return c.mana_max > 0 and not c.is_monster and (self.rules.get("magic_system") or "Mana") == "Mana"

    def mana_cost(self, level: int) -> int:
        return int(self.rules.get("mana_per_spell_level", 10) or 10) * max(0, int(level))

    def castable(self, c: Combatant, timing: str = "Action") -> list[tuple[Spell, int]]:
        """(spell, lowest slot level usable) for every spell c can cast right now with
        its action (timing "Action") or bonus action ("Bonus action").

        5e rule: after casting a bonus-action spell, the only other spell you can cast
        that turn is a cantrip with a casting time of one action (and so a leveled
        action spell rules out a bonus-action spell)."""
        out = []
        if not CND.can_act(c) or c.armor_untrained:      # no spells in armor you aren't trained to wear
            return out
        if getattr(self, "antimagic", False):            # a jail's wards (game/jail.py): no spells at all
            return out
        if timing == "Bonus action":
            if c.bonus_used or c.leveled_action_spell:
                return out
        elif timing == "Reaction":
            if c.reaction_used:
                return out
        elif c.action_used:
            return out
        for s in c.spells:
            if s.casting_time != timing:
                continue
            if timing == "Action" and c.bonus_spell and s.level > 0:
                continue
            if s.level == 0:
                out.append((s, 0))
            elif c.is_monster and not c.slots_max:
                if s.id not in c.once_per_fight:
                    out.append((s, s.level))
            else:
                levels = self.slot_levels(c, s)
                if levels:
                    out.append((s, levels[0]))
        return out

    def slot_levels(self, c: Combatant, spell: Spell) -> list[int]:
        """Levels the spell can be cast at right now. With Mana: any level from the spell's own up to
        the highest the character has slots for, that they can afford (10 Mana per level)."""
        if spell.level == 0 or (c.is_monster and not c.slots_max):
            return [spell.level]
        if self.uses_mana(c):
            top = c.max_cast_level or max(c.slots_max or {0: 0})
            return [l for l in range(spell.level, top + 1) if c.mana >= self.mana_cost(l)]
        return [l for l in sorted(c.slots) if l >= spell.level and c.slots[l] > 0]

    def spell_targets(self, c: Combatant, spell: Spell) -> list[Combatant]:
        if spell.self_only:
            return [c]
        if spell.effect == "Revive":
            return [o for o in self.combatants if o.dead and not o.hostile_to(c) and o is not c
                    and self.distance(c, o) <= max(1, spell.range)]
        pool = ([c] + self.allies_of(c)) if spell.helps_allies else self.enemies_of(c)
        reach = max(1, spell.range)
        return [o for o in pool if self.distance(c, o) <= reach
                and (o is c or self.distance(c, o) <= 1 or self.line_of_sight(c, o))]

    def area_reach(self, c: Combatant, spell: Spell) -> int:
        """How far away (in squares) an area spell can be aimed."""
        if spell.area in ("Cone", "Line") or spell.range <= 1:
            return max(1, spell.area_size)
        return spell.range

    def area_cells(self, c: Combatant, spell: Spell, x: int, y: int) -> set[tuple[int, int]]:
        """Squares covered by an area spell aimed at (x, y)."""
        size = max(1, spell.area_size)
        cells = set()
        cx, cy = c.center()
        if spell.area in ("Sphere", "Cylinder"):
            for yy in range(y - size, y + size + 1):
                for xx in range(x - size, x + size + 1):
                    if (xx - x) ** 2 + (yy - y) ** 2 <= size * size + size and self.map.inside(xx, yy):
                        cells.add((xx, yy))
        elif spell.area == "Cube":
            for yy in range(y - size // 2, y - size // 2 + size):
                for xx in range(x - size // 2, x - size // 2 + size):
                    if self.map.inside(xx, yy):
                        cells.add((xx, yy))
        elif spell.area in ("Cone", "Line"):
            dx, dy = x + 0.5 - cx, y + 0.5 - cy
            n = math.hypot(dx, dy) or 1
            ux, uy = dx / n, dy / n
            for yy in range(self.map.h):
                for xx in range(self.map.w):
                    vx, vy = xx + 0.5 - cx, yy + 0.5 - cy
                    along = vx * ux + vy * uy
                    edge = along - c.size / 2
                    if edge <= -0.2 or edge > size:
                        continue
                    across = abs(-vx * uy + vy * ux)
                    limit = (edge / 2 + 0.6) if spell.area == "Cone" else 0.6
                    if across <= limit:
                        cells.add((xx, yy))
        return {cell for cell in cells if cell not in self.map.walls}

    def cast(self, c: Combatant, spell: Spell, target: Combatant | None = None,
             cell: tuple[int, int] | None = None, slot: int | None = None) -> bool:
        timing = "Bonus action" if spell.bonus_action else "Action"
        if spell.self_only and target is None and not spell.targets_cell:
            target = c
        options = dict((s.id, lvl) for s, lvl in self.castable(c, timing))
        if spell.id not in options:
            return False
        if slot is None or slot not in self.slot_levels(c, spell):
            slot = options[spell.id]
        if not self._aim_ok(c, spell, target, cell):
            return False
        if spell.targets_area and cell is None:
            tx, ty = target.center()
            cell = (int(tx), int(ty))
        if spell.concentration:
            CND.end_concentration(self, c, "casting another concentration spell")
        if spell.bonus_action:
            c.bonus_used = True
            c.bonus_spell = True
        else:
            c.action_used = True
            c.attacks_left = 0
            if spell.level > 0:
                c.leveled_action_spell = True
        if spell.level > 0:
            if c.is_monster and not c.slots_max:
                c.once_per_fight.add(spell.id)
            elif self.uses_mana(c):
                c.mana -= self.mana_cost(slot)
            else:
                c.slots[slot] -= 1
        extra = max(0, slot - spell.level) if spell.level else 0
        level_txt = f" with a level {slot} slot" if spell.level and slot > spell.level else ""
        if spell.level and self.uses_mana(c):
            level_txt = (f" at level {slot}" if slot > spell.level else "") + f" ({self.mana_cost(slot)} Mana)"
        self.say("quest", f"{c.name} casts {spell.name}{level_txt}!")
        if self._countered(c, spell, slot):
            return True
        self._spell_effect(c, spell, target, cell, extra)
        return True

    def _countered(self, c: Combatant, spell: Spell, slot: int) -> bool:
        """Does a foe within 60 feet stop the spell (Counterspell)? Spells of the counter's slot level or
        lower simply fail; stronger ones need an ability check (DC 10 + the spell's level)."""
        level = slot if spell.level else 0
        for o in [x for x in self.combatants if x.active and x.hostile_to(c)]:
            if self.distance(o, c) > 12 or not self.line_of_sight(o, c):
                continue
            if not any(opt["kind"] == "spell" for opt in self.reaction_options(o, COUNTER)):
                continue
            r = self._offer_reaction(o, COUNTER, c, f"{c.name} is casting {spell.name}"
                                     f"{f' (level {level})' if level else ''}.",
                                     wanted=lambda opts: next((x for x in opts if x["kind"] == "spell"), None)
                                     if level >= 1 else None)
            if not r or r.get("counter") is None:
                continue
            if r["counter"] >= level:
                self.say("quest", f"{c.name}'s {spell.name} is countered!")
                return True
            check = dice.roll("1d20", self.rng).total + o.mod(o.casting_stat or "int")
            if check >= 10 + level:
                self.say("quest", f"{o.name} wrests the magic apart ({check} vs DC {10 + level}): "
                                  f"{spell.name} is countered!")
                return True
            self.say("system", f"{o.name}'s counter falls short ({check} vs DC {10 + level}).")
        return False

    def _aim_ok(self, c: Combatant, spell: Spell, target: Combatant | None, cell) -> bool:
        """Is this a valid target / square for the spell?"""
        if spell.effect == "Teleport":
            if cell is None:
                return False
            occ = self.occupied(ignore=c)
            return (self.distance_to_cell(c, *cell) <= max(1, spell.range) and self.map.fits(cell[0], cell[1], c.size)
                    and not any(p in occ for p in c.cells(*cell)))
        if spell.targets_area:
            if cell is None and target is not None:
                tx, ty = target.center()
                cell = (int(tx), int(ty))
            return cell is not None and self.distance_to_cell(c, *cell) <= self.area_reach(c, spell)
        return target is not None and target in self.spell_targets(c, spell)

    def _spell_effect(self, c: Combatant, spell: Spell, target: Combatant | None, cell, extra: int = 0,
                      emit: str = "combat.cast") -> None:
        """What a spell (or a damaging feature, dressed up as a spell) does once cast."""
        spell = self._cantrip_scaled(c, spell)
        dc = spell.dc or c.spell_dc
        to_hit = c.spell_attack if spell.attack_bonus is None else spell.attack_bonus
        if target is not None and not spell.targets_area:
            c.facing = _facing(target.x - c.x, target.y - c.y, c.facing)
        elif cell is not None:
            c.facing = _facing(cell[0] - c.x, cell[1] - c.y, c.facing)
        self._emit(emit, caster=c, spell=spell, target=target, cell=cell)

        def amount(base: str) -> dice.Roll:
            r = dice.roll(base, self.rng)
            if extra and spell.upcast:
                for _ in range(extra):
                    up = dice.roll(spell.upcast, self.rng)
                    r = dice.Roll(r.total + up.total, r.detail + " + " + up.detail, r.rolls + up.rolls)
            return r

        if spell.concentration and not c.concentration and spell.effect in ("Summon",):
            c.concentration = {"id": spell.id, "name": spell.name}
        if spell.effect == "Healing":
            if spell.targets_area and cell is not None:
                covered = self.area_cells(c, spell, *cell)
                patients = [o for o in [c] + self.allies_of(c) if any(p in covered for p in o.cells())]
            else:
                patients = [target]
            for p in patients:
                r = amount(spell.healing or "1d8")
                self.heal(p, r.total + c.mod(c.casting_stat))
            return
        if spell.effect == "Temporary hit points":
            r = amount(spell.temp_hp or spell.healing or "1d4")
            target = target or c
            if r.total > target.temp_hp:
                target.temp_hp = r.total
            self.say("heal", f"{target.name} gains {r.total} temporary hit points. ({target.hp_text()} HP)")
            if spell.effects:
                self._grant(c, spell, target)
            return
        if spell.effect == "Remove condition":
            target = target or c
            gone = [n for n in spell.removes if CND.has(target, n)]
            for n in gone:
                CND.remove(self, target, n)
            if not gone:
                self.say("system", f"{spell.name} finds nothing to cure on {target.name}.")
            return
        if spell.effect == "Revive":
            if target is not None and target.dead:
                target.dead, target.alive, target.dying, target.stable = False, True, False, False
                target.death_saves = [0, 0]
                target.conditions.pop("Unconscious", None)
                target.hp = max(1, min(target.max_hp, spell.revive_hp or 1))
                self.say("heal", f"{target.name} gasps back to life! ({target.hp_text()} HP)")
                self._emit("combat.revived", combatant=target, source=c)
            return
        if spell.effect == "Teleport":
            if cell is not None:
                c.x, c.y = cell
                self.say("narration", f"{c.name} vanishes and reappears elsewhere.")
                self._emit("combat.teleport", combatant=c)
            return
        if spell.effect == "Summon":
            self._summon(c, spell, extra)
            return

        if spell.effect == "Effect blocks":
            if spell.targets_area and cell is not None:
                covered = self.area_cells(c, spell, *cell)
                side = ([c] + self.allies_of(c)) if spell.helps_allies else self.enemies_of(c)
                victims = [o for o in side if any(p in covered for p in o.cells())]
            else:
                victims = [target or c]
            for v in victims:
                self._grant(c, spell, v)
            return

        if spell.targets_area:
            covered = self.area_cells(c, spell, *cell)
            if spell.damage:                              # walls, trees and furniture in it (game/combat/wreck.py)
                from game.combat import wreck
                wreck.area(self, c, covered, spell.damage, spell.damage_type)
            victims = [o for o in self.combatants if o.active and o is not c and any(p in covered for p in o.cells())]
            if spell.only_foes:
                victims = [o for o in victims if c.hostile_to(o)]
            if not victims:
                self.say("system", "The spell hits nothing.")
        else:
            victims = [target]

        if spell.effect in ("Spell attack (melee)", "Spell attack (ranged)"):
            expr = spell.damage or "1d6"
            if extra and spell.upcast:
                expr = " + ".join([expr] + [spell.upcast] * extra)
            for v in victims:
                for _ in range(max(1, spell.missiles)):
                    if not v.active:
                        break
                    atk = Attack(spell.name, "Ranged" if "ranged" in spell.effect else "Melee", to_hit,
                                 expr, spell.damage_type, reach=max(1, spell.range), range=spell.range,
                                 long_range=spell.range, stat=c.casting_stat, weapon=False)
                    res = self._resolve_attack(c, atk, v)
                    if res.hit and spell.condition and v.active:
                        self._spell_condition(c, spell, v, save=False, dc=dc)
                    if res.hit and spell.effects and v.active:
                        self._grant(c, spell, v)
        elif spell.effect == "Saving throw":
            r = amount(spell.damage) if spell.damage and dice.is_valid(spell.damage) else None
            for v in victims:
                ok = self.saving_throw(v, spell.save_stat, dc, from_spell=spell.level > 0 or spell.dc == 0)
                if not ok and spell.condition and v.active:
                    self._spell_condition(c, spell, v, save=True, dc=dc)
                if not ok and spell.effects and v.active:
                    self._grant(c, spell, v)
                if r is None:
                    continue
                dmg = r.total
                if ok:
                    if spell.on_save != "Half damage":
                        continue
                    dmg //= 2
                self.damage(v, dmg, spell.damage_type, source=c, detail=r.detail)
        elif spell.effect == "Automatic hit":
            for v in victims:
                if spell.hp_limit and v.hp > spell.hp_limit:
                    self.say("system", f"{v.name} has too much life left for {spell.name} to take hold.")
                    continue
                if spell.slays:
                    v.hp = 0
                    self._die(v, c, f"{spell.name}: {v.name} dies on the spot!")
                    continue
                for _ in range(max(1, spell.missiles) if (spell.damage or not spell.condition) else 0):
                    if v.active:
                        r = amount(spell.damage or "1d4")
                        self.damage(v, r.total, spell.damage_type, source=c, detail=r.detail)
                if spell.condition and v.active:
                    self._spell_condition(c, spell, v, save=False, dc=dc)
                if spell.effects and v.active:
                    self._grant(c, spell, v)
        else:
            self.say("system", spell.description or f"{spell.name} takes effect.")

    @staticmethod
    def _cantrip_scaled(c: Combatant, spell: Spell) -> Spell:
        """Cantrips get stronger at character levels 5, 11 and 17: twice, three and four times the
        dice (Fire Bolt 1d10 -> 4d10), or one beam more each time (Eldritch Blast)."""
        if spell.level != 0 or spell.cantrip_scaling == "None" or not spell.damage:
            return spell
        lvl = int(getattr(c, "level", 1) or 1)
        tier = 1 + (lvl >= 5) + (lvl >= 11) + (lvl >= 17)
        if tier == 1:
            return spell
        import dataclasses
        if spell.cantrip_scaling == "Extra beam":
            return dataclasses.replace(spell, missiles=max(1, spell.missiles) * tier)
        m = re.match(r"^\s*(\d*)d(\d+)(.*)$", spell.damage)
        if not m:
            return spell
        n = int(m.group(1) or 1) * tier
        return dataclasses.replace(spell, damage=f"{n}d{m.group(2)}{m.group(3)}")

    # ------------------------------------------------------------------
    # Legendary actions
    # ------------------------------------------------------------------
    def _legendary_after(self, ended: Combatant | None) -> None:
        """At the end of another creature's turn, each legendary creature may take one legendary action."""
        for c in list(self.order):
            if c is ended or not c.active or c.legendary_left <= 0 or not c.legendary or c.team == PLAYER \
                    or not CND.can_act(c) or self.outcome:
                continue
            foes = [o for o in self.enemies_of(c) if o.hp > 0]
            if not foes:
                continue
            for row in c.legendary:
                cost = max(1, int(row.get("cost") or 1))
                if cost > c.legendary_left:
                    continue
                if self._legendary_action(c, row, foes):
                    c.legendary_left -= cost
                    break

    def _legendary_action(self, c: Combatant, row: dict, foes: list) -> bool:
        does = row.get("does") or "Attack"
        what = str(row.get("what") or "").strip().lower()
        title = row.get("name") or what.title() or does
        if does == "Attack":
            attacks = [a for a in c.attacks if a.name.lower() == what] or c.attacks[:1]
            for atk in attacks:
                tgts = self.targets_for(c, atk)
                if tgts:
                    self.say("quest", f"{c.name} takes a legendary action: {title}!")
                    self._resolve_attack(c, atk, min(tgts, key=lambda o: o.hp))
                    return True
            return False
        if does == "Move":
            target = min(foes, key=lambda o: self.distance(c, o))
            if self.distance(c, target) <= 1:
                return False
            moved, dis = c.moved, c.disengaged
            c.moved, c.disengaged = c.speed - c.speed // 2, True
            dest = self._approach(c, target, None)
            if dest and dest != (c.x, c.y):
                self.say("quest", f"{c.name} takes a legendary action: {title}!")
                self.move(c, dest)
            c.moved, c.disengaged = moved, dis
            return bool(dest)
        f = next((x for x in c.features if x.name.lower() == what), None)
        spell = self.feature_spell(c, f) if f is not None else None
        if spell is None:
            return False
        if spell.targets_area:
            best = self._best_area_cell(c, spell, foes)
            if not best or best[1] < 1:
                return False
            self.say("quest", f"{c.name} takes a legendary action: {title}!")
            self._spell_effect(c, spell, None, best[0], emit="combat.feature_damage")
            return True
        tgts = [o for o in self.spell_targets(c, spell) if o in foes] if not spell.helps_allies else [c]
        if not tgts:
            return False
        self.say("quest", f"{c.name} takes a legendary action: {title}!")
        self._spell_effect(c, spell, min(tgts, key=lambda o: o.hp), None, emit="combat.feature_damage")
        return True

    # ------------------------------------------------------------------
    # Summoned creatures
    # ------------------------------------------------------------------
    # Set by whoever builds the battle: summon_factory(entity id, team, rng) -> (Combatant, sprite) or None
    summon_factory: Callable | None = None

    def _summon(self, c: Combatant, spell: Spell, extra: int = 0) -> list[Combatant]:
        if self.summon_factory is None or not spell.summons:
            self.say("system", f"{spell.name}: nothing answers the call.")
            return []
        n = max(1, dice.roll(spell.summon_count or "1", self.rng).total if dice.is_valid(str(spell.summon_count))
                else 1)
        team = ALLY if c.team in (PLAYER, ALLY) else c.team
        out = []
        for _ in range(n):
            made = self.summon_factory(spell.summons, team, self.rng)
            if not made:
                break
            s, art = made if isinstance(made, tuple) else (made, None)
            spot = self._free_spot_near(c, s.size)
            if spot is None:
                break
            s.x, s.y = spot
            s.summoned_by = f"{c.id}:{spell.id}"
            s.summon_rounds = -1 if spell.concentration else max(1, spell.rounds or 10)
            s.xp, s.loot, s.gold = 0, [], ""
            s.initiative = c.initiative
            self.combatants.append(s)
            idx = self.order.index(c) + 1 if c in self.order else len(self.order)
            self.order.insert(idx, s)
            if idx <= self.turn_index:
                self.turn_index += 1
            self.refresh_stats(s)
            out.append(s)
            self._emit("combat.summoned", combatant=s, sprite=art, source=c)
        if out:
            self.say("narration", f"{', '.join(o.name for o in out)} appear{'s' if len(out) == 1 else ''} at "
                                  f"{c.name}'s call!")
            if spell.concentration:
                c.concentration = {"id": spell.id, "name": spell.name}
        return out

    def _free_spot_near(self, c: Combatant, size: int = 1):
        occ = self.occupied()
        best = None
        for r in range(1, 6):
            for y in range(c.y - r, c.y + c.size + r):
                for x in range(c.x - r, c.x + c.size + r):
                    if not self.map.fits(x, y, size) or any((xx, yy) in occ for xx in range(x, x + size)
                                                             for yy in range(y, y + size)):
                        continue
                    d = abs(x - c.x) + abs(y - c.y)
                    if best is None or d < best[0]:
                        best = (d, (x, y))
            if best:
                return best[1]
        return None

    def _dismiss(self, c: Combatant, text: str = "") -> None:
        if not c.active:
            return
        c.fled = True
        if text:
            self.say("narration", text)
        self._emit("combat.dismissed", combatant=c)
        self._check_outcome()

    def _spell_condition(self, caster: Combatant, spell: Spell, target: Combatant, save: bool, dc: int) -> None:
        rounds = spell.condition_rounds if spell.condition_rounds > 0 else -1
        repeat = (spell.save_stat, dc) if (save and spell.condition_save_each_turn and spell.save_stat) else None
        if CND.apply(self, target, spell.condition, rounds, caster, repeat):
            if spell.concentration:
                target.conditions[spell.condition.title()].update(concentration=caster.id, spell=spell.id)
                caster.concentration = {"id": spell.id, "name": spell.name}

    def _grant(self, caster: Combatant, spell: Spell, target: Combatant) -> None:
        """Put a spell's effect blocks on a creature for the spell's duration."""
        if not spell.effects:
            return
        target.features = [f for f in target.features if f.id != f"spell:{spell.id}"]
        rf = F.granted(spell, spell.effects, spell.rounds if spell.rounds else 1, caster.id)
        target.features.append(rf)
        if spell.concentration:
            caster.concentration = {"id": spell.id, "name": spell.name}
        self.refresh_stats(target)
        what = ", ".join(sorted({e.kind.lower() for e in spell.effects}))
        span = "" if rf.rounds_left < 0 else f" for {rf.rounds_left} round{'s' if rf.rounds_left != 1 else ''}"
        self.say("system", f"{target.name} is under {spell.name}{span}: {what}.")

    def saving_throw(self, target: Combatant, stat_key: str, dc: int, from_spell: bool = False) -> bool:
        bonus = target.mod(stat_key) + (target.prof if stat_key in target.saves else 0)
        effect = CND.save_effect(target, stat_key)
        label_ = stat_key.upper() if stat_key else "Save"
        if effect == "fail":
            self.say("roll", f"{target.name} {label_} save vs DC {dc}  ·  automatic failure "
                             f"({CND.summary(target)})")
            return False
        if target.armor_untrained and stat_key in ("str", "dex"):
            effect = "disadvantage"
        advantage = False
        for _f, e in self.effects(target, "Advantage on saving throws"):
            what = (e.detail or e.amount or "").lower()
            if not what or "all" in what or stat_key in what or (from_spell and ("spell" in what or "magic" in what)):
                advantage = True
        mode = "normal"
        if effect and not advantage:
            mode = "disadvantage"
        elif advantage and not effect:
            mode = "advantage"
        roll, detail = dice.d20(self.rng, mode)
        for f, e in self.effects(target, "Bonus to saving throws"):
            n, _d = F.amount(target, f, e.amount, self.rng)
            bonus += n
        total = roll + bonus
        ok = total >= dc
        label = stat_key.upper() if stat_key else "Save"
        self.say("roll", f"{target.name} {label} save: {detail} {'+' if bonus >= 0 else '-'} {abs(bonus)} = {total} "
                         f"vs DC {dc}  ·  {'Success' if ok else 'Failure'}")
        if not ok and target.legendary_resist > 0 and target.team != PLAYER:
            target.legendary_resist -= 1
            self.say("system", f"{target.name} uses Legendary Resistance and succeeds instead! "
                               f"({target.legendary_resist} left)")
            ok = True
        return ok

    # ==================================================================
    # Reactions (features and spells with a trigger)
    # ==================================================================
    def reaction_options(self, c: Combatant, trigger: str) -> list[dict]:
        if c.reaction_used or not CND.can_act(c):
            return []
        out = []
        for f in c.features:
            if f.activation == "Reaction" and f.reaction_trigger == trigger and f.available(reaction=True) \
                    and self.requirements_met(c, f) and self.can_pay(c, f):
                out.append({"kind": "feature", "feature": f, "label": f"Use {f.name}"})
        for s, lvl in self.castable(c, "Reaction"):
            if s.reaction_trigger == trigger:
                cost = (f" ({self.mana_cost(lvl)} Mana)" if self.uses_mana(c) else f" (level {lvl} slot)")
                out.append({"kind": "spell", "spell": s, "slot": lvl,
                            "label": f"Cast {s.name}" + (cost if s.level and not c.is_monster else "")})
        return out

    def _reaction_has(self, option: dict, kinds: tuple) -> bool:
        effects = option["feature"].effects if option["kind"] == "feature" else option["spell"].effects
        return any(e.kind in kinds for e in effects)

    def _reaction_ac(self, c: Combatant, option: dict) -> int:
        if option["kind"] == "feature":
            f = option["feature"]
            return sum(F.fixed(c, f, e.amount) for e in f.effects if e.kind == "Bonus to AC")
        s = option["spell"]
        return sum(F.fixed(c, None, e.amount) for e in s.effects if e.kind == "Bonus to AC")

    def _reduced(self, c: Combatant, amount: int, how: str) -> int:
        how = str(how or "half").strip().lower()
        if how in ("half", "halve", "1/2", ""):
            return amount // 2
        return max(0, amount - F.fixed(c, None, how))

    def _offer_reaction(self, reactor: Combatant, trigger: str, other: Combatant | None, text: str,
                        wanted=None) -> dict | None:
        """If `reactor` has a reaction for this trigger, ask (player) or decide (computer), and use it.
        Returns what it did: {"ac": extra AC right now, "reduce": how to cut the damage, "disadvantage": bool}."""
        opts = self.reaction_options(reactor, trigger)
        if not opts:
            return None
        if reactor.team == PLAYER and self.ask_reaction is not None:
            title = opts[0]["label"].split(" ", 1)[1] if len(opts) == 1 else "Reaction"
            pick = self.ask_reaction(reactor, title, text, [o["label"] for o in opts])
            if pick is None:
                return None
            choice = opts[max(0, min(len(opts) - 1, int(pick)))]
        else:
            choice = wanted(opts) if wanted else opts[0]
            if choice is None:
                return None
        return self._use_reaction(reactor, choice, other)

    def _use_reaction(self, c: Combatant, choice: dict, other: Combatant | None) -> dict:
        c.reaction_used = True
        result = {"ac": 0, "reduce": None, "disadvantage": False, "counter": None}
        if choice["kind"] == "feature":
            f = choice["feature"]
            self._pay(c, f)
            if f.per_rest:
                f.uses_left -= 1
            if f.recharge:
                f.ready = False
            if f.uses == "Once per turn":
                f.used_this_turn = True
            self.say("quest", f"{c.name} reacts: {f.name}!")
            lasting = any(e.kind in F.LASTING for e in f.effects)
            if lasting and f.duration != "Instant":
                f.rounds_left = F.ROUNDS.get(f.duration, 1) or 1
                self.refresh_stats(c)
            else:
                result["ac"] = self._reaction_ac(c, choice)
            for e in f.effects:
                if e.kind == "Reduce damage":
                    result["reduce"] = e.amount or e.detail or "half"
                elif e.kind == "Impose disadvantage":
                    result["disadvantage"] = True
                elif e.kind == "Heal self":
                    self.heal(c, F.amount(c, f, e.amount or "1", self.rng)[0])
                elif e.kind == "Temporary hit points":
                    c.temp_hp = max(c.temp_hp, F.amount(c, f, e.amount or "1", self.rng)[0])
                elif e.kind == "Note" and (e.detail or e.amount):
                    self.say("narration", e.detail or e.amount)
            spell = self.feature_spell(c, f)
            if spell is not None and other is not None and other.active:
                if self.distance(c, other) <= max(1, spell.range):
                    tx, ty = other.center()
                    self._spell_effect(c, spell, other, (int(tx), int(ty)), emit="combat.feature_damage")
            self._emit("combat.reaction", combatant=c, kind=f.name, target=other)
        else:
            s, slot = choice["spell"], choice["slot"]
            if s.level > 0:
                if c.is_monster and not c.slots_max:
                    c.once_per_fight.add(s.id)
                elif self.uses_mana(c):
                    c.mana -= self.mana_cost(slot)
                else:
                    c.slots[slot] = c.slots.get(slot, 0) - 1
            self.say("quest", f"{c.name} casts {s.name} as a reaction!")
            if s.reaction_trigger == COUNTER:
                result["counter"] = slot
            elif s.effect == "Effect blocks":
                if s.buff_target in ("Self", "One ally", "Allies in the area"):
                    self._grant(c, s, c)
                elif other is not None:
                    self._grant(c, s, other)
            elif other is not None and other.active:
                tx, ty = other.center()
                self._spell_effect(c, s, other, (int(tx), int(ty)))
            self._emit("combat.reaction", combatant=c, kind=s.name, target=other)
        return result

    # ==================================================================
    # Features
    # ==================================================================
    def _ally_next_to(self, c: Combatant, target: Combatant | None) -> bool:
        if target is None:
            return False
        return any(o is not c and o.active and not o.hostile_to(c) and self.distance(o, target) <= 1
                   for o in self.combatants)

    def _condition(self, c: Combatant, cond: str, attack: Attack | None, target: Combatant | None,
                   mode: str | None) -> bool:
        if not cond or cond == "Always":
            return True
        if cond == "Below half hit points":
            return c.hp < c.max_hp / 2
        if attack is None:
            return False
        if cond == "Melee attacks":
            return not attack.ranged
        if cond == "Ranged attacks":
            return attack.ranged
        if cond == "Finesse or ranged attacks":
            return attack.finesse or attack.ranged
        if cond == "Strength attacks":
            return not attack.ranged and attack.stat == self.rules.get("melee_stat", "str")
        if cond == "Ally next to target":
            return self._ally_next_to(c, target)
        sneaky = mode != "disadvantage" and (mode == "advantage" or self._ally_next_to(c, target))
        if cond == "Advantage or ally next to target":
            return sneaky
        if cond == "Finesse or ranged, with advantage or ally next to target":
            return (attack.finesse or attack.ranged) and sneaky
        return False

    def requirements_met(self, c: Combatant, f) -> bool:
        for r in f.requires:
            if r == "Wearing no armor" and c.armor_worn:
                return False
            if r == "Not in heavy armor" and c.armor_worn == "Heavy":
                return False
            if r == "No shield" and c.has_shield:
                return False
            if r == "Holding a melee weapon" and not any(not a.ranged and a.item_id for a in c.attacks):
                return False
        return True

    def effects(self, c: Combatant, kind: str, attack: Attack | None = None, target: Combatant | None = None,
                mode: str | None = None) -> list:
        """(feature, effect) pairs of this kind that apply to c right now."""
        out = []
        for f in c.features:
            if not f.is_on or not self.requirements_met(c, f):
                continue
            for e in f.effects:
                if e.kind == kind and self._condition(c, e.only_when, attack, target, mode):
                    out.append((f, e))
        # auras: allies' features that reach this far (amounts worked out for the one who has the aura)
        for owner, f in self._auras_near(c):
            for e in f.effects:
                if e.kind == kind and e.kind in F.LASTING and self._condition(c, e.only_when, attack, target, mode):
                    fixed_amount = e.amount
                    if e.amount and not dice.is_valid(F._substitute(e.amount, F.variables(owner, f)).replace(" ", "")):
                        fixed_amount = str(F.fixed(owner, f, e.amount))
                    elif e.amount:
                        fixed_amount = F._substitute(e.amount, F.variables(owner, f)).replace(" ", "")
                    out.append((f, F.Effect(e.kind, fixed_amount, e.detail, e.only_when)))
        return out

    def _auras_near(self, c: Combatant) -> list:
        """(owner, feature) for allies' aura features that reach c."""
        out = []
        for o in self.combatants:
            if o is c or not o.active or o.hostile_to(c) or o.hp <= 0 or not CND.can_act(o):
                continue
            for f in o.features:
                if f.aura and f.is_on and self.requirements_met(o, f) and self.distance(o, c) <= f.aura:
                    out.append((o, f))
        return out

    def refresh_stats(self, c: Combatant) -> None:
        """Armor, speed, resistances, immunities, vulnerabilities, condition immunities, spell attack
        and DC, darkvision and (exhaustion) hit point maximum, recomputed from the base values,
        features (their own and allies' auras) and conditions."""
        if c.base_spell_attack is None:
            c.base_spell_attack = c.spell_attack
        if c.base_spell_dc is None:
            c.base_spell_dc = c.spell_dc
        if c.base_darkvision is None:
            c.base_darkvision = c.darkvision
        if CND.exhaustion(c) >= 4:
            c.max_hp = max(1, c.base_max_hp // 2)
            c.hp = min(c.hp, c.max_hp)
        elif c.max_hp != c.base_max_hp and c.base_max_hp:
            c.max_hp = c.base_max_hp
        if not c.features and not self._auras_near(c):
            return
        ac = c.base_ac
        for f, e in self.effects(c, "Armor formula"):
            ac = max(ac, F.fixed(c, f, e.detail or e.amount or "10") + (c.shield_ac if c.has_shield else 0))
        ac += sum(F.fixed(c, f, e.amount) for f, e in self.effects(c, "Bonus to AC"))
        c.ac = ac
        feet = sum(F.fixed(c, f, e.amount or e.detail) for f, e in self.effects(c, "Extra speed"))
        c.speed = max(1, c.base_speed + feet // 5)
        resist = set(c.base_resist)
        for _f, e in self.effects(c, "Resistance"):
            resist |= F.damage_types(e.detail or e.amount)
        c.resist = resist
        immune = set(c.base_immune)
        for _f, e in self.effects(c, "Damage immunity"):
            immune |= F.damage_types(e.detail or e.amount)
        c.immune = immune
        vulnerable = set(c.base_vulnerable)
        for _f, e in self.effects(c, "Vulnerability"):
            vulnerable |= F.damage_types(e.detail or e.amount)
        c.vulnerable = vulnerable
        c.condition_immune = set(c.base_condition_immune) | {
            (e.detail or e.amount).strip().title() for _f, e in self.effects(c, "Condition immunity")
            if (e.detail or e.amount)}
        bonus = sum(F.fixed(c, f, e.amount or "1") for f, e in self.effects(c, "Spell attack and DC bonus"))
        c.spell_attack = c.base_spell_attack + bonus
        c.spell_dc = c.base_spell_dc + bonus
        seen = [F.fixed(c, f, e.amount or e.detail or "60") // 5 for f, e in self.effects(c, "Darkvision")]
        c.darkvision = max([c.base_darkvision or 0] + seen)

    def _tick_features(self, c: Combatant) -> None:
        for o in self.combatants:
            for f in o.features:
                f.used_this_turn = False
        for f in c.features:
            if f.recharge and not f.ready:
                roll = self.rng.randint(1, 6)
                if roll >= f.recharge:
                    f.ready = True
                    self.say("system", f"{c.name}'s {f.name} recharges! (d6: {roll})")
            if f.rounds_left > 0:
                if f.duration == "Until your next turn":
                    f.rounds_left = 0
                elif f.duration not in ("Until end of your turn", "Instant"):
                    f.rounds_left -= 1
                if f.rounds_left == 0:
                    self.say("system", f"{c.name}'s {f.name} ends.")
        c.features = [f for f in c.features if not (f.activation == "Granted" and f.rounds_left == 0)]
        self.refresh_stats(c)

    def feature_options(self, c: Combatant, timing: str = "Action") -> list:
        """Features c can use right now with that kind of action (Action, Bonus action, Free)."""
        if (timing == "Action" and c.action_used) or (timing == "Bonus action" and c.bonus_used):
            return []
        if not CND.can_act(c):
            return []
        out = []
        for f in c.features:
            if f.activation != timing or not f.available() or not self.requirements_met(c, f):
                continue
            if not self.can_pay(c, f):
                continue
            kinds = {e.kind for e in f.effects}
            if kinds == {"Extra action"} and not c.action_done():
                continue                      # Action Surge only makes sense once your action is spent
            if kinds and kinds <= {"Regain spell slots"} and all(c.slots.get(l, 0) >= n
                                                                for l, n in c.slots_max.items()):
                continue
            out.append(f)
        return out

    def feature_cost(self, c: Combatant, f) -> int:
        default = "1" if f.uses in ("Costs resource", "Item charges") else "0"
        return max(0, F.fixed(c, f, getattr(f, "cost", "") or default))

    def can_pay(self, c: Combatant, f) -> bool:
        """Enough Mana/Stamina, resource points or item charges to use it."""
        if f.uses == "Costs Mana/Stamina":
            return c.mana >= self.feature_cost(c, f)
        if f.uses == "Costs resource":
            pool = c.resources.get(f.resource)
            return pool is not None and pool["cur"] >= self.feature_cost(c, f)
        if f.uses == "Item charges":
            return c.charges.get(f.source_item, 0) >= self.feature_cost(c, f)
        return True

    def _pay(self, c: Combatant, f) -> None:
        cost = self.feature_cost(c, f)
        if f.uses == "Costs Mana/Stamina":
            c.mana = max(0, c.mana - cost)
        elif f.uses == "Costs resource" and f.resource in c.resources:
            c.resources[f.resource]["cur"] = max(0, c.resources[f.resource]["cur"] - cost)
        elif f.uses == "Item charges" and f.source_item:
            c.charges[f.source_item] = max(0, c.charges.get(f.source_item, 0) - cost)

    def feature_spell(self, c: Combatant, f) -> Spell | None:
        """A damaging feature dressed up as a spell, so targeting and areas work the same way."""
        if getattr(f, "spell", None) is not None:
            return f.spell
        d = f.damage
        if not d:
            return None
        effect = {"Melee attack": "Spell attack (melee)", "Ranged attack": "Spell attack (ranged)"}.get(
            d["target"], "Saving throw")
        expr = F._substitute(d["dice"], F.variables(c, f)).replace(" ", "")
        if not dice.is_valid(expr):
            expr = "1d6" if effect.startswith("Spell attack") else ""
        return Spell(id=f.id, name=f.name, level=0, effect=effect, damage=expr, cantrip_scaling="None",
                     damage_type=d["type"], save_stat=d["save_stat"], on_save=d["on_save"], range=d["range"],
                     area=d["area"], area_size=d["area_size"], casting_time=f.activation, description=f.description,
                     dc=d["dc"], attack_bonus=d["attack_bonus"] if effect.startswith("Spell attack") else None,
                     condition=d.get("condition", ""), condition_rounds=d.get("condition_rounds", 0),
                     condition_save_each_turn=d.get("condition_save_each_turn", True),
                     only_foes=d.get("only_foes", False))

    def feature_targets(self, c: Combatant, f) -> list[Combatant]:
        spell = self.feature_spell(c, f)
        return self.spell_targets(c, spell) if spell and not spell.targets_cell else []

    def feature_needs_aim(self, c: Combatant, f) -> bool:
        """Does using it ask for a target or a square?"""
        spell = self.feature_spell(c, f)
        return spell is not None and not spell.self_only

    def use_feature(self, c: Combatant, f, option: str | None = None, target: Combatant | None = None,
                    cell: tuple[int, int] | None = None) -> bool:
        if f not in self.feature_options(c, f.activation):
            return False
        spell = self.feature_spell(c, f)
        if spell is not None:
            if spell.self_only and target is None and not spell.targets_cell:
                target = c
            if not self._aim_ok(c, spell, target, cell):
                return False
            if spell.targets_area and cell is None:
                tx, ty = target.center()
                cell = (int(tx), int(ty))
        if f.activation == "Action":
            c.action_used = True
            c.attacks_left = 0
        elif f.activation == "Bonus action":
            c.bonus_used = True
        if f.per_rest:
            f.uses_left -= 1
        if f.recharge:
            f.ready = False
        if f.uses == "Once per turn":
            f.used_this_turn = True
        self._pay(c, f)
        picked = option if option in f.options() else (f.options() or [""])[0]
        self.say("quest", f"{c.name} uses {f.name}{': ' + picked if picked else ''}!")
        if any(e.kind in F.LASTING for e in f.effects):
            f.rounds_left = F.ROUNDS.get(f.duration, 1) or 1
        for e in f.effects:
            if e.kind == "Heal self":
                n, d = F.amount(c, f, e.amount or "1", self.rng)
                self.heal(c, n)
            elif e.kind == "Temporary hit points":
                n, d = F.amount(c, f, e.amount or "1", self.rng)
                if n > c.temp_hp:
                    c.temp_hp = n
                self.say("heal", f"{c.name} gains {n} temporary hit points. ({c.hp_text()} HP)")
            elif e.kind == "Extra action":
                c.action_used = False
                c.attacks_left = 0
                self.say("narration", f"{c.name} can take another action this turn.")
            elif e.kind == "Dash, Disengage or Dodge":
                if picked == "Dash":
                    c.dashed = True
                    self.say("narration", f"{c.name} dashes, doubling their movement.")
                elif picked == "Disengage":
                    c.disengaged = True
                    self.say("narration", f"{c.name} disengages and can move without provoking attacks.")
                else:
                    c.dodging = True
                    self.say("narration", f"{c.name} dodges. Attacks against them have disadvantage.")
            elif e.kind == "Restore resource":
                name = (e.detail or "").strip()
                pool = c.resources.get(name)
                if pool is not None:
                    n = F.fixed(c, f, e.amount) if e.amount else pool["max"]
                    pool["cur"] = min(pool["max"], pool["cur"] + max(0, n))
                    self.say("narration", f"{c.name} recovers {name} ({pool['cur']}/{pool['max']}).")
            elif e.kind == "Regain spell slots" and self.uses_mana(c):
                gain = min(c.mana_max - c.mana, max(1, F.fixed(c, f, e.amount or "1")) * self.mana_cost(1))
                c.mana += max(0, gain)
                self.say("narration", f"{c.name} recovers {gain} {c.mana_name}.")
            elif e.kind == "Regain spell slots":
                budget = max(1, F.fixed(c, f, e.amount or "1"))
                got = []
                for lvl in sorted(c.slots_max, reverse=True):
                    while lvl <= budget and c.slots.get(lvl, 0) < c.slots_max[lvl]:
                        c.slots[lvl] = c.slots.get(lvl, 0) + 1
                        budget -= lvl
                        got.append(str(lvl))
                self.say("narration", f"{c.name} recovers spell slots: level {', '.join(got)}." if got
                         else f"{c.name} has no spell slots to recover.")
            elif e.kind == "Note":
                text = e.detail or e.amount or f.description
                if text:
                    self.say("narration", text)
        if f.rounds_left and not f.passive:
            lasting = ", ".join(sorted({e.kind.lower() for e in f.effects if e.kind in F.LASTING}))
            span = {"Until you rest": "for the rest of the fight", "1 minute": "for 1 minute",
                    "10 minutes": "for 10 minutes", "Until your next turn": "until their next turn"}.get(
                f.duration, "until the end of their turn")
            self.say("system", f"{f.name} is active {span}: {lasting}.")
        if spell is not None:
            if f.spell is not None and spell.concentration:
                CND.end_concentration(self, c, "using another concentration effect")
            self._spell_effect(c, spell, target, cell, emit="combat.cast" if f.spell is not None
                               else "combat.feature_damage")
        if f.mechanic:
            self._emit("feature.mechanic", combatant=c, feature=f, mechanic=f.mechanic)
        self.refresh_stats(c)
        self._emit("combat.feature", combatant=c, feature=f)
        return True

    # ==================================================================
    # Other actions
    # ==================================================================
    def usable_items(self, c: Combatant, timing: str = "Action") -> list[int]:
        """Indexes into c.items usable right now with that kind of action."""
        if (timing == "Bonus action" and c.bonus_used) or (timing == "Action" and c.action_used):
            return []
        if not CND.can_act(c):
            return []
        return [i for i, it in enumerate(c.items) if it.count > 0 and (it.timing or "Action") == timing]

    def use_item(self, c: Combatant, index: int, target: Combatant | None = None) -> bool:
        if index >= len(c.items):
            return False
        item = c.items[index]
        if index not in self.usable_items(c, item.timing or "Action"):
            return False
        target = target or c
        if item.timing == "Bonus action":
            c.bonus_used = True
        else:
            c.action_used = True
            c.attacks_left = 0
        item.count -= 1
        self.say("narration", f"{c.name} uses {item.name}.")
        if item.effect == "Heal":
            self.heal(target, dice.roll(item.dice, self.rng).total)
        elif item.effect == "Damage" and target is not c:
            self.damage(target, dice.roll(item.dice, self.rng).total, "", source=c)
        self._emit("combat.item", combatant=c, item=item)
        return True

    # ------------------------------------------------------------------
    # Grapple, shove, help, hide
    # ------------------------------------------------------------------
    def _skill(self, c: Combatant, skill: str, stat: str) -> int:
        bonus = c.mod(stat)
        if skill in c.skill_profs:
            bonus += c.prof * (2 if skill in c.expertise else 1)
        elif c.is_monster and stat in c.saves:
            bonus += c.prof
        return bonus

    def _contest(self, a: Combatant, b: Combatant, what: str) -> bool:
        """Attacker's Strength (Athletics) against the defender's best of Athletics or Acrobatics."""
        ab = self._skill(a, "athletics", "str")
        ra, da = dice.d20(self.rng, "disadvantage" if CND.check_disadvantage(a) else "normal")
        bb = max(self._skill(b, "athletics", "str"), self._skill(b, "acrobatics", "dex"))
        rb, db = dice.d20(self.rng, "disadvantage" if CND.check_disadvantage(b) else "normal")
        ok = ra + ab > rb + bb
        self.say("roll", f"{a.name} tries to {what} {b.name}: {da} {'+' if ab >= 0 else '-'} {abs(ab)} = {ra + ab} vs "
                         f"{db} {'+' if bb >= 0 else '-'} {abs(bb)} = {rb + bb}  ·  {'Success' if ok else 'Failure'}")
        return ok

    def _attack_slot(self, c: Combatant) -> bool:
        """Grapple and shove take the place of one attack (so Extra Attack still works)."""
        if not self.can_attack(c):
            return False
        if not c.action_used:
            c.action_used = True
            c.attacks_left = max(1, c.attacks_per_action)
        c.attacks_left -= 1
        return True

    def grapple_targets(self, c: Combatant) -> list[Combatant]:
        return [o for o in self.enemies_of(c) if self.distance(c, o) <= 1 and o.size <= c.size + 1
                and not CND.has(o, "Grappled")]

    def grapple(self, c: Combatant, target: Combatant) -> bool:
        if target not in self.grapple_targets(c) or not CND.can_act(c) or not self._attack_slot(c):
            return False
        if "Grappled" in target.condition_immune:
            self.say("system", f"{target.name} can't be grappled.")
            return True
        if self._contest(c, target, "grapple"):
            if c.grappling:
                held = next((o for o in self.combatants if o.id == c.grappling), None)
                if held is not None:
                    self._release(c, held)
            CND.apply(self, target, "Grappled", -1, c)
            c.grappling = target.id
        return True

    def _release(self, holder: Combatant, held: Combatant, text: str = "") -> None:
        rec = held.conditions.get("Grappled")
        if rec and rec.get("source") in (holder.id, None, ""):
            CND.remove(self, held, "Grappled")
        holder.grappling = ""
        if text:
            self.say("narration", text)

    def escape(self, c: Combatant) -> bool:
        """Use the action to break free of a grapple."""
        rec = c.conditions.get("Grappled")
        if rec is None or c.action_used or not CND.can_act(c):
            return False
        holder = next((o for o in self.combatants if o.id == rec.get("source")), None)
        c.action_used = True
        c.attacks_left = 0
        if holder is None or not holder.active:
            CND.remove(self, c, "Grappled")
            return True
        if self._contest(c, holder, "break free of"):
            self._release(holder, c, f"{c.name} breaks free!")
        return True

    def shove(self, c: Combatant, target: Combatant, push: bool = False) -> bool:
        """Knock a creature prone, or push it 5 feet away."""
        if target not in self.enemies_of(c) or self.distance(c, target) > 1 or target.size > c.size + 1 \
                or not CND.can_act(c) or not self._attack_slot(c):
            return False
        if self._contest(c, target, "shove"):
            if push:
                dx = (target.x > c.x) - (target.x < c.x)
                dy = (target.y > c.y) - (target.y < c.y)
                nx, ny = target.x + dx, target.y + dy
                occ = self.occupied(ignore=target)
                if self.map.fits(nx, ny, target.size) and not any(p in occ for p in target.cells(nx, ny)):
                    target.x, target.y = nx, ny
                    self._emit("combat.moved", combatant=target, x=nx, y=ny)
                    self.say("narration", f"{target.name} is pushed back.")
                    if target.grappling:
                        held = next((o for o in self.combatants if o.id == target.grappling), None)
                        if held is not None and self.distance(target, held) > 1:
                            self._release(target, held)
                else:
                    self.say("narration", f"{target.name} has nowhere to go.")
            else:
                CND.apply(self, target, "Prone", -1, c)
        return True

    def help_targets(self, c: Combatant) -> list[Combatant]:
        return [o for o in self.allies_of(c) if self.distance(c, o) <= 1 and not o.helped and o.hp > 0]

    def help(self, c: Combatant, ally: Combatant) -> bool:
        """The Help action: the ally's next attack roll has advantage."""
        if c.action_used or not CND.can_act(c) or ally not in self.help_targets(c):
            return False
        c.action_used = True
        c.attacks_left = 0
        ally.helped = True
        self.say("narration", f"{c.name} helps {ally.name}: their next attack has advantage.")
        return True

    def can_hide(self, c: Combatant) -> bool:
        """You can only hide where no enemy can see you (darkness, out of sight behind walls)."""
        if c.action_used or c.hidden or not CND.can_act(c):
            return False
        return not any(self.can_see(o, c) and (self.distance(o, c) <= 1 or self.line_of_sight(o, c))
                       for o in self.enemies_of(c) if CND.can_act(o))

    def hide(self, c: Combatant) -> bool:
        if not self.can_hide(c):
            return False
        c.action_used = True
        c.attacks_left = 0
        bonus = self._skill(c, "stealth", "dex")
        roll, detail = dice.d20(self.rng, "disadvantage" if c.stealth_dis else "normal")
        c.hidden, c.hidden_score = True, roll + bonus
        self.say("roll", f"{c.name} hides: Stealth {detail} {'+' if bonus >= 0 else '-'} {abs(bonus)} = {roll + bonus}")
        return True

    def _search(self, c: Combatant) -> None:
        """At the start of its turn, a creature looks for hidden enemies nearby (Perception)."""
        for o in self.enemies_of(c):
            if not o.hidden or self.distance(c, o) > 8:
                continue
            bonus = self._skill(c, "perception", "wis")
            roll, detail = dice.d20(self.rng)
            if roll + bonus >= o.hidden_score:
                o.hidden = False
                self.say("roll", f"{c.name} spots {o.name}! (Perception {roll + bonus} vs {o.hidden_score})")

    def dodge(self, c: Combatant) -> bool:
        if c.action_used or not CND.can_act(c):
            return False
        c.action_used = True
        c.dodging = True
        self.say("narration", f"{c.name} takes the Dodge action. Attacks against them have disadvantage.")
        return True

    def dash(self, c: Combatant) -> bool:
        if c.action_used or not CND.can_act(c):
            return False
        c.action_used = True
        c.dashed = True
        self.say("narration", f"{c.name} dashes, doubling their movement.")
        return True

    def disengage(self, c: Combatant) -> bool:
        if c.action_used or not CND.can_act(c):
            return False
        c.action_used = True
        c.disengaged = True
        self.say("narration", f"{c.name} disengages and can move without provoking attacks.")
        return True

    def at_edge(self, c: Combatant) -> bool:
        return c.x <= 0 or c.y <= 0 or c.x + c.size >= self.map.w or c.y + c.size >= self.map.h

    def flee(self, c: Combatant) -> bool:
        if c.action_used or not self.at_edge(c) or not CND.can_act(c) or c.movement_left() <= 0:
            return False
        c.action_used = True
        c.fled = True
        self.say("narration", f"{c.name} flees the battle!")
        self._emit("combat.fled", combatant=c)
        self._check_outcome()
        return True

    # ==================================================================
    # Enemy AI
    # ==================================================================
    def bonus_options(self, c: Combatant) -> bool:
        """Is there anything c could still do with its bonus action?"""
        if c.bonus_used:
            return False
        return bool(self.castable(c, "Bonus action") or self.usable_items(c, "Bonus action")
                    or self.feature_options(c, "Bonus action") or self.can_offhand(c))

    def turn_spent(self, c: Combatant) -> bool:
        """Out of actions and bonus actions (movement may be left)."""
        surge = any(e.kind == "Extra action" for f in self.feature_options(c, "Free") for e in f.effects)
        return c.action_done() and not surge and not self.bonus_options(c)

    @staticmethod
    def _worth_hitting(spell: Spell, targets: list, foes: list) -> list:
        """Standing foes only, and not ones a condition-only spell has already caught."""
        out = [t for t in targets if t in foes and not (spell.hp_limit and t.hp > spell.hp_limit)]
        if spell.condition and not spell.damage:
            out = [t for t in out if not CND.has(t, spell.condition)]
        return out

    def ai_turn(self, c: Combatant) -> Iterator[str]:
        """Play c's turn one step at a time, yielding after each step so the screen
        can redraw in between."""
        foes = [f for f in self.enemies_of(c) if f.hp > 0 and not f.hidden]
        if not foes or self.outcome:
            return
        if not CND.can_act(c):
            self.say("narration", f"{c.name} can't act ({CND.summary(c)}).")
            yield "wait"
            return
        hurt = c.hp < c.max_hp * 0.4

        # Healing features (Second Wind) when badly hurt.
        if c.hp < c.max_hp * 0.5:
            for timing in ("Bonus action", "Free"):
                for f in self.feature_options(c, timing):
                    if any(e.kind in ("Heal self", "Temporary hit points") for e in f.effects) and not f.damage:
                        self.use_feature(c, f)
                        yield "feature"
                        break

        if c.behavior == "Cowardly" and hurt:
            if self.at_edge(c):
                self.flee(c)
                yield "flee"
                return
            dest = self._spot_toward_edge(c)
            if dest:
                if any(self.distance(c, f) <= 1 for f in foes):
                    escape = next((f for f in self.feature_options(c, "Bonus action") if "Disengage" in f.options()),
                                  None)
                    if escape:
                        self.use_feature(c, escape, "Disengage")
                        yield "feature"
                    elif not c.action_used:
                        self.disengage(c)
                self.move(c, dest)
                yield "move"
            if self.at_edge(c) and not c.action_used:
                self.flee(c)
                yield "flee"
            return

        if c.behavior in ("Defensive", "Guardian") and all(self.distance(c, f) > c.speed + 1 for f in foes):
            self.say("narration", f"{c.name} holds its ground.")
            yield "wait"
            return

        for timing in ("Action", "Bonus action"):
            for spell, slot in self.castable(c, timing):
                if spell.effect == "Healing":
                    patients = [o for o in self.spell_targets(c, spell) if o.hp < o.max_hp * 0.4]
                    if patients:
                        self.cast(c, spell, target=min(patients, key=lambda o: o.hp / o.max_hp), slot=slot)
                        yield "cast"
                        if timing == "Action":
                            return

        target = min(foes, key=lambda f: (self.distance(c, f), f.hp))

        # Damaging abilities first (a breath weapon is the best thing a dragon can do).
        for f in self.feature_options(c, "Action"):
            spell = self.feature_spell(c, f)
            if spell is None or spell.helps_allies or spell.effect in ("Teleport", "Utility"):
                continue
            if spell.targets_area:
                best = self._best_area_cell(c, spell, foes)
                if best and best[1] >= 1 and best[2] == 0:
                    self.use_feature(c, f, cell=best[0])
                    yield "cast"
                    return
            else:
                tgts = self._worth_hitting(spell, self.spell_targets(c, spell), foes)
                if tgts:
                    self.use_feature(c, f, target=min(tgts, key=lambda o: o.hp))
                    yield "cast"
                    return

        for spell, slot in sorted(self.castable(c), key=lambda s: -s[0].level):
            if spell.effect not in ("Saving throw", "Automatic hit", "Spell attack (ranged)", "Spell attack (melee)"):
                continue
            if spell.targets_area:
                best = self._best_area_cell(c, spell, foes)
                if best and best[1] >= (2 if spell.level == 0 else 1) and best[2] == 0:
                    self.cast(c, spell, cell=best[0], slot=slot)
                    yield "cast"
                    return
            elif spell.level > 0 or self.distance(c, target) > 1 or not any(not a.ranged for a in c.attacks):
                tgts = self._worth_hitting(spell, self.spell_targets(c, spell), foes)
                if tgts:
                    self.cast(c, spell, target=min(tgts, key=lambda t: t.hp), slot=slot)
                    yield "cast"
                    return

        prefer_ranged = c.behavior == "Ranged" or bool(c.attacks and all(a.ranged for a in c.attacks))
        attack = self._best_attack(c, target, prefer_ranged)
        if attack is None:
            dest = self._approach(c, target, None)
            if dest and dest != (c.x, c.y):
                self.move(c, dest)
                yield "move"
            return
        if target not in self.targets_for(c, attack):
            dest = self._approach(c, target, attack)
            if dest and dest != (c.x, c.y):
                self.move(c, dest)
                yield "move"
                if not c.active or self.outcome:
                    return

        # Switch on fighting features (Rage) when about to swing.
        if not attack.ranged and self.targets_for(c, attack):
            for timing in ("Bonus action", "Free"):
                for f in self.feature_options(c, timing):
                    kinds = {e.kind for e in f.effects}
                    if f.damage or "Attacks against you have advantage" in kinds or not (kinds & F.LASTING):
                        continue
                    self.use_feature(c, f)
                    yield "feature"
                    break

        for _round in range(2):               # a second round after an extra action (Action Surge)
            yield from self._ai_attacks(c, attack, target)
            if not c.active or self.outcome:
                return
            surge = next((f for f in self.feature_options(c, "Free")
                          if any(e.kind == "Extra action" for e in f.effects)), None)
            if surge is None or not any(self.targets_for(c, a) for a in c.attacks):
                break
            self.use_feature(c, surge)
            yield "feature"

        # Two-weapon fighting.
        if self.can_offhand(c):
            for atk in c.bonus_attacks:
                tgts = self.targets_for(c, atk)
                if tgts:
                    self.attack(c, atk, target if target in tgts else min(tgts, key=lambda o: o.hp))
                    yield "attack"
                    break

    def _ai_attacks(self, c: Combatant, attack: Attack, target: Combatant) -> Iterator[str]:
        while self.can_attack(c) and not self.outcome:
            tgts = self.targets_for(c, attack)
            if not tgts:
                # Maybe a different attack reaches someone.
                alt = next((a for a in c.attacks if self.targets_for(c, a)), None)
                if alt is None:
                    break
                attack = alt
                continue
            tgt = target if target in tgts else min(tgts, key=lambda f: f.hp)
            self.attack(c, attack, tgt)
            yield "attack"
            if not c.active:
                return
            alts = [a for a in c.attacks if a is not attack and tgt.active and tgt in self.targets_for(c, a)]
            if alts and c.attacks_left and self.rng.random() < 0.6:
                attack = alts[0]

    def _best_attack(self, c: Combatant, target: Combatant, prefer_ranged: bool) -> Attack | None:
        if not c.attacks:
            return None
        d = self.distance(c, target)
        melee = [a for a in c.attacks if not a.ranged]
        ranged = [a for a in c.attacks if a.ranged]

        def avg(a):
            return dice.average(a.damage) + a.to_hit

        if d <= 1 and melee and not prefer_ranged:
            return max(melee, key=avg)
        if ranged and (prefer_ranged or d > c.speed + 1 or not melee):
            return max(ranged, key=avg)
        return max(melee or ranged, key=avg)

    def _approach(self, c: Combatant, target: Combatant, attack: Attack | None) -> tuple[int, int] | None:
        """Best square to move to this turn to get within reach (or as close as possible)."""
        reach = self.reachable(c)
        want = attack.max_range() if attack else 1
        if attack and attack.ranged:
            want = attack.range or attack.max_range()
        good = [p for p in reach if self.distance(c, target, *p) <= want
                and (attack is None or not attack.ranged or self._los_from(c, p, target))]
        if good:
            if attack and attack.ranged:
                return max(good, key=lambda p: (self.distance(c, target, *p), -reach[p][0]))
            return min(good, key=lambda p: reach[p][0])
        best = None
        for gx in range(target.x - c.size, target.x + target.size + 1):
            for gy in range(target.y - c.size, target.y + target.size + 1):
                if self.distance(c, target, gx, gy) == 1 and self.map.fits(gx, gy, c.size):
                    path = self._full_path(c, (gx, gy))
                    if path and (best is None or len(path) < len(best)):
                        best = path
        if best:
            for step in reversed(best[:c.movement_left()]):
                if step in reach:
                    return step
        if reach:
            return min(reach, key=lambda p: (self.distance(c, target, *p), reach[p][0]))
        return None

    def _los_from(self, c: Combatant, pos, target: Combatant) -> bool:
        ox, oy = c.x, c.y
        c.x, c.y = pos
        ok = self.line_of_sight(c, target)
        c.x, c.y = ox, oy
        return ok

    def _best_area_cell(self, c: Combatant, spell: Spell, foes: list[Combatant]):
        best = None
        candidates = {cell for f in foes for cell in f.cells()}
        for cell in candidates:
            if self.distance_to_cell(c, *cell) > self.area_reach(c, spell):
                continue
            covered = self.area_cells(c, spell, *cell)
            hit_foes = sum(1 for f in foes if any(p in covered for p in f.cells()))
            hit_friends = 0 if spell.only_foes else sum(1 for a in self.allies_of(c)
                                                          if any(p in covered for p in a.cells()))
            if best is None or (hit_foes - 2 * hit_friends) > (best[1] - 2 * best[2]):
                best = (cell, hit_foes, hit_friends)
        return best

    def _spot_toward_edge(self, c: Combatant):
        reach = self.reachable(c)
        if not reach:
            return None
        foes = self.enemies_of(c)

        def score(p):
            edge = min(p[0], p[1], self.map.w - (p[0] + c.size), self.map.h - (p[1] + c.size))
            danger = min((self.distance(c, f, *p) for f in foes), default=99)
            return (edge, -danger)
        return min(reach, key=score)

    # ==================================================================
    # Rewards
    # ==================================================================
    def rewards(self) -> dict:
        xp = sum(c.xp for c in self.combatants if c.team == ENEMY and not c.alive)
        gold = 0
        items: dict[str, int] = {}
        for c in self.combatants:
            if c.team != ENEMY or c.alive:
                continue
            if c.gold and dice.is_valid(c.gold):
                gold += max(0, dice.roll(c.gold, self.rng).total)
            for row in c.loot:
                if row.get("item") and self.rng.random() * 100 < float(row.get("chance", 100)):
                    q = row.get("quantity") or "1"
                    n = dice.roll(q, self.rng).total if dice.is_valid(q) else 1
                    items[row["item"]] = items.get(row["item"], 0) + max(1, n)
        return {"xp": xp, "gold": gold, "items": items}


def _facing(dx: float, dy: float, current: int) -> int:
    if abs(dx) < 1e-6 and abs(dy) < 1e-6:
        return current
    if abs(dy) >= abs(dx):
        return 0 if dy > 0 else 2
    return 3 if dx > 0 else 1
