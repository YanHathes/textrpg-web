"""The calendar: seasons, the moon, the light of the day, and how warm it is.

Everything here is worked out from the game clock (GameState.minutes) and the world's rules, so nothing
needs saving.

    season_days      world rule: days in each season (default 30, so a 120-day year), starting in spring
    season_start     world rule: the season day 1 falls in (Spring, Summer, Autumn, Winter)

The day's light, blended by the minute (game/combat/lighting.py turns it into bright / dim / dark):

    04:00-07:00  dawn    warm pink, fading to clear
    07:00-18:00  day     no tint
    18:00-22:00  dusk    orange, deepening
    22:00-04:00  night   deep blue-black

Later steps read the season: foraging and regrowth (step 7), festival dates (13), farm output (14),
cold and heat (16).
"""
from __future__ import annotations

import math

SEASONS = ["Spring", "Summer", "Autumn", "Winter"]
DAY = 24 * 60
MOON_DAYS = 28
MOON_PHASES = ["New moon", "Waxing crescent", "First quarter", "Waxing gibbous", "Full moon", "Waning gibbous",
               "Last quarter", "Waning crescent"]

# land -> (average temperature in spring, summer, autumn, winter), degrees Fahrenheit, at midday
CLIMATE = {
    "Plains": (58, 78, 56, 32), "Forest": (55, 74, 52, 30), "Hills": (52, 72, 50, 28), "Taiga": (40, 62, 36, 5),
    "Mountains": (38, 56, 34, 12), "Tundra": (25, 45, 22, -10), "Arctic": (5, 30, 2, -25),
    "Jungle": (82, 88, 82, 78), "Swamp": (66, 84, 64, 48), "Desert": (82, 104, 80, 60),
    "Badlands": (70, 92, 68, 45), "Savanna": (80, 90, 80, 72), "Coast": (56, 72, 58, 42),
    "Lake": (55, 72, 55, 34), "Ocean": (58, 70, 60, 48), "Urban": (58, 76, 56, 34),
}
COLD_LANDS = {"Taiga", "Tundra", "Arctic", "Mountains"}
TEMPERATE = {"Plains", "Forest", "Hills", "Coast", "Lake", "Urban", "Swamp"}
WARM_LANDS = {"Jungle", "Desert", "Badlands", "Savanna"}


def _rules(world) -> dict:
    return getattr(world, "rules", None) or {} if world is not None else {}


def season_days(world=None) -> int:
    return max(1, int(_rules(world).get("season_days", 30) or 30))


def year_days(world=None) -> int:
    return 4 * season_days(world)


def day_index(minutes: int) -> int:
    """Days since the game began (0 on day 1)."""
    return int(minutes) // DAY


def season(world, minutes: int) -> str:
    start = _rules(world).get("season_start") or "Spring"
    first = SEASONS.index(start) if start in SEASONS else 0
    return SEASONS[(day_index(minutes) // season_days(world) + first) % 4]


def season_progress(world, minutes: int) -> float:
    """How far through its season the day is (0 to 1)."""
    n = season_days(world)
    return ((int(minutes) / DAY) % n) / n


def day_of_year(world, minutes: int) -> int:
    return day_index(minutes) % year_days(world) + 1


def date_text(world, minutes: int) -> str:
    n = season_days(world)
    return f"{season(world, minutes)}, day {day_index(minutes) % n + 1} of {n}"


# ----------------------------------------------------------------------------------------------------
# The moon
# ----------------------------------------------------------------------------------------------------
def moon_phase(minutes: int) -> float:
    """0 new, 0.5 full, back to 1."""
    return ((int(minutes) / DAY) % MOON_DAYS) / MOON_DAYS


def moon_name(minutes: int) -> str:
    return MOON_PHASES[int(moon_phase(minutes) * 8 + 0.5) % 8]


def moonlight(minutes: int) -> float:
    """How much of the moon is lit (0 new to 1 full)."""
    return 0.5 - 0.5 * math.cos(moon_phase(minutes) * 2 * math.pi)


# ----------------------------------------------------------------------------------------------------
# The light of the day
# ----------------------------------------------------------------------------------------------------
DAWN, DAY_START, DUSK, NIGHT = 4 * 60, 7 * 60, 18 * 60, 22 * 60


def phase(minutes: int) -> str:
    m = int(minutes) % DAY
    if DAWN <= m < DAY_START:
        return "Dawn"
    if DAY_START <= m < DUSK:
        return "Day"
    if DUSK <= m < NIGHT:
        return "Dusk"
    return "Night"


def daylight(minutes: int) -> float:
    """1 in full day, 0 in the dead of night, blended smoothly by the minute through dawn and dusk."""
    m = int(minutes) % DAY
    if DAY_START <= m < DUSK:
        return 1.0
    if DAWN <= m < DAY_START:
        t = (m - DAWN) / (DAY_START - DAWN)
        return 0.5 - 0.5 * math.cos(t * math.pi)
    if DUSK <= m < NIGHT:
        t = (m - DUSK) / (NIGHT - DUSK)
        return 0.5 + 0.5 * math.cos(t * math.pi)
    return 0.0


def _mix(a, b, t: float):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(len(a)))


NIGHT_TINT = (8, 14, 40, 205)          # deep blue-black
DAWN_TINT = (236, 132, 150, 70)        # warm pink
DUSK_TINT = (232, 120, 40, 80)         # orange
CLEAR = (255, 255, 255, 0)


def sky_tint(minutes: int) -> tuple[int, int, int, int]:
    """The colour laid over the land at this minute (r, g, b, alpha), blended by the minute."""
    m = int(minutes) % DAY
    if DAY_START <= m < DUSK:
        return CLEAR
    if DAWN <= m < DAY_START:
        t = (m - DAWN) / (DAY_START - DAWN)
        if t < 0.35:                                       # night fading into pink
            c = _mix(NIGHT_TINT, DAWN_TINT, t / 0.35)
        else:                                              # pink fading to clear
            c = _mix(DAWN_TINT, (DAWN_TINT[0], DAWN_TINT[1], DAWN_TINT[2], 0), (t - 0.35) / 0.65)
        return tuple(int(v) for v in c)
    if DUSK <= m < NIGHT:
        t = (m - DUSK) / (NIGHT - DUSK)
        if t < 0.55:                                       # orange, deepening
            k = t / 0.55
            c = _mix((DUSK_TINT[0], DUSK_TINT[1], DUSK_TINT[2], 0), DUSK_TINT, min(1.0, k * 1.6))
            c = _mix(c, (200, 70, 50, 110), k)
        else:                                              # into the night
            c = _mix((200, 70, 50, 110), NIGHT_TINT, (t - 0.55) / 0.45)
        return tuple(int(v) for v in c)
    return NIGHT_TINT


# ----------------------------------------------------------------------------------------------------
# The time-skip scene (ui/timeskip.py)
# ----------------------------------------------------------------------------------------------------
def clock_text(minutes: int) -> str:
    m = int(minutes) % DAY
    return f"Day {int(minutes) // DAY + 1}   {m // 60:02d}:{m % 60:02d}"


def clock_frames(start: int, end: int, n: int = 24) -> list[str]:
    """The clock running from one time to another, in n steps (eased: quick in the middle)."""
    if end <= start:
        return [clock_text(end)]
    out = []
    for i in range(n + 1):
        k = i / n
        k = 0.5 - 0.5 * math.cos(k * math.pi)
        out.append(clock_text(int(round(start + (end - start) * k))))
    return out


def passed_text(minutes: int) -> str:
    """'8 hours pass.', '2 days and 3 hours pass.', 'Half an hour passes.'"""
    minutes = int(minutes)
    d, rest = divmod(minutes, DAY)
    h, m = divmod(rest, 60)
    if not d and not h:
        return "Half an hour passes." if 20 <= m <= 40 else f"{m} minute{'s' if m != 1 else ''} pass{'es' if m == 1 else ''}."
    bits = []
    if d:
        bits.append(f"{d} day{'s' if d != 1 else ''}")
    if h:
        bits.append(f"{h} hour{'s' if h != 1 else ''}")
    one = len(bits) == 1 and (d == 1 if d else h == 1)
    return " and ".join(bits) + (" passes." if one else " pass.")


# ----------------------------------------------------------------------------------------------------
# Warmth
# ----------------------------------------------------------------------------------------------------
def climate_of(biome: str) -> tuple:
    return CLIMATE.get(biome) or CLIMATE["Plains"]


def temperature(world, minutes: int, biome: str, weather: str = "") -> int:
    """Degrees Fahrenheit: the season's average for the land, eased between seasons, colder at night, and
    moved by the weather."""
    c = climate_of(biome)
    i = SEASONS.index(season(world, minutes))
    p = season_progress(world, minutes)
    here, nxt = c[i], c[(i + 1) % 4]
    base = here + (nxt - here) * max(0.0, p - 0.5)          # the second half of a season leans to the next
    m = int(minutes) % DAY
    swing = 18 if biome in ("Desert", "Badlands") else 10
    daily = -math.cos((m - 4 * 60) / DAY * 2 * math.pi)     # coldest about 04:00, warmest about 16:00
    t = base + swing / 2 * (daily - 1) + swing / 4           # warmest a little over the average, coldest well under
    t += {"Snow": -6, "Blizzard": -14, "Rain": -4, "Heavy rain": -5, "Storm": -6, "Overcast": -2, "Fog": -2,
          "Sea fog": -3, "Heat haze": 6, "Dust storm": 2, "Gale": -6, "Wind": -4, "Humid haze": 3}.get(weather, 0)
    return int(round(t))


__all__ = ["clock_text", "clock_frames", "passed_text", "SEASONS", "season", "season_days", "season_progress", "day_of_year", "date_text", "moon_phase",
           "moon_name", "moonlight", "phase", "daylight", "sky_tint", "temperature", "climate_of",
           "COLD_LANDS", "TEMPERATE", "WARM_LANDS"]
