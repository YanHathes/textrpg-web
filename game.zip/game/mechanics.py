"""The mechanics engine: runs the world's Mechanic rules.

Every system announces what happens on the event bus. This engine listens,
turns each event into one or more triggers ("Attack hit", "Damage taken"...),
each with the creature it happened to ("me") and the other side ("other"), and
runs every active mechanic with that trigger:

    WHEN  trigger, for whom (party members, enemies, anyone, a specific thing),
          where (anywhere, in combat, outside combat)
    IF    a formula (with names like me.hp, weapon.burn_chance, world.time),
          a chance, and how often it may run
    THEN  effects, top to bottom

In a fight, effects act on the creatures in the battle. Outside one, they act
on the party: hit points, conditions and custom values are kept with each
member until a long rest (custom values are kept for good).

A Feature's "Also run mechanic" runs that mechanic whenever the feature is used.
"""
from __future__ import annotations

import random
import re

from game import dice, formula

SUBJECTLESS = {"Combat start", "Combat end", "Location entered", "Rest", "Time passed", "New day",
               "Quest accepted", "Quest completed", "Item bought", "Item sold", "Custom event"}


class Lenient(dict):
    """Names a rule asks about that don't exist yet count as 0 (a custom value nobody has set,
    a weapon without a Burn Chance...)."""

    def __contains__(self, key) -> bool:      # noqa: D401
        # dotted names ("weapon.burn_chance") are looked up part by part, so say no to those here
        return "." not in str(key) or dict.__contains__(self, key)

    def __missing__(self, key):
        return 0


def lenient(d: dict) -> Lenient:
    return Lenient({k: (lenient(v) if isinstance(v, dict) and not isinstance(v, Lenient) else v)
                    for k, v in d.items()})


class Who:
    """A creature a mechanic is about: someone in a fight, or a party member outside one."""

    def __init__(self, combatant=None, member: dict | None = None, engine=None) -> None:
        self.c = combatant
        self.m = member
        self.engine = engine
        if self.c is None and member is not None and engine is not None:
            from game import condition
            self.c = condition.combatant(engine.world, member)
            condition.apply(engine.state, member, self.c)

    @property
    def name(self) -> str:
        return self.c.name if self.c is not None else (self.m or {}).get("name", "someone")

    @property
    def in_battle(self) -> bool:
        return self.m is None

    @property
    def member_id(self) -> str:
        if self.m is not None:
            return self.m.get("id", "")
        eid = getattr(self.c, "entity_id", "") or ""
        return eid.split(":", 1)[1] if eid.startswith("party:") else ""

    @property
    def team(self) -> str:
        return getattr(self.c, "team", "player")

    def has_thing(self, thing_id: str) -> bool:
        c = self.c
        if c is None:
            return False
        return (thing_id in (c.entity_id, c.race_id, c.class_id) or thing_id in c.equipment
                or any(f.id == thing_id for f in c.features))

    def values(self, world) -> dict:
        c = self.c
        if c is None:
            return {}
        out = {"name": c.name, "hp": c.hp, "max_hp": c.max_hp, "hp_pct": round(100 * c.hp / max(1, c.max_hp)),
               "temp_hp": c.temp_hp, "ac": c.ac, "level": c.level, "speed": c.speed * 5, "team": c.team,
               "party": c.team == "player", "alive": c.alive, "concentrating": bool(c.concentration)}
        for k, v in (c.stats or {}).items():
            out[k] = v
        for k, v in (c.mods or {}).items():
            out[f"{k}_mod"] = v
        from game.combat.conditions import CONDITIONS, exhaustion
        for name in CONDITIONS:
            out[name.lower()] = name in c.conditions
        out["exhaustion"] = exhaustion(c)
        ent = world.entities.get(c.entity_id) if c.entity_id and "." in c.entity_id else None
        if ent is not None:
            for cf in ent.custom:
                out.setdefault(cf.get("key"), cf.get("value"))
        out.update(c.vars or {})
        if self.m is not None and self.engine is not None:
            out.update(self.engine.state.party.get(self.member_id, {}).get("vars", {}))
        return out


def entity_values(world, entity_id: str) -> dict:
    e = world.entities.get(entity_id)
    return e.values() if e is not None else {}


class MechanicsEngine:
    def __init__(self, world, state, bus, battle=lambda: None, members=lambda: [], book=None,
                 rng: random.Random | None = None) -> None:
        self.world = world
        self.state = state
        self.bus = bus
        self.battle = battle            # callable: the Battle in progress, or None
        self.members = members          # callable: the party (member dicts)
        self.book = book
        self.rng = rng or random.Random()
        self._depth = 0
        self._running: set[str] = set()
        self._warned: set[str] = set()
        self._offs = [bus.on("*", self._on_event)] if bus is not None else []

    def close(self) -> None:
        for off in self._offs:
            off()
        self._offs = []

    # ------------------------------------------------------------------
    def mechanics(self) -> list:
        ms = [m for m in self.world.entities.all("mechanic") if m.fields.get("enabled", True)]
        return sorted(ms, key=lambda m: -int(m.fields.get("priority") or 0))

    def _say(self, kind: str, text: str) -> None:
        if self.bus is None:
            return
        b = self.battle()
        if b is not None:
            b.say(kind, text)
        else:
            self.bus.emit("log", kind=kind, text=text)

    # ------------------------------------------------------------------
    # Events -> triggers
    # ------------------------------------------------------------------
    def _on_event(self, event) -> None:
        if event.name in ("log", "combat.log") or event.name.startswith(("ui.", "mechanic.")):
            return
        if self._depth > 3:
            return
        for trig, me, other, extra in self.triggers_for(event):
            self.fire(trig, me, other, extra)
        if event.name == "combat.feature":
            f = event.get("feature")
            mech = self.world.entities.get(getattr(f, "mechanic", "") or "")
            if mech is not None and mech.type == "mechanic":
                self.run(mech, Who(event.get("combatant")), None, {"feature": getattr(f, "id", "")}, check=True)

    def triggers_for(self, event) -> list[tuple]:
        n, d = event.name, event.data
        W = lambda c: Who(c) if c is not None else None
        if n == "combat.turn_start":
            return [("Turn start", W(d.get("combatant")), None, {"round": d.get("round", 0)})]
        if n == "combat.turn_end":
            return [("Turn end", W(d.get("combatant")), None, {})]
        if n == "combat.attack":
            a, t = d.get("attacker"), d.get("target")
            atk = d.get("attack")
            extra = {"hit": bool(d.get("hit")), "crit": bool(d.get("crit")), "damage": d.get("damage", 0),
                     "weapon": getattr(atk, "item_id", "") or "", "attack": getattr(atk, "name", ""),
                     "ranged": bool(getattr(atk, "ranged", False)), "roll": d.get("roll", 0),
                     "total": d.get("total", 0)}
            out = [("Attack made", W(a), W(t), extra)]
            out.append(("Attack hit" if d.get("hit") else "Attack missed", W(a), W(t), extra))
            if d.get("crit"):
                out.append(("Critical hit", W(a), W(t), extra))
            if d.get("hit"):
                out.append(("Hit by an attack", W(t), W(a), extra))
            return out
        if n == "combat.damage":
            t, s = d.get("target"), d.get("source")
            extra = {"damage": d.get("amount", 0), "amount": d.get("amount", 0), "damage_type": d.get("damage_type", "")}
            out = [("Damage taken", W(t), W(s), extra)]
            if s is not None:
                out.append(("Damage dealt", W(s), W(t), extra))
            return out
        if n == "combat.heal":
            return [("Healed", W(d.get("target")), None, {"amount": d.get("amount", 0)})]
        if n == "combat.defeated":
            return [("Creature defeated", W(d.get("combatant")), W(d.get("source")), {})]
        if n == "combat.cast":
            s = d.get("spell")
            return [("Spell cast", W(d.get("caster")), W(d.get("target")),
                     {"spell": getattr(s, "id", ""), "spell_level": getattr(s, "level", 0)})]
        if n == "combat.feature":
            return [("Feature used", W(d.get("combatant")), None, {"feature": getattr(d.get("feature"), "id", "")})]
        if n == "combat.item":
            return [("Item used", W(d.get("combatant")), None, {"item": getattr(d.get("item"), "item_id", "")})]
        if n == "combat.condition" and d.get("applied"):
            return [("Condition applied", W(d.get("combatant")), W(d.get("source")),
                     {"condition": d.get("condition", "")})]
        if n == "combat.start":
            return [("Combat start", None, None, {})]
        if n == "combat.end":
            return [("Combat end", None, None, {"outcome": d.get("outcome", "")})]
        if n == "check.rolled":
            m = next((x for x in self.members() if x.get("id") == d.get("member")), None)
            me = Who(member=m, engine=self) if m else None
            return [("Check rolled", me, None, {"check": d.get("check", ""), "label": d.get("label", ""),
                                                "roll": d.get("roll", 0), "total": d.get("total", 0),
                                                "dc": d.get("dc", 0), "success": bool(d.get("success"))})]
        if n == "location.entered":
            return [("Location entered", None, None, {"location": d.get("location", ""), "town": d.get("town", ""),
                                                      "kind": d.get("kind", "")})]
        if n == "party.rested":
            return [("Rest", None, None, {"kind": d.get("kind", "")})]
        if n == "time.passed":
            return [("Time passed", None, None, {"minutes": d.get("minutes", 0)})]
        if n == "time.new_day":
            return [("New day", None, None, {"day": d.get("day", 0)})]
        if n in ("quest.accepted", "quest.completed"):
            q = d.get("quest") or {}
            return [("Quest accepted" if n.endswith("accepted") else "Quest completed", None, None,
                     {"quest": q.get("source", ""), "quest_title": q.get("title", "")})]
        if n in ("trade.bought", "trade.sold"):
            return [("Item bought" if n.endswith("bought") else "Item sold", None, None,
                     {"item": d.get("item", ""), "count": d.get("count", 0)})]
        if n.startswith("custom."):
            return [("Custom event", W(d.get("me")) if d.get("me") is not None else None, None,
                     {"event": n.split(".", 1)[1], **{k: v for k, v in d.items() if isinstance(v, (int, float, str))}})]
        return []

    # ------------------------------------------------------------------
    # Running rules
    # ------------------------------------------------------------------
    def fire(self, trigger: str, me, other, extra: dict) -> None:
        for mech in self.mechanics():
            f = mech.fields
            if f.get("trigger") != trigger:
                continue
            if trigger == "Custom event" and (f.get("custom_event") or "").strip().lower() != extra.get("event", "").lower():
                continue
            for subject in self._subjects(mech, trigger, me):
                if self._matches(mech, subject, extra):
                    self.run(mech, subject, other, extra, check=True)

    def _subjects(self, mech, trigger: str, me) -> list:
        if me is not None or trigger not in SUBJECTLESS:
            return [me] if me is not None else []
        who = mech.fields.get("applies_to") or "Anyone"
        b = self.battle()
        if b is not None:
            pool = [Who(c) for c in b.combatants if c.active]
        else:
            pool = [Who(member=m, engine=self) for m in self.members()]
        if who == "Anyone":
            return [None]                    # once, about nobody in particular
        return pool

    def _matches(self, mech, subject, extra: dict) -> bool:
        f = mech.fields
        b = self.battle()
        where = f.get("where") or "Anywhere"
        if (where == "In combat" and b is None) or (where == "Outside combat" and b is not None):
            return False
        who = f.get("applies_to") or "Anyone"
        if who == "Party members" and (subject is None or subject.team != "player"):
            return False
        if who == "Enemies" and (subject is None or subject.team == "player"):
            return False
        if who == "Specific thing":
            thing = f.get("entity") or ""
            e = self.world.entities.get(thing)
            if e is None:
                return False
            if e.type in ("building", "town"):
                loc = extra.get("location") or self.state.location
                return thing in (loc, extra.get("town", "")) or thing in str(self.state.location)
            if e.type == "spell":
                return extra.get("spell") == thing
            if e.type == "quest":
                return extra.get("quest") == thing
            if e.type == "skill":
                return extra.get("check") == thing
            if e.type == "item" and extra.get("weapon") == thing:
                return True
            if e.type == "item" and extra.get("item") == thing:
                return True
            return subject is not None and subject.has_thing(thing)
        return True

    def _limited(self, mech) -> bool:
        limit = mech.fields.get("limit") or "No limit"
        if limit == "No limit":
            return False
        used = self.state.npcs.setdefault("_mechanics", {}).get(mech.id, {})
        b = self.battle()
        if limit == "Once ever":
            return bool(used.get("ever"))
        if limit == "Once per day":
            return used.get("day") == self.state.day
        if limit == "Once per fight":
            return b is not None and used.get("fight") == id(b)
        return False

    def _mark(self, mech) -> None:
        rec = self.state.npcs.setdefault("_mechanics", {}).setdefault(mech.id, {})
        rec["ever"] = True
        rec["day"] = self.state.day
        b = self.battle()
        if b is not None:
            rec["fight"] = id(b)

    def variables(self, me, other, extra: dict) -> dict:
        w = self.world
        values = {k: v for k, v in extra.items()}
        values["me"] = me.values(w) if me is not None else {}
        values["other"] = other.values(w) if other is not None else {}
        values["weapon"] = entity_values(w, extra.get("weapon", ""))
        values["spell"] = entity_values(w, extra.get("spell", ""))
        values["item"] = entity_values(w, extra.get("item", ""))
        values["feature"] = entity_values(w, extra.get("feature", ""))
        values["quest"] = entity_values(w, extra.get("quest", ""))
        s = self.state
        values["world"] = {"day": s.day, "hour": s.minute_of_day // 60, "minute": s.minute_of_day % 60,
                           "time": s.time_of_day, "gold": s.gold, "xp": s.xp, "in_combat": self.battle() is not None,
                           **s.npcs.get("_vars", {})}
        for k in ("damage", "amount", "hit", "crit", "roll", "total", "dc", "success", "damage_type", "minutes"):
            values.setdefault(k, 0 if k not in ("damage_type",) else "")
        return lenient(values)

    def run(self, mech, me, other, extra: dict, check: bool = True) -> list[str]:
        """Run one mechanic. Returns lines describing what it did (for the Test button)."""
        if mech.id in self._running:
            return []
        f = mech.fields
        if check and self._limited(mech):
            return []
        values = self.variables(me, other, extra)
        cond = (f.get("condition") or "").strip()
        if check and cond:
            try:
                if not formula.evaluate(cond, values, self.rng):
                    return []
            except Exception as exc:              # noqa: BLE001 - a broken rule shouldn't break the game
                if mech.id not in self._warned:
                    self._warned.add(mech.id)
                    self._say("system", f"Mechanic '{mech.name}' has a problem in its condition: {exc}")
                return []
        chance = float(f.get("chance", 100) if f.get("chance") is not None else 100)
        if check and chance < 100 and self.rng.random() * 100 >= chance:
            return []
        self._mark(mech)
        self._running.add(mech.id)
        self._depth += 1
        lines = []
        try:
            if self.world.rules.get("mechanics_announce"):
                self._say("system", f"⚙ {mech.name}")
            for row in f.get("effects") or []:
                ok, line = self._effect(row, me, other, values)
                if line:
                    lines.append(line)
                if not ok:
                    break
        finally:
            self._depth -= 1
            self._running.discard(mech.id)
        if self.bus is not None:
            self.bus.emit("mechanic.ran", mechanic=mech.id, mechanic_name=mech.name)
        return lines

    # ------------------------------------------------------------------
    # Effects
    # ------------------------------------------------------------------
    def _targets(self, row, me, other) -> list:
        to = row.get("to") or "Who it happened to"
        b = self.battle()
        if to == "Who it happened to":
            return [me] if me is not None else []
        if to == "The other one":
            return [other] if other is not None else []
        if to == "The world":
            return ["world"]
        if b is not None:
            if to == "The whole party":
                return [Who(c) for c in b.combatants if c.team == "player" and c.active]
            if to == "All enemies in the fight":
                return [Who(c) for c in b.combatants if c.team != "player" and c.active]
            if to == "Everyone in the fight":
                return [Who(c) for c in b.combatants if c.active]
            return []
        if to == "The whole party":
            return [Who(member=m, engine=self) for m in self.members()]
        return []

    def _give_level(self, n: int = 1) -> str:
        """Every living party member can take n more levels (milestone levelling gets
        pending levels, XP levelling gets exactly enough experience)."""
        from game import character as CH
        from game import party as P
        members = self.members()
        milestone = (self.world.rules.get("levelling") or "XP") == "Milestone"
        for m in members:
            if m.get("dead"):
                continue
            if milestone:
                m["pending_levels"] = int(m.get("pending_levels", 0)) + n
            else:
                lvl = max(CH.total_level(self.world, m), CH.level_for_xp(int(m.get("xp", 0))))
                m["xp"] = max(int(m.get("xp", 0)), CH.XP_TABLE[min(19, lvl - 1 + n)])
        if members:
            P.save(self.world, members)
        if self.bus is not None:
            self.bus.emit("party.can_level")
        return f"gave {n} level{'s' if n > 1 else ''}"

    def _number(self, text, values) -> int:
        text = str(text or "").strip()
        if not text:
            return 0
        plain = text.replace(" ", "")
        if dice.is_valid(plain):
            return dice.roll(plain, self.rng).total
        try:
            return int(formula.evaluate(text, values, self.rng))
        except Exception:                         # noqa: BLE001
            return 0

    def _message(self, row, me, other, values, amount=None) -> str:
        msg = row.get("message") or ""
        if not msg:
            return ""
        rep = {"me": me.name if me is not None else "", "other": other.name if other is not None else "",
               "amount": "" if amount is None else str(amount), "damage": str(values.get("damage", ""))}
        return re.sub(r"\{(\w+)\}", lambda m: rep.get(m.group(1), m.group(0)), msg)

    def _effect(self, row, me, other, values) -> tuple[bool, str]:
        """Do one effect row. Returns (keep going, a line describing it)."""
        action = row.get("action") or "Message"
        b = self.battle()
        targets = self._targets(row, me, other)
        detail = str(row.get("detail") or "").strip()
        n = None
        keep_going = True
        done = []
        if action in ("Give item", "Remove item", "Give gold", "Take gold", "Give XP", "Start quest"):
            n = self._number(row.get("amount") or "1", values)
            thing = row.get("thing") or ""
            if action == "Give item" and self.world.entities.get(thing):
                self.state.add_item(thing, max(1, n), source="mechanic")
                done.append(f"gave {self.world.entities.get(thing).name} x{max(1, n)}")
            elif action == "Remove item" and thing:
                done.append(f"took {self.state.remove_item(thing, max(1, n), 'mechanic')}")
            elif action == "Give gold":
                self.state.add_gold(n, "mechanic")
                done.append(f"gave {n} gold")
            elif action == "Take gold":
                self.state.add_gold(-n, "mechanic")
                done.append(f"took {n} gold")
            elif action == "Give XP":
                self.state.add_xp(n, "mechanic")
                done.append(f"gave {n} XP")
            elif action == "Start quest" and self.book is not None and self.world.entities.get(thing):
                from game.quests import from_entity
                self.book.accept(from_entity(self.world, self.world.entities.get(thing)))
                done.append("started a quest")
        elif action == "Give level":
            done.append(self._give_level(max(1, int(self._number(row.get("amount") or "1", values)))))
        elif action == "Message":
            pass
        elif action == "Trigger event":
            if self.bus is not None and detail:
                self.bus.emit(f"custom.{detail}", me=me.c if me is not None and me.in_battle else None)
                done.append(f"triggered '{detail}'")
        else:
            for who in targets:
                if who == "world":
                    if action in ("Change value", "Set value") and detail:
                        wv = self.state.npcs.setdefault("_vars", {})
                        n = self._number(row.get("amount") or "1", values)
                        wv[detail] = (float(wv.get(detail, 0) or 0) + n) if action == "Change value" else n
                        self.state.save()
                        done.append(f"world {detail} = {wv[detail]:g}")
                    continue
                if who is None:
                    continue
                ok, line, n = self._creature_effect(action, who, me, other, detail, row, values, b)
                if line:
                    done.append(line)
                if not ok:
                    keep_going = False
        msg = self._message(row, me, other, values, n)
        if msg:
            self._say("narration", msg)
        return keep_going, "; ".join(done) or msg

    def _creature_effect(self, action, who, me, other, detail, row, values, b) -> tuple[bool, str, int | None]:
        from game import condition as COND
        from game.combat import conditions as CND
        c = who.c
        amount_text = row.get("amount") or ""
        source = (me.c if me is not None and me is not who and me.in_battle else
                  other.c if other is not None and other.in_battle and other is not who else None)
        if action == "Deal damage":
            n = max(0, self._number(amount_text or "1", values))
            if b is not None and who.in_battle:
                b.damage(c, n, detail.lower(), source=source, detail=amount_text)
            else:
                self._member_hp(who, -n)
                self._say("damage", f"{who.name} takes {n}{' ' + detail.lower() if detail else ''} damage.")
            return True, f"{who.name} took {n} damage", n
        if action == "Heal":
            n = max(0, self._number(amount_text or "1", values))
            if b is not None and who.in_battle:
                b.heal(c, n)
            else:
                self._member_hp(who, n)
                self._say("heal", f"{who.name} recovers {n} HP.")
            return True, f"{who.name} healed {n}", n
        if action == "Give temporary HP":
            n = max(0, self._number(amount_text or "1", values))
            if who.in_battle:
                c.temp_hp = max(c.temp_hp, n)
                self._say("heal", f"{who.name} gains {n} temporary hit points.")
            return True, f"{who.name} +{n} temp HP", n
        if action == "Apply condition":
            rounds = self._number(amount_text, values) if amount_text else -1
            if who.in_battle:
                CND.apply(b, c, detail, rounds if rounds > 0 else -1, source)
            else:
                rec = COND.record(self.state, who.m)
                if not CND.immune(c, detail.title()):
                    lasting = rec.setdefault("conditions", {})
                    name = detail.title()
                    if name == "Exhaustion":
                        lasting["Exhaustion"] = int(lasting.get("Exhaustion", 0)) + 1
                        c.conditions[name] = {"rounds": -1, "level": lasting["Exhaustion"], "lasting": True}
                    else:
                        lasting[name] = -1
                        c.conditions[name] = {"rounds": -1, "lasting": True}
                    self.state.save()
                    self._say("damage", f"{who.name} is {detail.lower()}.")
            return True, f"{who.name} is {detail.lower()}", None
        if action == "Remove condition":
            if who.in_battle:
                CND.remove(b, c, detail, "all")
            else:
                rec = COND.record(self.state, who.m)
                c.conditions.pop(detail.title(), None)
                if rec.get("conditions", {}).pop(detail.title(), None) is not None:
                    self.state.save()
                    self._say("heal", f"{who.name} is no longer {detail.lower()}.")
            return True, f"{who.name} no longer {detail.lower()}", None
        if action == "Change resource":
            from game import condition as COND
            n = self._number(amount_text or "1", values)
            pool = (getattr(c, "resources", {}) or {}).get(detail)
            if pool is None:
                return True, "", None
            pool["cur"] = max(0, min(pool["max"], pool["cur"] + n))
            if not who.in_battle and who.m is not None:
                COND.store(self.state, who.m, c)
            return True, f"{who.name} {detail} {'+' if n >= 0 else ''}{n}", n
        if action in ("Change value", "Set value"):
            n = self._number(amount_text or "1", values)
            key = detail.lower() or "value"
            change = action == "Change value"
            if key == "hp":
                if who.in_battle:
                    target_hp = c.hp + n if change else n
                    if target_hp < c.hp:
                        b.damage(c, c.hp - target_hp, "", source=source)
                    else:
                        b.heal(c, target_hp - c.hp)
                else:
                    self._member_hp(who, n if change else n - c.hp)
            elif key == "temp_hp" and who.in_battle:
                c.temp_hp = max(0, c.temp_hp + n if change else n)
            elif key in ("ac", "speed") and who.in_battle:
                if key == "ac":
                    c.base_ac = c.base_ac + n if change else n
                    c.ac = c.ac + n if change else n
                    b.refresh_stats(c)
                else:
                    sq = n // 5
                    c.base_speed = max(0, c.base_speed + sq if change else sq)
                    c.speed = max(0, c.speed + sq if change else sq)
                    b.refresh_stats(c)
            elif key in (c.stats or {}) and who.in_battle:
                c.stats[key] = c.stats[key] + n if change else n
                c.mods[key] = self.world.modifier(key, c.stats[key])
            else:
                store = c.vars if who.in_battle else COND.record(self.state, who.m).setdefault("vars", {})
                old = float(store.get(key, 0) or 0)
                store[key] = old + n if change else n
                c.vars[key] = store[key]
                if who.in_battle and who.member_id:
                    COND.record(self.state, {"id": who.member_id}).setdefault("vars", {})[key] = store[key]
                self.state.save()
            return True, f"{who.name} {key} {'+' if change and n >= 0 else ''}{n}", n
        if action == "Saving throw (stop if passed)":
            stat = (detail or "con").lower()[:3]
            dc = self._number(amount_text or "10", values)
            if who.in_battle:
                ok = b.saving_throw(c, stat, dc)
            else:
                from game import checks
                member = who.m or next((m for m in self.members() if m.get("id") == who.member_id), {"id": ""})
                r = checks.save(self.world, member, c, stat, dc, rng=self.rng)
                ok = r["success"]
                self._say("roll", r["text"])
            return (not ok), f"{who.name} {'passed' if ok else 'failed'} a {stat.upper()} save", dc
        if action == "Check (stop if failed)":
            from game import checks
            dc = self._number(amount_text or "10", values)
            opts = checks.options(self.world)
            opt = next((o for o in opts if o["label"].lower() == detail.lower()
                        or o["id"] == f"stat:{detail.lower()[:3]}"), None) or (opts[0] if opts else None)
            if opt is None:
                return True, "", None
            member = who.m or next((m for m in self.members() if m.get("id") == who.member_id), {"id": ""})
            mode = "disadvantage" if CND.check_disadvantage(c) else "normal"
            r = checks.roll(self.world, member, c, opt, dc, mode, self.rng, None)
            self._say("roll", r["text"])
            return bool(r.get("success")), f"{who.name} {'passed' if r.get('success') else 'failed'} {opt['label']}", dc
        if action == "Grant feature for the fight" and who.in_battle:
            from game.combat import features as F
            e = self.world.entities.get(row.get("thing") or "")
            if e is not None and e.type == "feature" and not any(f.id == e.id for f in c.features):
                c.features.append(F.build(self.world, e, c))
                b.refresh_stats(c)
                self._say("system", f"{who.name} gains {e.name} for this fight.")
                return True, f"{who.name} gains {e.name}", None
        return True, "", None

    def _member_hp(self, who, change: int) -> None:
        from game import condition as COND
        c = who.c
        c.hp = max(1, min(c.max_hp, c.hp + change))
        COND.store(self.state, who.m, c)

    # ------------------------------------------------------------------
    def test(self, mech) -> list[str]:
        """Run a mechanic right now, ignoring its trigger and limits, on the first party member."""
        members = self.members()
        me = Who(member=members[0], engine=self) if members else None
        other = Who(member=members[1], engine=self) if len(members) > 1 else None
        values = self.variables(me, other, {})
        out = []
        cond = (mech.fields.get("condition") or "").strip()
        if cond:
            try:
                out.append(f"Condition '{cond}' is {'true' if formula.evaluate(cond, values, self.rng) else 'false'} "
                           f"right now.")
            except Exception as exc:              # noqa: BLE001
                out.append(f"Condition problem: {exc}")
        lines = self.run(mech, me, other, {}, check=False)
        return out + (lines or ["It ran, but none of its effects had anything to act on outside a fight."])
