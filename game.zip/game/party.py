"""The player's party: up to six characters, saved with each world.

Until character creation exists, a member is a light description (race,
class, level, gear, look). Everything else (HP, armor, attacks, spells) is
worked out from the world's rules by game.combat.builders.
"""
from __future__ import annotations

import json
import uuid
from pathlib import Path

MAX_MEMBERS = 6
FILE = "party.json"


def new_id() -> str:
    return uuid.uuid4().hex[:8]


def _find(world, type_name: str, *names) -> str:
    for n in names:
        e = world.entities.find_by_name(type_name, n)
        if e:
            return e.id
    items = world.entities.all(type_name)
    return items[0].id if items else ""


def default_member(world, index: int = 0) -> dict:
    """A sensible starting character built from whatever the world has."""
    presets = [
        ("Rowan", ("Human",), ("Fighter",), {"Main hand": ("Longsword", "Shortsword"), "Off hand": ("Shield",),
                                             "Body": ("Chain Mail", "Leather Armor")}, {"hair": "short"}),
        ("Ilsa", ("Elf", "Human"), ("Wizard",), {"Main hand": ("Quarterstaff",), "Body": ("Wizard Robe",)}, {}),
        ("Brom", ("Dwarf", "Human"), ("Barbarian", "Fighter"), {"Main hand": ("Greataxe", "Battleaxe")},
         {"hair_color": "#c04a1a"}),
        ("Wren", ("Human",), ("Rogue", "Fighter"), {"Main hand": ("Shortsword",), "Off hand": ("Dagger",),
                                                    "Body": ("Leather Armor",)},
         {"hair": "ponytail", "hair_color": "#2b2220"}),
    ]
    name, races, classes, gear, look = presets[index % len(presets)]
    if index >= len(presets):
        name = f"Hero {index + 1}"
    eq = {slot: _find(world, "item", *names) for slot, names in gear.items()}
    return {"id": new_id(), "name": name, "race": _find(world, "race", *races),
            "class": _find(world, "class", *classes), "level": 3,
            "equipment": {k: v for k, v in eq.items() if v}, "look": dict(look), "potions": 2}


def load(world, defaults: bool = True) -> list[dict]:
    """The world's party. IDs are always saved, so a member keeps the same ID every time.
    defaults: with no party saved yet, make two ready-made heroes (the game itself passes False and walks
    the player through making their own instead)."""
    path = Path(world.path) / FILE
    members: list[dict] = []
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            members = [m for m in data.get("members", []) if isinstance(m, dict)][:MAX_MEMBERS]
        except (OSError, ValueError):
            members = []
    changed = False
    new_run = False
    if path.exists():
        try:
            new_run = bool(json.loads(path.read_text(encoding="utf-8")).get("new_run"))
        except (OSError, ValueError):
            new_run = False
    if not members and not new_run and defaults:
        members = [default_member(world, 0), default_member(world, 1)]
        changed = True
    for m in members:
        if not m.get("id"):
            m["id"] = new_id()
            changed = True
    from game.character import normalize
    normalized = [normalize(world, m) for m in members]
    if changed or normalized != members:
        members = normalized
        save(world, members)
    return members


def award_xp(world, members: list[dict], amount: int) -> list[str]:
    """Share experience equally among the living party members. Returns the names of anyone
    who can now level up."""
    from game.character import can_level_up
    alive = [m for m in members if not m.get("dead")]
    if not alive or amount <= 0:
        return []
    each = amount // len(alive)
    ready = []
    for m in alive:
        before = can_level_up(world, m)
        m["xp"] = int(m.get("xp", 0)) + each
        if can_level_up(world, m) and not before:
            ready.append(m.get("name", "Someone"))
    save(world, members)
    return ready


def give_milestone(world, members: list[dict]) -> None:
    for m in members:
        if not m.get("dead"):
            m["pending_levels"] = int(m.get("pending_levels", 0)) + 1
    save(world, members)


def save(world, members: list[dict]) -> None:
    path = Path(world.path) / FILE
    clean = []
    for m in members[:MAX_MEMBERS]:
        m = dict(m)
        m.setdefault("id", new_id())
        clean.append(m)
    path.write_text(json.dumps({"members": clean}, indent=2), encoding="utf-8")
