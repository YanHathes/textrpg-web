"""Where the party is, what's there, and the ways to somewhere else.

A location is a string:
    building.<slug>                 inside a building (its entity id): the room by the street door
    room|<building id>|<room>       in another room of a building (game/rooms.py makes the rooms)
    street|<town id>|<street name>  out on a street
    wild|<town id>|<direction>      the land outside a town in one direction
    road|<town id>|<direction>      on a road, during a journey (see game/travel.py)
    landmark|<landmark id>          at a landmark out in the wilds (game/dungeons.py)
    dungeon|<dungeon id>|<room>     in a dungeon room
    hex|<q>|<r>                     out in open country, in one hex of the overland map (game/hexes.py)
A bare town id (town.<slug>) means that town's first street.

Towns are made of streets ("connects to" lists the streets you can walk to).
Buildings open onto a street. A street with "leaves town to the North" is the
way out in that direction: there you can take a road (if the town has one going
that way) or head off into the wilds. A town with no exits marked can be left
from its first street in the directions of its roads, plus north, east, south
and west.
"""
from __future__ import annotations

import re
from collections import deque
from dataclasses import dataclass, field

from game.constants import DIRECTIONS

PLACE_FOR_KIND = {
    "Shop": "Shop", "Tavern": "Tavern", "Inn": "Inn", "Temple": "Temple", "Smithy": "Smithy",
    "Guild hall": "Guild hall", "House": "House", "Town hall": "Town hall", "Barracks": "Barracks",
    "Warehouse": "Warehouse", "Library": "Library", "Stable": "Stable", "Market": "Market", "Other": "House",
    "College": "Library", "Boatwright": "Warehouse", "Bank": "Town hall", "Jail": "Barracks", "Casino": "Tavern",
    "Arena": "Barracks", "Brothel": "Inn",
}
WALLS = {"Wooden": "Wooden", "Stone": "Stone", "Rich": "Rich", "Rustic": "Rustic", "Brick": "Brick"}
TERRAIN_PLACE = {"Plains": "Plains", "Forest": "Forest", "Hills": "Hills", "Mountains": "Mountains", "Coast": "Coast",
                 "Swamp": "Swamp", "Desert": "Desert", "Arctic": "Arctic"}
TERRAIN_NOUN = {"Plains": "fields", "Forest": "woods", "Hills": "hills", "Mountains": "mountains",
                "Coast": "shore", "Swamp": "marshes", "Desert": "dunes", "Arctic": "snowfields"}
OPPOSITE = {"North": "South", "South": "North", "East": "West", "West": "East", "North-east": "South-west",
            "South-west": "North-east", "North-west": "South-east", "South-east": "North-west"}

MIN_DOOR = 1              # in or out of a building
MIN_ROOM = 1              # from one room of a building to the next
MIN_STREET = 5            # one street to the next
MIN_TOWN_EDGE = 20        # from the edge of town out into the wilds, or back
MINUTES_IN_TOWN = 10      # older name, still used by a few callers
MINUTES_BETWEEN_TOWNS = 8 * 60   # fallback for towns with no road between them


@dataclass
class Spot:
    kind: str                       # building, street, wild, road, nowhere
    id: str
    name: str = ""
    town: object = None             # town entity
    building: object = None         # building entity
    street: str = ""
    direction: str = ""
    extra: dict = field(default_factory=dict)

    @property
    def type(self) -> str:          # lets old code ask "spot.type == 'building'"
        return {"street": "town"}.get(self.kind, self.kind)


# ======================================================================
# Ids
# ======================================================================
def street_id(town_id: str, street: str) -> str:
    return f"street|{town_id}|{street}"


def wild_id(town_id: str, direction: str) -> str:
    return f"wild|{town_id}|{direction}"


def road_id(town_id: str, direction: str) -> str:
    return f"road|{town_id}|{direction}"


def streets_of(town) -> list[dict]:
    rows = [dict(s) for s in (town.fields.get("streets") or []) if s.get("name")]
    if not rows:
        rows = [{"name": "Main Street", "connects": "", "exit": ""}]
    return rows


def first_street(town) -> str:
    return streets_of(town)[0]["name"]


def street_of_building(world, b) -> str:
    town = world.entities.get(b.fields.get("town"))
    if town is None:
        return ""
    names = [s["name"] for s in streets_of(town)]
    st = b.fields.get("street") or ""
    return st if st in names else names[0]


EXTRA_ROADS: dict[str, list[dict]] = {}     # town id -> roads the running save has built to it (game/colony.py)


def roads_of(town) -> list[dict]:
    own = [r for r in (town.fields.get("roads") or []) if r.get("direction")]
    extra = EXTRA_ROADS.get(town.id) if EXTRA_ROADS else None
    return own + extra if extra else own


def town_exits(town) -> dict[str, str]:
    """direction -> the street you leave town from."""
    streets = streets_of(town)
    out = {s["exit"]: s["name"] for s in streets if s.get("exit")}
    if not out:
        dirs = [r["direction"] for r in roads_of(town)] + ["North", "East", "South", "West"]
        for d in dirs:
            out.setdefault(d, streets[0]["name"])
    for r in roads_of(town):                    # every road can be reached somewhere
        out.setdefault(r["direction"], streets[0]["name"])
    return out


def parse(world, loc: str) -> Spot:
    """Turn a location string into a Spot (or a 'nowhere' Spot if it doesn't exist)."""
    loc = loc or ""
    if loc.startswith("landmark|") or loc.startswith("dungeon|"):
        return _parse_outside(world, loc)
    if loc.startswith("hex|"):
        return _parse_hex(world, loc)
    if loc.startswith("room|"):
        return _parse_room(world, loc)
    if "|" in loc:
        kind, town_id, rest = (loc.split("|", 2) + ["", ""])[:3]
        town = world.entities.get(town_id)
        if town is None or town.type != "town":
            return Spot("nowhere", "")
        if kind == "street":
            names = [s["name"] for s in streets_of(town)]
            if rest not in names:
                rest = names[0]
            return Spot("street", street_id(town.id, rest), rest, town, street=rest)
        if kind == "wild":
            terrain = town.fields.get("terrain") or "Plains"
            noun = TERRAIN_NOUN.get(terrain, "wilds")
            return Spot("wild", loc, f"The {noun} {rest.lower()} of {town.name}", town, direction=rest)
        if kind == "road":
            return Spot("road", loc, "On the road", town, direction=rest)
        if kind == "voyage":
            dest = world.entities.get(rest)
            state = getattr(world, "_state_for_places", None)
            method = ((state.journey or {}).get("method") if state is not None else "") or "Boat"
            words = {"Boat": "At sea", "Airship": "Aboard the airship", "Caravan": "With the caravan"}
            return Spot("voyage", loc, f"{words.get(method, 'Travelling')}, bound for "
                                       f"{dest.name if dest else 'somewhere'}", town, extra={"to": dest,
                                                                                            "method": method})
        return Spot("nowhere", "")
    e = world.entities.get(loc)
    if e is not None and e.type == "building":
        rows = building_rooms(e)
        return Spot("building", e.id, e.name, world.entities.get(e.fields.get("town")), e,
                    street=street_of_building(world, e),
                    extra={"room": rows[0]["name"] if rows else "", "floor": int(rows[0].get("floor") or 0)
                           if rows else 0})
    if e is not None and e.type == "town":
        st = first_street(e)
        return Spot("street", street_id(e.id, st), st, e, street=st)
    return Spot("nowhere", "")


def room_id(building_id: str, room: str) -> str:
    return f"room|{building_id}|{room}"


def building_rooms(b) -> list[dict]:
    """A building's rooms if it has them yet (they're made when someone first goes in)."""
    return [r for r in (b.fields.get("rooms") or []) if str(r.get("name") or "").strip()] if b is not None else []


def _parse_room(world, loc: str) -> Spot:
    _k, b_id, name = (loc.split("|", 2) + ["", ""])[:3]
    b = world.entities.get(b_id)
    if b is None or b.type != "building":
        return Spot("nowhere", "")
    rows = building_rooms(b)
    if not rows and b.fields.get("generate", True):          # not made (or not kept) yet: they come out the same
        from game import rooms as R
        rows = R.building_rows(world, b, save=False)
    row = next((r for r in rows if r["name"] == name), None)
    if row is None or row is rows[0]:                       # the first room is the building itself
        return parse(world, b.id)
    return Spot("building", room_id(b.id, name), name, world.entities.get(b.fields.get("town")), b,
                street=street_of_building(world, b), extra={"room": name, "floor": int(row.get("floor") or 0)})


def guest_room(world, spot) -> str:
    """Where a party renting rooms sleeps: a private room of this building ('' if it has none)."""
    if spot is None or spot.kind != "building":
        return ""
    rows = building_rooms(spot.building)
    for r in rows[1:]:
        if r.get("type") == "Private":
            return room_id(spot.building.id, r["name"])
    return ""


def room_here(spot) -> dict | None:
    """The room row a building Spot is in (None outside, or in a building with no rooms yet)."""
    if spot is None or spot.kind != "building" or spot.building is None:
        return None
    rows = building_rooms(spot.building)
    name = spot.extra.get("room") or (rows[0]["name"] if rows else "")
    return next((r for r in rows if r["name"] == name), None)


def _parse_outside(world, loc: str) -> Spot:
    from game import dungeons as D
    kind, _s, rest = loc.partition("|")
    if kind == "landmark":
        lm = world.entities.get(rest)
        if lm is None or lm.type != "landmark":
            return Spot("nowhere", "")
        town = world.entities.get(lm.fields.get("near_town") or "")
        return Spot("landmark", loc, lm.name, town, direction=lm.fields.get("direction") or "North",
                    extra={"landmark": lm})
    d_id, _s, name = rest.partition("|")
    d = world.entities.get(d_id)
    if d is None or d.type != "dungeon" or not D.ensure_rooms(world, d):
        return Spot("nowhere", "")
    if D.room(d, name) is None:
        name = D.entrance(d)
    lm = next(iter(world.entities.by_field("landmark", "dungeon", d.id)), None)
    town = world.entities.get((lm.fields.get("near_town") if lm else None) or d.fields.get("town") or "")
    return Spot("dungeon", D.room_id(d.id, name), name, town, direction=d.fields.get("direction") or "",
                extra={"dungeon": d, "room": name, "landmark": lm})


def _parse_hex(world, loc: str) -> Spot:
    from game import hexes as H
    qr = H.parse_id(loc)
    if qr is None or not H.on_map(world, *qr):
        return Spot("nowhere", "")
    q, r = qr
    b = H.biome(world, q, r)
    return Spot("hex", H.hex_id(q, r), H.name(world, q, r), None,
                extra={"q": q, "r": r, "biome": b, "region": H.region(world, q, r),
                       "continent": H.continent(world, q, r)})


def town_gate(world, town, toward: tuple[float, float] | None = None) -> str:
    """The street you come into a town by from open country (the exit facing where you came from)."""
    from game import geography as G
    exits = town_exits(town)
    p = G.town_position(world, town)
    if toward is None or p is None or not exits:
        return first_street(town)
    dx, dy = toward[0] - p[0], toward[1] - p[1]
    best = max(exits, key=lambda d: G.VECTORS.get(d, (0, 0))[0] * dx + G.VECTORS.get(d, (0, 0))[1] * dy)
    return exits[best]


def parse_plain(world, loc: str) -> bool:
    return world.entities.get(loc) is not None or ("|" in loc and world.entities.get(loc.split("|")[1]) is not None)


def _road_hours(world, town, road) -> float:
    from game import geography
    return geography.road_hours(world, town, road)


def default_location(world) -> str:
    """Where a new game starts: the world's start location if set, else a building with people in it,
    else any building or street."""
    start = world.rules.get("start_location") or ""
    if start and parse_plain(world, start):
        return start
    towns = world.entities.all("town")
    if towns and world.entities.count("building"):     # an inn in the liveliest town that has one
        for t in sorted(towns, key=lambda t: -int(t.fields.get("population") or 0))[:10]:
            inns = [b for b in buildings_in(world, t) if b.fields.get("kind") == "Inn"]
            for b in inns:
                if people_in(world, parse(world, b.id)):
                    return b.id
    buildings = world.entities.all("building")
    for b in buildings:
        if people_in(world, parse(world, b.id)):
            return b.id
    if buildings:
        return buildings[0].id
    towns = world.entities.all("town")
    if not towns:
        return ""
    biggest = max(towns, key=lambda t: int(t.fields.get("population") or 0))   # start somewhere lively
    return street_id(biggest.id, first_street(biggest))


def current(world, state) -> Spot:
    """Where the party is (fixing the state if it points at something deleted)."""
    world._state_for_places = state
    spot = parse(world, state.location)
    if spot.kind == "nowhere":
        state.location = default_location(world)
        spot = parse(world, state.location)
        if state.location:
            state.save()
    elif spot.id != state.location:          # a bare town id: settle on its street
        state.location = spot.id
    if spot.town is not None and spot.kind in ("street", "building"):
        state.last_town = spot.town.id
        from game import factions
        factions.meet_town(world, state, spot.town)       # its people and its realm become known
    return spot


# ======================================================================
# Who and what is where
# ======================================================================
def town_of(world, entity) -> str:
    if entity is None:
        return ""
    if isinstance(entity, Spot):
        return entity.town.id if entity.town is not None else ""
    if entity.type == "town":
        return entity.id
    if entity.type == "building":
        return entity.fields.get("town") or ""
    if entity.type == "npc":
        b = world.entities.get(building_of(world, entity))
        return (b.fields.get("town") if b else "") or entity.fields.get("town") or ""
    return ""


def building_of(world, npc) -> str:
    """The building an NPC is found in (their own field, or a building that lists them)."""
    if npc is None:
        return ""
    if npc.fields.get("building") and world.entities.get(npc.fields["building"]):
        return npc.fields["building"]
    listed = world.entities.by_field("building", "npcs", npc.id)
    return listed[0].id if listed else ""


def where_is(world, npc) -> str:
    """The location to go to to find an NPC."""
    if npc is None:
        return ""
    b = building_of(world, npc)
    if b:
        return b
    town = world.entities.get(npc.fields.get("town"))
    if town is not None:
        return street_id(town.id, npc.fields.get("street") or first_street(town))
    return ""


def location_of(world, entity_id: str) -> str:
    """A location string for a building, town or NPC id."""
    e = world.entities.get(entity_id)
    if e is None:
        return entity_id if "|" in (entity_id or "") else ""
    if e.type == "building":
        return e.id
    if e.type == "town":
        return street_id(e.id, first_street(e))
    if e.type == "npc":
        return where_is(world, e)
    return ""


def people_in(world, spot, state=None) -> list:
    """NPCs here. With the game state (and the world's npc_schedules rule on), it's who is here
    at this time of day: their schedules and homes count."""
    if spot is None:
        return []
    if not isinstance(spot, Spot):
        spot = parse(world, spot.id)
    from game import schedules
    if spot.kind == "building" and building_rooms(spot.building):
        whole = _people_in_building(world, spot, state)
        where = people_rooms(world, spot.building, whole, state)
        here = spot.extra.get("room") or building_rooms(spot.building)[0]["name"]
        return [n for n in whole if where.get(n.id) == here]
    return _people_in_building(world, spot, state)


def _people_in_building(world, spot, state=None) -> list:
    """Everyone in the building (or on the street) the spot is in, whichever room."""
    from game import schedules
    if state is not None and schedules.enabled(world) and spot.kind in ("building", "street"):
        return _people_now(world, spot, state)
    if spot.kind == "building":
        b = spot.building
        ids = list(b.fields.get("npcs") or [])
        ids += [n.id for n in world.entities.by_field("npc", "building", b.id) if n.id not in ids]
    elif spot.kind == "street":
        first = first_street(spot.town)
        ids = [n.id for n in world.entities.by_field("npc", "town", spot.town.id)
               if not building_of(world, n) and (n.fields.get("street") or first) == spot.street]
    else:
        ids = []
    out = [n for n in (world.entities.get(i) for i in ids) if n is not None and n.type == "npc"]
    if state is not None:
        out = [n for n in out if not state.npc_dead(n.id)]
    return out


def _people_now(world, spot, state) -> list:
    from game import schedules
    minute = state.minute_of_day
    pool: list = []
    if spot.kind == "building":
        b = spot.building
        pool = [world.entities.get(i) for i in b.fields.get("npcs") or []]
        pool += world.entities.by_field("npc", "building", b.id)
        pool += schedules.candidates(world, b.id)
        if b.fields.get("claim"):               # the party's hired hands (game/estate.py)
            from game import estate
            pool += estate.hands_at(world, b.id)
    else:
        pool = world.entities.by_field("npc", "town", spot.town.id) + schedules.candidates(world, spot.town.id)
        for b in buildings_in(world, spot.town):       # people who've left work for the street
            pool += [n for n in world.entities.by_field("npc", "building", b.id) if n.fields.get("schedule")]
    out, seen = [], set()
    for n in pool:
        if n is None or n.type != "npc" or n.id in seen or state.npc_dead(n.id):
            continue
        seen.add(n.id)
        if schedules.where_now(world, n, minute) == (spot.building.id if spot.kind == "building" else spot.id):
            out.append(n)
    return out


ROLE_STATION = {"Innkeeper": "bar", "Merchant": "counter", "Blacksmith": "forge", "Armorer": "forge",
                "Weaponsmith": "forge", "Alchemist": "counter", "Priest": "altar", "Guard": "door",
                "Librarian": "desk", "Scholar": "desk", "Noble": "tables", "Farmer": "tables", "Tailor": "counter",
                "Jeweler": "counter", "Fletcher": "counter", "Hunter": "counter"}


def people_rooms(world, b, npcs: list, state=None) -> dict[str, str]:
    """npc id -> the room of the building they're in: at their work (the bar, the forge, the altar) if
    they work here, asleep in a bedroom at night if they live here, otherwise in the main room."""
    from game import rooms as R
    rows = building_rooms(b)
    if not rows:
        return {}
    feats = {r["name"]: R.tile_features(world, r) for r in rows}
    common = next((r["name"] for r in rows if r.get("type") == "Common"), rows[0]["name"])
    beds = [r["name"] for r in rows if r.get("type") == "Private"]
    night = state is not None and (state.minute_of_day < 6 * 60 or state.minute_of_day >= 22 * 60)
    out = {}
    for i, n in enumerate(npcs):
        works = (n.fields.get("building") or "") == b.id
        key = ROLE_STATION.get(n.fields.get("occupation") or "", "")
        if key == "door":
            out[n.id] = rows[0]["name"]
            continue
        if night and works and beds:
            out[n.id] = beds[i % len(beds)]
            continue
        at = next((name for name, f in feats.items() if key and key in f), None) if works else None
        out[n.id] = at or common
    return out


def buildings_on(world, town, street: str) -> list:
    return [b for b in buildings_in(world, town) if street_of_building(world, b) == street]


def buildings_in(world, town) -> list:
    return sorted(world.entities.by_field("building", "town", town.id), key=lambda b: b.name.lower())


# ======================================================================
# Opening hours
# ======================================================================
_HOURS = re.compile(r"(\d{1,2})(?::(\d{2}))?\s*-\s*(\d{1,2})(?::(\d{2}))?")


def open_span(building) -> tuple[int, int] | None:
    """(open minute, close minute) of the day, or None when always open."""
    text = str(building.fields.get("open_hours") or "").strip().lower()
    if not text or text in ("always", "24h", "24 hours", "all day"):
        return None
    m = _HOURS.search(text)
    if not m:
        return None
    a = int(m.group(1)) * 60 + int(m.group(2) or 0)
    b = int(m.group(3)) * 60 + int(m.group(4) or 0)
    if a == b or (a == 0 and b >= 24 * 60):
        return None
    return a, b


def is_open(building, minute_of_day: int) -> bool:
    from game import destruction
    if building is not None and destruction.is_ruin(building.id):     # a ruin (game/destruction.py)
        return False
    span = open_span(building)
    if span is None:
        return True
    a, b = span
    if a < b:
        return a <= minute_of_day < b
    return minute_of_day >= a or minute_of_day < b          # open past midnight


def opens_at(building) -> str:
    span = open_span(building)
    return "" if span is None else f"{span[0] // 60:02d}:{span[0] % 60:02d}"


# ======================================================================
# Ways out
# ======================================================================
def road_to(town, direction: str) -> dict | None:
    return next((r for r in roads_of(town) if r["direction"] == direction), None)


def arrival_street(world, town, came_from_id: str) -> str:
    """Which street you arrive on when a road brings you into town."""
    back = next((r for r in roads_of(town) if r.get("leads_to") == came_from_id), None)
    exits = town_exits(town)
    if back and back["direction"] in exits:
        return exits[back["direction"]]
    return first_street(town)


def neighbors(world, loc: str) -> list[tuple[str, int, str]]:
    """Places one move away: (location, minutes, how). Roads give the far town's street,
    with the road's travel time."""
    spot = parse(world, loc)
    out = []
    if spot.kind == "building":
        rows = building_rooms(spot.building)
        here = spot.extra.get("room") or (rows[0]["name"] if rows else "")
        if spot.town is not None and (not rows or here == rows[0]["name"]):
            out.append((street_id(spot.town.id, spot.street), MIN_DOOR, "door"))
        if rows:
            from game import rooms as R
            for n in R.links(rows, here):
                out.append((room_id(spot.building.id, n) if n != rows[0]["name"] else spot.building.id, MIN_ROOM,
                            "room"))
    elif spot.kind == "street":
        town = spot.town
        for b in buildings_on(world, town, spot.street):
            out.append((b.id, MIN_DOOR, "door"))
        row = next((s for s in streets_of(town) if s["name"] == spot.street), {})
        names = [s["name"] for s in streets_of(town)]
        linked = [n.strip() for n in str(row.get("connects") or "").split(",") if n.strip() in names]
        linked += [s["name"] for s in streets_of(town)
                   if spot.street in [n.strip() for n in str(s.get("connects") or "").split(",")]]
        for n in dict.fromkeys(linked):
            if n != spot.street:
                out.append((street_id(town.id, n), MIN_STREET, "street"))
        for direction, st in town_exits(town).items():
            if st != spot.street:
                continue
            out.append((wild_id(town.id, direction), MIN_TOWN_EDGE, "wild"))
            road = road_to(town, direction)
            dest = world.entities.get(road.get("leads_to")) if road else None
            if dest is not None and dest.type == "town":
                hours = _road_hours(world, town, road)
                out.append((street_id(dest.id, arrival_street(world, dest, town.id)), int(hours * 60),
                            f"road:{direction}"))
    elif spot.kind == "wild":
        from game import dungeons as D
        st = town_exits(spot.town).get(spot.direction) or first_street(spot.town)
        out.append((street_id(spot.town.id, st), MIN_TOWN_EDGE, "back"))
        state = getattr(world, "_state_for_places", None)
        for e in D.here_from_wild(world, state, spot.town.id, spot.direction) if state is not None else []:
            if not D.is_discovered(state, e):
                continue
            if e.type == "landmark":
                out.append((D.landmark_id(e.id), int(e.fields.get("travel_minutes") or 60), "landmark"))
            elif D.ensure_rooms(world, e):
                out.append((D.room_id(e.id, D.entrance(e)), 45, "dungeon"))
        from game import geography as G
        from game import hexes as H
        p = G.party_position_of(world, spot)
        if p is not None:
            out.append((H.hex_of_point(world, p), MIN_TOWN_EDGE, "open"))
    elif spot.kind == "landmark":
        from game import dungeons as D
        lm = spot.extra["landmark"]
        if spot.town is not None:
            out.append((wild_id(spot.town.id, spot.direction), int(lm.fields.get("travel_minutes") or 60), "back"))
        from game import geography as G
        from game import hexes as H
        p = G.landmark_position(world, lm)
        if p is not None:
            out.append((H.hex_of_point(world, p), MIN_TOWN_EDGE, "open"))
        d = world.entities.get(lm.fields.get("dungeon") or "")
        if d is not None and D.ensure_rooms(world, d):
            out.append((D.room_id(d.id, D.entrance(d)), MIN_DOOR, "dungeon"))
    elif spot.kind == "dungeon":
        from game import dungeons as D
        d, name = spot.extra["dungeon"], spot.extra["room"]
        state = getattr(world, "_state_for_places", None)
        nxt = D.visible_links(state, d, name) if state is not None else D.links(d, name)
        for n in nxt:
            out.append((D.room_id(d.id, n), MIN_STREET, "room"))
        if name == D.entrance(d):
            outside = D.outside_of(world, d)
            if outside:
                out.append((outside, MIN_DOOR * 5, "leave"))
    elif spot.kind == "hex":
        from game import dungeons as D
        from game import hexes as H
        state = getattr(world, "_state_for_places", None)
        here = H.things_in(world, spot.extra["q"], spot.extra["r"])
        centre = H.center(world, spot.extra["q"], spot.extra["r"])
        for town in here["towns"]:
            out.append((street_id(town.id, town_gate(world, town, centre)), MIN_TOWN_EDGE, "enter_town"))
        for lm in here["landmarks"]:
            if state is None or D.is_discovered(state, lm):
                out.append((D.landmark_id(lm.id), 30, "landmark"))
        for d in here["dungeons"]:
            if (state is None or D.is_discovered(state, d)) and D.ensure_rooms(world, d):
                out.append((D.room_id(d.id, D.entrance(d)), 30, "dungeon"))
    return out


def route(world, start: str, goal: str) -> list[tuple[str, int, str]]:
    """Quickest way from one location to another: [(next location, minutes, how), ...]."""
    start = parse(world, start).id
    goal = parse(world, goal).id or goal
    if not start or not goal or start == goal:
        return []
    import heapq
    best = {start: (0, None, 0, "")}
    heap = [(0, start)]
    while heap:
        cost, loc = heapq.heappop(heap)
        if loc == goal:
            break
        if cost > best[loc][0]:
            continue
        for nxt, mins, how in neighbors(world, loc):
            c = cost + mins
            if nxt not in best or c < best[nxt][0]:
                best[nxt] = (c, loc, mins, how)
                heapq.heappush(heap, (c, nxt))
    if goal not in best:
        return []
    steps = []
    loc = goal
    while best[loc][1] is not None:
        _c, prev, mins, how = best[loc]
        steps.append((loc, mins, how))
        loc = prev
    return list(reversed(steps))


def route_text(world, start: str, goal: str) -> str:
    steps = route(world, start, goal)
    if not steps:
        return ""
    words = []
    for loc, mins, how in steps:
        spot = parse(world, loc)
        if how.startswith("road"):
            words.append(f"take the road to {spot.town.name} ({mins // 60} h)")
        elif how == "wild":
            words.append(f"leave town to the {spot.direction.lower()}")
        elif spot.kind == "building":
            words.append(f"go into {spot.name}")
        elif spot.kind == "street":
            words.append(f"walk to {spot.street}")
    total = sum(m for _l, m, _h in steps)
    span = f"{total // 60} h {total % 60} min" if total >= 60 else f"{total} min"
    text = ", then ".join(words)
    return text[:1].upper() + text[1:] + f". About {span}."


# ======================================================================
# Moving
# ======================================================================
def travel_minutes(world, start, dest) -> int:
    """Minutes from one place to another (entities, Spots or location strings)."""
    a = start.id if hasattr(start, "id") else str(start or "")
    b = dest.id if hasattr(dest, "id") else str(dest or "")
    b = location_of(world, b) or b
    steps = route(world, a, b)
    if steps:
        return sum(m for _l, m, _h in steps)
    return 0 if parse(world, a).id == parse(world, b).id else MINUTES_BETWEEN_TOWNS


def enter(world, state, loc: str, bus=None, minutes: int = 0, announce: bool = True, walking: bool = False) -> bool:
    """Arrive somewhere (after any time has already passed). Announces location.entered."""
    spot = parse(world, loc)
    if spot.kind == "nowhere":
        return False
    before = parse(world, state.location) if state.location else None
    if spot.kind == "building" and not building_rooms(spot.building):
        from game import rooms as R
        R.ensure(world, spot.building)
        spot = parse(world, loc)
    same_building = before is not None and before.kind == "building" and before.building is not None \
        and before.building.id == spot.building.id if spot.kind == "building" else False
    if same_building:
        announce = False
    state.location = spot.id
    from game import ticker
    ticker.run(state)                        # whatever changes with time catches up on arrival
    for v in (spot.id, spot.town.id if spot.town is not None else ""):
        if v and v not in state.visited:
            state.visited.append(v)
    if spot.town is not None and spot.kind in ("street", "building"):
        state.last_town = spot.town.id
        came = before is None or before.town is None or before.town.id != spot.town.id     # (into town)
        if came and any(not c.get("paid") for c in (getattr(state, "holdings", None) or {}).get("claims") or []):
            try:                             # a reminder of a claim to register here (game/estate.py)
                from game import estate
                for text in estate.arrived(world, state, spot.town, bus):
                    if bus is not None:
                        bus.emit("log", kind="system", text=text)
            except Exception:  # noqa: BLE001
                pass
    try:
        from game import geography
        geography.reveal_here(world, state)
    except Exception:          # noqa: BLE001 - the map is never worth failing a move over
        pass
    state.save()
    if bus is not None and announce:
        bus.emit("location.entered", location=spot.building.id if spot.building is not None else spot.id,
                 spot=spot.id, town=spot.town.id if spot.town is not None else "", place_name=spot.name,
                 kind=spot.kind, minutes=minutes, walking=walking)
    return True


def travel(world, state, dest_id: str, bus=None, reason: str = "") -> bool:
    """Go somewhere directly (no encounters on the way): passes the route's time.
    Road journeys with encounters go through game/travel.py instead."""
    dest = location_of(world, dest_id) or dest_id
    spot = parse(world, dest)
    if spot.kind in ("nowhere", "road"):
        return False
    here = current(world, state)
    minutes = travel_minutes(world, here.id, spot.id)
    if minutes:
        state.advance(minutes, reason or f"travel to {spot.name}")
    return enter(world, state, spot.id, bus, minutes)


# ======================================================================
# What the screens show
# ======================================================================
def scene_for(world, spot, state) -> dict:
    time = state.time_of_day
    if not isinstance(spot, Spot):
        spot = parse(world, spot.id) if spot is not None else Spot("nowhere", "")
    if spot.kind == "building":
        b = spot.building
        place = PLACE_FOR_KIND.get(b.fields.get("kind") or "Other", "House")
        row = room_here(spot)
        if row is not None:
            from game import rooms as R
            t = R.tile(world, row.get("tile") or "")
            if t and t.get("scene"):
                place = t["scene"]
            elif row is not building_rooms(b)[0] and row.get("type") == "Private":
                place = "Inn" if (b.fields.get("kind") or "") == "Inn" else "House"
        return {"place": place, "walls": WALLS.get(b.fields.get("interior") or "Wooden", "Wooden"), "time": time}
    if spot.kind == "street":
        return {"place": "Town street", "walls": "", "time": time}
    if spot.kind == "dungeon":
        from game import dungeons as D
        return {"place": D.SCENE.get(spot.extra["dungeon"].fields.get("kind") or "", "Dungeon"), "walls": "",
                "time": "Night"}
    if spot.kind == "hex":
        from game import hexes as H
        terrain = H._terrain(spot.extra.get("biome") or "Plains")
        return {"place": TERRAIN_PLACE.get(terrain, "Plains"), "walls": "", "time": time}
    terrain = (spot.town.fields.get("terrain") if spot.town is not None else "") or "Plains"
    return {"place": TERRAIN_PLACE.get(terrain, "Plains"), "walls": "", "time": time}


def options(world, state) -> list[dict]:
    """Every way to move from here, grouped for the Move window and Location panel:
    {"group", "label", "target", "minutes", "how", "enabled", "note"}."""
    spot = current(world, state)
    out = []
    if spot.kind == "voyage":
        j = state.journey or {}
        left = int(j.get("days", 0)) - int(j.get("done", 0))
        out.append({"group": "Journey", "label": "Travel on", "target": "voyage:continue", "how": "journey",
                    "enabled": True, "note": f"{left} day{'s' if left != 1 else ''} to go", "minutes": left * 1440})
        return out
    if spot.kind == "road":
        j = state.journey or {}
        dest = world.entities.get(j.get("to"))
        start = world.entities.get(j.get("from"))
        out.append({"group": "Journey", "label": f"Keep going to {dest.name if dest else 'the next town'}",
                    "target": "journey:continue", "how": "journey", "enabled": True, "note": "",
                    "minutes": int((j.get("hours", 0) - j.get("done", 0)) * 60)})
        out.append({"group": "Journey", "label": f"Turn back to {start.name if start else 'town'}",
                    "target": "journey:back", "how": "journey", "enabled": True, "note": "",
                    "minutes": int(j.get("done", 0) * 60)})
        return out
    minute = state.minute_of_day
    for loc, mins, how in neighbors(world, spot.id):
        dest = parse(world, loc)
        if how == "door" and dest.kind == "building":
            b = dest.building
            ok = is_open(b, minute)
            out.append({"group": "Places", "label": f"Go into {b.name}", "target": loc, "minutes": mins,
                        "how": how, "enabled": ok,
                        "note": "" if ok else f"closed, opens {opens_at(b)}"})
        elif how == "door":
            out.append({"group": "Leave", "label": f"Leave to {dest.street}", "target": loc, "minutes": mins,
                        "how": how, "enabled": True, "note": ""})
        elif how == "street":
            out.append({"group": "Streets", "label": f"Walk to {dest.street}", "target": loc, "minutes": mins,
                        "how": how, "enabled": True, "note": ""})
        elif how == "wild":
            noun = TERRAIN_NOUN.get(spot.town.fields.get("terrain") or "Plains", "wilds")
            out.append({"group": "Leave town", "label": f"Head {dest.direction.lower()} into the {noun}",
                        "target": loc, "minutes": mins, "how": how, "enabled": True, "note": "no road"})
        elif how.startswith("road"):
            road = road_to(spot.town, how.split(":", 1)[1])
            out.append({"group": "Leave town", "label": f"Take the {road['direction'].lower()} road to {dest.town.name}",
                        "target": f"road:{spot.town.id}:{road['direction']}", "minutes": mins, "how": how,
                        "enabled": True, "note": f"{mins // 60} h, {int(road.get('danger', 20) or 0)}% encounters"})
        elif how == "back" and spot.kind == "landmark":
            out.append({"group": "Leave", "label": f"Head back toward {spot.town.name}", "target": loc,
                        "minutes": mins, "how": how, "enabled": True, "note": ""})
        elif how == "back":
            out.append({"group": "Leave", "label": f"Return to {spot.town.name}", "target": loc, "minutes": mins,
                        "how": how, "enabled": True, "note": ""})
        elif how == "landmark":
            out.append({"group": "Places", "label": f"Go to {dest.name}", "target": loc, "minutes": mins,
                        "how": how, "enabled": True, "note": (dest.extra["landmark"].fields.get("kind") or "").lower()})
        elif how == "dungeon":
            d = dest.extra["dungeon"]
            out.append({"group": "Places", "label": f"Enter {d.name}", "target": loc, "minutes": mins,
                        "how": how, "enabled": True, "note": f"{(d.fields.get('kind') or 'dungeon').lower()}, "
                                                             f"level {d.fields.get('level') or 1}"})
        elif how == "room":
            note = ""
            if dest.kind == "building":
                f0, f1 = int(spot.extra.get("floor") or 0), int(dest.extra.get("floor") or 0)
                note = "upstairs" if f1 > f0 else "downstairs" if f1 < f0 else ""
            label = f"Go to the {dest.extra.get('room') or dest.name}" if dest.kind == "building" \
                else f"Go to the {dest.name.lower()}"
            out.append({"group": "Rooms", "label": label, "target": loc, "minutes": mins, "how": how,
                        "enabled": True, "note": note})
        elif how == "leave":
            out.append({"group": "Leave", "label": "Leave the dungeon", "target": loc, "minutes": mins,
                        "how": how, "enabled": True, "note": ""})
        elif how == "open":
            out.append({"group": "Leave", "label": "Strike out across open country", "target": loc,
                        "minutes": mins, "how": how, "enabled": True, "note": "pick a destination on the map"})
        elif how == "enter_town":
            out.append({"group": "Places", "label": f"Go into {dest.town.name}", "target": loc, "minutes": mins,
                        "how": how, "enabled": True, "note": dest.street})
    return out


def _walkable(world) -> bool:
    try:
        from game import worldmap
        return worldmap.walkable(world)
    except Exception:  # noqa: BLE001
        return False


def _story_activities(world, state, spot) -> list[dict]:
    """Looking into something a quest asks about here; the notice board; reading what the party carries."""
    out = []
    try:
        from game import books, quests
        book = quests.QuestBook(world, state)
        for q, i, o in book.investigate_here(spot.id, spot.town.id if spot.town is not None else "")[:3]:
            out.append({"label": f"Investigate: {o['text']} (1 hour)", "target": f"investigate:{q['id']}:{i}",
                        "enabled": True, "note": o.get("hint") or "", "group": "Quests"})
        b = spot.building
        if b is not None and ((b.fields.get("kind") or "") in ("Inn", "Tavern") or
                              "Notice board" in (b.fields.get("facilities") or [])):
            out.append({"label": "Read the notice board", "target": "notice", "enabled": True,
                        "note": "rumors and work", "group": "Here"})
        shown = 0
        for iid, n in sorted((state.inventory or {}).items()):
            it = world.entities.get(iid)
            if n > 0 and it is not None and books.is_book(it) and not books.has_read(state, it.id) and shown < 3:
                out.append({"label": f"Read {it.name}", "target": f"read:{it.id}", "enabled": True,
                            "note": f"about {books.read_minutes(it)} min", "group": "Books"})
                shown += 1
    except Exception:  # noqa: BLE001 - never lose the menu over a story
        pass
    return out


def activities(world, state) -> list[dict]:
    """Things to do here other than moving: explore, rest, rent a room."""
    spot = current(world, state)
    out = []
    if spot.kind in ("nowhere", "voyage"):      # aboard, the days pass with a night's rest each
        return out
    if spot.kind in ("wild", "hex"):
        out.append({"label": "Explore (1 hour)", "target": "explore", "enabled": True,
                    "note": "find what's out here", "group": "Here"})
    if spot.kind in ("wild", "road", "landmark", "hex") and _walkable(world):
        out.append({"label": "Search the land about (20 min)", "target": "search:land", "enabled": True,
                    "note": "hidden veins and rare herbs", "group": "Here"})
    if spot.kind in ("wild", "road", "landmark", "hex"):
        out.append({"label": "Cook over a campfire", "target": "craft:campfire", "enabled": True,
                    "note": "meals from what you've gathered", "group": "Here"})
        out.append({"label": "Make camp for the night", "target": "rest:camp", "enabled": True,
                    "note": "long rest, may be disturbed", "group": "Rest"})
    if spot.kind in ("landmark", "dungeon"):
        from game import dungeons as D
        items, gold, _owner, _key = D.loot_here(world, state, spot.id)
        if items or gold:
            out.append({"label": "Take the treasure", "target": "loot", "enabled": True, "note": "", "group": "Here"})
        if spot.kind == "dungeon":
            sp, label = D.special_here(world, state, spot.id)
            if sp:
                out.append({"label": label, "target": "special", "enabled": True, "note": sp.lower(),
                            "group": "Here"})
            out.append({"label": "Search for hidden doors and traps (10 min)", "target": "search", "enabled": True,
                        "note": "Perception", "group": "Here"})
    if spot.kind == "building" and spot.building is not None:
        from game import destruction
        if destruction.is_ruin(spot.building.id, state):           # a ruin: nothing to be had here
            return [{"label": "Short rest (1 hour)", "target": "rest:short", "enabled": True,
                     "note": "spend hit dice", "group": "Rest"}]
    if spot.kind == "street" and spot.town is not None:
        from game import homes
        mine = homes.home_in(world, spot.town)
        cost = homes.price_in(world, spot.town)
        if mine is None and cost:
            out.append({"label": f"Buy a house on {spot.street} ({cost} gp)", "target": "home:buy",
                        "enabled": state.copper >= cost * 100, "note": "a home of your own", "group": "Here"})
    if world.rules.get("survival"):              # hunger and thirst (game/survival.py)
        if spot.kind in ("street", "building") and spot.town is not None:
            out.append({"label": "Refill your waterskins at the well", "target": "survival:refill", "enabled": True,
                        "note": "clean water", "group": "Supplies"})
        if spot.kind == "building" and (spot.building.fields.get("kind") or "") in ("Inn", "Tavern"):
            out.append({"label": "Buy everyone a hot meal (3 sp each)", "target": "survival:meal", "enabled": True,
                        "note": "fed, with a little to spare", "group": "Supplies"})
    try:                                         # the party's land and buildings (game/estate.py)
        from game import estate as ES
        h = getattr(state, "holdings", None) or {}
        if h.get("claims") or h.get("workers"):
            out.append({"label": "Your land, buildings and workers", "target": "estate", "enabled": True,
                        "note": f"{len(h.get('claims') or [])} claim(s)", "group": "Land"})
        if spot.kind in ("hex", "wild"):
            out.append({"label": "Stake a claim here", "target": "estate:stake", "enabled": True,
                        "note": "mark it out, then register it at a town hall", "group": "Land"})
        if spot.kind == "building" and spot.building.fields.get("claim"):
            bid = spot.building.id
            if any(ES.output(state, bid).values()):
                out.append({"label": "Collect what's been made here", "target": f"estate:collect:{bid}",
                            "enabled": True, "note": "", "group": "Land"})
    except Exception:  # noqa: BLE001
        pass
    if spot.kind == "building" and spot.building.fields.get("owner"):
        from game import homes
        have = homes.perks(world, spot.building)
        if homes.can_extend(spot.building):
            out.append({"label": "Build onto your home", "target": "home:build", "enabled": True,
                        "note": "add rooms", "group": "Home"})
        out.append({"label": "Furnish it", "target": "home:furnish", "enabled": True,
                    "note": "furniture and workbenches", "group": "Home"})
        out.append({"label": "Sleep at home (free)", "target": "rest:home", "enabled": bool(have.get("Rest")),
                    "note": "long rest" if have.get("Rest") else
                    ("build a bedroom first" if homes.can_extend(spot.building) else "furnish it with beds first"),
                    "group": "Rest"})
    if spot.kind == "building":
        b = spot.building
        price = float(b.fields.get("inn_price") or 0)
        if price > 0:
            from game.state import money_text
            out.append({"label": f"Rent rooms for the night ({money_text(int(price * 100))})", "target": "rest:inn",
                        "enabled": state.copper >= int(price * 100), "note": "long rest", "group": "Rest"})
    out.append({"label": "Short rest (1 hour)", "target": "rest:short", "enabled": True,
                "note": "spend hit dice", "group": "Rest"})
    out += _story_activities(world, state, spot)
    try:                                         # animals, carts and boats (game/animals.py)
        from game import animals
        out += animals.activities(world, state, spot)
    except Exception:  # noqa: BLE001
        pass
    if spot.kind in ("street", "building") and spot.town is not None:     # festivals and raids (game/townevents.py)
        try:
            from game import townevents as TE
            f = TE.festival_at(world, spot.town, state.minutes)
            if f is not None:
                out.append({"label": f"The {f.name.lower()}: contests and stalls", "target": "festival",
                            "enabled": True, "note": ", ".join(TE.contest_name(c) for c in f.contests), "group": "Here"})
            if TE.raid_here(world, state) is not None:
                out.append({"label": "Fight the raiders alongside the guard", "target": "raid:fight", "enabled": True,
                            "note": "for gold, standing and loot", "group": "Here"})
        except Exception:  # noqa: BLE001
            pass
    if spot.kind == "building":                  # games and the arena (game/tablegames, game/arena.py)
        try:
            from game import arena, tablegames
            gs = tablegames.games_at(world, spot.building)
            if gs:
                out.append({"label": "Play at the tables", "target": "games", "enabled": True,
                            "note": ", ".join(tablegames.GAMES[g].title.lower() for g in gs[:3]) +
                                    (" and more" if len(gs) > 3 else ""), "group": "Here"})
            if arena.is_arena(spot.building):
                day = arena.next_day(spot.building, state.day)
                out.append({"label": "The arena: tournaments and bouts", "target": "arena", "enabled": True,
                            "note": "a tournament today!" if day == state.day else f"next tournament: day {day}",
                            "group": "Here"})
        except Exception:  # noqa: BLE001
            pass
    try:                                         # crimes, and answering for them (game/law.py)
        from game import law
        out += law.activities(world, state, spot)
    except Exception:  # noqa: BLE001
        pass
    return out


def short_description(desc: str, most: int = 170) -> str:
    """A place's description cut to a line or so for the log as the party walks in: its first sentence, and
    of a street's list of what's along it, the first three."""
    desc = " ".join((desc or "").split())
    along = ""
    if " Along it: " in desc:
        desc, rest = desc.split(" Along it: ", 1)
        names = [n.strip(" .") for n in rest.split(",") if n.strip(" .")]
        if names:
            along = " Along it: " + ", ".join(names[:3]) + (f" and {len(names) - 3} more." if len(names) > 3 else ".")
    first = desc
    for stop in (". ", "! ", "? "):
        i = desc.find(stop)
        if 0 < i < len(first):
            first = desc[:i + 1]
    if len(first) > most:
        cut = first[:most].rsplit(" ", 1)[0]
        first = cut.rstrip(",;:") + "…"
    return first + along


def describe(world, state) -> dict:
    """What the Location panel shows."""
    spot = current(world, state)
    if spot.kind == "nowhere":
        return {"breadcrumb": [], "name": "Nowhere yet",
                "description": "This world has no towns or buildings. Create a town and a building or two "
                               "(Create in the top bar), and put some NPCs in them.",
                "people": [], "exits": [], "scene": {"place": "Plains", "walls": "", "time": state.time_of_day},
                "id": "", "kind": "nowhere"}
    crumbs = []
    town = spot.town
    from game import geography
    cont = geography.continent_of_town(world, town) if town is not None else spot.extra.get("continent")
    if cont is not None:
        crumbs.append(cont.name)
    if spot.kind == "hex":
        reg = spot.extra.get("region")
        if reg is not None:
            if reg.fields.get("realm"):
                crumbs.append(reg.fields["realm"])
            crumbs.append(reg.name)
    if town is not None:
        region = geography.region_of_town(world, town)
        if region is not None and region.fields.get("realm"):
            crumbs.append(region.fields["realm"])
        if town.fields.get("region") or region is not None:
            crumbs.append(town.fields.get("region") or region.name)
        crumbs.append(town.name)
    if spot.kind == "building":
        crumbs.append(spot.street)
        b = spot.building
        rows = building_rooms(b)
        row = room_here(spot)
        if row is not None and row is not rows[0]:
            from game import rooms as R
            crumbs.append(b.name)
            floors_here = R.floors(rows)
            desc = (row.get("description") or f"The {row['name'].lower()}.")
            if len(floors_here) > 1:
                desc += f" ({R.floor_name(int(row.get('floor') or 0))}.)"
        else:
            desc = b.description or f"A {str(b.fields.get('kind') or 'building').lower()} on {spot.street}."
            if row is not None and row.get("description"):
                desc += f" You're in the {row['name'].lower()}: {row['description'][:1].lower()}{row['description'][1:]}"
            from game import destruction
            if destruction.is_ruin(b.id, state):                  # fallen (game/destruction.py)
                left = destruction.days_left(world, state, b.id) or 0
                desc = (f"The ruins of {b.name}: broken walls, fallen beams and rubble, open to the sky. Its people "
                        f"are rebuilding it" + (f" (about {left:.0f} days' work left)." if left >= 1 else
                                                 ", nearly done."))
        if not is_open(b, state.minute_of_day):
            desc += f" (Closed for the night. Opens at {opens_at(b)}.)"
    elif spot.kind == "street":
        desc = (town.description + " " if town.description and spot.street == first_street(town) else "")
        shops = [b.name for b in buildings_on(world, town, spot.street)]
        desc += f"{spot.street}, {town.name}." + (f" Along it: {', '.join(shops)}." if shops else "")
    elif spot.kind == "wild":
        terrain = town.fields.get("terrain") or "Plains"
        desc = (f"Open {TERRAIN_NOUN.get(terrain, 'country')} {spot.direction.lower()} of {town.name}, away from "
                f"the road. Explore to see what's out here; anything could be.")
    elif spot.kind == "hex":
        from game import hexes as H
        b = spot.extra.get("biome") or "Plains"
        desc = (f"Open {H.NOUN.get(b, 'country')}, far from any road. Explore to see what's here, or pick "
                f"somewhere on the map to head for.")
        near = _nearest_town(world, H.center(world, spot.extra["q"], spot.extra["r"]))
        if near is not None:
            desc += f" The nearest town is {near[0].name}, about {near[1]:.0f} miles {near[2].lower()}."
    elif spot.kind == "landmark":
        lm = spot.extra["landmark"]
        desc = lm.description or f"A {str(lm.fields.get('kind') or 'landmark').lower()} out in the wilds."
        if spot.town is not None:
            crumbs.append(spot.direction)
    elif spot.kind == "dungeon":
        from game import dungeons as D
        d, name = spot.extra["dungeon"], spot.extra["room"]
        r = D.room(d, name) or {}
        crumbs.append(d.name)
        desc = r.get("description") or (d.description if name == D.entrance(d) else f"The {name.lower()}.")
        p = D.progress(state, d)
        if r.get("enemy") and name in p["cleared"]:
            desc += " The fight here is over."
    elif spot.kind == "voyage":
        j = state.journey or {}
        from game import passage
        th = passage.THEMES.get(j.get("method") or "Boat", passage.THEMES["Boat"])
        dest = spot.extra.get("to")
        desc = (f"Day {j.get('done', 0)} of {j.get('days', 0)} aboard {th['noun']}"
                f"{', bound for ' + dest.name if dest else ''}. There's nothing to do but {th['verb']} on.")
    else:
        j = state.journey or {}
        dest = world.entities.get(j.get("to"))
        name = f"The road to {dest.name}" if dest else "On the road"
        spot.name = name
        desc = (f"{j.get('done', 0):g} of {j.get('hours', 0):g} hours along the road"
                f"{' to ' + dest.name if dest else ''}.")
    from game import schedules
    people = [{"id": n.id, "name": n.name, "npc": n.id,
               "role": schedules.activity_now(n, state.minute_of_day) or n.fields.get("occupation") or ""}
              for n in people_in(world, spot, state)]
    exits = [{"name": o["label"], "kind": o["how"], "target": o["target"], "enabled": o["enabled"],
              "note": o["note"], "group": o["group"]} for o in options(world, state)]
    return {"breadcrumb": crumbs, "name": spot.name, "description": desc, "people": people, "exits": exits,
            "activities": activities(world, state),
            "scene": scene_for(world, spot, state), "id": spot.id, "kind": spot.kind,
            "building": spot.building.id if spot.building is not None else ""}


def _nearest_town(world, p) -> tuple | None:
    """(town, miles, direction from p) for the closest town on the map."""
    from game import geography as G
    best = None
    for tid, tp in G.town_positions(world).items():
        d = G.distance(p, tp)
        if best is None or d < best[1]:
            best = (tid, d, tp)
    if best is None:
        return None
    dx, dy = best[2][0] - p[0], best[2][1] - p[1]
    direction = max(G.VECTORS, key=lambda k: G.VECTORS[k][0] * dx + G.VECTORS[k][1] * dy)
    return world.entities.get(best[0]), best[1], direction


__all__ = ["Spot", "parse", "current", "describe", "options", "route", "route_text", "travel", "enter",
           "neighbors", "is_open", "street_id", "wild_id", "road_id", "town_exits", "roads_of", "DIRECTIONS"]
