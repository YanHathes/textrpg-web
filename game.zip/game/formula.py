"""Safe formulas: "floor((value - 10) / 2)", "player.str * 2 + roll('1d6')".

Formulas are parsed with Python's own expression grammar, but only a small,
whitelisted set of operations is allowed (no imports, attribute tricks or
function calls beyond the ones listed in FUNCTIONS). Variables come from a
dictionary; dotted names like player.str look up nested dictionaries.
"""
from __future__ import annotations

import ast
import math
import operator
import random
from typing import Any

from game import dice

_BIN = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_UNARY = {ast.USub: operator.neg, ast.UAdd: operator.pos, ast.Not: operator.not_}
_CMP = {
    ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Lt: operator.lt, ast.LtE: operator.le,
    ast.Gt: operator.gt, ast.GtE: operator.ge,
}


class FormulaError(ValueError):
    pass


def _roll(text, _rng=None):
    return dice.roll(str(text), _rng).total


FUNCTIONS = {
    "floor": math.floor, "ceil": math.ceil, "round": round, "abs": abs,
    "min": min, "max": max, "int": int, "clamp": lambda v, lo, hi: max(lo, min(hi, v)),
    "roll": _roll,
}


def parse(text: str) -> ast.Expression:
    try:
        tree = ast.parse(str(text).strip(), mode="eval")
    except SyntaxError as exc:
        raise FormulaError(f"Can't read formula: {exc.msg}") from None
    _check(tree.body)
    return tree


def is_valid(text: str) -> bool:
    try:
        parse(text)
        return True
    except FormulaError:
        return False


def variables(text: str) -> set[str]:
    """Names (including dotted names) a formula refers to."""
    names: set[str] = set()

    def visit(node):
        if isinstance(node, ast.Name) and node.id not in FUNCTIONS and node.id not in ("True", "False"):
            names.add(node.id)
            return
        if isinstance(node, ast.Attribute):
            dotted = _dotted(node)
            if dotted:
                names.add(dotted)
                return
        for child in ast.iter_child_nodes(node):
            visit(child)

    visit(parse(text).body)
    return names


def evaluate(text: str, values: dict[str, Any] | None = None, rng: random.Random | None = None) -> Any:
    tree = parse(text)
    return _eval(tree.body, values or {}, rng)


def _dotted(node) -> str | None:
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
        return ".".join(reversed(parts))
    return None


def _check(node) -> None:
    allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.BoolOp, ast.Compare, ast.Constant,
               ast.Name, ast.Load, ast.Attribute, ast.Call, ast.IfExp, ast.And, ast.Or,
               *tuple(_BIN), *tuple(_UNARY), *tuple(_CMP))
    for child in ast.walk(node):
        if not isinstance(child, allowed):
            raise FormulaError(f"'{type(child).__name__}' isn't allowed in formulas")
        if isinstance(child, ast.Call):
            if not isinstance(child.func, ast.Name) or child.func.id not in FUNCTIONS:
                raise FormulaError("Only these functions are allowed: " + ", ".join(sorted(FUNCTIONS)))
            if child.keywords:
                raise FormulaError("Functions take plain values only")
        if isinstance(child, ast.Attribute) and child.attr.startswith("_"):
            raise FormulaError("Names can't start with an underscore")
        if isinstance(child, ast.Name) and child.id.startswith("_"):
            raise FormulaError("Names can't start with an underscore")
        if isinstance(child, ast.Constant) and not isinstance(child.value, (int, float, str, bool)):
            raise FormulaError("Only numbers, text and true/false are allowed")
        if isinstance(child, ast.Constant) and isinstance(child.value, (int, float)) and abs(child.value) > 1e9:
            raise FormulaError("Number too large")
        if isinstance(child, ast.BinOp) and isinstance(child.op, ast.Pow):
            right = child.right
            if not (isinstance(right, ast.Constant) and isinstance(right.value, (int, float)) and abs(right.value) <= 10):
                raise FormulaError("Powers are limited to small constant exponents")


def _lookup(name: str, values: dict) -> Any:
    if name in values:
        return values[name]
    current: Any = values
    for part in name.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            raise FormulaError(f"Unknown name '{name}'")
    return current


def _eval(node, values, rng):
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        if node.id == "True":
            return True
        if node.id == "False":
            return False
        return _lookup(node.id, values)
    if isinstance(node, ast.Attribute):
        return _lookup(_dotted(node), values)
    if isinstance(node, ast.BinOp):
        left, right = _eval(node.left, values, rng), _eval(node.right, values, rng)
        try:
            return _BIN[type(node.op)](left, right)
        except ZeroDivisionError:
            raise FormulaError("Division by zero") from None
        except TypeError:
            raise FormulaError("Can't combine those values") from None
    if isinstance(node, ast.UnaryOp):
        return _UNARY[type(node.op)](_eval(node.operand, values, rng))
    if isinstance(node, ast.BoolOp):
        if isinstance(node.op, ast.And):
            result = True
            for v in node.values:
                result = _eval(v, values, rng)
                if not result:
                    return result
            return result
        result = False
        for v in node.values:
            result = _eval(v, values, rng)
            if result:
                return result
        return result
    if isinstance(node, ast.Compare):
        left = _eval(node.left, values, rng)
        for op, comp in zip(node.ops, node.comparators):
            right = _eval(comp, values, rng)
            if not _CMP[type(op)](left, right):
                return False
            left = right
        return True
    if isinstance(node, ast.IfExp):
        return _eval(node.body, values, rng) if _eval(node.test, values, rng) else _eval(node.orelse, values, rng)
    if isinstance(node, ast.Call):
        args = [_eval(a, values, rng) for a in node.args]
        if node.func.id == "roll":
            return _roll(args[0] if args else "1d20", rng)
        try:
            return FUNCTIONS[node.func.id](*args)
        except (TypeError, ValueError) as exc:
            raise FormulaError(f"{node.func.id}(): {exc}") from None
    raise FormulaError(f"Unsupported: {type(node).__name__}")
