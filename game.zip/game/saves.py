"""Save slots for a world's running game.

The game always keeps the live progress in <world>/state.json, <world>/party.json and
<world>/holdings.json (what the party owns: game/holdings.py). A save slot is a copy of those
files in <world>/saves/<slot>/, with a little description (meta.json). Loading copies them back.

The "autosave" slot is refreshed whenever something important happens.
In Hardcore worlds there are no manual saves: only the live game, which is wiped if
the whole party falls.
"""
from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path

from game.entities import slugify

FILES = ("state.json", "party.json", "holdings.json")
AUTOSAVE = "autosave"


def folder(world) -> Path:
    return Path(world.path) / "saves"


def hardcore(world) -> bool:
    return (world.rules.get("party_falls") or "") == "Hardcore"


def list_saves(world) -> list[dict]:
    out = []
    root = folder(world)
    if not root.exists():
        return out
    for d in root.iterdir():
        meta_path = d / "meta.json"
        if not d.is_dir() or not meta_path.exists():
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        meta["slot"] = d.name
        out.append(meta)
    return sorted(out, key=lambda m: m.get("saved", ""), reverse=True)


def describe(world, state, members: list[dict]) -> dict:
    from game import places
    spot = places.current(world, state)
    where = spot.name + (f", {spot.town.name}" if spot.town is not None and spot.kind == "building" else "")
    party = ", ".join(f"{m.get('name')} ({m.get('level', 1)})" for m in members[:6])
    return {"clock": state.clock_text(), "where": where, "party": party, "gold": state.money_text()}


def save(world, state, members: list[dict], name: str, slot: str | None = None) -> str:
    """Write a save. Returns the slot name."""
    state.save()
    from game import holdings
    holdings.save(world, state)
    slot = slot or (AUTOSAVE if name == AUTOSAVE else slugify(name) or "save")
    d = folder(world) / slot
    d.mkdir(parents=True, exist_ok=True)
    for f in FILES:
        src = Path(world.path) / f
        if src.exists():
            shutil.copy2(src, d / f)
    meta = {"name": name, "saved": datetime.now().isoformat(timespec="seconds"),
            **describe(world, state, members)}
    (d / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return slot


def autosave(world, state, members: list[dict]) -> None:
    save(world, state, members, AUTOSAVE, AUTOSAVE)


def load(world, slot: str) -> bool:
    d = folder(world) / slot
    if not (d / "meta.json").exists():
        return False
    for f in FILES:
        src = d / f
        dst = Path(world.path) / f
        if src.exists():
            shutil.copy2(src, dst)
        elif dst.exists():
            dst.unlink()
    return True


def delete(world, slot: str) -> None:
    d = folder(world) / slot
    if d.exists():
        shutil.rmtree(d)


def wipe_run(world) -> None:
    """Hardcore: the party is gone. Delete the live game and every save of it."""
    for f in FILES:
        p = Path(world.path) / f
        if p.exists():
            p.unlink()
    root = folder(world)
    if root.exists():
        shutil.rmtree(root)
    # an empty party that stays empty: the next party is created by the player
    (Path(world.path) / "party.json").write_text(json.dumps({"members": [], "new_run": True}), encoding="utf-8")


def new_run(world) -> None:
    """Game over (not Hardcore): start again with a new party. The live game is cleared,
    saves are kept so an old run can still be loaded."""
    for f in FILES:
        p = Path(world.path) / f
        if p.exists():
            p.unlink()
    (Path(world.path) / "party.json").write_text(json.dumps({"members": [], "new_run": True}), encoding="utf-8")
