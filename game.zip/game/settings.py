"""Persistent program settings, stored as JSON in data/settings.json."""
from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

# Bump this when the default panel arrangement changes, so old saved layouts
# are discarded instead of restoring into a broken arrangement.
LAYOUT_VERSION = 2

DEFAULTS: dict[str, Any] = {
    "game_title": "YanCo Branded RPG",
    "ui_scale": 100,            # percent, applied at startup
    "log_font_size": 11,        # points
    "log_font": "",             # empty = automatic monospace font
    "theme_overrides": {},      # color key -> "#rrggbb"
    "layout_state": None,       # base64 Qt dock state
    "window_geometry": None,    # base64 Qt window geometry
    "layout_version": LAYOUT_VERSION,
    "current_world": "",        # slug of the open world
    "show_splash": True,        # the title screen while the game starts
    "ui_mode": "Map",           # Map: full-screen walking map with a menu; Panels: the older docked panels;
                                # Handheld: the phone layout (map above, controls below; ui/handheld.py)
    "map_zoom": 2,              # walking map zoom (1-4)
    "gamepad": True,            # read game controllers (Xbox-style through XInput, others through pygame)
    "start_mode": "Windowed",   # Windowed, Maximized, Full screen
    "combat_speed": "Normal",   # Slow, Normal, Fast, Instant
    "arena": {},                # world slug -> last test-arena setup
    "combat_layout_state": None,  # base64 Qt dock state used during fights
    "backdrop_strength": 60,    # how visible the location picture behind the log is (0-100)
    "scene_preview": {},        # Settings > Scene: show a chosen place instead of the current one
    "sound_on": True,           # Settings > Sound
    "volume_master": 80,        # 0-100
    "volume_music": 55,
    "volume_effects": 80,
    "volume_ambience": 60,
    "weather_effects": True,    # rain, snow, fog and lightning drawn on the walking map
    "checks_mode": "Dice",      # Settings > Checks: Dice, Minigames, or By kind (fights always roll)
    "minigame_kinds": {"physical": True, "social": True, "knowledge": True, "tools": True, "saves": True},
    "minigame_slow": False,     # slower games that need no quick reflexes
}


class Settings:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.data: dict[str, Any] = copy.deepcopy(DEFAULTS)
        self.load()

    def load(self) -> None:
        if not self.path.exists():
            return
        try:
            loaded = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return  # unreadable settings: fall back to defaults
        if isinstance(loaded, dict):
            self.data.update(loaded)

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def get(self, key: str, default: Any = None) -> Any:
        if key in self.data:
            return self.data[key]
        return DEFAULTS.get(key, default)

    def set(self, key: str, value: Any, save: bool = True) -> None:
        self.data[key] = value
        if save:
            self.save()
