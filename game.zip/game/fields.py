"""Field definitions: the typed variables every entity is built from.

A FieldDef describes one variable: its key, label, type and rules. Templates
(see templates.py) are lists of FieldDefs grouped into wizard steps.

Field types
    number      int or decimal. Options: min, max, integer (bool), suffix
    text        single line
    longtext    multi-line
    bool        yes / no
    choice      one value from `options`  (allow_custom lets you type a new one)
    multichoice several values from `options` (allow_custom too)
    textlist    list of free text lines (dialogue, languages, tags...)
    dice        dice expression such as 2d6+3
    formula     formula text, evaluated by the Mechanics system
    link        id of another entity; `targets` = allowed entity types
    links       list of entity ids
    table       list of rows; `columns` = FieldDefs for each column
    statvalues  {stat key: number} using the world's Stat entities
    color       "#rrggbb"
    sprite      sprite id from the sprite library
    appearance  paper-doll description (body base, colors, hair...)
    loadout     {slot: item id} of equipped items
    point       {"x": miles, "y": miles}: a place on the world map
"""
from __future__ import annotations

import copy
import re
from dataclasses import dataclass, field
from typing import Any

from game import dice, formula

FIELD_TYPES = (
    "number", "text", "longtext", "bool", "choice", "multichoice", "textlist", "dice",
    "formula", "link", "links", "table", "statvalues", "color", "sprite", "appearance", "loadout", "point",
    "tree", "recipe",
)

_EMPTY_DEFAULTS = {
    "number": 0, "text": "", "longtext": "", "bool": False, "choice": "", "multichoice": [],
    "textlist": [], "dice": "", "formula": "", "link": None, "links": [], "table": [],
    "statvalues": {}, "color": "", "sprite": "", "appearance": {}, "loadout": {}, "point": {}, "tree": {},
    "recipe": {},
}

_COLOR = re.compile(r"^#[0-9a-fA-F]{6}$")


def variable_name(text: str) -> str:
    """'Burn Chance!' -> 'burn_chance'"""
    name = re.sub(r"[^0-9a-zA-Z]+", "_", str(text).strip().lower()).strip("_")
    if not name:
        return "field"
    if name[0].isdigit():
        name = "f_" + name
    return name


@dataclass
class FieldDef:
    key: str
    label: str
    type: str = "text"
    default: Any = None
    help: str = ""
    required: bool = False
    options: list = field(default_factory=list)
    allow_custom: bool = False
    min: float | None = None
    max: float | None = None
    integer: bool = True
    suffix: str = ""
    targets: list = field(default_factory=list)       # link/links: allowed entity types
    columns: list = field(default_factory=list)       # table: list[FieldDef]
    show_if: dict | None = None                       # {"field": key, "in": [...]} or {"field": key, "is": value}
    options_from: str = ""                            # dynamic options, e.g. "town.streets.name"
    sprite_kind: str = ""                             # sprite: which library category to offer
    placeholder: str = ""

    def __post_init__(self) -> None:
        if self.type not in FIELD_TYPES:
            raise ValueError(f"Unknown field type '{self.type}' for '{self.key}'")
        self.columns = [c if isinstance(c, FieldDef) else FieldDef.from_dict(c) for c in self.columns]

    # ---- serialization ------------------------------------------------
    @classmethod
    def from_dict(cls, data: dict) -> "FieldDef":
        known = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        if "label" not in known:
            known["label"] = str(known.get("key", "Field")).replace("_", " ").title()
        return cls(**known)

    def to_dict(self) -> dict:
        out: dict[str, Any] = {"key": self.key, "label": self.label, "type": self.type}
        for name, default in (("default", None), ("help", ""), ("required", False), ("options", []),
                              ("allow_custom", False), ("min", None), ("max", None), ("integer", True),
                              ("suffix", ""), ("targets", []), ("show_if", None), ("options_from", ""),
                              ("sprite_kind", ""), ("placeholder", "")):
            value = getattr(self, name)
            if value != default:
                out[name] = copy.deepcopy(value)
        if self.columns:
            out["columns"] = [c.to_dict() for c in self.columns]
        return out

    # ---- values ---------------------------------------------------------
    def empty(self) -> Any:
        v = self.default if self.default is not None else _EMPTY_DEFAULTS[self.type]
        if v is None or isinstance(v, (str, int, float, bool, tuple)):
            return v                                    # nothing to share: no copy needed
        if not v:
            return type(v)()                            # a fresh empty list or dict
        return copy.deepcopy(v)

    def visible(self, values: dict) -> bool:
        return condition_met(self.show_if, values)

    def coerce(self, value: Any) -> Any:
        """Turn loose input into the stored form (raises ValueError when impossible)."""
        t = self.type
        if value is None:
            return self.empty()
        if t == "number":
            if isinstance(value, str):
                value = value.strip()
                if value == "":
                    return self.empty()
            num = float(value)
            if self.integer:
                num = int(round(num))
            elif num.is_integer():
                num = int(num)
            return num
        if t in ("text", "longtext", "dice", "formula", "choice", "color", "sprite"):
            return str(value).strip() if t != "longtext" else str(value)
        if t == "bool":
            if isinstance(value, str):
                return value.strip().lower() in ("1", "true", "yes", "y", "on")
            return bool(value)
        if t in ("multichoice", "textlist", "links"):
            if isinstance(value, str):
                value = [v.strip() for v in value.split("\n" if t == "textlist" else ",")]
            return [str(v).strip() for v in value if str(v).strip()]
        if t == "link":
            return str(value) if value else None
        if t == "table":
            rows = []
            for row in value or []:
                rows.append({c.key: c.coerce(row.get(c.key)) for c in self.columns})
            return rows
        if t == "statvalues":
            out = {}
            for k, v in dict(value).items():
                if v in ("", None):
                    continue
                out[str(k)] = int(round(float(v)))
            return out
        if t in ("appearance", "loadout"):
            return {str(k): v for k, v in dict(value).items() if v not in (None, "")}
        if t == "recipe":                   # an item's own recipe (game/crafting.py): {} = the automatic one
            if not isinstance(value, dict) or not value.get("materials"):
                return {}
            mats = []
            for row in value.get("materials") or []:
                ref = row.get("item") if isinstance(row, dict) else (row[0] if row else "")
                n = row.get("count", 1) if isinstance(row, dict) else (row[1] if len(row) > 1 else 1)
                if ref:
                    try:
                        mats.append({"item": str(ref), "count": max(1, int(float(n or 1)))})
                    except (TypeError, ValueError):
                        mats.append({"item": str(ref), "count": 1})
            if not mats:
                return {}
            out = {"materials": mats}
            for k in ("station", "tool"):
                if value.get(k):
                    out[k] = str(value[k])
            for k in ("makes", "work", "dc"):
                try:
                    if value.get(k):
                        out[k] = max(0, float(value[k])) if k == "work" else max(1, int(float(value[k])))
                except (TypeError, ValueError):
                    pass
            return out
        if t == "tree":                     # structured data kept as it is (a conversation's nodes)
            if isinstance(value, str):
                import json
                try:
                    value = json.loads(value) if value.strip() else {}
                except ValueError:
                    return {}
            return copy.deepcopy(value) if isinstance(value, (dict, list)) else {}
        if t == "point":
            if isinstance(value, str):
                parts = [p for p in re.split(r"[,; ]+", value.strip()) if p]
                if not parts:
                    return {}
                value = {"x": parts[0], "y": parts[1] if len(parts) > 1 else 0}
            if isinstance(value, (list, tuple)):
                value = {"x": value[0], "y": value[1] if len(value) > 1 else 0}
            value = dict(value or {})
            if value.get("x") in (None, "") and value.get("y") in (None, ""):
                return {}
            return {"x": round(float(value.get("x") or 0), 2), "y": round(float(value.get("y") or 0), 2)}
        return value

    def validate(self, value: Any) -> list[str]:
        """Human-readable problems with an already-coerced value."""
        problems = []
        t = self.type
        blank = value in (None, "", [], {})
        if self.required and blank:
            problems.append(f"{self.label} is required")
            return problems
        if blank:
            return problems
        if t == "number":
            if self.min is not None and value < self.min:
                problems.append(f"{self.label} must be at least {_num(self.min)}")
            if self.max is not None and value > self.max:
                problems.append(f"{self.label} must be at most {_num(self.max)}")
        elif t == "dice" and not dice.is_valid(re.sub(r"\{[^{}]*\}", "1", str(value))):   # {scale}d6 is fine
            problems.append(f"{self.label}: '{value}' isn't a valid dice roll (try 2d6+3)")
        elif t == "formula" and not formula.is_valid(value):
            problems.append(f"{self.label}: that formula can't be read")
        elif t == "choice" and self.options and not self.allow_custom and value not in self.options:
            problems.append(f"{self.label}: '{value}' isn't one of the options")
        elif t == "multichoice" and self.options and not self.allow_custom:
            bad = [v for v in value if v not in self.options]
            if bad:
                problems.append(f"{self.label}: {', '.join(bad)} not allowed")
        elif t == "color" and not _COLOR.match(value):
            problems.append(f"{self.label}: colors look like #33cc77")
        elif t == "table":
            for i, row in enumerate(value, start=1):
                for col in self.columns:
                    for p in col.validate(row.get(col.key)):
                        problems.append(f"{self.label} row {i}: {p}")
        return problems

    def link_ids(self, value: Any) -> list[str]:
        """Entity ids referenced by this value (used for 'used by' tracking)."""
        t = self.type
        if t == "link":
            return [value] if value else []
        if t == "links":
            return list(value or [])
        if t == "loadout":
            return [v for v in (value or {}).values() if isinstance(v, str) and v]
        if t == "appearance":
            race = (value or {}).get("race")
            return [race] if race else []
        if t == "table":
            ids = []
            for row in value or []:
                for col in self.columns:
                    ids.extend(col.link_ids(row.get(col.key)))
            return ids
        if t == "tree":
            return tree_link_ids(value)
        if t == "recipe":
            ids = [r.get("item") for r in (value or {}).get("materials") or [] if isinstance(r, dict)]
            return [i for i in ids if i and not str(i).startswith("tag:")] + \
                ([value["tool"]] if (value or {}).get("tool") else [])
        return []


def tree_link_ids(value) -> list[str]:
    """Entity ids anywhere inside structured data: strings shaped like "type.slug" for a known type."""
    from game.templates import TYPE_ORDER
    prefixes = tuple(f"{t}." for t in TYPE_ORDER)
    out = []

    def walk(v):
        if isinstance(v, str):
            if v.startswith(prefixes) and " " not in v:
                out.append(v)
        elif isinstance(v, dict):
            for x in v.values():
                walk(x)
        elif isinstance(v, list):
            for x in v:
                walk(x)
    walk(value)
    return out


def _num(v: float) -> str:
    return str(int(v)) if float(v).is_integer() else str(v)


def condition_met(cond: dict | None, values: dict) -> bool:
    """show_if: {"field": f, "in": [...]} / {"field": f, "is": v} / {"field": f, "not_empty": true},
    or {"all": [condition, ...]} when several must hold."""
    if not cond:
        return True
    if "all" in cond:
        return all(condition_met(c, values) for c in cond["all"])
    other = values.get(cond.get("field"))
    if "in" in cond:
        if isinstance(other, list):
            return any(o in cond["in"] for o in other)
        return other in cond["in"]
    if "is" in cond:
        return other == cond["is"]
    if "not_empty" in cond:
        return bool(other)
    return True
