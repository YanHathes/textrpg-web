"""Random encounter tables: what lives in each kind of land, and a fair fight for the party in front of it.

Every biome has a table, made from the world's monsters: the creatures that live there (their
"Found in" environments) at full weight, and those of neighbouring lands at less (a jungle gets some of
the forest's and the swamp's creatures, the tundra the arctic's). Region "Typical creatures" count extra,
the dead come out more at night, and nothing one-of-a-kind (a dungeon's master) or summoned is in them.

Rolling picks how hard the fight should be (mostly easy and medium, sometimes hard, now and then deadly)
and builds it for the party actually there: its members' levels and how many there are (the 2014
encounter-building rules: XP thresholds per character, and the multiplier for a group of monsters, one
step higher for a party of one or two and one lower for six or more). A fight can be one creature, a
pack of one kind, or a leader with its kin (an orc war leader and a few orcs, a hyena matriarch and her
clan). Too many creatures for a small party, or one big brute that would flatten low-level characters,
count against an option.
"""
from __future__ import annotations

import random
import zlib

from game.quests import (DIFFICULTIES, ENV_TO_MAP, cr_value, counted, enemy_xp, xp_budget)

# a land: [(environment, weight)]
BIOME_ENVS = {
    "Forest": [("Forest", 1.0), ("Taiga", 0.2), ("Jungle", 0.1)],
    "Jungle": [("Jungle", 1.0), ("Forest", 0.3), ("Swamp", 0.2)],
    "Taiga": [("Taiga", 1.0), ("Forest", 0.4), ("Tundra", 0.15), ("Arctic", 0.1)],
    "Plains": [("Plains", 1.0), ("Savanna", 0.15), ("Hills", 0.15)],
    "Savanna": [("Savanna", 1.0), ("Plains", 0.35), ("Desert", 0.1), ("Badlands", 0.1)],
    "Hills": [("Hills", 1.0), ("Mountains", 0.3), ("Plains", 0.2)],
    "Mountains": [("Mountains", 1.0), ("Hills", 0.35), ("Arctic", 0.1)],
    "Swamp": [("Swamp", 1.0), ("Jungle", 0.15), ("Forest", 0.1)],
    "Desert": [("Desert", 1.0), ("Badlands", 0.35)],
    "Badlands": [("Badlands", 1.0), ("Desert", 0.45), ("Hills", 0.15)],
    "Arctic": [("Arctic", 1.0), ("Tundra", 0.4), ("Mountains", 0.1)],
    "Tundra": [("Tundra", 1.0), ("Arctic", 0.55), ("Taiga", 0.1)],
    "Coast": [("Coast", 1.0), ("Underwater", 0.25), ("Plains", 0.1)],
    "Lake": [("Coast", 1.0), ("Underwater", 0.4)],
    "Ocean": [("Underwater", 1.0), ("Coast", 0.5)],
    "Urban": [("Urban", 1.0)],
    "Cave": [("Cave", 1.0), ("Dungeon", 0.4)],
    "Dungeon": [("Dungeon", 1.0), ("Cave", 0.4)],
    "Interior": [("Interior", 1.0), ("Urban", 0.4)],
    "Underwater": [("Underwater", 1.0), ("Coast", 0.3)],
}
MAP_FOR = {"Lake": "coast", "Ocean": "coast"}
DIFFICULTY_ODDS = {"Easy": 38, "Medium": 44, "Hard": 15, "Deadly": 3}
GENERIC_TAGS = {"srd 5.1", "bestiary", "world", "stand-in", "beast", "monstrosity", "humanoid", "flying", "ambush",
                "swarm", "sea", "desert", "arctic", "jungle", "savanna", "taiga", "tundra", "badlands", "dragon",
                "giant", "plant", "elemental", "fiend", "fey", "construct", "aberration", "celestial", "ooze",
                "insect", "reptile", "boss", "caster", "raider", "sky"}
KIN_BASES = {"goblin", "hobgoblin", "orc", "kobold", "gnoll", "lizardfolk", "skeleton", "zombie", "canine",
             "insect", "ogre"}


def biome_envs(biome: str) -> list[tuple[str, float]]:
    return BIOME_ENVS.get(biome) or [(biome, 1.0)]


def map_for(biome: str) -> str:
    """The battle map style for fights in this land."""
    return MAP_FOR.get(biome) or ENV_TO_MAP.get(biome) or ENV_TO_MAP.get(biome_envs(biome)[0][0], "plains")


DOMESTIC = {"Cat", "Mule", "Pony", "Draft Horse", "Riding Horse", "Warhorse", "Camel", "Mastiff"}
WATERY = {"Coast", "Underwater"}


def _usable(e) -> bool:
    tags = e.tags or []
    return "summon" not in tags and "unique" not in tags and not e.fields.get("lair") and enemy_xp(e) > 0 \
        and str(e.fields.get("cr", "0")) != "0" and e.name not in DOMESTIC and "," not in e.name


def _envs(e) -> list[str]:
    """Where it's found. Sea creatures from the SRD stay by the water whatever their list says (a giant
    sea horse isn't met on the plains)."""
    envs = list(e.fields.get("environments") or [])
    if "sea" in {t.lower() for t in e.tags or []} and "SRD 5.1" in (e.tags or []):
        wet = [x for x in envs if x in WATERY]
        envs = wet or ["Underwater", "Coast"]
    return envs


def table(world, biome: str) -> list[tuple[object, float]]:
    """[(enemy, weight)]: everything that can be met in this land, with how common it is there."""
    enemies = world.entities.all("enemy")
    cache = world.__dict__.setdefault("_enc_tables", {})
    key = (biome, len(enemies), sum(len(e.fields.get("environments") or []) for e in enemies))
    if key in cache:
        return cache[key]
    weights = dict(biome_envs(biome))
    out = []
    for e in enemies:
        if not _usable(e):
            continue
        w = max((weights.get(env, 0.0) for env in _envs(e)), default=0.0)
        if w > 0:
            out.append((e, w))
    cache[key] = out
    return out


def multiplier(count: int, players: int) -> float:
    """The 2014 group multiplier, shifted for a small (1-2) or large (6+) party."""
    steps = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0]
    i = 1 if count <= 1 else 2 if count == 2 else 3 if count <= 6 else 4 if count <= 10 else 5 if count <= 14 else 6
    if players <= 2:
        i += 1
    elif players >= 6:
        i -= 1
    return steps[max(0, min(len(steps) - 1, i))]


def _family(e) -> set[str]:
    """What makes two creatures kin (a leader and its followers)."""
    fam = {t.lower() for t in (e.tags or [])} - GENERIC_TAGS
    base = (e.fields.get("appearance") or {}).get("base") or ""
    if base in KIN_BASES:
        fam.add("base:" + base)
    return fam


def options(world, biome: str, levels: list[int], difficulty: str = "Medium", region=None,
            night: bool | None = None) -> list[dict]:
    """Every fair fight for this party here at this difficulty: [{"rows", "xp", "score", "weight"}],
    best first."""
    levels = [max(1, min(20, int(lv))) for lv in levels] or [1]
    players = len(levels)
    avg = sum(levels) / players
    low, target, high = xp_budget(levels, difficulty)
    tab = table(world, biome)
    favoured = set(region.fields.get("enemies") or []) if region is not None else set()
    max_count = min(12, max(3, players * 2 + 2))
    out: list[dict] = []

    def weight_of(e, w: float) -> float:
        if e.id in favoured:
            w *= 3.0
        if night is not None and "undead" in {t.lower() for t in e.tags or []}:
            w *= 2.5 if night else 0.35
        return w

    def score(adj: float, count: int, crs: list[float]) -> float:
        s = abs(adj - target) / max(1, target)
        s += 0.06 * max(0, count - players)                       # more foes than heroes: slower, swingier
        top = max(crs)
        if count == 1 and top > avg + 2:                          # one big brute: one crit flattens someone
            s += 0.25 * (top - avg - 2)
        if top > avg + 5:
            s += 0.5
        if min(crs) < avg / 8 and count > players:                # a crowd of chaff
            s += 0.15
        return s

    for e, w in tab:
        xp = enemy_xp(e)
        cr = cr_value(e.fields.get("cr", "0"))
        cap = max_count if cr <= 1 else min(max_count, 6)
        for n in range(1, cap + 1):
            adj = xp * n * multiplier(n, players)
            if adj > high:
                break
            if adj < low:
                continue
            out.append({"rows": [(e, n)], "xp": int(adj), "score": score(adj, n, [cr]),
                        "weight": weight_of(e, w)})
    # leaders with their kin
    by_family: dict[str, list] = {}
    for e, w in tab:
        for f in _family(e):
            by_family.setdefault(f, []).append((e, w))
    seen = set()
    for fam, members in by_family.items():
        if len(members) < 2:
            continue
        for lead, lw in members:
            lcr = cr_value(lead.fields.get("cr", "0"))
            for foll, fw in members:
                fcr = cr_value(foll.fields.get("cr", "0"))
                if foll is lead or fcr >= lcr or (lead.id, foll.id) in seen:
                    continue
                seen.add((lead.id, foll.id))
                for k in range(1, max_count):
                    adj = (enemy_xp(lead) + enemy_xp(foll) * k) * multiplier(1 + k, players)
                    if adj > high:
                        break
                    if adj < low:
                        continue
                    out.append({"rows": [(lead, 1), (foll, k)], "xp": int(adj),
                                "score": score(adj, 1 + k, [lcr, fcr]) - 0.05,
                                "weight": (weight_of(lead, lw) + weight_of(foll, fw)) / 2})
    out.sort(key=lambda o: o["score"])
    return out


def pick_difficulty(rng: random.Random) -> str:
    return rng.choices(list(DIFFICULTY_ODDS), weights=list(DIFFICULTY_ODDS.values()))[0]


def roll(world, biome: str, levels: list[int], rng: random.Random, difficulty: str = "", region=None,
         night: bool | None = None) -> dict | None:
    """A random encounter in this land for this party: {"rows": [{"id", "count"}], "environment",
    "text", "difficulty", "xp"} (None if the world has nothing that fits)."""
    diff = difficulty or pick_difficulty(rng)
    opts = []
    for d in [diff] + [x for x in ("Medium", "Easy", "Hard") if x != diff]:
        opts = options(world, biome, levels, d, region, night)
        if opts:
            diff = d
            break
    if not opts:
        return None
    best = opts[0]["score"]
    pool = [o for o in opts if o["score"] <= best + 0.35][:24]
    weights = [o["weight"] / (1.0 + 3.0 * (o["score"] - best)) for o in pool]
    o = rng.choices(pool, weights=weights)[0]
    rows = [{"id": e.id, "count": n} for e, n in o["rows"]]
    names = [counted(e.name, n) for e, n in o["rows"]]
    who = names[0] if len(names) == 1 else f"{names[0]} and {names[1]}"
    many = sum(n for _e, n in o["rows"]) > 1
    return {"rows": rows, "environment": map_for(biome), "difficulty": diff, "xp": o["xp"],
            "text": f"{who[:1].upper()}{who[1:]} {'block' if many else 'blocks'} the way!"}


def roamers(world, biome: str, levels: list[int], n: int = 6) -> list:
    """What's most likely to be met here by this party (for the map's description of a hex)."""
    seen: dict[str, float] = {}
    for d in ("Easy", "Medium", "Hard"):
        for o in options(world, biome, levels, d)[:40]:
            for e, _c in o["rows"]:
                seen[e.name] = seen.get(e.name, 0.0) + o["weight"]
    return [k for k, _v in sorted(seen.items(), key=lambda kv: -kv[1])][:n]


def seeded(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


__all__ = ["roll", "options", "table", "multiplier", "map_for", "roamers", "BIOME_ENVS", "DIFFICULTIES"]
