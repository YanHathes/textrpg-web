"""Landmarks and dungeons: places out in the world, explored room by room.

Location strings:
    landmark|<landmark id>              at a landmark
    dungeon|<dungeon id>|<room name>    in a dungeon room

A landmark is reached from the wilds outside its town (once discovered); one with "Entrance to"
leads into a dungeon. A dungeon without a landmark opens onto the wilds itself.

Progress is kept in the game state (state.dungeons[id]): rooms cleared of monsters, treasure taken,
traps sprung, secret rooms found. Dungeons with "Monsters return after" days restock.
"""
from __future__ import annotations

import random

from game import dice

SECRET_DC = 15
ENVIRONMENT = {"Cave": "cave", "Mine": "cave", "Lair": "cave", "Crypt": "dungeon", "Ruins": "dungeon",
               "Tower": "interior", "Sewer": "dungeon", "Temple": "dungeon", "Fortress": "dungeon",
               "Other": "dungeon"}
SCENE = {"Cave": "Cave", "Mine": "Cave", "Lair": "Cave"}


def landmark_id(lm_id: str) -> str:
    return f"landmark|{lm_id}"


def room_id(d_id: str, room: str) -> str:
    return f"dungeon|{d_id}|{room}"


def rooms(d) -> list[dict]:
    return [r for r in (d.fields.get("rooms") or []) if str(r.get("name") or "").strip()]


def room(d, name: str) -> dict | None:
    return next((r for r in rooms(d) if r["name"] == name), None)


def entrance(d) -> str:
    rs = rooms(d)
    return rs[0]["name"] if rs else ""


def links(d, name: str) -> list[str]:
    """Rooms connected to this one (either room may list the other)."""
    names = [r["name"] for r in rooms(d)]
    here = room(d, name) or {}
    out = [n.strip() for n in str(here.get("connects") or "").split(",") if n.strip() in names]
    for r in rooms(d):
        if name in [n.strip() for n in str(r.get("connects") or "").split(",")]:
            out.append(r["name"])
    return [n for n in dict.fromkeys(out) if n != name]


def progress(state, d) -> dict:
    p = state.dungeons.setdefault(d.id, {"cleared": [], "looted": [], "sprung": [], "found": [], "day": state.day})
    days = int(d.fields.get("restock_days") or 0) if d.type == "dungeon" else 0
    if days and p.get("cleared") and state.day >= int(p.get("day", state.day)) + days:
        p["cleared"] = []
        p["sprung"] = []
        p["traps"] = {}                              # (reset, and to be spotted again: game/traps.py)
        p["day"] = state.day
    return p


def visible_links(state, d, name: str) -> list[str]:
    p = progress(state, d)
    return [n for n in links(d, name) if not (room(d, n) or {}).get("secret") or n in p["found"]]


def hidden_links(state, d, name: str) -> list[str]:
    p = progress(state, d)
    return [n for n in links(d, name) if (room(d, n) or {}).get("secret") and n not in p["found"]]


def outside_of(world, d) -> str:
    """Where leaving the dungeon puts you: its landmark, or the wilds by its town."""
    from game import places
    lm = next(iter(world.entities.by_field("landmark", "dungeon", d.id)), None)
    if lm is not None:
        return landmark_id(lm.id)
    town = world.entities.get(d.fields.get("town") or "")
    if town is not None:
        return places.wild_id(town.id, d.fields.get("direction") or "North")
    from game import geography as G
    from game import hexes as H
    return H.hex_of_point(world, G.dungeon_position(world, d))


def is_discovered(state, entity) -> bool:
    return not entity.fields.get("hidden", True) or entity.id in state.discovered


def here_from_wild(world, state, town_id: str, direction: str) -> list:
    """Landmarks and dungeon entrances (discovered or not) out in this patch of wilds."""
    out = [lm for lm in world.entities.by_field("landmark", "near_town", town_id)
           if (lm.fields.get("direction") or "North") == direction]
    for d in world.entities.by_field("dungeon", "town", town_id):
        if (d.fields.get("direction") or "") == direction and not world.entities.by_field("landmark", "dungeon", d.id):
            out.append(d)
    return sorted(out, key=lambda e: e.name)


def lair_boss(world, d):
    """A creature made to rule this dungeon (enemy field "lair"): it waits in the boss room."""
    if d is None:
        return None
    found = world.entities.by_field("enemy", "lair", d.id)
    return found[0] if found else None


def relics(world, place) -> list[str]:
    """Items made to be found here (item field "found_in"): in a dungeon's boss room, or a landmark's loot."""
    if place is None:
        return []
    return [i.id for i in world.entities.by_field("item", "found_in", place.id)]


def room_foes(world, d, r: dict, rng: random.Random | None = None) -> list[tuple]:
    """[(enemy, count)] waiting in a room: its own monsters, and in the boss room the dungeon's master
    (if one was made for it) with the room's monsters as its followers."""
    out = []
    enemy = world.entities.get(r.get("enemy") or "")
    n = 1
    if enemy is not None:
        count = str(r.get("count") or "1")
        try:
            n = max(1, int(count))
        except ValueError:
            n = max(1, dice.roll(count, rng or random.Random()).total if dice.is_valid(count) else 1)
    boss = lair_boss(world, d) if r.get("boss") else None
    if boss is not None:
        out.append((boss, 1))
        if enemy is not None and enemy.id != boss.id and n > 1:
            out.append((enemy, n - 1))
    elif enemy is not None:
        out.append((enemy, n))
    return out


def discover(state, entity, bus=None) -> None:
    if entity.id not in state.discovered:
        state.discovered.append(entity.id)
        state.save()
        if bus is not None:
            bus.emit("place.discovered", entity=entity.id, place_name=entity.name)


# ======================================================================
# Arriving somewhere: guardians, traps, monsters
# ======================================================================
def arrival(world, state, loc: str, rng: random.Random | None = None, traps: bool = True) -> dict:
    """What happens on arriving: {"text", "trap": {...} or None, "fight": rows or None,
    "environment", "key" (what to mark cleared after a won fight)}. traps=False on the walking map, where
    a room's trap is on a square of it instead (game/traps.py)."""
    rng = rng or random.Random()
    out = {"text": "", "trap": None, "fight": None, "environment": "dungeon", "key": None}
    kind, _sep, rest = loc.partition("|")
    if kind == "landmark":
        lm = world.entities.get(rest)
        if lm is None:
            return out
        p = progress(state, lm)
        foes = [e for e in (world.entities.get(i) for i in lm.fields.get("enemies") or []) if e]
        if foes and "guardians" not in p["cleared"]:
            out["fight"] = [{"id": e.id, "count": 1} for e in foes]
            out["key"] = (lm.id, "guardians")
            from game import travel
            town = world.entities.get(lm.fields.get("near_town") or "")
            from game.quests import ENV_TO_MAP
            out["environment"] = ENV_TO_MAP.get(travel.terrain_of(town), "plains")
            out["text"] = f"{lm.name} is not unguarded!"
        return out
    if kind == "dungeon":
        d_id, _s, name = rest.partition("|")
        d = world.entities.get(d_id)
        r = room(d, name) if d is not None else None
        if r is None:
            return out
        p = progress(state, d)
        out["environment"] = ENVIRONMENT.get(d.fields.get("kind") or "Other", "dungeon")
        if r.get("type") or r.get("w"):              # generated rooms: a battle map the shape of the room
            out["map_size"] = battle_size(d, name) or ROOM_TYPES["Room"]["battle"]
            out["style"] = room_type(r)
            if out["environment"] == "dungeon":
                out["environment"] = "dungeon_room"
        if traps and int(r.get("trap_dc") or 0) and r.get("trap_damage") and name not in p["sprung"]:
            out["trap"] = {"dc": int(r["trap_dc"]), "damage": r["trap_damage"], "type": r.get("trap_type") or "piercing"}
            p["sprung"].append(name)
        foes = room_foes(world, d, r, rng)
        if foes and name not in p["cleared"]:
            out["fight"] = [{"id": e.id, "count": n} for e, n in foes]
            out["key"] = (d.id, name)
            boss = lair_boss(world, d) if r.get("boss") else None
            out["text"] = (f"{boss.name} rises to meet you!" if boss is not None else
                           "The master of this place rises to meet you!" if r.get("boss")
                           else f"Something stirs in the {name.lower()}!")
        state.save()
    return out


def trap_text(world, members: list, trap: dict, rng: random.Random, state) -> list[str]:
    """Each living member makes a Dexterity save against the trap; the hurt take damage."""
    from game import condition
    lines = ["A trap springs!"]
    for m in members:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        condition.apply(state, m, c)
        roll = rng.randint(1, 20) + c.mod("dex") + (c.prof if "dex" in c.saves else 0)
        dmg = max(0, dice.roll(trap["damage"], rng).total) if dice.is_valid(trap["damage"]) else 0
        if roll >= trap["dc"]:
            dmg //= 2
        c.hp = max(1, c.hp - dmg)
        condition.store(state, m, c, save=False)
        lines.append(f"{c.name}: Dexterity save {roll} vs DC {trap['dc']}, {dmg} {trap['type']} damage "
                     f"({c.hp}/{c.max_hp} HP).")
    state.save()
    return lines


def mark_cleared(state, key) -> None:
    if not key:
        return
    p = state.dungeons.setdefault(key[0], {"cleared": [], "looted": [], "sprung": [], "found": [], "day": state.day})
    if key[1] not in p["cleared"]:
        p["cleared"].append(key[1])
        p["day"] = state.day
    state.save()


def loot_here(world, state, loc: str) -> tuple[list, str, object, str]:
    """(item ids, gold dice, the landmark/dungeon, the key) for treasure not taken yet."""
    kind, _sep, rest = loc.partition("|")
    if kind == "landmark":
        lm = world.entities.get(rest)
        if lm is None:
            return [], "", None, ""
        p = progress(state, lm)
        if "treasure" in p["looted"] or (lm.fields.get("enemies") and "guardians" not in p["cleared"]):
            return [], "", lm, "treasure"
        gold = str(int(lm.fields.get("gold") or 0) or "")
        return list(lm.fields.get("loot") or []) + relics(world, lm), gold, lm, "treasure"
    if kind == "dungeon":
        d_id, _s, name = rest.partition("|")
        d = world.entities.get(d_id)
        r = room(d, name) if d is not None else None
        if r is None:
            return [], "", d, name
        p = progress(state, d)
        if name in p["looted"] or (room_foes(world, d, r) and name not in p["cleared"]):
            return [], "", d, name
        extra = relics(world, d) if r.get("boss") else []
        return list(r.get("loot") or []) + extra, str(r.get("gold") or ""), d, name
    return [], "", None, ""


BOOK_CHANCE = 0.2


def take_loot(world, state, loc: str, rng: random.Random | None = None) -> str:
    items, gold, owner, key = loot_here(world, state, loc)
    if owner is None or (not items and not gold):
        return ""
    rng = rng or random.Random()
    got = []
    from game import quality
    for i in items:
        i = quality.roll_found(world, i, rng)            # now and then damaged, or better or worse made
        e = world.entities.get(i)
        if e is not None:
            state.add_item(i, 1, source="treasure")
            got.append(e.name)
    if gold:
        n = dice.roll(gold, rng).total if dice.is_valid(gold) else int(float(gold or 0))
        if n > 0:
            state.add_gold(n, "treasure")
            got.append(f"{n} gold")
    if rng.random() < BOOK_CHANCE:                    # now and then a book among the treasure (game/books.py)
        from game import books
        shelf = [i for i in world.entities.all("item") if books.is_book(i) and books.kind_of(i) != "Manual"
                 and not books.has_read(state, i.id)]
        if shelf:
            b = rng.choice(sorted(shelf, key=lambda i: i.id))
            state.add_item(b.id, 1, source="treasure")
            got.append(b.name)
    progress(state, owner)["looted"].append(key)
    state.save()
    text = "You find: " + ", ".join(got) + "." if got else "Nothing of value after all."
    if world.rules.get("disease_curses"):              # a sealed tomb, a shrine's offerings (game/survival.py)
        from game import party as P
        from game import survival
        cursed = survival.after_loot(world, state, owner, P.load(world, defaults=False), rng)
        if cursed:
            text += " " + cursed
    return text


def search_secrets(world, state, loc: str, members: list, rng: random.Random | None = None) -> tuple[bool, str]:
    """The best Wisdom (Perception) in the party against DC 15 to find a hidden way on."""
    from game import checks, condition
    kind, _sep, rest = loc.partition("|")
    if kind != "dungeon":
        return False, ""
    d_id, _s, name = rest.partition("|")
    d = world.entities.get(d_id)
    if d is None:
        return False, ""
    hidden = hidden_links(state, d, name)
    rng = rng or random.Random()
    opt = next((o for o in checks.options(world) if o["label"].lower() == "perception"), None)
    best, who = -99, ""
    pick = None
    for m in members:                                 # the sharpest eyes in the party look
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        b = checks.bonus(world, m, c, opt)[0] if opt else c.mod("wis")
        if pick is None or b > pick[2]:
            pick = (m, c, b)
    if pick is not None:
        m, c, b = pick
        if opt is not None:
            best = checks.roll(world, m, c, opt, SECRET_DC if hidden else 0, rng=rng)["total"]
        else:
            best = rng.randint(1, 20) + b
        who = c.name
    state.advance(10, "searching")
    if hidden and best >= SECRET_DC:
        progress(state, d)["found"].extend(hidden)
        state.save()
        return True, f"{who} finds a hidden way on (Perception {best}): {', '.join(hidden)}."
    return False, f"You search carefully (best Perception {best}) but find no hidden doors."


# ======================================================================
# Making dungeons
# ======================================================================
# Each room type's size on the dungeon map (in map squares) and its battle map (squares, w x h).
ROOM_TYPES = {
    "Stairs": {"map": (3, 3), "battle": (10, 10)},
    "Entrance": {"map": (4, 4), "battle": (14, 10)},
    "Room": {"map": (4, 4), "battle": (14, 10)},
    "Hallway": {"map": (2, 7), "battle": (20, 6)},
    "Chamber": {"map": (7, 7), "battle": (20, 15)},
    "Treasure room": {"map": (3, 3), "battle": (10, 8)},
    "Special": {"map": (4, 4), "battle": (14, 10)},
    "Boss": {"map": (7, 7), "battle": (20, 15)},
}
SIZES = {"Small": 7, "Medium": 12, "Large": 18}
SPECIALS = {
    "Shrine": ("Pray at the shrine", "An old shrine, its candles somehow still burning."),
    "Fountain": ("Drink from the fountain", "Clear water wells up in a carved stone basin."),
    "Library": ("Search the shelves", "Rotting shelves of books and scrolls line the walls."),
    "Prison": ("Free the prisoner", "Rusted cells. Someone in the last one is still alive."),
    "Statue": ("Study the statue", "A statue stands here, one stone hand pointing at a blank wall."),
    "Armory": ("Search the weapon racks", "Racks of old weapons and armour, most of it rusted through."),
    "Altar": ("Lay an offering on the altar", "A dark altar hums faintly. A bowl for offerings sits on it."),
}
NAMES = {
    "Room": {"Cave": ["Dripping Passage", "Bat Roost", "Fungus Grotto", "Bone Pile", "Narrow Crawl", "Damp Hollow",
                      "Crystal Pocket", "Root Chamber", "Rat Warren", "Mossy Cave", "Lichen Hollow", "Hollow Stump"],
             "Mine": ["Ore Face", "Foreman's Hut", "Timbered Gallery", "Abandoned Camp", "Tool Store", "Cart Siding",
                      "Glittering Vein", "Pump Room", "Powder Store", "Miners' Bunks", "Sorting Room", "Lift Shaft"],
             "Crypt": ["Ossuary", "Embalming Room", "Burial Niches", "Priest's Cell", "Mourners' Room",
                       "Sealed Tomb", "Urn Room", "Collapsed Tombs", "Canopic Store", "Chapel of Rest",
                       "Shrouded Alcove", "Bone Room"],
             "": ["Guard Room", "Storeroom", "Barracks", "Cistern", "Kitchen", "Cell Block", "Well Room",
                  "Mess Hall", "Workshop", "Study", "Dormitory", "Pantry", "Lookout", "Wine Cellar", "Bath House"]},
    "Hallway": ["Long Hall", "Narrow Passage", "Pillared Corridor", "Crooked Tunnel", "Collapsed Passage",
                "Stair Down", "Echoing Corridor", "Flooded Passage", "Statue Walk", "Low Tunnel"],
    "Chamber": ["Great Hall", "Echoing Cavern", "Pillared Chamber", "Feasting Hall", "Throne Room",
                "Ritual Chamber", "Deep Cavern", "Grand Gallery"],
    "Treasure room": ["Treasury", "Strongroom", "Hoard", "Locked Vault", "Coffer Room", "Cache"],
    "Entrance": {"Cave": "Cave Mouth", "Mine": "Adit", "Crypt": "Entry Stair", "Sewer": "Outfall",
                 "Tower": "Tower Door", "Fortress": "Gatehouse", "": "Entrance"},
    "Boss": {"Cave": "Deep Chamber", "Mine": "The Deep Seam", "Crypt": "Inner Sepulchre", "Lair": "The Lair",
             "Temple": "Inner Sanctum", "Tower": "Tower Top", "Fortress": "Keep", "": "Inner Sanctum"},
}
DESCRIBE = {
    "Room": "A room like the others, but for what's in it.",
    "Hallway": "A long, narrow way on. There's nowhere to hide in here.",
    "Chamber": "A huge space. Your light doesn't reach the far wall.",
    "Treasure room": "A small room built to keep things safe.",
}


def room_type(r: dict) -> str:
    t = r.get("type") or ""
    if t in ROOM_TYPES or t == "Stairs":
        return t
    if r.get("boss"):
        return "Boss"
    return "Room"


def ensure_rooms(world, d) -> list[dict]:
    """A dungeon with no rooms and 'Generate the rooms' on gets them now (the same ones every time
    for that dungeon), and keeps them."""
    if rooms(d) or not d.fields.get("generate", True):
        return rooms(d)
    import zlib
    made = generate_rooms(world, d, random.Random(zlib.crc32(d.id.encode("utf-8"))))
    world.entities.update(d.id, fields={"rooms": made})
    return rooms(world.entities.get(d.id))


def _pick_name(pool: list, used: set, rng: random.Random) -> str:
    free = [n for n in pool if n not in used]
    if free:
        name = rng.choice(free)
    else:
        base = rng.choice(pool)
        k = 2
        while f"{base} {k}" in used:
            k += 1
        name = f"{base} {k}"
    used.add(name)
    return name


def _layout(types: list[str], rng: random.Random) -> tuple[list[tuple], list[tuple[int, int]]]:
    """Place rooms on a grid, each against an earlier one with a short corridor between.
    Returns ([(x, y, w, h)], [(room index, parent index)])."""
    rects: list[tuple] = []
    links: list[tuple[int, int]] = []

    def free(x, y, w, h) -> bool:
        return all(x + w + 1 <= ax or ax + aw + 1 <= x or y + h + 1 <= ay or ay + ah + 1 <= y
                   for ax, ay, aw, ah in rects)
    for i, kind in enumerate(types):
        w, h = ROOM_TYPES[kind]["map"]
        if i == 0:
            rects.append((0, 0, w, h))
            continue
        placed = False
        # later rooms prefer to grow off the newer end of the dungeon, so it winds outward
        for _ in range(400):
            parent = min(len(rects) - 1, int(len(rects) * (rng.random() ** 0.6)))
            px, py, pw, ph = rects[parent]
            side = rng.choice("NESW")
            if kind == "Hallway" and side in "EW":
                w, h = ROOM_TYPES[kind]["map"][1], ROOM_TYPES[kind]["map"][0]
            elif kind == "Hallway":
                w, h = ROOM_TYPES[kind]["map"]
            gap = 2
            if side == "N":
                x, y = px + pw // 2 - w // 2 + rng.randint(-1, 1), py - gap - h
            elif side == "S":
                x, y = px + pw // 2 - w // 2 + rng.randint(-1, 1), py + ph + gap
            elif side == "E":
                x, y = px + pw + gap, py + ph // 2 - h // 2 + rng.randint(-1, 1)
            else:
                x, y = px - gap - w, py + ph // 2 - h // 2 + rng.randint(-1, 1)
            if free(x, y, w, h):
                rects.append((x, y, w, h))
                links.append((i, parent))
                placed = True
                break
        if not placed:                                    # crowded: put it out on its own, off the last room
            px, py, pw, ph = rects[-1]
            x, y = px + pw + 3 + len(rects), py
            rects.append((x, y, w, h))
            links.append((i, len(rects) - 2))
    # a few loops, between rooms that ended up side by side
    for i in range(len(rects)):
        for j in range(i + 1, len(rects)):
            if (i, j) in links or (j, i) in links or rng.random() > 0.25:
                continue
            ax, ay, aw, ah = rects[i]
            bx, by, bw, bh = rects[j]
            side_by_side = (abs((ax + aw) - bx) <= 2 or abs((bx + bw) - ax) <= 2) and ay < by + bh and by < ay + ah
            stacked = (abs((ay + ah) - by) <= 2 or abs((by + bh) - ay) <= 2) and ax < bx + bw and bx < ax + aw
            if side_by_side or stacked:
                links.append((j, i))
    return rects, links


TOWER_NAMES = ["Guard Room", "Library", "Study", "Armory", "Laboratory", "Bedchamber", "Storeroom", "Observatory",
               "Shrine", "Trophy Room", "Map Room", "Scrying Chamber"]


def generate_rooms(world, d, rng: random.Random | None = None, count: int | None = None) -> list[dict]:
    """A random dungeon grown from the dungeon room tiles (see game/rooms.py): mostly rooms of the same
    size, a few hallways, large chambers, treasure rooms and special rooms, stairs to a deeper level in
    big ones; a boss in a chamber far from the entrance and a treasure room behind a secret door.
    Monsters are picked for the dungeon's level."""
    from game import rooms as R
    from game.quests import encounter_options
    rng = rng or random.Random()
    kind = d.fields.get("kind") or "Other"
    level = max(1, int(d.fields.get("level") or 1))
    lay = R.generate(world, kind, "dungeon", count=count, rng=rng, size=d.fields.get("size") or "Medium")
    # a treasure room behind a secret door, off a middle room
    treasure_tiles = [t for t in R.tiles_for(world, kind, "dungeon") if t["role"] == "Treasure room"]
    secret_i = None
    if treasure_tiles and len(lay.rooms) >= 4:
        doors = [dk for dk in lay.open_doors() if 0 < dk[0] < len(lay.rooms) - 1]
        rng.shuffle(doors)
        for i, k in doors:
            cands = lay.candidates(treasure_tiles, i, k)
            if cands:
                t, (x, y) = cands[0]
                secret_i = lay.add(t, x, y, lay.rooms[i]["floor"], i, k, name="Hidden Cache")
                break

    env = {"Cave": "Cave", "Mine": "Cave", "Lair": "Cave"}.get(kind, "Dungeon")
    easy = encounter_options(world, [level] * 4, "Easy", env) or encounter_options(world, [level] * 4, "Easy")
    medium = encounter_options(world, [level] * 4, "Medium", env) or easy
    hard = encounter_options(world, [level] * 4, "Hard", env) or medium
    treasures = [i for i in world.entities.all("item") if (i.fields.get("rarity") or "Common") in
                 (("Common", "Uncommon") if level < 5 else ("Uncommon", "Rare"))
                 and i.fields.get("category") in ("Consumable", "Treasure", "Trinket", "Weapon", "Armor")]
    gear = [i for i in world.entities.all("item") if i.fields.get("category") in ("Weapon", "Armor", "Shield")]
    specials = list(SPECIALS)
    rng.shuffle(specials)
    used: set = {"Hidden Cache"}
    key = kind if kind in ("Cave", "Mine", "Crypt") else ""
    extra = {}
    for i, room in enumerate(lay.rooms):
        t = room["type"]
        if i == secret_i:
            continue
        if t == "Entrance":
            name = NAMES["Entrance"].get(kind, NAMES["Entrance"][""])
            used.add(name)
        elif t == "Boss":
            name = NAMES["Boss"].get(kind, NAMES["Boss"][""])
            name = name if name not in used else name + " Below"
            used.add(name)
        elif t == "Special":
            sp = specials.pop() if specials else rng.choice(list(SPECIALS))
            name = _pick_name([f"{sp}", f"Hall of the {sp}", f"{sp} Room"], used, rng)
            extra[i] = sp
        elif t == "Stairs":
            name = _pick_name(["Stair Down" if room["stairs"] == "Down" else "Stair Foot", "Winding Stair",
                               "Broken Stair"], used, rng)
        elif kind == "Tower" and t == "Room":
            name = _pick_name(TOWER_NAMES, used, rng)
        elif t == "Room":
            name = _pick_name(NAMES["Room"].get(key, NAMES["Room"][""]), used, rng)
        else:
            name = _pick_name(NAMES.get(t, NAMES["Hallway"]) if isinstance(NAMES.get(t), list) else NAMES["Hallway"],
                              used, rng)
        room["name"] = name
    out = []
    for i, base in enumerate(lay.rows()):
        t = base["type"]
        row = dict(base, enemy=None, count="1", boss=t == "Boss", loot=[], gold="", trap_dc=0, trap_damage="",
                   trap_type="piercing", secret=False, special="")
        row["description"] = DESCRIBE.get(t, "") or base.get("description") or ""
        if i == secret_i:
            row.update(type="Treasure room", secret=True, description="A small room no one was meant to find.",
                       loot=[rng.choice(treasures).id] if treasures else [], gold=f"{level * 2}d10")
        elif t == "Special":
            row["special"] = extra.get(i, "Shrine")
            row["description"] = SPECIALS[row["special"]][1]
        elif t == "Entrance":
            row["description"] = d.description or "The way in. Daylight fades behind you."
        elif t == "Stairs":
            row["description"] = base.get("description") or "Steps worn smooth by many feet."
        elif t == "Boss":
            if hard:
                enemy, cnt, _a, _s = hard[0]
                row.update(enemy=enemy.id, count=str(max(1, cnt)))
            row["gold"] = f"{level * 4}d10"
            row["description"] = "The heart of this place. Whatever rules here waits for you."
            if treasures:
                row["loot"] = [rng.choice(treasures).id]
        elif t == "Chamber":
            if medium and rng.random() < 0.8:
                enemy, cnt, _a, _s = rng.choice(medium[:6])
                row.update(enemy=enemy.id, count=str(max(2, cnt)))
            if rng.random() < 0.4:
                row["gold"] = f"{level * 2}d10"
        elif t == "Room":
            if easy and rng.random() < 0.55:
                enemy, cnt, _a, _s = rng.choice(easy[:6])
                row.update(enemy=enemy.id, count=str(max(1, cnt)))
            if rng.random() < 0.25:
                row["gold"] = f"{level}d10"
            if kind == "Tower":
                row["description"] = "A round room on the tower stair."
        elif t == "Hallway":
            if easy and rng.random() < 0.25:
                enemy, cnt, _a, _s = rng.choice(easy[:6])
                row.update(enemy=enemy.id, count=str(max(1, cnt)))
        elif t == "Treasure room":
            row["gold"] = f"{level * 3}d10"
            if treasures and rng.random() < 0.7:
                row["loot"] = [rng.choice(treasures).id]
            if easy and rng.random() < 0.3:
                enemy, cnt, _a, _s = rng.choice(easy[:6])
                row.update(enemy=enemy.id, count=str(max(1, cnt)))
        if t == "Special" and row["special"] == "Armory" and gear:
            row["loot"] = [rng.choice(gear).id]
        trap_odds = {"Hallway": 0.35, "Treasure room": 0.5, "Room": 0.15}.get(t, 0)
        if i != secret_i and rng.random() < trap_odds:
            row.update(trap_dc=10 + level // 2 + rng.randint(0, 3), trap_damage=f"{max(1, level // 2 + 1)}d10",
                       trap_type=rng.choice(["piercing", "fire", "poison", "bludgeoning"]))
        out.append(row)
    return out


def layout(d) -> dict[str, tuple[float, float, float, float]]:
    """Room name -> (x, y, w, h) on the dungeon map. Rooms without a position (hand-made dungeons)
    are laid out in rows by how far they are from the entrance."""
    rs = rooms(d)
    out = {}
    for r in rs:
        if r.get("w") and r.get("h"):
            out[r["name"]] = (float(r.get("x") or 0), float(r.get("y") or 0), float(r["w"]), float(r["h"]))
    missing = [r["name"] for r in rs if r["name"] not in out]
    if not missing:
        return out
    depth = {rs[0]["name"]: 0} if rs else {}
    queue = [rs[0]["name"]] if rs else []
    while queue:
        cur = queue.pop(0)
        for n in links(d, cur):
            if n not in depth:
                depth[n] = depth[cur] + 1
                queue.append(n)
    rows: dict[int, int] = {}
    for name in missing:
        dd = depth.get(name, max(depth.values(), default=0) + 1)
        k = rows.get(dd, 0)
        rows[dd] = k + 1
        out[name] = (dd * 7.0, k * 6.0, 4.0, 4.0)
    return out


def battle_size(d, name: str) -> tuple[int, int] | None:
    r = room(d, name)
    if r is None:
        return None
    if r.get("tile"):                                    # rooms made from tiles: sized in 5-foot squares
        from game import rooms as R
        return R.battle_size(r)
    return ROOM_TYPES[room_type(r)]["battle"]


# ======================================================================
# Special rooms
# ======================================================================
def special_here(world, state, loc: str) -> tuple[str, str]:
    """(special kind, button label) for an unused special in this room, or ('', '')."""
    kind, _sep, rest = loc.partition("|")
    if kind != "dungeon":
        return "", ""
    d_id, _s, name = rest.partition("|")
    d = world.entities.get(d_id)
    r = room(d, name) if d is not None else None
    sp = (r or {}).get("special") or ""
    if not sp or sp not in SPECIALS:
        return "", ""
    p = progress(state, d)
    if name in p.setdefault("used", []) or (r.get("enemy") and name not in p["cleared"]):
        return "", ""
    return sp, SPECIALS[sp][0]


def use_special(world, state, loc: str, members: list, rng: random.Random | None = None, bus=None) -> str:
    """Use the special thing in this room (once). Returns what happened."""
    from game import condition
    rng = rng or random.Random()
    sp, _label = special_here(world, state, loc)
    if not sp:
        return ""
    _k, _s, rest = loc.partition("|")
    d_id, _s, name = rest.partition("|")
    d = world.entities.get(d_id)
    level = max(1, int(d.fields.get("level") or 1))
    p = progress(state, d)
    p["used"].append(name)
    living = [m for m in members if not m.get("dead")]

    def each(fn):
        lines = []
        for m in living:
            c = condition.combatant(world, m)
            condition.apply(state, m, c)
            lines.append(fn(m, c))
            condition.store(state, m, c, save=False)
        return lines
    if sp == "Shrine":
        def heal(m, c):
            gain = min(c.max_hp - c.hp, max(1, c.max_hp // 2))
            c.hp += gain
            return f"{c.name} +{gain} HP"
        text = "A warmth passes through you. " + ", ".join(each(heal)) + "."
    elif sp == "Fountain":
        roll = rng.random()
        if roll < 0.5:
            def drink(m, c):
                gain = min(c.max_hp - c.hp, max(0, dice.roll("2d8", rng).total))
                c.hp += gain
                return f"{c.name} +{gain} HP"
            text = "The water is cold and sweet. " + ", ".join(each(drink)) + "."
        elif roll < 0.75:
            state.add_xp(25 * level, "a strange fountain")
            text = "Visions swim before your eyes: you understand this place a little better."
        else:
            def sick(m, c):
                loss = min(c.hp - 1, max(0, dice.roll("1d6", rng).total))
                c.hp -= loss
                return f"{c.name} -{loss} HP"
            text = "The water is foul. " + ", ".join(each(sick)) + "."
    elif sp == "Library":
        state.add_xp(25 * level, "old books")
        n = dice.roll(f"{level}d10", rng).total
        state.add_gold(n, "a hidden purse")
        text = f"Among the rot you find useful notes, and a purse of {n} gold tucked behind a book."
    elif sp == "Prison":
        state.add_xp(50 * level, "rescuing a prisoner")
        n = dice.roll(f"{level * 2}d10", rng).total
        state.add_gold(n, "a grateful prisoner")
        text = f"You break the lock. The prisoner thanks you, and presses {n} gold on you before fleeing."
    elif sp == "Statue":
        found = [r["name"] for r in rooms(d) if r.get("secret") and r["name"] not in p["found"]]
        p["found"].extend(found)
        text = ("You follow the statue's pointing hand to a seam in the wall: a hidden door! "
                f"({', '.join(found)})" if found else "The statue points at nothing you can find.")
    elif sp == "Armory":
        r = room(d, name) or {}
        got = [world.entities.get(i) for i in r.get("loot") or []]
        for e in got:
            if e is not None:
                state.add_item(e.id, 1, source="armory")
        p["looted"].append(name)
        text = "Most of it is rust, but you find " + (", ".join(e.name for e in got if e) or "nothing usable") + "."
    elif sp == "Altar":
        cost = 10 * level
        if state.copper < cost * 100:
            p["used"].remove(name)
            return f"The altar wants an offering of {cost} gold, and you don't have it."
        state.add_copper(-cost * 100, "an offering")

        def restore(m, c):
            c.mana = c.mana_max
            c.slots = dict(c.slots_max)
            return f"{c.name} is restored"
        text = f"You lay {cost} gold on the altar. Power floods back into you: " + ", ".join(each(restore)) + "."
    else:
        text = ""
    state.save()
    if bus is not None and text:
        bus.emit("dungeon.special", dungeon=d.id, room=name, special=sp)
    return text
