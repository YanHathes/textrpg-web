"""Character sheet contents for a party member (or anyone in a fight).

Produces the generic dictionary the CharacterSheet panel draws, so the panel
never needs to know which stats a world uses.
"""
from __future__ import annotations


def _sign(n: int) -> str:
    return f"+{n}" if n >= 0 else str(n)


def sheet_for(world, combatant, member: dict | None = None, state=None) -> dict:
    c = combatant
    race = world.entities.get((member or {}).get("race")) if member else None
    klass = world.entities.get((member or {}).get("class")) if member else None
    entity = world.entities.get(c.entity_id) if c.entity_id and "." in c.entity_id else None
    level = int((member or {}).get("level") or 0)

    tags = []
    if level:
        tags.append(f"Level {level}")
    if race:
        tags.append(race.name)
    if klass:
        tags.append(klass.name)
    if entity and not member:
        tags.append(world.templates.get(entity.type).label)
        if entity.fields.get("cr"):
            tags.append(f"CR {entity.fields['cr']}")
    if not c.alive:
        tags.append("Unconscious" if c.team == "player" else "Defeated")
    for name in sorted(getattr(c, "conditions", {}) or {}):
        tags.append(name if name != "Exhaustion" else f"Exhaustion {c.conditions[name].get('level', 1)}")
    if getattr(c, "concentration", None):
        tags.append(f"Concentrating: {c.concentration.get('name')}")

    resources = [{"label": "Hit Points", "current": c.hp, "max": c.max_hp, "color": "danger"}]
    if c.temp_hp:
        resources.append({"label": "Temporary hit points", "current": c.temp_hp, "max": c.temp_hp,
                          "color": "info"})
    if getattr(c, "mana_max", 0):
        resources.append({"label": c.mana_name, "current": c.mana, "max": c.mana_max,
                          "color": "magic" if c.mana_name == "Mana" else "gold"})
    elif c.slots:
        for lvl, n in sorted(c.slots.items()):
            resources.append({"label": f"Level {lvl} spell slots", "current": n, "max": max(n, _slot_max(c, lvl)),
                              "color": "magic"})

    for name, pool in sorted((getattr(c, "resources", {}) or {}).items()):
        resources.append({"label": name, "current": pool["cur"], "max": pool["max"], "color": "warning"})
    for item_id, n in sorted((getattr(c, "charges", {}) or {}).items()):
        item = world.entities.get(item_id)
        if item is not None:
            resources.append({"label": f"{item.name} charges", "current": n,
                              "max": int(item.fields.get("charges") or n), "color": "info"})

    badges = [
        {"label": "Armor", "value": str(c.ac)},
        {"label": "Initiative", "value": _sign(c.init_bonus)},
        {"label": "Speed", "value": f"{c.speed * 5} ft"},
        {"label": "Proficiency", "value": _sign(c.prof)},
    ]

    stats = []
    for s in world.entities.stats():
        key = s.fields.get("key")
        if not key or not s.fields.get("show_on_sheet", True) or key not in c.stats:
            continue
        stats.append({"label": s.fields.get("abbreviation") or s.name[:3].upper(),
                      "main": _sign(c.mods.get(key, 0)), "sub": str(c.stats[key])})
    groups = [{"title": "Abilities", "columns": 3, "stats": stats}] if stats else []

    sections = []
    eq_rows = []
    for slot, item_id in ((member or {}).get("equipment") or (entity.fields.get("equipment") if entity else {}) or {}).items():
        item = world.entities.get(item_id)
        if item:
            eq_rows.append([slot, item.name])
    if eq_rows:
        sections.append({"title": "Equipment", "rows": eq_rows})
    if c.attacks:
        rows = [[a.name, f"{_sign(a.to_hit)}  ·  {a.damage}"] for a in c.attacks]
        if c.attacks_per_action > 1:
            rows.append(["Attacks per action", str(c.attacks_per_action)])
        sections.append({"title": "Attacks", "rows": rows})
    if c.spells:
        rows = [[s.name, "cantrip" if s.level == 0 else f"level {s.level}"] for s in c.spells]
        if getattr(c, "mana_max", 0) and c.max_cast_level:
            rows.append(["Cast up to level", f"{c.max_cast_level}  (10 Mana per level)"])
        rows.append(["Spell save DC", str(c.spell_dc)])
        rows.append(["Spell attack", _sign(c.spell_attack)])
        sections.append({"title": "Spells", "rows": rows})
    if c.items:
        sections.append({"title": "Items", "rows": [[i.name, f"x{i.count}"] for i in c.items]})
    senses = []
    if c.darkvision:
        senses.append(["Darkvision", f"{c.darkvision * 5} ft"])
    if c.light_bright or c.light_dim:
        senses.append(["Carrying light", f"{c.light_bright * 5} ft bright, {c.light_dim * 5} ft dim"])
    if c.resist:
        senses.append(["Resists", ", ".join(sorted(c.resist))])
    if c.immune:
        senses.append(["Immune to", ", ".join(sorted(c.immune))])
    if senses:
        sections.append({"title": "Senses & defenses", "rows": senses})
    if c.features:
        rows = []
        for f in c.features:
            uses = f.uses_text()
            if f.per_rest:
                uses = f"{f.uses_left}/{f.max_uses}"
            bits = ["passive" if f.passive else f.activation.lower()]
            if uses:
                bits.append(uses)
            if f.rounds_left:
                bits.append("ACTIVE")
            rows.append([f.name, "  ·  ".join(bits)])
        sections.append({"title": "Features", "rows": rows})
    if member:
        from game import tools
        rows = tools.sheet_rows(world, member)
        if rows:
            sections.append({"title": "Tools", "rows": rows})
    if state is not None and member:                  # hunger, thirst, rest; disease and curses (game/survival.py)
        from game import survival
        v = survival.view(world, state, member)
        if v:
            for key, top, lab in (("food", "meal_hours", "Fed (hours)"), ("water", "drink_hours", "Watered (hours)"),
                                  ("rest", "sleep_hours", "Rest (hours)")):
                resources.append({"label": lab, "current": max(0, int(round(v[key]))),
                                  "max": max(1, int(round(max(v[key], v[top])))),
                                  "color": "warning" if v[key] > 0 else "danger"})
        aff = survival.afflictions(state, member.get("id", "")) if survival.diseases_on(world) else []
        if aff:
            sections.append({"title": "Afflictions", "rows": [
                [a["name"], ("incubating" if not a.get("started") else a["kind"]) +
                 (f"  ·  -{a['penalty']}" if a.get("penalty") else "") +
                 (f"  ·  max HP -{a['hp_loss']}" if a.get("hp_loss") else "")] for a in aff]})
    if state is not None:
        rows = []
        for item_id, n in sorted(state.inventory.items(),
                                 key=lambda kv: (world.entities.get(kv[0]).name if world.entities.get(kv[0]) else kv[0])):
            item = world.entities.get(item_id)
            rows.append([item.name if item else item_id, f"x{n}"])
        if not rows:
            rows = [["Empty", ""]]
        sections.append({"title": "Party pack", "rows": rows,
                         "footer": f"{state.money_text()}   ·   XP  {state.xp}"})

    return {"name": c.name, "tags": tags, "resources": resources, "badges": badges, "stat_groups": groups,
            "sections": sections}


def _slot_max(c, lvl: int) -> int:
    return c.slots_max.get(lvl, c.slots.get(lvl, 0))
