"""The SRD 5.1 content pack that ships with the game (game/content/srd51-pack.json).

Built by tools/srd/build.py from the System Reference Document 5.1, plus original stand-ins (tagged
'Stand-in') where the SRD leaves gaps. Licensed CC-BY-4.0; the attribution below must stay with it.
"""
from __future__ import annotations

from game import builtin_packs as BP

PACK_PATH = BP.path_of("srd")
ATTRIBUTION = ("This work includes material taken from the System Reference Document 5.1 (\"SRD 5.1\") by "
               "Wizards of the Coast LLC and available at https://dnd.wizards.com/resources/systems-reference-document. "
               "The SRD 5.1 is licensed under the Creative Commons Attribution 4.0 International License available at "
               "https://creativecommons.org/licenses/by/4.0/legalcode.")


def available() -> bool:
    return BP.available("srd")


def load() -> dict:
    return BP.load("srd")


def install(world, mode: str = "replace") -> dict:
    """Put the SRD into a world. 'replace': things with the same name (Fighter, Longsword, Goblin) take the
    SRD's version; 'skip': keep the world's own; 'copy': add the SRD's version alongside."""
    return BP.install(world, "srd", mode)


def installed(world) -> bool:
    return BP.installed(world, "srd")
