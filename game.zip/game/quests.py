"""Quests: the generator NPCs use when asked for work, and the quest book that
tracks progress.

A quest the party has (or is being offered) is a plain dict, stored in the game
state:

    {"id", "title", "kind", "giver", "giver_name", "source", "pitch", "level",
     "objectives": [{"text", "kind", "target", "count", "progress", "done", "hint", "hunt"}],
     "return_to_giver", "status", "tracked", "rewards": {"gold", "xp", "items"},
     "offered_day", "accepted_day", "completed_day", "journal": [...]}

status: offered, active, ready (everything done, go back to the giver), completed, abandoned.

Generated quests come in three kinds:
  Fetch   an item the NPC would plausibly want, that can actually be got
          (some enemy carries it); bring N back.
  Defeat  an enemy (or a few) sized to the party with the 5e encounter
          budget, somewhere near the town.
  Visit   another building or town.

Each NPC gives at most one generated quest per cooldown (a week by default,
changeable per world and per NPC). What they offer is remembered for that
time, so asking again doesn't reroll it. Hand-made quests linked on the NPC
are offered first and aren't limited by the cooldown.

Progress is driven by events, so any system can feed it:
  inventory.changed  -> Fetch
  combat.defeated    -> Defeat (only while `counting`, i.e. not in test fights)
  location.entered   -> Visit
  npc.talked         -> Talk, Deliver
and by the screens: investigate() (a check at a spot), choose() (a decision in conversation).

More objective kinds (step 9, mostly for quest chains: game/chains.py):
  Talk         speak to someone
  Escort       bring someone (named in "who") to a place
  Deliver      give someone an item ("item")
  Investigate  a check at a place (Investigation or Perception against "dc")
  Choose       a decision, made in conversation with someone ("choices")
  Gather       have so many of something (stays done once done: it may go into crafting)
  Craft        make something (handed in like a fetched thing)
  Build        have so many finished buildings of a blueprint (step 14: game/estate.py; target: the blueprint)
Each objective may carry "where", the place to go (the map pin points there).
"""
from __future__ import annotations

import random
import re

from game import places
from game.constants import CR_XP, DIRECTIONS, cr_value

KINDS = ["Fetch", "Defeat", "Visit"]

# 5e encounter thresholds per character level: easy, medium, hard, deadly
XP_THRESHOLDS = {
    1: (25, 50, 75, 100), 2: (50, 100, 150, 200), 3: (75, 150, 225, 400), 4: (125, 250, 375, 500),
    5: (250, 500, 750, 1100), 6: (300, 600, 900, 1400), 7: (350, 750, 1100, 1700), 8: (450, 900, 1400, 2100),
    9: (550, 1100, 1600, 2400), 10: (600, 1200, 1900, 2800), 11: (800, 1600, 2400, 3600),
    12: (1000, 2000, 3000, 4500), 13: (1100, 2200, 3400, 5100), 14: (1250, 2500, 3800, 5700),
    15: (1400, 2800, 4300, 6400), 16: (1600, 3200, 4800, 7200), 17: (2000, 3900, 5900, 8800),
    18: (2100, 4200, 6300, 9500), 19: (2400, 4900, 7300, 10900), 20: (2800, 5700, 8500, 12700),
}
DIFFICULTIES = ["Easy", "Medium", "Hard", "Deadly"]

# What people in each line of work tend to need fetched (item tags).
WANTS = {
    "Blacksmith": ["metal", "ore"], "Armorer": ["metal", "hide"], "Weaponsmith": ["metal", "wood"],
    "Merchant": ["material", "gear", "treasure", "hide"], "Alchemist": ["herb", "alchemical", "monster"],
    "Innkeeper": ["food", "drink", "hide"], "Priest": ["holy", "herb", "treasure"], "Fletcher": ["wood", "feather"],
    "Tailor": ["hide", "cloth"], "Jeweler": ["gem", "treasure", "metal", "jewelry"], "Scholar": ["book", "scroll"],
    "Hunter": ["hide", "trap"], "Farmer": ["food", "tool"], "Guard": ["weapon"], "Noble": ["jewelry", "treasure"],
    "Mercenary": ["weapon", "potion"], "Commoner": ["food", "material"],
}
# How likely each line of work is to want each kind of quest (Fetch, Defeat, Visit).
KIND_WEIGHTS = {
    "Guard": (1, 4, 1), "Mercenary": (1, 4, 1), "Hunter": (2, 3, 1), "Noble": (1, 2, 3), "Merchant": (2, 1, 3),
    "Scholar": (2, 1, 3), "Priest": (1, 2, 2), "Innkeeper": (2, 1, 2), "Farmer": (2, 2, 1),
}
DEFAULT_WEIGHTS = (3, 2, 2)

ENV_TO_MAP = {"Forest": "forest", "Plains": "plains", "Hills": "hills", "Mountains": "hills", "Swamp": "swamp",
              "Desert": "desert", "Arctic": "arctic", "Coast": "coast", "Underwater": "coast", "Urban": "street",
              "Dungeon": "dungeon", "Cave": "cave", "Interior": "interior", "Jungle": "forest", "Savanna": "plains",
              "Taiga": "forest", "Tundra": "arctic", "Badlands": "desert"}
ENV_PHRASE = {"Forest": "in the woods", "Plains": "out on the plains", "Hills": "up in the hills",
              "Mountains": "in the mountains", "Swamp": "in the marsh", "Desert": "out in the dunes",
              "Arctic": "out on the snowfields", "Coast": "along the shore", "Underwater": "by the water",
              "Urban": "in the back streets", "Dungeon": "in the old ruins", "Cave": "in the caves",
              "Interior": "in an abandoned house", "Jungle": "in the jungle", "Savanna": "out on the grasslands",
              "Taiga": "in the pine forests", "Tundra": "out on the tundra", "Badlands": "out in the badlands"}

ENV_NOUN = {"Forest": "Woods", "Plains": "Fields", "Hills": "Hills", "Mountains": "Mountains", "Swamp": "Marsh",
            "Desert": "Dunes", "Arctic": "Snow", "Coast": "Shallows", "Underwater": "Shallows", "Urban": "Alleys",
            "Dungeon": "Ruins", "Cave": "Caves", "Interior": "Old House", "Jungle": "Jungle", "Savanna": "Grasslands",
            "Taiga": "Pinewoods", "Tundra": "Tundra", "Badlands": "Badlands"}

UNCOUNTABLE = {"ore", "wood", "cloth", "meat", "silk", "iron", "steel", "gold", "silver", "salt", "wool", "leather",
               "flour", "grain", "ale", "wine", "water", "coal", "timber", "bread", "cheese", "honey", "dust",
               "armor", "mail", "clothing", "gear"}
IRREGULAR = {"wolf": "wolves", "elf": "elves", "dwarf": "dwarves", "man": "men", "woman": "women", "knife": "knives",
             "staff": "staves", "foot": "feet", "tooth": "teeth", "mouse": "mice", "goose": "geese", "child": "children",
             "ox": "oxen", "thief": "thieves", "leaf": "leaves", "half": "halves", "loaf": "loaves"}
NUMBERS = ["no", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"]


# ======================================================================
# Words
# ======================================================================
def _plural_word(w: str) -> str:
    low = w.lower()
    if low in UNCOUNTABLE:
        return w
    if low in IRREGULAR:
        p = IRREGULAR[low]
        return p.capitalize() if w[0].isupper() else p
    if low.endswith("man") and low not in ("shaman", "talisman"):
        return w[:-3] + ("Men" if w[-3:] == "Man" else "men")
    if low in ("moose", "deer", "sheep", "elk", "swine"):
        return w
    if re.search(r"[^aeiou]y$", low):
        return w[:-1] + "ies"
    if re.search(r"(s|x|z|ch|sh)$", low):
        return w + "es"
    return w + "s"


def plural(name: str, n: int = 2) -> str:
    """'Wolf Pelt' -> 'Wolf Pelts', 'Dire Wolf' -> 'Dire Wolves', 'Potion of Healing' -> 'Potions of Healing'."""
    if n == 1 or not name:
        return name
    words = name.split(" ")
    if " of " in name:
        i = words.index("of") - 1
        if i >= 0:
            words[i] = _plural_word(words[i])
            return " ".join(words)
    words[-1] = _plural_word(words[-1])
    return " ".join(words)


def counted(name: str, n: int) -> str:
    return f"{n} {plural(name, n)}" if n != 1 else (f"a {name}" if name[:1].lower() not in "aeiou" else f"an {name}")


def cap(text: str) -> str:
    """Capitalize the first letter only (str.capitalize would lowercase names)."""
    return text[:1].upper() + text[1:] if text else text


def number_word(n: int) -> str:
    return NUMBERS[n] if 0 <= n < len(NUMBERS) else str(n)


def first_name(name: str) -> str:
    return (name or "Someone").split(" ")[0]


# ======================================================================
# Party strength and encounters
# ======================================================================
def group_multiplier(n: int) -> float:
    if n <= 1:
        return 1.0
    if n == 2:
        return 1.5
    if n <= 6:
        return 2.0
    if n <= 10:
        return 2.5
    if n <= 14:
        return 3.0
    return 4.0


def xp_budget(levels: list[int], difficulty: str = "Medium") -> tuple[int, int, int]:
    """(lowest, target, highest) adjusted XP for an encounter of that difficulty."""
    levels = [max(1, min(20, int(l))) for l in levels] or [1]
    i = DIFFICULTIES.index(difficulty) if difficulty in DIFFICULTIES else 1
    target = sum(XP_THRESHOLDS[l][i] for l in levels)
    low = sum(XP_THRESHOLDS[l][max(0, i - 1)] for l in levels) if i > 0 else target // 2
    high = sum(XP_THRESHOLDS[l][min(3, i + 1)] for l in levels) if i < 3 else int(target * 1.25)
    return low, target, high


def enemy_xp(enemy) -> int:
    return int(enemy.fields.get("xp") or 0) or CR_XP.get(str(enemy.fields.get("cr", "0")), 10)


def encounter_options(world, levels: list[int], difficulty: str = "Medium", terrain: str = "",
                      max_count: int = 8) -> list[tuple]:
    """[(enemy, count, adjusted xp, score)] best first. One creature near the party's level
    is preferred; groups of weaker ones fill in when nothing fits alone."""
    low, target, high = xp_budget(levels, difficulty)
    avg_level = sum(levels) / max(1, len(levels))
    out = []
    for enemy in world.entities.all("enemy"):
        if "summon" in (enemy.tags or []):          # a summoned companion, not something met in the wild
            continue
        if "unique" in (enemy.tags or []) or enemy.fields.get("lair"):   # one of a kind, waiting in its lair
            continue
        xp = enemy_xp(enemy)
        if xp <= 0:
            continue
        for n in range(1, max_count + 1):
            adj = xp * n * group_multiplier(n)
            if adj > high:
                break
            if adj < low:
                continue
            score = abs(adj - target) / max(1, target)
            score += 0.08 * (n - 1)                                      # fewer, tougher foes read better
            score += 0.05 * abs(cr_value(enemy.fields.get("cr", "0")) - avg_level / max(1, n))
            if terrain and terrain not in (enemy.fields.get("environments") or []):
                score += 0.25
            out.append((enemy, n, int(adj), score))
    out.sort(key=lambda t: t[3])
    return out


def hunt_environment(enemy, terrain: str, rng: random.Random) -> str:
    envs = [e for e in (enemy.fields.get("environments") or []) if e in ENV_TO_MAP]
    if terrain in envs:
        return terrain
    if envs:
        return rng.choice(envs)
    return terrain if terrain in ENV_TO_MAP else "Forest"


def loot_sources(world, item_id: str) -> list[tuple]:
    """[(enemy, chance %)] enemies that can drop this item."""
    out = []
    for enemy in world.entities.all("enemy"):
        for row in enemy.fields.get("loot") or []:
            if row.get("item") == item_id:
                out.append((enemy, float(row.get("chance", 100) or 100)))
    return sorted(out, key=lambda t: -t[1])


# ======================================================================
# The generator
# ======================================================================
class QuestGenerator:
    def __init__(self, world, rng: random.Random | None = None) -> None:
        self.world = world
        self.rng = rng or random.Random()

    # ----- context
    def _town(self, npc):
        return self.world.entities.get(places.town_of(self.world, npc))

    def _terrain(self, npc) -> str:
        town = self._town(npc)
        return (town.fields.get("terrain") if town else "") or "Plains"

    def _direction(self, npc) -> str:
        """The way out of town this quest points (lower case for sentences)."""
        if getattr(self, "_dir", None):
            return self._dir
        town = self._town(npc)
        dirs = list(places.town_exits(town)) if town is not None else []
        return (self.rng.choice(dirs) if dirs else self.rng.choice(DIRECTIONS)).lower()

    def _hunt(self, npc, enemy_id: str, count: int, env: str, where: str) -> dict:
        """Where the quarry is: the wilds off one side of the giver's town."""
        town = self._town(npc)
        direction = next((d for d in DIRECTIONS if d.lower() == self._direction(npc)), "North")
        return {"enemy": enemy_id, "count": count, "environment": env, "where": where,
                "town": town.id if town is not None else "", "direction": direction}

    def _where(self, npc, env: str) -> str:
        town = self._town(npc)
        place = ENV_PHRASE.get(env, "nearby")
        return f"{place} {self._direction(npc)} of {town.name}" if town else place

    # ----- choosing a kind
    def kinds_available(self, npc, levels: list[int], difficulty: str = "Medium") -> list[str]:
        out = []
        if self._fetch_candidates(npc):
            out.append("Fetch")
        if encounter_options(self.world, levels, difficulty, self._terrain(npc)):
            out.append("Defeat")
        if self._visit_candidates(npc):
            out.append("Visit")
        return out

    def pick_kind(self, npc, available: list[str]) -> str | None:
        if not available:
            return None
        weights = KIND_WEIGHTS.get(npc.fields.get("occupation") or "", DEFAULT_WEIGHTS)
        w = [weights[KINDS.index(k)] for k in available]
        return self.rng.choices(available, weights=w, k=1)[0]

    def generate(self, npc, kind: str | None, levels: list[int], difficulty: str = "Medium",
                 reward_scale: float = 1.0, allowed: list[str] | None = None) -> dict | None:
        available = [k for k in self.kinds_available(npc, levels, difficulty) if not allowed or k in allowed]
        if kind and kind not in available:
            return None
        kind = kind or self.pick_kind(npc, available)
        if kind is None:
            return None
        level = max(1, round(sum(levels) / max(1, len(levels))))
        self._dir = None
        self._dir = self._direction(npc)          # one direction for the whole quest
        quest = {"Fetch": self._fetch, "Defeat": self._defeat, "Visit": self._visit}[kind](npc, levels, difficulty)
        if quest is None:
            return None
        quest.update({"kind": kind, "giver": npc.id, "giver_name": npc.name, "source": "generated",
                      "level": level, "return_to_giver": True, "status": "offered", "tracked": False,
                      "journal": []})
        for o in quest["objectives"]:
            o.setdefault("progress", 0)
            o.setdefault("done", False)
            o.setdefault("count", 1)
        r = quest["rewards"]
        r["gold"] = max(5, int(round(r.get("gold", 0) * reward_scale / 5.0)) * 5)
        r["xp"] = max(10, int(round(r.get("xp", 0) * reward_scale / 5.0)) * 5)
        r.setdefault("items", {})
        return quest

    def _base_xp(self, levels: list[int]) -> int:
        return xp_budget(levels, "Medium")[1]

    # ----- Fetch
    def _fetch_candidates(self, npc) -> list[tuple]:
        """[(item, sources, score)] items this NPC would want that can be got."""
        wants = set(WANTS.get(npc.fields.get("occupation") or "", ["material"]))
        wants |= {t.lower() for t in npc.fields.get("sells_tags") or []}
        out = []
        for item in self.world.entities.all("item"):
            sources = loot_sources(self.world, item.id)
            if not sources:
                continue          # nothing in the world carries it (shops arrive with Trade)
            f = item.fields
            tags = {t.lower() for t in item.tags} | {str(f.get("category") or "").lower()}
            score = len(tags & wants) * 2.0
            if f.get("category") in ("Material", "Consumable", "Treasure"):
                score += 1.0
            if f.get("rarity") not in (None, "", "Common"):
                score -= 1.5
            out.append((item, sources, score))
        out.sort(key=lambda t: -t[2])
        return out

    def _fetch(self, npc, levels, difficulty) -> dict | None:
        cands = self._fetch_candidates(npc)
        if not cands:
            return None
        top = [c for c in cands if c[2] >= cands[0][2] - 1.0][:5]
        item, sources, _score = self.rng.choice(top)
        enemy, chance = sources[0]
        stack = bool(item.fields.get("stackable")) or item.fields.get("category") in ("Material", "Consumable")
        count = 1
        if stack:
            count = max(1, min(6, int(round(self.rng.uniform(1.5, 3.0) * chance / 100.0 * 2))))
        terrain = self._terrain(npc)
        env = hunt_environment(enemy, terrain, self.rng)
        options = [o for o in encounter_options(self.world, levels, "Easy", terrain) if o[0].id == enemy.id]
        hunt_n = options[0][1] if options else 1
        where = self._where(npc, env)
        thing = counted(item.name, count)
        source_txt = f"{plural(enemy.name)} {where} carry them" if count > 1 else f"{plural(enemy.name)} {where} carry one"
        hint = f"{plural(enemy.name)} carry {plural(item.name)} ({int(chance)}% each)"
        occ = npc.fields.get("occupation") or ""
        lines = {
            "Blacksmith": f"The forge eats {plural(item.name)} faster than I can buy them. Bring me {thing}.",
            "Armorer": f"I can't patch a jerkin without {plural(item.name)}. {cap(thing)} would do.",
            "Innkeeper": f"Kitchen's short. If you can find {thing}, there's coin in it.",
            "Alchemist": f"My next batch needs {thing}. Fresh, if you can manage it.",
            "Hunter": f"I've traps to mend and no {plural(item.name)} to do it with. Get me {thing}.",
            "Merchant": f"I've a buyer waiting on {thing}. Get them to me and we'll split the profit, more or less.",
        }
        pitch = lines.get(occ, self.rng.choice([
            f"I could use {thing}. Bring them here and I'll make it worth your while." if count > 1 else
            f"I could use {thing}. Bring it here and I'll make it worth your while.",
            f"I'm running low on {plural(item.name)}. {cap(thing)} would see me through.",
        ]))
        pitch += f" {cap(source_txt)}, if you're not squeamish."
        title = self.rng.choice([
            f"{plural(item.name, count)} for {first_name(npc.name)}",
            f"{first_name(npc.name)}'s {plural(item.name, count)}",
            f"A Need for {plural(item.name)}",
        ])
        value = float(item.fields.get("value") or 1)
        base = self._base_xp(levels)
        return {
            "title": title, "pitch": pitch,
            "objectives": [{"text": f"Bring {thing} to {npc.name}", "kind": "Fetch", "target": item.id,
                            "count": count, "hint": hint,
                            "hunt": self._hunt(npc, enemy.id, hunt_n, env, where)}],
            "rewards": {"gold": 10 * max(1, round(sum(levels) / len(levels))) + value * count * 1.5 + base * 0.04,
                        "xp": base * 0.3},
        }

    # ----- Defeat
    def _defeat(self, npc, levels, difficulty) -> dict | None:
        terrain = self._terrain(npc)
        options = encounter_options(self.world, levels, difficulty, terrain)
        if not options:
            return None
        enemy, n, adj, _ = self.rng.choice(options[:4])
        env = hunt_environment(enemy, terrain, self.rng)
        where = self._where(npc, env)
        foes = counted(enemy.name, n)
        noun = ENV_NOUN.get(env, "Wilds")
        title = self.rng.choice([
            f"{plural(enemy.name, n)} in the {noun}" if n > 1 else f"Hunt the {enemy.name}",
            f"Trouble in the {noun}",
            f"Trouble on the {self._direction(npc).title()} Road",
        ])
        occ = npc.fields.get("occupation") or ""
        if occ in ("Guard", "Mercenary"):
            pitch = f"We've had reports of {foes} {where}. The watch is stretched thin. Deal with {'them' if n > 1 else 'it'}."
        elif occ == "Farmer":
            pitch = f"Something's been at my animals. Folk say it's {foes} {where}. Put an end to it, please."
        else:
            pitch = self.rng.choice([
                f"{cap(foes)} {'have' if n > 1 else 'has'} been seen {where}. Nobody's safe on the road "
                f"while {'they live' if n > 1 else 'it lives'}. Deal with {'them' if n > 1 else 'it'} and I'll pay.",
                f"There {'are' if n > 1 else 'is'} {foes} {where}, and I want {'them' if n > 1 else 'it'} gone. "
                f"Can you do it?",
            ])
        base = self._base_xp(levels)
        return {
            "title": title, "pitch": pitch,
            "objectives": [{"text": f"Defeat {foes} {where}", "kind": "Defeat", "target": enemy.id, "count": n,
                            "hint": f"CR {enemy.fields.get('cr', '?')}  ·  {difficulty.lower()} fight for your party",
                            "hunt": self._hunt(npc, enemy.id, n, env, where)}],
            "rewards": {"gold": 15 * max(1, round(sum(levels) / len(levels))) + adj / 8, "xp": base * 0.35},
        }

    # ----- Visit
    def _visit_candidates(self, npc) -> list:
        """Buildings in the NPC's own town, and towns (with their buildings) up to two roads
        away. In a world without roads, every town."""
        home = places.building_of(self.world, npc)
        town_id = places.town_of(self.world, npc)
        town = self.world.entities.get(town_id)
        out = []
        if town is not None:
            out += [b for b in places.buildings_in(self.world, town) if b.id != home]
        near: list = []
        frontier = [town] if town is not None else []
        seen = {town_id}
        for _hop in range(2):
            nxt = []
            for t in frontier:
                for r in places.roads_of(t):
                    other = self.world.entities.get(r.get("leads_to"))
                    if other is not None and other.type == "town" and other.id not in seen:
                        seen.add(other.id)
                        nxt.append(other)
            near += nxt
            frontier = nxt
        if not near and len(self.world.entities.all("town")) <= 40:
            near = [t for t in self.world.entities.all("town") if t.id != town_id]
        for t in near:
            out.append(t)
            out += places.buildings_in(self.world, t)[:6]
        return out

    def _visit(self, npc, levels, difficulty) -> dict | None:
        cands = self._visit_candidates(npc)
        if not cands:
            return None
        here = places.town_of(self.world, npc)
        far = [c for c in cands if places.town_of(self.world, c) != here]
        place = self.rng.choice(far if far and self.rng.random() < 0.5 else cands)
        same_town = places.town_of(self.world, place) == here
        people = places.people_in(self.world, place)
        whom = people[0].name if people else ""
        if place.type == "town":
            pitch = self.rng.choice([
                f"I need word carried to {place.name}. Go there, ask around, let them know {first_name(npc.name)} sent you.",
                f"Haven't heard from {place.name} in a while. Would you travel there and see that all's well?",
            ])
        elif whom:
            pitch = self.rng.choice([
                f"Would you look in on {whom} at {place.name} for me? Tell them I asked after them.",
                f"Run over to {place.name}, would you? {first_name(whom)} owes me an answer.",
            ])
        else:
            pitch = f"I need someone to go to {place.name} and have a look around. I'll explain when you're back."
        title = self.rng.choice([f"An Errand to {place.name}", f"Word for {place.name}", f"The Road to {place.name}"]
                                if not same_town else [f"An Errand to {place.name}", f"Word for {place.name}"])
        base = self._base_xp(levels)
        lvl = max(1, round(sum(levels) / len(levels)))
        return {
            "title": title, "pitch": pitch,
            "objectives": [{"text": f"Go to {place.name}", "kind": "Visit", "target": place.id, "count": 1,
                            "hint": "in town" if same_town else "another town"}],
            "rewards": {"gold": (6 if same_town else 20) * lvl + 5, "xp": base * (0.15 if same_town else 0.25)},
        }


# ======================================================================
# Hand-made quests
# ======================================================================
def from_entity(world, entity, npc=None) -> dict:
    f = entity.fields
    giver = world.entities.get(f.get("giver")) or npc
    objectives = []
    for row in f.get("objectives") or []:
        kind = row.get("kind") or "Custom"
        target = row.get("target") or ""
        obj = {"text": row.get("text") or kind, "kind": kind, "target": target,
               "count": max(1, int(row.get("count") or 1)), "progress": 0, "done": False, "hint": ""}
        t = world.entities.get(target)
        if kind == "Fetch" and t is not None:
            src = loot_sources(world, t.id)
            if src:
                enemy, chance = src[0]
                obj["hint"] = f"{plural(enemy.name)} carry {plural(t.name)} ({int(chance)}% each)"
                env = hunt_environment(enemy, "", random.Random(0))
                obj["hunt"] = {"enemy": enemy.id, "count": 1, "environment": env, "where": ENV_PHRASE.get(env, "")}
        if kind == "Defeat" and t is not None and t.type == "enemy":
            env = hunt_environment(t, "", random.Random(0))
            obj["hunt"] = {"enemy": t.id, "count": obj["count"], "environment": env,
                           "where": ENV_PHRASE.get(env, "")}
        objectives.append(obj)
    items = {}
    for i in f.get("reward_items") or []:
        items[i] = items.get(i, 0) + 1
    return {
        "title": entity.name, "kind": f.get("kind") or "Custom", "giver": giver.id if giver else "",
        "giver_name": giver.name if giver else "", "source": entity.id,
        "pitch": entity.description or (f"I have a task for you: {entity.name}." if giver else entity.name),
        "level": int(f.get("level") or 1), "objectives": objectives,
        "return_to_giver": bool(f.get("return_to_giver", True)) and bool(giver),
        "status": "offered", "tracked": False, "journal": [],
        "rewards": {"gold": int(f.get("reward_gold") or 0), "xp": int(f.get("reward_xp") or 0), "items": items},
    }


# ======================================================================
# The quest book: offers, progress, hand-ins
# ======================================================================
class QuestBook:
    def __init__(self, world, state, bus=None, rng: random.Random | None = None,
                 levels=lambda: [1]) -> None:
        self.world = world
        self.state = state
        self.bus = bus
        self.rng = rng or random.Random()
        self.levels = levels                # callable returning the party's levels
        self.counting = True                # False during test fights (Arena)
        self._offs = []
        if bus is not None:
            self._offs = [
                bus.on("inventory.changed", lambda e: self.check_all()),
                bus.on("combat.defeated", self._on_defeated),
                bus.on("location.entered", self._on_entered),
                bus.on("npc.talked", lambda e: self.talked(e.get("npc", ""))),
                bus.on("estate.built", lambda e: self.check_all()),
            ]

    def close(self) -> None:
        """Stop listening (when another world is opened)."""
        for off in self._offs:
            off()
        self._offs = []

    # ----- helpers
    def _emit(self, name: str, **data) -> None:
        if self.bus is not None:
            self.bus.emit(name, **data)

    def _log(self, text: str, kind: str = "quest") -> None:
        self._emit("log", kind=kind, text=text)

    def rules(self) -> dict:
        return self.world.rules

    def get(self, quest_id: str) -> dict | None:
        return next((q for q in self.state.quests if q.get("id") == quest_id), None)

    def active(self) -> list[dict]:
        return [q for q in self.state.quests if q.get("status") in ("active", "ready")]

    def finished(self) -> list[dict]:
        return [q for q in self.state.quests if q.get("status") in ("completed", "abandoned", "failed")]

    def giver_died(self, npc_id: str) -> None:
        """Quests from someone who's now dead can't be handed in (a chain passes to an heir: game/chains.py)."""
        from game import chains
        chains.npc_died(self.world, self.state, self, npc_id)
        for q in self.active():
            if q.get("chain"):
                continue
            if q.get("giver") == npc_id and q.get("return_to_giver"):
                q["status"] = "failed"
                q["tracked"] = False
                q["journal"].append(f"Day {self.state.day}: {q.get('giver_name')} is dead. The quest has failed.")
                self._log(f"Quest failed: {q['title']} ({q.get('giver_name')} is dead).", "system")
                self._emit("quest.failed", quest=q)
        self._retrack()
        self.state.save()

    def cooldown_days(self, npc) -> int:
        own = int(npc.fields.get("quest_cooldown_days") or 0)
        return own or int(self.rules().get("quest_cooldown_days", 7) or 7)

    def days_until_next(self, npc) -> int:
        mem = self.state.npc(npc.id)
        last = mem.get("last_quest_day")
        if last is None:
            return 0
        return max(0, int(last) + self.cooldown_days(npc) - self.state.day)

    # ----- offering
    def handmade_available(self, npc) -> list:
        out = []
        ids = list(npc.fields.get("quests") or [])
        ids += [q.id for q in self.world.entities.by_field("quest", "giver", npc.id) if q.id not in ids]
        for qid in ids:
            e = self.world.entities.get(qid)
            if e is None or e.type != "quest":
                continue
            from game import chains
            _ql, idx = chains.questline_of(self.world, e.id)
            if idx > 0:                                        # a later step of a questline: it comes in turn
                continue
            taken = [q for q in self.state.quests if q.get("source") == e.id]
            if any(q["status"] in ("active", "ready") for q in taken):
                continue
            if any(q["status"] == "completed" for q in taken) and not e.fields.get("repeatable"):
                continue
            out.append(e)
        return out

    def from_npc_active(self, npc) -> list[dict]:
        return [q for q in self.active() if q.get("giver") == npc.id]

    def offer(self, npc, kind: str | None = None) -> tuple[dict | None, str]:
        """What this NPC offers when asked for work: (quest or None, what they say)."""
        name = first_name(npc.name)
        from game import chains
        hand = self.handmade_available(npc)
        if hand:                                             # what the world's author gave them comes first
            quest = from_entity(self.world, hand[0], npc)
            quest["id"] = "offer"
            return quest, quest["pitch"]
        if self.from_npc_active(npc):
            return None, "You're still working on what I asked. Finish that first."
        if not kind:                                         # asked for a particular job: that, not a story
            st = chains.starter_offer(self.world, self.state, npc, self.levels())
            if st is not None:                               # the starter: theirs to offer until it's taken
                return st, st["pitch"]
            nxt = chains.follow_up(self.world, self.state, npc, self.levels())
            if nxt is not None:
                return nxt, nxt["pitch"]
        wait = self.days_until_next(npc)
        if wait:
            return None, (f"Nothing right now. Come back in {wait} day{'s' if wait != 1 else ''}, "
                          f"I might have something then.")
        mem = self.state.npc(npc.id)
        remembered = mem.get("offer")
        if remembered and self.state.day < int(remembered.get("offered_day", 0)) + self.cooldown_days(npc):
            if kind and remembered["kind"] != kind:
                return remembered, "That's not what I need, but here's what I've got. " + remembered["pitch"]
            return remembered, remembered["pitch"]
        rules = self.rules()
        if not kind and (npc.fields.get("occupation") or "") in chains.OCC_STORY and \
                random.Random(f"{npc.id}|{self.state.day}").random() < chains.CHAIN_CHANCE and \
                not any(c.get("giver") == npc.id and c.get("status") == "active" for c in chains.all_chains(self.state)):
            ch = chains.offer(self.world, self.state, npc, self.levels())
            if ch is not None:
                ch["offered_day"] = self.state.day
                mem["offer"] = ch
                self.state.save()
                self._emit("quest.offered", quest=ch, npc=npc.id)
                return ch, ch["pitch"]
        allowed = [k for k in KINDS if k in (rules.get("quest_kinds") or KINDS)]
        gen = QuestGenerator(self.world, self.rng)
        quest = gen.generate(npc, kind, self.levels(), rules.get("quest_difficulty", "Medium"),
                             float(rules.get("quest_reward_scale", 1.0) or 1.0), allowed)
        if quest is None:
            if kind:
                what = {"Fetch": "need fetching", "Defeat": "need fighting", "Visit": "need doing elsewhere"}[kind]
                return None, f"Nothing that {what}, sorry."
            return None, f"I can't think of anything, sorry. ({name} has no work that fits this world yet.)"
        quest["id"] = "offer"
        quest["offered_day"] = self.state.day
        mem["offer"] = quest
        self.state.save()
        self._emit("quest.offered", quest=quest, npc=npc.id)
        return quest, quest["pitch"]

    def accept(self, quest: dict, npc=None) -> dict:
        if quest.get("chain_offer"):                          # a chain: filled in now, and its first step begun
            from game import chains
            if quest.get("giver") and (quest.get("chain_offer") or {}).get("giver") == quest.get("giver"):
                mem = self.state.npc(quest["giver"])
                mem["last_quest_day"] = self.state.day
                mem.pop("offer", None)
            q = chains.begin(self.world, self.state, self, quest)
            if q is not None:
                return q
        q = dict(quest)
        q["id"] = self.state.next_id("q")
        q["status"] = "active"
        q["accepted_day"] = self.state.day
        q["journal"] = [f"Day {self.state.day}: accepted from {q.get('giver_name') or 'nobody in particular'}."]
        if not any(o.get("tracked") for o in self.active()):
            q["tracked"] = True
        self.state.quests.append(q)
        if q.get("source", "").startswith("quest."):
            from game import chains
            chains.begin_questline(self.world, self.state, self, q)
        if q.get("giver") and q.get("source") == "generated":
            mem = self.state.npc(q["giver"])
            mem["last_quest_day"] = self.state.day
            mem.pop("offer", None)
        self.state.save()
        self._log(f"Quest accepted: {q['title']}")
        self._emit("quest.accepted", quest=q)
        self.check(q)
        return q

    def abandon(self, quest_id: str) -> None:
        q = self.get(quest_id)
        if not q or q["status"] not in ("active", "ready"):
            return
        q["status"] = "abandoned"
        q["tracked"] = False
        q["journal"].append(f"Day {self.state.day}: abandoned.")
        self._retrack()
        self.state.save()
        self._log(f"Quest abandoned: {q['title']}", "system")
        self._emit("quest.abandoned", quest=q)

    def track(self, quest_id: str) -> None:
        self.state.pin = {}
        for q in self.state.quests:
            q["tracked"] = q.get("id") == quest_id and q["status"] in ("active", "ready")
        self.state.save()
        self._emit("quest.tracked", quest=self.get(quest_id))

    def _retrack(self) -> None:
        """Nothing pinned any more: the newest quest is."""
        if not any(q.get("tracked") for q in self.active()) and self.active():
            self.active()[-1]["tracked"] = True

    # ----- the map pin
    def pinned(self) -> dict | None:
        """The pinned quest: the one chosen in the journal, else the most recently taken."""
        act = self.active()
        return next((q for q in act if q.get("tracked")), None) or (act[-1] if act else None)

    def pin_rumor(self, rumor_id: str) -> None:
        self.state.pin = {"rumor": rumor_id} if rumor_id else {}
        self.state.save()
        self._emit("quest.tracked", quest=None)

    def objective_place(self, q: dict) -> tuple[str, str]:
        """(place id, what to do there) for a quest's next objective (its giver when it's ready)."""
        from game import chains
        if q.get("status") == "ready":
            return chains._loc_of(self.world, q.get("giver") or ""), f"Return to {q.get('giver_name')}"
        o = next((o for o in q["objectives"] if not o.get("done")), None)
        if o is None:
            return "", ""
        if o.get("where"):
            return o["where"], o["text"]
        h = o.get("hunt") or {}
        if h.get("town") and h.get("direction"):
            return places.wild_id(h["town"], h["direction"]), o["text"]
        tgt = self.world.entities.get(o.get("target") or "")
        if tgt is not None and tgt.type in ("npc", "town", "building", "dungeon", "landmark"):
            return chains._loc_of(self.world, tgt.id), o["text"]
        return chains._loc_of(self.world, q.get("giver") or ""), o["text"]

    def pin_target(self) -> dict | None:
        """What the map pin points to: {"title", "text", "loc", "pos": (x, y) map miles, "quest" or "rumor"}."""
        from game import geography as G
        from game import rumors
        pin = self.state.pin or {}
        if pin.get("rumor"):
            r = next((x for x in rumors.heard(self.state) if x.get("id") == pin["rumor"]), None)
            if r is not None:
                return {"title": "Rumor", "text": r["text"], "loc": r.get("loc") or "", "rumor": r["id"],
                        "pos": rumors.position(self.world, self.state, r)}
        q = self.pinned()
        if q is None:
            return None
        loc, text = self.objective_place(q)
        pos = None
        if loc:
            try:
                pos = G.party_position_of(self.world, places.parse(self.world, loc), self.state)
            except Exception:  # noqa: BLE001 - somewhere not on the map
                pos = None
        return {"title": q["title"], "text": text, "loc": loc, "quest": q["id"], "pos": pos}

    # ----- progress
    def check_all(self) -> None:
        for q in list(self.active()):
            self.check(q)

    def check(self, q: dict) -> None:
        """Work out fetch counts and whether the quest is ready, and report changes."""
        changed = False
        for o in q["objectives"]:
            if o["kind"] in ("Gather", "Craft"):
                have = min(o["count"], self._have(o["target"]))
                if o["kind"] == "Gather" and o.get("done"):
                    continue                                 # gathered once is enough (it may be crafted with)
                if have != o.get("progress"):
                    o["progress"] = have
                    changed = True
                done = have >= o["count"]
                if done != o.get("done"):
                    o["done"] = done
                    changed = True
                continue
            if o["kind"] == "Build":
                from game import estate
                have = min(int(o.get("count") or 1), estate.built_count(self.world, o.get("target") or ""))
                if have != o.get("progress"):
                    o["progress"] = have
                    changed = True
                    if 0 < have < int(o.get("count") or 1):
                        self._log(f"Quest updated: {q['title']}  ·  {o['text']} ({have}/{o['count']})")
                done = have >= int(o.get("count") or 1)
                if done != o.get("done"):
                    o["done"] = done
                    changed = True
                continue
            if o["kind"] == "Fetch":
                have = min(o["count"], self.state.count(o["target"]))
                if have != o.get("progress"):
                    o["progress"] = have
                    changed = True
                    if 0 < have < o["count"]:
                        self._log(f"Quest updated: {q['title']}  ·  {o['text']} ({have}/{o['count']})")
                done = have >= o["count"]
                if done != o.get("done"):
                    o["done"] = done
                    changed = True
        all_done = all(o.get("done") for o in q["objectives"]) and q["objectives"]
        before = q["status"]
        if all_done and before == "active":
            if q.get("return_to_giver") and q.get("giver"):
                q["status"] = "ready"
                q["journal"].append(f"Day {self.state.day}: all done. Return to {q.get('giver_name')}.")
                self._log(f"Quest ready: {q['title']}  ·  return to {q.get('giver_name')}.")
                self._emit("quest.ready", quest=q)
            else:
                self.complete(q)
                return
            changed = True
        elif not all_done and before == "ready":
            q["status"] = "active"
            changed = True
        if changed:
            self.state.save()
            self._emit("quest.updated", quest=q)

    def _advance(self, kind: str, target_ids: set[str], amount: int = 1) -> None:
        for q in list(self.active()):
            hit = False
            for o in q["objectives"]:
                if o["kind"] == kind and not o.get("done") and o.get("target") in target_ids:
                    o["progress"] = min(o["count"], int(o.get("progress", 0)) + amount)
                    o["done"] = o["progress"] >= o["count"]
                    hit = True
                    if o["count"] > 1:
                        self._log(f"Quest updated: {q['title']}  ·  {o['text']} ({o['progress']}/{o['count']})")
                    elif o["done"]:
                        self._log(f"Quest updated: {q['title']}  ·  {o['text']}  ·  done")
            if hit:
                self.state.save()
                self._emit("quest.updated", quest=q)
                self.check(q)

    def _on_defeated(self, event) -> None:
        c = event.get("combatant")
        if c is None or getattr(c, "team", "") == "player":
            return
        entity_id = getattr(c, "entity_id", "") or ""
        if not self.counting:
            return
        self.state.record_kill(entity_id)
        self.defeated(entity_id)

    def defeated(self, entity_id: str) -> None:
        self._advance("Defeat", {entity_id})

    def _on_entered(self, event) -> None:
        self.entered(event.get("location", ""), event.get("town", ""))

    def entered(self, location_id: str, town_id: str = "") -> None:
        ids = self._place_ids(location_id, town_id)          # anywhere in a dungeon counts as reaching it
        if (location_id or "").startswith("landmark|"):
            lm = self.world.entities.get(location_id.split("|")[1])
            if lm is not None and lm.fields.get("dungeon"):
                ids.add(lm.fields["dungeon"])
        self._advance("Visit", ids)
        self._advance("Escort", ids)

    def talked(self, npc_id: str) -> None:
        if not npc_id:
            return
        self._advance("Talk", {npc_id})
        for q in list(self.active()):                         # handing something over
            for o in q["objectives"]:
                if o["kind"] != "Deliver" or o.get("done") or o.get("target") != npc_id:
                    continue
                item = o.get("item") or ""
                if item and self._have(item) >= o["count"]:
                    self._take(item, o["count"], f"given for {q['title']}")
                    o["progress"], o["done"] = o["count"], True
                    who = self.world.entities.get(npc_id)
                    self._log(f"Quest updated: {q['title']}  ·  {o['text']}  ·  done")
                    q["journal"].append(f"Day {self.state.day}: handed it over to {who.name if who else 'them'}.")
                    self.state.save()
                    self._emit("quest.updated", quest=q)
                    self.check(q)

    def _have(self, item_id: str) -> int:
        """How many the party has (the pack and members' bags, any quality)."""
        from game import quality
        n = 0
        for k, v in (self.state.inventory or {}).items():
            if quality.base_of(k) == item_id:
                n += int(v)
        return n

    def _take(self, item_id: str, n: int, reason: str) -> None:
        from game import quality
        for k in sorted(list(self.state.inventory), key=lambda k: k != item_id):
            if n <= 0:
                break
            if quality.base_of(k) == item_id:
                n -= self.state.remove_item(k, n, reason=reason)

    def investigate_here(self, location_id: str, town_id: str = "") -> list[tuple[dict, int, dict]]:
        """Investigate objectives waiting at this place: [(quest, objective index, objective)]."""
        ids = self._place_ids(location_id, town_id)
        out = []
        for q in self.active():
            for i, o in enumerate(q["objectives"]):
                if o["kind"] == "Investigate" and not o.get("done") and \
                        (o.get("target") in ids or (o.get("where") or "") in ids):
                    out.append((q, i, o))
        return out

    def investigate(self, quest_id: str, index: int, members: list, rng: random.Random | None = None) -> tuple[bool, str]:
        """Look into it: the party's best Investigation or Perception against the objective's DC (an hour)."""
        from game import checks, condition
        q = self.get(quest_id)
        if not q or not (0 <= index < len(q["objectives"])):
            return False, ""
        o = q["objectives"][index]
        rng = rng or self.rng
        opts = {x["label"].lower(): x for x in checks.options(self.world)}
        best = None
        for m in members or []:
            if m.get("dead"):
                continue
            c = condition.combatant(self.world, m)
            for k in ("investigation", "perception"):
                opt = opts.get(k)
                if opt is not None:
                    b = checks.bonus(self.world, m, c, opt)[0]
                    if best is None or b > best[3]:
                        best = (m, c, opt, b)
        self.state.advance(60, "investigating")
        if best is None:
            return False, "There's nobody to look."
        m, c, opt, _b = best
        dc = int(o.get("dc") or 12)
        r = checks.roll(self.world, m, c, opt, dc, rng=rng, bus=self.bus, target=o["text"].lower())
        if not r.get("success"):
            return False, f"{m.get('name')} looks for an hour but finds nothing yet. Try again."
        o["progress"], o["done"] = o["count"], True
        q["journal"].append(f"Day {self.state.day}: {o['text'][:1].lower()}{o['text'][1:]}: found what there was to find.")
        self.state.save()
        self._log(f"Quest updated: {q['title']}  ·  {o['text']}  ·  done")
        self._emit("quest.updated", quest=q)
        self.check(q)
        return True, f"{m.get('name')} finds it."

    def choices_with(self, npc_id: str) -> list[tuple[dict, int, dict]]:
        """Decisions waiting in conversation with this person: [(quest, objective index, objective)]."""
        out = []
        for q in self.active():
            for i, o in enumerate(q["objectives"]):
                if o["kind"] == "Choose" and not o.get("done") and o.get("target") == npc_id:
                    out.append((q, i, o))
        return out

    def choose(self, quest_id: str, index: int, choice: int, members: list | None = None,
               rng: random.Random | None = None) -> tuple[bool, str]:
        """Make a decision: it sets the reward and the standing that follow, and goes in the journal."""
        q = self.get(quest_id)
        if not q or not (0 <= index < len(q["objectives"])):
            return False, ""
        o = q["objectives"][index]
        opts = o.get("choices") or []
        if not (0 <= choice < len(opts)):
            return False, ""
        c = opts[choice]
        if c.get("check") and members:
            from game import checks, condition
            label, dc = c["check"]
            opt = next((x for x in checks.options(self.world) if x["label"] == label), None)
            if opt is not None:
                m = max((x for x in members if not x.get("dead")),
                        key=lambda x: checks.bonus(self.world, x, condition.combatant(self.world, x), opt)[0])
                r = checks.roll(self.world, m, condition.combatant(self.world, m), opt, int(dc), rng=rng or self.rng,
                                bus=self.bus, target=c["text"].lower())
                if not r.get("success"):
                    return False, "They won't hear of it. Choose again."
        o["progress"], o["done"], o["chose"] = o["count"], True, choice
        q["chose"] = c.get("journal") or c["text"]
        q["journal"].append(f"Day {self.state.day}: {q['chose']}.")
        r = q.setdefault("rewards", {})
        r["gold"] = int(round(float(r.get("gold") or 0) * float(c.get("gold", 1.0) or 0) + 10 * float(c.get("gold", 1.0) or 0)))
        self._choice_standing(q, o, c)
        self.state.save()
        self._log(f"Quest updated: {q['title']}  ·  {q['chose']}")
        self._emit("quest.updated", quest=q)
        self.check(q)
        return True, q["chose"]

    def _choice_standing(self, q: dict, o: dict, c: dict) -> None:
        from game import factions
        giver = self.world.entities.get(q.get("giver") or "")
        other = self.world.entities.get(o.get("target") or "")
        for who, delta in ((giver, int(c.get("rep") or 0)), (other, int(c.get("other") or 0))):
            if who is None or not delta:
                continue
            try:
                f = factions.primary(self.world, who)
                if f is not None:
                    factions.change(self.world, self.state, f.id, delta, f"{q['title']}", self.bus)
            except Exception:  # noqa: BLE001 - a world without factions
                pass
            if delta < 0:
                self.state.npc(who.id)["disposition"] = "Wary"

    def _place_ids(self, location_id: str, town_id: str = "") -> set:
        ids = {i for i in (location_id, town_id) if i}
        kind, _s, rest = (location_id or "").partition("|")
        if kind in ("dungeon", "landmark") and rest:
            ids.add(rest.partition("|")[0])
            ids.add(f"{kind}|{rest.partition('|')[0]}")
        if kind == "room" and rest:
            ids.add(rest.partition("|")[0])
        if kind in ("street",) and rest:
            ids.add(rest.partition("|")[0])
        return ids

    def mark_done(self, quest_id: str, index: int) -> None:
        """For Custom objectives nothing else can finish."""
        q = self.get(quest_id)
        if q and 0 <= index < len(q["objectives"]):
            o = q["objectives"][index]
            o["progress"], o["done"] = o["count"], True
            self.state.save()
            self.check(q)

    # ----- handing in
    def ready_for(self, npc) -> list[dict]:
        return [q for q in self.active() if q.get("giver") == npc.id and q["status"] == "ready"]

    def hand_in(self, quest_id: str) -> list[str]:
        q = self.get(quest_id)
        if not q or q["status"] != "ready":
            return []
        self.check(q)                     # items may have been used since
        if q["status"] != "ready":
            return []
        for o in q["objectives"]:
            if o["kind"] == "Fetch":
                self.state.remove_item(o["target"], o["count"], reason=f"handed in for {q['title']}")
            elif o["kind"] == "Craft":
                self._take(o["target"], o["count"], f"handed in for {q['title']}")
        return self.complete(q)

    def complete(self, q: dict) -> list[str]:
        q["status"] = "completed"
        q["tracked"] = False
        q["completed_day"] = self.state.day
        q["journal"].append(f"Day {self.state.day}: completed.")
        lines = self.state.give_rewards(q.get("rewards") or {}, source=q["title"])
        self._retrack()
        self.state.save()
        self._log(f"Quest complete: {q['title']}" + (f"  ·  {', '.join(lines)}" if lines else ""), "loot")
        from game import factions
        factions.quest_done(self.world, self.state, q, self.bus)
        self._emit("quest.completed", quest=q, rewards=q.get("rewards"))
        if q.get("chain"):                                     # the next step of its story
            from game import chains
            chains.step_done(self.world, self.state, self, q)
        return lines

    # ----- for the screen
    def reward_text(self, q: dict) -> str:
        r = q.get("rewards") or {}
        bits = []
        if r.get("gold"):
            bits.append(f"{r['gold']} gold")
        if r.get("xp"):
            bits.append(f"{r['xp']} XP")
        for item_id, n in (r.get("items") or {}).items():
            item = self.world.entities.get(item_id)
            bits.append(f"{item.name if item else item_id}" + (f" x{n}" if n > 1 else ""))
        return "  ·  ".join(bits)

    def display(self, q: dict) -> dict:
        objs = []
        for o in q["objectives"]:
            text = o["text"]
            if o["count"] > 1 and o["kind"] in ("Fetch", "Defeat"):
                text += f"  ({o.get('progress', 0)}/{o['count']})"
            objs.append({"text": text, "done": bool(o.get("done"))})
        if q["status"] == "ready":
            giver = self.world.entities.get(q.get("giver"))
            where = places.parse(self.world, places.where_is(self.world, giver)) if giver else None
            where = where if where is not None and where.kind != "nowhere" else None
            objs.append({"text": f"Return to {q.get('giver_name')}" + (f" at {where.name}" if where else ""),
                         "done": False})
        where = ""
        if q["status"] in ("active", "ready"):
            loc, _t = self.objective_place(q)
            sp = places.parse(self.world, loc) if loc else None
            where = sp.name if sp is not None and sp.kind != "nowhere" else ""
        pinned = self.pinned()
        return {"id": q["id"], "title": q["title"], "kind": q.get("kind"), "giver": q.get("giver_name"),
                "tracked": bool(pinned is not None and pinned.get("id") == q["id"] and not (self.state.pin or {}).get("rumor")),
                "objectives": objs, "reward": self.reward_text(q), "status": q["status"], "where": where,
                "history": list(q.get("journal") or [])[-4:], "chain": q.get("chain") or ""}

    def journal(self) -> dict:
        """Everything the journal shows: chains with their steps, standalone quests, the finished, lore,
        rumors and the party's own notes."""
        from game import books, chains, rumors
        active = [self.display(q) for q in self.active()]
        groups = []
        for c in chains.all_chains(self.state):
            if c.get("status") not in ("active", "completed", "failed"):
                continue
            if c.get("questline"):
                rows = chains._questline_steps(self.world, c)
                titles = [(self.world.entities.get(r["quest"]).name if self.world.entities.get(r["quest"]) else "?")
                          for r in rows]
            else:
                titles = [st["title"] for st in c.get("steps") or []]
            at = int(c.get("step") or 0)
            steps = [{"title": t, "state": ("done" if (i < at or c["status"] == "completed") else
                                            "current" if i == at and c["status"] == "active" else
                                            "failed" if i == at else "todo")} for i, t in enumerate(titles)]
            cur = next((d for d in active if d["id"] == c.get("quest")), None)
            groups.append({"id": c["id"], "title": c["title"], "main": bool(c.get("main")), "status": c["status"],
                           "chapter": int(c.get("chapter") or 1), "giver": c.get("giver_name") or "",
                           "steps": steps, "quest": cur, "history": list(c.get("history") or [])[-5:],
                           "why": c.get("why") or ""})
        groups.sort(key=lambda g: (not g["main"], g["status"] != "active"))
        in_chain = {g["quest"]["id"] for g in groups if g["quest"]}
        standalone = [d for d in active if d["id"] not in in_chain]
        L = books.lore(self.state)
        pin = (self.state.pin or {}).get("rumor")
        return {"chains": groups, "active": standalone, "finished": [self.display(q) for q in self.finished()
                                                                     if not q.get("chain")],
                "lore": list(L["entries"]), "rumors": [dict(r, pinned=r.get("id") == pin) for r in rumors.heard(self.state)],
                "notes": L.get("notes") or ""}
