"""Empty lots with a "For sale" sign (laid out by game/townlayout.py), and the flyer you can take from one.

The flyer is a quest with one step: go and talk to the town's lot seller (the town's "Lot seller" field,
set when the towns were grown). It ends as soon as you talk to them, whether you buy anything or not, and
gives nothing: no experience, no money. One flyer per town at a time.
"""
from __future__ import annotations

from game import places


def seller(world, town):
    """Who sells the land in this town (None if nobody does)."""
    if town is None:
        return None
    npc = world.entities.get(town.fields.get("lot_seller") or "")
    return npc if npc is not None and npc.type == "npc" else None


def open_flyer(state, town_id: str) -> dict | None:
    for q in state.quests:
        if q.get("source") == "flyer" and q.get("town") == town_id and q.get("status") in ("active", "ready"):
            return q
    return None


def where_text(world, npc) -> str:
    spot = places.parse(world, places.where_is(world, npc))
    if spot is None or spot.kind == "nowhere":
        return ""
    if spot.building is not None:
        return f"at {spot.building.name}" + (f" on {spot.street}" if spot.street else "")
    return f"on {spot.street}" if spot.street else ""


def flyer_quest(world, town) -> dict | None:
    npc = seller(world, town)
    if npc is None:
        return None
    where = where_text(world, npc)
    who = npc.name + (f", {npc.fields.get('title')}" if npc.fields.get("title") else "")
    return {
        "title": f"Land for sale in {town.name}", "kind": "Talk", "giver": "", "giver_name": "a flyer",
        "source": "flyer", "town": town.id, "level": 0,
        "pitch": f"LAND FOR SALE. Good plots in {town.name}, ready to build on. Ask {who}{' ' + where if where else ''}.",
        "objectives": [{"text": f"Ask {npc.name} about the land for sale" + (f" ({where})" if where else ""),
                        "kind": "Talk", "target": npc.id, "count": 1, "progress": 0, "done": False,
                        "hint": where}],
        "return_to_giver": False, "status": "offered", "tracked": False, "rewards": {},
    }


def sign_prompt(world, state, town):
    """What reading a "For sale" sign offers: (title, text, [(label, action, enabled)])."""
    npc = seller(world, town)
    if npc is None:
        return ("For sale", "The sign is weathered past reading. Nobody seems to be selling.", [])
    where = where_text(world, npc)
    text = f"\"Land for sale. Enquire with {npc.name}{' ' + where if where else ''}.\""
    if open_flyer(state, town.id):
        return ("For sale", text + " You already have one of the flyers.", [])
    return ("For sale", text + " A few flyers are tucked into a box under the sign.",
            [("Take a flyer", ("activity", f"flyer:{town.id}"), True)])


def take_flyer(world, state, book, town_id: str) -> str:
    """Take a flyer: starts the quest. Returns what to tell the player."""
    town = world.entities.get(town_id)
    if town is None:
        return ""
    if open_flyer(state, town_id):
        return "You already have a flyer for the land here."
    q = flyer_quest(world, town)
    if q is None:
        return "There's nobody to ask."
    book.accept(q)
    return f"You take a flyer. {q['pitch']}"


__all__ = ["seller", "open_flyer", "flyer_quest", "sign_prompt", "take_flyer"]
