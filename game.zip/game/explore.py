"""Walking about a town, a building or a dungeon square by square (game/area.py has the maps).

The party is one token: its face, the member with the best Charisma. The Explorer moves it, opens
doors (and tries locks), works out what can be seen from where it stands, keeps track of what has
been seen before, puts people where they are at this hour, and turns stepping into a room or onto a
street into arriving there (places.enter), so everything that hangs off arriving still works.

Nothing here draws or asks: when something needs the player's say (a locked door, someone to talk
to, the edge of town) a step returns a Prompt with its options, and choose() carries one out. Options
that need a window (talking, trading, the world map) come back as actions for the screen to do.

Saved in the game state (state.explore):
    "pos":   {"area", "level", "x", "y", "loc", "facing"}
    "seen":  {area key: {"sig", "levels": {level key: base64 bitset}}}
    "doors": {area key: {"level:x,y": "open" | "unlocked" | "broken" | "locked"}}
    "keys":  [room locations the party may come and go from (a rented room)]
"""
from __future__ import annotations

import base64
import bisect
import math
import random
import zlib
from dataclasses import dataclass, field

from game import area as A
from game import places
from game import travel

STEPS_PER_MINUTE = 30                 # indoors and in town, poking about
WORLD_STEPS_PER_MINUTE = 50           # out on the open road: about 3 miles an hour
ENCOUNTER_SQUARES = 300               # how often a roll is made for meeting something, walking the wilds
CARDINAL = {"N": (0, -1), "S": (0, 1), "E": (1, 0), "W": (-1, 0)}
DIRS = {"N": (0, -1), "S": (0, 1), "E": (1, 0), "W": (-1, 0), "NE": (1, -1), "NW": (-1, -1), "SE": (1, 1),
        "SW": (-1, 1)}
DIR_WORDS = {"N": "north", "S": "south", "E": "east", "W": "west", "NE": "north-east", "NW": "north-west",
             "SE": "south-east", "SW": "south-west"}
HIDERS = ("pounce", "ambush", "camouflage", "false appearance", "stealth", "nimble escape", "surprise attack",
          "skulk", "lurk", "mimic", "chameleon", "hide")


@dataclass
class Token:
    id: str
    name: str
    x: int
    y: int
    level: str
    kind: str = "npc"                 # npc | enemy
    entity: str = ""                  # entity id (for the sprite)
    room: str = ""                    # location it belongs to
    home: tuple = (0, 0)
    hidden: bool = False
    wander: int = 0                   # squares it may stray from home
    count: int = 1
    facing: str = "S"                 # which way it's turned (N, S, E, W)
    group: str = ""                   # a band of monsters met on the road (see Explorer.tick)
    announced: bool = False
    at_work: bool = False             # standing at their work (a bar over them shows what they're making)


@dataclass
class Prompt:
    title: str
    text: str = ""
    options: list = field(default_factory=list)       # [(label, action tuple, enabled)]
    who: str = ""                                     # the person (entity id) it's about, for a portrait


@dataclass
class StepResult:
    moved: bool = False
    prompt: Prompt | None = None
    action: tuple | None = None       # something for the screen to do right away
    message: str = ""
    changed_level: bool = False
    entered: str = ""                 # a location newly arrived at


class Explorer:
    def __init__(self, world, state, bus=None, members=None, rng: random.Random | None = None) -> None:
        self.world, self.state, self.bus = world, state, bus
        self.members = members or (lambda: [])
        self.rng = rng or random.Random()
        self.area: A.Area | None = None
        self.level = "0"
        self.x = self.y = 0
        self.facing = "S"
        self.tokens: list[Token] = []
        self.visible: set[tuple[int, int]] = set()
        self._seen: dict[str, bytearray] = {}
        self._steps = 0
        self._last_spot = ""
        self._route = None                           # the way being travelled (see route)
        self._look_memo = None                       # what's opaque, while working out what's in sight
        self._look_open = None                       # the open land, when no town is in sight
        self.seen_version = 0                        # bumped when anything new is seen (the view redraws fog)
        self.door_version = 0                        # bumped when a door opens, shuts or is unlocked
        self.sub_progress = 0.0                      # part of the day a voyage is through (for the map)
        self._people_at = -1
        self._light_cache = None                     # the party's light and darkvision (see party_lights)
        self._weather_cache = None
        self.crowd_info: dict[str, dict] = {}        # the townsfolk on the streets now (game/crowds.py)
        self._crowd_looks: dict[str, list] = {}
        self._dirty_seen = False
        self.encounters: dict[str, dict] = {}       # group id -> {"rows", "text", "tokens": [Token]}
        self._enc_meter = 0
        self._enc_count = 0
        self._people: list[Token] = []

    # ==================================================================
    # Saved bits
    # ==================================================================
    @property
    def data(self) -> dict:
        ex = getattr(self.state, "explore", None)
        if not isinstance(ex, dict):
            ex = {}
            self.state.explore = ex
        return ex

    def _door_states(self) -> dict:
        return self.data.setdefault("doors", {}).setdefault(self.area.key, {})

    def door_state(self, level: str, c) -> str:
        if self.area is None:
            return ""
        return self._door_states().get(f"{level}:{c[0]},{c[1]}", "")

    def set_door(self, level: str, c, value: str) -> None:
        states = self._door_states()
        key = f"{level}:{c[0]},{c[1]}"
        was = states.get(key, "")
        states[key] = value
        self.door_version += 1
        if self.bus is not None and (was in ("open", "broken")) != (value in ("open", "broken")):
            self.bus.emit("door.opened" if value in ("open", "broken") else "door.closed")

    def _load_seen(self) -> None:
        """What's been seen here before. Plain levels keep one bitset each (checked against the level's
        size when first used); the open world keeps one per chunk."""
        from game import worldmap as WM
        self._seen = {}
        self.seen_version += 1
        self.door_version += 1
        rec = self.data.setdefault("seen", {}).get(self.area.key)
        if not rec or rec.get("sig") != self.area.sig:
            return
        for k, b64 in (rec.get("levels") or {}).items():
            if isinstance(b64, dict):
                self._seen[k] = WM.unpack_seen(b64.get("chunks") or "")
                continue
            try:
                self._seen[k] = bytearray(zlib.decompress(base64.b64decode(b64)))
            except Exception:  # noqa: BLE001 - a damaged record just means seeing it again
                continue

    def save_seen(self) -> None:
        from game import worldmap as WM
        if self.area is None or not self._dirty_seen:
            return
        levels = {}
        for k, v in self._seen.items():
            if isinstance(v, dict):
                levels[k] = {"chunks": WM.pack_seen(v)}
            else:
                levels[k] = base64.b64encode(zlib.compress(bytes(v), 6)).decode("ascii")
        self.data.setdefault("seen", {})[self.area.key] = {"sig": self.area.sig, "levels": levels}
        self._dirty_seen = False

    def _bits(self, lv) -> bytearray:
        b = self._seen.get(lv.key)
        size = (lv.w * lv.h + 7) // 8
        if not isinstance(b, bytearray) or len(b) != size:
            b = bytearray(size)
            self._seen[lv.key] = b
        return b

    def seen(self, lv, x: int, y: int) -> bool:
        if not lv.inside(x, y):
            return False
        b = self._seen.get(lv.key)
        if b is None:
            return False
        if getattr(lv, "chunked", False):
            from game.worldmap import CH
            cb = b.get((x // CH, y // CH)) if isinstance(b, dict) else None
            if cb is None:
                return False
            i = (y % CH) * CH + (x % CH)
            return bool(cb[i >> 3] & (1 << (i & 7)))
        i = (y - lv.oy) * lv.w + (x - lv.ox)
        if not isinstance(b, bytearray) or (i >> 3) >= len(b) or len(b) != (lv.w * lv.h + 7) // 8:
            return False
        return bool(b[i >> 3] & (1 << (i & 7)))

    def _mark(self, lv, x: int, y: int) -> None:
        if not lv.inside(x, y):
            return
        if getattr(lv, "chunked", False):
            from game.worldmap import CH, SEEN_BYTES
            d = self._seen.get(lv.key)
            if not isinstance(d, dict):
                d = self._seen[lv.key] = {}
            key = (x // CH, y // CH)
            cb = d.get(key)
            if cb is None:
                cb = d[key] = bytearray(SEEN_BYTES)
            i = (y % CH) * CH + (x % CH)
        else:
            cb = self._bits(lv)
            i = (y - lv.oy) * lv.w + (x - lv.ox)
        if not cb[i >> 3] & (1 << (i & 7)):
            cb[i >> 3] |= 1 << (i & 7)
            self._dirty_seen = True
            self.seen_version += 1

    def remember_pos(self) -> None:
        if self.area is not None:
            self.data["pos"] = {"area": self.area.key, "level": self.level, "x": self.x, "y": self.y,
                                "loc": self.state.location, "facing": self.facing}

    def save(self) -> None:
        if self.area is None:
            return
        self.remember_pos()
        self.save_seen()
        self.state.save()
        if getattr(self.world, "_unsaved_rooms", False):   # rooms made for the towns walked through
            self.world._unsaved_rooms = False
            self.world.entities.save("building")

    # ==================================================================
    # Where we are
    # ==================================================================
    def sync(self) -> bool:
        """Line the map up with where the game says the party is. Returns False when there's no map
        for here (the wilds, a road...)."""
        spot = places.current(self.world, self.state)
        a = self._area_for(spot)
        prev = self._last_spot
        self._last_spot = spot.id
        if a is None:
            if self.area is not None:
                self.save_seen()
            self.area = None
            self.tokens = []
            return False
        was_same = self.area is a
        if not was_same:
            if self.area is not None:
                self.save_seen()
                if (getattr(self.state, "destruction", None) or {}).get("fires"):
                    from game import fire                 # leaving a fire behind: it's settled now
                    fire.leave(self)
            self.area = a
            self._load_seen()
        if a.kind == "world":                          # the town or landmark it's all about, laid in first
            if spot.town is not None and spot.kind in ("street", "building", "wild"):
                a.load_town(spot.town)
            if spot.kind == "landmark" and spot.extra.get("landmark") is not None:
                a.load_site("landmark", spot.extra["landmark"].id)
        pos = self.data.get("pos") or {}
        same = was_same and prev and self.zone_loc() == spot.id
        if spot.kind in ("road", "voyage"):
            if not self.place_on_route():
                self.area = None
                self.tokens = []
                return False
        elif self.state.trek and a.kind == "world" and self.place_on_route():
            pass                                          # crossing country: wherever the trek has got to
        elif same:
            pass                                          # still standing in the right place
        elif pos.get("area") == a.key and pos.get("loc") == self.state.location and \
                a.levels.get(pos.get("level")) is not None and prev in ("", spot.id):
            self.level, self.x, self.y = pos["level"], int(pos["x"]), int(pos["y"])
            self.facing = pos.get("facing") or "S"
            self._unstick()
        else:
            self._place_for(spot, prev)
        self.refresh_people(force=True)
        self.look()
        self.remember_pos()
        return True

    def _unstick(self) -> None:
        """A saved spot that's now inside something (the town has grown a wall, a well, a house since):
        step out to the nearest open square."""
        if not self.layer(self.x, self.y).blocks(self.x, self.y):
            return
        for r in range(1, 40):
            for dy in range(-r, r + 1):
                for dx in range(-r, r + 1):
                    if max(abs(dx), abs(dy)) != r:
                        continue
                    x, y = self.x + dx, self.y + dy
                    lv = self.layer(x, y)
                    if not lv.blocks(x, y) and (x, y) not in lv.doors and (x, y) not in lv.exits:
                        self.x, self.y = x, y
                        return

    def _area_for(self, spot):
        """The map for a place: the walkable world for towns, the open country and landmarks (when the
        world has a map), a dungeon's own map, or (in a world with no map) the town on its own."""
        from game import geography as G
        from game import worldmap as WM
        if spot.kind in ("street", "building", "wild", "hex", "landmark") and WM.walkable(self.world):
            if spot.kind == "hex" or spot.kind == "landmark" or G.town_position(self.world, spot.town) is not None:
                return WM.world_area(self.world)
            if spot.kind == "building" and spot.building is not None and spot.building.fields.get("claim"):
                return WM.world_area(self.world)             # the party's own land, out in the wilds
        if spot.kind == "road" and WM.walkable(self.world) and self.state.journey:
            j = self.state.journey
            a = WM.world_area(self.world)
            if j.get("kind") != "voyage" and a.has_road(j.get("from") or "", j.get("to") or ""):
                return a                               # walking the road on the world's map
            return None
        if spot.kind == "voyage" and WM.walkable(self.world) and (self.state.journey or {}).get("kind") == "voyage":
            j = self.state.journey
            towns = [self.world.entities.get(j.get(k) or "") for k in ("from", "to")]
            if all(t is not None and G.town_position(self.world, t) is not None for t in towns):
                return WM.world_area(self.world)       # on the world's map, aboard
            return None
        return A.for_spot(self.world, spot)

    def _place_for(self, spot, prev: str) -> None:
        a = self.area
        cell = None
        if spot.kind == "street" and prev:
            p = places.parse(self.world, prev)
            if p.kind not in ("street", "building", "nowhere", "hex") or \
                    (p.town is not None and p.town.id != spot.town.id):
                d = self._arrival_direction(spot.town, p)
                g = a.gates_of(spot.town).get(d) if d else None
                if g:
                    cell = ("0",) + self._inward(g)
        if cell is None and a.kind == "world" and prev.startswith("dungeon|"):
            cell = a.dungeon_door(prev.split("|")[1])          # out of the door you went in by
        if cell is None and a.kind == "world":
            cell = a.cell_for(spot)
        if cell is None and spot.kind == "dungeon" and prev and places.parse(self.world, prev).kind != "dungeon":
            g = a.gates.get("out")
            if g:
                ent = a.spawns.get(spot.id)
                if ent:
                    cell = ent
        if cell is None:
            cell = a.spawns.get(spot.id)
        if cell is None and spot.kind == "building" and spot.building is not None:
            cell = a.spawns.get(spot.building.id)
        if cell is None:
            cell = next(iter(a.spawns.values()), (a.base_key, a.w // 2, a.h // 2))
        self.level, self.x, self.y = cell[0], int(cell[1]), int(cell[2])

    def _arrival_direction(self, town, prev) -> str:
        if prev.kind == "wild" and prev.town is not None and prev.town.id == town.id:
            return prev.direction
        came = (self.state.journey or {}).get("from") or (prev.town.id if prev.town is not None else "")
        road = next((r for r in places.roads_of(town) if r.get("leads_to") == came), None)
        if road:
            return road["direction"]
        return prev.direction if prev.kind == "wild" else ""

    def _inward(self, g) -> tuple[int, int]:
        x, y = g
        if self.area.kind == "world":
            return self.area.nearest_walkable(x, y, 10) or (x, y)
        lv = self.area.base
        best = A._nearest_free(lv, x, y, lambda xx, yy: (xx, yy) not in lv.exits, 8)
        return best or (x, y)

    def lv(self) -> A.Level:
        return self.area.level(self.level)

    def layer(self, x: int, y: int) -> A.Level:
        return self.area.layer(self.level, x, y)

    def zone_loc(self, x: int | None = None, y: int | None = None) -> str:
        if self.area is None:
            return ""
        x = self.x if x is None else x
        y = self.y if y is None else y
        return self.loc_at(self.layer(x, y), x, y)

    def loc_at(self, lv, x: int, y: int) -> str:
        names = getattr(lv, "names", None) or self.area.zone_names
        z = lv.zone_at(x, y)
        return names[z] if 0 <= z < len(names) else ""

    def inside_building(self) -> str:
        """The building the party is in ('' out on the street, or on a porch under an upper floor)."""
        if self.area is None or self.area.kind not in ("town", "world"):
            return ""
        lv = self.lv()
        if lv.overlay:
            return lv.bid
        if (self.x, self.y) in self.area.porch:
            return ""
        bid = self.area.cell_building.get((self.x, self.y), "")
        if bid and (getattr(self.state, "destruction", None) or {}).get("ruins"):
            from game import destruction                       # a ruin has no roof: you're out of doors
            if destruction.is_ruin(bid, self.state):
                return ""
        return bid

    def under_roof(self) -> str:
        """The building whose roof comes off to show the party inside (same as inside_building)."""
        return self.inside_building()

    # ==================================================================
    # Seeing
    # ==================================================================
    def party_lights(self) -> tuple[int, int, str, int]:
        """(bright, dim, colour) of the light the party carries, and its best darkvision (squares)."""
        from game.combat import lighting as LT
        members = self.members() or []
        sig = tuple((m.get("id"), tuple(sorted((m.get("equipment") or {}).items())), bool(m.get("dead")),
                     m.get("level"), m.get("race")) for m in members)
        if self._light_cache is None or self._light_cache[0] != sig:
            b, d, col = LT.party_light(self.world, members)
            self._light_cache = (sig, (b, d, col, LT.party_darkvision(self.world, members)))
        return self._light_cache[1]

    def weather(self):
        """The weather where the party is (game/weather.py), worked out again as the clock moves."""
        from game import weather as W
        key = (self.state.minutes // 15, self.state.location)
        if self._weather_cache is None or self._weather_cache[0] != key:
            self._weather_cache = (key, W.here(self.world, self.state))
        return self._weather_cache[1]

    def outdoors(self) -> bool:
        return self.area is not None and self.area.kind in ("town", "world") and not self.lv().dark and \
            not self.inside_building() and not getattr(self.lv(), "underground", False)

    def sight_radius(self) -> int:
        """How far the party sees: by day, far; at dawn, dusk or under the moon, less; on a dark night only as
        far as its light or darkvision reaches. Fog, heavy rain and snow cut it, blizzards and dust storms most.
        Indoors is lit by hearths and lamps; dungeons and caves are always dark."""
        from game.combat import lighting as LT
        if self.area is None:
            return 0
        lv = self.lv()
        b, d, _col, dv = self.party_lights()
        if lv.dark or self.area.kind == "dungeon":
            return max(8 if self.area.kind == "dungeon" else 10, b + d, dv)
        if self.inside_building():
            return 16
        w = self.weather()
        light = LT.outdoor_light(self.state.minutes, w)
        if light == LT.BRIGHT:
            r = 20
        elif light == LT.DIM:
            r = 13
        else:
            r = max(b + d, dv, 2)
            if self._lit_town():
                r = max(r, 9)                                  # street lamps and lit windows
        return max(2, int(round(r * w.sight)))

    def _lit_town(self) -> bool:
        """Standing on the streets of a town big enough for street lamps."""
        from game import settlements as ST
        spot = places.current(self.world, self.state)
        return spot.kind in ("street", "building") and spot.town is not None and \
            ST.tier_of(spot.town) in ("Town", "City", "Capital")

    def door_open(self, lv: A.Level, c) -> bool:
        st = self.door_state(lv.key, c)
        return st in ("open", "broken")

    def secret_hidden(self, lv: A.Level, c) -> bool:
        d = lv.doors.get(c)
        if not d or not d.get("secret"):
            return False
        from game import dungeons as DG
        dd = self.world.entities.get(d.get("bid") or "")
        if dd is None or dd.type != "dungeon":
            return False
        found = DG.progress(self.state, dd)["found"]
        return not any(n and n in found for n in d.get("names") or ())

    def opaque(self, x: int, y: int) -> bool:
        memo = self._look_memo
        if memo is not None:
            hit = memo.get((x, y))
            if hit is not None:
                return hit
        lv = self._look_open or self.layer(x, y)
        if lv.opaque(x, y):
            out = True
        elif (x, y) in lv.doors:
            out = self.secret_hidden(lv, (x, y)) or not self.door_open(lv, (x, y))
        else:
            out = False
        if memo is not None:
            memo[(x, y)] = out
        return out

    def look(self) -> set[tuple[int, int]]:
        """Work out what's in sight from here and remember it."""
        if self.area is None:
            self.visible = set()
            return self.visible
        r = self.sight_radius()
        vis = {(self.x, self.y)}
        ox, oy = self.x, self.y
        self._look_memo = {}                           # each square is looked at by several octants
        if self.area.kind == "world" and self.level == "0":
            reach = r + 1                              # out in the open country, no town in sight: the land
            if not any(st.overlaps(ox - reach, oy - reach, 2 * reach + 1, 2 * reach + 1)  # is all there is
                       for st in self.area.sites.values()):
                self._look_open = self.area.levels["0"]
        try:
            for oct in range(8):
                self._cast(ox, oy, 1, 1.0, 0.0, r, oct, vis)
        finally:
            self._look_memo = None
        self.visible = vis
        open_land = self._look_open
        self._look_open = None
        for (x, y) in vis:
            self._mark(open_land or self.layer(x, y), x, y)
        if self.area.kind == "dungeon" and getattr(self.area.levels.get(self.level), "traps", None):
            from game import traps                     # a trap coming into sight: one roll to spot it
            traps.notice(self)
        return vis

    _MULT = [(1, 0, 0, 1), (0, 1, 1, 0), (0, -1, 1, 0), (-1, 0, 0, 1), (-1, 0, 0, -1), (0, -1, -1, 0),
             (0, 1, -1, 0), (1, 0, 0, -1)]

    def _cast(self, cx, cy, row, start, end, radius, oct, vis) -> None:
        """Recursive shadowcasting (one octant)."""
        if start < end:
            return
        xx, xy, yx, yy = self._MULT[oct]
        r2 = radius * radius
        new_start = start
        for j in range(row, radius + 1):
            dx, dy = -j - 1, -j
            blocked = False
            while dx <= 0:
                dx += 1
                X, Y = cx + dx * xx + dy * xy, cy + dx * yx + dy * yy
                l_slope, r_slope = (dx - 0.5) / (dy + 0.5), (dx + 0.5) / (dy - 0.5)
                if start < r_slope:
                    continue
                if end > l_slope:
                    break
                if not (0 <= X < self.area.w and 0 <= Y < self.area.h):
                    continue
                if dx * dx + dy * dy <= r2:
                    vis.add((X, Y))
                op = self.opaque(X, Y)
                if blocked:
                    if op:
                        new_start = r_slope
                        continue
                    blocked = False
                    start = new_start
                elif op and j < radius:
                    blocked = True
                    self._cast(cx, cy, j + 1, start, l_slope, radius, oct, vis)
                    new_start = r_slope
            if blocked:
                break

    # ==================================================================
    # People
    # ==================================================================
    def refresh_people(self, force: bool = False) -> None:
        """Put everyone where they are at this hour (again, once time has moved on)."""
        if self.area is None:
            self.tokens = []
            return
        stamp = self.state.minutes // 15
        if not force and stamp == self._people_at:
            return
        self._people_at = stamp
        self.crowd_info = {}
        if self.area.kind == "town":
            self._people = self._town_people(places.current(self.world, self.state).town)
        elif self.area.kind == "world":
            self._people = []
            for site in list(self.area.sites.values()):
                if site.kind not in ("town", "claim"):
                    continue
                x0, y0, w, h = site.rect
                if abs(x0 + w / 2 - self.x) > w / 2 + 120 or abs(y0 + h / 2 - self.y) > h / 2 + 120:
                    continue                                 # only the towns near enough to see
                if site.kind == "claim":
                    self._people += self._claim_people(site)
                else:
                    self._people += self._town_people(self.world.entities.get(site.ent_id))
        else:
            self._people = self._dungeon_foes()
        self._merge_tokens()

    def _merge_tokens(self) -> None:
        self.tokens = list(self._people) + [t for g in self.encounters.values() for t in g["tokens"]]

    def _spot_near(self, lk: str, x: int, y: int, taken: set, loc: str, limit: int = 12):
        """A free square near (x, y), standing in `loc`."""
        for r in range(limit):
            for dy in range(-r, r + 1):
                for dx in range(-r, r + 1):
                    if max(abs(dx), abs(dy)) != r:
                        continue
                    c = (x + dx, y + dy)
                    lv = self.area.layer(lk, *c)
                    if not lv.inside(*c) or lv.blocks(*c) or c in lv.doors or c in lv.stairs or c in taken:
                        continue
                    if loc and self.loc_at(lv, *c) != loc:
                        continue
                    return c
        return None

    def _claim_people(self, site) -> list[Token]:
        """Who's at work on the party's own land (game/estate.py): hired hands in working hours, automatons
        always."""
        from game import estate as ES
        out: list[Token] = []
        taken: set = set()
        for b in ES.buildings(self.world, site.ent_id):
            sp = places.parse(self.world, b.id)
            for n in places._people_in_building(self.world, sp, self.state):
                home = self.area.spawns.get(b.id)
                info = self.area.buildings.get(b.id)
                if home is None:
                    pl = b.fields.get("place") or {}
                    x0, y0 = site.rect[0], site.rect[1]
                    home = ("0", x0 + int(pl.get("x", 0)), y0 + int(pl.get("y", 0)))
                rng = random.Random(zlib.crc32((n.id + b.id).encode()))
                c = self._spot_near(home[0], home[1] + rng.randint(-2, 2), home[2] + rng.randint(-2, 2), taken, "")
                if c:
                    taken.add(c)
                    out.append(Token(n.id, n.name, c[0], c[1], home[0], "npc", n.id, b.id if info else "", c,
                                     wander=0, at_work=True))
        tid = getattr(site.area, "settlement_town", "")
        town = self.world.entities.get(tid) if tid else None
        if town is not None:                          # the party's own settlement: who's out on the green
            for s in places.streets_of(town):
                loc = places.street_id(town.id, s["name"])
                home = self.area.spawns.get(loc)
                if not home:
                    continue
                for n in places._people_in_building(self.world, places.parse(self.world, loc), self.state):
                    rng = random.Random(zlib.crc32(n.id.encode()))
                    c = self._spot_near(home[0], home[1] + rng.randint(-5, 5), home[2] + rng.randint(-3, 3), taken,
                                        loc)
                    if c:
                        taken.add(c)
                        out.append(Token(n.id, n.name, c[0], c[1], "0", "npc", n.id, loc, c, wander=3))
        return out

    def _town_people(self, town) -> list[Token]:
        a = self.area
        out: list[Token] = []
        taken: set = set()
        if town is None:
            return out
        for s in places.streets_of(town):
            loc = places.street_id(town.id, s["name"])
            sp = places.parse(self.world, loc)
            home = a.spawns.get(loc)
            if not home:
                continue
            for n in places._people_in_building(self.world, sp, self.state):
                rng = random.Random(zlib.crc32(n.id.encode()))
                c = self._spot_near(home[0], home[1] + rng.randint(-8, 8), home[2] + rng.randint(-2, 2), taken, loc)
                if c:
                    taken.add(c)
                    out.append(Token(n.id, n.name, c[0], c[1], "0", "npc", n.id, loc, c, wander=4))
        for b in places.buildings_in(self.world, town):
            info = a.buildings.get(b.id)
            if not info:
                continue
            sp = places.parse(self.world, b.id)
            people = places._people_in_building(self.world, sp, self.state)
            if not people:
                continue
            rooms = places.people_rooms(self.world, b, people, self.state)
            rows = places.building_rooms(b)
            for n in people:
                room = rooms.get(n.id) or (rows[0]["name"] if rows else "")
                loc = b.id if rows and room == rows[0]["name"] else places.room_id(b.id, room)
                key = places.ROLE_STATION.get(n.fields.get("occupation") or "", "")
                works = (n.fields.get("building") or "") == b.id
                cell = self._station_spot(loc, key, taken) if works else None
                lvk = None
                if cell is None:
                    home = a.spawns.get(loc)
                    if not home:
                        continue
                    lvk = home[0]
                    rng = random.Random(zlib.crc32((n.id + loc).encode()))
                    cell = self._spot_near(lvk, home[1] + rng.randint(-3, 3), home[2] + rng.randint(-3, 3), taken, loc)
                    if not cell:
                        continue
                else:
                    lvk, cell = cell
                taken.add(cell)
                out.append(Token(n.id, n.name, cell[0], cell[1], lvk, "npc", n.id, loc, cell,
                                 wander=0 if works else 2, at_work=bool(works and key)))
        out += self._crowd(town, taken)
        out += self._homeless(town, taken)
        return out

    def _homeless(self, town, taken: set) -> list[Token]:
        """The town's homeless (game/homeless.py): bedded down against the buildings' walls by night, drifting
        about the streets by day."""
        from game import crowds, homeless
        if not homeless.shown(town):
            return []
        looks = self._crowd_looks.get(town.id)
        if looks is None:
            looks = self._crowd_looks[town.id] = crowds.pool(self.world, town)
        streets = [places.street_id(town.id, s["name"]) for s in places.streets_of(town)]
        streets = [loc for loc in streets if self.area.spawns.get(loc)]
        if not streets:
            return []
        key = (town.id, frozenset(homeless.hired_ids(self.state)))
        cache = self.__dict__.setdefault("_homeless_cache", {})
        if key not in cache:                              # (the same people every day: worked out once)
            cache[key] = (homeless.roster(self.world, town, self.state, looks),
                          set(places.street_id(town.id, n) for n in self._rough(town)))
        roster, rough = cache[key]
        night = homeless.at_night(self.state)
        day = self.state.minutes // 1440
        out = []
        for i, d in enumerate(roster):
            rng = random.Random(zlib.crc32(f"{d['id']}|{day}|{night}".encode()))
            pool = [s for s in streets if s in rough] * 2 + streets           # (the rough streets more)
            loc = pool[(i * 7 + rng.randint(0, 3)) % len(pool)]
            home = self.area.spawns[loc]
            x, y = home[1] + rng.randint(-14, 14), home[2] + rng.randint(-4, 4)
            c = self._wall_spot(home[0], x, y, taken, loc) if night else None
            c = c or self._spot_near(home[0], x, y, taken, loc)
            if not c:
                continue
            taken.add(c)
            self.crowd_info[d["id"]] = d
            t = Token(d["id"], d["name"], c[0], c[1], home[0], "crowd", crowds.sprite_key(d), loc, c,
                      wander=0 if night else 3)
            if night:
                t.facing = self._away_from_wall(home[0], c)
            out.append(t)
        return out

    def _sleeping(self, t: Token) -> bool:
        return t.id.startswith("homeless:") and not t.wander

    def _rough(self, town) -> list:
        from game import thieves
        try:
            return thieves.rough_streets(self.world, town)
        except Exception:  # noqa: BLE001 - no rough streets: anywhere will do
            return []

    def _wall_spot(self, lk: str, x: int, y: int, taken: set, loc: str, limit: int = 10):
        """A free square of the street near (x, y) with a building's wall beside it (to sleep against)."""
        for r in range(limit):
            for dy in range(-r, r + 1):
                for dx in range(-r, r + 1):
                    if max(abs(dx), abs(dy)) != r:
                        continue
                    c = (x + dx, y + dy)
                    lv = self.area.layer(lk, *c)
                    if not lv.inside(*c) or lv.blocks(*c) or c in lv.doors or c in lv.stairs or c in taken:
                        continue
                    if self.loc_at(lv, *c) not in (loc, "") or (getattr(self.area, "cell_building", None) or {}).get(c):
                        continue                          # (the street, or the open ground round its buildings)
                    if any(self._a_wall(lv, c[0] + ax, c[1] + ay) for ax, ay in CARDINAL.values()):
                        return c
        return None

    def _a_wall(self, lv, x: int, y: int) -> bool:
        """A building's wall (not a doorway, nor right beside one)."""
        if not lv.inside(x, y) or not lv.blocks(x, y) or (x, y) in lv.doors:
            return False
        if not (getattr(self.area, "cell_building", None) or {}).get((x, y)) and \
                not self.loc_at(lv, x, y).startswith("building"):
            return False
        return not any((x + dx, y + dy) in lv.doors for dx, dy in CARDINAL.values())

    def _away_from_wall(self, lk: str, c) -> str:
        lv = self.area.layer(lk, *c)
        for name, (dx, dy) in CARDINAL.items():
            if self._a_wall(lv, c[0] + dx, c[1] + dy):
                return {"N": "S", "S": "N", "E": "W", "W": "E"}.get(name, "S")
        return "S"

    def _crowd(self, town, taken: set) -> list[Token]:
        """The unnamed townsfolk on a city's streets (game/crowds.py): made fresh each hour, never saved."""
        from game import crowds
        if not crowds.per_town(town):
            return []
        looks = self._crowd_looks.get(town.id)
        if looks is None:
            looks = self._crowd_looks[town.id] = crowds.pool(self.world, town)
        streets = [(places.street_id(town.id, s["name"])) for s in places.streets_of(town)]
        streets = [loc for loc in streets if self.area.spawns.get(loc)]
        if not streets:
            return []
        out = []
        taken.add((self.x, self.y))                       # not where the party's standing
        for i, d in enumerate(crowds.crowd(self.world, town, self.state.minutes // 60, looks)):
            loc = streets[i % len(streets)]
            home = self.area.spawns[loc]
            rng = random.Random(zlib.crc32(d["id"].encode()))
            c = self._spot_near(home[0], home[1] + rng.randint(-14, 14), home[2] + rng.randint(-3, 3), taken, loc)
            if not c:
                continue
            taken.add(c)
            self.crowd_info[d["id"]] = d
            out.append(Token(d["id"], d["name"], c[0], c[1], home[0], "crowd", crowds.sprite_key(d), loc, c,
                             wander=8))
        return out

    def _station_spot(self, loc: str, key: str, taken: set):
        if not key:
            return None
        levels = list(self.area.levels.items())
        if self.area.kind == "world":
            levels = [(k, lv) for k, lv in levels if not getattr(lv, "chunked", False)]
            levels += [("0", s.base) for s in self.area.sites.values()]
        for lk, lv in levels:
            for c, st in lv.stations.items():
                if st["room"] == loc and st["kind"] == key and st.get("spot") and st["spot"] not in taken:
                    return lk, st["spot"]
        return None

    def _free_near(self, lv, x, y, taken, ok) -> tuple[int, int] | None:
        return A._nearest_free(lv, x, y, lambda xx, yy: (xx, yy) not in taken and ok(xx, yy), 12)

    def _dungeon_foes(self) -> list[Token]:
        from game import dungeons as DG
        a = self.area
        spot = places.current(self.world, self.state)
        d = spot.extra.get("dungeon") if spot.kind == "dungeon" else None
        if d is None:
            return []
        p = DG.progress(self.state, d)
        out, taken = [], set()
        for r in DG.rooms(d):
            if r["name"] in p["cleared"]:
                continue
            loc = DG.room_id(d.id, r["name"])
            foes = DG.room_foes(self.world, d, r, random.Random(zlib.crc32(loc.encode())))
            home = a.spawns.get(loc)
            if not foes or not home:
                continue
            lv = a.levels[home[0]]
            z = a.zone_id(loc)
            total = sum(n for _e, n in foes)
            i = 0
            for e, n in foes:
                for _k in range(n):
                    if i >= 4:
                        break
                    c = self._free_near(lv, home[1] + (i % 2) * 2 - 1, home[2] + (i // 2) * 2 - 1, taken,
                                        lambda x, y: lv.zone_at(x, y) == z)
                    if c:
                        taken.add(c)
                        out.append(Token(f"{loc}#{i}", e.name, c[0], c[1], home[0], "enemy", e.id, loc, c,
                                         hidden=hides(e), count=total))
                    i += 1
        return out

    def token_at(self, x: int, y: int, level: str | None = None) -> Token | None:
        lk = self.level if level is None else level
        here = self.area.layer(lk, x, y)
        for t in self.tokens:
            if t.x == x and t.y == y and self.area.layer(t.level, x, y) is here:
                return t
        return None

    def shown(self, t: Token) -> bool:
        """Is this person or creature on screen? (In sight, on this floor, and not lying in wait.)"""
        if t.hidden:
            return False
        if (t.x, t.y) not in self.visible:
            return False
        return self.area.layer(t.level, t.x, t.y) is self.layer(t.x, t.y)

    def wander(self) -> bool:
        """Let townsfolk drift about a little. Returns True if anyone moved."""
        moved = False
        for t in self.tokens:
            if t.wander <= 0 or self.rng.random() > 0.25:
                continue
            dx, dy = self.rng.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
            nx, ny = t.x + dx, t.y + dy
            if abs(nx - t.home[0]) > t.wander or abs(ny - t.home[1]) > t.wander:
                continue
            lv = self.area.layer(t.level, nx, ny)
            if lv is None or lv.blocks(nx, ny) or (nx, ny) in lv.doors or (nx, ny) in lv.stairs \
                    or (nx, ny) in lv.exits or (nx, ny) == (self.x, self.y) or self.token_at(nx, ny, t.level):
                continue
            if self.loc_at(lv, nx, ny) != t.room:
                continue
            t.x, t.y = nx, ny
            t.facing = {(1, 0): "E", (-1, 0): "W", (0, 1): "S", (0, -1): "N"}[(dx, dy)]
            moved = True
        return moved

    # ==================================================================
    # Moving
    # ==================================================================
    def walkable(self, x: int, y: int) -> bool:
        lv = self.layer(x, y)
        if lv.blocks(x, y):
            return False
        if (x, y) in lv.doors:
            return self.door_open(lv, (x, y)) and not self.secret_hidden(lv, (x, y))
        return self.token_at(x, y) is None

    # ==================================================================
    # Being carried along: a road journey, a trek across country, a voyage
    # ==================================================================
    VESSELS = {"Boat": "ship", "Airship": "airship", "Caravan": "wagon"}

    def travelling(self) -> str:
        """'road', 'trek' or 'voyage' while a journey carries the party along on the world's map, else ''."""
        if self.area is None or self.area.kind != "world":
            return ""
        j = self.state.journey
        if j and j.get("kind") == "voyage" and self.state.location.startswith("voyage|"):
            return "voyage"
        if j and j.get("kind") != "voyage" and self.state.location.startswith("road|"):
            return "road"
        if self.state.trek:
            return "trek"
        return ""

    _ride = None

    def ride_factor(self) -> float:
        """How much faster than walking the party crosses the world's map (1.0 on foot)."""
        try:
            from game import animals
            if not animals.owned(self.state):
                return 1.0
            return animals.travel_factor(self.world, self.state, self.members())
        except Exception:  # noqa: BLE001
            return 1.0

    def followers(self) -> list[tuple[str, int, int, str]]:
        """The party's pets, trotting along behind it: [(enemy id, x, y, facing)]."""
        if self.area is None or self.travelling():
            return []
        if self._steps <= 1 or "_pets" not in self.__dict__:
            try:
                from game import animals
                self._pets = [v["enemy"] for v in animals.companions(self.world, self.state)][:3] \
                    if animals.owned(self.state) else []
            except Exception:  # noqa: BLE001
                self._pets = []
        out = []
        trail = self.__dict__.get("_trail") or []
        for i, eid in enumerate(self._pets):
            k = 1 + i * 2
            if k < len(trail) and trail[k][0] == self.level and (trail[k][1], trail[k][2]) != (self.x, self.y):
                out.append((eid, trail[k][1], trail[k][2], trail[k][3]))
        return out

    def town_dressing(self) -> str:
        """How the town looks today (game/townevents.py): "festival" (bunting), "lanterns" (a festival after dark,
        or midwinter), "smoke" (after a raid), or ""."""
        key = (self.state.minutes // 30, self.state.location)
        memo = self.__dict__.get("_dress")
        if memo is not None and memo[0] == key:
            return memo[1]
        out = ""
        try:
            from game import townevents as TE
            spot = places.current(self.world, self.state)
            if spot.town is not None and self.area is not None and self.area.kind in ("town", "world"):
                f = TE.festival_at(self.world, spot.town, self.state.minutes)
                if f is not None:
                    night = self.state.time_of_day in ("Night", "Dusk")
                    out = "lanterns" if night or f.name == "Midwinter" else "festival"
                elif TE.scarred(self.state, spot.town.id) or TE.raid_here(self.world, self.state) is not None:
                    out = "smoke"
        except Exception:  # noqa: BLE001
            out = ""
        self.__dict__["_dress"] = (key, out)
        return out

    # ---- getting down and back up (the party's own mounts and carts) ------------------------------------
    RIDE_WORDS = {"cart": "the cart", "wagon": "the wagon", "horse": "your horses"}

    def mounted(self) -> str:
        """What the party is riding in or on right now (a voyage's vessel, or its own cart, wagon or horses),
        or '' on foot."""
        return self.vessel or self.ride()

    def parked_here(self) -> dict | None:
        """The mount the party got down from, if it was left in this area: {"kind", "level", "x", "y",
        "facing"}."""
        from game import animals
        pk = animals.parked(self.state)
        if pk is None or self.area is None or pk.get("area") != self.area.key:
            return None
        return pk

    def can_remount(self) -> bool:
        pk = self.parked_here()
        return pk is not None and pk.get("level") == self.level and \
            max(abs(pk["x"] - self.x), abs(pk["y"] - self.y)) <= 1

    def dismount(self) -> tuple[bool, str]:
        """Get down: the mount (cart, wagon or horses) stays on this square; the party steps onto a free square
        beside it. Not mid-voyage, and not where there's no room."""
        if self.travelling() == "voyage":
            what = {"ship": "the ship", "airship": "the airship", "wagon": "the caravan",
                    "rowboat": "the boat"}.get(self.vessel, "it")
            return False, f"You can't get off {what} until it reaches land."
        kind = self.ride()
        if not kind:
            return False, "You're on foot."
        lv = self.lv()
        spot = None
        back = DIRS.get(self.facing, (0, 1))
        order = [(-back[0], -back[1])] + [(dx, dy) for dx, dy in ((0, 1), (1, 0), (-1, 0), (0, -1), (1, 1),
                                                                  (-1, 1), (1, -1), (-1, -1))]
        for dx, dy in order:                             # beside it, behind first (as you'd climb down)
            c = (self.x + dx, self.y + dy)
            if not (0 <= c[0] < self.area.w and 0 <= c[1] < self.area.h):
                continue
            here = self.layer(*c)
            if getattr(here, "overlay", False) != getattr(lv, "overlay", False) or not self.walkable(*c) or \
                    c in here.water or c in here.doors or c in here.stairs or c in here.exits:
                continue                                 # outdoors, open ground, nobody there
            spot = c
            break
        if spot is None:
            return False, "There's no room to get down here."
        from game import animals
        if animals.parked(self.state) is not None:
            return False, "You've already left a mount behind: go back for it first."
        mode = self.travelling()
        if mode == "road":                               # getting down ends the journey, as stepping off it does
            self.leave_road()
        elif mode == "trek":
            from game import hexes as H
            H.stop_trek(self.state)
        animals.park(self.world, self.state, self.area.key, self.level, self.x, self.y, self.facing, kind)
        self.x, self.y = spot
        self._ride = None
        self.remember_pos()
        self.look()
        self.save()
        return True, f"You get down and leave {self.RIDE_WORDS.get(kind, 'your mount')} here."

    def remount(self) -> tuple[bool, str]:
        """Back up onto the mount left beside (or under) the party: the party takes its square."""
        pk = self.parked_here()
        if pk is None:
            return False, "Your mount isn't here."
        if not self.can_remount():
            return False, "Go back to where you left it."
        from game import animals
        animals.unpark(self.world, self.state)
        self.level, self.x, self.y = pk["level"], pk["x"], pk["y"]
        self.facing = pk.get("facing") or self.facing
        self._ride = None
        self.remember_pos()
        self.look()
        self.save()
        kind = self.ride() or pk.get("kind", "")
        return True, f"You climb back onto {self.RIDE_WORDS.get(kind, 'your mount')}."

    def ride(self) -> str:
        """What the party is seen riding on the world's map: 'wagon', 'horse' or ''."""
        if self.area is None or self.area.kind != "world":
            return ""
        try:
            from game import animals
            if not animals.owned(self.state):
                return ""
            return animals.ride_kind(self.world, self.state, self.members())
        except Exception:  # noqa: BLE001
            return ""

    @property
    def vessel(self) -> str:
        """What the party rides in: 'ship', 'airship', 'wagon' (a caravan) or '' (on foot)."""
        if self.travelling() != "voyage":
            return ""
        j = self.state.journey or {}
        if j.get("own"):                                 # the party's own boat (game/animals.py)
            from game import animals
            b = animals.get(self.state, j["own"])
            if b is not None and b.get("type") in ("Rowboat", "Keelboat"):
                return "rowboat"
        return self.VESSELS.get(j.get("method") or "", "ship")

    def _route_key(self, mode: str) -> tuple:
        if mode == "trek":
            t = self.state.trek or {}
            return ("trek", tuple(t.get("goal") or ()), len(t.get("path") or ()), t.get("then") or "")
        j = self.state.journey or {}
        return (mode, j.get("from"), j.get("to"), j.get("direction") or j.get("method"))

    def route(self, mode: str = ""):
        """(points, running lengths) of the way the party is being carried, from where it set out."""
        mode = mode or self.travelling()
        if not mode:
            return None
        key = self._route_key(mode)
        if self._route is not None and self._route[0] == key:
            return self._route[1]
        from game import hexes as H
        from game.worldmap import SQ
        pts = None
        if mode == "trek":
            t = self.state.trek or {}
            start = t.get("start") or [self.x, self.y]
            pts = [tuple(start)] + [(H.center(self.world, q, r)[0] * SQ, H.center(self.world, q, r)[1] * SQ)
                                    for q, r in t.get("path") or []]
        else:
            j = self.state.journey or {}
            a, b = self.world.entities.get(j.get("from") or ""), self.world.entities.get(j.get("to") or "")
            if mode == "road":
                _k, origin, direction = (self.state.location.split("|") + ["", ""])[:3]
                pts = self.area.road_route(a, b, direction if origin == (a.id if a else "") else "")
            else:
                pts = self.area.voyage_route(a, b, j.get("method") or "Boat")
        if not pts or len(pts) < 2:
            pts = pts if pts and mode == "trek" else None
        run = None
        if pts:
            run = [0.0]
            for (ax, ay), (bx, by) in zip(pts, pts[1:]):
                run.append(run[-1] + math.hypot(bx - ax, by - ay))
        self._route = (key, (pts, run) if pts else None)
        return self._route[1]

    def road_route(self):
        return self.route("road")

    def route_point(self, frac: float, mode: str = "") -> tuple[float, float, float, float] | None:
        """(x, y, dx, dy): where `frac` of the way along is, and which way the way runs there."""
        r = self.route(mode)
        if r is None:
            return None
        pts, run = r
        if len(pts) == 1:
            return pts[0][0], pts[0][1], 0.0, 0.0
        want = max(0.0, min(1.0, frac)) * run[-1]
        i = max(0, min(len(pts) - 2, bisect.bisect_right(run, want) - 1))
        (ax, ay), (bx, by) = pts[i], pts[i + 1]
        seg = max(1e-6, run[i + 1] - run[i])
        t = max(0.0, min(1.0, (want - run[i]) / seg))
        return ax + (bx - ax) * t, ay + (by - ay) * t, bx - ax, by - ay

    def leave_road(self) -> None:
        """Stop travelling: the party stands where it is, out in the open (the hex it's in)."""
        travel.stop(self.world, self.state, self.bus)
        loc = self.zone_loc()
        if loc and loc != self.state.location:
            places.enter(self.world, self.state, loc, self.bus, walking=True)
            self._last_spot = loc
        self.remember_pos()

    def place_on_route(self) -> bool:
        """Put the party where the journey (road, trek or voyage) has got to."""
        mode = self.travelling()
        if not mode:
            return False
        if mode == "trek":
            t = self.state.trek or {}
            r = self.route("trek")
            if r is None:
                return False
            pts, _run = r
            i = max(0, min(len(pts) - 1, int(t.get("i") or 0)))
            x, y = pts[i]
            nx_, ny_ = pts[min(len(pts) - 1, i + 1)]
            dx, dy = nx_ - x, ny_ - y
            if i == len(pts) - 1 and i > 0:
                dx, dy = x - pts[i - 1][0], y - pts[i - 1][1]
        else:
            j = self.state.journey or {}
            whole = float(j.get("days" if mode == "voyage" else "hours", 1) or 1)
            done = float(j.get("done", 0)) + (self.sub_progress if mode == "voyage" else 0.0)
            p = self.route_point(done / max(0.01, whole), mode)
            if p is None:
                return False
            x, y, dx, dy = p
        afloat = mode == "voyage" and self.vessel in ("ship", "airship", "rowboat")
        if afloat:                                     # on the water, or in the air: anywhere will do
            c = (int(x), int(y))
        else:
            c = self.area.nearest_walkable(int(x), int(y), 12) or (int(x), int(y))
        self.level, self.x, self.y = "0", c[0], c[1]
        if abs(dx) > abs(dy):
            self.facing = "E" if dx > 0 else "W"
        elif dy:
            self.facing = "S" if dy > 0 else "N"
        self.look()
        self.remember_pos()
        return True

    def step(self, direction: str) -> StepResult:
        if self.area is None or direction not in DIRS:
            return StepResult()
        mode = self.travelling()
        if mode == "voyage":                             # aboard: nowhere to walk to
            what = {"ship": "the ship", "airship": "the airship", "wagon": "the caravan",
                    "rowboat": "the boat"}.get(self.vessel, "it")
            return StepResult(message=f"You're travelling with {what} until it arrives.")
        if mode == "road":                               # walking off on your own: the journey's over
            self.leave_road()
        elif mode == "trek":
            from game import hexes as H
            H.stop_trek(self.state)
            if self.bus is not None:
                self.bus.emit("log", kind="narration", text="You stop and take your bearings.")
        dx, dy = DIRS[direction]
        self.facing = direction
        nx, ny = self.x + dx, self.y + dy
        if dx and dy:                                    # no squeezing between two corners, no doors aslant
            if not self.walkable(self.x + dx, self.y) or not self.walkable(self.x, self.y + dy) or \
                    (nx, ny) in self.layer(nx, ny).doors or (self.x, self.y) in self.layer(self.x, self.y).doors:
                return StepResult()
        return self._enter(nx, ny)

    def _enter(self, nx: int, ny: int) -> StepResult:
        lv = self.layer(nx, ny)
        if not (0 <= nx < self.area.w and 0 <= ny < self.area.h):
            return StepResult()
        t = self.token_at(nx, ny)
        if t is not None and t.kind == "crowd" and t.level == self.level and self._sleeping(t):
            from game import homeless                 # bedded down for the night: they don't budge
            return StepResult(prompt=homeless.prompt(self, t))
        if t is not None and t.kind == "crowd" and t.level == self.level:
            t.x, t.y = self.x, self.y                 # townsfolk step round you (E to speak to one)
            t = None
        if t is not None:
            if t.kind == "enemy":
                if t.group:
                    return StepResult(action=("battle", t.group))
                return StepResult(action=("enter", t.room))
            return StepResult(prompt=self.person_prompt(t))
        pk = self.parked_here()
        if pk is not None and (pk["x"], pk["y"]) == (nx, ny) and pk.get("level") == self.level:
            ok, msg = self.remount()                     # walking up to the mount you left: climb back on
            return StepResult(moved=ok, message=msg)
        if (nx, ny) in lv.doors and not self.secret_hidden(lv, (nx, ny)) and not self.door_open(lv, (nx, ny)):
            return self._bump_door(lv, (nx, ny))
        if (nx, ny) in lv.exits:
            return StepResult(prompt=self.exit_prompt(lv.exits[(nx, ny)]))
        if not self.walkable(nx, ny):
            st = lv.stations.get((nx, ny))
            if st:
                return StepResult(prompt=self.station_prompt(lv, (nx, ny)))
            return StepResult()
        d = lv.doors.get((nx, ny))
        if d and d.get("kind") == "exit":
            return StepResult(prompt=self.leave_dungeon_prompt())
        if getattr(lv, "traps", None) and (nx, ny) in lv.traps:       # a trap (game/traps.py)
            from game import traps
            here = traps.at(self, lv, (nx, ny))
            if here is not None and here[3] == "seen":
                return StepResult(prompt=traps.prompt(self, lv, (nx, ny)))
            res = self._move_to(nx, ny)
            if here is not None and res.moved:
                d0, row, _inf, _st = here
                out = traps.spring(self.world, self.state, self.members(), d0, row, self.rng, self.bus)
                self.door_version = getattr(self, "door_version", 0) + 1
                if self.bus is not None:
                    for line in out["lines"]:
                        self.bus.emit("log", kind="damage", text=line)
                if out.get("fight") and res.action is None:
                    res.action = ("trap", "alarm", out["key"][0], out["key"][1])
            return res
        return self._move_to(nx, ny)

    def _move_to(self, nx: int, ny: int) -> StepResult:
        res = StepResult(moved=True)
        trail = self.__dict__.setdefault("_trail", [])       # where the party's been: pets follow it
        trail.insert(0, (self.level, self.x, self.y, self.facing))
        del trail[6:]
        self.x, self.y = nx, ny
        lv = self.layer(nx, ny)
        if (nx, ny) in lv.stairs and self._ruined_stairs(lv.stairs[(nx, ny)][0]):
            res.message = "The stairs end in broken beams and open sky."     # a fallen building (destruction.py)
        elif (nx, ny) in lv.stairs:
            lk, sx, sy = lv.stairs[(nx, ny)]
            going = "up" if self.area.levels[lk].floor_no > lv.floor_no else "down"
            self.level, self.x, self.y = lk, sx, sy
            self._step_off_stairs()
            res.changed_level = True
            res.message = f"You climb the stairs {going}." if going == "up" else "You go down the stairs."
        self.remember_pos()
        self._steps += 1
        per = STEPS_PER_MINUTE
        if self.area.kind == "world":
            if self._steps == 1 or self._ride is None:      # riding covers more ground a minute (game/animals.py)
                self._ride = self.ride_factor()
            per = int(WORLD_STEPS_PER_MINUTE * self._ride)
        if self._steps >= per:
            self._steps = 0
            self.state.advance(1, "walking")
        loc = self.zone_loc()
        if loc and loc != self.state.location:
            places.enter(self.world, self.state, loc, self.bus, walking=True)
            self._last_spot = loc
            res.entered = loc
            self._discover(loc)
            self.refresh_people()
            self.save()
            if (self.state.law or {}).get("jail"):            # getting out of jail (game/jail.py)
                from game import jail
                msg, prompt = jail.on_move(self, loc)
                res.message = msg or res.message
                res.prompt = prompt or res.prompt
        self.look()
        if (getattr(self.state, "destruction", None) or {}).get("fires"):
            from game import fire                             # fires burning (game/fire.py)
            for line in fire.update(self):
                res.message = res.message or line
            if fire.burning_at(self, self.x, self.y) and self.bus is not None:
                for line in fire.scorched(self):
                    self.bus.emit("log", kind="damage", text=line)
        if self.area.kind == "world" and loc.startswith("hex|"):
            found = self._roll_encounter(loc)
            if found:
                res.message = found
        elif res.prompt is None and (self.state.location or "").startswith(("street|", "room|", "building")):
            from game import thieves                          # cutpurses and muggers (game/thieves.py)
            msg, prompt = thieves.on_step(self, res.entered)
            res.message = msg or res.message
            res.prompt = prompt or res.prompt
        return res

    def _ruined_stairs(self, lk: str) -> bool:
        if not (getattr(self.state, "destruction", None) or {}).get("ruins"):
            return False
        from game import destruction
        return destruction.stairs_blocked(self, lk)

    def _discover(self, loc: str) -> None:
        if loc.startswith("landmark|"):
            from game import dungeons as DG
            lm = self.world.entities.get(loc.split("|", 1)[1])
            if lm is not None:
                DG.discover(self.state, lm, self.bus)

    def _step_off_stairs(self) -> None:
        """Arriving by the stairs, stand beside them, not on them (or straight back you'd go)."""
        lv = self.lv()
        for dx, dy in ((0, 1), (1, 0), (-1, 0), (0, -1), (1, 1), (-1, 1), (1, -1), (-1, -1)):
            c = (self.x + dx, self.y + dy)
            if lv.inside(*c) and not lv.blocks(*c) and c not in lv.doors and c not in lv.stairs and \
                    self.token_at(*c) is None:
                self.x, self.y = c
                return

    def teleport(self, level: str, x: int, y: int) -> None:
        self.level, self.x, self.y = level, x, y
        self.look()

    def path_to(self, gx: int, gy: int, limit: int = 30000) -> list[tuple[int, int]]:
        """Squares to walk to reach (gx, gy) on this level (or next to it, if it's a person or a door).
        A* search, so even a long walk across open country is quick to find. Into or out of a walled town
        it goes by way of the gates (searching round a long wall for the way through would take ages)."""
        if self.area is None:
            return []
        start = (self.x, self.y)
        legs = self._gate_legs(start, (gx, gy))
        if legs:
            out, cur = [], start
            for wp in legs:
                seg = self._astar(cur, wp, limit)
                if not seg:
                    break
                out += seg
                cur = seg[-1]
            else:
                seg = self._astar(cur, (gx, gy), limit)
                if seg or cur == (gx, gy):
                    return out + seg
        return self._astar(start, (gx, gy), limit)

    def _gate_legs(self, start, goal) -> list[tuple[int, int]]:
        """The town gates to pass on the way from start to goal (world map only), [] if no walls between."""
        if getattr(self.area, "kind", "") != "world":
            return []
        for p in (start, goal):
            site = self.area.site_at(*p)
            rings = getattr(site.area, "gate_rings", None) if site is not None else None
            boxes = getattr(site.area, "walls_of_town", None) if site is not None else None
            if not rings or not boxes or not all(rings):
                continue
            ox, oy = site.area.ox, site.area.oy
            n = len(boxes)

            def depth(q) -> int:
                x, y = q[0] - ox, q[1] - oy
                return sum(1 for (x0, y0, x1, y1) in boxes if x0 < x < x1 and y0 < y < y1)
            ds, dg = depth(start), depth(goal)
            if ds == dg:
                continue
            crossing = list(range(n - ds, n - dg)) if ds > dg else list(range(n - 1 - ds, n - 1 - dg, -1))
            # the gate (the same way out through every ring) that makes the shortest walk
            first = rings[crossing[0]]

            def far(i) -> float:
                gx, gy = first[i][0] + ox, first[i][1] + oy
                return abs(gx - start[0]) + abs(gy - start[1]) + abs(gx - goal[0]) + abs(gy - goal[1])
            i = min(range(len(first)), key=far)
            return [(rings[k][min(i, len(rings[k]) - 1)][0] + ox, rings[k][min(i, len(rings[k]) - 1)][1] + oy)
                    for k in crossing]
        return []

    def _astar(self, start, goal, limit: int = 30000) -> list[tuple[int, int]]:
        import heapq
        gx, gy = goal
        target_ok = self.walkable(gx, gy)
        goal_door = goal in self.layer(gx, gy).doors
        if self.area is not None and self.area.kind == "dungeon":
            from game import traps
            known = traps.avoid(self) - {goal}             # round the traps you've seen
        else:
            known = ()

        def h(c):
            ddx, ddy = abs(c[0] - gx), abs(c[1] - gy)
            return max(ddx, ddy) + 0.41 * min(ddx, ddy)
        prev = {start: None}
        cost = {start: 0.0}
        todo = [(h(start), 0.0, start)]
        end = None
        while todo and len(prev) < limit:
            _f, g, c = heapq.heappop(todo)
            if g > cost.get(c, 1e18):
                continue
            near = abs(c[0] - gx) + abs(c[1] - gy) == 1 if goal_door else max(abs(c[0] - gx), abs(c[1] - gy)) == 1
            if c == goal or (not target_ok and near):
                end = c
                break
            for d, (dx, dy) in DIRS.items():
                n = (c[0] + dx, c[1] + dy)
                if not (0 <= n[0] < self.area.w and 0 <= n[1] < self.area.h):
                    continue
                step = 1.41 if dx and dy else 1.0
                ng = g + step
                if ng >= cost.get(n, 1e18):
                    continue
                if dx and dy and (not self.walkable(c[0] + dx, c[1]) or not self.walkable(c[0], c[1] + dy)
                                  or n in self.layer(*n).doors or c in self.layer(*c).doors):
                    continue
                lv = self.layer(*n)
                if not self.walkable(*n) and not self._door_passable(lv, n):
                    continue
                if n in known:
                    continue
                if n in lv.exits and n != goal:
                    continue
                if n in lv.stairs and n != goal:
                    continue
                cost[n] = ng
                prev[n] = c
                heapq.heappush(todo, (ng + h(n), ng, n))
        if end is None:
            return []
        out = []
        while end is not None and end != start:
            out.append(end)
            end = prev[end]
        return out[::-1]

    def _door_passable(self, lv: A.Level, c) -> bool:
        """A shut door the party could just open on the way (not barred, not known to be locked)."""
        d = lv.doors.get(c)
        if not d or d.get("barred") or d.get("kind") == "exit" or self.secret_hidden(lv, c):
            return False
        return self.door_state(lv.key, c) != "locked" and self.token_at(*c) is None

    def direction_to(self, x: int, y: int) -> str:
        dx = (x > self.x) - (x < self.x)
        dy = (y > self.y) - (y < self.y)
        for k, v in DIRS.items():
            if v == (dx, dy):
                return k
        return ""

    # ==================================================================
    # Monsters met in the open
    # ==================================================================
    def _roll_encounter(self, hex_loc: str) -> str:
        """Every so often out in the wilds, roll for meeting something. What turns up is put on the map a
        little way off, out of sight, and comes for the party (unless it lies in wait)."""
        from game import hexes as H
        from game import travel
        self._enc_meter += 1
        every = int(self.world.rules.get("walk_encounter_squares", ENCOUNTER_SQUARES) or ENCOUNTER_SQUARES)
        if self._enc_meter < every or self.encounters:
            return ""
        self._enc_meter = 0
        qr = H.parse_id(hex_loc)
        if qr is None:
            return ""
        from game import settlements as ST
        from game.worldmap import SQ
        floor = self.layer(self.x, self.y).floor_at(self.x, self.y)
        grade = ROAD_FLOORS.get(floor, "")                 # the roads are watched (highways most)
        chance = H.encounter_chance(self.world, *qr) * ST.danger_factor(self.world, self.x / SQ, self.y / SQ, grade)
        if chance <= 0 or self.rng.random() * 100 >= chance:
            return ""
        levels = [max(1, int(m.get("level") or 1)) for m in self.members() if not m.get("dead")] or [1]
        found = travel.encounter(self.world, H.biome(self.world, *qr), levels, self.rng,
                                 region=H.region(self.world, *qr), night=self.state.time_of_day in ("Night", "Dusk"))
        if not found:
            return ""
        return self.spawn_group(found, calm=self._calm(found))

    def _calm(self, found: dict) -> bool:
        """Beasts going about their business, not hunting the party: grazers mostly, and now and then a
        predator that isn't hungry. They can be tamed (game/animals.py)."""
        from game import animals
        es = [self.world.entities.get(r.get("id") or "") for r in found.get("rows") or []]
        if not es or not all(e is not None and animals.tameable(e) for e in es):
            return False
        return self.rng.random() < (0.85 if not any(animals.predator(e) for e in es) else 0.3)

    def raid_sync(self) -> str:
        """A raid on the town (game/townevents.py): its current wave comes in at the gate, and the waves that
        are over (or a raid that's ended) leave the map."""
        ev = getattr(self.state, "events", None) or {}
        raid = ev.get("raid")
        live = raid is not None and raid.get("status") == "on" and self.area is not None
        gid = f"raid{raid['started']}w{raid['wave']}" if live else ""
        for g in [k for k, v in self.encounters.items() if v.get("raid") and k != gid]:
            self.encounters.pop(g, None)
        if not live or gid in self.encounters:
            self._merge_tokens()
            return ""
        from game import townevents as TE
        town = self.world.entities.get(raid["town"])
        here = places.current(self.world, self.state)
        if town is None or here.town is None or here.town.id != town.id:
            return ""
        gates = (self.area.gates_of(town) if self.area.kind == "world" else self.area.gates) or {}
        at = gates.get(raid.get("gate") or "") or next(iter(gates.values()), None)
        rows = TE.wave_rows(raid)
        if not rows:
            return ""
        self.spawn_group({"rows": rows, "text": raid.get("text") or "Raiders!", "environment": "street"},
                         at=at, gid=gid)
        if gid in self.encounters:
            self.encounters[gid]["raid"] = True
        return gid

    def spawn_group(self, found: dict, distance: tuple[int, int] = (9, 13), calm: bool = False, at=None,
                    gid: str = "") -> str:
        """Put a band of monsters on the map near the party (out of sight where possible). calm: beasts that
        keep to themselves (they graze and wander, and can be tamed) until something sets them off."""
        import math
        self._enc_count += 1
        gid = gid or f"enc{self._enc_count}"
        rows = found.get("rows") or []
        units = []
        for row in rows:
            e = self.world.entities.get(row.get("id") or "")
            if e is not None:
                units += [e] * max(1, int(row.get("count") or 1))
        if not units:
            return ""
        best = None
        if at is not None:
            best = self._spot_near(self.level, int(at[0]), int(at[1]), set(), "", 12)
        for _ in range(0 if best is not None else 40):
            ang = self.rng.random() * 2 * math.pi
            d = self.rng.randint(*distance)
            c = (int(self.x + math.cos(ang) * d), int(self.y + math.sin(ang) * d))
            if not self.walkable(*c):
                continue
            if c not in self.visible:
                best = c
                break
            best = best or c
        if best is None:
            return ""
        toks, taken = [], set()
        for i, e in enumerate(units[:6]):
            c = self._spot_near(self.level, best[0] + (i % 3) - 1, best[1] + (i // 3), taken, "", 6)
            if c is None:
                continue
            taken.add(c)
            toks.append(Token(f"{gid}#{i}", e.name, c[0], c[1], self.level, "enemy", e.id, "", c, hidden=hides(e),
                              group=gid))
        if not toks:
            return ""
        self.encounters[gid] = {"rows": rows, "text": found.get("text") or "", "tokens": toks,
                                "environment": found.get("environment") or "plains", "calm": calm}
        self._merge_tokens()
        return ""

    def watch(self) -> StepResult:
        """A guard who can see a wanted party comes to stop it (game/law.py)."""
        res = StepResult()
        if self.area is None or self.area.kind not in ("town", "world") or self.travelling():
            return res
        from game import law
        key, gp = law.should_confront(self.world, self.state)
        if not gp:
            return res
        vis = self.visible or set()
        for t in self.tokens:
            if t.kind != "npc" or t.level != self.level or (t.x, t.y) not in vis:
                continue
            if max(abs(t.x - self.x), abs(t.y - self.y)) > 8:
                continue
            npc = self.world.entities.get(t.entity)
            if npc is None or (npc.fields.get("occupation") or "") != "Guard" or self.state.npc_dead(npc.id):
                continue
            law.confronted(self.state)
            res.prompt = Prompt(f"{npc.name} of the watch",
                                f"\"Hold there. You're wanted in {law.realm_name(self.world, key)}: {gp} gp, or the "
                                f"cells.\"", law.guard_prompt_options(self.world, self.state, key, gp), who=npc.id)
            return res
        return res

    def tick(self) -> StepResult:
        """A moment passes on the map: monsters out in the open close in. Returns an action when they reach
        the party (a fight), or a message when they're first seen. A guard stops a wanted party."""
        res = StepResult()
        if self.area is None:
            return res
        if (getattr(self.state, "events", None) or {}).get("raid") or any(v.get("raid") for v in self.encounters.values()):
            self.raid_sync()
        if not self.encounters:
            return self.watch()
        import math
        for gid, g in list(self.encounters.items()):
            toks = g["tokens"]
            near = min(max(abs(t.x - self.x), abs(t.y - self.y)) for t in toks)
            if near > 45:                                    # left behind
                del self.encounters[gid]
                continue
            if g.get("calm"):                                 # grazing: a step this way or that, now and then
                for t in toks:
                    t.hidden = False
                    if self.rng.random() < 0.08:
                        sx, sy = self.rng.choice(list(DIRS.values()))
                        nx, ny = t.x + sx, t.y + sy
                        lv = self.area.layer(t.level, nx, ny)
                        if max(abs(nx - t.home[0]), abs(ny - t.home[1])) <= 4 and not lv.blocks(nx, ny) and \
                                (nx, ny) not in lv.doors and self.token_at(nx, ny, t.level) is None and \
                                (nx, ny) != (self.x, self.y):
                            t.x, t.y = nx, ny
                            t.facing = "E" if sx > 0 else "W" if sx < 0 else "S" if sy > 0 else "N"
                    if not g.get("announced") and self.shown(t):
                        g["announced"] = True
                        if not res.message:
                            many = len(toks) > 1
                            res.message = f"{'Some' if many else 'A'} {t.name.lower()}{'s' if many else ''} " \
                                          f"{'graze' if many else 'grazes'} nearby, keeping an eye on you."
                continue
            before = [(t.x, t.y) for t in toks]
            for t in toks:
                if t.hidden and max(abs(t.x - self.x), abs(t.y - self.y)) <= 2:
                    t.hidden = False
                    res.message = f"{t.name} springs out of hiding!"
                    res.action = ("battle", gid)
                    break
                if not t.hidden and not g.get("announced") and self.shown(t):
                    g["announced"] = True
                    if not res.message:
                        res.message = g["text"] or f"{t.name} is coming this way!"
                if t.hidden:
                    continue
                dx, dy = self.x - t.x, self.y - t.y
                if max(abs(dx), abs(dy)) <= 1:
                    res.action = ("battle", gid)
                    break
                options = []
                for sx, sy in DIRS.values():
                    nx, ny = t.x + sx, t.y + sy
                    lv = self.area.layer(t.level, nx, ny)
                    if lv.blocks(nx, ny) or (nx, ny) in lv.doors or self.token_at(nx, ny, t.level) is not None \
                            or (nx, ny) == (self.x, self.y):
                        continue
                    options.append((math.hypot(self.x - nx, self.y - ny), nx, ny, sx, sy))
                if options:
                    _d, nx, ny, sx, sy = min(options)
                    if _d < math.hypot(dx, dy):
                        t.x, t.y = nx, ny
                        t.facing = "E" if sx > 0 else "W" if sx < 0 else "S" if sy > 0 else "N"
            if res.action:
                break
            # carried along a road or across country, the party doesn't stand still for long: what lies in
            # wait springs its ambush as you pass, and what can't find a way to you gives up
            if self.travelling() and [(t.x, t.y) for t in toks] == before:
                g["still"] = g.get("still", 0) + 1
                if g["still"] >= 20:
                    if any(t.hidden for t in toks) and near <= 16:
                        for t in toks:
                            t.hidden = False
                        res.message = f"{toks[0].name} springs out of hiding!"
                        res.action = ("battle", gid)
                        break
                    del self.encounters[gid]
                    res.message = res.message or "Whatever it was loses your trail."
            else:
                g["still"] = 0
        self._merge_tokens()
        return res

    def prefetch(self, radius: int = 3) -> bool:
        """Make one not-yet-made chunk of the open world near the party (call when there's time to spare),
        so walking on doesn't stop to make them. Returns True if it made one."""
        if self.area is None or self.area.kind != "world":
            return False
        from game.worldmap import CH
        base = self.area.levels["0"]
        cx, cy = self.x // CH, self.y // CH
        for r in range(radius + 1):
            for j in range(cy - r, cy + r + 1):
                for i in range(cx - r, cx + r + 1):
                    if max(abs(i - cx), abs(j - cy)) == r and not base.has(i, j):
                        base.chunk(i, j)
                        return True
        return False

    def group_info(self, gid: str) -> dict | None:
        return self.encounters.get(gid)

    def tame(self, tid: str, rng=None) -> dict:
        """One try at taming a calm beast on the map (game/animals.py). Tamed, it leaves its herd and joins the
        party; a bad failure sends the herd off (or turns a predator on the party: "angry", with its group)."""
        from game import animals
        t = next((x for x in self.tokens if x.id == tid), None)
        g = self.encounters.get(t.group) if t is not None and t.group else None
        e = self.world.entities.get(t.entity) if t is not None else None
        if g is None or e is None:
            return {"result": "gone", "text": "It's gone."}
        r = animals.tame_try(self.world, self.state, self.members(), e, f"tame:{t.id}", rng or self.rng, self.bus)
        if r["result"] == "tamed":
            g["tokens"] = [x for x in g["tokens"] if x.id != t.id]
            for row in g["rows"]:
                if row.get("id") == e.id:
                    row["count"] = max(0, int(row.get("count") or 1) - 1)
            g["rows"] = [row for row in g["rows"] if int(row.get("count") or 0) > 0]
            if not g["tokens"]:
                self.encounters.pop(t.group, None)
            r["animal"] = animals.adopt(self.world, self.state, e)
        elif r["result"] == "fled":
            self.encounters.pop(t.group, None)
        elif r["result"] == "angry":
            g["calm"] = False
            r["group"] = t.group
        self._merge_tokens()
        return r

    def remove_group(self, gid: str) -> None:
        self.encounters.pop(gid, None)
        self._merge_tokens()

    # ==================================================================
    # Doors and locks
    # ==================================================================
    def _bump_door(self, lv: A.Level, c) -> StepResult:
        d = lv.doors[c]
        if d.get("kind") == "dungeon":
            label = d.get("label") or "the dark"
            return StepResult(prompt=Prompt(f"Go into {label}?", "Who knows what's down there.",
                                            [("Go in", ("go", d.get("target") or ""), bool(d.get("target"))),
                                             ("Not yet", ("none",), True)]))
        if d.get("barred"):
            return StepResult(message="Someone's home. The door is barred, and nobody comes when you knock.")
        if d.get("kind") == "exit":
            return StepResult(prompt=self.leave_dungeon_prompt())
        dc, why = self.lock_of(lv, c)
        if dc:
            self.set_door(lv.key, c, "locked") if self.door_state(lv.key, c) != "locked" else None
            from game import jail
            if jail.opened_in_jail(self, lv, c):            # locked in: call the guard, or pick it (game/jail.py)
                return StepResult(prompt=jail.door_prompt(self, lv, c))
            return StepResult(prompt=self.lock_prompt(lv, c, dc, why))
        self.set_door(lv.key, c, "open")
        self.look()
        return StepResult(message="")

    def lock_of(self, lv: A.Level, c) -> tuple[int, str]:
        """(DC, why) if this door is locked right now, else (0, '')."""
        d = lv.doors.get(c) or {}
        st = self.door_state(lv.key, c)
        if st in ("unlocked", "broken", "open"):
            return 0, ""
        if d.get("kind") == "street":
            b = self.world.entities.get(d.get("bid") or "")
            if b is None or b.fields.get("owner"):
                return 0, ""
            if not places.is_open(b, self.state.minute_of_day):
                return 15, f"{b.name} is shut. It opens at {places.opens_at(b)}."
            return 0, ""
        dc = int(d.get("lock") or 0)
        if not dc:
            return 0, ""
        room = d.get("room") or ""
        if room in (self.data.get("keys") or []):
            return 0, ""
        # standing on the private side, the latch opens from inside (but not a jail cell's)
        if self.zone_loc() == room and not d.get("cell"):
            return 0, ""
        name = places.parse(self.world, room).name if room else "the room"
        return dc, f"The door to the {name.lower() if name else 'room'} is locked."

    def give_key(self, room_loc: str) -> None:
        keys = self.data.setdefault("keys", [])
        if room_loc and room_loc not in keys:
            keys.append(room_loc)

    def best_member(self, option_ids: list[str], stat: str):
        """(member, combatant, option, bonus) of whoever is best at this."""
        from game import checks, condition
        opts = {o["id"]: o for o in checks.options(self.world)}
        best = None
        for m in self.members():
            if m.get("dead"):
                continue
            c = condition.combatant(self.world, m)
            for oid in option_ids + [f"stat:{stat}"]:
                o = opts.get(oid)
                if o is None:
                    continue
                if o["kind"] == "Tool" and not checks.proficient(self.world, m, o) and not o.get("untrained", True):
                    continue
                b, _p = checks.bonus(self.world, m, c, o)
                if best is None or b > best[3]:
                    best = (m, c, o, b)
                break
        return best

    def lock_prompt(self, lv: A.Level, c, dc: int, why: str) -> Prompt:
        opts = []
        pick = self.best_member(["skill.thieves-tools"], "dex")
        force = self.best_member(["skill.athletics"], "str")
        key = f"{lv.key}:{c[0]},{c[1]}"
        if pick:
            m, _c, o, b = pick
            opts.append((f"Pick the lock: {m.get('name')} ({o['label']} {b:+d} vs DC {dc})", ("pick", key, dc), True))
        if force and not (lv.doors.get(c) or {}).get("cell"):        # (iron: no shouldering a cell door)
            m, _c, o, b = force
            opts.append((f"Force it open: {m.get('name')} ({o['label']} {b:+d} vs DC {dc + 3})",
                         ("force", key, dc + 3), True))
        opts.append(("Leave it", ("none",), True))
        return Prompt("Locked", why, opts)

    def try_lock(self, key: str, dc: int, how: str) -> str:
        from game import checks
        lk, _s, xy = key.rpartition(":")
        x, y = (int(v) for v in xy.split(","))
        lv = next((v for v in self.area.all_levels() if v.key == lk), None)
        if lv is None:
            return ""
        got = self.best_member(["skill.thieves-tools"], "dex") if how == "pick" else \
            self.best_member(["skill.athletics"], "str")
        if got is None:
            return "Nobody can do that."
        m, c, o, _b = got
        r = checks.roll(self.world, m, c, o, dc, rng=self.rng, bus=self.bus,
                        target="a lock" if how == "pick" else "a door")
        self.state.advance(1 if how == "pick" else 0, "a lock")
        if r.get("success"):
            d = lv.doors.get((x, y)) or {}
            b = self.world.entities.get(d.get("bid") or "")
            from game import jail
            if jail.opened_in_jail(self, lv, (x, y)):        # out of the cell (game/jail.py)
                self.set_door(lk, (x, y), "unlocked")
                self.look()
                self.save()
                return jail.cell_opened(self)
            if b is not None and b.type == "building" and not b.fields.get("owner"):   # not yours: a crime
                from game import law
                law.broke_in(self.world, self.state, self.members(), places.current(self.world, self.state).town,
                             d.get("kind") == "street", self, self.rng, self.bus)
            self.set_door(lk, (x, y), "unlocked" if how == "pick" else "broken")
            self.look()
            self.save()
            return f"{m.get('name')} gets the door open." if how == "pick" else \
                f"{m.get('name')} breaks the door in with a crash."
        if how == "force":
            return f"{m.get('name')} throws a shoulder at the door. It holds."
        return f"{m.get('name')} can't work the lock."

    def toggle_door(self, c) -> str:
        lv = self.layer(*c)
        if c not in lv.doors:
            return ""
        st = self.door_state(lv.key, c)
        if st == "broken":
            return "That door won't shut any more."
        if st == "open":
            if (self.x, self.y) == c or self.token_at(*c):
                return ""
            self.set_door(lv.key, c, "unlocked" if lv.doors[c].get("lock") or lv.doors[c].get("kind") == "street"
                          else "")
            self.look()
            return "You close the door."
        r = self._bump_door(lv, c)
        return r.message

    # ==================================================================
    # Things to do
    # ==================================================================
    def facing_cell(self) -> tuple[int, int]:
        dx, dy = DIRS.get(self.facing, (0, 1))
        return self.x + dx, self.y + dy

    def interact(self) -> StepResult:
        """The use button: whatever's in front of the party (or underfoot)."""
        if self.area is None:
            return StepResult()
        lv = self.layer(self.x, self.y)
        cands = [self.facing_cell()] + [(self.x + dx, self.y + dy) for dx, dy in DIRS.values()]
        for c in cands:
            t = self.token_at(*c)
            if t is not None and self.shown(t):
                if t.kind == "crowd" and t.id.startswith("homeless:"):
                    from game import homeless                     # (game/homeless.py)
                    return StepResult(prompt=homeless.prompt(self, t))
                if t.kind == "crowd":
                    dx, dy = self.x - t.x, self.y - t.y           # they turn to you (briefly)
                    t.facing = ("E" if dx > 0 else "W") if abs(dx) >= abs(dy) and dx else ("S" if dy > 0 else "N")
                    return StepResult(message=self.crowd_line(t))
                return StepResult(prompt=self.person_prompt(t))
        f = self.facing_cell()                             # a trap you know of, just ahead (game/traps.py)
        lf = self.layer(*f)
        if getattr(lf, "traps", None) and f in lf.traps:
            from game import traps
            here = traps.at(self, lf, f)
            if here is not None and here[3] == "seen":
                return StepResult(prompt=traps.prompt(self, lf, f))
        for c in cands:
            l2 = self.layer(*c)
            if c in l2.doors and not self.secret_hidden(l2, c):
                if l2.doors[c].get("kind") == "exit":
                    return StepResult(prompt=self.leave_dungeon_prompt())
                if not self.door_open(l2, c):
                    return self._bump_door(l2, c)
                if c == self.facing_cell():
                    return StepResult(message=self.toggle_door(c))
            if c in l2.stations:
                return StepResult(prompt=self.station_prompt(l2, c))
            p = l2.prop_cells.get(c)
            if p is not None and p.id == "chest":
                return StepResult(prompt=self.chest_prompt())
        if (self.x, self.y) in lv.stairs:
            lk, sx, sy = lv.stairs[(self.x, self.y)]
            self.level, self.x, self.y = lk, sx, sy
            self._step_off_stairs()
            self.look()
            return StepResult(moved=True, changed_level=True)
        from game import fire
        f = self.facing_cell()
        if fire.burning_at(self, *f):                    # flames ahead (game/fire.py)
            return StepResult(prompt=fire.prompt(self, *f))
        for c in cands:                                   # something to gather (game/gathering.py)
            got = self.gather_target(*c)
            if got is not None:
                return self.gather_step(*got)
        from game import destruction                     # something to break (game/destruction.py)
        p = destruction.prompt(self, *f)
        if p is not None:
            return StepResult(prompt=p)
        return StepResult(message="")

    # ==================================================================
    # People at work (game/crafting.py)
    # ==================================================================
    def work_bar(self, t: Token) -> float | None:
        """How far along the piece a working NPC is making is (0..1), or None. It's worked out from the
        clock, so it moves only when the clock does, and after a while out of sight it has caught up."""
        if not t.at_work or t.kind != "npc" or self.state.time_of_day == "Night":
            return None
        key = (t.entity, self.state.minutes)
        memo = self.__dict__.setdefault("_bar_memo", {})
        if key in memo:
            return memo[key]
        from game import crafting
        from game import estate as ES
        npc = self.world.entities.get(t.entity)
        try:
            v = ES.bar(self.world, self.state, npc) if npc is not None and \
                ES.worker_of_npc(self.state, npc.id) is not None else \
                crafting.bar_for(self.world, self.state, npc) if npc is not None else None
        except Exception:  # noqa: BLE001 - never stop the map over a bar
            v = None
        if len(memo) > 500:
            memo.clear()
        memo[key] = v
        return v

    # ==================================================================
    # Gathering (game/gathering.py)
    # ==================================================================
    def gather_target(self, x: int, y: int):
        """(level, prop or None, x, y, work) for something that can be gathered at a square, or None."""
        from game import gathering as GA
        lv = self.layer(x, y)
        p = lv.prop_cells.get((x, y))
        if p is not None:
            if p.id in GA.SOURCES:
                return lv, p, p.x, p.y, GA.SOURCES[p.id][0]
            from game import landchanges
            chg = landchanges.change_on(self.state, lv, p.x, p.y)
            if chg is not None and chg.get("was"):
                return lv, p, p.x, p.y, ""                  # used up: say when it grows back
            return None
        if (x, y) in lv.water and not self.vessel and lv.water.get((x, y)) != "swamp":
            return lv, None, x, y, "fishing"
        return None

    def land_at(self, x: int, y: int) -> str:
        """The land a square is in (for what grows there)."""
        a = self.area
        grid = getattr(a, "grid", None)
        if grid is not None and a.kind == "world":
            from game.worldmap import SQ
            site = a.site_at(x, y) if hasattr(a, "site_at") else None
            if site is not None:
                town = self.world.entities.get(site.ent_id)
                if town is not None and town.type == "town":
                    return town.fields.get("terrain") or "Plains"
            return grid.biome_at(x / SQ, y / SQ)
        if a.kind == "dungeon":
            return "Cave"
        return getattr(a, "terrain", "") or "Plains"

    def danger_here(self) -> int:
        """How dangerous the region is (rarer ore in harder places)."""
        from game import geography as G
        spot = places.current(self.world, self.state)
        try:
            if spot.kind == "dungeon":
                return int(spot.extra["dungeon"].fields.get("level") or 1) * 5
            if self.area is not None and self.area.kind == "world":
                from game.worldmap import SQ
                reg = G.region_at(self.world, self.x / SQ, self.y / SQ)
            else:
                pos = G.town_position(self.world, spot.town) if spot.town is not None else None
                reg = G.region_at(self.world, *pos) if pos else None
            return int((reg.fields.get("danger") if reg is not None else 0) or 0)
        except Exception:  # noqa: BLE001 - nowhere in particular
            return 0

    def gather_step(self, lv, p, x: int, y: int, work: str) -> StepResult:
        from game import landchanges
        if not work:
            chg = landchanges.change_on(self.state, lv, x, y) or {}
            what = {"stump": "a stump", "spent_vein": "a worked-out vein", "bare_patch": "picked clean",
                    "rubble": "broken rock", "bush": "picked clean"}.get(p.id, "used up")
            until = chg.get("until")
            if until is None:
                return StepResult(message=f"Nothing more to be had here: {what}.")
            days = max(1, round((int(until) - self.state.minutes) / 1440))
            return StepResult(message=f"Nothing more to be had here ({what}): it should grow back in about "
                                      f"{days} day{'s' if days != 1 else ''}.")
        return StepResult(prompt=self.gather_prompt(lv, p, x, y, work))

    def gather_prompt(self, lv, p, x: int, y: int, work: str) -> Prompt:
        from game import gathering as GA
        pid = p.id if p is not None else "water"
        src = GA.SOURCES.get(pid) or GA.SOURCES["water"]
        who = GA.best_gatherer(self.world, self.state, self.members(), work, src[1])
        title = p.defn.label if p is not None else "Water"
        if who is None:
            return Prompt(title, "Nobody here can do that.", [("Leave it", ("none",), True)])
        m, _c, opt, b, tool, speed = who
        minutes = int(round(src[3] * (1.0 if tool is not None else GA.HAND_TIME) / max(0.25, speed)))
        how = f"with {tool.name.lower()}" if tool is not None else "by hand (slow, and only one at a time)"
        text = (f"{GA.VERB[work]}: {m.get('name')} {how}, about {minutes} minutes a try. "
                f"{opt['label']} {'+' if b >= 0 else '-'}{abs(b)}.")
        w = self.weather()
        if work in ("foraging", "harvesting") and getattr(w, "ground", "") == "snow":
            return Prompt(title, "Everything is buried under the snow.", [("Leave it", ("none",), True)])
        if not GA.in_season(self.world, self.state.minutes, work, pid, self.land_at(x, y)):
            from game import calendar as CAL
            return Prompt(title, GA.out_of_season(work, CAL.season(self.world, self.state.minutes)),
                          [("Leave it", ("none",), True)])
        if work == "fishing" and getattr(w, "wet", False):
            text += " The fish are biting in the rain."
        if work in GA.NOISY:
            text += " Noisy work: it may draw attention."
        verb = GA.VERB[work]
        opts = [(f"{verb} (one try)", ("gather", x, y, 1), True),
                (f"Keep at it (up to {GA.MAX_TRIES} tries)", ("gather", x, y, GA.MAX_TRIES), True)]
        if p is not None:
            from game import destruction                     # or break it (game/destruction.py)
            if destruction.thing_at(self, x, y) is not None:
                opts.append(("Smash it instead", ("smash_prompt", x, y), True))
        if p is None and self.world.rules.get("survival"):     # water to drink (game/survival.py)
            opts.append(("Fill your waterskins here", ("activity", "survival:refill-wild"), True))
        opts.append(("Leave it", ("none",), True))
        return Prompt(title, text, opts)

    def gather(self, x: int, y: int, tries: int = 1, on_try=None) -> dict:
        """Gather from the thing at (x, y) (one try, or keep at it until it's used up or `tries` are done).
        on_try(i, result) is called after each (for the screen's progress bar). Returns {"lines", "items",
        "minutes", "used_up", "found"}."""
        from game import gathering as GA
        got = self.gather_target(x, y)
        if got is None:
            for c in [(x, y)] + [(x + dx, y + dy) for dx, dy in DIRS.values()]:
                if self.layer(*c).prop_cells.get(c) is not None:
                    got = self.gather_target(*c)
                    if got is not None:
                        break
        out = {"lines": [], "oks": [], "items": [], "minutes": 0, "used_up": False, "found": "", "work": ""}
        if got is None or not got[4]:
            out["lines"].append("There's nothing to gather there.")
            return out
        lv, p, gx, gy, work = got
        out["work"] = work
        pid = p.id if p is not None else "water"
        land = self.land_at(gx, gy)
        danger = self.danger_here()
        weather = self.weather()
        noisy = work in GA.NOISY and self.area is not None and self.area.kind == "world"
        for i in range(max(1, tries)):
            r = GA.attempt(self.world, self.state, self.members(), pid, gx, gy, land, rng=self.rng, bus=self.bus,
                           weather=weather, variant=p.variant if p is not None else 0, danger=danger, work=work)
            out["lines"].append(r["text"])
            out["oks"].append(bool(r.get("ok")))
            out["items"] += r.get("items") or []
            out["minutes"] += r.get("minutes") or 0
            if noisy:
                self._enc_meter += GA.NOISE_SQUARES
            if on_try is not None:
                try:
                    on_try(i, r)
                except Exception:  # noqa: BLE001 - the screen's business
                    pass
            if r.get("ok") and r.get("used_up") and p is not None:
                GA.use_up(self.world, self.state, lv, gx, gy, r, p, self.bus)
                out["used_up"] = True
                from game import destruction                 # a tree cut through falls away from you
                if p.id in destruction.TRUNK:
                    t = {"lv": lv, "x": gx, "y": gy, "id": p.id, "label": p.defn.label}
                    out["lines"] += destruction.fall(self, t, (self.x, self.y), self.rng, stump=False)
                    destruction._redraw(self)
                break
            if not r.get("minutes"):                         # couldn't even start (snow, nobody able)
                break
        self._weather_cache = None
        if noisy:
            loc = self.zone_loc()
            if loc.startswith("hex|"):
                out["found"] = self._roll_encounter(loc)
        self.save()
        return out

    def search_land(self, radius: int = 24) -> tuple[bool, str]:
        """Search the land about for what's hidden (a rich vein, rare herbs): the party's best Wisdom
        (Perception) or Intelligence (Investigation) against DC 14. Takes 20 minutes."""
        from game import checks, condition
        from game import gathering as GA
        opts = {o["label"].lower(): o for o in checks.options(self.world)}
        pick = None
        for m in self.members():
            if m.get("dead"):
                continue
            c = condition.combatant(self.world, m)
            for k in ("perception", "investigation", "survival"):
                o = opts.get(k)
                if o is None:
                    continue
                b = checks.bonus(self.world, m, c, o)[0]
                if pick is None or b > pick[3]:
                    pick = (m, c, o, b)
        self.state.advance(20, "searching")
        if pick is None or self.area is None:
            return False, "You look about but find nothing."
        m, c, o, _b = pick
        r = checks.roll(self.world, m, c, o, GA.SEARCH_DC, rng=self.rng, bus=self.bus, target="searching the land")
        if not r.get("success"):
            return False, f"{m.get('name')} searches the land about but finds nothing out of the ordinary."
        if self.area.kind != "world":
            return False, f"{m.get('name')} searches carefully: nothing hidden here."
        found = GA.reveal_near(self.world, self.state, self.area.levels["0"], self.x, self.y, radius, self.bus,
                               land_at=self.land_at)
        if not found:
            return False, f"{m.get('name')} searches carefully: nothing hidden hereabouts."
        bits = []
        for hx, hy, kind in found:
            d = DIR_WORDS.get(self.direction_to(hx, hy), "")
            bits.append(("a rich vein of ore" if kind == "rich_vein" else "a patch of rare herbs") +
                        (f" to the {d}" if d else " close by"))
        return True, f"{m.get('name')} finds " + "; ".join(bits) + "."

    def crowd_line(self, t: Token) -> str:
        d = self.crowd_info.get(t.id) or {}
        line = d.get("line") or "..."
        if self.rng.random() < self._crowd_rumor_chance():          # now and then, something worth hearing
            from game import rumors
            spot = places.current(self.world, self.state)
            r = rumors.hear(self.world, self.state, spot.town, self.rng, source="someone in the street",
                            bus=self.bus) if spot.town is not None else None
            if r is not None:
                line = r["text"]
        return f"{t.name[:1].upper()}{t.name[1:]}: \"{line}\""

    @staticmethod
    def _crowd_rumor_chance() -> float:
        from game import rumors
        return rumors.CROWD_CHANCE

    def person_prompt(self, t: Token) -> Prompt:
        npc = self.world.entities.get(t.entity)
        dx, dy = self.x - t.x, self.y - t.y                 # they turn to face you
        if abs(dx) >= abs(dy) and dx:
            t.facing = "E" if dx > 0 else "W"
        elif dy:
            t.facing = "S" if dy > 0 else "N"
        if t.kind == "enemy":
            g = self.encounters.get(t.group) if t.group else None
            if g is not None and g.get("calm"):                # a wild beast minding its own business
                from game import animals
                e = self.world.entities.get(t.entity)
                got = int(self.state.taming.get(f"tame:{t.id}", 0))
                dc = animals.tame_dc(e) if e is not None else 10
                text = f"Wary, but not hostile. Calming it: {got} of {animals.TAME_SUCCESSES} (DC {dc})."
                return Prompt(t.name, text, [("Try to tame it (10 min)", ("tame", t.id), True),
                                             ("Attack", ("battle", t.group), True),
                                             ("Leave it be", ("none",), True)], who=t.entity)
            return Prompt(t.name, "", [("Attack", ("enter", t.room), True), ("Back away", ("none",), True)], who=t.entity)
        opts = [(f"Talk to {t.name}", ("chat", t.entity), True)]
        from game import trade
        if npc is not None and trade.is_merchant(self.world, npc):
            opts.append(("Trade", ("trade", t.entity), True))
        opts.append(("Make a check...", ("check", t.entity), True))
        if npc is not None and self.area is not None and self.area.kind in ("town", "world"):
            opts.append(("Pick their pocket (a crime)", ("pickpocket", t.entity), True))   # game/law.py
            if trade.is_merchant(self.world, npc):
                opts.append(("Steal from their wares (a crime)", ("steal", t.entity), True))
        opts.append(("Attack", ("fight", t.entity), True))
        opts.append(("Never mind", ("none",), True))
        occ = (npc.fields.get("occupation") or "") if npc is not None else ""
        return Prompt(t.name, occ, opts, who=t.entity)

    def worker_at(self, loc: str, kind: str) -> Token | None:
        key_for = {v: k for k, v in places.ROLE_STATION.items()}
        for t in self.tokens:
            if t.room != loc or t.kind != "npc":
                continue
            npc = self.world.entities.get(t.entity)
            if npc is not None and places.ROLE_STATION.get(npc.fields.get("occupation") or "") == kind:
                return t
        del key_for
        return None

    def station_prompt(self, lv: A.Level, c) -> Prompt:
        st = lv.stations[c]
        kind, loc = st["kind"], st["room"]
        spot = places.parse(self.world, loc)
        words = {"craft": (st.get("station") or "workbench").capitalize(), "signpost": "A signpost", "bar": "The bar", "counter": "The counter", "forge": "The forge", "altar": "The altar",
                 "beds": "A bed", "hearth": "The hearth", "tables": "A table", "desk": "A desk",
                 "throne": "The throne", "chest": "A chest", "special": "Something here"}
        opts = []
        w = self.worker_at(loc, kind) if kind in ("bar", "counter", "forge", "altar", "desk") else None
        if w is not None:
            opts.append((f"Talk to {w.name}", ("chat", w.entity), True))
            npc = self.world.entities.get(w.entity)
            from game import trade
            if npc is not None and trade.is_merchant(self.world, npc):
                opts.append((f"Trade with {w.name}", ("trade", w.entity), True))
        b = spot.building
        if kind in ("bar", "counter") and b is not None and float(b.fields.get("inn_price") or 0) > 0:
            from game.state import money_text
            opts.append((f"Rent rooms for the night ({money_text(int(float(b.fields['inn_price']) * 100))})",
                         ("activity", "rest:inn"), True))
        if kind in ("cot", "evidence") and b is not None:        # a jail's (game/jail.py)
            from game import jail
            if kind == "evidence":
                return jail.evidence_prompt(self, b.id)
            rec = jail.record(self.state)
            if rec and rec.get("cell") == loc:
                return jail.bed_prompt(self)
            kind = "beds"
        if kind == "beds" and b is not None:
            if b.fields.get("owner"):
                opts.append(("Sleep (long rest)", ("activity", "rest:home"), True))
            elif loc in (self.data.get("keys") or []):
                opts.append(("Sleep (long rest)", ("activity", "rest:inn"), True))
        craft_at = ""
        if kind == "craft":
            craft_at = st.get("station") or ""
        elif kind == "forge":
            craft_at = "forge"
        elif kind == "bar" and b is not None:
            from game import crafting
            if "kitchen" in crafting.building_stations(self.world, b):
                craft_at = "kitchen"
        if craft_at:
            from game import crafting
            info = crafting.station_info(self.world, craft_at)
            owned = b is not None and bool(b.fields.get("owner"))
            cost = crafting.rent(self.world, craft_at, owned)
            from game.state import money_text
            label = f"Work at the {info['label'].lower()}" + (f" ({money_text(int(cost * 100))} a day)" if cost else "")
            opts.insert(0, (label, ("craft", craft_at, loc, b.id if b is not None else ""), True))
            ready = crafting.ready_jobs(self.state, loc)
            if ready:
                opts.insert(0, (f"Collect {ready[0]['name']}" + (f" and {len(ready) - 1} more" if len(ready) > 1 else ""),
                                ("craft", craft_at, loc, b.id if b is not None else ""), True))
        if kind in ("tables", "bar", "counter") and b is not None:     # a game going (game/tablegames)
            from game import tablegames
            if tablegames.games_at(self.world, b):
                opts.insert(0, ("Sit down to play", ("games", b.id), True))
        if kind == "vault" and b is not None:          # a bank's strongboxes (game/bank.py)
            from game import bank
            from game.state import money_text
            held = bank.vault_holds(self.world, self.state, b)
            return Prompt("The strongboxes", f"Iron-bound and locked tight. They hold about {money_text(held)}." if held
                          else "Empty: someone's been here not long ago.",
                          [("Break into the vault (a crime)", ("rob", b.id), held > 0), ("Leave it", ("none",), True)])
        if kind == "shelf" and b is not None:          # a library's bookshelf (game/books.py)
            from game import books
            what, held = books.on_shelf(self.world, b, int(st.get("n") or 0), int(st.get("of") or 1))
            unread = sum(1 for i in held if not books.has_read(self.state, i.id))
            text = f"{what}: {len(held)} book{'s' if len(held) != 1 else ''}" + \
                (f", {unread} you haven't read." if unread else ", all of them read.")
            return Prompt("A bookshelf", text, [("Browse the shelf", ("shelf", b.id, int(st.get("n") or 0),
                                                                       int(st.get("of") or 1)), bool(held)),
                                                ("Never mind", ("none",), True)])
        if kind == "special":
            opts.append(("Look closer", ("activity", "special"), True))
        if kind == "chest":
            return self.chest_prompt()
        if kind == "claim_sign":
            from game import estate as ES
            c = ES.claim(self.state, st.get("claim") or "")
            if c is not None:
                n = len(ES.buildings(self.world, c["id"]))
                return Prompt(c["name"], f"Your {'settlement' if c['kind'] == 'settlement' else 'land'}: "
                                         f"{n} building{'s' if n != 1 else ''}." +
                              ("" if c.get("paid") else " " + ES.unregistered_text(self.world, c)),
                              [("Build something here", ("activity", f"estate:build:{c['id']}"), bool(c.get("paid"))),
                               ("Your land and workers", ("activity", f"estate:{c['id']}"), True),
                               ("Leave it", ("none",), True)])
        if kind == "sale_sign":
            from game import lots
            title, text, extra = lots.sign_prompt(self.world, self.state, self.world.entities.get(st.get("town") or ""))
            return Prompt(title, text, extra + [("Leave it", ("none",), True)])
        if kind == "signpost":
            from game import geography as G
            town = self.world.entities.get(st.get("town") or "")
            road = places.road_to(town, st.get("direction") or "") if town is not None else None
            if road:
                hours = G.road_hours(self.world, town, road)
                return Prompt(f"The road to {st.get('to') or 'the next town'}",
                              f"About {hours:.0f} hours on foot. " + GRADE_WORDS.get(
                                  road.get("grade") or "", f"Some {int(road.get('danger', 20) or 0)}% chance of "
                                                           "trouble on the way. ") +
                              "You can walk it, or follow the road and let the hours pass.",
                              [(f"Travel the road to {st.get('to')}", ("go", f"road:{town.id}:{road['direction']}"),
                                True), ("Never mind", ("none",), True)])
        opts.append(("Rest a while (short rest)", ("activity", "rest:short"), kind in ("beds", "tables", "hearth")))
        opts = [o for o in opts if o[2]]
        opts.append(("Never mind", ("none",), True))
        return Prompt(words.get(kind, kind.title()), spot.name if spot.kind != "nowhere" else "", opts)

    def chest_prompt(self) -> Prompt:
        from game import dungeons as DG
        items, gold, _owner, _key = DG.loot_here(self.world, self.state, self.state.location)
        if items or gold:
            return Prompt("A chest", "", [("Take what's inside", ("activity", "loot"), True), ("Leave it", ("none",), True)])
        return Prompt("A chest", "Empty.", [("Close it", ("none",), True)])

    def exit_prompt(self, ex: dict) -> Prompt:
        spot = places.current(self.world, self.state)
        town = spot.town
        d = ex["direction"]
        opts = []
        road = places.road_to(town, d) if town is not None else None
        if road and ex.get("road", True):
            dest = self.world.entities.get(road.get("leads_to") or "")
            if dest is not None:
                from game import geography
                hours = geography.road_hours(self.world, town, road)
                opts.append((f"Take the {d.lower()} road to {dest.name} (about {hours:.0f} h)",
                             ("go", f"road:{town.id}:{d}"), True))
        if town is not None:
            noun = places.TERRAIN_NOUN.get(town.fields.get("terrain") or "Plains", "wilds")
            opts.append((f"Head {d.lower()} into the {noun}", ("wilds", places.wild_id(town.id, d)), True))
        opts.append((f"Stay in {town.name if town else 'town'}", ("none",), True))
        return Prompt(f"Leave {town.name if town else 'town'}?", "Beyond here is the open country.", opts)

    def leave_dungeon_prompt(self) -> Prompt:
        target = next((o["target"] for o in places.options(self.world, self.state) if o["how"] == "leave"), "")
        spot = places.current(self.world, self.state)
        name = spot.extra.get("dungeon").name if spot.kind == "dungeon" else "this place"
        opts = [(f"Leave {name}", ("go", target), bool(target)), ("Stay", ("none",), True)]
        if not target:
            from game import dungeons as DG
            out = DG.outside_of(self.world, spot.extra.get("dungeon")) if spot.kind == "dungeon" else ""
            opts[0] = (f"Leave {name}", ("go", out), bool(out))
        return Prompt(f"Leave {name}?", "Daylight is that way.", opts)

    def choose(self, action: tuple) -> StepResult:
        """Carry out a prompt's option. What needs a window comes back as res.action."""
        what = action[0] if action else "none"
        if what == "none":
            return StepResult()
        if what in ("pick", "force"):
            msg = self.try_lock(action[1], int(action[2]), what)
            return StepResult(message=msg)
        if what in ("smash", "smash_prompt", "burn", "douse"):   # breaking and burning (game/destruction.py, fire.py)
            return self._wreck(action)
        if what == "enter":
            loc = action[1]
            if loc and loc != self.state.location:
                places.enter(self.world, self.state, loc, self.bus, walking=True)
                self._last_spot = loc
            return StepResult(entered=loc)
        return StepResult(action=action)


    def _wreck(self, action: tuple) -> StepResult:
        from game import destruction, fire
        what = action[0]
        x, y = int(action[1]), int(action[2])
        if what == "smash_prompt":
            return StepResult(prompt=destruction.prompt(self, x, y))
        if what == "smash":
            out = destruction.smash(self, x, y, int(action[3]) if len(action) > 3 else 1)
        elif what == "burn":
            out = fire.light(self, x, y)
        else:
            out = fire.douse(self, x, y, action[3] if len(action) > 3 else "")
        if self.bus is not None:
            for line in out.get("lines") or []:
                self.bus.emit("log", kind="damage" if out.get("broke") else "narration", text=line)
        fire.update(self)
        self.save()
        return StepResult(prompt=out.get("prompt"))


GRADE_WORDS = {"highway": "A paved highway, well kept and well watched. ",
               "road": "A good road, fairly safe near the towns. ",
               "track": "A rough track, little watched: keep your eyes open. "}
ROAD_FLOORS = {"cobble": "highway", "path": "road", "wood": "road", "track": "track", "ford": "track"}


def hides(e) -> bool:
    """Does this kind of creature lie in wait out of sight (until you're on top of it)?"""
    tags = " ".join(str(t).lower() for t in (e.tags or []))
    if "ambush" in tags or "hidden" in tags or e.fields.get("hides"):
        return True
    text = " ".join(str(f).lower() for f in e.fields.get("features") or [])
    return any(h.replace(" ", "-") in text for h in HIDERS)


def face_of(world, members: list[dict]) -> dict | None:
    """The party's face: whoever has the best Charisma."""
    from game import condition
    best, score = None, -99
    for m in members:
        if m.get("dead"):
            continue
        try:
            c = condition.combatant(world, m)
            v = int(c.stats.get("cha", 10))
        except Exception:  # noqa: BLE001 - an odd member still walks
            v = 10
        if v > score:
            best, score = m, v
    return best


FACING_TURNS = {"S": 0, "W": 1, "N": 2, "E": 3, "SW": 1, "NW": 1, "SE": 3, "NE": 3}   # quarter turns clockwise


def turns(facing: str) -> int:
    """How far a south-facing sprite turns to face this way (0 south, 1 west, 2 north, 3 east)."""
    return FACING_TURNS.get(facing or "S", 0)


__all__ = ["Explorer", "turns", "Token", "Prompt", "StepResult", "face_of", "hides", "DIRS"]
