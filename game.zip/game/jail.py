"""Jails (Hotfix 16): the cells a wanted party is locked in when it goes quietly. Towns, Cities and Capitals have
a jail (game/settlements.py); a village's or hamlet's watch carts you off to the nearest town that has one, and
the hours on the road pass. (Only in a world with no jails at all does the old way still happen: game/law.py
go_to_jail, the days pass and you walk out.)

Going in:
    Your gear goes in the Evidence Box: everything every character carries and wears, the party pack and the
    purse (cursed things that have bound themselves on stay where they are). You're put in a cell (game/rooms.py
    jail_rows: a row of cells off the cell block, the guardroom at the front, the evidence room beside it).
    The sentence is the bounty's (game/law.py jail_days: a day for every 50 gp, at most 60).
    Bad enough crimes (a murder, robbing a bank, or a bounty of EXECUTION_GP or more) put you up for
    execution instead: you hang at dawn, EXECUTION_DAYS days on. Waiting won't save you then.

Getting out:
    Wait it out    the cot in your cell: the days pass and you're let out (not when you're to hang).
    Work it off    call the guard at the cell door: a shift of hard labour (SHIFT_HOURS hours) takes a day
                   off the sentence, two with a good Athletics check (not when you're to hang).
    Bribe a guard  at the cell door, a Persuasion check; the guard helps himself to your confiscated purse
                   (a third of your bounty: BRIBE_SHARE). A refusal costs a day, and he won't hear it again
                   until tomorrow. Sparing a neck is a harder sell (BRIBE_HANGING_DC).
    Pick the lock  of the cell door (Thieves' Tools, with whatever's to hand; DC CELL_DC), then get out past
                   the guardroom unseen (your Stealth, rolled as the door opens, against the watch: SEEN_DC by
                   day, a little less at night). Seen, you go back (EXTRA_DAYS more) or fight your way out.
                   Out of the building, you're free but wanted for the jailbreak on top of it all, and your
                   things stay in the evidence room unless you took them on the way (its chest).
    Break out      the destruction stage, to come.
Served, worked off or bribed: you're let out at the jail's door with everything in the Evidence Box, less
anything stolen (that's gone for good) and the bribe.

The jail's wards: no spell can be cast inside it, by anyone, in a fight or out of one (antimagic).

Kept in the save (state.law): "jail" {"key" (the realm), "bid" (the jail), "town", "cell" (its room's location),
"since", "release" (the minute you're let out; 0 when you're to hang), "execute" (the minute you hang, or 0), "bounty"
(gp, when you went in: the bribe is a share of it),
"sneak" (once out of the cell), "bribe_tried"}; "evidence" {jail id: {"copper", "pack": {item: n}, "members":
{member id: {"inventory", "equipment", "attuned"}}}}.
"""
from __future__ import annotations

import random

from game import law, places

CELL_DC = 18
SHIFT_HOURS = 8
EXECUTION_GP = 2000
EXECUTION_DAYS = 3
CAPITAL_CRIMES = ("murder", "bank robbery")
BRIBE_SHARE = 1 / 3            # of the bounty
BRIBE_DC = 12
BRIBE_HANGING_DC = 18
SEEN_DC = 14                    # the watch in the guardroom, by day (two less at night)
CLUB_ID = "item.makeshift-club"
CELL_DOOR = {"material": "iron", "ac": 19, "hp": 27, "threshold": 0}    # iron-bound, with a grille (destruction)
NOISE_DC = 12                   # each minute of smashing: the party's Stealth (rolled) against this, or the guard
                                # comes (one less if it's only the cot: it's quick)
EXTRA_DAYS = 3                  # caught getting out
JAIL_TIERS = ("Town", "City", "Capital")
JAILBREAK_GP = 200


# ----------------------------------------------------------------------------------------------------
# Where and whether
# ----------------------------------------------------------------------------------------------------
def record(state) -> dict | None:
    return (state.law or {}).get("jail") or None


def jailed(state) -> bool:
    return record(state) is not None


def jail_in(world, town):
    """The town's jail building, if it's big enough to have one."""
    if town is None:
        return None
    from game import settlements as ST
    if ST.tier_of(town) not in JAIL_TIERS:
        return None
    return next((b for b in places.buildings_in(world, town) if (b.fields.get("kind") or "") == "Jail"), None)


def jail_for(world, town) -> tuple:
    """(jail building, miles to it): the town's own, else the nearest town's that has one; (None, 0) if no
    town anywhere has a jail."""
    b = jail_in(world, town)
    if b is not None or town is None:
        return b, 0.0
    from game import geography as G
    here = G.town_position(world, town)
    best = None
    for t in world.entities.all("town"):
        if t.id == town.id:
            continue
        jb = jail_in(world, t)
        if jb is None:
            continue
        there = G.town_position(world, t)
        d = G.distance(here, there) if here is not None and there is not None else 10 ** 6
        if best is None or d < best[1]:
            best = (jb, d)
    return best if best is not None else (None, 0.0)


def is_jail(b) -> bool:
    return b is not None and (b.fields.get("kind") or "") == "Jail"


def antimagic(world, state) -> bool:
    """Inside a jail, the wards smother every spell."""
    if state is None:
        return False
    spot = places.current(world, state)
    return spot.kind == "building" and is_jail(spot.building)


def capital(world, state, key: str) -> bool:
    """Up for execution: a murder or a robbed bank still standing in the realm, or a bounty big enough."""
    standing = [c for c in law.data(state)["crimes"] if c.get("realm") == key and law.counts(state, c)]
    return any(c["kind"] in CAPITAL_CRIMES for c in standing) or law.bounty(world, state, key) >= EXECUTION_GP


def cells(world, b) -> list[str]:
    from game import rooms as R
    rows = R.building_rows(world, b)
    return [places.room_id(b.id, r["name"]) for r in rows if r.get("tile") == "Cell"]


def evidence(state) -> dict:
    return law.data(state).setdefault("evidence", {})


def _dawn_after(minutes: int, days: int) -> int:
    day0 = minutes - minutes % 1440
    return day0 + days * 1440 + 6 * 60


def days_left(state) -> float:
    rec = record(state)
    if not rec or not rec.get("release"):
        return 0.0
    return max(0.0, (int(rec["release"]) - state.minutes) / 1440)


def status_text(state) -> str:
    rec = record(state)
    if not rec:
        return ""
    if rec.get("execute"):
        left = (int(rec["execute"]) - state.minutes) / 60
        when = f"in {left:.0f} hours" if left < 30 else f"in {left / 24:.1f} days"
        return f"You hang at dawn, {when}."
    d = days_left(state)
    if d <= 0:
        return "Your time is served."
    return f"{d:.1f} days of your sentence left." if d < 10 else f"{d:.0f} days of your sentence left."


def _bribe_gp(state) -> int:
    """A third of the bounty the party went in with."""
    rec = record(state) or {}
    gp = rec.get("bounty")
    if gp is None:                                       # (locked up before the bribe followed the bounty)
        gp = EXECUTION_GP if rec.get("execute") else law.JAIL_GP_PER_DAY * max(1.0, days_left(state))
    return max(1, int(round(float(gp) * BRIBE_SHARE)))


def _purse(state) -> int:
    rec = record(state) or {}
    return int((evidence(state).get(rec.get("bid") or "") or {}).get("copper") or 0)


# ----------------------------------------------------------------------------------------------------
# The Evidence Box
# ----------------------------------------------------------------------------------------------------
def _strip(world, state, members: list[dict], bid: str) -> dict:
    """Everything the party has goes in the box (added to anything already there from an earlier visit)."""
    from game import party as P
    box = evidence(state).setdefault(bid, {"copper": 0, "pack": {}, "members": {}})
    box["copper"] = int(box.get("copper") or 0) + int(state.copper)
    state.copper = 0
    pack = box.setdefault("pack", {})
    for iid, n in list(state.inventory.items()):
        pack[iid] = int(pack.get(iid, 0)) + int(n)
        state.inventory.pop(iid, None)
    held = box.setdefault("members", {})
    for m in members:
        bound = set(m.get("bound") or [])
        keep = {i: n for i, n in (m.get("inventory") or {}).items() if i in bound}
        took = {i: n for i, n in (m.get("inventory") or {}).items() if i not in bound}
        mine = held.setdefault(m["id"], {"inventory": {}, "equipment": {}, "attuned": []})
        for i, n in took.items():
            mine["inventory"][i] = int(mine["inventory"].get(i, 0)) + int(n)
        mine["equipment"].update({s: i for s, i in (m.get("equipment") or {}).items() if i not in bound})
        mine["attuned"] = list(dict.fromkeys(list(mine.get("attuned") or []) +
                                             [i for i in (m.get("attuned") or []) if i not in bound]))
        m["inventory"] = keep
        m["equipment"] = {s: i for s, i in (m.get("equipment") or {}).items() if i in bound}
        m["attuned"] = [i for i in (m.get("attuned") or []) if i in bound]
    P.save(world, members)
    state.save()
    return box


def give_back(world, state, members: list[dict], bid: str) -> int:
    """Hand the box back: everything but what was stolen (gone for good). Returns how many stolen things
    were kept."""
    from game import party as P
    box = evidence(state).pop(bid, None)
    if not box:
        return 0
    lost = 0
    state.copper += int(box.get("copper") or 0)
    for iid, n in (box.get("pack") or {}).items():
        if law.is_stolen(iid):
            lost += int(n)
            continue
        state.inventory[iid] = state.count(iid) + int(n)
    by_id = {m["id"]: m for m in members}
    for mid, got in (box.get("members") or {}).items():
        m = by_id.get(mid)
        inv = {i: n for i, n in (got.get("inventory") or {}).items() if not law.is_stolen(i)}
        lost += sum(int(n) for i, n in (got.get("inventory") or {}).items() if law.is_stolen(i))
        if m is None or m.get("dead"):                  # gone from the party: their things go in the pack
            for i, n in inv.items():
                state.inventory[i] = state.count(i) + int(n)
            continue
        mine = dict(m.get("inventory") or {})
        for i, n in inv.items():
            mine[i] = int(mine.get(i, 0)) + int(n)
        m["inventory"] = mine
        eq = dict(m.get("equipment") or {})
        for slot, i in (got.get("equipment") or {}).items():
            if not law.is_stolen(i) and slot not in eq:
                eq[slot] = i
        m["equipment"] = eq
        m["attuned"] = list(dict.fromkeys(list(m.get("attuned") or []) +
                                          [i for i in (got.get("attuned") or []) if not law.is_stolen(i)]))
    P.save(world, members)
    state.save()
    return lost


# ----------------------------------------------------------------------------------------------------
# In and out
# ----------------------------------------------------------------------------------------------------
def imprison(world, state, members: list[dict], key: str, explorer=None, bus=None, extra_days: int = 0) -> dict:
    """Lock the party up: in this town's jail, or (a village, a hamlet) the nearest town's, carted there by the
    watch. {"ok": False} only when no town anywhere has a jail (the old way, then)."""
    here = places.current(world, state).town
    b, miles = jail_for(world, here)
    if b is None:
        return {"ok": False}
    rooms = cells(world, b)
    if not rooms:
        return {"ok": False}
    town = world.entities.get(b.fields.get("town"))
    gp = law.bounty(world, state, key)
    hang = capital(world, state, key)
    days = law.jail_days(gp) + max(0, int(extra_days))
    _strip(world, state, members, b.id)
    road = ""
    if town is not None and here is not None and town.id != here.id:      # the watch carts you there
        from game import geography as G
        hours = max(1, int(round(miles / G.mph(world))))
        state.journey = None
        state.advance(hours * 60, "taken to jail")
        road = (f"{here.name} has no jail. The watch puts you in irons and carts you to {town.name}, "
                f"{hours} hour{'s' if hours != 1 else ''} on the road. ")
    cell = rooms[state.day % len(rooms)]
    law.data(state)["jail"] = {"key": key, "bid": b.id, "town": town.id if town else "", "cell": cell,
                               "since": state.minutes, "bounty": gp,
                               "release": 0 if hang else state.minutes + days * 1440,
                               "execute": _dawn_after(state.minutes, EXECUTION_DAYS) if hang else 0}
    state.save()
    _to_cell(world, state, explorer, bus)
    if bus is not None:
        bus.emit("jail.entered", jail=b.id, hang=hang)
    if hang:
        text = (f"The watch strips you of everything and throws you in a cell in {b.name}. For what you've done "
                f"you're to hang: at dawn, {EXECUTION_DAYS} days from now. Get out before then, or don't.")
    else:
        text = (f"The watch strips you of everything (it goes in the evidence box) and locks you in a cell in "
                f"{b.name}: {days} day{'s' if days != 1 else ''}. Lie down on the cot to wait it out, or call "
                "the guard at the door.")
    return {"ok": True, "text": road + text, "hang": hang, "days": days, "carted": bool(road)}


def _to_cell(world, state, explorer, bus) -> None:
    rec = record(state)
    places.enter(world, state, rec["cell"], bus)
    if explorer is None:
        return
    explorer.sync()
    put_in_room(explorer, rec["cell"])
    lv, door = cell_door(explorer)
    if door is not None:
        explorer.set_door(lv.key, door, "locked")
    explorer.look()
    explorer.remember_pos()
    explorer.save()


def put_in_room(explorer, loc: str) -> bool:
    """Stand the party in a cell: on the free square furthest in from its door."""
    a = explorer.area
    if a is None:
        return False
    for lv in a.all_levels():
        door = next((c for c, d in lv.doors.items() if d.get("cell") and d.get("room") == loc), None)
        if door is None:
            continue
        seen, todo, best = {door}, [door], None
        while todo:
            x, y = todo.pop(0)
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                c = (x + dx, y + dy)
                if c in seen or explorer.loc_at(lv, *c) != loc or lv.blocks(*c) or c in lv.doors:
                    continue
                seen.add(c)
                todo.append(c)
                if explorer.token_at(*c) is None:
                    best = c                                   # (the last one found is the furthest in)
        if best is not None:
            explorer.level, explorer.x, explorer.y = _level_key(a, lv), best[0], best[1]
            explorer.facing = "S"
            return True
    return False


def _level_key(a, lv) -> str:
    """The key the walking map keeps for a level (a town laid into the open world is a piece of its base)."""
    return lv.key if lv.key in a.levels else a.base_key


def cell_door(explorer):
    """(level, square) of the party's cell door, or (None, None)."""
    rec = record(explorer.state)
    if not rec or explorer.area is None:
        return None, None
    for lv in explorer.area.all_levels():
        for c, d in lv.doors.items():
            if d.get("cell") and d.get("room") == rec["cell"]:
                return lv, c
    return None, None


def release(world, state, members: list[dict], explorer=None, bus=None, how: str = "served") -> str:
    """Let the party out at the jail's door, with its things back."""
    rec = record(state)
    if not rec:
        return ""
    bid = rec["bid"]
    law.settle(world, state, rec["key"], how, bus)
    lost = give_back(world, state, members, bid)
    law.data(state).pop("jail", None)
    state.save()
    outside(world, state, explorer, bid, bus)
    if bus is not None:
        bus.emit("jail.released", how=how)
        bus.emit("party.changed")
    text = {"served": "Your time is served. A guard unlocks the cell",
            "worked": "The last of your sentence is worked off. A guard unlocks the cell",
            "bribed": "The guard pockets the coin, unlocks the cell and looks the other way"}.get(how, "You're let out")
    text += " and hands back your things from the evidence box"
    text += f", all but the stolen goods ({lost}), which the watch keeps." if lost else "."
    return text + " You're outside the jail, free."


def outside(world, state, explorer, bid: str, bus=None) -> None:
    """Just outside the building's street door."""
    b = world.entities.get(bid)
    town = world.entities.get(b.fields.get("town")) if b is not None else None
    if town is None:
        return
    places.enter(world, state, places.street_id(town.id, places.street_of_building(world, b)), bus)
    if explorer is None:
        return
    explorer.sync()
    a = explorer.area
    info = a.buildings.get(bid) if a is not None else None
    if not info or not info.get("door"):
        return
    from game.area import SIDES
    dx, dy = info["door"]
    sx, sy = SIDES.get(info.get("facing") or "S", (0, 1))
    base = a.layer(a.base_key, dx + sx, dy + sy)
    explorer.level, explorer.x, explorer.y = _level_key(a, base), dx + sx, dy + sy
    explorer.facing = info.get("facing") or "S"
    explorer._unstick()
    explorer.look()
    explorer.remember_pos()
    explorer.save()


def escaped(world, state, bus=None) -> str:
    """Out of the building without leave: free, and wanted for the jailbreak as well."""
    rec = record(state)
    if not rec:
        return ""
    town = world.entities.get(rec.get("town") or "")
    law.data(state).pop("jail", None)
    law.commit(world, state, "jailbreak", town, [law.CROWD], 0, "", None)
    state.save()
    if bus is not None:
        bus.emit("jail.escaped")
    left = "" if not evidence(state).get(rec["bid"]) else " Your things are still in the jail's evidence room."
    return ("You slip out into the street. You're free, and wanted for breaking out on top of everything else "
            f"(+{JAILBREAK_GP} gp on your head).{left}")


def due(state) -> str:
    """'hang' when the hour has come and the party's still in its cell; 'free' when the sentence has run out
    (time passed some other way than on the cot) and it's still in."""
    rec = record(state)
    if rec and rec.get("execute") and state.minutes >= int(rec["execute"]):
        return "hang"
    if rec and rec.get("release") and state.minutes >= int(rec["release"]) and "sneak" not in rec:
        return "free"
    return ""


def execute(world, state, members: list[dict], bus=None) -> str:
    """The end."""
    from game import party as P
    rec = record(state) or {}
    b = world.entities.get(rec.get("bid") or "")
    for m in members:
        m["dead"] = True
    P.save(world, members)
    law.data(state).pop("jail", None)
    state.save()
    if bus is not None:
        bus.emit("jail.executed")
    town = world.entities.get(rec.get("town") or "")
    return (f"Dawn. The guards come for you, and the people of {town.name if town else 'the town'} gather to watch "
            f"you hang outside {b.name if b else 'the jail'}.")


def recaptured(world, state, members: list[dict], explorer=None, bus=None) -> str:
    """Beaten by the jailers while getting out: back in the cell, with more time to serve."""
    from game import condition
    rec = record(state)
    if not rec:
        return ""
    for m in members:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        condition.apply(state, m, c)
        c.hp = max(1, c.hp)
        condition.store(state, m, c, save=False)
    _back(state)
    _to_cell(world, state, explorer, bus)
    return "The guards beat you down and drag you back to your cell. " + _added_text(state)


def _back(state) -> None:
    rec = record(state)
    rec.pop("sneak", None)
    if rec.get("release"):
        rec["release"] = max(int(rec["release"]), state.minutes) + EXTRA_DAYS * 1440
    state.save()


def _added_text(state) -> str:
    rec = record(state) or {}
    return "Your hanging is still set for dawn." if rec.get("execute") else \
        f"{EXTRA_DAYS} more days on your sentence. {status_text(state)}"


# ----------------------------------------------------------------------------------------------------
# On the walking map (game/explore.py asks)
# ----------------------------------------------------------------------------------------------------
def door_prompt(explorer, lv, c):
    """The cell door from inside: call the guard (work, a bribe), or pick the lock."""
    from game.explore import Prompt
    from game.state import money_text
    state = explorer.state
    rec = record(state)
    hang = bool(rec.get("execute"))
    opts = []
    if not hang:
        opts.append((f"Work off your sentence ({SHIFT_HOURS} hours' labour)", ("jail", "work"), True))
    gp = _bribe_gp(state)
    tried = state.minutes - int(rec.get("bribe_tried", -10 ** 9)) < 1440
    enough = _purse(state) >= gp * 100
    note = " (he won't hear it again today)" if tried else "" if enough else " (your purse won't cover it)"
    opts.append((f"Bribe the guard ({money_text(gp * 100)} from your purse){note}", ("jail", "bribe"),
                 enough and not tried))
    pick = explorer.best_member(["skill.thieves-tools"], "dex")
    if pick:
        m, _c, o, b = pick
        key = f"{lv.key}:{c[0]},{c[1]}"
        opts.append((f"Pick the lock: {m.get('name')} ({b:+d} vs DC {CELL_DC})", ("pick", key, CELL_DC), True))
    left = _door_left(state, lv, c)
    who = _smasher(explorer)
    if who is not None:
        m, a = who
        opts.append((f"Smash the door: {m.get('name')} with {a.name.lower()} ({left}/{CELL_DOOR['hp']} left; loud)",
                     ("jail", "smash", f"{lv.key}:{c[0]},{c[1]}"), True))
    opts.append(("Leave it", ("none",), True))
    text = status_text(state) + " The door is iron-bound, with a grille. A guard will come if you call: to set " \
        "you to work, or to hear an offer, paid from the purse they took off you. Or there's a bent nail in the " \
        "straw that might do for a pick. Cut round the frame are the wards that smother any spell in this place."
    return Prompt("The cell door", text, opts)


def bed_prompt(explorer):
    from game.explore import Prompt
    state = explorer.state
    rec = record(state)
    if rec.get("execute"):
        club = [] if rec.get("cot_broken") else [("Break the cot for a makeshift club (it'll make a noise)",
                                                  ("jail", "club"), True)]
        return Prompt("A straw cot", status_text(state) + " Lying here waiting is how it ends.",
                      club + [("Rest a while (short rest)", ("activity", "rest:short"), True),
                              ("Never mind", ("none",), True)])
    d = days_left(state)
    club = [] if rec.get("cot_broken") else [("Break the cot for a makeshift club (it'll make a noise)",
                                              ("jail", "club"), True)]
    return Prompt("A straw cot", status_text(state),
                  [(f"Wait out your sentence ({d:.1f} days)" if d < 10 else f"Wait out your sentence ({d:.0f} days)",
                    ("jail", "wait"), True)] + club +
                  [("Rest a while (short rest)", ("activity", "rest:short"), True), ("Never mind", ("none",), True)])


def evidence_prompt(explorer, bid: str):
    from game.explore import Prompt
    from game.state import money_text
    box = evidence(explorer.state).get(bid)
    if not box:
        return Prompt("The evidence box", "Bundles of other people's confiscated things, tagged with names.",
                      [("Leave it", ("none",), True)])
    n = sum(int(v) for v in (box.get("pack") or {}).values()) + sum(
        sum(int(v) for v in (m.get("inventory") or {}).values()) for m in (box.get("members") or {}).values())
    return Prompt("The evidence box", f"Your things, tagged with your names: {n} item{'s' if n != 1 else ''} and "
                                      f"{money_text(int(box.get('copper') or 0))}.",
                  [("Take back your things", ("jail", "evidence", bid), True), ("Leave them", ("none",), True)])


def cell_opened(explorer) -> str:
    """The cell door's open: now to get past the guardroom unseen (one Stealth roll, kept)."""
    rec = record(explorer.state)
    if rec is None:
        return ""
    rec["sneak"] = law.sneak_roll(explorer.world, explorer.members(), explorer.rng, explorer.bus)
    explorer.state.save()
    return "The lock gives. Now, quietly, past the guardroom and out."


def on_move(explorer, loc: str):
    """After the party steps into somewhere new: out of the jail (escaped), or into the guardroom (seen?).
    Returns (message, prompt)."""
    from game.explore import Prompt
    state, world = explorer.state, explorer.world
    rec = record(state)
    if rec is None:
        return "", None
    spot = places.parse(world, loc)
    inside = spot.kind == "building" and spot.building is not None and spot.building.id == rec["bid"]
    if not inside:
        return escaped(world, state, explorer.bus), None
    if loc == rec["cell"]:
        return "", None
    if spot.id == rec["bid"]:                            # the guardroom (the entrance: the building itself)
        if "sneak" not in rec:                            # out of the cell without opening the door (somehow)
            rec["sneak"] = law.sneak_roll(world, explorer.members(), explorer.rng, explorer.bus)
        dc = SEEN_DC - (2 if state.time_of_day in ("Night", "Dusk") else 0)
        if int(rec["sneak"]) < dc:
            cost = "your hanging stands" if rec.get("execute") else f"{EXTRA_DAYS} more days"
            return "", Prompt("Seen!", "\"Oi! How did you get out?\" The guard on watch is on his feet, reaching for "
                                       "a cudgel.",
                              [(f"Go back to your cell quietly ({cost})", ("jail", "caught", "back"), True),
                               ("Fight your way out", ("jail", "caught", "fight"), True)])
    return "", None


def opened_in_jail(explorer, lv, c) -> bool:
    """Is this the party's own cell door, picked from inside?"""
    rec = record(explorer.state)
    d = lv.doors.get(c) or {}
    return bool(rec and d.get("cell") and d.get("room") == rec.get("cell"))


# ----------------------------------------------------------------------------------------------------
# What a choice does (the app and the browser version both call this)
# ----------------------------------------------------------------------------------------------------
def act(world, state, members: list[dict], explorer, action: tuple, rng=None, bus=None) -> dict:
    """Carry out ("jail", what, ...). Returns {"text", "kind" (for the log), "skip" (a title, when time passes
    off-screen), "fight" (enemy rows: fight your way out), "released"}."""
    from game import checks, condition
    rng = rng or random.Random()
    what = action[1] if len(action) > 1 else ""
    rec = record(state)
    if what == "evidence":
        bid = action[2] if len(action) > 2 else ""
        if not evidence(state).get(bid):
            return {"text": "There's nothing of yours here."}
        lost = give_back(world, state, members, bid)
        if bus is not None:
            bus.emit("party.changed")
        return {"text": "You take back your things" + (f" (not the stolen goods: {lost})" if lost else "") + ".",
                "kind": "loot"}
    if rec is None:
        return {"text": ""}
    if what == "wait":
        if rec.get("execute"):
            return {"text": "Waiting is how this ends."}
        state.advance(max(0, int(rec["release"]) - state.minutes), "in jail")
        return {"text": release(world, state, members, explorer, bus, "served"), "kind": "narration",
                "skip": "In the cells", "released": True}
    if what == "work":
        if rec.get("execute"):
            return {"text": "\"Work? You'll be working a rope.\""}
        opt = next((o for o in checks.options(world) if o["label"] == "Athletics"), None)
        best = max((m for m in members if not m.get("dead")), default=None,
                   key=lambda m: checks.bonus(world, m, condition.combatant(world, m), opt)[0] if opt else 0)
        good = False
        if best is not None and opt is not None:
            r = checks.roll(world, best, condition.combatant(world, best), opt, 12, rng=rng, bus=bus,
                            target="hard labour")
            good = bool(r.get("success"))
        state.advance(SHIFT_HOURS * 60, "hard labour")
        off = 2 if good else 1
        rec["release"] = int(rec["release"]) - off * 1440
        state.save()
        if state.minutes >= int(rec["release"]):
            return {"text": release(world, state, members, explorer, bus, "worked"), "kind": "narration",
                    "skip": "Hard labour", "released": True}
        if explorer is not None:
            _to_cell(world, state, explorer, bus)
        return {"text": f"A long shift breaking stone in the yard{' (and you put your back into it)' if good else ''}: "
                        f"{off} day{'s' if off != 1 else ''} off your sentence. {status_text(state)}",
                "kind": "narration", "skip": "Hard labour"}
    if what == "bribe":
        gp = _bribe_gp(state)
        if _purse(state) < gp * 100:
            return {"text": "Your confiscated purse won't cover it."}
        opt = next((o for o in checks.options(world) if o["label"] == "Persuasion"), None)
        best = max((m for m in members if not m.get("dead")), default=None,
                   key=lambda m: checks.bonus(world, m, condition.combatant(world, m), opt)[0] if opt else 0)
        dc = BRIBE_HANGING_DC if rec.get("execute") else BRIBE_DC
        ok = False
        if best is not None and opt is not None:
            r = checks.roll(world, best, condition.combatant(world, best), opt, dc, rng=rng, bus=bus,
                            target="a bribe")
            ok = bool(r.get("success"))
        if not ok:
            rec["bribe_tried"] = state.minutes
            if rec.get("release"):
                rec["release"] = int(rec["release"]) + 1440
            state.save()
            return {"text": "The guard spits through the grille. \"Try that again and you'll be here longer.\" "
                            + ("" if rec.get("execute") else "A day more on your sentence."), "kind": "system"}
        box = evidence(state).get(rec["bid"]) or {}
        box["copper"] = int(box.get("copper") or 0) - gp * 100
        return {"text": release(world, state, members, explorer, bus, "bribed"), "kind": "narration",
                "released": True}
    if what == "club":
        return _break_cot(world, state, members, explorer, rng, bus)
    if what == "smash":
        return _smash_door(world, state, members, explorer, action[2] if len(action) > 2 else "", rng, bus)
    if what == "caught":
        how = action[2] if len(action) > 2 else "back"
        if how == "fight":
            town = world.entities.get(rec.get("town") or "")
            return {"text": "You go for the guard before he can shout.",
                    "fight": law.guards_for(world, town, 2), "kind": "system"}
        _back(state)
        _to_cell(world, state, explorer, bus)
        return {"text": "You're marched back to your cell. " + _added_text(state), "kind": "system"}
    return {"text": ""}


# ----------------------------------------------------------------------------------------------------
# Breaking out (Hotfix 23): bare fists, or a leg off the cot, against the cell door
# ----------------------------------------------------------------------------------------------------
def club(world):
    """The makeshift club: a leg of the cot (made the first time it's wanted, in the playthrough's overlay)."""
    e = world.entities.get(CLUB_ID)
    if e is not None:
        return e
    return world.entities.create("item", "Makeshift Club", {
        "category": "Weapon", "damage": "1d4", "damage_type": "bludgeoning", "properties": ["light"],
        "slot": "Main hand", "value": 0, "rarity": "Common", "stackable": False, "sprite": "weapon/club"},
        "A leg wrenched off a jail cot. It'll do.", ["weapon", "wood"], entity_id=CLUB_ID, overlay=True)


def _heard(world, state, members, explorer, rng, bus, dc: int) -> bool:
    """A noise in the cells: does the guard come? (the party's Stealth, rolled, against dc)."""
    s = law.sneak_roll(world, members, rng, bus)
    return s < dc


def _caught_at_it(state, explorer, bus, what: str) -> dict:
    """The guard heard: the club's taken off you, and it's more days (or your hanging stands)."""
    from game import inventory as INV
    rec = record(state)
    for m in (explorer.members() if explorer is not None else []):
        if INV.count(m, CLUB_ID):
            INV.remove(m, CLUB_ID, INV.count(m, CLUB_ID))
    rec.pop("door_dmg", None)
    _back(state)
    return {"text": f"Boots in the passage. 'What's all this?' The guard {what}, and takes the club. "
                    + _added_text(state), "kind": "system"}


def _break_cot(world, state, members, explorer, rng, bus) -> dict:
    from game import inventory as INV
    from game import party as P
    rec = record(state)
    if rec.get("cot_broken"):
        return {"text": "There's nothing left of the cot to break."}
    m = next((x for x in members if not x.get("dead")), None)
    if m is None:
        return {"text": ""}
    rec["cot_broken"] = True
    state.advance(1, "breaking the cot")
    if _heard(world, state, members, explorer, rng, bus, NOISE_DC - 1):
        return _caught_at_it(state, explorer, bus, "finds the cot in pieces")
    c = club(world)
    INV.add(m, c.id, 1)
    INV.equip(world, m, c.id)
    P.save(world, members)
    state.save()
    return {"text": f"Wood splinters. {m.get('name')} wrenches a leg off the cot: a makeshift club "
                    "(1d4 bludgeoning).", "kind": "loot"}


def _door_left(state, lv, c) -> int:
    rec = record(state) or {}
    return max(0, CELL_DOOR["hp"] - int((rec.get("door_dmg") or {}).get(f"{lv.key}:{c[0]},{c[1]}", 0)))


def _smasher(explorer):
    """Who hits the door best, and with what (fists, or the club)."""
    from game import destruction as D
    t = dict(CELL_DOOR, label="cell door")
    best = None
    for m in explorer.members():
        if m.get("dead"):
            continue
        got = D.best_blow(explorer.world, explorer.state, m, t)
        if got is not None and (best is None or got[1] > best[2]):
            best = (m, got[0], got[1])
    return (best[0], best[1]) if best is not None else None


def _smash_door(world, state, members, explorer, key: str, rng, bus) -> dict:
    """A minute of battering the cell door. Loud: the guard may come."""
    from game import destruction as D
    rec = record(state)
    if not key or explorer is None:
        return {"text": ""}
    lk, xy = key.rsplit(":", 1)
    cx, cy = (int(v) for v in xy.split(","))
    t = dict(CELL_DOOR, label="cell door")
    who = _smasher(explorer)
    if who is None:
        return {"text": "Nothing you have will make a mark on it."}
    m, a = who
    done = 0
    for _r in range(D.ROUNDS_A_MINUTE):
        hit, dmg, _d = D._swing(t, a, rng)
        done += dmg
    state.advance(1, "smashing the door")
    dmgs = rec.setdefault("door_dmg", {})
    dmgs[key] = int(dmgs.get(key, 0)) + done
    left = max(0, CELL_DOOR["hp"] - dmgs[key])
    if _heard(world, state, members, explorer, rng, bus, NOISE_DC):
        return _caught_at_it(state, explorer, bus, "finds the door half off its hinges")
    if left <= 0:
        dmgs.pop(key, None)
        explorer.set_door(lk, (cx, cy), "broken")
        explorer.look()
        explorer.save()
        cell_opened(explorer)
        state.save()
        return {"text": f"{m.get('name')} smashes the cell door off its hinges. Now, quickly and quietly, out.",
                "kind": "loot"}
    state.save()
    return {"text": f"{m.get('name')} batters the door with {a.name.lower()} ({done} damage, {left}/"
                    f"{CELL_DOOR['hp']} left). Nobody's come. Yet.", "kind": "narration"}


__all__ = ["record", "jailed", "jail_in", "antimagic", "capital", "imprison", "release", "escaped", "due", "execute",
           "recaptured", "act", "door_prompt", "bed_prompt", "evidence_prompt", "cell_opened", "on_move",
           "give_back", "status_text", "days_left", "CELL_DC"]
