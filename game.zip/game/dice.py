"""Dice expressions like "2d6+3", "1d20 - 1", "d8", "4d6 + 1d4 + 2".

    parse("2d6+3")             -> DiceExpr
    roll("2d6+3", rng)         -> Roll(total=11, detail="2d6 (4, 4) + 3")
    is_valid("2d+")            -> False
    average("2d6+3")           -> 10.0
"""
from __future__ import annotations

import random
import re
from dataclasses import dataclass

_TERM = re.compile(r"\s*([+-])?\s*(?:(\d*)\s*[dD]\s*(\d+)|(\d+))\s*")


class DiceError(ValueError):
    pass


@dataclass(frozen=True)
class Term:
    sign: int        # +1 or -1
    count: int       # number of dice, 0 for a flat number
    sides: int       # die size, 0 for a flat number
    flat: int = 0

    @property
    def is_dice(self) -> bool:
        return self.sides > 0


@dataclass(frozen=True)
class DiceExpr:
    terms: tuple[Term, ...]
    text: str

    def average(self) -> float:
        total = 0.0
        for t in self.terms:
            total += t.sign * (t.count * (t.sides + 1) / 2 if t.is_dice else t.flat)
        return total

    def minimum(self) -> int:
        return sum(t.sign * (t.count if t.is_dice else t.flat) if t.sign > 0
                   else t.sign * (t.count * t.sides if t.is_dice else t.flat) for t in self.terms)

    def maximum(self) -> int:
        return sum(t.sign * (t.count * t.sides if t.is_dice else t.flat) if t.sign > 0
                   else t.sign * (t.count if t.is_dice else t.flat) for t in self.terms)

    def doubled_dice(self) -> "DiceExpr":
        """Critical hit: roll the dice twice as many times, flat bonuses unchanged."""
        terms = tuple(Term(t.sign, t.count * 2, t.sides) if t.is_dice else t for t in self.terms)
        return DiceExpr(terms, _format(terms))


@dataclass(frozen=True)
class Roll:
    total: int
    detail: str
    rolls: tuple[int, ...]


def parse(text: str) -> DiceExpr:
    if text is None:
        raise DiceError("No dice given")
    source = str(text).strip()
    if not source:
        raise DiceError("No dice given")
    pos, terms = 0, []
    while pos < len(source):
        m = _TERM.match(source, pos)
        if not m or m.end() == pos:
            raise DiceError(f"Can't read '{source[pos:]}' in '{source}'")
        sign_txt, count_txt, sides_txt, flat_txt = m.groups()
        if terms and not sign_txt:
            raise DiceError(f"Missing + or - before '{m.group(0).strip()}'")
        sign = -1 if sign_txt == "-" else 1
        if sides_txt is not None:
            count = int(count_txt) if count_txt else 1
            sides = int(sides_txt)
            if count < 1 or count > 1000:
                raise DiceError("Number of dice must be between 1 and 1000")
            if sides < 1 or sides > 1000:
                raise DiceError("Dice must have between 1 and 1000 sides")
            terms.append(Term(sign, count, sides))
        else:
            terms.append(Term(sign, 0, 0, int(flat_txt)))
        pos = m.end()
    if not terms:
        raise DiceError("No dice given")
    return DiceExpr(tuple(terms), _format(tuple(terms)))


def is_valid(text: str) -> bool:
    try:
        parse(text)
        return True
    except DiceError:
        return False


def average(text: str) -> float:
    return parse(text).average()


def roll(expr, rng: random.Random | None = None) -> Roll:
    rng = rng or random
    if not isinstance(expr, DiceExpr):
        expr = parse(expr)
    total, parts, all_rolls = 0, [], []
    for i, t in enumerate(expr.terms):
        sign_txt = ("-" if t.sign < 0 else "+") if i else ("-" if t.sign < 0 else "")
        if t.is_dice:
            values = [rng.randint(1, t.sides) for _ in range(t.count)]
            all_rolls.extend(values)
            subtotal = sum(values)
            shown = ", ".join(str(v) for v in values)
            parts.append(f"{sign_txt} {t.count}d{t.sides} ({shown})".strip())
        else:
            subtotal = t.flat
            parts.append(f"{sign_txt} {t.flat}".strip())
        total += t.sign * subtotal
    return Roll(total, " ".join(parts), tuple(all_rolls))


def d20(rng: random.Random | None = None, mode: str = "normal") -> tuple[int, str]:
    """Roll a d20 with 'normal', 'advantage' or 'disadvantage'. Returns (kept, detail)."""
    rng = rng or random
    a = rng.randint(1, 20)
    if mode == "normal":
        return a, f"d20 ({a})"
    b = rng.randint(1, 20)
    kept = max(a, b) if mode == "advantage" else min(a, b)
    label = "adv" if mode == "advantage" else "dis"
    return kept, f"d20 {label} ({a}, {b})"


def _format(terms: tuple[Term, ...]) -> str:
    out = []
    for i, t in enumerate(terms):
        body = f"{t.count}d{t.sides}" if t.is_dice else str(t.flat)
        if i == 0:
            out.append(("-" if t.sign < 0 else "") + body)
        else:
            out.append(("- " if t.sign < 0 else "+ ") + body)
    return " ".join(out)
