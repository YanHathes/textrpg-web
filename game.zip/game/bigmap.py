"""The big map (step 20): the world and each of its continents as pictures, drawn once from the walking map
(game/mapimage.py) and kept in the world itself (bigmap.db), so the map opens at once instead of drawing
the whole world again.

What's kept never goes stale by itself: the land doesn't change. What can change is the towns: the party
founds a settlement (game/colony.py), it grows, it gets a road. refresh(world) looks for any town that's
new, gone or changed since the last time the map was opened, and draws again only the part of each picture
it covers (the town, and its roads to the next towns); everything else comes straight from the file.

Nothing here ever holds the game up. A picture not yet drawn (a world made on this machine, never opened)
is drawn a strip at a time by work(), as the map is looked at: the map shows what's done and keeps
answering. Close-up tiles of the walking map are kept here too once drawn (the most recently seen ones).

    open_map(world)            -> BigMap (kept on the world; World.close closes it)
    BigMap.names()             the pictures: "world", "continent:<id>"
    BigMap.pic(name)           -> Pic (its pixels, perhaps not all drawn yet: Pic.done)
    BigMap.work(seconds, want) draws more of the pictures named in want (then any), for about that long;
                               returns the changed parts [(name, x, y, w, h)]
    BigMap.finish(name)        draws all of one picture now (a loading screen does this)
    BigMap.refresh()           the town check above; returns the rectangles (miles) it redrew
    BigMap.tile(...)/put_tile  close-up tiles
    build_all(world)           every picture, all at once (tools/prebuild_world.py, for the phone app)
"""
from __future__ import annotations

import json
import shutil
import sqlite3
import time
import zlib
from dataclasses import dataclass, field

from game import geography as G

VERSION = 1
FILE = "bigmap.db"
WORLD_PX = 2048              # the whole world, at most this many pixels across
CONTINENT_PX = 1600          # each continent
TILES_KEPT = 600             # close-up tiles kept (the most recently seen)
TOWN_R = 2.0                 # miles round a town that redrawing it covers
SAVE_EVERY = 8.0             # seconds of drawing between saves of a picture being drawn


@dataclass
class Pic:
    name: str
    w: int
    h: int
    bounds: tuple            # (x0, y0, x1, y1) in miles
    stride: float            # walking-map squares to a pixel
    continent: str | None
    rgb: bytearray
    jobs: list = field(default_factory=list)      # parts still to draw: [x, y, w, h, rows done]
    dirty: bool = False

    @property
    def done(self) -> bool:
        return not self.jobs

    def fraction(self) -> float:
        left = sum(j[2] * (j[3] - j[4]) for j in self.jobs)
        return 1.0 - left / max(1, self.w * self.h)

    def to_qimage(self):
        from PySide6.QtGui import QImage
        return QImage(bytes(self.rgb), self.w, self.h, self.w * 3, QImage.Format.Format_RGB888).copy()

    def part(self, x: int, y: int, w: int, h: int) -> bytes:
        """The pixels of one rectangle of it, as RGB bytes."""
        row = self.w * 3
        return b"".join(bytes(self.rgb[(y + j) * row + x * 3:(y + j) * row + (x + w) * 3]) for j in range(h))


def _base_sig(world) -> str:
    """What the pictures are drawn from that never changes in play: the world's size and seed."""
    from game import mapimage as MI
    s = G.settings(world)
    return json.dumps([VERSION, MI.VERSION, round(s["width"], 1), round(s["height"], 1), s["seed"]])


def _fit(bounds, max_px: int) -> tuple[int, int, float]:
    from game import mapimage as MI
    from game import worldmap as WM
    x0, y0, x1, y1 = bounds
    wm, hm = max(1e-6, x1 - x0), max(1e-6, y1 - y0)
    if MI.np is None:
        max_px = min(max_px, 720)                       # square by square: a smaller picture
    stride = max(wm, hm) * WM.SQ / max_px
    return max(1, int(round(wm * WM.SQ / stride))), max(1, int(round(hm * WM.SQ / stride))), stride


def plan(world) -> dict:
    """name -> (bounds, max_px, continent) of every picture the world should have."""
    s = G.settings(world)
    out = {"world": ((0.0, 0.0, float(s["width"]), float(s["height"])), WORLD_PX, None)}
    for c in world.entities.all("continent"):
        b = G.continent_bounds(world, c)
        if b is None:
            continue
        b = (max(0.0, b[0]), max(0.0, b[1]), min(float(s["width"]), b[2]), min(float(s["height"]), b[3]))
        if b[2] > b[0] and b[3] > b[1]:
            out[f"continent:{c.id}"] = (b, CONTINENT_PX, c.id)
    return out


# ======================================================================
# The town check
# ======================================================================
def towns_now(world) -> dict:
    """id -> [signature, x0, y0, x1, y1]: each town as the big map draws it, and the miles it covers (the
    town and its roads). The party's own settlements are looked at closely (they grow); the world's own
    towns only by where they are and where their roads go."""
    pos = G.town_positions(world)
    out = {}
    for t in world.entities.all("town"):
        p = pos.get(t.id)
        if p is None:
            continue
        roads = sorted((r.get("leads_to") or "", r.get("grade") or "") for r in t.fields.get("roads") or [])
        x0, y0, x1, y1 = p[0] - TOWN_R, p[1] - TOWN_R, p[0] + TOWN_R, p[1] + TOWN_R
        for to, _grade in roads:                       # a road bends: room round its straight line
            q = pos.get(to)
            if q is None:
                continue
            pad = 1.0 + 0.15 * ((q[0] - p[0]) ** 2 + (q[1] - p[1]) ** 2) ** 0.5
            x0, y0 = min(x0, q[0] - pad, p[0] - pad), min(y0, q[1] - pad, p[1] - pad)
            x1, y1 = max(x1, q[0] + pad, p[0] + pad), max(y1, q[1] + pad, p[1] + pad)
        sig = [round(p[0], 3), round(p[1], 3), roads]
        if t.fields.get("settlement"):
            from game import area as A
            sig.append(A._town_sig(world, t))
        out[t.id] = [zlib.crc32(json.dumps(sig, default=str).encode()), round(x0, 3), round(y0, 3),
                     round(x1, 3), round(y1, 3)]
    return out


def changed_rects(old: dict, new: dict) -> list[tuple]:
    """The miles to draw again: where a town was and where it is now, for each one new, gone or changed."""
    rects = []
    for tid in set(old) | set(new):
        a, b = old.get(tid), new.get(tid)
        if a is not None and b is not None and a[0] == b[0]:
            continue
        for r in (a, b):
            if r is not None:
                rects.append(tuple(r[1:5]))
    return rects


# ======================================================================
# The store
# ======================================================================
class BigMap:
    def __init__(self, world) -> None:
        self.world = world
        self.path = world.path / FILE
        _from_bundle(world, self.path)
        self.db = sqlite3.connect(str(self.path))
        self.db.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)")
        self.db.execute("CREATE TABLE IF NOT EXISTS pic (name TEXT PRIMARY KEY, info TEXT, rgb BLOB)")
        self.db.execute("CREATE TABLE IF NOT EXISTS tile (k INTEGER, tx INTEGER, ty INTEGER, used REAL, rgb BLOB,"
                        " PRIMARY KEY (k, tx, ty)) WITHOUT ROWID")
        self.db.commit()
        self.loaded: dict[str, Pic] = {}
        self._infos: dict | None = None
        self._saved_at = time.monotonic()
        self._px_s = 2e-5                          # seconds to draw a pixel, as last measured (start careful)
        sig = _base_sig(world)
        if self._meta("base") != sig:              # a new world (or a new way of drawing): start afresh
            self.db.execute("DELETE FROM pic")
            self.db.execute("DELETE FROM tile")
            self._set_meta("base", sig)
            self._set_meta("towns", json.dumps(towns_now(world)))
            self.db.commit()
            _forget_old_pictures(world)

    # ---- bits
    def _meta(self, k: str):
        row = self.db.execute("SELECT v FROM meta WHERE k = ?", (k,)).fetchone()
        return row[0] if row else None

    def _set_meta(self, k: str, v: str) -> None:
        self.db.execute("INSERT OR REPLACE INTO meta (k, v) VALUES (?, ?)", (k, v))

    def close(self) -> None:
        try:
            self.save()
            self.db.close()
        except sqlite3.Error:
            pass

    # ---- the pictures
    def infos(self) -> dict:
        """name -> (bounds, w, h, stride, continent) of every picture, without their pixels."""
        if self._infos is None:
            out = {}
            stored = {n: json.loads(i) for n, i in self.db.execute("SELECT name, info FROM pic")}
            for name, (bounds, max_px, cont) in plan(self.world).items():
                w, h, stride = _fit(bounds, max_px)
                info = stored.get(name)
                if info is not None and tuple(info["bounds"]) == tuple(round(b, 3) for b in bounds):
                    w, h, stride = info["w"], info["h"], info["stride"]     # as it was drawn (maybe elsewhere)
                out[name] = (tuple(bounds), w, h, stride, cont)
            self._infos = out
        return self._infos

    def names(self) -> list[str]:
        return list(self.infos())

    def pic(self, name: str) -> Pic | None:
        p = self.loaded.get(name)
        if p is not None:
            return p
        info = self.infos().get(name)
        if info is None:
            return None
        bounds, w, h, stride, cont = info
        row = self.db.execute("SELECT info, rgb FROM pic WHERE name = ?", (name,)).fetchone()
        p = None
        if row is not None:
            meta = json.loads(row[0])
            if meta["w"] == w and meta["h"] == h and tuple(meta["bounds"]) == tuple(round(b, 3) for b in bounds):
                p = Pic(name, w, h, bounds, stride, cont, bytearray(zlib.decompress(row[1])), meta.get("jobs") or [])
        if p is None:                              # not drawn yet: all of it to do
            p = Pic(name, w, h, bounds, stride, cont, bytearray(w * h * 3), [[0, 0, w, h, 0]])
        self.loaded[name] = p
        for other in [n for n in self.loaded if n not in (name, "world")][:-3]:   # keep a few in memory
            self._store(self.loaded.pop(other))
        return p

    def _store(self, p: Pic, level: int = 1) -> None:
        if not p.dirty:
            return
        info = {"w": p.w, "h": p.h, "bounds": [round(b, 3) for b in p.bounds], "stride": p.stride,
                "continent": p.continent, "jobs": p.jobs}
        self.db.execute("INSERT OR REPLACE INTO pic (name, info, rgb) VALUES (?, ?, ?)",
                        (p.name, json.dumps(info), zlib.compress(bytes(p.rgb), level)))
        p.dirty = False

    def save(self, level: int = 1) -> None:
        for p in self.loaded.values():
            self._store(p, level)
        self.db.commit()
        self._saved_at = time.monotonic()

    # ---- drawing
    def _draw_rows(self, p: Pic, job: list, rows: int) -> tuple:
        from game import mapimage as MI
        from game import worldmap as WM
        x, y, w, h, done = job
        rows = max(1, min(rows, h - done))
        X0 = p.bounds[0] * WM.SQ + x * p.stride
        Y0 = p.bounds[1] * WM.SQ + (y + done) * p.stride
        rgb = MI.render(self.world, X0, Y0, p.stride, w, rows, sites=False, continent=p.continent)
        line = w * 3
        for j in range(rows):
            at = ((y + done + j) * p.w + x) * 3
            p.rgb[at:at + line] = rgb[j * line:(j + 1) * line]
        job[4] = done + rows
        if job[4] >= h:
            p.jobs.remove(job)
        p.dirty = True
        return (p.name, x, y + done, w, rows)

    def work(self, seconds: float, want: list[str] | tuple = ()) -> list[tuple]:
        """Draw more, for about `seconds`: first the pictures in want (in that order), then nothing else
        (the others are drawn when they're wanted). Returns what changed: [(name, x, y, w, h)] in pixels."""
        out = []
        start = time.perf_counter()
        for name in want:
            p = self.pic(name)
            while p is not None and p.jobs:
                left = seconds - (time.perf_counter() - start)
                if left <= 0 and out:                 # (always a strip at least, however short the time)
                    break
                job = p.jobs[0]
                rows = int(max(1, left / max(1e-9, self._px_s * job[2])))
                t = time.perf_counter()
                got = self._draw_rows(p, job, rows)
                self._px_s = 0.6 * self._px_s + 0.4 * (time.perf_counter() - t) / max(1, got[3] * got[4])
                out.append(got)
            if time.perf_counter() - start >= seconds:
                break
        if out and (time.monotonic() - self._saved_at > SAVE_EVERY or all(self.pic(n).done for n in want)):
            self.save()
        return out

    def finish(self, name: str) -> Pic | None:
        """All of one picture, now (reporting progress, for a loading screen)."""
        from game import progress
        p = self.pic(name)
        if p is None:
            return None
        while p.jobs:
            progress.report(p.fraction(), "Drawing the map")
            self._draw_rows(p, p.jobs[0], max(8, p.h // 24))
        progress.report(1.0, "Drawing the map")
        self.save()
        return p

    # ---- the towns
    def refresh(self) -> list[tuple]:
        """Draw again what a new, gone or changed town covers (see the top). Returns those rectangles (miles)."""
        old = json.loads(self._meta("towns") or "{}")
        new = towns_now(self.world)
        rects = changed_rects(old, new)
        if not rects:
            return []
        from game import worldmap as WM
        for name, (b, _w, _h, _s, _c) in self.infos().items():
            if not any(r[0] < b[2] and b[0] < r[2] and r[1] < b[3] and b[1] < r[3] for r in rects):
                continue                           # nothing changed on this one
            row = self.db.execute("SELECT 1 FROM pic WHERE name = ?", (name,)).fetchone()
            if row is None and name not in self.loaded:
                continue                           # not drawn yet: it'll be drawn as it is now
            p = self.pic(name)
            for r in rects:
                x0 = int((r[0] - p.bounds[0]) * WM.SQ / p.stride) - 1
                y0 = int((r[1] - p.bounds[1]) * WM.SQ / p.stride) - 1
                x1 = int((r[2] - p.bounds[0]) * WM.SQ / p.stride) + 2
                y1 = int((r[3] - p.bounds[1]) * WM.SQ / p.stride) + 2
                x0, y0, x1, y1 = max(0, x0), max(0, y0), min(p.w, x1), min(p.h, y1)
                if x1 > x0 and y1 > y0:
                    p.jobs.append([x0, y0, x1 - x0, y1 - y0, 0])
                    p.dirty = True
        self._drop_tiles(rects)
        self._set_meta("towns", json.dumps(new))
        self.save()
        return rects

    # ---- close-up tiles
    def tile(self, k: int, tx: int, ty: int) -> bytes | None:
        row = self.db.execute("SELECT rgb FROM tile WHERE k = ? AND tx = ? AND ty = ?", (k, tx, ty)).fetchone()
        if row is None:
            return None
        self.db.execute("UPDATE tile SET used = ? WHERE k = ? AND tx = ? AND ty = ?", (time.time(), k, tx, ty))
        return zlib.decompress(row[0])

    def put_tile(self, k: int, tx: int, ty: int, rgb: bytes) -> None:
        self.db.execute("INSERT OR REPLACE INTO tile (k, tx, ty, used, rgb) VALUES (?, ?, ?, ?, ?)",
                        (k, tx, ty, time.time(), zlib.compress(rgb, 1)))
        n = self.db.execute("SELECT COUNT(*) FROM tile").fetchone()[0]
        if n > TILES_KEPT:                                       # the least recently seen go
            old = self.db.execute("SELECT k, tx, ty FROM tile ORDER BY used LIMIT ?", (n - TILES_KEPT,)).fetchall()
            self.db.executemany("DELETE FROM tile WHERE k = ? AND tx = ? AND ty = ?", old)
        self.db.commit()

    def _drop_tiles(self, rects: list[tuple], size: int = 256) -> None:
        from game import worldmap as WM
        gone = []
        for k, tx, ty in self.db.execute("SELECT k, tx, ty FROM tile"):
            span = size * (2 ** k) / WM.SQ                      # miles across the tile
            a = (tx * span, ty * span, (tx + 1) * span, (ty + 1) * span)
            if any(a[0] < r[2] and r[0] < a[2] and a[1] < r[3] and r[1] < a[3] for r in rects):
                gone.append((k, tx, ty))
        self.db.executemany("DELETE FROM tile WHERE k = ? AND tx = ? AND ty = ?", gone)


def _forget_old_pictures(world) -> None:
    """Before step 20 the world's and continents' pictures were kept in the cache file: let them go."""
    try:
        from game import diskcache
        for name in diskcache.names(world):
            if name == "map-world" or name.startswith("map-continent-"):
                diskcache.drop(world, name)
    except Exception:  # noqa: BLE001 - only tidying
        pass


def _from_bundle(world, path) -> None:
    """A world first copied from the app's ready-made one (game/world.py, BUNDLED) gets its big map too, if
    it hasn't one yet and the land's the same."""
    if path.exists():
        return
    try:
        from game.world import BUNDLED
        src = BUNDLED / world.slug / FILE
        if not src.exists():
            return
        con = sqlite3.connect(str(src))
        row = con.execute("SELECT v FROM meta WHERE k = 'base'").fetchone()
        con.close()
        if row and row[0] == _base_sig(world):
            shutil.copyfile(src, path)
    except (OSError, sqlite3.Error):
        pass


def open_map(world) -> BigMap:
    bm = getattr(world, "_bigmap", None)
    if bm is None:
        bm = world._bigmap = BigMap(world)
    return bm


def close(world) -> None:
    bm = getattr(world, "_bigmap", None)
    if bm is not None:
        bm.close()
        world._bigmap = None


def build_all(world) -> BigMap:
    """Every picture, drawn now and kept tightly packed (for the ready-made world the phone app brings)."""
    from game import progress
    bm = open_map(world)
    names = bm.names()
    for i, name in enumerate(names):
        with progress.part(i / len(names), (i + 1) / len(names), "Drawing the map"):
            p = bm.finish(name)
        if p is not None:
            p.dirty = True
            bm._store(p, level=9)
            if name != "world":
                bm.loaded.pop(name, None)            # one continent in memory at a time
    bm.db.commit()
    bm.db.execute("VACUUM")
    return bm


__all__ = ["BigMap", "Pic", "open_map", "close", "build_all", "plan", "towns_now", "changed_rects", "FILE"]
