"""Game engine: entities, rules, state. No UI code lives here."""
