"""Plans for the map's close-up tiers: a town's streets and buildings, and a building's rooms.

Nothing is stored: a plan is worked out from the town's own data (streets, what connects to what,
which buildings stand on which street, which way the exits face) and comes out the same every
time, so a plan only changes when the town does. Units are "plots": about 10 feet.

town_plan(world, town) -> {
    "streets":   [{"name", "x1", "y1", "x2", "y2"}],
    "buildings": [{"id", "name", "kind", "street", "x", "y", "w", "h"}],     (real buildings)
    "houses":    [{"x", "y", "w", "h"}],                                    (filler, just for looks)
    "gates":     [{"direction", "street", "x", "y", "road_to"}],
    "bounds":    (x0, y0, x1, y1)}

floor_plan(world, building) -> {
    "rooms":    [{"name", "x", "y", "w", "h"}],
    "stations": [{"kind", "label", "x", "y"}],      counter, bar, beds, forge, altar, door...
    "bounds":   (0, 0, w, h)}
people_spots(world, building, npcs) -> {npc id: (x, y)}
"""
from __future__ import annotations

import random
import zlib

BIG = {"Tavern", "Inn", "Temple", "Town hall", "Guild hall", "Market", "Barracks", "Warehouse", "Library", "Stable",
       "College", "Boatwright", "Bank", "Casino", "Arena", "Jail", "Brothel"}
UNIT_FEET = 10


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(str(k) for k in key).encode("utf-8")))


# ======================================================================
# Towns
# ======================================================================
def _links(streets: list[dict]) -> dict[str, list[str]]:
    names = [s["name"] for s in streets]
    out = {n: [] for n in names}
    for s in streets:
        for other in str(s.get("connects") or "").split(","):
            other = other.strip()
            if other in out and other != s["name"]:
                if other not in out[s["name"]]:
                    out[s["name"]].append(other)
                if s["name"] not in out[other]:
                    out[other].append(s["name"])
    # streets nobody connects to hang off the first street
    first = names[0]
    for n in names[1:]:
        if not out[n]:
            out[n].append(first)
            out[first].append(n)
    return out


def _size_of(kind: str) -> tuple[int, int]:
    return (6, 4) if kind in BIG else (4, 3)


def town_plan(world, town) -> dict:
    from game import places
    streets = places.streets_of(town)
    names = [s["name"] for s in streets]
    links = _links(streets)
    rng = _rng("town", town.id, len(names))
    on_street: dict[str, list] = {n: [] for n in names}
    for b in places.buildings_in(world, town):
        on_street.setdefault(places.street_of_building(world, b), []).append(b)
    pop = int(town.fields.get("population") or 0)
    filler_per_street = max(0, min(6, pop // 400))

    def length_for(n: str) -> int:
        need = 0
        for b in on_street.get(n, []):
            need += _size_of(b.fields.get("kind") or "")[0] + 1
        need = need // 2 + 2 + filler_per_street * 3
        return max(14, need + 4)

    placed: dict[str, dict] = {}
    first = names[0]
    L = length_for(first)
    placed[first] = {"name": first, "x1": 0, "y1": 0, "x2": L, "y2": 0, "horizontal": True}
    queue = [first]
    side_turn: dict[str, int] = {}
    while queue:
        cur = queue.pop(0)
        seg = placed[cur]
        kids = [k for k in links.get(cur, []) if k not in placed]
        for i, k in enumerate(kids):
            t = (i + 1) / (len(kids) + 1)
            kl = length_for(k)
            flip = 1 if side_turn.get(cur, 0) % 2 == 0 else -1
            side_turn[cur] = side_turn.get(cur, 0) + 1
            if seg["horizontal"]:
                x = round(seg["x1"] + (seg["x2"] - seg["x1"]) * t)
                y = seg["y1"]
                placed[k] = {"name": k, "x1": x, "y1": y, "x2": x, "y2": y + flip * kl, "horizontal": False}
            else:
                x = seg["x1"]
                y = round(seg["y1"] + (seg["y2"] - seg["y1"]) * t)
                placed[k] = {"name": k, "x1": x, "y1": y, "x2": x + flip * kl, "y2": y, "horizontal": True}
            queue.append(k)
    for n in names:                                       # anything not reached (shouldn't happen)
        if n not in placed:
            y = 8 * (len(placed) + 1)
            placed[n] = {"name": n, "x1": 0, "y1": y, "x2": length_for(n), "y2": y, "horizontal": True}

    buildings, houses, taken = [], [], []

    def free(x, y, w, h) -> bool:
        for (ax, ay, aw, ah) in taken:
            if x < ax + aw and ax < x + w and y < ay + ah and ay < y + h:
                return False
        for s in placed.values():                         # keep off every street
            if s["horizontal"]:
                lo, hi = sorted((s["x1"], s["x2"]))
                if y < s["y1"] + 1 and s["y1"] - 1 < y + h and x < hi and lo < x + w:
                    return False
            else:
                lo, hi = sorted((s["y1"], s["y2"]))
                if x < s["x1"] + 1 and s["x1"] - 1 < x + w and y < hi and lo < y + h:
                    return False
        return True

    def put_along(seg, w, h, start_at):
        """Find the next free plot along a street (alternating sides). Returns (x, y) or None."""
        if seg["horizontal"]:
            lo, hi = sorted((seg["x1"], seg["x2"]))
            pos = lo + 1 + start_at
            while pos + w <= hi:
                for y in (seg["y1"] - 1 - h, seg["y1"] + 1):
                    if free(pos, y, w, h):
                        return pos, y
                pos += 1
        else:
            lo, hi = sorted((seg["y1"], seg["y2"]))
            pos = lo + 1 + start_at
            while pos + h <= hi:
                for x in (seg["x1"] - 1 - w, seg["x1"] + 1):
                    if free(x, pos, w, h):
                        return x, pos
                pos += 1
        return None

    for n in names:
        seg = placed[n]
        for b in sorted(on_street.get(n, []), key=lambda e: e.name):
            w, h = _size_of(b.fields.get("kind") or "")
            at = put_along(seg, w, h, 0)
            if at is None:                                # street too crowded: lengthen it
                if seg["horizontal"]:
                    seg["x2"] += (w + 2) * (1 if seg["x2"] >= seg["x1"] else -1)
                else:
                    seg["y2"] += (w + 2) * (1 if seg["y2"] >= seg["y1"] else -1)
                at = put_along(seg, w, h, 0)
            if at is None:
                continue
            taken.append((at[0], at[1], w, h))
            buildings.append({"id": b.id, "name": b.name, "kind": b.fields.get("kind") or "", "street": n,
                              "x": at[0], "y": at[1], "w": w, "h": h})
        for _ in range(filler_per_street):
            w, h = rng.choice([(3, 3), (4, 3), (3, 2)])
            at = put_along(seg, w, h, rng.randrange(0, 4))
            if at is not None:
                taken.append((at[0], at[1], w, h))
                houses.append({"x": at[0], "y": at[1], "w": w, "h": h})

    xs = [v for s in placed.values() for v in (s["x1"], s["x2"])] + [b["x"] for b in buildings + houses] + \
         [b["x"] + b["w"] for b in buildings + houses]
    ys = [v for s in placed.values() for v in (s["y1"], s["y2"])] + [b["y"] for b in buildings + houses] + \
         [b["y"] + b["h"] for b in buildings + houses]
    x0, y0, x1, y1 = min(xs), min(ys), max(xs), max(ys)
    gates = []
    roads = {r["direction"]: r for r in places.roads_of(town)}
    from game import geography as G
    for direction, st in places.town_exits(town).items():
        seg = placed.get(st)
        if seg is None:
            continue
        vx, vy = G.VECTORS.get(direction, (0, 0))
        ends = [(seg["x1"], seg["y1"]), (seg["x2"], seg["y2"])]
        ex, ey = max(ends, key=lambda p: p[0] * vx + p[1] * vy)
        gx = x1 + 2 if vx > 0.1 else x0 - 2 if vx < -0.1 else ex     # out at the edge of town
        gy = y1 + 2 if vy > 0.1 else y0 - 2 if vy < -0.1 else ey
        road = roads.get(direction)
        gates.append({"direction": direction, "street": st, "x": gx, "y": gy,
                      "from_x": ex, "from_y": ey, "road_to": (road or {}).get("leads_to") or ""})

    xs += [g["x"] for g in gates]
    ys += [g["y"] for g in gates]
    pad = 3
    return {"streets": [{k: v for k, v in s.items()} for s in placed.values()], "buildings": buildings,
            "houses": houses, "gates": gates,
            "bounds": (min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad)}


def street_point(plan: dict, street: str) -> tuple[float, float] | None:
    s = next((s for s in plan["streets"] if s["name"] == street), None)
    return ((s["x1"] + s["x2"]) / 2, (s["y1"] + s["y2"]) / 2) if s else None


def building_rect(plan: dict, building_id: str) -> dict | None:
    return next((b for b in plan["buildings"] if b["id"] == building_id), None)


# ======================================================================
# Buildings
# ======================================================================
# Each kind's rooms on a 20 x 14 floor, and the things in them.
LAYOUTS = {
    "Tavern": ([("Common room", 0, 0, 13, 10), ("Bar", 13, 0, 7, 5), ("Kitchen", 13, 5, 7, 5),
                ("Cellar stairs", 0, 10, 20, 4)],
               [("bar", "Bar counter", 15, 2), ("tables", "Tables", 5, 5), ("hearth", "Hearth", 1, 2)]),
    "Inn": ([("Common room", 0, 0, 13, 9), ("Bar", 13, 0, 7, 5), ("Kitchen", 13, 5, 7, 4),
             ("Guest rooms", 0, 9, 20, 5)],
            [("bar", "Bar counter", 15, 2), ("tables", "Tables", 5, 4), ("beds", "Beds", 9, 11)]),
    "Shop": ([("Shop floor", 0, 0, 14, 10), ("Storeroom", 14, 0, 6, 10)],
             [("counter", "Counter", 7, 2), ("shelves", "Shelves", 2, 1), ("crates", "Crates", 16, 5)]),
    "Market": ([("Market hall", 0, 0, 20, 10)],
               [("counter", "Stalls", 10, 3), ("crates", "Crates", 3, 7)]),
    "Warehouse": ([("Warehouse floor", 0, 0, 16, 10), ("Office", 16, 0, 4, 10)],
                  [("counter", "Desk", 17, 3), ("crates", "Crates", 6, 5)]),
    "Smithy": ([("Forge", 0, 0, 12, 10), ("Yard", 12, 0, 8, 10)],
               [("forge", "Forge", 3, 3), ("counter", "Anvil and racks", 8, 5), ("crates", "Ore", 15, 6)]),
    "Temple": ([("Nave", 0, 0, 14, 10), ("Sanctuary", 14, 0, 6, 7), ("Vestry", 14, 7, 6, 3)],
               [("altar", "Altar", 16, 3), ("pews", "Pews", 6, 5), ("counter", "Offerings", 16, 8)]),
    "House": ([("Main room", 0, 0, 11, 8), ("Bedroom", 11, 0, 7, 8)],
              [("tables", "Table", 4, 4), ("hearth", "Hearth", 1, 1), ("beds", "Bed", 14, 3)]),
    "Town hall": ([("Hall", 0, 0, 14, 10), ("Office", 14, 0, 6, 5), ("Records", 14, 5, 6, 5)],
                  [("counter", "Clerk's desk", 16, 2), ("tables", "Benches", 6, 5)]),
    "Guild hall": ([("Great hall", 0, 0, 14, 10), ("Guildmaster's room", 14, 0, 6, 5), ("Vault", 14, 5, 6, 5)],
                   [("counter", "Guild desk", 7, 2), ("tables", "Long tables", 6, 6)]),
    "Library": ([("Reading room", 0, 0, 12, 10), ("Stacks", 12, 0, 8, 10)],
                [("counter", "Librarian's desk", 5, 2), ("shelves", "Shelves", 15, 5), ("tables", "Tables", 5, 6)]),
    "Barracks": ([("Drill hall", 0, 0, 12, 10), ("Bunks", 12, 0, 8, 10)],
                 [("counter", "Duty desk", 3, 2), ("beds", "Bunks", 15, 5), ("racks", "Weapon racks", 8, 7)]),
    "Stable": ([("Stalls", 0, 0, 14, 10), ("Tack room", 14, 0, 6, 10)],
               [("counter", "Hostler", 16, 3), ("stalls", "Stalls", 6, 5)]),
    "College": ([("Lecture hall", 0, 0, 10, 10), ("Reading room", 10, 0, 10, 6), ("Stacks", 10, 6, 10, 4)],
                [("counter", "Porter's desk", 5, 2), ("tables", "Benches", 5, 6), ("shelves", "Shelves", 15, 8)]),
    "Boatwright": ([("Boat shed", 0, 0, 14, 10), ("Office", 14, 0, 6, 10)],
                   [("counter", "Boatwright's desk", 17, 3), ("crates", "Timber and pitch", 6, 5)]),
}
ROLE_STATION = {"Innkeeper": "bar", "Merchant": "counter", "Blacksmith": "forge", "Armorer": "forge",
                "Weaponsmith": "forge", "Alchemist": "counter", "Priest": "altar", "Guard": "door",
                "Librarian": "counter", "Farmer": "tables", "Noble": "tables"}


def floor_plan(world, building) -> dict:
    kind = building.fields.get("kind") or "House"
    rooms, stations = LAYOUTS.get(kind, ([("Main room", 0, 0, 16, 10)], [("tables", "Tables", 7, 5)]))
    out_rooms = [{"name": n, "x": x, "y": y, "w": w, "h": h} for n, x, y, w, h in rooms]
    out_st = [{"kind": k, "label": label, "x": x, "y": y} for k, label, x, y in stations]
    first = out_rooms[0]
    out_st.append({"kind": "door", "label": "Door to the street", "x": first["x"] + first["w"] / 2,
                   "y": first["y"] + first["h"]})
    if float(building.fields.get("inn_price") or 0) > 0 and not any(s["kind"] == "beds" for s in out_st):
        out_st.append({"kind": "beds", "label": "Rooms to rent", "x": first["x"] + 2, "y": first["y"] + first["h"] - 2})
    w = max(r["x"] + r["w"] for r in out_rooms)
    h = max(r["y"] + r["h"] for r in out_rooms)
    return {"rooms": out_rooms, "stations": out_st, "bounds": (0, 0, w, h)}


def people_spots(world, building, npcs: list) -> dict[str, tuple[float, float]]:
    """Where each person in the building stands: their work station, or somewhere in the main room."""
    plan = floor_plan(world, building)
    st = {s["kind"]: s for s in plan["stations"]}
    main = plan["rooms"][0]
    rng = _rng("people", building.id)
    out = {}
    used = set()
    for n in npcs:
        works_here = (n.fields.get("building") or "") == building.id
        key = ROLE_STATION.get(n.fields.get("occupation") or "", "")
        s = st.get(key) if works_here else None
        if s is not None and key not in used:
            used.add(key)
            out[n.id] = (s["x"], s["y"] + 1.2)
            continue
        for _ in range(20):
            x = main["x"] + 1.5 + rng.random() * (main["w"] - 3)
            y = main["y"] + 1.5 + rng.random() * (main["h"] - 3)
            if all(abs(x - a) + abs(y - b) > 2 for a, b in out.values()):
                break
        out[n.id] = (x, y)
    return out
