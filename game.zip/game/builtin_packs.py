"""Content that ships with the game, and starting a world with any mix of it.

STARTERS lists everything a new world can start with (Worlds > New world shows each as a checkbox):
  * "test"   the sample town and the small test pack (written in code: game/starter.py)
  * "srd"    the SRD 5.1 pack (game/content/srd51-pack.json)
  * "more"   original monsters, goods and magic items that build on the SRD (game/content/more-pack.json)
  * "world1" the big world, batch 1: continents and regions (game/content/world-continents-pack.json)
  * "world2" batch 2: settlements and roads; "world3" batch 3: landmarks and dungeons;
    "world4" batch 4: the buildings and people of every settlement (a zipped pack: it's big);
    "world5" batch 5: quests (needs "more" too)
They are installed in that order: the SRD replaces the test pack's rules content (Fighter, Longsword,
Goblin...), and the world packs only add places.
"""
from __future__ import annotations

from pathlib import Path

CONTENT = Path(__file__).resolve().parent / "content"

# key, label shown on the checkbox, pack file (None: built in code), install mode
STARTERS = [
    ("test", "Sample town and test pack (a starting town, its people, a dungeon and a few quests)", None, ""),
    ("srd", "SRD 5.1 rules: classes, races, spells, items and monsters", "srd51-pack.json", "replace"),
    ("more", "More monsters and goods: original monsters, shop goods and magic items (needs the SRD)",
     "more-pack.json", "skip"),
    ("world1", "The big world, part 1: 10 continents and 50 regions", "world-continents-pack.json", "skip"),
    ("world2", "The big world, part 2: about 1,000 settlements and the roads between them",
     "world-settlements-pack.json", "skip"),
    ("world3", "The big world, part 3: landmarks and dungeons in every region",
     "world-landmarks-pack.json", "skip"),
    ("world4", "The big world, part 4: the inns, shops, temples and homes of every settlement, and its people",
     "world-towns-pack.rpgpack", "skip"),
    ("world5", "The big world, part 5: quests (a master and a relic for every dungeon, landmarks to find, "
               "errands)", "world-quests-pack.json", "skip"),
    ("world6", "The big world, part 6: every settlement grown to its size (homes and families; banks, jails, "
               "casinos, colleges, arenas; graded roads and roadside inns)", "world-growth-pack.rpgpack", "skip"),
]
REQUIRES = {"more": ["srd"], "world2": ["world1"], "world3": ["world2"], "world4": ["world3"], "world5": ["world4", "more"],
            "world6": ["world4"]}          # installing one brings in what it builds on
_cache: dict[str, dict] = {}


def path_of(key: str) -> Path | None:
    for k, _label, fname, _mode in STARTERS:
        if k == key and fname:
            return CONTENT / fname
    return None


def available(key: str) -> bool:
    if key == "test":
        return True
    p = path_of(key)
    return p is not None and p.exists()


def choices() -> list[tuple[str, str]]:
    """(key, label) for every starter this copy of the game has."""
    return [(k, label) for k, label, _f, _m in STARTERS if available(k)]


def label_of(key: str) -> str:
    return next((label for k, label, _f, _m in STARTERS if k == key), key)


def load(key: str) -> dict:
    if key in _cache:
        return _cache[key]
    from game import packs
    path = path_of(key)
    pack = packs.read_pack(path)[0]
    if path.stat().st_size < 4_000_000:                   # the big ones aren't worth keeping in memory
        _cache[key] = pack
    return pack


def install(world, key: str, mode: str | None = None) -> dict:
    """Install one built-in pack into a world (and remember that it's there). Packs it builds on come
    first if the world doesn't have them yet."""
    from game import packs
    for need in REQUIRES.get(key, []):
        if not installed(world, need) and available(need):
            install(world, need)
    default = next((m for k, _l, _f, m in STARTERS if k == key), "skip") or "skip"
    pack = load(key)
    # packs that grow what other packs made match by id only: their new people may share a name with
    # someone already there, and must not be mistaken for them
    by_name = key not in BY_ID
    report = packs.install(world, pack, mode or default, by_name=by_name)
    if pack.get("patches"):
        report["patched"] = packs.apply_patches(world, pack["patches"])
    world.meta.setdefault("content", {})[key if key != "srd" else "srd51"] = pack.get("version", "1")
    world.save_meta()
    return report


BY_ID = {"world6"}
UPGRADES = [("world6", "world4")]                   # (pack, the pack whose worlds it upgrades)
REFRESH = {"more": "5"}                             # packs that grew: worlds with an older one get what's new


def upgrade(world) -> list[str]:
    """Give a world made before a pack existed what it builds on (the settlements grown, for worlds with
    the big world's towns). Returns the packs installed."""
    done = []
    for key, base in UPGRADES:
        if installed(world, base) and not installed(world, key) and available(key):
            from game import progress
            with progress.part(0.0, 1.0, f"Adding {label_of(key)}"):
                install(world, key)
            done.append(key)
    for key, version in REFRESH.items():
        have = (world.meta.get("content") or {}).get(key)
        if have and str(have) != version and available(key):
            from game import progress
            with progress.part(0.0, 1.0, f"Adding to {label_of(key)}"):
                install(world, key)                       # skip mode: only what's new goes in
            done.append(key)
    return done


def installed(world, key: str) -> bool:
    return bool((world.meta.get("content") or {}).get(key if key != "srd" else "srd51"))


def start_world(world, keys) -> None:
    """Put any mix of the starters into a fresh world, in the right order."""
    wanted = set(keys or [])
    for _ in range(3):                                   # what each builds on, all the way down
        for k in list(wanted):
            wanted |= set(REQUIRES.get(k, []))
    from game import progress
    todo = [k for k, _label, _f, _m in STARTERS if k in wanted and available(k)]
    with world.entities.batch():                          # the records are packed once, at the end
        for i, (k, label, _f, _m) in enumerate(STARTERS):
            if k not in wanted or not available(k):
                continue
            progress.report(todo.index(k) / max(1, len(todo)), f"Adding {label}")
            if k == "test":
                from game.starter import install_starter
                install_starter(world, "test")
            else:
                install(world, k)
