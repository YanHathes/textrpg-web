"""Dungeon traps on the walking map (Hotfix 19): something on a square, to be spotted, disarmed, stepped round
or sprung.

Where they are
    A dungeon room the dungeon maker gave a trap (game/dungeons.py: trap_dc, trap_damage, trap_type) has it on
    one square of the room, in the way between its doors (game/area.py build_dungeon puts it there: lv.traps).
    What kind it is follows from its damage type (and the dungeon and room, so it's always the same one):
    KINDS below. Old dungeons get their traps the same way; nothing in the world changes.

Spotting
    The first time the trap's square comes into sight, the party rolls once for it: the sharpest eyes' Wisdom
    (Perception), d20 + bonus (always rolled, not the flat passive 10 + bonus), against the trap's DC. Seen,
    it's shown on the map; missed, it stays hidden, and walking away and back doesn't roll again. Searching
    the room (Search for hidden doors and traps) is a fresh Perception roll for any missed in sight.
A seen trap
    Stepping onto it asks: disarm it (Thieves' Tools, or Arcana for a glyph; failing by 5 or more sets it off),
    step over it carefully (Acrobatics; failing sets it off), or leave it. Walking by tapping goes round it.
A hidden one
    Goes off when stepped on. Each kind does its own thing (a save against its DC for each of the party).
Once sprung or disarmed it's done with (an open pit stays to be seen), until the dungeon restocks.

Kept in the save (state.dungeons[dungeon id]["traps"]): {room name: "seen" | "missed" | "disarmed" | "sprung"}.
"""
from __future__ import annotations

import random
import zlib

from game import dice

# kind: name, the save, damage type ("" for none), what's seen when it's spotted, what happens, what disarms it
KINDS = {
    "darts": {"name": "dart trap", "save": "dex", "type": "piercing", "skill": "tools",
              "seen": "a pressure plate, and tiny holes in the walls either side",
              "sprung": "Click. Darts hiss out of the walls!"},
    "blade": {"name": "scything blade", "save": "dex", "type": "slashing", "skill": "tools",
              "seen": "a tripwire, and a slot in the wall where a blade waits",
              "sprung": "A blade sweeps out of the wall at waist height!"},
    "pit": {"name": "hidden pit", "save": "dex", "type": "bludgeoning", "skill": "tools",
            "seen": "flagstones that don't quite meet: a pit's lid",
            "sprung": "The floor drops away beneath you!"},
    "block": {"name": "falling block", "save": "dex", "type": "bludgeoning", "skill": "tools",
              "seen": "a loose plate, and a block of stone hung in the ceiling above it",
              "sprung": "Stone grinds overhead and a great block drops!"},
    "flame": {"name": "flame jet", "save": "dex", "type": "fire", "skill": "tools",
              "seen": "scorch marks, and nozzles in the floor",
              "sprung": "Jets of fire roar up out of the floor!"},
    "glyph": {"name": "glyph of warding", "save": "dex", "type": "thunder", "skill": "arcana",
              "seen": "a faint rune traced on the floor",
              "sprung": "A rune flares underfoot and bursts with a thunderclap!"},
    "gas": {"name": "poison gas", "save": "con", "type": "poison", "skill": "tools", "poisons": True,
            "seen": "a plate, and vents in the walls stained green",
            "sprung": "Green gas billows from the walls!"},
    "alarm": {"name": "alarm", "save": "", "type": "", "skill": "tools", "alarm": True,
              "seen": "a tripwire strung to a bell",
              "sprung": "A bell clangs somewhere ahead, and something answers it."},
}
FAMILY = {"piercing": ["darts", "darts", "blade"], "slashing": ["blade"], "bludgeoning": ["pit", "block"],
          "fire": ["flame", "flame", "glyph"], "poison": ["gas"], "thunder": ["glyph"]}
ALARM_ODDS = 7                    # one trap in this many is an alarm instead
CAREFUL_EASIER = 2                # stepping over a seen trap: its DC less this
SEARCH_MINUTES = 10


# ----------------------------------------------------------------------------------------------------
# What a room's trap is
# ----------------------------------------------------------------------------------------------------
def kind_of(d, row: dict) -> str:
    k = row.get("trap_kind")
    if k in KINDS:
        return k
    h = zlib.crc32(f"{d.id}|{row.get('name')}".encode("utf-8"))
    if h % ALARM_ODDS == 0:
        return "alarm"
    fam = FAMILY.get(row.get("trap_type") or "piercing", FAMILY["piercing"])
    return fam[(h // ALARM_ODDS) % len(fam)]


def info(d, row: dict) -> dict | None:
    if not (int(row.get("trap_dc") or 0) and (row.get("trap_damage") or "")):
        return None
    k = kind_of(d, row)
    kd = KINDS[k]
    return {"kind": k, "name": kd["name"], "dc": int(row["trap_dc"]), "damage": row["trap_damage"],
            "type": kd["type"], "save": kd["save"], "room": row.get("name")}


def _where(world, lv, c):
    """(dungeon, room row, trap info) for the trap on this square, or (None, None, None)."""
    from game import dungeons as D
    t = getattr(lv, "traps", {}).get(c)
    if not t:
        return None, None, None
    d = world.entities.get(t["dungeon"])
    row = D.room(d, t["name"]) if d is not None else None
    if row is None:
        return None, None, None
    return d, row, info(d, row)


def _redraw(explorer) -> None:
    """The map shows the traps the party knows of: have it draw them again (the app keeps what it drew)."""
    if explorer is not None:
        explorer.door_version = getattr(explorer, "door_version", 0) + 1


def _book(state, d) -> dict:
    from game import dungeons as D
    p = D.progress(state, d)
    return p.setdefault("traps", {})


def status(state, d, name: str) -> str:
    return (_book(state, d) or {}).get(name, "")


def shown(explorer, lv) -> list[tuple[int, int, str, str]]:
    """(x, y, kind, status) of the traps on this level the party knows of (to draw on the map)."""
    out = []
    for c, t in (getattr(lv, "traps", None) or {}).items():
        d, row, inf = _where(explorer.world, lv, c)
        if inf is None:
            continue
        st = status(explorer.state, d, t["name"])
        if st in ("seen", "disarmed", "sprung"):
            out.append((c[0], c[1], inf["kind"], st))
    return out


def avoid(explorer) -> set:
    """Squares of seen traps still set (walking by tapping goes round them)."""
    a = explorer.area
    if a is None or a.kind != "dungeon":
        return set()
    out = set()
    for lv in a.all_levels():
        for x, y, _k, st in shown(explorer, lv):
            if st == "seen":
                out.add((x, y))
    return out


# ----------------------------------------------------------------------------------------------------
# Rolling
# ----------------------------------------------------------------------------------------------------
ABILITY_CHECK = {"dex": "Dexterity check", "int": "Intelligence check", "wis": "Wisdom check"}


def _best(world, members: list, label: str, ability: str):
    """(member, combatant, option, bonus) with the best bonus for this skill. A tool nobody's trained with
    falls back on the plain ability check (fiddling with a trap without thieves' tools)."""
    from game import checks, condition
    opts = checks.options(world)
    opt = next((o for o in opts if o["label"].lower() == label.lower()), None)
    plain = next((o for o in opts if o["label"] == ABILITY_CHECK.get(ability, "")), None)
    best = None
    for m in members:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        use = opt
        if opt is not None and opt.get("kind") == "Tool" and not checks.bonus(world, m, c, opt)[1] \
                and not opt.get("untrained", True):
            use = plain
        b = checks.bonus(world, m, c, use)[0] if use else c.mod(ability)
        if best is None or b > best[3]:
            best = (m, c, use, b)
    return best


def _roll(world, state, members, label: str, ability: str, dc: int, rng, bus=None, target: str = ""):
    """(total, who, success) for the party's best at this, rolled."""
    from game import checks
    pick = _best(world, members, label, ability)
    if pick is None:
        return 0, "", False
    m, c, opt, b = pick
    if opt is not None:
        r = checks.roll(world, m, c, opt, dc, rng=rng, bus=bus, target=target)
        return int(r["total"]), c.name, bool(r.get("success"))
    tot = rng.randint(1, 20) + b
    return tot, c.name, tot >= dc


# ----------------------------------------------------------------------------------------------------
# Spotting (when it comes into sight), and searching
# ----------------------------------------------------------------------------------------------------
def notice(explorer) -> list[str]:
    """Called when the party looks round (game/explore.py look): one roll for each trap seen for the first
    time. Returns what's said (also put in the log)."""
    a = explorer.area
    if a is None or a.kind != "dungeon":
        return []
    lv = a.levels.get(explorer.level)
    traps = getattr(lv, "traps", None) if lv is not None else None
    if not traps:
        return []
    out = []
    for c, t in traps.items():
        if c not in explorer.visible:
            continue
        d, row, inf = _where(explorer.world, lv, c)
        if inf is None:
            continue
        book = _book(explorer.state, d)
        if t["name"] in book:
            continue                                    # rolled for already (or done with)
        tot, who, ok = _roll(explorer.world, explorer.state, explorer.members(), "Perception", "wis", inf["dc"],
                             explorer.rng)
        book[t["name"]] = "seen" if ok else "missed"
        explorer.state.save()
        _redraw(explorer)
        if ok:
            text = (f"{who} spots something ahead (Perception {tot} vs DC {inf['dc']}): "
                    f"{KINDS[inf['kind']]['seen']}. A {inf['name']}.")
            out.append(text)
            if explorer.bus is not None:
                explorer.bus.emit("log", kind="system", text=text)
                explorer.bus.emit("trap.spotted", kind=inf["kind"])
    return out


def search(world, state, explorer, members: list, rng=None) -> tuple[int, list[str]]:
    """A fresh Perception roll for the traps missed in sight (part of searching a room). Returns (how many
    found, lines)."""
    rng = rng or random.Random()
    if explorer is None or explorer.area is None or explorer.area.kind != "dungeon":
        return 0, []
    lv = explorer.area.levels.get(explorer.level)
    found, lines = 0, []
    for c, t in (getattr(lv, "traps", None) or {}).items():
        if c not in explorer.visible:
            continue
        d, row, inf = _where(world, lv, c)
        if inf is None or status(state, d, t["name"]) != "missed":
            continue
        tot, who, ok = _roll(world, state, members, "Perception", "wis", inf["dc"], rng)
        if ok:
            _book(state, d)[t["name"]] = "seen"
            found += 1
            lines.append(f"{who} finds {KINDS[inf['kind']]['seen']}: a {inf['name']} (Perception {tot} vs DC "
                         f"{inf['dc']}).")
    state.save()
    _redraw(explorer)
    return found, lines


# ----------------------------------------------------------------------------------------------------
# Stepping onto one
# ----------------------------------------------------------------------------------------------------
def at(explorer, lv, c):
    """The trap on this square if it's still set: (dungeon, row, info, status), else None."""
    d, row, inf = _where(explorer.world, lv, c)
    if inf is None:
        return None
    st = status(explorer.state, d, row["name"])
    if st in ("disarmed", "sprung"):
        return None
    return d, row, inf, st


def prompt(explorer, lv, c):
    """A seen trap underfoot: disarm it, step over it carefully, or leave it."""
    from game.explore import Prompt
    d, row, inf, _st = at(explorer, lv, c)
    members = explorer.members()
    key = f"{lv.key}:{c[0]},{c[1]}"
    opts = []
    arcane = KINDS[inf["kind"]]["skill"] == "arcana"
    pick = _best(explorer.world, members, "Arcana" if arcane else "Thieves' Tools", "int" if arcane else "dex")
    if pick is not None:
        m, cc, _o, b = pick
        tool = _o["label"] if _o else ("Arcana" if arcane else "Dexterity")
        opts.append((f"Disarm it: {cc.name} ({tool} {b:+d} vs DC {inf['dc']})", ("trap", "disarm", key), True))
    pick = _best(explorer.world, members, "Acrobatics", "dex")
    if pick is not None:
        m, cc, _o, b = pick
        opts.append((f"Step over it carefully (Acrobatics {b:+d} vs DC {max(5, inf['dc'] - CAREFUL_EASIER)})",
                     ("trap", "over", key), True))
    opts.append(("Leave it", ("none",), True))
    return Prompt(f"A {inf['name']}", f"{KINDS[inf['kind']]['seen'][0].upper()}{KINDS[inf['kind']]['seen'][1:]}. "
                                      "Step on it and it goes off.", opts)


def spring(world, state, members: list, d, row: dict, rng=None, bus=None) -> dict:
    """It goes off. {"lines", "fight": enemy rows or None (an alarm), "key" (for the fight)}."""
    from game import condition
    from game import dungeons as D
    rng = rng or random.Random()
    inf = info(d, row)
    if inf is None:
        return {"lines": [], "fight": None}
    kd = KINDS[inf["kind"]]
    _book(state, d)[row["name"]] = "sprung"
    D.progress(state, d)["sprung"] = sorted(set(D.progress(state, d)["sprung"]) | {row["name"]})
    lines = [kd["sprung"]]
    out = {"lines": lines, "fight": None, "key": None}
    if kd.get("alarm"):
        near = _alarm_foes(world, state, d, row, rng)
        if near is not None:
            name, foes = near
            out["fight"] = foes
            out["key"] = (d.id, name)
            lines.append(f"They come running from the {name.lower()}!")
        else:
            lines.append("The bell rings on into empty halls. Nothing comes.")
        state.save()
        return out
    for m in members:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        condition.apply(state, m, c)
        ab = kd["save"] or "dex"
        roll = rng.randint(1, 20) + c.mod(ab) + (c.prof if ab in c.saves else 0)
        dmg = max(0, dice.roll(inf["damage"], rng).total) if dice.is_valid(inf["damage"]) else 0
        saved = roll >= inf["dc"]
        if saved:
            dmg //= 2
        c.hp = max(1, c.hp - dmg)
        extra = ""
        if kd.get("poisons") and not saved:
            c.conditions["Poisoned"] = {"rounds": -1, "source": "", "save": None, "lasting": True}
            extra = ", poisoned until a rest"
        condition.store(state, m, c, save=False)
        lines.append(f"{c.name}: {ab.upper()[:3].title()} save {roll} vs DC {inf['dc']}, {dmg} {inf['type']} damage"
                     f"{extra} ({c.hp}/{c.max_hp} HP).")
    from game import party as P
    P.save(world, members)
    state.save()
    if bus is not None:
        bus.emit("trap.sprung", kind=inf["kind"])
    return out


def _alarm_foes(world, state, d, row, rng):
    """The monsters an alarm brings: the nearest room's that hasn't been cleared."""
    from game import dungeons as D
    p = D.progress(state, d)
    lay = D.layout(d)
    here = lay.get(row["name"])
    best = None
    for r in D.rooms(d):
        if r["name"] == row["name"] or r["name"] in p["cleared"]:
            continue
        foes = D.room_foes(world, d, r, rng)
        if not foes:
            continue
        there = lay.get(r["name"])
        dist = abs(there[0] - here[0]) + abs(there[1] - here[1]) if here and there else 999
        if best is None or dist < best[0]:
            best = (dist, r["name"], [{"id": e.id, "count": n} for e, n in foes])
    return (best[1], best[2]) if best else None


def act(world, state, members: list, explorer, action: tuple, rng=None, bus=None) -> dict:
    """("trap", "disarm" | "over", "level:x,y"). Returns {"lines", "fight", "key", "moved"}."""
    rng = rng or random.Random()
    what = action[1] if len(action) > 1 else ""
    lk, _s, xy = (action[2] if len(action) > 2 else "").partition(":")
    try:
        x, y = (int(v) for v in xy.split(","))
    except ValueError:
        return {"lines": []}
    a = explorer.area
    lv = a.levels.get(lk) if a is not None else None
    here = at(explorer, lv, (x, y)) if lv is not None else None
    if here is None:
        return {"lines": ["There's nothing set there now."]}
    d, row, inf, _st = here
    kd = KINDS[inf["kind"]]
    _redraw(explorer)
    if what == "disarm":
        arcane = kd["skill"] == "arcana"
        tot, who, ok = _roll(world, state, members, "Arcana" if arcane else "Thieves' Tools",
                             "int" if arcane else "dex", inf["dc"], rng, bus, f"the {inf['name']}")
        state.advance(1, "disarming a trap")
        if ok:
            _book(state, d)[row["name"]] = "disarmed"
            state.save()
            if bus is not None:
                bus.emit("trap.disarmed", kind=inf["kind"])
            return {"lines": [f"{who} disarms the {inf['name']} ({tot} vs DC {inf['dc']})."]}
        if tot <= inf["dc"] - 5:
            out = spring(world, state, members, d, row, rng, bus)
            out["lines"] = [f"{who} fumbles it ({tot} vs DC {inf['dc']})."] + out["lines"]
            return out
        return {"lines": [f"{who} can't work it out ({tot} vs DC {inf['dc']}), but it doesn't go off."]}
    if what == "over":
        dc = max(5, inf["dc"] - CAREFUL_EASIER)
        tot, who, ok = _roll(world, state, members, "Acrobatics", "dex", dc, rng, bus, f"the {inf['name']}")
        explorer.x, explorer.y = x, y                      # onto it (and on past, next step)
        explorer.look()
        explorer.remember_pos()
        explorer.save()
        if ok:
            return {"lines": [f"Carefully, carefully: {who} leads the way over the {inf['name']} "
                              f"({tot} vs DC {dc})."], "moved": True}
        out = spring(world, state, members, d, row, rng, bus)
        out["lines"] = [f"A foot in the wrong place ({tot} vs DC {dc})."] + out["lines"]
        out["moved"] = True
        return out
    return {"lines": []}


__all__ = ["KINDS", "kind_of", "info", "status", "shown", "avoid", "notice", "search", "at", "prompt", "spring",
           "act"]
