"""Gathering: wood, stone and ore, herbs, berries and grain, fish, and skins from beasts you've killed.

    Activity      Where                                   Faster with                Check
    Woodcutting   any tree                                an axe (woodcutter's best) Strength (Athletics)
    Mining        ore veins, quarry rock, rocks           a miner's pick             Strength (Athletics)
    Foraging      bushes, herb patches, wild grain,       a sickle or scythe;        Wisdom (Survival) or
                  mushrooms                               a herbalism kit            Intelligence (Nature)
    Fishing       water                                   fishing tackle             Wisdom (Survival)
    Skinning      beasts you've killed                    a knife                    Wisdom (Survival)

A try takes game time. By hand it takes twice as long and gives only one; a tool (and its quality: Fine
x1.25, Masterwork x1.5, Legendary x2) is faster and gives more, and so does a better roll (or a better
minigame, game/minigames.py): one more for every 5 over the DC. Proficiency with the work (from use: 100,
1,000, 10,000 tries; game/tools.py) adds its bonus, and every successful try counts towards it.

A tree becomes a stump and a vein is used up: they grow back after some days (sooner in spring, later in
winter). The save records which squares are used (game/landchanges.py); the land itself is made from the
world's seed, so every save in a world has the same veins. Chopping and mining are noisy: they draw
roaming monsters a little (game/explore.py). Some herbs and berries grow only in some seasons; fish bite
more in the rain; nothing can be foraged under deep snow.

Hidden deposits (a rich vein, a patch of rare herbs) are in some chunks of the land, out of sight until a
search finds them (or, in step 9, a rumor points to them).

What each kind of thing gives is a table (DROPS, below) of item names with weights, by land and season;
a world can change it with the world rule "gathering" (the same shape, merged over this one).
"""
from __future__ import annotations

import random
import zlib

from game import calendar as CAL

# prop id -> (work, the check(s), DC, minutes per try with a tool, days to grow back, what it leaves)
SOURCES = {
    "tree": ("woodcutting", ("athletics",), 10, 30, 12, "stump"),
    "big_tree": ("woodcutting", ("athletics",), 12, 45, 18, "stump"),
    "pine": ("woodcutting", ("athletics",), 10, 30, 12, "stump"),
    "ore_vein": ("mining", ("athletics",), 12, 40, 30, "spent_vein"),
    "rich_vein": ("mining", ("athletics",), 13, 45, 60, "spent_vein"),
    "quarry_rock": ("mining", ("athletics",), 10, 40, 20, "rubble"),
    "rock": ("mining", ("athletics",), 8, 25, 10, "rubble"),
    "boulder": ("mining", ("athletics",), 10, 40, 20, "rubble"),
    "herb_patch": ("foraging", ("survival", "nature"), 10, 15, 5, "bare_patch"),
    "rare_herbs": ("foraging", ("survival", "nature"), 14, 20, 30, "bare_patch"),
    "berry_bush": ("foraging", ("survival", "nature"), 8, 15, 6, "bush"),
    "bush": ("foraging", ("survival", "nature"), 10, 15, 6, "bush"),
    "mushrooms": ("foraging", ("survival", "nature"), 11, 15, 4, "bare_patch"),
    "wild_grain": ("harvesting", ("survival", "nature"), 8, 20, 7, "bare_patch"),
    "fishing_spot": ("fishing", ("survival",), 9, 30, 0, ""),
    "water": ("fishing", ("survival",), 11, 30, 0, ""),
}
VERB = {"woodcutting": "Cut wood", "mining": "Mine", "foraging": "Forage", "harvesting": "Harvest",
        "fishing": "Fish", "skinning": "Skin"}
NOISY = {"woodcutting", "mining"}
HAND_TIME = 2.0                       # by hand: twice as long
MAX_TRIES = 6                         # "keep at it": up to this many tries in a row
NOISE_SQUARES = 40                    # each noisy try counts as walking this far, for meeting monsters
SEARCH_DC = 14                        # searching the land for what's hidden
SEASON_REGROW = {"Spring": 0.6, "Summer": 0.8, "Autumn": 1.0, "Winter": 1.6}
SKILL_LABEL = {"athletics": "Athletics", "survival": "Survival", "nature": "Nature"}

# what each work gives: {work: {key: [(item name, weight, seasons or "")]}} where key is a prop id, a land
# ("land:Forest"), or "*" for anything else
DROPS: dict = {
    "woodcutting": {
        "land:Taiga": [("Pine Log", 10, "")], "land:Arctic": [("Pine Log", 10, "")],
        "land:Tundra": [("Pine Log", 10, "")], "land:Mountains": [("Pine Log", 10, "")],
        "land:Jungle": [("Ironwood Log", 3, ""), ("Oak Log", 7, "")],
        "land:Forest": [("Oak Log", 10, ""), ("Ironwood Log", 1, "")],
        "pine": [("Pine Log", 10, "")],
        "*": [("Oak Log", 10, "")],
    },
    "mining": {
        "quarry_rock": [("Stone Block", 10, "")],
        "rock": [("Stone Block", 6, ""), ("Coal", 1, "")],
        "boulder": [("Stone Block", 10, "")],
        "*": [("Stone Block", 4, "")],
    },
    "foraging": {
        "berry_bush": [("Wild Strawberries", 6, "Spring Summer"), ("Blackberries", 8, "Summer Autumn"),
                       ("Lingonberries", 5, "Autumn")],
        "land:Tundra": [("Cloudberries", 8, "Summer"), ("Lingonberries", 5, "Autumn"), ("Frostcap", 2, "")],
        "mushrooms": [("Field Mushrooms", 6, "Summer Autumn"), ("Chanterelles", 5, "Summer Autumn"),
                      ("Morels", 4, "Spring"), ("Ghostcap", 1, "Autumn Winter")],
        "rare_herbs": [("Moonpetal", 4, ""), ("Mandrake Root", 3, ""), ("Fire Lily", 2, "Summer"),
                       ("Mountain Gentian", 2, "Summer")],
        "herb:Forest": [("Yarrow", 5, "Spring Summer"), ("Silverleaf", 4, ""), ("Wolfsbane", 2, "Summer Autumn"),
                        ("Nightshade", 2, "Summer")],
        "herb:Plains": [("Yarrow", 6, "Spring Summer"), ("Willow Bark", 3, ""), ("Thornapple", 2, "Summer")],
        "herb:Hills": [("Mountain Gentian", 3, "Summer"), ("Yarrow", 4, "Spring Summer"), ("Silverleaf", 3, "")],
        "herb:Swamp": [("Bog Myrtle", 6, ""), ("Nightshade", 3, "Summer Autumn"), ("Willow Bark", 3, "")],
        "herb:Desert": [("Desert Sage", 8, "")],
        "herb:Jungle": [("Jungle Orchid", 5, ""), ("Thornapple", 3, ""), ("Silk Cocoons", 2, "")],
        "herb:Coast": [("Silverleaf", 4, ""), ("Yarrow", 4, "Spring Summer")],
        "herb:Taiga": [("Frostcap", 4, "Autumn Winter"), ("Silverleaf", 3, ""), ("Wolfsbane", 2, "Summer")],
        "*": [("Yarrow", 5, "Spring Summer"), ("Silverleaf", 3, "")],
    },
    "harvesting": {
        "*": [("Wild Wheat", 7, "Summer Autumn"), ("Wild Barley", 5, "Summer Autumn"), ("Flax", 3, "Summer Autumn")],
        "land:Swamp": [("Wild Rice", 8, "Summer Autumn")],
    },
    "fishing": {
        "land:Ocean": [("Cod", 6, ""), ("Mackerel", 6, "Spring Summer"), ("Herring", 6, "")],
        "land:Coast": [("Cod", 5, ""), ("Mackerel", 5, "Spring Summer"), ("Herring", 5, "")],
        "land:Arctic": [("Ice Fish", 8, ""), ("Salmon", 3, "Summer Autumn")],
        "land:Tundra": [("Ice Fish", 6, ""), ("Salmon", 4, "Summer Autumn")],
        "land:Taiga": [("Trout", 6, ""), ("Salmon", 4, "Summer Autumn")],
        "land:Swamp": [("Catfish", 7, ""), ("Carp", 5, "")],
        "land:Jungle": [("Catfish", 7, ""), ("Carp", 4, "")],
        "*": [("Trout", 6, ""), ("Perch", 6, ""), ("Carp", 4, ""), ("Golden Carp", 1, "Summer")],
    },
}
# what a vein holds goes by its picture (game/art/tiles.py ORE_FLECKS): stone, coal, copper, iron, silver, gold
ORE_BY_VARIANT = ["Stone Block", "Coal", "Copper Ore", "Iron Ore", "Silver Ore", "Gold Nugget"]
VEIN_WEIGHTS = [18, 24, 22, 20, 10, 6]
VEIN_DANGER = [0, 0, 0, 0, 10, 25]       # region danger a vein needs to hold silver, gold (rarer in harder places)
MITHRAL_DANGER = 40                       # and in the hardest places, now and then mithral
MITHRAL_CHANCE = 0.08
HIDES = [("rabbit", "Rabbit Furs"), ("hare", "Rabbit Furs"), ("deer", "Deer Hide"), ("elk", "Deer Hide"),
         ("wolf", "Wolf Pelt"), ("boar", "Boar Hide"), ("bear", "Bear Hide"), ("seal", "Seal Skin"),
         ("crocodile", "Crocodile Leather"), ("leopard", "Snow Leopard Pelt"), ("lion", "Lion's Mane"),
         ("moose", "Moose Antlers"), ("owlbear", "Owlbear Feathers"), ("spider", "Giant Spider Silk"),
         ("wyvern", "Wyvern Stinger"), ("dragon", "Dragon Scale"), ("basilisk", "Basilisk Eye"),
         ("griffon", "Griffon Feather"), ("harpy", "Harpy Feather"), ("scorpion", "Scorpion Venom Gland"),
         ("serpent", "Serpent Scale"), ("snake", "Serpent Scale"), ("raptor", "Raptor Claw"),
         ("rhino", "Woolly Rhino Horn"), ("goose", "Goose Feathers"), ("eagle", "Eagle Feathers"),
         ("hawk", "Eagle Feathers"), ("owl", "Goose Feathers"), ("vulture", "Eagle Feathers")]
SKIN_EXTRA = ["Game Meat", "Small Pelt", "Rough Hide", "Thick Hide", "Scaled Hide"]   # meat from every beast
RICH_EXTRA = ["Agate", "Turquoise", "Jade", "Moonstone", "Garnet", "Topaz"]          # gems in rich veins
MEAT_FROM = {"beast"}
SKINNABLE = {"beast", "monstrosity", "dragon"}


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


def drops_table(world) -> dict:
    """The drop table, with the world's own changes (world rule "gathering") laid over it."""
    own = (getattr(world, "rules", None) or {}).get("gathering") if world is not None else None
    if not own:
        return DROPS
    out = {k: dict(v) for k, v in DROPS.items()}
    for work, rows in own.items():
        out.setdefault(work, {}).update(rows)
    return out


def source_of(prop_id: str) -> tuple | None:
    return SOURCES.get(prop_id)


def vein_variant(x: int, y: int, seed: int, danger: int = 0) -> int:
    """Which ore a vein in the land holds (and so which picture it gets): by weight, with silver and gold
    only where the region is dangerous enough. The same in every save."""
    r = _rng("vein", seed, x, y).random()
    ok = [w if danger >= VEIN_DANGER[i] else 0 for i, w in enumerate(VEIN_WEIGHTS)]
    r *= sum(ok)
    for i, w in enumerate(ok):
        r -= w
        if r < 0:
            return i
    return 3


def ore_at(world, x: int, y: int, variant: int, danger: int = 0, rng: random.Random | None = None) -> str:
    """What comes out of a vein: what its picture shows; from silver and gold veins in the most dangerous
    places, now and then mithral."""
    name = ORE_BY_VARIANT[int(variant) % len(ORE_BY_VARIANT)]
    if int(variant) % 6 >= 4 and danger >= MITHRAL_DANGER and (rng or random).random() < MITHRAL_CHANCE:
        return "Mithral Ore"
    return name


def candidates(world, work: str, prop_id: str, land: str, season: str) -> list[tuple[str, float]]:
    table = drops_table(world).get(work, {})
    rows = None
    if work == "foraging" and prop_id in ("herb_patch",):
        rows = table.get(f"herb:{land}")
    if rows is None:
        rows = table.get(prop_id) or table.get(f"land:{land}") or table.get("*") or []
    out = []
    for name, weight, seasons in rows:
        if seasons and season not in seasons.split():
            continue
        out.append((name, float(weight)))
    return out


def pick(world, rows: list[tuple[str, float]], rng: random.Random):
    """One item (entity) by weight among those the world has; None if none."""
    have = [(world.entities.find_by_name("item", n), w) for n, w in rows]
    have = [(e, w) for e, w in have if e is not None]
    if not have:
        return None
    total = sum(w for _e, w in have)
    r = rng.random() * total
    for e, w in have:
        r -= w
        if r <= 0:
            return e
    return have[-1][0]


def out_of_season(work: str, season: str) -> str:
    if work == "fishing":
        return f"Nothing is biting here in {season.lower()}."
    return f"Nothing worth taking grows here in {season.lower()}."


def in_season(world, minutes: int, work: str, prop_id: str, land: str) -> bool:
    if work == "mining" and prop_id in ("ore_vein", "rich_vein"):
        return True
    return bool(candidates(world, work, prop_id, land, CAL.season(world, minutes)))


def season_ok(world, minutes: int, ground: str, work: str) -> tuple[bool, str]:
    if work in ("foraging", "harvesting") and ground == "snow":
        return False, "Everything is buried under the snow."
    return True, ""


def regrow_minutes(world, minutes: int, days: float) -> int:
    """Minutes until something used up grows back: its days, sooner in spring and later in winter, times the
    world rule regrow_percent."""
    k = SEASON_REGROW.get(CAL.season(world, minutes), 1.0)
    try:
        k *= float(world.rules.get("regrow_percent", 100) or 100) / 100.0
    except (TypeError, ValueError, AttributeError):
        pass
    return max(60, int(days * k * 1440))


# ----------------------------------------------------------------------------------------------------
# One try
# ----------------------------------------------------------------------------------------------------
def best_gatherer(world, state, members, work: str, skills: tuple):
    """(member, combatant, check option, bonus, tool item or None, tool speed) for whoever does it best."""
    from game import checks, condition, tools
    opts = {o["label"].lower(): o for o in checks.options(world)}
    best = None
    for m in members or []:
        if m.get("dead"):
            continue
        c = condition.combatant(world, m)
        for sk in skills:
            o = opts.get(sk)
            if o is None:
                continue
            b = checks.bonus(world, m, c, o)[0] + work_bonus(world, m, c, work)
            tool, speed = tools.best_tool(world, m, state, work)
            score = b + (2 if tool is not None else 0) + speed
            if best is None or score > best[-1]:
                best = (m, c, o, b, tool, speed, score)
    return best[:-1] if best else None


def work_bonus(world, m: dict, combatant, work: str) -> int:
    """Proficiency, expertise or mastery with the work itself (from use) adds its bonus."""
    from game import tools
    _lvl, mult = tools.level(world, m, f"work:{work}")
    return combatant.prof * mult


def attempt(world, state, members, prop_id: str, x: int, y: int, land: str, rng: random.Random | None = None,
            bus=None, weather=None, variant: int = 0, danger: int = 0, work: str = "") -> dict:
    """Try to gather from the thing at (x, y). Returns {"ok", "text", "items": [(item id, n)], "minutes",
    "used_up", "member", "work", "leave"}. Takes time; counts tool uses; does not touch the map (the caller
    marks the square used: see use_up)."""
    from game import checks, tools
    rng = rng or random.Random()
    src = SOURCES.get(prop_id) or SOURCES.get("water")
    work = work or src[0]
    if work == "skinning":
        src = ("skinning", ("survival",), 10, 15, 0, "")
    _w, skills, dc, minutes, days, leave = src
    season = CAL.season(world, state.minutes)
    ok, why = season_ok(world, state.minutes, getattr(weather, "ground", ""), work)
    if not ok:
        return {"ok": False, "text": why, "items": [], "minutes": 0, "used_up": False, "work": work}
    rows = None
    if not (work == "mining" and prop_id in ("ore_vein", "rich_vein")):
        rows = candidates(world, work, prop_id, land, season)
        if not rows:
            return {"ok": False, "text": out_of_season(work, season), "items": [], "minutes": 0,
                    "used_up": False, "work": work}
    who = best_gatherer(world, state, members, work, skills)
    if who is None:
        return {"ok": False, "text": "Nobody can do that.", "items": [], "minutes": 0, "used_up": False, "work": work}
    m, c, opt, _b, tool, speed = who
    by_hand = tool is None
    took = int(round(minutes * (HAND_TIME if by_hand else 1.0) / max(0.25, speed)))
    if work == "fishing" and weather is not None and getattr(weather, "wet", False):
        dc -= 2                                            # fish bite more in the rain
    if prop_id == "fishing_spot":
        dc -= 1
    extra = work_bonus(world, m, c, work)
    r = checks.roll(world, m, c, opt, dc, rng=rng, bus=bus, target=VERB.get(work, work).lower(),
                    context=f"work:{work}", extra=extra)
    state.advance(took, work)
    if not r.get("success"):
        return {"ok": False, "text": f"{m.get('name')} works at it for {took} minutes and gets nothing.",
                "items": [], "minutes": took, "used_up": False, "member": m, "work": work}
    over = max(0, int(r["total"]) - dc)
    if by_hand:
        n = 1
    else:
        n = max(1, int(round((1 + over // 5) * float(tool.fields.get("tool_yield") or 1.0))))
    if work == "mining" and prop_id in ("ore_vein", "rich_vein"):
        name = ore_at(world, x, y, variant if prop_id == "ore_vein" else 4 + int(rng.random() < 0.4),
                      danger + (20 if prop_id == "rich_vein" else 0), rng)
        item = world.entities.find_by_name("item", name)
        if prop_id == "rich_vein":
            n += 2
            if rng.random() < 0.25:                           # now and then a gem in the rock
                gem = world.entities.find_by_name("item", rng.choice(RICH_EXTRA))
                if gem is not None:
                    state.add_item(gem.id, 1, source=work)
    else:
        item = pick(world, rows, rng)
    if item is None:
        return {"ok": False, "text": "Nothing comes of it.", "items": [], "minutes": took, "used_up": False,
                "member": m, "work": work}
    if work in ("foraging", "harvesting", "fishing") and world.rules.get("survival") and \
            world.rules.get("forage_less"):              # lean country (game/survival.py)
        n = n // 2 if n > 1 else int(rng.random() < 0.5)
        if n <= 0:
            return {"ok": False, "text": f"{m.get('name')} works at it for {took} minutes and finds next to nothing.",
                    "items": [], "minutes": took, "used_up": False, "member": m, "work": work}
    state.add_item(item.id, n, source=work)
    tools.record_use(world, m, f"work:{work}", 1, bus)
    how = f"with {tool.name.lower()}" if tool is not None else "by hand"
    text = f"{m.get('name')} {VERB_PAST.get(work, 'gathers')} {how}: {item.name}" + (f" x{n}" if n > 1 else "") + \
        f" ({took} minutes)."
    return {"ok": True, "text": text, "items": [(item.id, n)], "minutes": took, "used_up": bool(days),
            "member": m, "work": work, "leave": leave, "days": days}


VERB_PAST = {"woodcutting": "cuts wood", "mining": "mines", "foraging": "forages", "harvesting": "harvests",
             "fishing": "fishes", "skinning": "skins the carcass"}


def use_up(world, state, level, x: int, y: int, result: dict, prop, bus=None) -> None:
    """Mark the square used: a stump, a worked-out vein, bare ground; it grows back after some days."""
    from game import landchanges
    if not result.get("used_up"):
        return
    until = state.minutes + regrow_minutes(world, state.minutes, result.get("days") or 10)
    change = {"prop": result.get("leave") or "", "variant": 0, "until": until,
              "was": {"prop": prop.id, "variant": prop.variant}}
    if getattr(level, "chunked", False):
        landchanges.record(world, state, x, y, change, bus)
    else:
        landchanges.record_level(world, state, level, x, y, change, bus)


# ----------------------------------------------------------------------------------------------------
# Skinning
# ----------------------------------------------------------------------------------------------------
def skinnable(world, enemy) -> bool:
    tags = {str(t).lower() for t in (enemy.tags or [])}
    return bool(tags & SKINNABLE) and "undead" not in tags and "construct" not in tags


def skin_item(world, enemy):
    """What comes off a beast: its own hide or part where there is one, else a hide by its size."""
    name = enemy.name.lower()
    for key, item_name in HIDES:
        if key in name:
            e = world.entities.find_by_name("item", item_name)
            if e is not None:
                return e
    tags = {str(t).lower() for t in (enemy.tags or [])}
    size = enemy.fields.get("size") or "Medium"
    if tags & {"dragon", "reptile"} or "lizard" in name or "drake" in name:
        generic = "Scaled Hide"
    elif size in ("Tiny", "Small"):
        generic = "Small Pelt"
    elif size in ("Large", "Huge", "Gargantuan"):
        generic = "Thick Hide"
    else:
        generic = "Rough Hide"
    return world.entities.find_by_name("item", generic)


def skin(world, state, members, enemies: list, rng: random.Random | None = None, bus=None) -> dict:
    """Skin the beasts a fight left behind (one try each, by the party's best hand)."""
    from game import checks, tools
    rng = rng or random.Random()
    who = best_gatherer(world, state, members, "skinning", ("survival",))
    if who is None:
        return {"ok": False, "text": "Nobody can do that.", "items": []}
    m, c, opt, _b, tool, speed = who
    got, lines, minutes = [], [], 0
    for e in enemies:
        if not skinnable(world, e):
            continue
        item = skin_item(world, e)
        if item is None:
            continue
        took = int(round(15 * (HAND_TIME if tool is None else 1.0) / max(0.25, speed)))
        minutes += took
        dc = 10 + (2 if (e.fields.get("size") or "") in ("Large", "Huge", "Gargantuan") else 0)
        r = checks.roll(world, m, c, opt, dc, rng=rng, bus=bus, target=f"skinning the {e.name.lower()}",
                        context="work:skinning", extra=work_bonus(world, m, c, "skinning"))
        if not r.get("success"):
            lines.append(f"The {e.name.lower()}'s hide is ruined.")
            continue
        n = 1 if tool is None else max(1, int(round(float(tool.fields.get("tool_yield") or 1.0))))
        state.add_item(item.id, n, source="skinning")
        tools.record_use(world, m, "work:skinning", 1, bus)
        got.append((item.id, n))
        lines.append(f"{item.name}" + (f" x{n}" if n > 1 else "") + f" from the {e.name.lower()}.")
        tags = {str(t).lower() for t in (e.tags or [])}
        meat = world.entities.find_by_name("item", "Game Meat")
        if meat is not None and tags & MEAT_FROM:                     # and meat for the pot
            k = {"Tiny": 1, "Small": 1, "Medium": 2, "Large": 4, "Huge": 8, "Gargantuan": 12}.get(
                e.fields.get("size") or "Medium", 2)
            state.add_item(meat.id, k, source="skinning")
            got.append((meat.id, k))
    if minutes:
        state.advance(minutes, "skinning")
    return {"ok": bool(got), "items": got, "text": f"{m.get('name')} skins the kills: " + " ".join(lines)
            if lines else "Nothing worth skinning.", "minutes": minutes}


# ----------------------------------------------------------------------------------------------------
# Hidden deposits
# ----------------------------------------------------------------------------------------------------
HIDDEN_CHANCE = 0.18                  # of a chunk having one
ROAD_FLOORS = {"cobble", "path", "track", "wood", "ford"}
VEIN_LANDS = {"Mountains", "Hills", "Badlands", "Desert", "Arctic"}


def hidden_in_chunk(world, cx: int, cy: int, CH: int = 32) -> tuple[int, int] | None:
    """Where a chunk's hidden deposit lies (the same in every save), or None."""
    from game import geography as G
    try:
        seed = int(G.settings(world)["seed"])
    except Exception:  # noqa: BLE001
        seed = 0
    r = _rng("hidden", seed, cx, cy)
    if r.random() >= HIDDEN_CHANCE:
        return None
    return cx * CH + r.randrange(2, CH - 2), cy * CH + r.randrange(2, CH - 2)


def hidden_kind(land: str) -> str:
    return "rich_vein" if land in VEIN_LANDS else "rare_herbs"


def reveal_near(world, state, level, x: int, y: int, radius: int = 24, bus=None, land_at=None) -> list:
    """Show the hidden deposits within reach of a point (a successful search; a rumor). Returns
    [(x, y, kind)] newly revealed."""
    from game import landchanges
    CH = landchanges.CH
    out = []
    for cy in range((y - radius) // CH, (y + radius) // CH + 1):
        for cx in range((x - radius) // CH, (x + radius) // CH + 1):
            spot = hidden_in_chunk(world, cx, cy, CH)
            if spot is None:
                continue
            hx, hy = spot
            if (hx - x) ** 2 + (hy - y) ** 2 > radius * radius:
                continue
            if landchanges.change_at(state, hx, hy) is not None:
                continue                                    # already found (or dug out)
            if level.blocks(hx, hy) or (hx, hy) in level.prop_cells or level.floor_at(hx, hy) in ROAD_FLOORS:
                continue                                    # (not out in the open, nor on a road)
            land = land_at(hx, hy) if land_at is not None else "Hills"
            kind = hidden_kind(land)
            landchanges.record(world, state, hx, hy, {"prop": kind, "variant": 0, "found": True}, bus)
            out.append((hx, hy, kind))
    return out


__all__ = ["vein_variant", "MAX_TRIES", "SOURCES", "DROPS", "attempt", "use_up", "skin", "skinnable", "skin_item", "candidates", "ore_at",
           "hidden_in_chunk", "reveal_near", "best_gatherer", "VERB", "NOISY", "drops_table"]
