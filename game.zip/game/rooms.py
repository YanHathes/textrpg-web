"""Rooms: the tileset every building and dungeon is made from, and the generator that grows layouts.

A *tile* is a kind of room: its size (in 5-foot squares), where its doors are, which floors it can be
on, which kinds of place use it, how many of it a place may have, and what's in it (a bar, beds, a forge).
The built-in tiles are below; a world can add its own as "room" entities (Create > Room), and those
override built-ins of the same name.

Doors are written as sides with an optional offset along the side, in squares from the top/left:
    "N S E W"                      one door in the middle of each side
    "S N@2 N@7 W E"                two doors on the north side
A tile can also have stairs: "Up" (the floor above starts here), "Down" (the floor below), or "Both".

A *layout* is saved on the building or dungeon as its "rooms" table, one row per room:
    {"name", "type" (the room's role), "tile", "floor", "x", "y", "w", "h", "connects", "description", ...}
Rooms link through doors that meet, and stairs link floors. The first row is the entrance.

The generator starts with an entrance tile and keeps attaching tiles to open doorways (rotating them as
needed), honouring each tile's floor, its min/max count and the place's footprint: upper floors and
cellars stay inside the ground floor's walls. The same attaching is what the room editor (and a
player building onto their home) uses.
"""
from __future__ import annotations

import random
import zlib

# ----------------------------------------------------------------------
# Kinds of place
# ----------------------------------------------------------------------
BUILDING_KINDS = ["Shop", "Tavern", "Inn", "Temple", "Smithy", "Guild hall", "House", "Town hall", "Barracks",
                  "Warehouse", "Library", "Stable", "Market", "Mansion", "Castle", "College", "Boatwright", "Bank",
                  "Casino", "Arena", "Jail", "Brothel", "Other"]
DUNGEON_KINDS = ["Cave", "Mine", "Lair", "Crypt", "Ruins", "Tower", "Sewer", "Temple", "Fortress", "Other"]
ROLES = ["Entrance", "Common", "Private", "Service", "Storage", "Work", "Hall", "Stairs", "Yard", "Special",
         "Room", "Hallway", "Chamber", "Treasure room", "Boss"]
FLOORS = ["Any", "Ground", "Upper", "Cellar", "Ground or upper"]
FEATURES = ["bar", "counter", "forge", "altar", "beds", "hearth", "tables", "shelves", "crates", "pews", "stalls",
            "racks", "desk", "bath", "throne", "door", "vault", "cot", "evidence"]
PERKS = ["", "Rest", "Healing", "Income", "Storage", "Training", "Crafting"]
# room counts (low, high) and ground-floor footprint (squares) by kind
COUNTS = {"House": (3, 6), "Shop": (2, 5), "Market": (3, 6), "Warehouse": (3, 5), "Smithy": (2, 4),
          "Tavern": (5, 9), "Inn": (10, 22), "Temple": (4, 9), "Town hall": (5, 10), "Guild hall": (6, 12),
          "Library": (4, 9), "College": (6, 12), "Boatwright": (2, 4), "Bank": (3, 6), "Casino": (4, 8), "Arena": (3, 6), "Barracks": (5, 10), "Stable": (3, 5), "Mansion": (24, 48), "Castle": (30, 60),
          "Jail": (6, 10), "Brothel": (20, 34),
          "Other": (2, 4)}
FOOTPRINT = {"House": (16, 13), "Shop": (16, 13), "Market": (26, 20), "Warehouse": (24, 18), "Smithy": (20, 16),
             "Tavern": (24, 20), "Inn": (26, 22), "Temple": (24, 28), "Town hall": (26, 22), "Guild hall": (26, 22),
             "Library": (24, 20), "College": (28, 22), "Boatwright": (22, 16), "Bank": (22, 18), "Casino": (28, 22),
             "Jail": (30, 16), "Brothel": (26, 22),
             "Arena": (34, 28), "Barracks": (26, 22), "Stable": (22, 16), "Mansion": (42, 32),
             "Castle": (56, 56), "Other": (16, 13)}
DUNGEON_COUNTS = {"Small": 8, "Medium": 13, "Large": 20}
TOWER_FLOORS = {"Small": 4, "Medium": 6, "Large": 8}
# how a building's rooms spread over its floors (the rest follows wherever doors lead)
FLOOR_SHARE = {"Inn": {0: 0.35, 1: 0.55, -1: 0.1}, "Brothel": {0: 0.4, 1: 0.6}, "Mansion": {0: 0.45, 1: 0.45, -1: 0.1},
               "Castle": {0: 0.55, 1: 0.35, -1: 0.1}, "House": {0: 0.65, 1: 0.35},
               "Guild hall": {0: 0.7, 1: 0.3}, "Town hall": {0: 0.7, 1: 0.3}, "Tavern": {0: 0.8, -1: 0.2},
               "Temple": {0: 0.8, -1: 0.2}, "Barracks": {0: 0.7, 1: 0.3}, "Library": {0: 0.6, 1: 0.4},
               "College": {0: 0.6, 1: 0.4}}
BUILDING_SCALE = {"Small": 0.0, "Medium": 0.5, "Large": 1.0}
TOWER_FOOTPRINT = (10, 10)

B = "*building"
D = "*dungeon"
ANY_HOUSE = ["House", "Mansion"]


def T(name, role, used_in, w, h, doors="N S E W", floor="Any", stairs="", mn=0, mx=0, weight=1.0, features=(),
      scene="", cost=0, days=0, perk="", names=(), desc="", fixed=False):
    return {"name": name, "role": role, "used_in": list(used_in), "w": w, "h": h, "doors": doors, "floor": floor,
            "stairs": stairs, "min": mn, "max": mx, "weight": weight, "features": list(features), "scene": scene,
            "cost": cost, "days": days, "perk": perk, "names": list(names), "description": desc, "fixed": fixed}


UPPER_ALL = ["Inn", "Brothel", "Mansion", "Castle", "Guild hall", "Town hall", "Library", "College", "Barracks", "House", "Shop",
             "Temple"]
CELLAR_ALL = ["Tavern", "Inn", "Mansion", "Castle", "House", "Temple"]

TILES: list[dict] = [
    # ---------------- entrances
    T("Common Room", "Entrance", ["Tavern", "Inn"], 12, 10, "S N@3 N@9 E W", "Ground", mn=1, mx=1,
      features=["bar", "tables", "hearth"], scene="Tavern", desc="Long tables, a crackling hearth and a bar along "
      "one wall. The heart of the place."),
    T("Parlour", "Entrance", ["Brothel"], 12, 10, "S N@3 N@9 E W", "Ground", mn=1, mx=1,
      features=["bar", "tables", "hearth"], scene="Tavern", desc="Red lamps, deep couches, a bar of good wine and "
      "a madam who misses nothing."),
    T("Front Room", "Entrance", ["House"], 7, 6, "S N E W", "Ground", mn=1, mx=1, features=["tables", "hearth"],
      scene="House", desc="A table, a few chairs and a hearth."),
    T("Entry Hall", "Entrance", ["Town hall", "Guild hall", "Library", "College", "Barracks", "Other"], 6, 6, "S N E W",
      "Ground", mn=1, mx=1, desc="A plain hall just inside the doors."),
    T("Front Hall", "Entrance", ["Mansion"], 8, 7, "S N E W", "Ground", mn=1, mx=1, scene="House",
      desc="A tiled hall with a sweeping view of the house beyond."),
    T("Shop Floor", "Entrance", ["Shop"], 10, 8, "S N E W", "Ground", mn=1, mx=1, features=["counter", "shelves"],
      scene="Shop", desc="Shelves of wares and a well-worn counter."),
    T("Market Hall", "Entrance", ["Market"], 16, 12, "S N E W N@4 N@12", "Ground", mn=1, mx=1,
      features=["stalls", "counter"], scene="Market", desc="A busy roofed hall of stalls and hawkers."),
    T("Forge", "Entrance", ["Smithy"], 10, 8, "S N E W", "Ground", mn=1, mx=1, features=["forge", "counter"],
      scene="Smithy", desc="The roar of the forge, the ring of the anvil and the smell of hot iron."),
    T("Nave", "Entrance", ["Temple"], 10, 16, "S N E W W@4 E@4", "Ground", mn=1, mx=1, features=["pews"],
      scene="Temple", desc="Rows of pews lead toward the sanctuary."),
    T("Warehouse Floor", "Entrance", ["Warehouse"], 14, 10, "S N E W", "Ground", mn=1, mx=1, features=["crates"],
      scene="Warehouse", desc="Stacked crates, bales and barrels."),
    T("Gaming Floor", "Entrance", ["Casino"], 14, 10, "S N E W", "Ground", mn=1, mx=1, features=["tables", "bar"],
      scene="Tavern", desc="Lamplight on green cloth, the rattle of dice and the whirr of the wheel."),
    T("Card Room", "Common", ["Casino"], 9, 7, "S N E W", "Any", mn=1, mx=2, features=["tables"], scene="Tavern",
      desc="Round tables, quiet players and a haze of pipe smoke."),
    T("Cashier's Cage", "Work", ["Casino"], 5, 5, "N S E W", "Ground", mn=1, mx=1, features=["counter"],
      desc="Chips for coin and coin for chips, behind iron bars."),
    T("Arena Floor", "Entrance", ["Arena"], 16, 12, "S N E W N@4 N@12", "Ground", mn=1, mx=1, features=["pillars"],
      scene="Barracks", desc="Raked sand, dark in places, and tiers of benches all round."),
    T("Stands", "Common", ["Arena"], 16, 5, "S N E W", "Any", mn=1, mx=2, features=["pews"], scene="Barracks",
      desc="Benches stacked high above the sand, and a crowd that wants blood."),
    T("Fighters' Quarters", "Private", ["Arena"], 7, 6, "S N E W", "Ground", mx=2, features=["beds", "racks"],
      desc="Cots, a rack of practice blades and the smell of liniment."),
    T("Banking Hall", "Entrance", ["Bank"], 12, 8, "S N E W", "Ground", mn=1, mx=1, features=["counter", "tables"],
      scene="Town hall", desc="Tellers behind brass grilles, ledgers, and a guard who watches the door."),
    T("Strongroom", "Storage", ["Bank"], 5, 5, "N S E W", "Ground", mn=1, mx=1, features=["vault"],
      desc="Iron-bound strongboxes behind a door as thick as a fist is long."),
    T("Boat Shed", "Entrance", ["Boatwright"], 14, 10, "S N E W", "Ground", mn=1, mx=1, features=["crates", "racks"],
      scene="Warehouse", desc="A hull on the stocks, ribs bare, and the smell of pitch and shavings."),
    T("Stable Yard", "Entrance", ["Stable"], 12, 8, "S N E W", "Ground", mn=1, mx=1, features=["stalls"],
      scene="Stable", desc="Straw, horses and the smell of both."),
    T("Gatehouse", "Entrance", ["Castle"], 8, 8, "S N E W", "Ground", mn=1, mx=1, features=["racks"],
      scene="Barracks", desc="Murder holes above, a portcullis behind and guards on watch."),
    # ---------------- common rooms
    T("Great Hall", "Common", ["Guild hall", "Mansion", "Castle"], 12, 10, "S N E W N@3 N@9", "Ground", mx=1,
      weight=2, features=["tables", "hearth"], scene="Guild hall", desc="A high-roofed hall with long tables."),
    T("Dining Room", "Common", ["Mansion", "Castle", "Inn"], 10, 6, "S N E W", "Ground", mx=1,
      features=["tables"], desc="A polished table set for many guests."),
    T("Drawing Room", "Common", ["Mansion"], 7, 6, "S N E W", "Ground or upper", mx=3, features=["tables"],
      desc="Soft chairs, a card table and a view of the gardens."),
    T("Meeting Room", "Common", ["Guild hall", "Town hall"], 8, 6, "S N E W", "Any", mx=2, features=["tables"],
      desc="A long table and too many chairs."),
    T("Council Chamber", "Common", ["Town hall"], 10, 8, "S N E W", "Any", mn=1, mx=1, features=["tables", "desk"],
      scene="Town hall", desc="Benches face a raised table where the council sits."),
    T("Mess Hall", "Common", ["Barracks", "Castle"], 10, 8, "S N E W", "Ground", mx=1, features=["tables"],
      desc="Trestle tables and the smell of stew."),
    T("Lecture Hall", "Common", ["College"], 10, 8, "S N E W", "Any", mn=1, mx=2, features=["tables", "desk"],
      scene="Library", desc="Benches in rising rows, and a lectern worn smooth by a century of elbows."),
    T("Reading Room", "Common", ["Library", "College"], 10, 8, "S N E W", "Any", mn=1, mx=2, features=["desk", "tables"],
      scene="Library", desc="Quiet tables under tall windows."),
    T("Stall Row", "Common", ["Market"], 12, 4, "W E N@6 S@6", "Ground", mx=3, features=["stalls"],
      desc="A row of stalls under an awning."),
    T("Stalls", "Common", ["Stable"], 10, 6, "S N E W", "Ground", mx=3, features=["stalls"],
      desc="A row of horse stalls."),
    T("Courtyard", "Yard", ["Castle"], 14, 14, "S N E W N@3 N@11 S@3 S@11", "Ground", mn=1, mx=1,
      desc="An open courtyard inside the walls."),
    # ---------------- private rooms
    T("Guest Room", "Private", ["Inn"], 4, 5, "S N", "Upper", mn=4, mx=30, weight=12, features=["beds"],
      scene="Inn", desc="A narrow bed, a washstand and a shuttered window."),
    T("Private Room", "Private", ["Brothel"], 4, 5, "S N", "Ground or upper", mn=12, mx=40, weight=20,
      features=["beds"], scene="Inn", desc="A wide bed, a curtain, a lamp turned low, and a floorboard that squeaks."),
    T("Private Suite", "Private", ["Inn", "Mansion", "Brothel"], 7, 5, "S N", "Upper", mx=2, features=["beds", "hearth"],
      scene="Inn", desc="A finer room with a real bed and its own hearth."),
    T("Bedroom", "Private", ["House", "Mansion", "Castle", "Shop"], 5, 5, "S N E W", "Ground or upper", mx=12,
      weight=3, features=["beds"], scene="House", cost=120, days=4, perk="Rest",
      desc="A bed, a chest and a small window."),
    T("Master Bedroom", "Private", ["House", "Mansion", "Castle"], 7, 6, "S N E W", "Ground or upper", mx=1,
      features=["beds", "hearth"], scene="House", cost=250, days=6, perk="Rest",
      desc="A great bed under a canopy, and a fire to warm it."),
    T("Servants' Quarters", "Private", ["Mansion", "Castle"], 6, 5, "S N E W", "Any", mx=3, features=["beds"],
      desc="Bunks and plain chests for the household staff."),
    T("Bunk Room", "Private", ["Barracks", "Castle"], 8, 6, "S N E W", "Any", mn=1, mx=4, weight=3,
      features=["beds"], scene="Barracks", desc="Rows of bunks and footlockers."),
    T("Captain's Quarters", "Private", ["Barracks", "Castle"], 5, 5, "S N E W", "Any", mx=1, features=["beds", "desk"],
      desc="A cot, a desk covered in duty rosters, a sword on the wall."),
    T("Priests' Cell", "Private", ["Temple"], 4, 4, "S N E W", "Any", mx=4, features=["beds"],
      desc="Bare walls, a cot and a holy symbol."),
    T("Shopkeeper's Room", "Private", ["Shop", "Smithy"], 5, 5, "S N E W", "Upper", mx=1, features=["beds"],
      desc="Where the owner sleeps above the shop."),
    T("Hostler's Room", "Private", ["Stable"], 4, 4, "S N E W", "Any", mx=1, features=["beds"],
      desc="A cot and a lantern for whoever minds the horses."),
    T("Lodger's Room", "Private", ANY_HOUSE, 4, 5, "S N", "Any", mx=6, features=["beds"], cost=150, days=4,
      perk="Income", desc="A small room let out to a lodger."),
    # ---------------- service, storage, work
    T("Kitchen", "Service", ["Tavern", "Inn", "House", "Mansion", "Castle", "Barracks"], 6, 6, "W E N S", "Ground",
      mx=1, weight=3, features=["hearth", "tables"], cost=150, days=5, perk="Rest",
      desc="Pots, a great hearth and a scrubbed table."),
    T("Pantry", "Storage", ["Tavern", "Inn", "House", "Mansion", "Castle"], 4, 4, "N S E W", "Ground", mx=2,
      features=["shelves"], cost=50, days=2, desc="Sacks, jars and hanging hams."),
    T("Storeroom", "Storage", ["Shop", "Smithy", "Warehouse", "Market", "Tavern", "Inn", "Guild hall", "Town hall",
                               "Barracks", "Temple", "Castle", "Other"], 6, 5, "N S E W", "Any", mx=3, weight=2,
      features=["crates"], desc="Crates, barrels and dust."),
    T("Back Room", "Storage", ["Shop"], 5, 5, "N S E W", "Ground", mx=1, features=["crates", "shelves"],
      desc="Stock waiting to go out on the shelves."),
    T("Bath", "Service", ["Mansion", "Castle", "Inn", "House", "Brothel"], 4, 4, "N S E W", "Any", mx=2, features=["bath"],
      cost=120, days=4, perk="Rest", desc="A copper tub and a stove to heat the water."),
    T("Office", "Work", ["Warehouse", "Town hall", "Guild hall", "Market", "Barracks", "Library", "College", "Castle",
                         "Boatwright", "Bank"], 5, 5,
      "N S E W", "Any", mx=2, features=["desk"], desc="A desk buried in ledgers."),
    T("Guildmaster's Office", "Work", ["Guild hall"], 6, 5, "N S E W", "Any", mn=1, mx=1, features=["desk"],
      desc="A grand desk, a strongbox and portraits of past masters."),
    T("Vault", "Storage", ["Guild hall", "Castle", "Mansion", "House"], 4, 4, "N", "Any", mx=1,
      features=["crates"], cost=250, days=6, perk="Storage", desc="Iron door, iron walls, iron lock."),
    T("Training Room", "Work", ["Guild hall", "Barracks", "Castle", "Mansion"], 8, 8, "S N E W", "Ground", mx=1,
      features=["racks"], cost=300, days=7, perk="Training", desc="Practice dummies, racks of blunted weapons."),
    T("Records Room", "Storage", ["Town hall"], 6, 6, "N S E W", "Any", mx=2, features=["shelves"],
      desc="Shelves of deeds, tax rolls and old judgements."),
    T("Clerk's Office", "Work", ["Town hall"], 5, 5, "N S E W", "Any", mx=1, features=["desk"],
      desc="Where permits are stamped and complaints filed."),
    T("Jail Cell", "Special", ["Town hall", "Barracks", "Castle"], 4, 4, "N", "Any", mx=3,
      desc="A barred cell with a bucket and a bench."),
    T("Armory", "Storage", ["Barracks", "Castle"], 6, 6, "N S E W", "Any", mx=1, features=["racks"],
      desc="Racks of spears, shields and crossbows."),
    T("Smelting Room", "Work", ["Smithy"], 6, 6, "N S E W", "Ground", mx=1, features=["forge"],
      desc="A smelter and moulds for casting."),
    T("Workshop", "Work", ["Shop", "Smithy", "House", "Mansion", "Guild hall"], 6, 6, "N S E W", "Any", mx=2,
      features=["tables"], cost=200, days=5, perk="Crafting", desc="Benches, tools and half-finished work."),
    T("Yard", "Yard", ["Smithy", "Stable", "House", "Warehouse", "Boatwright"], 8, 8, "N S E W", "Ground", mx=1,
      features=["crates"], desc="A walled yard open to the sky."),
    T("Herb Garden", "Yard", ANY_HOUSE, 8, 8, "N S E W", "Ground", mx=1, cost=80, days=3, perk="Income",
      desc="Neat beds of herbs and a sundial."),
    T("Loading Dock", "Yard", ["Warehouse", "Market"], 10, 5, "N S E W", "Ground", mx=1, features=["crates"],
      desc="Wide doors where carts unload."),
    T("Tack Room", "Storage", ["Stable"], 4, 5, "N S E W", "Any", mx=1, features=["racks"],
      desc="Saddles, bridles and harness on pegs."),
    T("Stacks", "Storage", ["Library", "College"], 8, 6, "N S E W", "Any", mn=1, mx=4, weight=2, features=["shelves"],
      desc="Tall shelves of books."),
    T("Study", "Work", ["Library", "College", "Mansion", "House"], 5, 5, "N S E W", "Any", mx=2, features=["desk", "shelves"],
      cost=200, days=5, desc="A writing desk and a reading lamp."),
    T("Scriptorium", "Work", ["Library", "College", "Temple"], 8, 6, "N S E W", "Any", mx=1, features=["desk", "tables"],
      desc="Copyists' desks under good light."),
    T("Archive", "Storage", ["Library", "College", "Temple", "Town hall"], 6, 6, "N S E W", "Any", mx=1, features=["shelves"],
      desc="Locked cases of rare books and old records."),
    T("Private Library", "Work", ANY_HOUSE + ["Castle"], 6, 6, "N S E W", "Any", mx=1, features=["shelves"],
      cost=400, days=8, perk="Training", desc="Floor-to-ceiling shelves and a rolling ladder."),
    # ---------------- temples
    T("Sanctuary", "Special", ["Temple"], 6, 6, "S N E W", "Ground", mn=1, mx=1, features=["altar"], scene="Temple",
      desc="The altar, candles and the holy of holies."),
    T("Chapel", "Special", ["Temple", "Castle", "Mansion"], 6, 6, "S N E W", "Any", mx=2, features=["altar"],
      scene="Temple", desc="A small chapel for quiet prayer."),
    T("Vestry", "Storage", ["Temple"], 4, 4, "N S E W", "Any", mx=1, features=["shelves"],
      desc="Robes, candles and holy oils."),
    T("Home Shrine", "Special", ANY_HOUSE, 5, 5, "S N E W", "Any", mx=1, features=["altar"], cost=300, days=6,
      perk="Healing", desc="A small shrine with a candle that never seems to burn down."),
    # ---------------- grand rooms
    T("Ballroom", "Special", ["Mansion", "Castle"], 14, 10, "S N E W", "Ground", mx=1,
      desc="A sprung floor, mirrors and chandeliers."),
    T("Conservatory", "Special", ["Mansion"], 8, 6, "S N E W", "Ground", mx=1,
      desc="Glass walls and exotic plants."),
    T("Throne Room", "Special", ["Castle"], 12, 10, "S N", "Any", mx=1, features=["throne"],
      desc="Banners, a long carpet and the throne at its end."),
    T("Gallery", "Hall", ["Mansion", "Castle"], 12, 4, "W E N@3 N@9 S@3 S@9", "Any", mx=4,
      desc="A long hall hung with portraits."),
    # ---------------- halls and stairs (buildings)
    T("Upper Hall", "Hall", UPPER_ALL, 3, 12, "N S W@2 W@6 W@10 E@2 E@6 E@10", "Upper", mx=4, weight=3,
      cost=120, days=3, desc="A narrow hall lined with doors."),
    T("Corridor", "Hall", ["Mansion", "Castle", "Guild hall", "Town hall", "Barracks", "Inn", "Brothel"], 3, 10,
      "N S W@2 W@7 E@2 E@7", "Any", mx=4, weight=1.5, desc="A plain corridor."),
    T("Stairs Up", "Stairs", UPPER_ALL, 4, 4, "N S E W", "Ground or upper", stairs="Up", mx=2, weight=2,
      cost=200, days=4, desc="A staircase climbing to the floor above."),
    T("Landing", "Stairs", UPPER_ALL, 4, 4, "N S E W", "Upper", stairs="Down", mx=4,
      desc="The top of the stairs."),
    T("Cellar Stairs", "Stairs", CELLAR_ALL, 4, 4, "N S E W", "Ground", stairs="Down", mx=1, cost=150, days=4,
      desc="Steps down into the dark."),
    T("Cellar", "Stairs", CELLAR_ALL, 4, 4, "N S E W", "Cellar", stairs="Up", mx=1,
      desc="The foot of the cellar stairs. It's cool and damp."),
    T("Wine Cellar", "Storage", ["Tavern", "Inn", "Mansion", "Castle"], 8, 6, "N S E W", "Cellar", mx=2,
      features=["crates"], desc="Racks of bottles and great casks."),
    T("Cellar Storeroom", "Storage", CELLAR_ALL, 6, 6, "N S E W", "Cellar", mx=2, features=["crates"],
      cost=100, days=3, perk="Storage", desc="Barrels, sacks and cobwebs."),
    T("Crypt", "Special", ["Temple", "Castle"], 8, 8, "N S E W", "Cellar", mx=1,
      desc="Stone tombs of priests and patrons."),
    T("Dungeon Cells", "Special", ["Castle"], 8, 6, "N S E W", "Cellar", mx=1,
      desc="Damp cells and rusting chains."),

    # ---------------- a jail (game/jail.py): laid out by jail_rows, not grown
    T("Guardroom", "Entrance", ["Jail"], 8, 6, "S N E W", "Ground", mn=1, mx=1, features=["desk", "racks"],
      scene="Barracks", desc="A desk, a rack of cudgels and a ring of keys on a nail. Someone is always on watch."),
    T("Cell Block", "Hall", ["Jail"], 20, 3, "N S", "Ground", mn=1, mx=1, scene="Barracks",
      desc="A cold passage of iron-bound doors, each with a grille."),
    T("Cell", "Private", ["Jail"], 5, 5, "S", "Ground", mn=3, mx=6, features=["cot"], scene="Barracks",
      desc="Stone walls, a straw cot and a bucket. Strange marks are cut into the stone round the door."),
    T("Evidence Room", "Storage", ["Jail"], 6, 6, "W", "Ground", mx=1, features=["evidence", "crates"],
      scene="Barracks", desc="Shelves of confiscated goods, each bundle tagged with a name."),
    T("Warden's Office", "Work", ["Jail"], 6, 6, "E", "Ground", mx=1, features=["desk"], scene="Barracks",
      desc="Ledgers of the condemned and the released."),

    # ---------------- dungeons
    T("Dungeon Entrance", "Entrance", [D], 8, 8, "S N E W", "Ground", mn=1, mx=1,
      desc="The way in. Daylight fades behind you."),
    T("Room", "Room", [D], 10, 8, "N S E W", "Any", weight=6),
    T("Small Room", "Room", [D], 6, 6, "N S E W", "Any", weight=3),
    T("Hallway", "Hallway", [D], 3, 14, "N S W@7 E@7", "Any", mn=1, weight=2.5),
    T("Chamber", "Chamber", [D], 16, 14, "N S E W N@4 S@12", "Any", mn=1, weight=1),
    T("Treasure Room", "Treasure room", [D], 6, 6, "S", "Any", mn=1, weight=1),
    T("Special Room", "Special", [D], 10, 8, "N S", "Any", mn=1, weight=1.2),
    T("Boss Chamber", "Boss", [D], 16, 14, "S", "Any", mx=1),
    T("Stairs Down", "Stairs", ["Mine", "Crypt", "Fortress", "Sewer", "Temple", "Ruins", "Cave", "Lair"], 6, 6,
      "N S E W", "Any", stairs="Down", mx=1, weight=0.8, desc="Steps lead down to a deeper level."),
    T("Stairs Foot", "Stairs", ["Mine", "Crypt", "Fortress", "Sewer", "Temple", "Ruins", "Cave", "Lair"], 6, 6,
      "N S E W", "Cellar", stairs="Up", mx=2, desc="The foot of the stairs, a level deeper."),
    T("Tower Door", "Entrance", ["Tower"], 10, 10, "S", "Ground", stairs="Up", mn=1, mx=1, fixed=True,
      desc="The tower's ground floor, a stair spiralling up the wall."),
    T("Tower Room", "Room", ["Tower"], 10, 10, "", "Upper", stairs="Both", weight=4, fixed=True,
      desc="A round room on the tower stair."),
    T("Tower Top", "Boss", ["Tower"], 10, 10, "", "Upper", stairs="Down", mx=1, fixed=True,
      desc="The top of the tower, open to the wind."),
]
TILE_BY_NAME = {t["name"]: t for t in TILES}


# ======================================================================
# Tiles
# ======================================================================
def _clean(t: dict) -> dict:
    out = dict(T("", "Room", [], 6, 6))
    out.update({k: v for k, v in t.items() if v is not None})
    out["w"], out["h"] = max(1, int(out["w"] or 1)), max(1, int(out["h"] or 1))
    out["used_in"] = list(out.get("used_in") or [])
    out["features"] = list(out.get("features") or [])
    out["names"] = list(out.get("names") or [])
    return out


def world_tiles(world) -> list[dict]:
    """The world's own tiles (room entities)."""
    out = []
    try:
        ents = world.entities.all("room") if world is not None else []
    except (KeyError, ValueError):
        ents = []
    for e in ents:
        f = e.fields
        used = [{"Any building": B, "Any dungeon": D}.get(u, u) for u in f.get("used_in") or []]
        out.append(_clean({"name": e.name, "role": f.get("role") or "Room", "used_in": used,
                           "w": f.get("w") or 6, "h": f.get("h") or 6, "doors": f.get("doors") or "N S E W",
                           "floor": f.get("floor") or "Any", "stairs": f.get("stairs") or "",
                           "min": int(f.get("min_count") or 0), "max": int(f.get("max_count") or 0),
                           "weight": float(f.get("weight") or 1), "features": f.get("features") or [],
                           "scene": f.get("scene") or "", "cost": float(f.get("cost") or 0),
                           "days": int(f.get("build_days") or 0), "perk": f.get("perk") or "",
                           "names": f.get("names") or [], "description": e.description, "fixed": False,
                           "id": e.id, "materials": f.get("materials") or []}))
    return out


_TILES_CACHE: dict = {}


def all_tiles(world) -> list[dict]:
    """Every room tile: the world's own, then the built-in ones it hasn't replaced. Worked out once until
    the world's room tiles change (they're read for every room of every building made)."""
    try:
        ents = world.entities.all("room") if world is not None else []
    except (KeyError, ValueError):
        ents = []
    key = (id(world), len(ents), max((e.modified or "" for e in ents), default=""),
           tuple(e.id for e in ents[:3]))
    hit = _TILES_CACHE.get(id(world))
    if hit is not None and hit[0] == key:
        return list(hit[1])
    mine = world_tiles(world)
    names = {t["name"] for t in mine}
    out = mine + [_clean(t) for t in TILES if t["name"] not in names]
    _TILES_CACHE[id(world)] = (key, out, {t["name"]: t for t in out})
    return list(out)


def is_dungeon_kind(kind: str, category: str = "") -> bool:
    return category == "dungeon" or (category != "building" and kind in DUNGEON_KINDS and kind not in BUILDING_KINDS)


REQUIRED = {"Inn": ["Stairs Up"], "Brothel": ["Stairs Up"], "Mansion": ["Stairs Up", "Kitchen"], "Castle": ["Stairs Up", "Kitchen"],
            "Tavern": ["Kitchen"], "Guild hall": ["Great Hall"]}


def tiles_for(world, kind: str, category: str = "building") -> list[dict]:
    """Tiles a place of this kind may use."""
    star = D if category == "dungeon" else B
    out = []
    must = REQUIRED.get(kind, []) if category == "building" else []
    for t in all_tiles(world):
        if t["name"] in must:
            t = dict(t, min=max(1, int(t.get("min") or 0)))
        used = t["used_in"]
        if kind in used or star in used:
            if category == "dungeon" and kind == "Tower" and star in used and t["role"] in ("Entrance", "Boss",
                                                                                           "Room", "Hallway",
                                                                                           "Chamber"):
                continue                                   # towers use their own stacked rooms
            out.append(t)
    return out


def tile(world, name: str) -> dict | None:
    all_tiles(world)
    return _TILES_CACHE[id(world)][2].get(name)


# ======================================================================
# Doors and geometry
# ======================================================================
OPP = {"N": "S", "S": "N", "E": "W", "W": "E"}


def doors_of(t: dict, w: int | None = None, h: int | None = None) -> list[tuple[str, int]]:
    """[(side, offset)] for a tile (offset in squares from the top/left of that side)."""
    w = t["w"] if w is None else w
    h = t["h"] if h is None else h
    out = []
    for tok in str(t.get("doors") or "").replace(",", " ").split():
        side, _s, off = tok.partition("@")
        side = side.strip().upper()[:1]
        if side not in OPP:
            continue
        length = w if side in "NS" else h
        try:
            o = int(off) if off else length // 2
        except ValueError:
            o = length // 2
        out.append((side, max(0, min(length - 1, o))))
    return out


ROT = {"N": "E", "E": "S", "S": "W", "W": "N"}           # a quarter turn clockwork


def rotated(t: dict, quarter: int) -> dict:
    """The tile turned clockwise a quarter turn `quarter` times (doors move with it)."""
    quarter %= 4
    if quarter == 0 or t.get("fixed"):
        return dict(t, rot=0)
    w, h = t["w"], t["h"]
    doors = doors_of(t)
    for _ in range(quarter):
        nd = []
        for side, o in doors:
            # clockwise: N(x along w) -> E(y along new h = w); E(y) -> S(x' = h-1-y); S(x) -> W(y' = w-1-x)...
            if side == "N":
                nd.append(("E", o))
            elif side == "E":
                nd.append(("S", h - 1 - o))
            elif side == "S":
                nd.append(("W", o))
            else:
                nd.append(("N", h - 1 - o))
        doors = nd
        w, h = h, w
    return dict(t, w=w, h=h, doors=" ".join(f"{s}@{o}" for s, o in doors), rot=quarter)


def door_point(x: int, y: int, w: int, h: int, side: str, off: int) -> tuple[float, float]:
    """The middle of a doorway on the room's edge (in squares)."""
    if side == "N":
        return (x + off + 0.5, y)
    if side == "S":
        return (x + off + 0.5, y + h)
    if side == "E":
        return (x + w, y + off + 0.5)
    return (x, y + off + 0.5)


def _overlaps(a, b) -> bool:
    return a[0] < b[0] + b[2] and b[0] < a[0] + a[2] and a[1] < b[1] + b[3] and b[1] < a[1] + a[3]


def floor_allowed(t: dict, floor: int, category: str = "dungeon") -> bool:
    f = t.get("floor") or "Any"
    if f == "Any":
        # in a building, only cellar rooms (and storerooms) go below ground
        return floor >= 0 or category == "dungeon" or t.get("role") in ("Storage", "Stairs")
    if f == "Ground":
        return floor == 0
    if f == "Upper":
        return floor > 0
    if f == "Cellar":
        return floor < 0
    if f == "Ground or upper":
        return floor >= 0
    return True


# ======================================================================
# Layouts
# ======================================================================
class Layout:
    """Rooms being put together. Each room: dict(name, type, tile, floor, x, y, w, h, doors (list), links (set),
    used (set of door indexes))."""

    def __init__(self, kind: str, category: str, footprint: tuple | None = None, rng=None):
        self.kind, self.category = kind, category
        self.footprint = footprint
        self.rng = rng or random.Random()
        self.rooms: list[dict] = []
        self.target = 0                                  # rooms wanted (0: no limit)

    # ---- what's where
    def on_floor(self, floor: int) -> list[dict]:
        return [r for r in self.rooms if r["floor"] == floor]

    def count(self, tile_name: str) -> int:
        return sum(1 for r in self.rooms if r["tile"] == tile_name)

    def _ground_box(self, floor: int) -> tuple | None:
        """The area an upper floor (or cellar) must stay inside: the walls of the floor nearer the ground."""
        if self.category != "building" or floor == 0:
            return None
        below = floor - 1 if floor > 0 else floor + 1
        rs = self.on_floor(below)
        if not rs:
            return None
        return (min(r["x"] for r in rs), min(r["y"] for r in rs), max(r["x"] + r["w"] for r in rs),
                max(r["y"] + r["h"] for r in rs))

    def fits(self, rect: tuple, floor: int) -> bool:
        for r in self.on_floor(floor):
            if _overlaps(rect, (r["x"], r["y"], r["w"], r["h"])):
                return False
        if self.footprint is not None:
            rs = self.on_floor(floor) or self.on_floor(0)
            xs = [r["x"] for r in rs] + [r["x"] + r["w"] for r in rs] + [rect[0], rect[0] + rect[2]]
            ys = [r["y"] for r in rs] + [r["y"] + r["h"] for r in rs] + [rect[1], rect[1] + rect[3]]
            if max(xs) - min(xs) > self.footprint[0] or max(ys) - min(ys) > self.footprint[1]:
                return False
        box = self._ground_box(floor)
        if box is not None and (rect[0] < box[0] or rect[1] < box[1] or rect[0] + rect[2] > box[2]
                                or rect[1] + rect[3] > box[3]):
            return False
        return True

    # ---- open attachments
    def open_doors(self) -> list[tuple[int, int]]:
        """[(room index, door index)] doorways with nothing behind them yet."""
        out = []
        for i, r in enumerate(self.rooms):
            for k, (side, off) in enumerate(r["doors"]):
                if k in r["used"]:
                    continue
                px, py = door_point(r["x"], r["y"], r["w"], r["h"], side, off)
                if self._door_blocked(r, side, px, py):
                    continue
                out.append((i, k))
        return out

    def _door_blocked(self, r, side, px, py) -> bool:
        # a doorway that opens straight into another room's wall (without a matching door) is closed
        probe = {"N": (px, py - 0.5), "S": (px, py + 0.5), "E": (px + 0.5, py), "W": (px - 0.5, py)}[side]
        for o in self.on_floor(r["floor"]):
            if o is r:
                continue
            if o["x"] <= probe[0] < o["x"] + o["w"] and o["y"] <= probe[1] < o["y"] + o["h"]:
                return True
        return False

    def open_stairs(self) -> list[tuple[int, int]]:
        """[(room index, floor it leads to)] stairs with no room at their other end."""
        out = []
        for i, r in enumerate(self.rooms):
            st = r.get("stairs") or ""
            for d, step in (("Up", 1), ("Down", -1)):
                if st in (d, "Both") and not any(self.rooms[j]["floor"] == r["floor"] + step for j in r["links"]):
                    out.append((i, r["floor"] + step))
        return out

    # ---- choosing and placing
    def candidates(self, tiles: list[dict], room_i: int, door_k: int) -> list[tuple[dict, tuple]]:
        """[(rotated tile, (x, y))] tiles that can attach at this doorway."""
        r = self.rooms[room_i]
        side, off = r["doors"][door_k]
        px, py = door_point(r["x"], r["y"], r["w"], r["h"], side, off)
        want = OPP[side]
        out = []
        for t in tiles:
            if t["role"] == "Entrance" or not floor_allowed(t, r["floor"], self.category):
                continue
            if t.get("stairs") in ("Down", "Both") and r["floor"] >= 0 and t["floor"] in ("Upper", "Cellar") \
                    and t["role"] == "Stairs":
                continue                                    # landings only come with their stairs
            if t.get("stairs") == "Up" and t["floor"] == "Cellar":
                continue
            if t["max"] and self.count(t["name"]) >= t["max"]:
                continue
            if t.get("stairs") and self.target and self.target - len(self.rooms) < 3:
                continue                                    # no new flight of stairs with nothing left to put up there
            if t.get("stairs") and self.category == "dungeon" and self.kind != "Tower" and (
                    self.target < 16 or len(self.rooms) < self.target // 3):
                continue                                    # only big dungeons go down a level, and not at once
            for q in range(4):
                rt = rotated(t, q)
                if q and t.get("fixed"):
                    break
                for k2, (s2, o2) in enumerate(doors_of(rt)):
                    if s2 != want:
                        continue
                    # put the new room so its door meets this one
                    if want == "S":
                        x, y = int(round(px - 0.5 - o2)), int(py - rt["h"])
                    elif want == "N":
                        x, y = int(round(px - 0.5 - o2)), int(py)
                    elif want == "W":
                        x, y = int(px), int(round(py - 0.5 - o2))
                    else:
                        x, y = int(px - rt["w"]), int(round(py - 0.5 - o2))
                    if self.fits((x, y, rt["w"], rt["h"]), r["floor"]):
                        out.append((dict(rt, door_used=k2), (x, y)))
                        break
                else:
                    continue
                break
        return out

    def stair_candidates(self, tiles: list[dict], room_i: int, floor: int) -> list[tuple[dict, tuple]]:
        r = self.rooms[room_i]
        need = "Down" if floor > r["floor"] else "Up"
        out = []
        for t in tiles:
            if t.get("stairs") not in (need, "Both") or not floor_allowed(t, floor, self.category):
                continue
            if t["max"] and self.count(t["name"]) >= t["max"]:
                continue
            for q in range(4):
                rt = rotated(t, q)
                if (rt["w"], rt["h"]) == (r["w"], r["h"]) and self._fits_stair((r["x"], r["y"], rt["w"], rt["h"]),
                                                                               floor):
                    out.append((dict(rt, door_used=None), (r["x"], r["y"])))
                    break
                if t.get("fixed"):
                    break
        return out

    def _fits_stair(self, rect, floor) -> bool:
        return not any(_overlaps(rect, (o["x"], o["y"], o["w"], o["h"])) for o in self.on_floor(floor))

    def add(self, t: dict, x: int, y: int, floor: int, parent: int | None = None, parent_door: int | None = None,
            name: str = "") -> int:
        room = {"name": name or self._name_for(t), "type": t["role"], "tile": t["name"], "floor": floor, "x": x,
                "y": y, "w": t["w"], "h": t["h"], "doors": doors_of(t), "links": set(), "used": set(),
                "stairs": t.get("stairs") or "", "rot": t.get("rot", 0), "description": t.get("description") or "",
                "features": list(t.get("features") or []), "src": t}
        self.rooms.append(room)
        i = len(self.rooms) - 1
        if parent is not None:
            room["links"].add(parent)
            self.rooms[parent]["links"].add(i)
            if parent_door is not None:
                self.rooms[parent]["used"].add(parent_door)
            if t.get("door_used") is not None:
                room["used"].add(t["door_used"])
        return i

    def _name_for(self, t: dict) -> str:
        base = self.rng.choice(t["names"]) if t.get("names") else t["name"]
        used = {r["name"] for r in self.rooms}
        if base not in used:
            return base
        k = 2
        while f"{base} {k}" in used:
            k += 1
        return f"{base} {k}"

    def remove(self, i: int) -> bool:
        """Take out a room that only one other room leads to (never the entrance)."""
        if i <= 0 or i >= len(self.rooms) or len(self.rooms[i]["links"]) > 1:
            return False
        for j in self.rooms[i]["links"]:
            other = self.rooms[j]
            other["links"].discard(i)
            # its doorway on our side opens up again
            for k, (side, off) in enumerate(other["doors"]):
                px, py = door_point(other["x"], other["y"], other["w"], other["h"], side, off)
                r = self.rooms[i]
                probe = {"N": (px, py - 0.5), "S": (px, py + 0.5), "E": (px + 0.5, py), "W": (px - 0.5, py)}[side]
                if r["floor"] == other["floor"] and r["x"] <= probe[0] < r["x"] + r["w"] \
                        and r["y"] <= probe[1] < r["y"] + r["h"]:
                    other["used"].discard(k)
        self.rooms.pop(i)
        for r in self.rooms:
            r["links"] = {j - 1 if j > i else j for j in r["links"] if j != i}
        return True

    # ---- growing
    def attach_at(self, tiles, room_i: int, door_k: int, pick=None) -> int | None:
        cands = self.candidates(tiles, room_i, door_k)
        if not cands:
            self.rooms[room_i]["used"].add(door_k)          # nothing fits: wall it up
            return None
        t, (x, y) = pick(cands) if pick else self._weighted(cands)
        i = self.add(t, x, y, self.rooms[room_i]["floor"], room_i, door_k)
        return i

    def _weighted(self, cands):
        need = [c for c in cands if c[0]["min"] and self.count(c[0]["name"]) < c[0]["min"]]
        pool = need or cands
        total = sum(max(0.01, c[0]["weight"]) for c in pool)
        roll = self.rng.uniform(0, total)
        for c in pool:
            roll -= max(0.01, c[0]["weight"])
            if roll <= 0:
                return c
        return pool[-1]

    def link_neighbours(self, odds: float) -> None:
        """Doors that happen to meet between rooms already placed become links (some of them)."""
        pts = {}
        for i, r in enumerate(self.rooms):
            for k, (side, off) in enumerate(r["doors"]):
                p = door_point(r["x"], r["y"], r["w"], r["h"], side, off)
                pts.setdefault((r["floor"], p), []).append((i, k, side))
        for (_fl, _p), lst in pts.items():
            for a in range(len(lst)):
                for b in range(a + 1, len(lst)):
                    i, k, s1 = lst[a]
                    j, k2, s2 = lst[b]
                    if OPP[s1] == s2 and j not in self.rooms[i]["links"] and self.rng.random() < odds:
                        self.rooms[i]["links"].add(j)
                        self.rooms[j]["links"].add(i)
                        self.rooms[i]["used"].add(k)
                        self.rooms[j]["used"].add(k2)

    # ---- saving
    def rows(self) -> list[dict]:
        out = []
        for r in self.rooms:
            row = dict(r.get("extra") or {})                # anything else saved on the room (a dungeon's monsters)
            row.update({"name": r["name"], "type": r["type"], "tile": r["tile"], "floor": r["floor"],
                        "x": r["x"], "y": r["y"], "w": r["w"], "h": r["h"],
                        "connects": ", ".join(self.rooms[j]["name"] for j in sorted(r["links"])),
                        "description": r.get("description") or "", "rot": r.get("rot", 0)})
            out.append(row)
        return out

    @classmethod
    def from_rows(cls, world, rows: list[dict], kind: str, category: str, footprint=None, rng=None) -> "Layout":
        lay = cls(kind, category, footprint, rng)
        names = {}
        for row in rows:
            t = tile(world, row.get("tile") or "") or _clean({"name": row.get("tile") or row.get("type") or "Room",
                                                               "role": row.get("type") or "Room",
                                                               "w": row.get("w") or 6, "h": row.get("h") or 6})
            rt = rotated(t, int(row.get("rot") or 0))
            w, h = int(row.get("w") or rt["w"]), int(row.get("h") or rt["h"])
            room = {"name": row["name"], "type": row.get("type") or t["role"], "tile": t["name"],
                    "floor": int(row.get("floor") or 0), "x": int(row.get("x") or 0), "y": int(row.get("y") or 0),
                    "w": w, "h": h, "doors": doors_of(rt, w, h), "links": set(), "used": set(),
                    "stairs": t.get("stairs") or "", "rot": int(row.get("rot") or 0),
                    "description": row.get("description") or "", "features": list(t.get("features") or []),
                    "src": t, "extra": {k: v for k, v in row.items() if k not in ("name", "type", "tile", "floor",
                                                                                 "x", "y", "w", "h", "connects",
                                                                                 "description", "rot")}}
            names[row["name"]] = len(lay.rooms)
            lay.rooms.append(room)
        for row in rows:
            i = names[row["name"]]
            for n in str(row.get("connects") or "").split(","):
                j = names.get(n.strip())
                if j is not None and j != i:
                    lay.rooms[i]["links"].add(j)
                    lay.rooms[j]["links"].add(i)
        # doors already in use: those that meet a linked room
        for i, r in enumerate(lay.rooms):
            for k, (side, off) in enumerate(r["doors"]):
                px, py = door_point(r["x"], r["y"], r["w"], r["h"], side, off)
                probe = {"N": (px, py - 0.5), "S": (px, py + 0.5), "E": (px + 0.5, py), "W": (px - 0.5, py)}[side]
                for j in r["links"]:
                    o = lay.rooms[j]
                    if o["floor"] == r["floor"] and o["x"] <= probe[0] < o["x"] + o["w"] \
                            and o["y"] <= probe[1] < o["y"] + o["h"]:
                        r["used"].add(k)
        if lay.rooms:
            ent = lay.rooms[0]
            for k, (side, _o) in enumerate(ent["doors"]):
                if side == "S":
                    ent["used"].add(k)                      # the way in from outside
                    break
        return lay


def footprint_for(kind: str, category: str) -> tuple | None:
    if category == "dungeon":
        return TOWER_FOOTPRINT if kind == "Tower" else None
    return FOOTPRINT.get(kind, FOOTPRINT["Other"])


def generate(world, kind: str, category: str = "building", count: int | None = None, rng=None,
             size: str = "Medium") -> Layout:
    """A fresh layout for a place of this kind. A jail is always the same plan (jail_rows)."""
    rng = rng or random.Random()
    if category == "building" and kind == "Jail":
        return Layout.from_rows(world, jail_rows(size), kind, category, footprint_for(kind, category), rng)
    tiles = tiles_for(world, kind, category)
    lay = Layout(kind, category, footprint_for(kind, category), rng)
    entrances = [t for t in tiles if t["role"] == "Entrance"] or [
        _clean({"name": "Entrance", "role": "Entrance", "w": 6, "h": 6, "doors": "S N E W"})]
    ent = rng.choice(entrances)
    lay.add(dict(ent, door_used=None), 0, 0, 0)
    for k, (side, _o) in enumerate(lay.rooms[0]["doors"]):
        if side == "S":
            lay.rooms[0]["used"].add(k)                     # that's the way in from outside
            break
    if count is None:
        if category == "dungeon" and kind == "Tower":
            count = TOWER_FLOORS.get(size, 6) + rng.randint(0, 1)
        elif category == "dungeon":
            count = DUNGEON_COUNTS.get(size, 13) + rng.randint(-1, 2)
        else:
            lo, hi = COUNTS.get(kind, COUNTS["Other"])
            s = BUILDING_SCALE.get(size, 0.5)
            mid = lo + (hi - lo) * s
            count = max(lo, min(hi, int(round(mid + rng.uniform(-(hi - lo) / 4, (hi - lo) / 4)))))
    if category == "dungeon" and count >= 16:                # big dungeons always go down a level
        tiles = [dict(t, min=1) if t.get("stairs") == "Down" and t["role"] == "Stairs" else t for t in tiles]
    boss = [t for t in tiles if t["role"] == "Boss"]
    body = [t for t in tiles if t["role"] != "Boss"]
    grow(lay, body, count - (1 if boss and category == "dungeon" else 0))
    if boss and category == "dungeon":
        place_far(lay, boss)
    finish_stairs(lay, body)
    lay.link_neighbours(0.6 if category == "building" else 0.3)
    return lay


def grow(lay: Layout, tiles: list[dict], count: int, max_steps: int = 2000) -> None:
    """Attach rooms until there are `count` (or nothing more fits). Stairs are followed as soon as
    they're placed, so every floor starts at its stairs."""
    rng = lay.rng
    lay.target = count
    steps = 0
    while len(lay.rooms) < count and steps < max_steps:
        steps += 1
        stairs = lay.open_stairs()
        if stairs:
            i, floor = stairs[0]
            cands = lay.stair_candidates(tiles, i, floor)
            if cands:
                t, (x, y) = lay._weighted(cands)
                lay.add(t, x, y, floor, i)
                continue
            lay.rooms[i]["stairs"] = ""                     # nothing can go there: the stair is just a room
            continue
        doors = lay.open_doors()
        if not doors:
            break
        share = FLOOR_SHARE.get(lay.kind) if lay.category == "building" else (
            {0: 0.6, -1: 0.4} if count >= 16 and lay.kind not in ("Tower",) else None)
        if share:
            have = {}
            for r in lay.rooms:
                have[r["floor"]] = have.get(r["floor"], 0) + 1
            floors_open = {lay.rooms[i]["floor"] for i, _k in doors}
            want = sorted(floors_open, key=lambda f: -(share.get(f, 0.0) * count - have.get(f, 0)))
            if 0 in floors_open and share.get(0, 0.0) * count - have.get(0, 0) > 0:
                want = [0]                                  # the ground floor first: upper floors sit on it
            if want and share.get(want[0], 0.0) * count - have.get(want[0], 0) > 0:
                doors = [d for d in doors if lay.rooms[d[0]]["floor"] == want[0]]
        # grow from anywhere, a little toward the newer rooms
        doors.sort(key=lambda d: d[0])
        pick = doors[min(len(doors) - 1, int(len(doors) * (rng.random() ** 0.7)))]
        lay.attach_at(tiles, *pick)


def finish_stairs(lay: Layout, tiles: list[dict]) -> None:
    """Stairs left leading nowhere get their other end (or stop being stairs)."""
    for _ in range(8):
        stairs = lay.open_stairs()
        if not stairs:
            return
        for i, floor in stairs:
            cands = lay.stair_candidates(tiles, i, floor)
            ends = [c for c in cands if c[0].get("stairs") != "Both"]      # a stair that ends, not one more flight
            cands = ends or ([] if lay.kind == "Tower" else cands)
            if cands:
                t, (x, y) = lay._weighted(cands)
                lay.add(t, x, y, floor, i)
            else:
                lay.rooms[i]["stairs"] = ""


def place_far(lay: Layout, tiles: list[dict]) -> int | None:
    """Put one of these tiles (a boss's lair) at the open doorway farthest from the entrance."""
    depth = {0: 0}
    queue = [0]
    while queue:
        cur = queue.pop(0)
        for j in lay.rooms[cur]["links"]:
            if j not in depth:
                depth[j] = depth[cur] + 1
                queue.append(j)
    doors = sorted(lay.open_doors(), key=lambda d: -depth.get(d[0], 0))
    for i, k in doors:
        cands = lay.candidates(tiles, i, k)
        if cands:
            t, (x, y) = cands[0]
            return lay.add(t, x, y, lay.rooms[i]["floor"], i, k)
    for i, floor in lay.open_stairs():
        cands = lay.stair_candidates(tiles, i, floor)
        if cands:
            t, (x, y) = cands[0]
            return lay.add(t, x, y, floor, i)
    return None


# ======================================================================
# Places with rooms (buildings, dungeons)
# ======================================================================
def category_of(e) -> str:
    return "dungeon" if e.type == "dungeon" else "building"


def ensure(world, e) -> list[dict]:
    """A building or dungeon's rooms: generated the first time (the same ones every time for that place)
    and saved on it."""
    if e.type == "dungeon":
        rows = [r for r in (e.fields.get("rooms") or []) if str(r.get("name") or "").strip()]
        if rows or not e.fields.get("generate", True):
            return rows
        from game import dungeons as DG
        return DG.ensure_rooms(world, e)
    return building_rows(world, e)


def jail_rows(size: str = "Medium") -> list[dict]:
    """A jail's rooms (game/jail.py), always the same plan: the guardroom at the front (the street door), the
    warden's office on one side of it and the evidence room on the other; behind it the cell block, a
    passage with a row of cells along it. Small jails have three cells, middling ones four, large ones six."""
    n = {"Small": 3, "Large": 6}.get(size, 4)
    w = 5 * n                                            # the cells, side by side (each 5 x 5)
    rows = []
    gx = (w - 8) // 2
    rows.append({"name": "Guardroom", "type": "Entrance", "tile": "Guardroom", "floor": 0, "x": gx, "y": 8,
                 "w": 8, "h": 6, "connects": "Cell Block"})
    rows.append({"name": "Cell Block", "type": "Hall", "tile": "Cell Block", "floor": 0, "x": 0, "y": 5, "w": w,
                 "h": 3, "connects": ", ".join(f"Cell {k + 1}" for k in range(n))})
    for k in range(n):
        rows.append({"name": f"Cell {k + 1}", "type": "Private", "tile": "Cell", "floor": 0, "x": 5 * k, "y": 0,
                     "w": 5, "h": 5, "connects": ""})
    if gx >= 4:
        rows.append({"name": "Warden's Office", "type": "Work", "tile": "Warden's Office", "floor": 0, "x": 0,
                     "y": 8, "w": gx, "h": 6, "connects": "Guardroom"})
    rows.append({"name": "Evidence Room", "type": "Storage", "tile": "Evidence Room", "floor": 0, "x": gx + 8,
                 "y": 8, "w": max(4, w - gx - 8), "h": 6, "connects": "Guardroom"})
    for r in rows:
        r.setdefault("description", (TILE_BY_NAME.get(r["tile"]) or {}).get("description", ""))
        r.setdefault("rot", 0)
    return rows


def is_jail_plan(rows: list[dict]) -> bool:
    return any(r.get("tile") == "Cell" for r in rows)


def building_rows(world, b, save: bool = True) -> list[dict]:
    """A building's rooms, made (and stored on it) the first time anyone needs them. save=False leaves
    writing the buildings file to the caller (a whole town at once). A jail made before jails had cells
    (Hotfix 16) is laid out again as one."""
    rows = [r for r in (b.fields.get("rooms") or []) if str(r.get("name") or "").strip()]
    jail = (b.fields.get("kind") or "") == "Jail"
    if (rows and not (jail and not is_jail_plan(rows) and not b.fields.get("rooms_edited"))) or \
            not b.fields.get("generate", True):
        return rows
    if jail:
        rows = jail_rows(b.fields.get("size") or "Medium")
        world.entities.update(b.id, fields={"rooms": rows}, save=save)
        return rows
    rng = random.Random(zlib.crc32(b.id.encode("utf-8")))
    lay = generate(world, b.fields.get("kind") or "House", "building", rng=rng, size=b.fields.get("size") or "Medium")
    rows = lay.rows()
    world.entities.update(b.id, fields={"rooms": rows}, save=save)
    return rows


def layout_of(world, e) -> Layout:
    return Layout.from_rows(world, ensure(world, e), e.fields.get("kind") or "", category_of(e),
                            footprint_for(e.fields.get("kind") or "", category_of(e)))


def floors(rows: list[dict]) -> list[int]:
    return sorted({int(r.get("floor") or 0) for r in rows}) or [0]


def floor_name(n: int) -> str:
    if n == 0:
        return "Ground floor"
    if n < 0:
        return "Cellar" if n == -1 else f"Cellar level {-n}"
    return {1: "First floor", 2: "Second floor", 3: "Third floor"}.get(n, f"Floor {n}")


def room_row(rows: list[dict], name: str) -> dict | None:
    return next((r for r in rows if r.get("name") == name), None)


def links(rows: list[dict], name: str) -> list[str]:
    names = [r["name"] for r in rows]
    here = room_row(rows, name) or {}
    out = [n.strip() for n in str(here.get("connects") or "").split(",") if n.strip() in names]
    for r in rows:
        if name in [n.strip() for n in str(r.get("connects") or "").split(",")]:
            out.append(r["name"])
    return [n for n in dict.fromkeys(out) if n != name]


def doorway(a: dict, b: dict) -> tuple[float, float] | None:
    """Where two linked rooms on one floor meet (for drawing the door)."""
    if int(a.get("floor") or 0) != int(b.get("floor") or 0):
        return None
    ax, ay, aw, ah = (float(a.get(k) or 0) for k in ("x", "y", "w", "h"))
    bx, by, bw, bh = (float(b.get(k) or 0) for k in ("x", "y", "w", "h"))
    if abs(ax + aw - bx) < 0.01 or abs(bx + bw - ax) < 0.01:
        lo, hi = max(ay, by), min(ay + ah, by + bh)
        if hi > lo:
            return (ax + aw if abs(ax + aw - bx) < 0.01 else ax, (lo + hi) / 2)
    if abs(ay + ah - by) < 0.01 or abs(by + bh - ay) < 0.01:
        lo, hi = max(ax, bx), min(ax + aw, bx + bw)
        if hi > lo:
            return ((lo + hi) / 2, ay + ah if abs(ay + ah - by) < 0.01 else ay)
    return None


def battle_size(row: dict) -> tuple[int, int]:
    """Battle map squares for a fight in this room (a little bigger than the room, within limits)."""
    w, h = int(row.get("w") or 10), int(row.get("h") or 8)
    return (max(10, min(30, w + 4)), max(8, min(22, h + 4)))


def tile_features(world, row: dict) -> list[str]:
    """What a room has in it: its tile's features, and anything the party furnished it with (game/homes.py)."""
    t = tile(world, row.get("tile") or "")
    out = list(t.get("features") or []) if t else []
    for f in row.get("furnished") or ():
        if f not in out:
            out.append(f)
    return out


__all__ = ["TILES", "Layout", "generate", "grow", "ensure", "tiles_for", "all_tiles", "doors_of", "rotated",
           "floors", "floor_name", "links", "doorway", "battle_size", "layout_of", "BUILDING_KINDS", "ROLES"]
