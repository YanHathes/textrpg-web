"""The party's own settlements (build plan step 15): a starter settlement (game/estate.py) grows from a Camp into a
Hamlet, a Village and beyond by the same rules the world's towns follow (game/settlements.py).

A settlement is a town of the save's own: a save-owned town entity (with a save-owned faction), so every town
list, the map, the road graph, the daily schedules, the quest generator, safe zones and festivals see it like any
other town, but only in the save that founded it. Its walking map is the party's claim (game/estate.py lays it
in), and the claim's open ground is the settlement's one street, "<Name> Green".

The record (holdings["settlements"]):
    {"id", "name", "tier", "claim", "town", "faction", "street", "settlers": [npc ids], "households",
     "store": {item: n} (the shared storehouse every building fills), "ledger": [{"day", "gp", "what"}],
     "pending" (a settler waiting to be answered), "turned_away": [keys], "tax_rate", "next_n",
     "visitors": [{"npc", "until"}], "road": {...}, "bad_harvest_until", "no_food_days", "unsafe_days"}

Settlers come more often the more the place offers: free housing, food and water (farms, wells), safety
(walls, guards, watchtowers against the region's danger), draws (an inn, a forge, a shrine, a market), the
party's standing there, and less the more dangerous the region. One at a time, a settler turns up on the green
and talks (dialogue: "So, you'd like to settle here?"): their name and people (automatons too), their trade
(leaning to what the place lacks), their household, the taxes they'd pay a week, and what they need. Accepted,
they become ordinary townsfolk: a home (or a tent until a house is free), work at a building that fits their
trade (filling the storehouse), a schedule, talk, trade, quests. Turned away, they go and never come back. Left
waiting a week, they move on.

Every week (the catch-up step "colony"): taxes, the settlement's standing with the party (good housing, food
and safety raise it; high taxes and hardship lower it), settlers leaving after three weeks without a home, food
or safety, the tier it's grown to, raids (the region's danger, less with walls and guards: fought by the party
if it's there, rolled by the guards if not, and losable), and now and then a bad harvest, a travelling merchant
or a wandering trainer. A road project joins it to the nearest town; then road journeys reach it.
"""
from __future__ import annotations

import math
import random
import zlib

DAY = 1440
WEEK_DAYS = 7
WAIT_DAYS = 7                    # a settler waits this long for an answer
LEAVE_DAYS = 21                  # without a home, food or safety this long, a household leaves
MAX_SETTLERS = 300               # named households (population counts their people)
HOUSEHOLD = {"Camp": (1, 5), "Hamlet": (2, 6), "Village": (4, 14), "Town": (20, 60), "City": (60, 180),
             "Capital": (150, 400)}
TAX_RATES = {"Low": 0.5, "Fair": 1.0, "High": 1.6}
HOUSING = {"House": 1, "Inn": 2, "Barracks": 2, "Castle": 4, "Mansion": 3}
FOOD = {"farm": 30, "pen": 12, "Dock": 12, "Mill": 10}
WATER_PER_WELL = 60
FREE_FOOD = FREE_WATER = 10      # a handful of people get by on what they find
ROAD_GP_PER_MILE = 30
ROAD_STONE_PER_MILE = 4
VISIT_DAYS = 3
# title, occupation, blueprints they work at, skilled, what they need
PROFESSIONS = [
    ("farmer", "Farmer", ["Farm"], True, "farmland"),
    ("herder", "Farmer", ["Livestock Pen"], True, "a pen for their beasts"),
    ("woodcutter", "Commoner", ["Lumber Camp"], True, "a lumber camp"),
    ("miner", "Commoner", ["Mine Shaft"], True, "a mine"),
    ("fisher", "Hunter", ["Dock"], True, "a dock"),
    ("miller", "Farmer", ["Mill", "Granary"], True, "a mill"),
    ("blacksmith", "Blacksmith", ["Forge"], True, "a forge"),
    ("carpenter", "Commoner", ["Carpenter's Workshop"], True, "a workshop"),
    ("tanner", "Tailor", ["Tannery"], True, "a tannery"),
    ("weaver", "Tailor", ["Weaving Shed"], True, "a loom"),
    ("alchemist", "Alchemist", ["Alchemy Lab"], True, "a laboratory"),
    ("scribe", "Scholar", ["Scriptorium"], True, "a scriptorium"),
    ("jeweler", "Jeweler", ["Jeweler's Workshop"], True, "a jeweler's bench"),
    ("cook", "Innkeeper", ["Cookhouse", "Inn"], True, "a kitchen"),
    ("shopkeeper", "Merchant", ["Shop", "Market"], True, "a shop"),
    ("priest", "Priest", ["Shrine", "Temple"], True, "a shrine"),
    ("guard", "Guard", ["Watchtower", "Barracks", "Jail"], True, "a post to keep"),
    ("laborer", "Commoner", [], False, ""),
]
DRAWS = {"Inn", "Forge", "Shrine", "Temple", "Market"}
SKIN = ["#f1d3b3", "#e0b48c", "#c68a5e", "#a0663e", "#7a4c30", "#5a3824"]
HAIR = ["#2b2220", "#4a3020", "#7a5230", "#b08040", "#d8c080", "#8a8a8a", "#e8e8e0", "#a03a20"]
STYLES = ["short", "long", "bun", "cropped", "braid", "bald"]
CLOTHES = ["#4a3f5e", "#3e5a4a", "#5e4a3a", "#2e4a6a", "#6a2e2e", "#5a5a5a", "#7a6a3a"]
GIVEN = ["Aldo", "Mira", "Teo", "Vesna", "Oren", "Hale", "Ysolde", "Bram", "Corin", "Elsa", "Fenn", "Greta", "Ivo",
         "Jory", "Kesta", "Lio", "Maren", "Nils", "Odile", "Pell", "Rhea", "Sorrel", "Tam", "Una", "Wim"]
FAMILY = ["Ashby", "Brook", "Cotter", "Dunmore", "Ellery", "Fallow", "Garrow", "Hedge", "Ivers", "Joss", "Kell",
          "Lowe", "Marrow", "Netherby", "Oakes", "Pike", "Quill", "Rook", "Stave", "Thane", "Underhill", "Vale"]


def _rng(*key) -> random.Random:
    return random.Random(zlib.crc32("|".join(map(str, key)).encode("utf-8")))


def _h(state) -> dict:
    from game import estate
    return estate._h(state)


def settlements(state) -> list[dict]:
    return list(_h(state)["settlements"]) if state is not None else []


def get(state, sid: str) -> dict | None:
    return next((s for s in settlements(state) if s.get("id") == sid), None)


def of_town(state, town_id: str) -> dict | None:
    return next((s for s in settlements(state) if s.get("town") == town_id), None) if town_id else None


def town_of(world, st):
    return world.entities.get(st.get("town") or "") if st else None


def street_name(world, st) -> str:
    return st.get("street") or f"{st.get('name') or 'The'} Green"


def street_id(st) -> str:
    from game import places
    return places.street_id(st.get("town") or "", st.get("street") or "")


def is_own(town) -> bool:
    return bool(town is not None and town.fields.get("settlement"))


def claim_of(state, st):
    from game import estate
    return estate.claim(state, st.get("claim") or "")


def _save(world, state) -> None:
    from game import estate
    estate._save(world, state)


# ======================================================================
# Founding: a town and a faction of the save's own
# ======================================================================
def found(world, state, sid: str) -> object | None:
    """Make the settlement's town (and its faction) as save-owned entities. Once."""
    from game import geography as G
    from game import worldmap as WM
    st = get(state, sid)
    if st is None:
        return None
    if st.get("town") and world.entities.get(st["town"]) is not None:
        return world.entities.get(st["town"])
    c = claim_of(state, st)
    if c is None or not c.get("rect"):
        return None
    x, y, w, h = c["rect"]
    mx, my = (x + w / 2) / WM.SQ, (y + h / 2) / WM.SQ
    biome = G.biome_at(world, mx, my)
    from game.constants import TERRAINS
    terrain = biome if biome in TERRAINS else {"Jungle": "Forest", "Taiga": "Forest", "Tundra": "Arctic",
                                               "Savanna": "Plains", "Badlands": "Hills"}.get(biome, "Plains")
    reg = G.region_at(world, mx, my)
    name = st.get("name") or "Our settlement"
    street = st.get("street") or f"{name} Green"
    st["street"] = street
    town = world.entities.create("town", name, {
        "kind": "Camp", "population": 0, "position": {"x": round(mx, 3), "y": round(my, 3)}, "terrain": terrain,
        "region": reg.name if reg is not None else "", "region_ref": reg.id if reg is not None else None,
        "streets": [{"name": street, "connects": "", "exit": ""}], "roads": [], "defenses": "None",
        "settlement": sid, "claim": c["id"], "lot_seller": None},
        f"{name}: a settlement of your own, founded on day {state.day}.", ["Settlement"], overlay=True)
    fac = world.entities.get(st.get("faction") or "")
    if fac is not None and fac.type == "faction":       # its people carry on (an older save's settlement)
        world.entities.update(fac.id, fields={"town": town.id})
    else:
        fac = world.entities.create("faction", f"The people of {name}", {
            "kind": "Town", "town": town.id, "realm": "", "start": 10},
            f"The settlers of {name}.", ["Faction", "Settlement"], overlay=True)
    world.entities.update(town.id, fields={"faction": fac.id})
    st.update(town=town.id, faction=fac.id)
    st.setdefault("settlers", [])
    st.setdefault("turned_away", [])
    st.setdefault("tax_rate", "Fair")
    st.setdefault("next_n", 0)
    st.setdefault("visitors", [])
    st.setdefault("pending", "")
    st["next_week"] = state.minutes + WEEK_DAYS * DAY
    state.ticks.setdefault("colony", state.minutes)
    for b in _buildings(world, st):                          # what already stands on the land is the town's
        world.entities.update(b.id, fields={"town": town.id, "street": street})
    _save(world, state)
    sync(world, state)
    _maps_changed(world, state, st)
    return world.entities.get(town.id)


def sync(world, state) -> None:
    """After a save is opened: older settlements get their town; the roads the save has built are known."""
    from game import places
    places.EXTRA_ROADS.clear()
    for st in settlements(state):
        if not st.get("town") or world.entities.get(st["town"]) is None:
            st["town"] = ""
            found(world, state, st["id"])
            continue
        road = st.get("road") or {}
        if road.get("done") and road.get("to"):
            places.EXTRA_ROADS.setdefault(road["to"], []).append(
                {"direction": road["back"], "leads_to": st["town"], "hours": road["hours"], "danger": 10,
                 "grade": "track"})


def _maps_changed(world, state, st) -> None:
    from game import estate
    from game import worldmap as WM
    WM.forget(world)                                         # the towns (and maybe roads) changed: made again
    estate._changed(world, state, claim=st.get("claim"))


# ======================================================================
# What the settlement has
# ======================================================================
def _buildings(world, st) -> list:
    from game import estate
    return estate.buildings(world, st.get("claim") or "")


def _finished(world, st) -> list:
    return [b for b in _buildings(world, st) if b.fields.get("status") == "done"]


def _bp_name(world, b) -> str:
    from game import estate
    bp = estate.bp_of(world, b)
    return bp.name if bp is not None else ""


def infrastructure(world, st) -> set[str]:
    """What the settlement has, by the names the tiers ask for (game/settlements.py RULES "needs")."""
    from game import estate
    have = set()
    for b in _finished(world, st):
        bp = estate.bp_of(world, b)
        if bp is None:
            continue
        style = estate.style(bp)
        kind = bp.fields.get("kind") or ""
        if style == "well":
            have.add("Well")
        if style == "farm":
            have.add("Farm")
        have.add(kind)
        have.add(bp.name)
        if kind in ("Mill", "Granary"):
            have.add("Granary")
        if kind == "Temple":
            have |= {"Shrine", "Temple"} if bp.name != "Shrine" else {"Shrine"}
    return have


def settlers_of(world, st) -> list:
    return [n for n in (world.entities.get(i) for i in st.get("settlers") or []) if n is not None]


def household(n) -> int:
    return int((n.fields.get("settler") or {}).get("household") or 1)


def population(world, st) -> int:
    return sum(household(n) for n in settlers_of(world, st))


def housing(world, st) -> dict:
    """npc id -> the home they have ('' camping), filling the houses in the order settlers came."""
    from game import homes
    slots = []
    for b in _finished(world, st):
        k = b.fields.get("kind") or ""
        n = HOUSING.get(k, 1 if homes.perks(world, b).get("Rest") else 0)
        slots += [b.id] * n
    out = {}
    for i, n in enumerate(settlers_of(world, st)):
        out[n.id] = slots[i] if i < len(slots) else ""
    return out


def free_houses(world, st) -> int:
    from game import homes
    cap = 0
    for b in _finished(world, st):
        k = b.fields.get("kind") or ""
        cap += HOUSING.get(k, 1 if homes.perks(world, b).get("Rest") else 0)
    return cap - len(settlers_of(world, st))


def _staffed(state, b) -> bool:
    from game import estate
    return any(w.get("building") == b.id for w in estate.workers(state))


def food(world, state, st) -> int:
    """People the settlement can feed (staffed farms, pens, docks, mills; more with a granary)."""
    from game import estate
    total = FREE_FOOD
    granary = False
    for b in _finished(world, st):
        bp = estate.bp_of(world, b)
        if bp is None:
            continue
        style, kind = estate.style(bp), bp.fields.get("kind") or ""
        if kind == "Granary":
            granary = True
        per = FOOD.get(style) or FOOD.get(bp.name) or FOOD.get(kind) or 0
        if per and _staffed(state, b):
            total += per
    return int(total * (1.25 if granary else 1.0))


def water(world, st) -> int:
    from game import estate
    wells = sum(1 for b in _finished(world, st) if estate.style(estate.bp_of(world, b)) == "well")
    return FREE_WATER + WATER_PER_WELL * wells


def guards(world, st) -> int:
    return sum(1 for n in settlers_of(world, st) if (n.fields.get("occupation") or "") == "Guard")


def defense(world, st) -> int:
    """Defence points: walls, gates, towers and the like, and two for every guard."""
    from game import estate
    pts = 0
    for b in _finished(world, st):
        bp = estate.bp_of(world, b)
        if bp is not None:
            pts += int(bp.fields.get("defense") or 0)
    return pts + 2 * guards(world, st)


def danger(world, st) -> int:
    town = town_of(world, st)
    reg = world.entities.get((town.fields.get("region_ref") or "") if town is not None else "")
    return max(0, int((reg.fields.get("danger") if reg is not None else 0) or 0))


def threat(world, st) -> int:
    from game import settlements as ST
    return danger(world, st) // 10 + ST.TIERS.index(st.get("tier") or "Camp")


def safe(world, st) -> bool:
    return defense(world, st) >= threat(world, st)


def standing(world, state, st) -> int:
    from game import factions
    return factions.standing(world, state, st.get("faction") or "") if st.get("faction") else 0


def status(world, state, st) -> dict:
    """Everything the screens show about it."""
    pop = population(world, st)
    return {"tier": st.get("tier") or "Camp", "population": pop, "households": len(st.get("settlers") or []),
            "free_houses": free_houses(world, st), "food": food(world, state, st), "water": water(world, st),
            "defense": defense(world, st), "threat": threat(world, st), "safe": safe(world, st),
            "standing": standing(world, state, st), "tax_week": round(weekly_tax(world, st), 2),
            "next_tier": next_tier(world, st), "chance": round(arrival_chance(world, state, st), 3)}


# ======================================================================
# Growing: the tiers of game/settlements.py
# ======================================================================
def tier_now(world, st) -> str:
    """The highest tier its people and buildings both reach."""
    from game import settlements as ST
    pop = population(world, st)
    have = infrastructure(world, st)
    best = "Camp"
    for t in ST.TIERS[1:]:
        lo = ST.RULES[t]["people"][0]
        if pop < lo or any(n not in have for n in ST.RULES[t]["needs"]):
            break
        best = t
    return best


def next_tier(world, st) -> str:
    """What it takes to reach the next tier ('' at the top)."""
    from game import settlements as ST
    cur = st.get("tier") or "Camp"
    i = ST.TIERS.index(cur)
    if i + 1 >= len(ST.TIERS):
        return ""
    t = ST.TIERS[i + 1]
    lack = [n.lower() for n in ST.RULES[t]["needs"] if n not in infrastructure(world, st)]
    pop, want = population(world, st), ST.RULES[t]["people"][0]
    bits = ([f"{want - pop} more people"] if pop < want else []) + ([f"a {n}" for n in lack])
    return f"{t}: " + (", ".join(bits) if bits else "ready")


def update(world, state, st, bus=None) -> str:
    """Set its tier and population on the town; returns the new tier if it moved."""
    town = town_of(world, st)
    if town is None:
        return ""
    tier = tier_now(world, st)
    pop = population(world, st)
    moved = tier != (st.get("tier") or "Camp")
    if moved or int(town.fields.get("population") or 0) != pop or town.fields.get("kind") != tier:
        world.entities.update(town.id, fields={"kind": tier, "population": pop})
    if moved:
        from game import settlements as ST
        up = ST.TIERS.index(tier) > ST.TIERS.index(st.get("tier") or "Camp")
        st["tier"] = tier
        text = f"{st['name']} is a {tier.lower()} now!" if up else f"{st['name']} has dwindled to a {tier.lower()}."
        _report(state, st, text)
        if bus is not None:
            bus.emit("log", kind="quest", text=text)
            bus.emit("settlement.tier", settlement=st["id"], tier=tier)
        return tier
    return ""


# ======================================================================
# Settlers
# ======================================================================
def weekly_tax(world, st) -> float:
    rate = TAX_RATES.get(st.get("tax_rate") or "Fair", 1.0)
    return sum(float((n.fields.get("settler") or {}).get("tax") or 0) for n in settlers_of(world, st)) * rate


def arrival_chance(world, state, st) -> float:
    """A settler's chance of turning up on any one day."""
    have = infrastructure(world, st)
    pop = population(world, st)
    score = min(2, max(0, free_houses(world, st))) * 0.75 - (0.5 if free_houses(world, st) < 0 else 0)
    score += 1 if food(world, state, st) >= pop + 3 else -1
    score += 1 if water(world, st) >= pop + 3 else -1
    score += 1 if safe(world, st) else -1
    score += 0.5 * len(DRAWS & have)
    score += standing(world, state, st) / 25
    score -= danger(world, st) / 20
    return max(0.02, min(0.5, 0.1 + 0.05 * score))


def _profession(world, state, st, rng) -> tuple:
    """A trade, leaning to what the settlement lacks: work standing empty first, then trades it hasn't got."""
    have_titles = {(n.fields.get("settler") or {}).get("profession") for n in settlers_of(world, st)}
    built = {}
    for b in _finished(world, st):
        built.setdefault(_bp_name(world, b), []).append(b)
    weights = []
    for p in PROFESSIONS:
        title, _occ, works, _sk, _need = p
        wt = 1.0
        if any(w in built for w in works):
            wt += 4.0 if any(_slots_free(world, state, b) for w in works for b in built.get(w, [])) else 1.0
        if title not in have_titles:
            wt += 1.5
        if title == "farmer":
            wt += 1.5
        weights.append(wt)
    t = rng.random() * sum(weights)
    for p, wt in zip(PROFESSIONS, weights):
        t -= wt
        if t <= 0:
            return p
    return PROFESSIONS[-1]


def _slots_free(world, state, b) -> bool:
    from game import estate
    bp = estate.bp_of(world, b)
    return bp is not None and sum(1 for w in estate.workers(state) if w.get("building") == b.id) < estate.worker_cap(bp)


def _race(world, rng):
    from game import neighborhood as NB
    races = [r for r in world.entities.all("race") if r.fields.get("playable", True)]
    auto = next((r for r in races if r.name == "Automaton"), None)
    if auto is not None and rng.random() < 0.08:
        return auto
    common = [r for r in races if r.name in ("Human", "Dwarf", "Elf", "Halfling", "Gnome", "Half-Elf",
                                               "Half-Orc", "Dragonborn", "Tiefling")] or races
    _ = NB
    return rng.choice(common) if common else None


def _settler_name(world, st, rng, race) -> str:
    used = {n.name for n in settlers_of(world, st)}
    if race is not None and race.name == "Automaton":
        for _ in range(20):
            nm = f"{rng.choice(['Cog', 'Brass', 'Tock', 'Spindle', 'Gear', 'Rivet', 'Pewter'])}-{rng.randint(10, 99)}"
            if nm not in used:
                return nm
    for _ in range(40):
        nm = f"{rng.choice(GIVEN)} {rng.choice(FAMILY)}"
        if nm not in used:
            return nm
    return f"{rng.choice(GIVEN)} {rng.choice(FAMILY)} the Younger"


def settler_key(st, n: int) -> str:
    return f"{st['id']}:{n}"


def offer(world, state, st, bus=None):
    """A new settler turns up on the green (the next one in line; never one that was turned away)."""
    if st.get("pending") and world.entities.get(st["pending"]) is not None:
        return world.entities.get(st["pending"])
    town = town_of(world, st)
    if town is None:
        return None
    n = int(st.get("next_n") or 0)
    while settler_key(st, n) in (st.get("turned_away") or []):
        n += 1
    st["next_n"] = n + 1
    key = settler_key(st, n)
    rng = _rng("settler", key)
    title, occ, works, skilled, need = _profession(world, state, st, rng)
    race = _race(world, rng)
    nm = _settler_name(world, st, rng, race)
    lo, hi = HOUSEHOLD.get(st.get("tier") or "Camp", (1, 5))
    size = rng.randint(lo, hi)
    if race is not None and race.name == "Automaton":
        size = 1
    tax = round((2.0 if skilled else 1.0) * (1 + size / 5), 2)
    needs = ["a house"] + ([need] if need else [])
    auto = race is not None and race.name == "Automaton"
    look = {"base": "automaton"} if auto else {"sex": rng.choice(["male", "female"]), "skin": rng.choice(SKIN),
                                               "hair_color": rng.choice(HAIR), "hair": rng.choice(STYLES)}
    look["clothes"] = rng.choice(CLOTHES)
    who = "a household of " + str(size) if size > 1 else "on their own"
    npc = world.entities.create("npc", nm, {
        "race": race.id if race is not None else None, "occupation": occ, "class": None, "level": 1,
        "disposition": "Friendly", "faction": st.get("faction"), "trains": [], "building": "", "town": town.id,
        "street": street_name(world, st), "home": None, "schedule": [], "talk": None,
        "greeting": f"Good day. I'm {nm.split(' ')[0]}, a {title}, {who}. We heard there's land here, and room "
                    f"to make a living.",
        "quest_cooldown_days": 0, "quests": [], "sells_tags": [], "shop_items": [], "gold": rng.randint(5, 60),
        "price_markup": 100, "passages": [], "relationships": [], "title": title, "appearance": look,
        "equipment": {}, "fights_as": None,
        "settler": {"settlement": st["id"], "key": key, "profession": title, "household": size, "tax": tax,
                    "needs": needs, "skilled": bool(skilled), "works": list(works), "pending": True,
                    "arrived": state.minutes}},
        f"A {title} come to settle in {st['name']}.", ["Settler"], overlay=True)
    st["pending"] = npc.id
    st["pending_since"] = state.minutes
    text = f"A newcomer waits on {street_name(world, st)} in {st['name']}: {nm}, a {title}, hoping to settle."
    _report(state, st, text)
    if bus is not None:
        bus.emit("log", kind="quest", text=text)
    _save(world, state)
    return npc


def pitch(world, npc) -> dict:
    """What a waiting settler tells you (for the screens)."""
    s = npc.fields.get("settler") or {}
    race = world.entities.get(npc.fields.get("race") or "")
    return {"name": npc.name, "race": race.name if race is not None else "", "profession": s.get("profession"),
            "household": int(s.get("household") or 1), "tax": float(s.get("tax") or 0),
            "needs": list(s.get("needs") or []), "skilled": bool(s.get("skilled"))}


def pending(world, st):
    n = world.entities.get(st.get("pending") or "") if st else None
    return n if n is not None and (n.fields.get("settler") or {}).get("pending") else None


def settlement_of_npc(state, npc) -> dict | None:
    s = (npc.fields.get("settler") or {}) if npc is not None else {}
    return get(state, s.get("settlement") or "") if s else None


def accept(world, state, npc, bus=None) -> tuple[bool, str]:
    st = settlement_of_npc(state, npc)
    if st is None or not (npc.fields.get("settler") or {}).get("pending"):
        return False, "They aren't waiting on an answer."
    s = dict(npc.fields["settler"], pending=False, joined=state.day)
    world.entities.update(npc.id, fields={"settler": s})
    st.setdefault("settlers", []).append(npc.id)
    st["pending"] = ""
    st["households"] = len(st["settlers"])
    job = _put_to_work(world, state, st, world.entities.get(npc.id))
    home = rehouse(world, state, st).get(npc.id)
    update(world, state, st, bus)
    bits = [f"{npc.name} settles in {st['name']}"]
    if home:
        bits.append(f"in {world.entities.get(home).name}")
    else:
        bits.append("(camping on the green until a house is free)")
    text = " ".join(bits) + "." + (f" They'll work at {job.name}." if job is not None else "")
    _report(state, st, text)
    if bus is not None:
        bus.emit("log", kind="quest", text=text)
        bus.emit("settler.accepted", settlement=st["id"], npc=npc.id)
    _save(world, state)
    return True, text


def turn_away(world, state, npc, bus=None) -> tuple[bool, str]:
    st = settlement_of_npc(state, npc)
    if st is None or not (npc.fields.get("settler") or {}).get("pending"):
        return False, "They aren't waiting on an answer."
    key = (npc.fields.get("settler") or {}).get("key")
    st.setdefault("turned_away", []).append(key)
    st["pending"] = ""
    world.entities.delete(npc.id)
    text = f"{npc.name} shoulders their pack and goes on, to settle somewhere else."
    if bus is not None:
        bus.emit("log", kind="narration", text=text)
    _save(world, state)
    return True, text


def _put_to_work(world, state, st, npc):
    """A settler takes the work their trade fits, at a building with room (a worker that's never paid: they pay
    taxes)."""
    from game import estate
    s = npc.fields.get("settler") or {}
    works = s.get("works") or []
    for b in _finished(world, st):
        if _bp_name(world, b) in works and _slots_free(world, state, b):
            w = {"id": state.next_id("worker"), "kind": "settler", "npc": npc.id, "name": npc.name,
                 "skilled": bool(s.get("skilled")), "wage": 0.0, "grade": "", "building": "", "hired": state.day}
            estate.workers(state).append(w)
            estate.assign(world, state, w["id"], b.id)
            return b
    return None


def find_work(world, state, st) -> int:
    """Settlers without work take up any that's opened for their trade. Returns how many did."""
    from game import estate
    working = {w.get("npc") for w in estate.workers(state)}
    n = 0
    for npc in settlers_of(world, st):
        if npc.id not in working and _put_to_work(world, state, st, npc) is not None:
            n += 1
    return n


def rehouse(world, state, st) -> dict:
    """Give everyone a home (in the order they came) and note who's camping."""
    got = housing(world, st)
    for npc in settlers_of(world, st):
        home = got.get(npc.id) or None
        s = dict(npc.fields.get("settler") or {})
        changed = (npc.fields.get("home") or None) != home
        if home is None and not s.get("camping_since"):
            s["camping_since"] = state.minutes
            changed = True
        elif home is not None and s.get("camping_since"):
            s.pop("camping_since", None)
            changed = True
        if changed:
            world.entities.update(npc.id, fields={"home": home, "settler": s})
    return got


def leave(world, state, st, npc, why: str, bus=None) -> str:
    from game import estate
    st["settlers"] = [i for i in st.get("settlers") or [] if i != npc.id]
    st["households"] = len(st["settlers"])
    _h(state)["workers"] = [w for w in estate.workers(state) if w.get("npc") != npc.id]
    world.entities.delete(npc.id)
    text = f"{npc.name} and their household leave {st['name']}: {why}."
    _report(state, st, text)
    if bus is not None:
        bus.emit("log", kind="system", text=text)
    return text


def _report(state, st, text: str) -> None:
    _h(state)["reports"].append(text)
    st.setdefault("ledger", [])


# ======================================================================
# Taxes, standing and hardship (weekly)
# ======================================================================
def set_tax(state, sid: str, rate: str) -> None:
    st = get(state, sid)
    if st is not None and rate in TAX_RATES:
        st["tax_rate"] = rate


def _week(world, state, st, minute: int, bus=None) -> None:
    from game import factions
    rehouse(world, state, st)
    find_work(world, state, st)
    tax = weekly_tax(world, st)
    if tax > 0:
        state.copper += int(round(tax * 100))
        st.setdefault("ledger", []).append({"day": minute // DAY + 1, "gp": round(tax, 2), "what": "taxes"})
        del st["ledger"][:-52]
    pop = population(world, st)
    fed = food(world, state, st) >= pop and water(world, st) >= pop
    secure = safe(world, st)
    housed = free_houses(world, st) >= 0
    delta = (1 if housed else -2) + (1 if fed else -3) + (1 if secure else -2)
    delta -= int(round((TAX_RATES.get(st.get("tax_rate") or "Fair", 1.0) - 1.0) * 6))
    if st.get("faction") and st.get("settlers"):
        factions.change(world, state, st["faction"], delta, "life in the settlement", None)
    st["no_food_days"] = 0 if fed else int(st.get("no_food_days") or 0) + WEEK_DAYS
    st["unsafe_days"] = 0 if secure else int(st.get("unsafe_days") or 0) + WEEK_DAYS
    people = settlers_of(world, st)
    gone = None
    for npc in people:                                  # the longest without a home goes first
        since = (npc.fields.get("settler") or {}).get("camping_since")
        if since is not None and minute - int(since) >= LEAVE_DAYS * DAY:
            gone = leave(world, state, st, npc, "no home after three weeks of camping", bus)
            break
    if gone is None and people and int(st["no_food_days"]) >= LEAVE_DAYS:
        leave(world, state, st, people[-1], "there isn't enough food and water", bus)
        st["no_food_days"] = 0
    elif gone is None and people and int(st["unsafe_days"]) >= LEAVE_DAYS:
        leave(world, state, st, people[-1], "it isn't safe", bus)
        st["unsafe_days"] = 0
    _events(world, state, st, minute, bus)
    _raid_roll(world, state, st, minute, bus)
    update(world, state, st, bus)


# ======================================================================
# Events: raids (game/townevents.py, set so they can be lost), harvests, visitors
# ======================================================================
def raid_chance(world, st) -> float:
    pts = defense(world, st)
    return max(0.0, (0.03 + danger(world, st) / 300) * (1 - min(0.75, pts * 0.06)))


def defense_xp(world, st) -> int:
    """The defence's strength on the raiders' scale (adjusted XP: game/arena.py)."""
    return 150 * defense(world, st) + 25 * len(st.get("settlers") or [])


def _here(world, state, st) -> bool:
    from game import places
    spot = places.current(world, state)
    return spot.town is not None and spot.town.id == st.get("town")


def _levels(world, st) -> list[int]:
    from game import neighborhood as NB
    town = town_of(world, st)
    lo, hi = NB.level_range(world, town) if town is not None else (1, 4)
    return [max(1, (lo + hi) // 2)] * 4


def start_raid(world, state, st, rng=None, bus=None) -> dict:
    """Raiders come. With the party there, it's the step 13 raid (fight it, or leave it to the guards); away,
    the guards' roll decides at once."""
    from game import townevents as TE
    rng = rng or random.Random()
    town = town_of(world, st)
    if _here(world, state, st):
        raid = TE.start_raid(world, state, town, rng, _levels(world, st), winnable=True,
                             defense=defense_xp(world, st))
        raid["settlement"] = st["id"]
        if bus is not None:
            bus.emit("log", kind="damage", text=raid["text"])
        return raid
    waves = [TE.raiders(world, town, _levels(world, st), rng) for _ in range(rng.randint(*TE.WAVES))]
    raid = {"town": town.id, "settlement": st["id"], "waves": waves, "wave": 0, "status": "on", "winnable": True,
            "defense": defense_xp(world, st), "beaten_by": [], "started": state.minutes}
    guards_roll(world, state, raid, rng, bus)
    return raid


def guards_roll(world, state, raid: dict, rng=None, bus=None) -> str:
    """The guards fight what's left of a raid without the party: wave by wave, their defence against the
    raiders' strength (with luck either way). Returns "beaten" or "lost"."""
    from game import townevents as TE
    rng = rng or random.Random()
    while raid["wave"] < len(raid["waves"]):
        strength = TE._strength(world, raid["waves"][raid["wave"]])
        if strength > int(raid.get("defense") or 0) * rng.uniform(0.7, 1.5):
            raid["status"] = "lost"
            break
        raid["wave"] += 1
        raid["beaten_by"].append("guard")
    else:
        raid["status"] = "beaten"
    raid_over(world, state, raid, bus)
    return raid["status"]


def raid_over(world, state, raid: dict, bus=None) -> None:
    """A raid on a settlement of the party's own is over: thanks if it was beaten, losses if not."""
    if raid.get("applied"):
        return
    st = get(state, raid.get("settlement") or "") or of_town(state, raid.get("town") or "")
    if st is None:
        return
    raid["applied"] = True
    from game import factions
    if raid.get("status") == "abandoned":                       # the party left: the guards finish it
        raid["applied"] = False
        raid["status"] = "on"
        guards_roll(world, state, raid, _rng("guards", raid["town"], raid.get("started", 0)), bus)
        return
    st.setdefault("raids", []).append({"day": state.day, "status": raid.get("status"),
                                       "by": sorted(set(raid.get("beaten_by") or []))})
    del st["raids"][:-20]
    if raid.get("status") == "beaten":
        text = f"The raiders are driven off from {st['name']}."
        if st.get("faction"):
            factions.change(world, state, st["faction"], 3, "for keeping the settlement safe", None)
    else:
        text = f"Raiders overran {st['name']}! " + damage(world, state, st, _rng("loss", st["id"], state.minutes))
        if st.get("faction"):
            factions.change(world, state, st["faction"], -5, "for the raid", None)
    _report(state, st, text)
    if bus is not None:
        bus.emit("log", kind="damage" if raid.get("status") == "lost" else "quest", text=text)
    _save(world, state)


def damage(world, state, st, rng) -> str:
    """What a lost raid costs: a building wrecked (to be repaired), a third of the stores, a household."""
    from game import estate
    bits = []
    cand = [b for b in _finished(world, st) if estate.style(estate.bp_of(world, b)) not in ("wall", "gate", "well")]
    if cand:
        b = rng.choice(cand)
        bp = estate.bp_of(world, b)
        world.entities.update(b.id, fields={"status": "building"})
        _h(state)["jobs"].append({"id": state.next_id("build"), "kind": "build", "building": b.id,
                                  "work": max(10.0, float(bp.fields.get("labor") or 0) * 0.3), "done": 0.0,
                                  "start": state.minutes, "materials": [], "repair": True})
        bits.append(f"{b.name} is wrecked and must be repaired")
    store = st.setdefault("store", {})
    took = 0
    for k in list(store):
        n = int(store[k] * 0.33)
        store[k] -= n
        took += n
    if took:
        bits.append(f"{took} of what was in the storehouse is carried off")
    people = settlers_of(world, st)
    if people:
        victim = rng.choice(people)
        leave(world, state, st, victim, "they won't stay after the raid")
        bits.append(f"the {victim.name.split(' ')[-1]} household leaves")
    estate._changed(world, state, claim=st.get("claim"))
    return (", ".join(bits) + ".").capitalize() if bits else "Somehow, nothing was lost."


def _raid_roll(world, state, st, minute: int, bus=None) -> None:
    from game import townevents as TE
    rng = _rng("colony-raid", st["id"], minute // DAY)
    if TE.data(state).get("raid") is not None:
        return
    if rng.random() < raid_chance(world, st):
        start_raid(world, state, st, rng, bus)


def _events(world, state, st, minute: int, bus=None) -> None:
    rng = _rng("colony-event", st["id"], minute // DAY)
    for v in list(st.get("visitors") or []):                   # visitors move on
        if minute >= int(v.get("until") or 0):
            if world.entities.get(v.get("npc") or "") is not None:
                world.entities.delete(v["npc"])
            st["visitors"].remove(v)
    if (st.get("tier") or "Camp") == "Camp":
        return
    have = infrastructure(world, st)
    roll = rng.random()
    if roll < 0.06 and "Farm" in have:
        st["bad_harvest_until"] = minute + 30 * DAY
        text = f"Blight in the fields of {st['name']}: the harvest will be poor this month."
    elif roll < 0.21:
        text = _visitor(world, state, st, rng, "merchant", minute)
    elif roll < 0.29:
        text = _visitor(world, state, st, rng, "trainer", minute)
    else:
        return
    if text:
        _report(state, st, text)
        if bus is not None:
            bus.emit("log", kind="quest", text=text)


def _visitor(world, state, st, rng, what: str, minute: int) -> str:
    town = town_of(world, st)
    nm = f"{rng.choice(GIVEN)} {rng.choice(FAMILY)}"
    if what == "merchant":
        fields = {"occupation": "Merchant", "title": "travelling merchant", "sells_tags": ["gear", "tool", "food",
                                                                                          "clothing", "potion"],
                  "greeting": "Fine goods from far away! Have a look, have a look."}
        text = f"A travelling merchant, {nm}, has set up on {street_name(world, st)} in {st['name']} for a few days."
    else:
        tools = [e.id for e in world.entities.all("skill") if e.name.endswith(("Tools", "Kit", "Supplies",
                                                                                 "utensils"))]
        if not tools:
            return ""
        teach = rng.sample(tools, min(2, len(tools)))
        fields = {"occupation": "Commoner", "title": "wandering trainer", "trains": teach,
                  "greeting": "I teach for a living, and I don't stay long anywhere. Learn while you can."}
        names = ", ".join(world.entities.get(t).name for t in teach)
        text = f"A wandering trainer, {nm}, is in {st['name']} for a few days, teaching {names}."
    base = {"race": None, "class": None, "level": 1, "disposition": "Friendly", "faction": None, "trains": [],
            "building": "", "town": town.id, "street": street_name(world, st), "home": None, "schedule": [],
            "talk": None, "quest_cooldown_days": 0, "quests": [], "sells_tags": [], "shop_items": [],
            "gold": rng.randint(50, 300), "price_markup": 110, "passages": [], "relationships": [],
            "appearance": {"sex": rng.choice(["male", "female"]), "skin": rng.choice(SKIN),
                           "hair_color": rng.choice(HAIR), "hair": rng.choice(STYLES), "clothes": rng.choice(CLOTHES)},
            "equipment": {}, "fights_as": None, "visitor": st["id"]}
    race = world.entities.find_by_name("race", "Human")
    base["race"] = race.id if race is not None else None
    base.update(fields)
    npc = world.entities.create("npc", nm, base, f"A {fields['title']} passing through.", ["Visitor"], overlay=True)
    st.setdefault("visitors", []).append({"npc": npc.id, "until": minute + VISIT_DAYS * DAY, "what": what})
    return text


# ======================================================================
# The road project
# ======================================================================
def road_plan(world, state, st) -> dict | None:
    """The road to the nearest town: {"to", "miles", "labor", "materials": [(item, n)], "direction"}."""
    from game import estate
    from game import geography as G
    town = town_of(world, st)
    p0 = G.town_position(world, town) if town is not None else None
    if p0 is None:
        return None
    best, bd = None, 1e18
    for tid, p in G.town_positions(world).items():
        t = world.entities.get(tid)
        if t is None or is_own(t):
            continue
        d = math.hypot(p[0] - p0[0], p[1] - p0[1])
        if d < bd:
            best, bd = t, d
    if best is None:
        return None
    stone = estate._item_ref(world, "Stone Block")
    miles = max(0.5, bd)
    return {"to": best.id, "name": best.name, "miles": round(miles, 1), "labor": int(ROAD_GP_PER_MILE * miles),
            "materials": [(stone, int(math.ceil(ROAD_STONE_PER_MILE * miles)))] if stone else [],
            "direction": _direction(p0, G.town_position(world, best))}


def _direction(a, b) -> str:
    ang = math.degrees(math.atan2(b[1] - a[1], b[0] - a[0]))          # y down: 90 is south
    names = ["East", "South-east", "South", "South-west", "West", "North-west", "North", "North-east"]
    return names[int(((ang % 360) + 22.5) // 45) % 8]


OPPOSITE = {"North": "South", "South": "North", "East": "West", "West": "East", "North-east": "South-west",
            "South-west": "North-east", "North-west": "South-east", "South-east": "North-west"}


def road_job(state, st) -> dict | None:
    return next((j for j in _h(state)["jobs"] if j.get("kind") == "road" and j.get("settlement") == st["id"]), None)


def start_road(world, state, sid: str, bus=None) -> tuple[bool, str]:
    st = get(state, sid)
    if st is None:
        return False, "No such settlement."
    if (st.get("road") or {}).get("done"):
        return False, "The road's already built."
    if road_job(state, st) is not None:
        return False, "The road is already being built."
    plan = road_plan(world, state, st)
    if plan is None:
        return False, "There's no town to build a road to."
    lack = [(i, n - state.count(i)) for i, n in plan["materials"] if state.count(i) < n]
    if lack:
        return False, "The road needs " + ", ".join(
            f"{n} more {world.entities.get(i).name}" for i, n in lack) + "."
    for i, n in plan["materials"]:
        state.remove_item(i, n, "the road")
    _h(state)["jobs"].append({"id": state.next_id("road"), "kind": "road", "settlement": sid, "to": plan["to"],
                              "work": float(plan["labor"]), "done": 0.0, "start": state.minutes,
                              "direction": plan["direction"]})
    state.ticks.setdefault("colony", state.minutes)
    _save(world, state)
    msg = f"Work begins on a road from {st['name']} to {plan['name']} ({plan['miles']} miles)."
    if bus is not None:
        bus.emit("log", kind="quest", text=msg)
    return True, msg


def road_crew(world, state, st) -> int:
    """The party, and every settler with no other work, up to ten."""
    from game import estate
    working = {w.get("npc") for w in estate.workers(state)}
    idle = sum(1 for n in settlers_of(world, st) if n.id not in working)
    return 1 + min(9, idle)


def _road_work(world, state, st, frac: float, bus=None) -> None:
    from game import estate
    job = road_job(state, st)
    if job is None:
        return
    job["done"] = float(job["done"]) + estate.pace(world) * road_crew(world, state, st) * frac
    if job["done"] < float(job["work"]):
        return
    _h(state)["jobs"] = [j for j in _h(state)["jobs"] if j is not job]
    finish_road(world, state, st, job["to"], job.get("direction") or "", bus)


def finish_road(world, state, st, to_id: str, direction: str = "", bus=None) -> None:
    """The road is open: journeys and caravans reach the settlement, and it joins the quest neighborhoods."""
    from game import geography as G
    town, other = town_of(world, st), world.entities.get(to_id)
    if town is None or other is None:
        return
    p0, p1 = G.town_position(world, town), G.town_position(world, other)
    direction = direction or _direction(p0, p1)
    miles = math.hypot(p1[0] - p0[0], p1[1] - p0[1])
    hours = round(max(0.5, miles / G.mph(world)), 1)
    roads = [r for r in town.fields.get("roads") or [] if r.get("leads_to") != to_id]
    roads.append({"direction": direction, "leads_to": to_id, "hours": hours, "danger": 10, "grade": "track"})
    world.entities.update(town.id, fields={"roads": roads, "streets": [
        {"name": street_name(world, st), "connects": "", "exit": direction}]})
    st["road"] = {"to": to_id, "direction": direction, "back": OPPOSITE.get(direction, "North"), "hours": hours,
                  "done": True, "day": state.day}
    sync(world, state)
    _maps_changed(world, state, st)
    text = f"The road from {st['name']} to {other.name} is finished: {hours:g} hours on foot."
    _report(state, st, text)
    if bus is not None:
        bus.emit("log", kind="quest", text=text)
    _save(world, state)


# ======================================================================
# The catch-up step
# ======================================================================
def _catch_up(world, state, since: int, now: int) -> None:
    h = getattr(state, "holdings", None)
    if not h or not h.get("settlements"):
        return
    run(world, state, since, now)


def run(world, state, since: int, now: int) -> None:
    bus = getattr(state, "bus", None)
    for st in settlements(state):
        if not st.get("town") or world.entities.get(st["town"]) is None:
            continue
        t = since
        span = now - since
        step = DAY if span <= 400 * DAY else max(DAY, span // 400)
        while t < now:
            t2 = min(now, (t // DAY + 1) * DAY if step == DAY else t + step)
            frac = (t2 - t) / DAY
            _road_work(world, state, st, frac, bus)
            if t2 // DAY != t // DAY:
                _day(world, state, st, t2, frac, bus)
            while int(st.get("next_week") or 0) <= t2:
                _week(world, state, st, int(st.get("next_week") or t2), bus)
                st["next_week"] = int(st.get("next_week") or t2) + WEEK_DAYS * DAY
            t = t2
    _save(world, state)


def _day(world, state, st, minute: int, frac: float, bus=None) -> None:
    """A new day: a waiting settler gives up after a week; otherwise someone new may turn up."""
    n = pending(world, st)
    if n is not None:
        since = int((n.fields.get("settler") or {}).get("arrived") or minute)
        if minute - since >= WAIT_DAYS * DAY:
            st["pending"] = ""
            world.entities.delete(n.id)
            _report(state, st, f"{n.name} waited a week for an answer and moved on.")
        return
    if len(st.get("settlers") or []) >= MAX_SETTLERS:
        return
    rng = _rng("arrive", st["id"], minute // DAY)
    if rng.random() < arrival_chance(world, state, st) * min(1.0, max(frac, 1.0)):
        offer(world, state, st, bus)


def _register() -> None:
    from game import ticker
    ticker.register("colony", _catch_up)


_register()

__all__ = ["found", "sync", "settlements", "get", "of_town", "offer", "accept", "turn_away", "pending", "pitch",
           "status", "tier_now", "update", "road_plan", "start_road", "finish_road", "start_raid", "guards_roll",
           "raid_over", "set_tax", "population", "infrastructure", "TAX_RATES"]
