"""Entities: everything a player can create (items, NPCs, towns, ...).

An entity, as the game sees it:
    {
      "id": "item.ember-blade", "type": "item", "name": "Ember Blade",
      "description": "...", "tags": ["weapon", "fire"],
      "fields": {"damage": "1d8", ...},            # template fields
      "custom": [{"key": "burn_chance", "label": "Burn Chance",
                  "type": "number", "value": 15}],  # one-off fields on this entity only
      "created": "...", "modified": "..."
    }

Where they live (step 18): one SQLite file, <world>/entities/entities.db, so a world of tens of thousands of
NPCs and buildings opens in a moment and holds only what's in use:

  * The small types (items, spells, towns, quests...) are read in full when the world opens.
  * NPCs and buildings (LAZY) are fetched when asked for: by id, by name, or through an index of the fields the
    game looks them up by ("everyone whose building is X", "everyone who names Y in their relationships"; see
    INDEXED). Asking for all of them (all("npc")) still works, it just reads them all.
  * Only what changed is written back: each loaded entity remembers the record it was read as.
  * Each record holds only what differs from its kind's defaults (game/recordpack.py): an innkeeper is
    stored as what makes this innkeeper unlike the usual one.

Code that edits entity.fields directly must call store.save() (or store.touch(type)) afterwards, as before.
Worlds made before step 18 kept one JSON file per type; they're moved into the database the first time they
open.
"""
from __future__ import annotations

import copy
import json
import re
import sqlite3
import sys
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from game.fields import FieldDef, variable_name
from game.templates import TYPE_ORDER, TemplateRegistry

FILE_FORMAT = 1
DB_FORMAT = 1
DB_FILE = "entities.db"
LAZY = ("npc", "building")                   # fetched when asked for, not read at open
# the fields the game looks NPCs and buildings up by (by_field), each with how to read its values from a
# record: a field's own value (or each item of a list), or a column of a table's rows
INDEXED = {
    "npc": {"building": "building", "town": "town", "home": "home", "occupation": "occupation",
            "faction": "faction", "title": "title", "place": ("schedule", "place"), "rel": ("relationships", "npc")},
    "building": {"town": "town", "npcs": "npcs", "kind": "kind", "owner": "owner", "street": "street"},
}
TRIM_AT = {"npc": 6000, "building": 4000}    # loaded beyond this many, the unchanged, unused ones are let go


class ValidationError(ValueError):
    def __init__(self, problems: list[str]) -> None:
        super().__init__("; ".join(problems))
        self.problems = problems


class InUseError(ValueError):
    def __init__(self, entity: "Entity", users: list[tuple["Entity", str]]) -> None:
        names = ", ".join(f"{u.name} ({label})" for u, label in users[:6])
        more = f" and {len(users) - 6} more" if len(users) > 6 else ""
        super().__init__(f"{entity.name} is used by {names}{more}")
        self.users = users


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def slugify(text: str) -> str:
    slug = re.sub(r"[^0-9a-z]+", "-", str(text).lower()).strip("-")
    return slug or "unnamed"


@dataclass
class Entity:
    id: str
    type: str
    name: str
    description: str = ""
    tags: list[str] = field(default_factory=list)
    fields: dict[str, Any] = field(default_factory=dict)
    custom: list[dict] = field(default_factory=list)
    created: str = ""
    modified: str = ""

    def get(self, key: str, default: Any = None) -> Any:
        if key in ("name", "description", "tags"):
            return getattr(self, key)
        if key in self.fields:
            return self.fields[key]
        for c in self.custom:
            if c.get("key") == key:
                return c.get("value")
        return default

    def values(self) -> dict:
        """Every value by key: template fields, custom fields, name, description, tags."""
        out = dict(self.fields)
        for c in self.custom:
            out.setdefault(c["key"], c.get("value"))
        out.update(name=self.name, description=self.description, tags=list(self.tags))
        return out

    def to_dict(self, copy_values: bool = True) -> dict:
        """As stored. copy_values=False shares the field values (for writing straight out to a file)."""
        return {
            "id": self.id, "type": self.type, "name": self.name, "description": self.description,
            "tags": list(self.tags), "fields": copy.deepcopy(self.fields) if copy_values else self.fields,
            "custom": copy.deepcopy(self.custom) if copy_values else self.custom, "created": self.created,
            "modified": self.modified,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Entity":
        return cls(
            id=data["id"], type=data["type"], name=data.get("name", "Unnamed"),
            description=data.get("description", ""), tags=list(data.get("tags", [])),
            fields=dict(data.get("fields", {})), custom=list(data.get("custom", [])),
            created=data.get("created", ""), modified=data.get("modified", ""),
        )

    def copy(self) -> "Entity":
        return Entity.from_dict(self.to_dict())


class EntityStore:
    def __init__(self, folder: Path, templates: TemplateRegistry,
                 on_change: Callable[[str, "Entity"], None] | None = None) -> None:
        self.folder = Path(folder)
        self.templates = templates
        self.on_change = on_change
        self.rev = 0                     # goes up with every change (things worked out from the world check it)
        self._by_type: dict[str, dict[str, Entity]] = {t: {} for t in TYPE_ORDER}   # what's in memory
        self._complete: set[str] = set()                 # types wholly in memory
        self._sig: dict[str, str] = {}                   # id -> the record as it was last read or written
        self._deleted: dict[str, set[str]] = {}          # type -> ids to delete from the file at the next save
        self._sorted: dict[str, list[Entity]] = {}
        self._names: dict[str, dict[str, Entity]] = {}
        self._fields: dict[tuple[str, str], dict] = {}
        self._db: sqlite3.Connection | None = None
        self._packer = None
        self._batching = 0
        self._fresh_file = False                         # nothing was in the file when it was opened
        self._pending: set[str] = set()
        # Save-owned entities (the player's own buildings): seen by every query like any other entity,
        # but kept in the running game's save (game/holdings.py), never written to the world's files.
        self._overlay: set[str] = set()
        self.overlay_hook: Callable[[], None] | None = None     # called when save-owned entities change
        self.load()

    # ==================================================================
    # The file
    # ==================================================================
    @property
    def db_path(self) -> Path:
        return self.folder / DB_FILE

    def _conn(self) -> sqlite3.Connection:
        if self._db is None:
            self.folder.mkdir(parents=True, exist_ok=True)
            db = sqlite3.connect(str(self.db_path), check_same_thread=False, isolation_level=None)
            db.execute("PRAGMA synchronous=NORMAL")
            db.execute("PRAGMA temp_store=MEMORY")
            db.execute("PRAGMA cache_size=-2000")            # a 2 MB page cache: enough, and kind to small phones
            db.executescript("""
                CREATE TABLE IF NOT EXISTS entities (id TEXT PRIMARY KEY, type TEXT NOT NULL, name TEXT NOT NULL,
                                                     lname TEXT NOT NULL, data TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS ent_type_lname ON entities(type, lname);
                CREATE TABLE IF NOT EXISTS refs (type TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL,
                                                 id TEXT NOT NULL, PRIMARY KEY (type, key, value, id))
                                                 WITHOUT ROWID;
                CREATE TABLE IF NOT EXISTS archetypes (type TEXT NOT NULL, kind TEXT NOT NULL, data TEXT NOT NULL,
                                                       PRIMARY KEY (type, kind));
                CREATE TABLE IF NOT EXISTS dicts (type TEXT PRIMARY KEY, data BLOB NOT NULL);
                CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
            """)
            self._db = db
        return self._db

    def close(self) -> None:
        """Let go of the file (before the world's folder is moved or deleted)."""
        if self._db is not None:
            try:
                self._db.close()
            finally:
                self._db = None

    @property
    def packer(self):
        if self._packer is None:
            from game import recordpack
            self._packer = recordpack.Packer(self._conn())
        return self._packer

    # ==================================================================
    # Indexes
    # ==================================================================
    def touch(self, type_name: str | None = None) -> None:
        """Forget cached lookups for a type (or all types) after a change."""
        if type_name is None:
            self._sorted.clear()
            self._names.clear()
            self._fields.clear()
            return
        self._sorted.pop(type_name, None)
        self._names.pop(type_name, None)
        for key in [k for k in self._fields if k[0] == type_name]:
            del self._fields[key]

    def custom_index(self, type_name: str, name: str, build: Callable[[list["Entity"]], dict]) -> dict:
        """A cached index of one type, made by build(entities); rebuilt when that type changes. (For NPCs and
        buildings this reads them all: use by_field, or memo, where you can.)"""
        key = (type_name, "@" + name)
        idx = self._fields.get(key)
        if idx is None:
            idx = build(self.all(type_name))
            self._fields[key] = idx
        return idx

    def memo(self, type_name: str, name: str) -> dict:
        """A scratch dict for things worked out from a type, emptied whenever that type changes."""
        return self._fields.setdefault((type_name, "#" + name), {})

    def by_field(self, type_name: str, key: str, value) -> list["Entity"]:
        """Entities of a type whose field `key` is `value` (or, for list fields, contains it). For NPCs and
        buildings, the keys in INDEXED come from the file's index (plus what's changed in memory)."""
        lazy = type_name in LAZY and type_name not in self._complete
        if lazy and key in INDEXED.get(type_name, {}):
            return self._indexed(type_name, key, value)
        idx = self._fields.get((type_name, key))
        if idx is None:
            idx = {}
            for e in self._each(type_name):
                for x in _values_of(e, key, INDEXED.get(type_name, {}).get(key, key)):
                    idx.setdefault(x, []).append(e)
            self._fields[(type_name, key)] = idx
        return list(idx.get(value, ()))

    def _indexed(self, type_name: str, key: str, value) -> list["Entity"]:
        """A lookup through the file's index, corrected by what's in memory (loaded entities may have changed
        since they were written, and new ones may not be written yet)."""
        how = INDEXED[type_name][key]
        mem = self._fields.get((type_name, "~" + key))
        if mem is None:
            mem = {}
            for e in self._by_type[type_name].values():
                for x in _values_of(e, key, how):
                    mem.setdefault(x, []).append(e)
            self._fields[(type_name, "~" + key)] = mem
        out = list(mem.get(value, ()))
        seen = {e.id for e in out}
        loaded = self._by_type[type_name]
        gone = self._deleted.get(type_name, set())
        rows = self._conn().execute("SELECT id FROM refs WHERE type=? AND key=? AND value=?",
                                    (type_name, key, _ref_text(value))).fetchall()
        want = _ref_text(value)
        for (eid,) in rows:
            if eid in seen or eid in loaded or eid in gone:
                continue                                  # in memory: what's in memory decides
            e = self._fetch(eid)
            if e is not None and any(_ref_text(x) == want for x in _values_of(e, key, how)):
                out.append(e)
        return out

    # ==================================================================
    # Loading / saving
    # ==================================================================
    def load(self) -> None:
        keep = self.overlay_entities() if getattr(self, "_overlay", None) else []
        self._overlay = set()
        db = self._conn()
        if not self._format():
            self._import_json()
        from game import progress
        self._by_type = {t: {} for t in TYPE_ORDER}
        self._sig.clear()
        self._deleted.clear()
        self._complete = set()
        eager = [t for t in TYPE_ORDER if t not in LAZY]
        for i, t in enumerate(eager):
            progress.report(i / max(1, len(eager)), "Reading the world")
            self._read_all(t)
        stored = dict(db.execute("SELECT type, COUNT(*) FROM entities GROUP BY type").fetchall())
        self._fresh_file = not stored
        for t in LAZY:
            if not stored.get(t):
                self._complete.add(t)        # none in the file: what's in memory is all of them
        for e in keep:                       # a reload from disk keeps the running game's own entities
            self.add_overlay(e)
        self.touch()

    def _format(self) -> int:
        row = self._conn().execute("SELECT value FROM meta WHERE key='format'").fetchone()
        return int(row[0]) if row else 0

    def _read_all(self, type_name: str) -> None:
        """Every stored entity of a type into memory (keeping the ones already there as they are)."""
        bucket = self._by_type[type_name]
        gone = self._deleted.get(type_name, set())
        unpack, text = self.packer.unpack, self.packer.text
        for eid, name, data in self._conn().execute("SELECT id, name, data FROM entities WHERE type=?",
                                                    (type_name,)):
            if eid in bucket or eid in gone:
                continue
            data = text(type_name, data)
            bucket[eid] = unpack(type_name, eid, name, data)
            self._sig[eid] = data
        self._complete.add(type_name)

    def _fetch(self, entity_id: str) -> Entity | None:
        type_name = entity_id.split(".", 1)[0]
        if type_name not in self._by_type:
            return None
        row = self._conn().execute("SELECT name, data FROM entities WHERE id=?", (entity_id,)).fetchone()
        if row is None:
            return None
        data = self.packer.text(type_name, row[1])
        e = self.packer.unpack(type_name, entity_id, row[0], data)
        self._by_type[type_name][entity_id] = e
        self._sig[entity_id] = data
        for (t, key), idx in self._fields.items():       # what's in memory now includes it
            if t == type_name and key.startswith("~"):
                for x in _values_of(e, key[1:], INDEXED[type_name][key[1:]]):
                    idx.setdefault(x, []).append(e)
        self._sorted.pop(type_name, None)
        if len(self._by_type[type_name]) > TRIM_AT.get(type_name, 1 << 30):
            self.trim(type_name)
        return e

    def _drop_mem_index(self, type_name: str) -> None:
        for key in [k for k in self._fields if k[0] == type_name and k[1].startswith("~")]:
            del self._fields[key]
        self._sorted.pop(type_name, None)

    def trim(self, type_name: str) -> int:
        """Let go of loaded NPCs or buildings nobody's using: unchanged since read, and held by nothing but this
        store (they're read again if asked for). Returns how many went."""
        if type_name not in LAZY:
            return 0
        bucket = self._by_type[type_name]
        pack = self.packer.pack
        # the store's own lookups hold them too: forget those first (they're cheap to make again)
        self._fields = {k: v for k, v in self._fields.items() if k[0] != type_name}
        self._sorted.pop(type_name, None)
        self._names.pop(type_name, None)
        drop = []
        for eid in list(bucket):
            if eid in self._overlay or eid not in self._sig:
                continue
            e = bucket[eid]
            if sys.getrefcount(e) > 3:                   # the bucket, `e`, getrefcount's own argument
                del e
                continue
            if pack(e) != self._sig[eid]:
                continue                                 # changed and not saved yet: keep it
            drop.append(eid)
        e = None
        for eid in drop:
            del bucket[eid]
            self._sig.pop(eid, None)
        if drop:
            self._fresh_file = False                     # what's not in memory may now be in the file
        if drop:
            self._complete.discard(type_name)
        return len(drop)

    def save(self, type_name: str | None = None) -> None:
        """Write what's changed (only what's changed) to the file. (Inside batch(), not until it's over.)"""
        if self._batching:
            self.touch(type_name)
            return
        self.touch(type_name)          # whatever was edited directly is picked up by the indexes
        overlay_touched = False
        db = self._conn()
        pack = self.packer.pack
        types = [type_name] if type_name else TYPE_ORDER
        db.execute("BEGIN")
        try:
            for t in types:
                lazy = t in LAZY
                for eid in self._deleted.pop(t, set()):
                    if lazy:
                        self._unref(db, t, eid)
                    db.execute("DELETE FROM entities WHERE id=?", (eid,))
                    self._sig.pop(eid, None)
                rows, drop_refs, add_refs = [], [], []
                store = self.packer.store
                for eid, e in list(self._by_type.get(t, {}).items()):
                    if eid in self._overlay:
                        overlay_touched = True
                        if eid in self._sig:                 # handed over to the save: out of the world's file
                            if lazy:
                                self._unref(db, t, eid)
                            db.execute("DELETE FROM entities WHERE id=?", (eid,))
                            self._sig.pop(eid, None)
                        continue
                    data = pack(e)
                    if self._sig.get(eid) == data:
                        continue
                    rows.append((eid, t, e.name, e.name.lower(), store(t, data)))
                    if lazy:                                  # the file's index: only what's changed
                        old = self._stored_refs(db, t, eid)
                        new = _refs(e.fields, t, eid)
                        if old != new:
                            drop_refs += [r for r in old if r not in new]
                            add_refs += [r for r in new if r not in old]
                    self._sig[eid] = data
                if drop_refs:
                    db.executemany("DELETE FROM refs WHERE type=? AND key=? AND value=? AND id=?", drop_refs)
                if rows:
                    db.executemany("INSERT OR REPLACE INTO entities (id, type, name, lname, data) "
                                   "VALUES (?,?,?,?,?)", rows)
                if add_refs:
                    db.executemany("INSERT OR IGNORE INTO refs (type, key, value, id) VALUES (?,?,?,?)", add_refs)
            db.execute("COMMIT")
        except BaseException:
            db.execute("ROLLBACK")
            raise
        if overlay_touched and self.overlay_hook is not None:
            self.overlay_hook()

    def _stored_refs(self, db, t: str, eid: str) -> list[tuple]:
        """The file's index rows for an entity, worked out from its record in the file."""
        data = self._sig.get(eid)
        if data is None:
            if self._fresh_file:
                return []                                # nothing's been written yet that it could be
            row = db.execute("SELECT data FROM entities WHERE id=?", (eid,)).fetchone()
            if row is None:
                return []
            data = row[0]
        return _refs(self.packer.fields(t, data, INDEXED[t]), t, eid)

    def _unref(self, db, t: str, eid: str) -> None:
        """Take an entity's lookups out of the file's index."""
        db.executemany("DELETE FROM refs WHERE type=? AND key=? AND value=? AND id=?", self._stored_refs(db, t, eid))

    def _save_for(self, entity: Entity) -> None:
        """Write out one changed entity: a save-owned one goes to the save, not the world's files."""
        if entity.id in self._overlay:
            if self.overlay_hook is not None:
                self.overlay_hook()
        else:
            self.save(entity.type)

    def put(self, entity: Entity) -> Entity:
        """Add (or replace) an entity in memory; it's written at the next save of its type."""
        self._by_type[entity.type][entity.id] = entity
        self._deleted.get(entity.type, set()).discard(entity.id)
        self.touch(entity.type)
        self._drop_mem_index(entity.type)
        return entity

    def remove(self, entity_id: str) -> None:
        """Take an entity out (no checks, no unlinking); it leaves the file at the next save of its type."""
        type_name = entity_id.split(".", 1)[0]
        if self._by_type.get(type_name, {}).pop(entity_id, None) is not None or type_name in LAZY:
            self._deleted.setdefault(type_name, set()).add(entity_id)
        self._overlay.discard(entity_id)
        self.touch(type_name)
        self._drop_mem_index(type_name)

    def compact_later(self, type_names: list[str]) -> None:
        """compact() now, or at the end of the batch() under way."""
        if self._batching:
            self._pending.update(type_names)
        else:
            self.compact(type_names)

    @contextmanager
    def batch(self):
        """Many packs going in at once (a new world): their records are packed together at the end."""
        self._batching += 1
        try:
            yield self
        finally:
            self._batching -= 1
            if not self._batching:
                todo, self._pending = sorted(self._pending), set()
                if todo and self._fresh_file:
                    from game import recordpack           # nothing written yet: pack it all as it goes in
                    recordpack.plan(self, todo)
                    todo = []
                self.save()
                if todo:
                    self.compact(todo)

    def compact(self, type_names: list[str] | None = None) -> None:
        """Work out each kind's defaults again from what's stored, and rewrite every record of those types as
        its differences from them (game/recordpack.py). After a pack adds thousands of entities."""
        from game import recordpack
        types = type_names or TYPE_ORDER
        self.save()
        recordpack.compact(self, types)

    def stored_ids(self, type_name: str) -> set[str]:
        """The ids written in the world's file (not the save's own entities, nor unsaved ones)."""
        return {r[0] for r in self._conn().execute("SELECT id FROM entities WHERE type=?", (type_name,))}

    def export_json(self, folder: Path) -> None:
        """Every entity written out the old way, one JSON file per type (for tools, and older versions)."""
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        for t in TYPE_ORDER:
            ents = [e for e in self.all(t) if e.id not in self._overlay]
            if ents:
                payload = {"format": FILE_FORMAT, "type": t, "entities": [e.to_dict(False) for e in ents]}
                (folder / f"{t}.json").write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")

    def _import_json(self) -> None:
        """A world from before step 18 (one JSON file per type): moved into the database a type at a time, each
        already packed (its archetypes worked out from the file first), and the old files deleted."""
        from game import progress, recordpack
        db = self._conn()
        files = [(t, self.folder / f"{t}.json") for t in TYPE_ORDER if (self.folder / f"{t}.json").exists()]
        sizes = {t: p.stat().st_size for t, p in files}
        total, done = max(1, sum(sizes.values())), 0
        db.execute("BEGIN")
        try:
            for t, path in files:
                progress.report(done / total, "Upgrading the world's files")
                done += sizes[t]
                ents = [Entity.from_dict(raw) for raw in
                        json.loads(path.read_text(encoding="utf-8")).get("entities", [])]
                step = max(1, len(ents) // recordpack.TALLY)
                arch = recordpack.work_out(t, (recordpack.flat(e) for e in ents[::step]))
                by_id = sorted(((e.id, e) for e in ents), key=lambda r: r[0])
                recordpack._write_plan(db, [t], arch, lambda tt, packer: [
                    packer.pack(e) for e in recordpack._every(by_id)])
                packer = self.packer
                packer.reload()
                db.executemany("INSERT OR REPLACE INTO entities (id, type, name, lname, data) VALUES (?,?,?,?,?)",
                               [(e.id, t, e.name, e.name.lower(), packer.store(t, packer.pack(e))) for e in ents])
                if t in LAZY:
                    db.executemany("INSERT OR IGNORE INTO refs (type, key, value, id) VALUES (?,?,?,?)",
                                   [r for e in ents for r in _refs(e.fields, t, e.id)])
                del ents, by_id
            db.execute("INSERT OR REPLACE INTO meta (key, value) VALUES ('format', ?)", (str(DB_FORMAT),))
            db.execute("COMMIT")
        except BaseException:
            db.execute("ROLLBACK")
            self.packer.reload()
            raise
        for _t, path in files:
            try:
                path.unlink()
            except OSError:
                pass

    # ==================================================================
    # Save-owned entities
    # ==================================================================
    def is_overlay(self, entity_id: str) -> bool:
        return entity_id in self._overlay

    def overlay_entities(self) -> list[Entity]:
        out = []
        for i in sorted(self._overlay):
            e = self._by_type.get(i.split(".", 1)[0], {}).get(i)
            if e is not None:
                out.append(e)
        return out

    def add_overlay(self, entity: Entity) -> Entity:
        """Put a save-owned entity in (its id is changed if the world already uses it)."""
        self.rev = getattr(self, "rev", 0) + 1
        if self.get(entity.id) is not None and entity.id not in self._overlay:
            entity.id = self._new_id(entity.type, entity.name)
        self._by_type[entity.type][entity.id] = entity
        self._overlay.add(entity.id)
        self.touch(entity.type)
        self._drop_mem_index(entity.type)
        return entity

    def clear_overlay(self) -> None:
        """Take every save-owned entity out (another save is being loaded)."""
        self.rev = getattr(self, "rev", 0) + 1
        for eid in list(self._overlay):
            t = eid.split(".", 1)[0]
            self._by_type.get(t, {}).pop(eid, None)
            self._drop_mem_index(t)
        self._overlay.clear()
        self.touch()

    def move_to_overlay(self, entity_id: str) -> None:
        """Hand a world entity over to the save (it leaves the world's files)."""
        self.rev = getattr(self, "rev", 0) + 1
        e = self.get(entity_id)
        if e is not None and entity_id not in self._overlay:
            self._overlay.add(entity_id)
            self.save(e.type)

    # ==================================================================
    # Queries
    # ==================================================================
    def get(self, entity_id: str | None) -> Entity | None:
        if not entity_id or "." not in entity_id:
            return None
        type_name = entity_id.split(".", 1)[0]
        bucket = self._by_type.get(type_name)
        if bucket is None:
            return None
        got = bucket.get(entity_id)
        if got is None and type_name in LAZY and type_name not in self._complete and \
                entity_id not in self._deleted.get(type_name, ()):
            got = self._fetch(entity_id)
        if got is None and "@" in entity_id and type_name == "item":      # an item of some quality, or damaged
            from game import quality
            return quality.make(self, entity_id)
        return got

    def _each(self, type_name: str):
        if type_name in LAZY and type_name not in self._complete:
            self._read_all(type_name)
        return self._by_type[type_name].values()

    def all(self, type_name: str) -> list[Entity]:
        cached = self._sorted.get(type_name)
        if cached is None or (type_name in LAZY and type_name not in self._complete):
            cached = sorted(self._each(type_name), key=lambda e: e.name.lower())
            self._sorted[type_name] = cached
        return list(cached)

    def count(self, type_name: str) -> int:
        if type_name not in LAZY or type_name in self._complete:
            return len(self._by_type[type_name])
        stored = self._conn().execute("SELECT COUNT(*) FROM entities WHERE type=?", (type_name,)).fetchone()[0]
        unsaved = sum(1 for eid in self._by_type[type_name] if eid not in self._sig)
        gone = sum(1 for eid in self._deleted.get(type_name, ()) if eid not in self._by_type[type_name])
        return stored + unsaved - gone

    def counts(self) -> dict[str, int]:
        return {t: self.count(t) for t in self._by_type}

    def everything(self) -> list[Entity]:
        return [e for t in TYPE_ORDER for e in self.all(t)]

    def search(self, text: str = "", type_name: str | None = None, tag: str | None = None) -> list[Entity]:
        needle = text.strip().lower()
        if type_name in LAZY and type_name not in self._complete and needle and not tag:
            return self._search_lazy(type_name, needle)
        pool = self.all(type_name) if type_name else self.everything()
        out = []
        for e in pool:
            if tag and tag.lower() not in (t.lower() for t in e.tags):
                continue
            if needle and needle not in e.name.lower() and needle not in " ".join(e.tags).lower() \
                    and needle not in e.description.lower():
                continue
            out.append(e)
        return out

    def _search_lazy(self, type_name: str, needle: str) -> list[Entity]:
        """Search NPCs or buildings by name, tag or description without reading them all."""
        text = self.packer.text
        ids = [eid for eid, lname, data in self._conn().execute(
               "SELECT id, lname, data FROM entities WHERE type=? ORDER BY lname", (type_name,))
               if needle in lname or needle in text(type_name, data).lower()]
        seen_ids = set(ids)
        out = []
        for eid in ids:
            e = self.get(eid)
            if e is not None and (needle in e.name.lower() or needle in " ".join(e.tags).lower()
                                  or needle in e.description.lower()):
                out.append(e)
        for e in self._by_type[type_name].values():            # and the ones changed in memory
            if e.id not in seen_ids and (needle in e.name.lower() or needle in e.description.lower()
                                    or needle in " ".join(e.tags).lower()):
                out.append(e)
        return sorted(out, key=lambda e: e.name.lower())

    def find_by_name(self, type_name: str, name: str) -> Entity | None:
        key = str(name or "").lower()
        if type_name in LAZY and type_name not in self._complete:
            for e in self._by_type[type_name].values():        # in memory first (it may be newer)
                if e.name.lower() == key:
                    return e
            gone = self._deleted.get(type_name, ())
            for (eid,) in self._conn().execute("SELECT id FROM entities WHERE type=? AND lname=? ORDER BY rowid",
                                               (type_name, key)):
                if eid in gone:
                    continue
                e = self.get(eid)
                if e is not None and e.name.lower() == key:
                    return e
            return None
        names = self._names.get(type_name)
        if names is None:
            names = {}
            for e in self._by_type[type_name].values():
                names.setdefault(e.name.lower(), e)
            self._names[type_name] = names
        return names.get(key)

    def has_name(self, type_name: str, name: str) -> bool:
        """Is this exact name taken (for picking a new building's or person's name) - without reading them all."""
        if type_name not in LAZY or type_name in self._complete:
            return any(e.name == name for e in self._by_type[type_name].values())
        if any(e.name == name for e in self._by_type[type_name].values()):
            return True
        gone = self._deleted.get(type_name, ())
        loaded = self._by_type[type_name]
        for (eid, nm) in self._conn().execute("SELECT id, name FROM entities WHERE type=? AND lname=?",
                                             (type_name, name.lower())):
            if nm == name and eid not in gone and eid not in loaded:
                return True
        return False

    def having(self, type_name: str, key: str) -> list[Entity]:
        """Entities with anything at all in an indexed field (e.g. buildings with an owner)."""
        if type_name not in LAZY or type_name in self._complete or key not in INDEXED.get(type_name, {}):
            how = INDEXED.get(type_name, {}).get(key, key)
            return [e for e in self._each(type_name) if _values_of(e, key, how)]
        how = INDEXED[type_name][key]
        loaded = self._by_type[type_name]
        out = [e for e in loaded.values() if _values_of(e, key, how)]
        gone = self._deleted.get(type_name, set())
        for (eid,) in self._conn().execute("SELECT DISTINCT id FROM refs WHERE type=? AND key=?",
                                           (type_name, key)).fetchall():
            if eid not in loaded and eid not in gone:
                e = self._fetch(eid)
                if e is not None:
                    out.append(e)
        return out

    def id_names(self, type_name: str) -> list[tuple[str, str]]:
        """(id, name) of every entity of a type, by name - for pickers, without reading the entities."""
        if type_name not in LAZY or type_name in self._complete:
            return [(e.id, e.name) for e in self.all(type_name)]
        loaded = self._by_type[type_name]
        gone = self._deleted.get(type_name, set())
        rows = {eid: nm for eid, nm in self._conn().execute(
            "SELECT id, name FROM entities WHERE type=? ORDER BY lname", (type_name,)) if eid not in gone}
        for eid, e in loaded.items():
            rows[eid] = e.name
        return sorted(rows.items(), key=lambda r: r[1].lower())

    def stats(self) -> list[Entity]:
        return self.all("stat")

    def stat_by_key(self, key: str) -> Entity | None:
        found = self.by_field("stat", "key", key)
        return found[0] if found else None

    def used_by(self, entity_id: str) -> list[tuple[Entity, str]]:
        users = []
        for other in self.everything():
            if other.id == entity_id:
                continue
            template = self.templates.get(other.type)
            for f in template.fields():
                if entity_id in f.link_ids(other.fields.get(f.key)):
                    users.append((other, f.label))
            for c in other.custom:
                if c.get("type") in ("link", "links"):
                    probe = FieldDef(c["key"], c.get("label", c["key"]), c["type"])
                    if entity_id in probe.link_ids(c.get("value")):
                        users.append((other, c.get("label", c["key"])))
        return users

    # ==================================================================
    # Validation
    # ==================================================================
    def clean(self, type_name: str, name: str, fields: dict | None, description: str = "",
              tags: list | None = None, custom: list | None = None,
              current_id: str | None = None) -> tuple[dict, list[dict], list[str]]:
        """Coerce and check values. Returns (fields, custom, problems)."""
        template = self.templates.get(type_name)
        problems: list[str] = []
        if not str(name or "").strip():
            problems.append("Name is required")
        given = dict(fields or {})
        cleaned: dict[str, Any] = {}
        for f in template.fields():
            if f.key in ("name", "description", "tags"):
                continue
            raw = given[f.key] if f.key in given else f.empty()      # a missing field: its empty value
            try:
                cleaned[f.key] = f.coerce(raw)
            except (TypeError, ValueError):
                problems.append(f"{f.label}: '{raw}' isn't a valid {f.type}")
                cleaned[f.key] = f.empty()
        # Keep values for fields the template no longer has, so nothing is silently lost.
        for key, value in given.items():
            if key not in cleaned and not template.field(key):
                cleaned[key] = value

        if type_name == "stat":
            key = cleaned.get("key") or variable_name(cleaned.get("abbreviation") or name or "stat")
            cleaned["key"] = variable_name(key)
            other = self.stat_by_key(cleaned["key"])
            if other and other.id != current_id:
                problems.append(f"Another stat ({other.name}) already uses the variable name '{cleaned['key']}'")

        merged = {**cleaned, "name": name, "description": description, "tags": tags or []}
        for step in template.steps:
            if not step.visible(merged):
                continue
            for f in step.fields:
                if f.key in ("name", "description", "tags"):
                    continue
                if f.visible(merged):
                    problems.extend(f.validate(cleaned[f.key]))

        clean_custom = []
        seen = set()
        for c in custom or []:
            label = str(c.get("label") or c.get("key") or "").strip()
            if not label:
                continue
            key = variable_name(c.get("key") or label)
            if key in seen or template.field(key):
                problems.append(f"Custom field '{label}' clashes with an existing field")
                continue
            seen.add(key)
            ftype = c.get("type", "text")
            try:
                probe = FieldDef(key, label, ftype)
                value = probe.coerce(c.get("value"))
                problems.extend(probe.validate(value))
            except (TypeError, ValueError) as exc:
                problems.append(f"Custom field '{label}': {exc}")
                continue
            clean_custom.append({"key": key, "label": label, "type": ftype, "value": value})
        return cleaned, clean_custom, problems

    # ==================================================================
    # Changes
    # ==================================================================
    def create(self, type_name: str, name: str, fields: dict | None = None, description: str = "",
               tags: list | None = None, custom: list | None = None, save: bool = True,
               entity_id: str | None = None, overlay: bool = False) -> Entity:
        cleaned, clean_custom, problems = self.clean(type_name, name, fields, description, tags, custom)
        if problems:
            raise ValidationError(problems)
        new_id = entity_id if entity_id and not self.get(entity_id) else self._new_id(type_name, name)
        stamp = _now()
        entity = Entity(new_id, type_name, str(name).strip(), description or "",
                        [str(t).strip() for t in (tags or []) if str(t).strip()],
                        cleaned, clean_custom, stamp, stamp)
        self.put(entity)
        if overlay:
            self._overlay.add(entity.id)
        if save:
            self._save_for(entity)
        self._changed("created", entity)
        return entity

    def update(self, entity_id: str, name: str | None = None, fields: dict | None = None,
               description: str | None = None, tags: list | None = None, custom: list | None = None,
               save: bool = True) -> Entity:
        entity = self.get(entity_id)
        if not entity:
            raise KeyError(entity_id)
        new_name = entity.name if name is None else name
        merged_fields = {**entity.fields, **(fields or {})}
        new_desc = entity.description if description is None else description
        new_tags = entity.tags if tags is None else tags
        new_custom = entity.custom if custom is None else custom
        cleaned, clean_custom, problems = self.clean(entity.type, new_name, merged_fields, new_desc,
                                                     new_tags, new_custom, current_id=entity.id)
        if problems:
            raise ValidationError(problems)
        entity.name = str(new_name).strip()
        entity.description = new_desc or ""
        entity.tags = [str(t).strip() for t in new_tags if str(t).strip()]
        entity.fields = cleaned
        entity.custom = clean_custom
        entity.modified = _now()
        self.touch(entity.type)
        self._drop_mem_index(entity.type)
        if save:
            self._save_for(entity)
        self._changed("updated", entity)
        return entity

    def delete(self, entity_id: str, force: bool = False, save: bool = True) -> None:
        entity = self.get(entity_id)
        if not entity:
            return
        users = self.used_by(entity_id)
        if users and not force:
            raise InUseError(entity, users)
        was_overlay = entity_id in self._overlay
        self.remove(entity_id)
        if users:
            self._unlink(entity_id)
            self.touch()
        if save:
            self.save()
            if was_overlay and self.overlay_hook is not None:
                self.overlay_hook()
        self._changed("deleted", entity)

    def duplicate(self, entity_id: str) -> Entity:
        entity = self.get(entity_id)
        if not entity:
            raise KeyError(entity_id)
        base = f"{entity.name} (copy)"
        name, n = base, 2
        while self.find_by_name(entity.type, name):
            name = f"{entity.name} (copy {n})"
            n += 1
        fields = copy.deepcopy(entity.fields)
        if entity.type == "stat":
            fields["key"] = ""
        return self.create(entity.type, name, fields, entity.description, list(entity.tags),
                           copy.deepcopy(entity.custom))

    def promote_custom_field(self, entity_id: str, key: str) -> None:
        """Turn a one-off custom field into a template field for every entity of this type."""
        entity = self.get(entity_id)
        custom = next((c for c in entity.custom if c["key"] == key), None)
        if not custom:
            raise KeyError(key)
        self.templates.add_world_field(entity.type, FieldDef(key, custom["label"], custom["type"]))
        entity.fields[key] = custom.get("value")
        entity.custom = [c for c in entity.custom if c["key"] != key]
        self.touch(entity.type)
        self.save(entity.type)
        self._changed("updated", entity)

    # ==================================================================
    def _new_id(self, type_name: str, name: str) -> str:
        base = f"{type_name}.{slugify(name)}"
        new_id, n = base, 2
        while self.get(new_id):
            new_id = f"{base}-{n}"
            n += 1
        return new_id

    def _unlink(self, entity_id: str) -> None:
        """Remove references to a deleted entity everywhere."""
        def scrub(f: FieldDef, value):
            if f.type == "link":
                return None if value == entity_id else value
            if f.type == "links":
                return [v for v in value or [] if v != entity_id]
            if f.type == "loadout":
                return {k: v for k, v in (value or {}).items() if v != entity_id}
            if f.type == "appearance":
                value = dict(value or {})
                if value.get("race") == entity_id:
                    value.pop("race")
                return value
            if f.type == "table":
                rows = []
                for row in value or []:
                    rows.append({c.key: scrub(c, row.get(c.key)) for c in f.columns})
                return rows
            return value

        for other in self.everything():
            template = self.templates.get(other.type)
            changed = False
            for f in template.fields():
                if f.key in other.fields:
                    new = scrub(f, other.fields[f.key])
                    if new != other.fields[f.key]:
                        other.fields[f.key] = new
                        changed = True
            if changed:
                other.modified = _now()

    def _changed(self, what: str, entity: Entity) -> None:
        self.rev += 1
        if self.on_change:
            self.on_change(what, entity)


# ======================================================================
def _ref_text(v) -> str:
    return v if isinstance(v, str) else json.dumps(v)


def _values_of(e: Entity, key: str, how) -> list:
    """The values an entity is indexed under for a key: its field (each item of a list field), or one column
    of a table field's rows."""
    return _field_values(e.fields, how)


def _field_values(fields: dict, how) -> list:
    if isinstance(how, tuple):
        table, col = how
        out = []
        for row in fields.get(table) or []:
            if isinstance(row, dict):
                v = row.get(col)
                if _indexable(v):
                    out.append(v)
        return out
    v = fields.get(how)
    if isinstance(v, (list, tuple, set)):
        return [x for x in v if _indexable(x)]
    if _indexable(v):
        return [v]
    return []


def _refs(fields: dict, t: str, eid: str) -> list[tuple]:
    """The rows of the file's index for an entity's fields."""
    out = []
    for k, how in INDEXED[t].items():
        for v in _field_values(fields, how):
            r = (t, k, _ref_text(v), eid)
            if r not in out:
                out.append(r)
    return out


def _indexable(v) -> bool:
    """Strings, numbers and yes are looked up by; empty strings, no and anything else aren't."""
    if isinstance(v, bool):
        return v
    return isinstance(v, (str, int, float)) and v != ""


