"""How the party is doing between fights: hit points, hit dice, spell slots and
feature uses, and resting to get them back (5e rules).

Short rest (1 hour): spend hit dice to heal (each: roll the class's hit die + CON
modifier, spent automatically until healed or out of dice); per-short-rest
features come back.
Long rest (8 hours): all hit points, all spell slots and feature uses, and half
your hit dice (at least one) come back. Only one long rest counts per 24 hours.
Resource pools (Ki, Sorcery Points...) come back on the rest their class says;
magic items regain charges after a long rest ("at dawn").

Stored in the game state per party member. Test fights (Arena) ignore all this
and start everyone fresh.
"""
from __future__ import annotations

import random

from game import dice
from game.combat import builders as B

SHORT_REST_MIN = 60
LONG_REST_MIN = 8 * 60
LONG_REST_GAP = 16 * 60      # minutes after a long rest before another one counts


def combatant(world, m: dict, potions: int | None = None, team: str = "player"):
    """A party member's fighting numbers, worked out from the world (see game/character.py)."""
    from game.character import build
    return build(world, m, team, potions=int(m.get("potions", 0) if potions is None else potions))


def hit_die(world, m: dict) -> int:
    klass = world.entities.get(m.get("class"))
    try:
        return int(str((klass.fields.get("hit_die") if klass else "d8") or "d8").lstrip("d") or 8)
    except ValueError:
        return 8


def record(state, m: dict) -> dict:
    return state.party.setdefault(m["id"], {})


def apply(state, m: dict, c) -> None:
    """Put a member's saved condition onto a freshly built combatant."""
    rec = state.party.get(m.get("id", ""))
    if not rec:
        return
    if rec.get("hp") is not None:
        c.hp = max(1, min(c.max_hp, int(rec["hp"])))
    if rec.get("mana") is not None and c.mana_max:
        c.mana = max(0, min(c.mana_max, int(rec["mana"])))
    if rec.get("slots") is not None:
        for lvl in list(c.slots):
            c.slots[lvl] = max(0, min(c.slots_max.get(lvl, 0), int(rec["slots"].get(str(lvl), c.slots[lvl]))))
    for f in c.features:
        if f.per_rest and f.id in (rec.get("uses") or {}):
            f.uses_left = max(0, min(f.max_uses, int(rec["uses"][f.id])))
    for name, cur in (rec.get("resources") or {}).items():
        if name in c.resources:
            c.resources[name]["cur"] = max(0, min(c.resources[name]["max"], int(cur)))
    for item_id, n in (rec.get("charges") or {}).items():
        if item_id in c.charges:
            c.charges[item_id] = max(0, min(c.charges[item_id], int(n)))
    # conditions that last until a rest (from mechanics), exhaustion, and custom values
    for name, rounds in (rec.get("conditions") or {}).items():
        if name == "Exhaustion":
            c.conditions[name] = {"rounds": -1, "source": "", "save": None, "level": int(rounds), "lasting": True}
        else:
            c.conditions[name] = {"rounds": -1, "source": "", "save": None, "lasting": True}
    c.vars.update(rec.get("vars") or {})
    if rec.get("temp_hp") or (getattr(state, "survival", None) and (state.survival.get(m.get("id", "")) or {})
                              .get("afflictions")):
        from game import survival                    # a good meal; disease and curses (game/survival.py)
        survival.apply(state, m, c)
    if c.conditions:
        from game.combat.conditions import exhaustion
        if exhaustion(c) >= 4:
            c.max_hp = max(1, c.base_max_hp // 2)
            c.hp = min(c.hp, c.max_hp)


def store(state, m: dict, c, save: bool = True) -> None:
    """Remember a member's condition after a fight (someone who went down comes to at 1 HP)."""
    rec = record(state, m)
    rec["hp"] = max(1, int(c.hp))
    rec["max"] = int(c.max_hp)
    rec["mana"] = int(getattr(c, "mana", 0))
    rec["slots"] = {str(k): int(v) for k, v in c.slots.items()}
    rec["uses"] = {f.id: int(f.uses_left) for f in c.features if f.per_rest}
    rec["resources"] = {name: int(p["cur"]) for name, p in (getattr(c, "resources", {}) or {}).items()}
    if "temp_hp" in rec or getattr(c, "temp_hp", 0):
        rec["temp_hp"] = int(getattr(c, "temp_hp", 0) or 0)
    if getattr(c, "charges", None):
        rec.setdefault("charges", {}).update({k: int(v) for k, v in c.charges.items()})
    rec.setdefault("hit_dice", int(m.get("level") or 1))
    lasting = {}
    from game import survival
    own = {a["name"] for a in survival.afflictions(state, m.get("id", ""))} | {"Blinded"} \
        if survival.afflictions(state, m.get("id", "")) else set()
    for name, cond in (getattr(c, "conditions", {}) or {}).items():
        if name == "Exhaustion":
            lasting[name] = int(cond.get("level", 1))
        elif cond.get("lasting") and name not in own:     # (what afflicts them is put back on: survival.apply)
            lasting[name] = -1
    rec["conditions"] = lasting
    if getattr(c, "vars", None):
        rec.setdefault("vars", {}).update(c.vars)
    if save:
        state.save()


def hit_dice_left(state, m: dict) -> int:
    return int(record(state, m).get("hit_dice", int(m.get("level") or 1)))


def short_rest(world, state, members: list[dict], rng: random.Random | None = None, bus=None) -> list[str]:
    rng = rng or random.Random()
    state.advance(SHORT_REST_MIN, "short rest")
    lines = []
    for m in members:
        if m.get("dead"):
            continue
        c = combatant(world, m)
        apply(state, m, c)
        rec = record(state, m)
        hd = hit_dice_left(state, m)
        die = hit_die(world, m)
        con = c.mods.get(world.rules.get("hp_stat", "con"), 0)
        healed, spent = 0, 0
        while c.hp < c.max_hp and hd > 0:
            gain = max(1, dice.roll(f"1d{die}", rng).total + con)
            c.hp = min(c.max_hp, c.hp + gain)
            healed += gain
            hd -= 1
            spent += 1
        for f in c.features:
            if f.uses == "Per short rest":
                f.uses_left = f.max_uses
        for pool in c.resources.values():
            if pool.get("recharge") == "Short rest":
                pool["cur"] = pool["max"]
        if c.mana_max:
            key = "short_rest_stamina" if c.mana_name == "Stamina" else "short_rest_mana"
            pct = int(world.rules.get(key, 100 if c.mana_name == "Stamina" else 0) or 0)
            c.mana = min(c.mana_max, c.mana + c.mana_max * pct // 100)
        store(state, m, c, save=False)
        rec["hit_dice"] = hd
        if spent:
            lines.append(f"{c.name} spends {spent} hit di{'ce' if spent > 1 else 'e'} and recovers HP "
                         f"({c.hp}/{c.max_hp}).")
        else:
            lines.append(f"{c.name} catches their breath ({c.hp}/{c.max_hp} HP).")
    state.save()
    _say(bus, ["You take a short rest."] + lines)
    if bus is not None:
        bus.emit("party.rested", kind="short")
    return lines


def can_long_rest(state) -> int:
    """Minutes until a long rest would count (0 = now)."""
    return max(0, state.last_long_rest + LONG_REST_GAP - state.minutes)


def long_rest(world, state, members: list[dict], bus=None, minutes: int = LONG_REST_MIN) -> list[str]:
    wait = can_long_rest(state)
    if wait:
        _say(bus, [f"You're not tired enough for another long rest. Try again in {wait // 60 + 1} hours."])
        return []
    from game import survival
    if survival.on(world):                       # asleep: no tiredness piles up while they sleep
        survival.resting(state, members)
    state.advance(minutes, "long rest")
    state.last_long_rest = state.minutes
    lines = []
    for m in members:
        if m.get("dead"):
            continue
        c = combatant(world, m)
        c.hp = c.max_hp
        c.mana = c.mana_max
        c.slots = dict(c.slots_max)
        for f in c.features:
            if f.per_rest:
                f.uses_left = f.max_uses
        for pool in c.resources.values():
            if pool.get("recharge") != "Never":
                pool["cur"] = pool["max"]
        for item_id in list(c.charges):
            item = world.entities.get(item_id)
            regain = str((item.fields.get("charges_regain") if item is not None else "") or "")
            top = int(item.fields.get("charges") or 0) if item is not None else 0
            if regain and dice.is_valid(regain):
                c.charges[item_id] = min(top, c.charges[item_id] + max(0, dice.roll(regain).total))
        level = int(m.get("level") or 1)
        hd = min(level, hit_dice_left(state, m) + max(1, level // 2))
        before = int((record(state, m).get("conditions") or {}).get("Exhaustion", 0))
        store(state, m, c, save=False)
        rec = record(state, m)
        rec["hit_dice"] = hd
        conds = {}
        if before:                          # a long rest eases exhaustion by one (if they've eaten and drunk)
            from game import survival
            left = survival.after_long_rest(world, state, m, before) if (survival.on(world) or
                                                                          survival.diseases_on(world)) else before - 1
            if left:
                conds["Exhaustion"] = left
        rec["conditions"] = conds
        rec.pop("temp_hp", None)
        lines.append(f"{c.name} is fully rested ({c.max_hp} HP).")
    state.save()
    _say(bus, ["You sleep through the night." if minutes >= LONG_REST_MIN else "You rest."] + lines)
    if bus is not None:
        bus.emit("party.rested", kind="long")
    return lines


def knocked_out(world, state, members: list[dict], bus=None) -> str:
    """'Wake up in town': a beaten party comes to back in the last town, hurt. Anyone who
    died in the fight stays dead (a temple can raise them)."""
    for m in members:
        if m.get("dead"):
            continue
        c = combatant(world, m)
        apply(state, m, c)
        c.hp = 1
        store(state, m, c, save=False)
    state.journey = None
    state.advance(8 * 60, "knocked out")
    town = world.entities.get(state.last_town) or next(iter(world.entities.all("town")), None)
    from game import places
    where = ""
    if town is not None:
        healer = next((b for b in places.buildings_in(world, town)
                       if b.fields.get("kind") in ("Temple", "Inn", "Tavern")), None)
        where = healer.id if healer else places.street_id(town.id, places.first_street(town))
        places.enter(world, state, where, bus)
    state.save()
    text = (f"Everything goes dark. You wake hours later in {town.name if town else 'a strange place'}, "
            f"battered but alive.")
    _say(bus, [text])
    return text


def _say(bus, lines: list[str]) -> None:
    if bus is None:
        return
    for i, line in enumerate(lines):
        bus.emit("log", kind="narration" if i == 0 else "heal", text=line)


# ======================================================================
# Casting outside a fight
# ======================================================================
OUTSIDE_EFFECTS = ("Healing", "Remove condition", "Revive")


def _minutes(text: str) -> int:
    """'1 minute' -> 1, '10 days' -> 14400, 'Any time' -> very long."""
    import re
    s = str(text or "").lower()
    if not s or "any" in s or "ever" in s:
        return 10 ** 9
    m = re.search(r"(\d+)\s*(round|minute|min|hour|day)", s)
    if not m:
        return 1
    n, unit = int(m.group(1)), m.group(2)
    return max(1, n * {"round": 1, "minute": 1, "min": 1, "hour": 60, "day": 1440}[unit] // (10 if unit == "round" else 1))


def outside_spells(world, state, m: dict) -> list:
    """Spells this member could usefully cast right now, outside combat: (Spell, lowest level)."""
    from game.combat.engine import Battle
    from game import jail
    if jail.antimagic(world, state):                    # a jail's wards (game/jail.py)
        return []
    c = combatant(world, m)
    apply(state, m, c)
    out = []
    mana_rules = (world.rules.get("magic_system") or "Mana") == "Mana" and c.mana_max
    per = int(world.rules.get("mana_per_spell_level", 10) or 10)
    for s in c.spells:
        if s.effect not in OUTSIDE_EFFECTS:
            continue
        if s.level == 0:
            out.append((s, 0))
        elif mana_rules and c.mana >= per * s.level and (c.max_cast_level or 0) >= s.level:
            out.append((s, s.level))
        elif not mana_rules and any(n > 0 for lvl, n in c.slots.items() if lvl >= s.level):
            out.append((s, min(lvl for lvl, n in c.slots.items() if lvl >= s.level and n > 0)))
    return out


def cast_outside(world, state, caster_m: dict, spell_id: str, target_m: dict, rng=None, bus=None) -> str:
    """Cast a healing, curing or reviving spell between fights. Returns what happened ('' = couldn't)."""
    rng = rng or random.Random()
    c = combatant(world, caster_m)
    apply(state, caster_m, c)
    found = next(((s, lvl) for s, lvl in outside_spells(world, state, caster_m) if s.id == spell_id), None)
    if found is None:
        return ""
    spell, level = found
    if caster_m.get("dead"):
        return ""
    text = ""
    if spell.effect == "Revive":
        if not target_m.get("dead"):
            return f"{target_m.get('name')} isn't dead."
        died = int(target_m.get("died_at", state.minutes) or state.minutes)
        window = _minutes(world.entities.get(spell_id).fields.get("revive_within") or "1 minute") + 10
        if state.minutes - died > window:
            return f"It's too late for {spell.name} to bring {target_m.get('name')} back."
        target_m["dead"] = False
        rec = record(state, target_m)
        rec["hp"] = max(1, int(spell.revive_hp or 1))
        rec["conditions"] = {}
        text = f"{c.name} casts {spell.name}. {target_m.get('name')} breathes again!"
    elif target_m.get("dead"):
        return f"{target_m.get('name')} is beyond that kind of help."
    elif spell.effect == "Healing":
        t = combatant(world, target_m)
        apply(state, target_m, t)
        gain = max(1, dice.roll(spell.healing or "1d8", rng).total + c.mod(c.casting_stat))
        if level > spell.level and spell.upcast:
            for _ in range(level - spell.level):
                gain += dice.roll(spell.upcast, rng).total
        before = t.hp
        t.hp = min(t.max_hp, t.hp + gain)
        store(state, target_m, t, save=False)
        text = f"{c.name} casts {spell.name} on {t.name}: +{t.hp - before} HP ({t.hp}/{t.max_hp})."
    elif spell.effect == "Remove condition":
        rec = record(state, target_m)
        conds = dict(rec.get("conditions") or {})
        gone = [n for n in spell.removes if n in conds]
        for n in gone:
            conds.pop(n)
        rec["conditions"] = conds
        from game import survival
        lifted = survival.cure_spell(world, state, target_m, spell.name)     # disease and curses
        text = (f"{c.name} casts {spell.name}: {target_m.get('name')} is no longer {', '.join(gone).lower()}."
                if gone else (f"{c.name} casts {spell.name}." if lifted else
                              f"{c.name} casts {spell.name}, but there's nothing to cure.")) + lifted
    if spell.level:
        c = combatant(world, caster_m)
        apply(state, caster_m, c)
        if (world.rules.get("magic_system") or "Mana") == "Mana" and c.mana_max:
            c.mana -= int(world.rules.get("mana_per_spell_level", 10) or 10) * level
        else:
            c.slots[level] = max(0, c.slots.get(level, 0) - 1)
        store(state, caster_m, c, save=False)
    state.save()
    _say(bus, [text])
    if bus is not None:
        bus.emit("spell.cast_outside", caster=caster_m.get("id"), spell=spell_id, target=target_m.get("id"))
    return text
